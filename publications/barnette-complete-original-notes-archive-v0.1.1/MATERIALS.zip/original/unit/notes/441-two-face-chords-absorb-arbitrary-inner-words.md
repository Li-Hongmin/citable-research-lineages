> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two face chords absorb arbitrary inner words

The row-IV short-leaf word with sites \((1,7)\), short leaf \(2\), and depth vector \((1,3,4,4,4,4,3)\) is the first remaining row of [Note 437](437-the-fourth-matching-short-leaf-has-thirteen-necessary-depth-words.md). A two-chord splice closes it. The splice holds with two arbitrary inner ordinary words, so it is useful beyond this single tree.

Let \(U_1=((x_1y_1))\) and \(U_7=((x_7y_7))\) be full leaves. Let \(L,B\) be disjoint ordinary words, each occupying a contiguous old-cycle interval, in that order. Suppose \(L\) contains an old-cycle edge \(x_4y_4\), and \(B\) has an outer ordinary chord \(B_\ell B_r\) and contains an old-cycle edge \(x_5y_5\). Put
\[
R=F(B,U_7),\qquad T=F(L,R),\qquad W=F(U_1,T),
\tag{1}
\]
with all three displayed \(F\)-branches full. Suppose the two face edges \(x_4y_5\) and \(x_5y_4\) exist. Write \(\overrightarrow L[a,b]\) for the forward old-cycle segment of \(L\) from \(a\) to \(b\).

The old-cycle path \(B_\ell\to B_r\) plus \(B_\ell B_r\) is a Hamilton cycle of \(B\). Delete \(x_5y_5\) and orient the resulting spanning path as
\[
Z_B=(y_5\xrightarrow{\mathrm{old\ forward}}B_r,\,
      B_\ell\xrightarrow{\mathrm{old\ forward}}x_5),
\tag{2}
\]
where \(B_rB_\ell\) is the intervening ordinary chord. For the six bracket vertices of \(R\), use
\[
J_R=(\lambda_0^R,\rho_0^R,\rho_1^R,\lambda_1^R,
     \lambda_2^R,\rho_2^R).
\tag{3}
\]
Its first, third and last edges are ordinary chords, and its other two edges are old-cycle edges.

**Two-chord absorption lemma.** The old-cycle edges, ordinary chords and the two stipulated face edges contain a spanning \(y_1\)--\(x_7\) path of \(W\):
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,\quad
\lambda_2^W\xrightarrow{P_W}\rho_2^W,\quad
\rho_0^T\xrightarrow{Q_T}\lambda_2^T,\quad
L_\ell\xrightarrow{\overrightarrow L[L_\ell,x_4]}x_4,\\
&y_5\xrightarrow{Z_B}x_5,\quad
y_4\xrightarrow{\overrightarrow L[y_4,L_r]}L_r,\quad
R_\ell=\lambda_0^R\xrightarrow{J_R}\rho_2^R,\quad
R_7\xrightarrow{X_7}x_7.
\end{aligned}                                                     \tag{4}
\]
Here \(Y_1,X_7,P_W,Q_T\) are the leaf and bracket paths of [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md). The nonordinary transitions \(x_4y_5,x_5y_4\) are precisely the assumed face chords. The other joins \(L_1\lambda_2^W\), \(\rho_2^W\rho_0^T\), \(\lambda_2^TL_\ell\), \(L_rR_\ell\), and \(\rho_2^RR_7\) are consecutive old-cycle edges. Deleting \(x_4y_4\) partitions the old-cycle path through \(L\) into the two disjoint segments shown in (4); deleting \(x_5y_5\) gives the disjoint spanning path (2) of \(B\). All three displayed branch wrappers and both end leaves are covered once. Thus (4) contains all \(|L|+|B|+30\) vertices of \(W\) once, proving the lemma. \(\square\)

**Row-IV application.** Take
\[
S_2=(x_2y_2),\qquad A=F(U_3,U_4),\qquad
L=F(S_2,A),\qquad B=F(U_5,U_6).
\tag{5}
\]
Then \(|L|=4+18+6=28\), \(|B|=18\), and (1) has depths \((1,3,4,4,4,4,3)\) with short leaf \(2\). Row IV supplies both crossed face chords in the lemma, and (4) spans \(28+18+30=76\) vertices from site \(y_1\) to site \(x_7\). The fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), closes this path through both site edges in every legal parent completion. By [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md), clause 1, every corresponding legal child is Hamiltonian. Reflection gives the row-V assertion.

Together with Notes 437--440, this leaves eight structurally necessary short-leaf words in row IV/V. Row VI, other kernel branches and Barnette's conjecture remain open.
