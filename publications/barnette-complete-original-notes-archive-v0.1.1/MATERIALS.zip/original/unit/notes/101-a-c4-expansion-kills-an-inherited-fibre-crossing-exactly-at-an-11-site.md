> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A (C_4)-expansion kills an inherited fibre crossing exactly at an (11) site

[Note 100](100-a-legal-wide-fixed-pairing-fibre-need-not-be-convex-in-the-face-flip-lattice.md)
shows that a fixed-pairing crossing edge may be intrinsically nonfacial.
One possible route to a counterexample is therefore to modify a known
plane-brace fibre until all its crossing edges disappear.  This note gives
the exact local test for whether one old crossing edge survives a
\(C_4\)-expansion, then completely applies it to every one-step facial move
on the Note 099 instance.

An inherited crossing is not automatically preserved.  It is destroyed
exactly when the two selected site edges occur together in one endpoint
matching.  This obstruction is realizable by a legal move whose child is
again a plane brace.  Nevertheless, no one-step move on the fixed Note 099
embedding destroys all 69 old crossing edges: every legal-wide brace child
retains at least 19, and its complete fibre still has global cross-sector
minimum one.

## 1. The local lift table

Let a \(C_4\)-expansion replace the vertex-disjoint edges

\[
p=uv,\qquad q=xy
\tag{1}
\]

by

\[
ua,ab,bv,xc,cd,dy,ad,bc.
\tag{2}
\]

For a parent perfect matching \(P\), write

\[
\sigma(P)=({\bf1}_{p\in P},{\bf1}_{q\in P}).
\tag{3}

A lift restricts outside (2) to \(P\setminus\{p,q\}\).  Matching degree at
the four old endpoints and the four new vertices gives the complete table

\[
\begin{array}{c|c|c}
\sigma(P)&\text{patch matching}&\text{complement effect}\\ \hline
00&\{bc,da\}&p,q\text{ are separately subdivided}\\
00&\{ab,cd\}&(uv),(xy)\text{ are reconnected as }(uy),(vx)\\
10&\{ua,bv,cd\}&q\text{ is subdivided}\\
01&\{xc,dy,ab\}&p\text{ is subdivided}\\
11&\{ua,bv,xc,dy\}&abcd\text{ is an isolated complement }C_4.
\end{array}
\tag{4}
\]

Now suppose \(P\) belongs to a fixed-pairing spanning-two-path fibre.  The
first \(00\) pattern and the \(10,01\) patterns preserve both complement
paths and their terminal pairing.  The second \(00\) pattern never does:
if \(p,q\) lie on different paths it changes the terminal pairing, while if
they lie on one path it cuts off a closed component.  The \(11\) pattern
adds the isolated square.  Hence

\[
\boxed{
P\text{ has a unique target-preserving inherited lift}
\iff \sigma(P)\ne11.}
\tag{5}

## 2. Exact survival criterion for a crossing edge

Let \(M,N\) be parent fibre members.  If neither local state is \(11\), use
the target-preserving lifts from (5).  Their local symmetric differences
replace each occurrence of \(p\) or \(q\) by an internally disjoint path
with the same endpoints.  Therefore every component of
\(M\mathbin\triangle N\) is merely subdivided.  In particular,

\[
M\mathbin\triangle N\text{ is one alternating cycle}
\Longrightarrow
\widehat M\mathbin\triangle\widehat N
\text{ is one alternating cycle}.
\tag{6}

Combining (5)--(6) gives the exact inherited-pair test

\[
\boxed{
\{M,N\}\text{ survives as a child-fibre crossing edge}
\iff
\{p,q\}\nsubseteq M\text{ and }\{p,q\}\nsubseteq N.}
\tag{7}

Equivalently, the move kills the old pair exactly when one endpoint has
local state \(11\).  If both site edges lie on the old alternating cycle,
they must have the same matching parity around that cycle.  Merely selecting
one edge of the cycle is insufficient.

## 3. The obstruction occurs in a legal plane brace

In the Note 099 graph, the square

\[
x_3a_1a_0x_2x_3
\tag{8}

is facial.  Expand its opposite edges

\[
p=a_0a_1,\qquad q=x_2x_3
\tag{9}

with orientation \((u,v,x,y)=(a_0,a_1,x_3,x_2)\).  The move touches neither
the root square nor either named gate.  A frozen cross-sector single-cycle
pair from Note 099 has

\[
\{p,q\}\subseteq M\cap N.
\tag{10}

Thus both endpoints have state \(11\), and their unique perfect-matching
lifts acquire an isolated complement square.  Neither lies in the child
fibre.

The child has 36 vertices and 54 edges and remains simple, plane, cubic,
bipartite and 3-connected.  Its 1,755 perfect matchings cover all 1,323
independent edge pairs, so it is again a brace.  The original root square
and legal-wide gate face remain unchanged.  Consequently there is no
unconditional theorem preserving each individual crossing edge under a
legal facial expansion.

## 4. Complete one-step classification of the Note 099 instance

Fix the labelled plane embedding and named root and surviving gate of
Note 099.  It has 94 facial bipartite \(C_4\)-moves.  Of these, 89 retain
the root edge; six of those delete another root-square edge and four delete
the surviving gate.  The remaining 79 carry the inherited fixed-pairing
interface, and all 79 children are braces.

Exactly 74 of the 79 also retain a legal-wide gate face: 65 have closed gate
arcs \((5,5)\), and nine have arcs \((5,7)\).  Across these 74 children:

\[
\begin{array}{c|c}
\text{quantity}&\text{value}\\ \hline
\text{moves killing at least one old crossing}&62\\
\text{moves killing no old crossing}&12\\
\text{old crossings retained by one move}&19\text{ through }69\\
\text{new child crossing edges}&0\text{ through }169\\
\text{all child crossing edges}&69\text{ through }215.
\end{array}
\tag{11}

The sharpest move is

\[
\{b_2b_3,t_0t_1\},
\tag{12}

which kills 50 of the 69 old crossing edges and retains 19.  Complete child
perfect-matching enumeration agrees with (7) for every move and every old
pair.  It also shows

\[
\boxed{
\min_{M'\in\mathcal L^0,\,N'\in\mathcal L^1}
\#\operatorname{comp}(M'\mathbin\triangle N')=1
}
\tag{13}

for all 74 legal-wide brace children.  Thus this entire one-step class
contains no counterexample.

## 5. Consequence and boundary

An ordinary edge hitting set for the 69 old alternating cycles does not
control their survival.  The correct object is a family of legal cofacial
edge pairs whose state-\(11\) kill sets cover the old crossings.  Equation
(7) supplies the exact incidence test for that next question.

The arbitrary-order result of this note is only the local lift criterion
(5)--(7).  The counts in (11)--(13) are a complete classification of one
fixed 32-vertex parent and its frozen one-step facial moves, not an
order-36 census or a general preservation theorem.  In particular, the
classification does not decide whether two or more successive moves can
remove every old crossing and avoid complete-fibre supplementation.

The permanent
[verification bundle](../computations/bundles/c4-crossing-lift-and-note099-one-step/README.md)
contains the one-step enumerator, full per-move records and reproduction
instructions.

