> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The order-\(24\) carrier forces six crossings after every actual factor join

[Note 158](158-complete-boundary-row-deletion-forces-fixed-carrier-crossing-compensation.md)
shows that one clean factor row forces additional crossings at the fixed
carrier of
[Note 154](154-a-crossing-bridge-can-be-an-isolated-mixed-component.md).
The same conclusion is much stronger at the order-\(24\) carrier of
[Note 153](153-a-fixed-common-b-unique-crossing-can-have-no-rooted-triangle.md):
every factor bond of the intended type has two carrier copies, the
state-empty endpoint alone has two further carrier exchanges, and its two
deletion rows add two more. Thus this carrier can never support a
one-crossing annular splice.

## 1. Carrier rows

Use the graph with graph6 encoding

~~~text
W???????????w?s?P_BC?Go?B_?B_?@o?GW?B@??_W?A__?
~~~

and the legal-wide decoration

\[
Q=(6,15,2,16),\qquad
e=6\!-\!15,\qquad
g_0=2\!-\!16,\qquad
g_1=4\!-\!14.
\tag{1}
\]

Its two closed \(g_0\)-to-\(g_1\) arcs have cardinalities \(5\) and \(7\).
The graph is a simple plane cubic bipartite brace. Cut the root-disjoint
facial square at the opposite edges

\[
(a_0,a_1,a_2,a_3)=(5,21,11,23),\qquad
a_0a_1,\ a_2a_3.
\tag{2}
\]

A carrier row contains \(e,g_0\), covers every nonport vertex, and leaves
one of the six bipartite boundary states. A clean factor atom is specified
by its state and the path pairing in the factor complement. The complete
compatible carrier sets and their \(g_1\)-sectors are

\[
\begin{array}{c|c|c}
\text{factor atom}&\text{compatible carrier rows}&g_1\text{-sectors}\\ \hline
Z:\varnothing,\ 01\mid23&
K_0,K_3,K_4,K_5,K_{18},K_{23}&1,1,1,0,0,1\\
O:\varnothing,\ 03\mid12&K_2&1\\
A_0:\{0,1\},\ 23&K_{47},K_{50},K_{51},K_{54}&1,1,1,1\\
A_1:\{1,2\},\ 03&K_{59}&1\\
A_2:\{2,3\},\ 01&K_{78},K_{81},K_{84},K_{85}&0,0,0,0\\
A_3:\{3,0\},\ 12&K_{88}&1.
\end{array}
\tag{3}
\]

These rows are extracted from the complete family of \(104\) carrier
boundary rows; no carrier row is omitted from (3) once a clean factor atom
is fixed.

For two carrier rows \(K,L\), write

\[
d_C(K,L)=\Pi+z\text{ closed}
\]

for the path pairing \(\Pi\) and the number \(z\) of closed components in
their symmetric difference. The carrier atoms needed below are

\[
\begin{aligned}
d_C(K_5,K_{47})&=d_C(K_{18},K_{54})
    =01+0\text{ closed},\\
d_C(K_0,K_5)&=d_C(K_{18},K_{23})
    =1\text{ closed},\\
d_C(K_{18},K_{59})&=12+0\text{ closed},\\
d_C(K_5,K_{88})&=30+0\text{ closed}.
\end{aligned}
\tag{4}
\]

Every pair in (4) has opposite \(g_1\)-sectors by (3).

## 2. Factor hypothesis

Let \(B^-\) be any actual four-port factor obtained by deleting the
opposite edges \(q_0,q_2\) from a square

\[
b_0b_1b_2b_3b_0,\qquad q_i=b_ib_{i+1}.
\]

Suppose its complete boundary-row family contains rows \(N_0,N_1\) with

\[
\begin{array}{ll}
N_0:&\text{state }\varnothing,\quad
      B^--N_0=P_{01}\mathbin{\dot\cup}P_{23},\\
N_1:&\text{state }A_0=\{0,1\},\quad
      B^--N_1=P_{23}',\\
&d_B(N_0,N_1)=01+0\text{ closed}.
\end{array}
\tag{5}
\]

Thus \(N_0\) is a \(Z\)-row, \(N_1\) is a clean \(A_0\)-row, and their
difference is the intended productive factor bond.

The complete pairing in the first line of (5) forces
\(q_1,q_3\in N_0\): if, for example, \(q_1\notin N_0\), then \(q_1\) is an
entire \(12\)-component of the complement, contrary to \(01\mid23\).
Consequently the two deletion rows

\[
R_1=N_0-\{q_1\},\qquad R_3=N_0-\{q_3\}
\tag{6}
\]

are actual rows of states \(A_1,A_3\), respectively, and

\[
d_B(N_0,R_1)=12+0\text{ closed},\qquad
d_B(N_0,R_3)=30+0\text{ closed}.
\tag{7}
\]

## 3. Six forced crossings

Join the factor to the carrier along equally labelled ports. Compatibility
in (3) makes every endpoint below a rooted target.

First, the single factor bond in (5) has two distinct carrier copies:

\[
(K_5,N_0)\sim(K_{47},N_1),\qquad
(K_{18},N_0)\sim(K_{54},N_1).
\tag{8}
\]

For each edge, the carrier \(01\)-path and factor \(01\)-path join through
the two connectors to form one alternating cycle.

Second, use the same factor row \(N_0\) at both endpoints. Its factor
difference is empty, while the two carrier differences in the second line
of (4) are already single alternating cycles:

\[
(K_0,N_0)\sim(K_5,N_0),\qquad
(K_{18},N_0)\sim(K_{23},N_0).
\tag{9}
\]

Finally, combine the deletion rows (6)--(7) with the last two carrier atoms
in (4):

\[
(K_{18},N_0)\sim(K_{59},R_1),\qquad
(K_5,N_0)\sim(K_{88},R_3).
\tag{10}
\]

The six edges in (8)--(10) are pairwise distinct and every one crosses the
\(g_1\)-sector cut. Therefore:

> **Order-\(24\) carrier compensation theorem.** Every actual factor
> satisfying (5) produces a complete joined rooted family with
>
> \[
> \boxed{|E\Gamma_{g_1}|\ge 6.}
> \]

No planarity, bipartiteness, brace condition, Hamilton parity, or
additional factor row is used after (5); only the actuality of the two
deletion rows in (6) is needed. In fact, (8) already gives two crossings
without deletion closure.

## 4. Scope

This theorem closes the attempt to combine the Note 153 carrier cut with a
purpose-built factor to obtain one crossing. It does not prove the global
implication

\[
\Gamma_{g_1}(\mathcal T_e)\ne\varnothing
\Longrightarrow |E\Gamma_{g_1}(\mathcal T_e)|\ne1
\]

for every legal-wide root-square brace. The carrier table also shows why a
one-sided check is insufficient: \(A_1^0=A_3^0=\varnothing\), but the
actual deletion companions use the opposite direction
\(Z^0\!-\!A_1^1\) and \(Z^0\!-\!A_3^1\). A future carrier obstruction must
eliminate both sector directions, duplicate copies of the designated
factor bond, and same-factor-row carrier exchanges simultaneously.

The fixed
[verification bundle](../computations/bundles/order24-carrier-six-crossing-compensation/README.md)
reconstructs all \(104\) rows, the complete compatible table (3), and the
carrier atoms in (4). Its terminal marker is
ORDER24_CARRIER_SIX_CROSSINGS_VERIFIED.
