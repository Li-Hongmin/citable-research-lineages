> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Bounded special slots give a finite ladder-reduced Hamilton interface

The one-chord family of [Note 409](409-one-nested-face-chord-supports-arbitrarily-long-chord-free-site-arcs.md) is unbounded in its old-cycle main segment but collapses through even four-terminal ladders. This is a general feature of a noncrossing matching with only finitely many exceptional positions. The resulting bound is analytic: it does not require a graph census and does not assert Hamiltonicity of the remaining finite cores.

Let \(I=(v_1,\ldots,v_N)\) be a proper consecutive segment of a Hamilton cycle \(C\) in a simple cubic plane graph. Designate \(t\ge1\) positions as *special*. Every other position belongs to the complementary perfect matching and is paired to another nonspecial position of \(I\). Assume these ordinary matching edges are drawn on one side of \(C\), are noncrossing there, and no matched pair is consecutive in \(I\). Write \(c=(N-t)/2\) for their number. An *ordinary four-rung ladder* is formed by four chords
\[
 (a_0,b_0),(a_1,b_1),(a_2,b_2),(a_3,b_3),
 \qquad a_0<a_1<a_2<a_3<b_3<b_2<b_1<b_0,             \tag{1}
\]
with consecutive left endpoints and consecutive right endpoints in the full order of \(I\): \(a_{i+1}=a_i+1\) and \(b_i=b_{i+1}+1\).

**Finite ladder-kernel theorem.** If \(I\) has no ordinary four-rung ladder, then
\[
                    c\le6t-3,
 \qquad              N\le13t-6.                         \tag{2}
\]
If the host is bipartite, the stronger bounds hold:
\[
                    c\le3t-3,
 \qquad              N\le7t-6.                          \tag{3}
\]
Any ordinary four-rung ladder in (1) induces \(P_4\square K_2\) in the cubic host, with exactly four corner attachments; all eight ladder vertices are nonspecial. Replacing it by a square as in [Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md) decreases \(N\) by four, preserves the cubic bipartite plane three-connected class whenever the host is Barnette, and preserves all Hamilton cycles' exterior edge marks. If a fixed legal site has all four endpoints special, this reduction also preserves its six witness clauses of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) separately, as proved in Note 409. Repeating the reduction ends at a representative satisfying (2), and (3) when bipartite, with the same special positions and Hamilton site interface.

**Proof of the bound.** Regard each ordinary chord \((i,j)\), \(i<j\), as the interval \([i,j]\). Since the chords do not cross, two such intervals are disjoint or nested. Their strict containment relation is a rooted forest. A *child* is a maximal properly contained chord. Assign each special position lying inside at least one chord to the smallest chord containing it; a node is *marked* if it receives a special position. There are at most \(t\) marked nodes.

Every leaf is marked. Indeed, a leaf contains no other chord endpoints: a matched endpoint strictly inside it would have its mate inside as well, since a mate outside would cross the leaf chord. The leaf endpoints are not consecutive, so an interior position exists and must be special. Distinct leaf interiors are disjoint, hence the number \(L\) of leaves is at most \(t\). In a rooted forest with at least one node and \(R\) roots, the number \(B\) of nodes with at least two children satisfies \(B\le L-R\le t-1\). Therefore at most \(2t-1\) nodes are either marked or branching.

Every remaining node has exactly one child and receives no special position; call it *plain unary*. If a plain unary chord has child \((i',j')\), then their left endpoints are consecutive in \(I\), and so are their right endpoints. Any position between those endpoints would be either a directly assigned special position or an endpoint of a second child, both excluded. Three consecutive plain unary nodes together with the child of the third therefore form the four nested chords (1). In the absence of (1), each maximal plain-unary chain has at most two nodes. Every such chain ends at a marked or branching node, and each latter node has only one incoming parent chain. Thus there are at most twice as many plain-unary nodes as marked-or-branching nodes. The total is at most \(3(2t-1)=6t-3\), proving the first inequality in (2); \(N=t+2c\) gives the second. \(\square\)

**Bipartite sharpening.** In a bipartite host, the endpoints of every ordinary chord have opposite parity along \(C\). Hence the open interval inside any chord contains an even number of positions. Each immediate child's closed interval also contains an even number. The positions left over inside the parent are exactly the special positions assigned directly to it, so their number is even. Every marked node therefore receives at least two special positions. There are at most \(\lfloor t/2\rfloor\) marked nodes and at most \(\lfloor t/2\rfloor\) leaves; the number of branching nodes is at most \(\lfloor t/2\rfloor-1\) when the forest is nonempty. At most \(2\lfloor t/2\rfloor-1\le t-1\) nodes are marked or branching. Charging at most two plain-unary ancestors to each such node as above gives \(c\le3t-3\) and then \(N=t+2c\le7t-6\). If the forest is empty, the same inequalities are immediate. \(\square\)

**Exposed-slot sharpening.** Call a special position *exposed* if it lies in no open interval of an ordinary chord, and let \(b\) be the number of exposed special positions. Such positions are never assigned to a forest node. Repeating the preceding argument with only the \(t-b\) assignable special positions gives
\[
c\le\max\{0,3(t-b)-3\}                                    \tag{4}
\]
in a bipartite host. Indeed, if the forest is nonempty, every marked node is assigned at least two special positions, so there are at most \(\lfloor(t-b)/2\rfloor\) marked nodes and at most that many leaves. The same branch and plain-unary charges give \(c\le6\lfloor(t-b)/2\rfloor-3\le3(t-b)-3\). If \(t-b<2\), the forest must be empty. The general, not necessarily bipartite version similarly gives \(c\le\max\{0,6(t-b)-3\}\). \(\square\)


If the nonempty forest has \(R\) roots, the same charge keeps the exact root term: with \(u=t-b\) assignable specials and at most \(u/2\) marked nodes, the branching count is at most \(u/2-R\), so
\[
                         c\le3(u-R).                   \tag{4a}
\]
This can improve the kernel by six vertices per additional root. The coefficient in (4) is sharp for abstract bipartite noncrossing matchings: take any full binary rooted tree with \(m\) leaves. At a leaf write the matching word \((xy)\), where \(x,y\) are the two special positions; at a branch write a pair of parentheses enclosing the two child words; then wrap *every* node word in two further nested pairs of parentheses. Parentheses pair ordinary chord endpoints. Every chord encloses an even number of positions, so its endpoints have opposite parity; no pair is consecutive. The only chains with consecutive endpoints on both sides consist of the two wrappers and their core chord, so there is no four-rung ladder. The tree has \(2m-1\) nodes and thus \(c=3(2m-1)=3(2m)-3\) ordinary chords on \(u=2m\) special positions. This is sharpness of the interval-matching bound, not a claim that every such word extends to a Barnette graph.

**Why the ladder reduction applies.** In (1), the four left endpoints form one old-cycle rail, the four right endpoints form the other rail in reverse order, and the four matching edges are the rungs. No additional host edge joins two ladder vertices: every matching incidence is already a rung; the only old-cycle edges among them are rail edges, because an inner rung cannot duplicate an old-cycle edge and \(I\) is a proper segment of \(C\). Each corner has one exterior old-cycle edge, while the four noncorner vertices have no exterior edge. All eight vertices are ordinary, so site edges, face-side chords and escape targets designated special remain outside the patch. The four-pole theorem of Note 178 supplies class and Hamilton preservation. The square can be embedded with its two rail edges on the old Hamilton cycle and its rungs on the same page as the original four chords. Thus the old-cycle order outside the patch, any selected trapped segment, and the legal cofacial site survive the local compression, with facial arcs shortened where a rail lay on their boundary. Each step removes four vertices, so the process terminates.

**Single-hexagon consequence.** In the setup of [Notes 403--409](409-one-nested-face-chord-supports-arbitrarily-long-chord-free-site-arcs.md), let \(s=|S_0|\), let \(e\in\{2,4\}\) be the number of main-segment escape targets of the trapped hexagon, and let \(f\) be the number of additional main matching chords on the common-face side, excluding the two site edges. Designate as special the four site ports, the \(e\) escape targets and both ends of each of the \(f\) face-side chords. They are distinct, so
\[
                         t=4+e+2f\le8+2f.              \tag{5}
\]
Every remaining main vertex is matched to another remaining main vertex on the opposite side of \(C\). Hence the theorem applies. After compressing all available ordinary four-rung ladders, the parent remains Barnette, the selected trapped hexagon and the number \(f\) remain unchanged, and its entire six-witness site interface is unchanged. Its main length and total order obey
\[
 s\le10+e+14f,
 \qquad |V(G)|=s+6\le16+e+14f.                         \tag{6}
\]
Here the stronger exposed-slot bound (4) applies with \(b\ge e+2\). No opposite-page ordinary chord may contain an escape target: its endpoints would interlace the escape edge to the hexagon on that same page. The two end positions \(w_0,w_{s-1}\) of the main segment, which are site ports, cannot lie strictly inside a chord with both endpoints in the segment. Thus at most \(2+2f\) special positions can be assigned to nodes, and \(c\le3+6f\), giving (6). In particular, \(f=1\) reduces to parents of order at most \(34\) for a chord-free trapped hexagon and at most \(32\) for a chorded one. The reductions do not by themselves prove those bounded cores Hamiltonian; they show that arbitrarily long ordinary opposite-page chord corridors add no new six-witness behaviour once even ladders are factored out. The general Barnette conjecture remains open.

**One trapped segment of arbitrary even length.** The same argument does not depend on the trapped segment being a hexagon. Suppose the selected three-edge facial opening of [Note 176](176-alternating-facial-arcs-create-one-residual-cycle-per-matching-edge.md) traps exactly one residual cycle with \(\ell\ge4\) vertices. Let \(e\) of its interior vertices have matching edges into the main segment \(S_0\), and keep the same definition of \(f\). Each escape edge lies opposite the common face by Note 176, so its main endpoint is exposed; the two end site ports are also exposed. The forest and four-rung reduction therefore give
\[
 |S_0|\le10+e+14f,\qquad
 |V(\bar G)|\le\ell+10+e+14f,\qquad
 |V(\bar G^+)|\le\ell+14+e+14f.                       \tag{7}
\]
All three bounds hold regardless of matching chords internal to the trapped segment. Since the \(\ell-2\) interior vertices are either paired internally or escape into \(S_0\), \(e\le\ell-2\), yielding \(|V(\bar G^+)|\le2\ell+12+14f\). The same exact ladder signatures preserve Hamiltonicity of the parent and expanded child and all six site-witness existence clauses.

**Mixed leaf-ladder reduction and stronger single-trap kernel.** A second four-column ladder occurs whenever a leaf ordinary chord receives exactly two special positions \(x,y\) and has two consecutive plain-unary ancestors. A leaf has no ordinary endpoints inside, so \(x,y\) are consecutive in the full old-cycle order. The eight vertices of the three nested ordinary chords and these two positions occur on \(C\) as
\[
 a_0,a_1,a_2,x,y,b_2,b_1,b_0.
\]
The three ordinary chords \(a_0b_0,a_1b_1,a_2b_2\) are three rungs; the old-cycle edge \(xy\) is the fourth, and the two old-cycle runs are rails. The matching edges at \(x,y\) leave the patch: they cannot equal the old-cycle edge \(xy\) in a simple graph, and all six ordinary vertices are already matched. The only other exterior edges are the old-cycle edges at \(a_0,b_0\). Thus this is an induced \(P_4\square K_2\) with exactly four corner attachments. Replace it by the square with old-cycle path \(a_0,x,y,b_0\); all four corners and their attachment edges remain in the same cyclic order. Note 178 gives two-way Barnette and exterior-marked Hamilton preservation. Embed the replacement square in the same disk, with the four attachment edges in their former cyclic order. Exterior face incidences of those edges, including any common face containing the site edges, persist; the selected trapped segment is outside the disk.

The positions \(x,y\) may be site ports. If one is, its site edge is an exterior attachment and its endpoint remains a square corner. Expanding the site replaces that attachment outside the ladder, so square compression and site expansion commute. In the child, every gadget edge is exterior to the ladder or one of its four attachment edges. Note 178 therefore preserves the *set of gadget-edge incidence patterns* realized by Hamilton cycles. The six patterns correspond individually to the six parent witness types by [Notes 001](001-exact-c4-expansion-criterion-and-central-transfer.md) and [013](013-h-plus-minus-parent-forces-a-p2-hamiltonian-c4-child.md). Consequently this mixed reduction preserves each of the six witness-existence clauses even when a retained corner is a site endpoint. It removes four ordinary vertices and changes neither \(e\) nor \(f\).

Alternate ordinary four-rung and mixed leaf-ladder reductions until neither applies; each decreases the vertex count by four. Let \(u\le2+2f=2m_{\max}\), where \(m_{\max}=f+1\), be the number of special slots lying inside at least one remaining ordinary chord. Direct special-slot parity makes \(u\) even. If the forest is nonempty, put \(m=u/2\), and let \(M_0,L,B\) count marked nodes, leaves and branching nodes; let \(A\) count nodes that are marked or branching. Then \(M_0\le m\), \(L\le M_0\), \(B\le L-1\), and \(A\le M_0+L-1\). Let \(F\) count leaves receiving at least four special slots. Every marked node uses at least two and each such fat leaf uses at least two more, so \(F\le m-M_0\). Therefore the number \(Q\) of leaves receiving exactly two special slots satisfies
\[
 Q\ge L-F\ge M_0+L-m.
\]
Each non-plain node has at most two plain-unary ancestors in its incoming chain. The chain above every one of these \(Q\) leaves has at most one, since two would give a mixed leaf ladder. Hence the number \(P\) of plain-unary nodes is at most \(2A-Q\). The total ordinary-chord count is
\[
 c=A+P\le3A-Q
 \le3(M_0+L-1)-(M_0+L-m)
 =2(M_0+L)+m-3\le5m-3\le5f+2.                        \tag{8}
\]
The final bound also holds for an empty forest. Therefore a doubly reduced representative with one trapped segment of length \(\ell\) satisfies
\[
 |S_0|\le8+e+12f,\qquad
 |V(\bar G^+)|\le\ell+12+e+12f.                         \tag{9}
\]
This supersedes (6)--(7) after both reductions. It is a finite kernel for the complete six-witness site interface, not an assertion that all such expansions are Hamiltonian.

The coefficient in (8) is sharp for abstract bipartite noncrossing partial matchings. For a full binary rooted tree with \(m\) leaves, place two special positions \(x,y\) inside the ordinary chord at every leaf and wrap that leaf chord in one plain-unary chord. At each branch, enclose its two child words in one ordinary chord and then two plain-unary chords. Every ordinary chord spans an odd index difference, so its endpoints have opposite parity, and none duplicates a consecutive old-cycle edge. Branching prevents four consecutive ordinary rungs; each leaf has only one plain-unary ancestor, so no mixed leaf ladder occurs. There are \(2m\) special positions and \(2m+3(m-1)=5m-3\) ordinary chords, attaining (8) with \(f=m-1\). This interval-matching extremizer is not asserted to extend to a Barnette graph or to the required cofacial site.
