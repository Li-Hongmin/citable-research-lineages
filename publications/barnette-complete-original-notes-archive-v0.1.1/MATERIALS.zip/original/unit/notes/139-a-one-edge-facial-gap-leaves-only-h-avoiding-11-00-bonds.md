> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A one-edge facial gap leaves only (h)-avoiding (11)--(00) bonds

[Note 138](138-a-one-edge-facial-gap-transfers-every-pure-11-rooted-bond.md)
proves that a one-edge residual facial gap transfers every pure-(11)
rooted bond.  This note gives the exact mixed-bond classification.  Three
mixed rows also transfer automatically.  The only direct obstruction in a
plane graph is a state-(00) endpoint that omits the short facial edge.

Consequently a failure of short-gap ChildSupplement has a much narrower
necessary form than mixed-only: every parent bond must be (11)--(00),
and every state-(00) endpoint on a bond must avoid the short edge.

## 1. Rooted setup and the canonical lifts

Use the rooted bond graph and interface-disjoint decoration of Note 138.
Let the expanded edges occur on a common face in the order

\[
 p=uv,\qquad q=xy,\qquad
 u,p,v,A,x,q,y,h,u,
\tag{1}
\]

where the second residual arc is the single retained edge

\[
 h=yu.
\tag{2}
\]

The child patch has edges

\[
 ua,ab,bv,xc,cd,dy,ad,bc.
\tag{3}
\]

Let (M,N) be rooted parent targets in opposite surviving-gate sectors,
and suppose

\[
 C=M\mathbin\triangle N
\tag{4}
\]

is one alternating cycle.  Assume (M) has state (11), while (N) has
state (10,01), or (00).  The short-gap lift from Note 138 is

\[
 \Phi(M)=(M-\{p,q\})\cup\{h,ad,bv,xc\}.
\tag{5}
\]

It lies in (X_{vx}), and its complement is obtained from (G-M) by
subdividing (h) as (u-a-b-c-d-y).  Hence it preserves the two labelled
complement components, root separation, and gate sector.

For the non-(11) endpoint use its canonical lift

\[
\begin{array}{c|c}
\sigma(N)&\widehat N\\ \hline
10&(N-\{p\})\cup\{ua,bv,cd\},\\
01&(N-\{q\})\cup\{xc,dy,ab\},\\
00&N\cup\{ad,bc\}.
\end{array}
\tag{6}
\]

These complements respectively subdivide (q), subdivide (p), or
subdivide (p,q) separately.  Thus every \(\widehat N\) is also a rooted
child target with the same labelled components, root separation, and gate
sector as (N).  The only remaining question is the component count of
\(\Phi(M)\triangle\widehat N\).

## 2. Exact mixed-bond transfer theorem

**Theorem 1.**  In the setup above:

1. every (11)--(10) bond transfers to an
   (X_{vx})--(C_{10}) child rooted bond;
2. every (11)--(01) bond transfers to an
   (X_{vx})--(C_{01}) child rooted bond;
3. every (11)--(00) bond whose state-(00) endpoint contains (h)
   transfers to an (X_{vx})--(C_{00}) child rooted bond;
4. every (11)--(00) bond whose state-(00) endpoint omits (h) gives
   exactly two components in
   \(\Phi(M)\triangle\widehat N\), and hence this direct pair is not a
   child bond.

### Proof

If (N) has state (10), then (p) is common to (M,N), while (q)
lies on (C).  Cancellation in (5)--(6) gives

\[
 \Phi(M)\mathbin\triangle\widehat N
 =(C-\{q\})\cup E(y,u,a,d,c,x).
\tag{7}
\]

The inserted path has the same endpoints as (q=xy); it merely subdivides
that edge of (C).  The result is one cycle.  For state (01), (q) is
common and

\[
 \Phi(M)\mathbin\triangle\widehat N
 =(C-\{p\})\cup E(u,y,d,a,b,v),
\tag{8}
\]

which merely subdivides (p=uv).  This is again one cycle.

Now let (N) have state (00).  If (h\in N), then the parent difference
contains the consecutive path

\[
 v-p-u-h-y-q-x.
\tag{9}
\]

The edge (h) is common to the two child matchings, as is (ad).  Hence

\[
 \Phi(M)\mathbin\triangle\widehat N
 =(C-\{p,h,q\})\cup E(v,b,c,x).
\tag{10}
\]

This replaces the path (9) by another path with the same endpoints, so the
result remains one cycle.

Suppose instead that (h\notin N).  Then

\[
 \Phi(M)\mathbin\triangle\widehat N
 =(C-\{p,q\})\cup\{h\}\cup E(v,b,c,x).
\tag{11}
\]

Deleting (p,q) from the single cycle (C) leaves two vertex-disjoint
paths.  The marked endpoints occur around the common face as

\[
 u,v,x,y.
\tag{12}
\]

The two paths lie in the closed disk complementary to the open face.  They
cannot have pairing ((u,x)\mid(v,y)), because these pairs alternate on
the disk boundary and two such disjoint arcs would cross.  They also cannot
have pairing ((u,v)\mid(x,y)), since adding (p,q) would then produce two
cycles rather than (C).  Therefore planarity forces

\[
 C-\{p,q\}:\qquad (u,y)\mid(v,x).
\tag{13}
\]

The two new paths in (11) have exactly the same pairing: (h) closes the
(u)--(y) path and (v-b-c-x) closes the (v)--(x) path.  Thus (11)
is the disjoint union of exactly two cycles.

All endpoints used above are already rooted child targets, and interface
disjointness preserves the surviving-gate bits.  Hence the one-cycle rows
are rooted bonds and the two-cycle row is not. \(\square\)

Without planarity, the last row has the exact alternative: the direct pair
is one cycle if and only if (C-\{p,q\}) has crossed pairing
((u,x)\mid(v,y)).  Thus the plane embedding does not eliminate the
obstruction; it eliminates the good pairing and forces direct failure.

The noncanonical (R_{00}) patch does not repair the prescribed bad pair.
Its local (v)--(x) path is (v-b-a-d-c-x), so the same two parent paths
in (13) are again closed separately whenever that endpoint happens to be
root-admissible.

## 3. Consequence for ParentKill and ChildSupplement

Assume ParentKill: the parent bond graph is nonempty and every parent bond
has at least one state-(11) endpoint.  Note 138 transfers any
(11)--(11) bond.  Theorem 1 transfers any mixed bond in the first three
rows.  Therefore

\[
\boxed{
 \neg\mathrm{ChildSupplement}
 \quad\Longrightarrow\quad
 \begin{array}{l}
 \text{every parent bond is }11\text{--}00,\\
 \text{and every bonded }00\text{ endpoint omits }h.
 \end{array}}
\tag{14}
\]

This is only a necessary condition for failure.  A complete child family
may supply a nondirect new-cell bond even when every prescribed direct pair
in (14) splits into two cycles.

If the other residual arc is the single edge (r=vx), reflection gives the
same statement with (X_{uy}) in place of (X_{vx}): a failure requires
every parent bond to be (11)--(00), with every bonded state-(00)
endpoint omitting (r).

## 4. The exceptional row occurs in a real legal-wide decoration

The exceptional row is not an abstract port pattern.  Use the order-(26)
plane cubic bipartite graph and fixed site from Note 138:

~~~text
Y?????????????w?Y?CW??w??[?EC?T??_W?D@??AK?@_O?GK??SA???
~~~

with

\[
 (u,v,x,y)=(21,11,25,3),\qquad
 p=21\!-11,\quad q=25\!-3,\quad h=3\!-21.
\tag{15}
\]

Among all state-(11)--non-(11) perfect-matching pairs whose symmetric
difference is one cycle, the complete fixed-family counts are

\[
\begin{array}{c|r|c}
\text{row}&\text{number of pairs}&
\#\operatorname{comp}(\Phi(M)\triangle\widehat N)\\ \hline
11\text{--}10&248&1\\
11\text{--}01&392&1\\
11\text{--}00,\ h\in N&652&1\\
11\text{--}00,\ h\notin N&406&2.
\end{array}
\tag{16}
\]

Every row has an actual interface-disjoint legal-wide rooted decoration.
In particular, matching indices (58,210), with root (6-16), forced
gate (8-19), and surviving gate (0-13), give a genuine bond in the last
row.  Its two canonical child targets have a two-cycle difference exactly
as in (11)--(13).

This decoration is not a ChildSupplement counterexample: its complete
parent bond graph fails ParentKill, while its complete child fibre has
(23) bonds, (16) of which touch a new cell.  It strictly separates the
realizability of the local direct obstruction from failure of the complete-
family conclusion.

All counts, the four legal-wide decorations, rooted admission, gate sectors,
component counts, and the complete-family boundary for the exceptional
witness are checked by the
[fixed certificate](../computations/bundles/one-edge-gap-mixed-bond-classification/README.md).

## 5. Exact boundary

The direct mixed branch at a one-edge facial gap is completely classified.
Together with Note 138, every pure or mixed parent bond transfers except
the plane (11)--(00), short-edge-avoiding row, whose canonical direct
pair has exactly two cycles.

[Note 145](145-legal-wide-is-essential-for-short-gap-complete-family-compensation.md)
later gives an interface-disjoint plane-brace complete family whose entire
bond graph has the form in (14) and whose child has no supplement. Thus the
unrestricted selection problem is false. The unresolved short-gap branch is
the same complete-family question with the historical legal-wide gate-face
hypothesis retained. This note makes no claim for sites whose two residual
arcs both have length at least three.
