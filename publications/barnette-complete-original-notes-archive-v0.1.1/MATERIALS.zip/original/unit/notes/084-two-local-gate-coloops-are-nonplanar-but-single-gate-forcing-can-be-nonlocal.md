> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two local gate coloops are nonplanar, but single-gate forcing can be nonlocal

[Note 083](083-a-wide-gate-can-be-a-restricted-coloop.md) gives an
infinite family in which one gate of a legal wide site is a restricted
coloop of the complete rooted-target family.  The ordinary lifting interface
fails exactly when both gates are restricted coloops.  This note determines
the first structural boundary of that paired question.

Two gates cannot both be forced by the opposite-square mechanism: the two
squares and the residual facial arcs form a subdivision of \(K_{3,3}\).
This does not settle the paired question, because restricted coloops need not
be square-local.  A complete reclassification of the already frozen
through-\(26\) brace corpus gives \(113\) nonlocal occurrences, including a
real order-\(24\) family whose root and forced gate cannot even be joined by
a chain of family-common opposite squares.

## 1. The paired restricted-coloop question

Let \(G\) be a simple plane cubic bipartite brace, let \(C\) be a facial
cycle, and let

\[
g_0=a_0b_0,\qquad g_1=a_1b_1
\tag{1}
\]

be two disjoint gates in legal cyclic order

\[
a_0,b_0,A,a_1,b_1,B
\tag{2}
\]

around \(C\).  The paths \(A,B\) are the two residual facial arcs; at a
wide site each has odd length at least three.  Let \(e=rs\) be an unchanged
root and let \(\mathcal T_e\) be its nonempty complete rooted-target family.

The unresolved neutral-target assertion is

\[
\exists M\in\mathcal T_e:
g_0\notin M\ \lor\ g_1\notin M.
\tag{3}
\]

Its failure is precisely

\[
g_0,g_1\in\bigcap_{M\in\mathcal T_e}M.
\tag{4}
\]

## 2. Simultaneous opposite-square forcing is nonplanar

The opposite-square lemma of Note 083 says that if the root \(e\) and a
gate \(g_i\) are opposite edges of a \(4\)-cycle, then every member of
\(\mathcal T_e\) contains \(g_i\).  This mechanism cannot establish (4).

**Simultaneous-square theorem.**  The two cofacial gates \(g_0,g_1\)
cannot both be opposite to the same root \(e\) in \(4\)-cycles.

**Proof.**  If a gate meets the root, no perfect matching contains both, so
assume all six displayed endpoints are distinct.  Choose the bipartition
\(X\sqcup Y\) with

\[
r,b_0,b_1\in X,\qquad s,a_0,a_1\in Y.
\tag{5}
\]

Bipartiteness uniquely forces the two alleged squares to be

\[
Q_i=a_i-r-s-b_i-a_i,\qquad i=0,1.
\tag{6}
\]

There is no second endpoint pairing: \(r b_i\) and \(s a_i\) would be
same-colour edges.

Let \(P_{01}\) be the residual facial path from \(b_0\) to \(a_1\), and
\(P_{10}\) the residual path from \(b_1\) to \(a_0\).  Their interiors are
disjoint.  They also avoid \(r,s\).  Indeed, the three incidences at \(r\)
in (6) are \(rs,ra_0,ra_1\).  If \(r\) lay internally on \(C\), then,
because \(rs\notin E(C)\), its two facial neighbours would be
\(a_0,a_1\), contrary to the cyclic order (2).  The same argument applies
to \(s\).

The following nine mutually internally disjoint connections form a
\(K_{3,3}\)-subdivision with branch bipartition
\(\{r,b_0,b_1\}\mid\{s,a_0,a_1\}\):

\[
\begin{array}{c|ccc}
 &s&a_0&a_1\\ \hline
r&rs&ra_0&ra_1\\
b_0&b_0s&b_0a_0&P_{01}\\
b_1&b_1s&P_{10}&b_1a_1.
\end{array}
\tag{7}
\]

This contradicts planarity. \(\square\)

The theorem uses neither the brace axiom nor the assumption that the two
squares are facial.  Cofaciality of the gates supplies exactly the two
paths missing from the two squares.

## 3. The obstruction is not an ordinary matching coloop

Fix a gate \(g_i=x_iy_i\) disjoint from \(e\).  At least one edge incident
with \(x_i\), other than \(g_i\), is independent of \(e\): bipartiteness
prevents \(x_i\) from being adjacent to both ends of \(e\).  Since \(G\) is
\(2\)-extendable, that edge and \(e\) extend to a perfect matching \(N_i\).
Necessarily

\[
e\in N_i,\qquad g_i\notin N_i.
\tag{8}
\]

Thus a restricted gate coloop is never forced among all root-sharing
perfect matchings.  It is forced only after imposing the two-cycle
complement and root-separation conditions.

There is also a quantifier trap.  For one chosen \(N_i\), every
component-subset toggle that removes \(g_i\) may fail the two-rooted orbit
condition of Notes 081--082 even though another gate-deleting target lies
outside that one component cube.  Gate forcing is equivalent to universal
failure only after quantifying over every root-sharing perfect matching
that excludes the gate.

## 4. Even prisms exclude paired coloops at every width

For the even prism \(G_n=C_n\square K_2\), use the notation of Note 083.
For a rim root, symmetry reduces to \(e=B_0\), and

\[
\mathcal T_{B_0}
=\{M_j:j\notin\{-1,0,1\}\},
\tag{9}
\]

with

\[
M_j=\{T_0,T_j,B_0,B_j\}
\cup\{R_i:i\notin\{0,1,j,j+1\}\}.
\tag{10}
\]

Consequently

\[
\bigcap_{M\in\mathcal T_{B_0}}M=\{B_0,T_0\}.
\tag{11}
\]

Exactly one top-rim edge can therefore be a restricted coloop.

For completeness, take a rung root \(R_k\).  In the bipyramid dual,
\(R_k^*=q_{k-1}q_k\); normalize its two endpoints to colour \(0\).
The two incident NAE triangles force both apices to colour \(1\), and the
remaining NAE conditions say that the colour-\(1\) equatorial vertices are
independent.  If there are none, the matching is the all-rung matching:
after deleting the dual root, the monochromatic equatorial cycle becomes a
path and the two apices are isolated, which is exactly the rooted target
profile.  If there is one colour-\(1\) equatorial vertex, the zero path
containing the root splits when the root is deleted, so the root marks are
separated.  If there are at least two, the monochromatic \(K_{2,s}\) on the
two apices and the \(s\) colour-\(1\) vertices retains a cycle not containing
the root.  Thus the complete family for a rung root is the singleton
all-rung matching, which uses no rim gate.  No legal wide rim site in any
even prism has a restricted-coloop pair.

The finite verifier in the
[bundle](../computations/bundles/paired-restricted-gate-coloop-boundary/README.md)
enumerates all \(49\) perfect matchings of the octagonal prism and checks
every root and every minimum-wide gate pair.  Equations (9)--(11) are the
arbitrary-order proof.

## 5. A real restricted coloop beyond common square ladders

The through-\(26\) graph representatives already frozen in the permanent
wide-site bundles were reprocessed without graph generation.  Across all
\(50\) plane-brace representatives one obtains

\[
\begin{array}{c|r}
\text{legal wide splits}&376\\
\text{nonempty complete rooted-target families}&10\,322\\
\text{families with no restricted gate coloop}&9\,668\\
\text{families with exactly one restricted gate coloop}&654\\
\text{families with two restricted gate coloops}&0.
\end{array}
\tag{12}
\]

Of the \(654\) coloop occurrences, \(541\) are direct opposite-square
forcings and \(113\) are not.  Form the square-opposition graph whose
vertices are primal edges, joining two edges when they are opposite in a
\(4\)-cycle, and restrict it to edges common to the complete target family.
The root-to-coloop distance distribution is

\[
1^{541},\qquad2^{69},\qquad3^{33},\qquad4^5,\qquad5^4,\qquad\infty^2.
\tag{13}
\]

Thus square-locality is false even after allowing arbitrary chains of
family-common square forcings.

The first occurrence at distance \(\infty\) has order \(24\) and graph6
string

    W???????????w?s?P_BC?I_?H_?e??B_?SG?@B??@g??B_?

Use root \(4\,14\) and gates \(9\,23,3\,18\).  The complete family has
\(15\) members and gate profile

\[
01^{12},\qquad11^3.
\tag{14}
\]

Its full intersection is

\[
\bigcap_{M\in\mathcal T_e}M=\{4\,14,3\,18\}.
\tag{15}
\]

Hence \(3\,18\) is a genuine nonlocal restricted gate coloop.  The root
and that gate are not opposite in any square and are disconnected in the
square-opposition graph induced by (15).  The other gate \(9\,23\) is still
omitted by twelve targets.

This is a real plane-brace seed for the global stratum, not an abstract
incidence model.  It does not refute (3).

## 6. Exact boundary

The paired restricted-coloop question remains open at arbitrary order.
The simultaneous-square theorem excludes two local certificates, and the
even-prism classification excludes the full infinite family that realizes
one such certificate.  The order-\(24\) example simultaneously refutes the
stronger claim that every restricted gate coloop is generated by a common
square ladder.

Any counterexample to (3) must therefore have one of two forms:

1. one gate is square-forced and the other is globally forced; or
2. both gates are globally forced.

Here “globally forced” includes the order-\(24\) mechanism of (14)--(15).
The next decision-changing problem is to determine whether such a nonlocal
coloop can be coupled to forcing of the second gate without complete-family
supplementation.  An adjacent-order census does not address that mechanism.

**Exact conclusion.**  Two cofacial gates cannot both be forced by
root-opposite squares, but restricted gate coloops need not be square-local.

**Evidence level.**  The simultaneous-square theorem and the even-prism
classification are arbitrary-order analytic results.  Equations
(12)--(13) are a complete reclassification of the named frozen
through-\(26\) corpus.  The order-\(24\) nonlocal seed has an independent
full-family certificate.

**Unresolved boundary.**  It is unknown whether a legal wide site can have
two restricted gate coloops.  Any proof or counterexample must couple the
two gate coordinates through common rooted-target incidence beyond local
square forcing.
