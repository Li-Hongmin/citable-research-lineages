> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two-sided short flanks preserve the forward four-double Hamilton route

[Note 355](355-arbitrary-one-sided-short-flanks-preserve-forward-four-double-hamilton-routes.md)
settles a \(J_3,J_1,J_3,J_1\) four-double group with short
blocks on only one outer side and none between the middle
double blocks. When both outer sides are nonempty, their
standard boundary links need not be the only possibility.
If both are absent, noncrossing forces one compatible pair
of long chords and a spanning route through both flanks.

Work in the compressed, gapless, tight-target all-square
opening of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Let an ordinary target-free free group, with even left
and odd right endports \(L,R\), have block order
\[
S_1,\ldots,S_a,D_1,D_2,D_3,D_4,T_1,\ldots,T_b,
\qquad a,b\ge0,                                             \tag{1}
\]
where
\[
\begin{split}
S_i&=(c_i,r_i,s_i,d_i),&
T_j&=(c'_j,r'_j,s'_j,d'_j),\\
D_t&=(a_t,o_t,h_t,i_t,k_t,j_t,e_t,b_t)
&& (1\le t\le4).
\end{split}                                                  \tag{2}
\]
The four double blocks have common-face internal
matching chords
\[
                 i_1e_1,\quad o_2k_2,\quad
                 i_3e_3,\quad o_4k_4,                      \tag{3}
\]
and all blocks have their common-face closing chords.
Put \(F_i=(r_i,c_i,d_i,s_i)\) and
\(G_j=(r'_j,c'_j,d'_j,s'_j)\).

**Two-sided-flank theorem.** Every complementary matching
that occurs in a Barnette parent under (1)--(3) gives a
vertex-spanning \(L\)--\(R\) path through the group,
for arbitrary \(a,b\ge0\).
If all vacancies outside this group occupy distinct
internal blocks, the parent has a Hamilton cycle
through both site edges and its legal child is
Hamiltonian.

More precisely, when \(a,b\ge1\), either at least
one standard boundary chord \(Lr_1,s'_bR\) occurs,
or both are absent and the entire free matching
is forced. In the latter case it consists of
\[
\begin{split}
&Lj_2,\quad r_1h_1,\quad s_ao_1,\quad
k_1i_2,\quad j_1h_2,\quad e_2o_3,\\
&h_3R,\quad k_3i_4,\quad j_3h_4,\quad
j_4s'_b,\quad e_4r'_1,\\
&s_ir_{i+1}\ (1\le i<a),\qquad
s'_jr'_{j+1}\ (1\le j<b).
\end{split}                                                  \tag{4}
\]
The theorem is conditional on an actual Barnette
matching; it does not assert that every formal word
in (4) is realized.

**Boundary reduction.** By [Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md),
(3) excludes other same-block free chords.
By [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
all cross-block free chords lie on the opposite page
and do not cross. Every such chord encloses an even
number of free slots. A nonempty proper interval
of complete blocks closed under the matching would
have only two old-cycle edges leaving it, contrary
to three-connectivity.

The cases \(a=0\) or \(b=0\) follow from Note 355,
with reflection when needed. Assume \(a,b\ge1\).
The left-end calculation of Note 355 still applies:
\(Lr_t\) with \(t>1\), \(Lo_1\), \(Lo_3\), and \(LR\)
close complete-block intervals. A chord \(Lr'_j\)
would close
\(S_1,\ldots,S_a,D_1,\ldots,D_4,
T_1,\ldots,T_{j-1}\).
Parity excludes all other odd candidates.
Thus the only viable mates of \(L\) are
\[
                         r_1,\quad j_2,\quad j_4.         \tag{5}
\]

At the right end, \(R\) can meet only an even
free slot. A chord to \(L\) or a left-flank
\(s_i\) closes a complete interval containing
all four double blocks. The chord \(e_2R\)
closes \(D_3,D_4,T_1,\ldots,T_b\);
\(e_4R\) closes the whole right flank;
and \(s'_jR\) for \(j<b\) closes the
short-block suffix \(T_{j+1},\ldots,T_b\).
The even candidates \(k_1,h_2,k_3,h_4\)
enclose odd numbers of free slots.
Hence the only viable mates of \(R\) are
\[
                         s'_b,\quad h_1,\quad h_3.        \tag{6}
\]

If \(Lr_1\), reserve
\((L,r_1,c_1,d_1,s_1)\) and treat \(s_1\)
as the new even left endport. If \(s'_bR\),
reserve \((r'_b,c'_b,d'_b,s'_b,R)\)
and treat \(r'_b\) as the new odd right endport.
These are path peelings: the original graph
is unchanged, and every cut invoked after
a peel is a proper interval of original
complete blocks. The argument inducts on
\(a+b\), reaching Note 355 if either side
empties. Concatenating the reserved path
segments at their designated endports
lifts the final group route.

It remains to treat a matching with neither
standard boundary chord. By (5)--(6),
\(L\) meets \(j_2\) or \(j_4\), while
\(R\) meets \(h_1\) or \(h_3\).
Three combinations cross on the opposite
page:
\[
L<h_1<j_2<R,\qquad
L<h_1<j_4<R,\qquad
L<h_3<j_4<R.
\]
Therefore \(Lj_2,h_3R\) are forced.

Inside \(Lj_2\), Note 355's \(Lj_2\)
forcing is unchanged by the right flank:
\(r_1h_1,s_ir_{i+1}\ (i<a),s_ao_1,
k_1i_2,j_1h_2\).
Inside \(h_3R\), the even slot \(k_3\)
must meet \(i_4\): \(k_3j_3\) is old,
\(k_3j_4\) and every \(k_3r'_j\)
enclose odd numbers of free slots.
Then \(j_3h_4\) is forced.
The odd slot \(j_4\) cannot meet \(e_4\),
an old edge. If it met \(s'_j\) for
\(j<b\), the complete suffix
\(T_{j+1},\ldots,T_b\) would close.
Thus \(j_4s'_b\), and noncrossing with
the same prefix cut rule forces
\(e_4r'_1,s'_jr'_{j+1}\ (j<b)\).
The two still-free middle slots are
\(e_2,o_3\), so \(e_2o_3\) is forced.
This proves (4). \(\square\)

**Spanning route.** In the fully nonstandard
case (4), the two sequences
\[
\begin{split}
P_L={}&(L,j_2,k_2,o_2,h_2,i_2,k_1,j_1,e_1,i_1,h_1,
F_1,\ldots,F_a,o_1,a_1,b_1,a_2,b_2,e_2),\\
P_R={}&(o_3,a_3,b_3,e_3,j_3,h_4,o_4,a_4,b_4,e_4,
G_1,\ldots,G_b,j_4,k_4,i_4,k_3,i_3,h_3,R)
\end{split}                                                  \tag{7}
\]
are vertex-disjoint, cover every block vertex
of (1), and use only old edges, the chords
of (3)--(4), and block-closing chords.
Their ends \(e_2,o_3\) are joined by
the matching edge \(e_2o_3\).
Consequently \((P_L,P_R)\) is one
spanning \(L\)--\(R\) path.
The other branches were handled by
path peeling. The resulting route
composes with Note 324's other groups
under the stated outside-vacancy
hypothesis; [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
then gives a Hamilton cycle in the legal
child. \(\square\)

The theorem covers the forward
\(J_3,J_1,J_3,J_1\) word with no
central short block and arbitrary
outer short flanks. A positive central
corridor, other internal chord words
and other opening types remain outside
its scope; the general Barnette
conjecture is not settled. This is a
project-internal analytic proof,
without an external priority claim.
