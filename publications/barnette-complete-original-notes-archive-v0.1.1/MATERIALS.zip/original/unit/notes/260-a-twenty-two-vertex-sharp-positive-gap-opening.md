> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A 22-vertex sharp positive-gap all-square opening

[Note 258](258-every-all-square-second-surplus-opening-is-hamiltonian.md)
proves that an all-square opening with a positive interblock gap
has \(f\ge4r+8\). [Note 259](259-two-target-free-vacancy-blocks-cannot-support-a-third-surplus-gap.md)
excludes two target-free vacancy blocks at equality. The bound is
nevertheless attained: both vacancies can occupy one target-free
block, with its face-side chord using only the last four slots.

Let \(C\) be the cyclic order \(0,1,\ldots,21,0\). Add the
following perfect matching, drawn in the two disks bounded by
\(C\):

\[
\begin{array}{c|l}
\text{designated-face side}
 &(0,3),(4,11),(7,10),(14,17),(18,21)\\
\text{opposite side}
 &(1,20),(2,5),(6,15),(8,13),(9,12),(16,19).
\end{array}                                                     \tag{1}
\]

**Sharp-gap construction theorem.** The graph \(G=C\cup M\)
of (1) is a Barnette graph. The site edges
\(q=(0,3)\) and \(p=(14,17)\) lie on a common face, and
their standard \(C_4\)-expansion is again a Hamiltonian
Barnette graph. The facial arc
\[
17,18,21,0                                                   \tag{2}
\]
is an alternating \(C,M,C\) opening. Its unique trapped
segment is a square, and its parameters are
\[
\ell=r=1,\qquad \sigma=2,\qquad T=2,\qquad
f=12=4r+8.                                                    \tag{3}
\]
Hence Note 258's universal positive-gap bound is sharp.
It is also the smallest possible order of a parent with a
positive-gap selected all-square opening and \(\ell,r\ge1\).

**Proof: class and face.** Every vertex of \(C\) occurs in
exactly one pair of (1). Every pair joins opposite parities,
and no pair is an edge of \(C\), so \(G\) is simple, cubic
and bipartite. The designated-face pairs are disjoint or
nested, with \((7,10)\) inside \((4,11)\). The opposite-side
pairs are likewise noninterlacing: \((1,20)\) encloses all
the others, \((6,15)\) encloses \((8,13)\), which encloses
\((9,12)\), and the remaining pairs are disjoint from that
nested chain. This is a plane embedding. Its common facial
boundary is
\[
0,3,4,11,12,13,14,17,18,21,0,                         \tag{4}
\]
which contains \(q,p\). The chord \((7,10)\) lies inside
the \((4,11)\) pocket and does not split this face.

For three-connectivity, use the following elementary
interlacement criterion. In any simple cubic graph written
as a Hamilton cycle plus a complementary perfect matching,
form the graph on matching edges in which two edges are
adjacent when their endpoints alternate on the Hamilton
cycle. If this interlacement graph is connected, the cubic
graph is three-connected. Indeed, deleting one vertex leaves
the spanning cycle as a path. If deleting nonadjacent
vertices \(u,v\) disconnected the graph, the two remaining
cycle paths would have no matching edge between them.
If \(u,v\) are matched together, or both have their matching
mates in the same path, the other path's matching edges form
a nonempty interlacement component separated from the rest.
If their mates lie in different paths, assign each of \(u,v\)
to the path containing its mate. The matching edges then lie
in two disjoint cyclic intervals and cannot interlace across
the two groups. Either way the interlacement graph would be
disconnected. Adjacent deleted vertices leave one spanning
cycle path. This proves the criterion.

For (1), the following crossing chains join all eleven
matching edges; \(\sim\) means alternation on \(C\):
\[
\begin{split}
(1,20)&\sim(0,3)\sim(2,5)\sim(4,11)
       \sim(6,15)\sim(14,17)\sim(16,19)\sim(18,21),\\
(4,11)&\sim(8,13)\sim(7,10),\qquad
(4,11)\sim(9,12).
\end{split}                                                    \tag{5}
\]
Thus \(G\) is three-connected.

**Proof: opening and marked Hamilton cycle.** In (4), the
arc (2) consists of the cycle edge \(17,18\), matching edge
\((18,21)\), and cycle edge \(21,0\). Its trapped old-cycle
segment is \(18,19,20,21\); the edge \((18,21)\) closes it
to a square. The escape matching edges are \((1,20)\) and
\((16,19)\), so \(R_1=1,L_1=16\). The other face arc has
one matching chord \((4,11)\), hence \(r=1\). Its blocks
are \([0,3]\), \([4,11]\), \([14,17]\), with capacities
\(0,2,0\), and the sole positive gap is \((11,14)_C\)
with slots \(12,13\). Thus \(\ell=1,\sigma=2,T=2\).
The main segment \([0,17]_C\) has eighteen vertices, so
\(f=18-2\ell-4=12\), proving (3).

The parent has the following Hamilton cycle through both
site edges (successive numbers are adjacent in \(G\)):
\[
7,6,15,14,17,16,19,18,21,20,1,0,3,2,5,4,11,
10,9,12,13,8,7.                                          \tag{6}
\]
Every old vertex appears exactly once. Replacing its
\(14,17\) edge by \(14,A,B,17\) and its \(0,3\) edge by
\(0,C,D,3\) gives a Hamilton cycle of the square-expanded
child, with new square \(A,B,C,D\) and cross edges
\(A D,B C\).

**Proof: legality of the child.** The expansion is cubic,
simple and plane inside face (4). Assign \(A,C\) odd and
\(B,D\) even; its new edges respect the old bipartition.
For three-connectivity, use the child Hamilton cycle obtained
from (6). The eleven old complementary matching edges,
listed by their endpoint *positions along (6)*, form this
single interlacement chain:
\[
(0,17)\sim(16,19)\sim(18,21)\sim(3,20)
\sim(2,5)\sim(4,7)\sim(6,9)\sim(8,11)
\sim(10,13)\sim(12,15)\sim(1,14).                         \tag{7}
\]
Inserting \(A,B\) after old position 3 and \(C,D\) after
old position 11 preserves the cyclic order of all old
vertices, so the old interlacement edges remain. The two
new complementary matching edges \(A D\) and \(B C\)
occupy child positions \((4,15)\) and \((5,14)\).
Both alternate with the old complementary edge
\((15,16)\), whose endpoint positions become \((2,7)\).
The child interlacement graph is connected by (7), hence
the child is three-connected by the same criterion.
\(\square\)

The construction proves sharpness of the gap bound for
\(r=\ell=1\); it does not establish sharpness separately
for every \((r,\ell)\), nor does it decide non-Hamiltonian
children at the third surplus or Barnette's conjecture.

**Minimum-order corollary.** After one-square-per-lobe
compression, any such positive-gap parent satisfies
\[
|V(G)|=|V(S_0)|+4\ell
      =f+6\ell+4
      \ge4r+6\ell+12\ge22.                       \tag{8}
\]
Uncompressed lobes only add vertices. The graph (1) attains
22, and its legal square-expanded child has 26 vertices.
Thus 22 and 26 are the exact minimum parent and child orders
*for positive-gap selected all-square openings with*
\(\ell,r\ge1\); no minimum-order claim is made for general
Barnette graphs or other opening types.
