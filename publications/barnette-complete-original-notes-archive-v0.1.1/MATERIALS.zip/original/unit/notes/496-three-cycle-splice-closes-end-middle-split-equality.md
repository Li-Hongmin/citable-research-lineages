> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A three-cycle splice closes the end-middle split equality profile

The three disjoint base cycles in [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md) can be joined into a single cycle on all their vertices using three old edges. Applying the two-terminal leaf-square theorem to that cycle gives a general closure whenever the special positions outside two-special leaves are paired among themselves. [Note 492](492-two-mixed-openings-reduce-end-middle-split-pairs-to-direct-cross-chords.md) forces exactly this pairing in its remaining end-middle case.

Use the chord-free three-root single-hexagon order
\[
 C=(w_0,t_d,W_1,t_c,W_2,t_b,W_3,t_a,w_*,
       \alpha,a,b,c,d,\beta,w_0)
\]
and the vertex-disjoint cycles \(D=C_1\cup C_2\cup C_3\) of Note 456. The middle-root closing chord is \(e_2=\ell_2r_2\), where \(\ell_2,r_2\) are the ends of \(W_2\). The site ports \(u,v\) are special positions in the three roots and satisfy \(q=w_0u,p=vw_*\).

**Self-matched-defect theorem.** Let \(\mathcal N\) be the set of all assigned special positions that do not belong to complete two-special leaves. Suppose \(u,v\) lie in two-special leaves and every position of \(\mathcal N\) has its face-matching mate in \(\mathcal N\). Then the parent has a Hamilton cycle containing both \(p,q\), regardless of the placement of \(\mathcal N\), the number of leaves or ordinary wrappers, and the connectivity of the root face graph. Its legal \(C_4\)-expanded child is Hamiltonian.

**Proof.** Delete the three edges \(t_cc,\ell_2r_2,t_bb\) from \(D\) and add \(t_c\ell_2,r_2t_b,bc\). The result is a single cycle \(D_0\) on \(V(D)\), explicitly
\[
 (c,d,t_d,W_{1,\ell}\xrightarrow{\rm old}W_{1,r},t_c,
   \ell_2\xrightarrow{\rm old}r_2,t_b,
   W_{3,\ell}\xrightarrow{\rm old}W_{3,r},t_a,a,b,c).
                                                               \tag{1}
\]
All displayed transitions outside the root arcs are old-cycle edges or the already specified escape edges \(t_dd,t_aa\). Thus (1) visits every vertex of \(D\) exactly once. In particular, it does not use any face-matching edge at \(\mathcal N\).

Let \(E\) be the old square-supported edge at each complete two-special leaf. Every edge of \(E\) occurs on the old root arcs of \(D_0\); its four square vertices are consecutive on \(D_0\), and distinct leaves have disjoint supports. Let \(M_E\) be the face-matching edges at these leaf special positions other than \(u,v\). The hypothesis that \(\mathcal N\) is matched within itself means \(M_E\) matches every endpoint of \(E\) except \(u,v\), with no edge joining a leaf special position to \(\mathcal N\). Also \(M_E\cap E(D_0)=\varnothing\), since third edges are not old-cycle edges.

Apply the two-terminal square-switch theorem of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) to \(D_0,E,M_E\). Its connectivity condition is automatic because \(D_0\) itself is one cycle. It gives a spanning \(u\)--\(v\) path on \(V(D)\). The unused outside path
\[
                         (u,w_0,\beta,\alpha,w_*,v)       \tag{2}
\]
closes it to a parent Hamilton cycle containing \(q,p\). The four vertices omitted from \(D_0\) are precisely \(w_0,w_*,\alpha,\beta\), and (2) covers each once. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts this marked parent cycle to the legal child. \(\square\)

**End-middle theorem.** Assume two split marked unary nodes lie in \(W_1,W_2\), every other assigned special position belongs to a complete two-special leaf, and the middle-node core chord \(H_2J_2\) is distinct from the root closing chord \(e_2\). Then the parent has a Hamilton cycle containing both site edges, and its legal child is Hamiltonian. The reflected assertion holds for nodes in \(W_2,W_3\).

**Proof.** If the root face graph is disconnected, [Note 486](486-disconnected-three-root-two-split-nodes-must-share-site-root.md) gives a marked parent Hamilton cycle for nodes in distinct roots. If it is connected and the parent had no marked Hamilton cycle, [Note 492](492-two-mixed-openings-reduce-end-middle-split-pairs-to-direct-cross-chords.md) would force the four direct positions to pair as \(s_1t_2,t_1s_2\). They are exactly \(\mathcal N\), while the site ports must lie in the remaining two-special leaves. The self-matched-defect theorem then gives the missing marked cycle, a contradiction. Reverse the root order for \(W_2,W_3\). \(\square\)

At the chord-free \(12f+2\) equality boundary of [Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md), each marked unary node has plain-unary ancestors, so \(H_2J_2\ne e_2\). Together with Notes [486](486-disconnected-three-root-two-split-nodes-must-share-site-root.md) and [490](490-two-split-end-roots-close-three-root-single-hexagon-openings.md), the end-middle theorem closes every placement of two split marked unary nodes in distinct roots. A possible failure of this equality profile must put both nodes in one root and have a connected root face graph. It must also have a site port at a direct special position or a face chord from a direct special position to a two-special leaf; otherwise the four direct positions are matched among themselves and the self-matched-defect theorem applies. The same theorem reproves the all-leaf three-root closure of Note 456 without a root face-graph case split. These conclusions concern a selected single-hexagon opening and do not prove Barnette's conjecture.
