> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One adjacent and one split unary node close the three-root chord-free equality profile

[Note 483](483-all-two-root-chord-free-unary-openings-are-hamiltonian.md) eliminates the two-root row at the chord-free \(12f+2\) equality boundary of [Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md). The remaining row has three ordinary roots, two marked unary nodes assigned two special positions each, and all other assigned special positions in two-special leaves. Here one unary node has an adjacent direct pair and the other has a split pair.

Use the three-root order and cycles \(C_1,C_2,C_3\) of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md):
\[
 w_0,t_d,W_1,t_c,W_2,t_b,W_3,t_a,w_*,
\tag{1}
\]
with site edges \(q=w_0u,p=vw_*\), escape edges \(t_dd,t_cc,t_bb,t_aa\), and trap chord \(\alpha\beta\). Let \(N_s\) have local word \(H_s,s,A,t,J_s\), with child chord \(LR\) and old boundary edges \(sL,Rt\). Let the other marked unary node \(N_a\) have adjacent direct positions \(x,y\), with old edge \(d=xy\). Write \(E\) for all two-special-leaf old edges, \(M\) for the face matching except at \(u,v\), and \(D=C_1\cup C_2\cup C_3\).

**Mixed-node theorem.** In this equality profile the parent has a Hamilton cycle containing \(p,q\), and every legal expanded child is Hamiltonian. The two marked unary nodes may lie in the same or different roots, disjointly or nested.

**The available wrapper switch.** In the equality row of Note 477, \(A_0=2f-3\), \(Q=f-1\), and \(c=5f-8\). Thus the number of plain-unary nodes is \(c-A_0=3f-5=2A_0-Q\), equality in the refined charge of Note 410. Both marked nonleaf nodes are unary and each has two consecutive plain-unary ancestors. Consequently the local wrapper substitution of [Note 472](472-one-adjacent-and-one-split-unary-node-always-splice-at-chorded-equality.md) applies on any root cycle of \(D\). If \(N_a\) is disjoint from \(N_s\) or lies in its child \(A\), use the square formed by \(N_a\)'s core chord and its immediate plain-unary parent. If \(N_a\) is an ancestor of \(N_s\), use the square formed by the two plain-unary ancestors of \(N_s\). Its two old rail edges lie in the same two component classes as the endpoints of the deleted \(d\); replacing those rails by its two unused ordinary chords connects the classes whenever restoring \(d\) would. The switch support consists only of ordinary vertices, is disjoint from all leaf-square supports and \(sL,Rt\), and its parent chord is not a root-closing edge of \(D\). The argument is local to a root arc, so it is unchanged when that root cycle is closed through escape vertices rather than its root chord.

**Proof.** If the root face graph \(K\) is disconnected, Note 456 puts both site ports in one isolated end root \(W\), with all its non-site face chords internal. Because \(N_s,N_a\) are distinct marked nodes, three possibilities exhaust \(W\). If it contains neither, Note 458 gives a spanning \(u\)--\(v\) path in its root cycle. If it contains only \(N_a\), the two-terminal one-unsupported-edge theorem of [Note 459](459-one-adjacent-nonleaf-pair-splices-and-102-vertex-failures-must-split.md) gives the path. If it contains \(N_s\), possibly together with \(N_a\), apply the inner/outer root-cycle openings of [Note 461](461-disconnected-root-face-matchings-close-the-split-unary-kernel.md), with the wrapper switch substituting for \(d\) when \(N_a\subset W\). In the inner opening, a matching edge crossing \(A\) connects its two coarse arcs; otherwise three-connectivity puts both site ports in \(A\), Note 473 forbids matching \(s\) to \(t\), and the outer opening connects the arcs. The extra adjacent pair is wholly within one coarse arc and its wrapper supplies exactly the missing switch there. Thus either opening gives a spanning \(u\)--\(v\) path. The exterior path (4) or (5) of Note 456 joins it through \(q,p\) to a parent Hamilton cycle.

Suppose \(K\) is connected. Form
\[
             F=(D-E-\{d,sL,Rt\})\cup M\cup\{LR\}.
\tag{2}
\]
It has one \(u\)--\(v\) path and some cycles. After restoring \(E,d\), the three base cycles have been cut only at \(sL,Rt\). Call the child arc \(A\), the complementary arc of its root cycle \(B\), and retain the other two whole root cycles. The adjacent edge \(d\) is wholly in one of these coarse pieces: the ordinary intervals of \(N_s,N_a\) are laminar and \(x,y\) are consecutive. The wrapper switch is therefore internal to that same coarse piece and gives the component connectivity that \(d\) would give. All other links between pieces are \(M\)-edges. Since \(K\) is connected, restoring \(E,d\) leaves either one connected component or exactly two, and the switchable leaf edges plus the wrapper square have the same connectivity.

If the restored graph is connected, switch along a component spanning tree rooted at the \(u\)--\(v\) path. Every switch joins a cycle to that path; the result spans \(D\). The outside path
\[
                         (u,w_0,\beta,\alpha,w_*,v)
\tag{3}
\]
then closes a Hamilton cycle through both site edges.

Otherwise switch separately in the two restored components. One becomes a spanning \(u\)--\(v\) path \(P\), the other a spanning cycle \(Z\). None of the switches changes an escape edge. The exclusion argument in [Note 462](462-three-root-split-unary-splice-and-sharper-single-hexagon-kernel.md) applies to this coarse separation. An unmarked \(A\) alone gives a forbidden two-edge cut. If \(N_s\) lies in an end root, the only unmarked side without an end escape edge besides \(A\) alone is \(A\) joined to the middle root; a face chord between them traps a suffix or prefix of the split root containing one of \(s,t\), complete leaf pairs, and possibly the adjacent pair \(x,y\). No site port or matching chord leaves that side, so its number of matching endpoints is odd. If \(N_s\) lies in the middle root, the only remaining unmarked side without an end escape edge is its complementary arc \(B\) alone. Its portions on the two sides of \(A\) each contain one of \(s,t\), complete leaf pairs, and possibly both \(x,y\) in one portion. Their odd matching counts force a face chord enclosing \(A\); noncrossing then leaves \(A\) with only \(sL,Rt\) in its edge cut, again impossible. In each count the adjacent pair contributes zero or two positions to a portion, so it does not change the parity or crossing argument of Note 462.

Therefore \(Z\) contains \(t_dd\) or \(t_aa\). Delete that edge. If it is \(t_dd\), join \(Z-t_dd\) and \(P\) through
\[
                    (u,w_0,t_d),\qquad(d,\beta,\alpha,w_*,v);
\tag{4}
\]
if it is \(t_aa\), use
\[
                    (u,w_0,\beta,\alpha,a),\qquad(t_a,w_*,v).
\tag{5}
\]
The two exterior paths in either line cover the four vertices outside \(D\), contain \(q,p\), and form one Hamilton cycle with \(P,Z\), exactly as in Note 462. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts every marked parent cycle to the legal child. \(\square\)

**Equality consequence.** Together with Note 483, a non-Hamiltonian chord-free child at \(c=5f-8\), if one exists, must have the three-root two-unary profile, and both unary nodes must have their direct special positions either both adjacent or both split. The theorem does not decide those two arrangements or the general Barnette conjecture.
