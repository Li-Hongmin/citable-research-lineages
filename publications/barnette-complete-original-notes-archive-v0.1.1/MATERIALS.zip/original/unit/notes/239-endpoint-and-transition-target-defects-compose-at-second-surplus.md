> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An endpoint and a cross-block transition defect compose at second surplus

[Note 237](237-disjoint-tight-budget-target-defects-compose-at-all-surpluses.md)
handles target defects with disjoint block intervals.
At the second surplus, an endpoint defect and a
transition defect in distinct blocks can overlap
only when the endpoint target and the transition's
nearer target share one block. The two possible
matching chords across that block's target run
would create a two-edge cut.

Use a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps, and \(s=2\),
so \(f=4r+6\). Let \(d_L,b,d_R\) be Note 197's
target-order defects.

**Endpoint--transition theorem.** Suppose the two
targets of the defective transition lie in
distinct blocks. If
\[
d_L+b+d_R=2,\qquad b=1,\qquad d_L+d_R=1,
\tag{1}
\]
then the parent has a Hamilton cycle through both
site edges \(xy,uv\), and its legal site-expanded
child is Hamiltonian. This holds for arbitrary
positive original lobe lengths.

**Proof.** Reverse the oriented opening if necessary,
so \(d_L=b=1,d_R=0\). Write \(R_\ell\in B_h\).
For the unique defective transition
\(L_j,R_{j-1}\), \(2\le j\le\ell\), write
\(L_j\in B_i,R_{j-1}\in B_m\).
Target order gives \(h\le i\). The two defects
consume both eligible vacancies by Note 197.
Its endpoint barrier and the one vacancy before
\(R_\ell\) put that target at the third interior
slot of \(B_h\), with all preceding blocks short.
The first-slot cut of Note 212 excludes
\(R_{j-1}\) as the first interior of a later
block. Its sole vacancy between the defective
targets then puts \(L_j\) at the last eligible
position of \(B_i\), \(R_{j-1}\) at the third
interior slot of \(B_m\), and makes every block
strictly between \(B_i,B_m\) short. The
hypothesis gives \(i<m\).

If \(h<i\), the defect intervals \([0,h]\)
and \([i,m]\) are disjoint, so Note 237
applies. It remains to take \(h=i\).
No vacancy remains between \(R_\ell\) and
\(L_j\). All targets there are consecutive,
because every other inter-lobe transition
is tight. The shared block has the free and
target order
\[
o_i,w,R_\ell,L_\ell,R_{\ell-1},\ldots,
L_j,c,e_i,                                      \tag{2}
\]
with the evident shortened sequence when
\(j=\ell\). Here \(o_i,w\) are the free
slots before the target run and \(c,e_i\)
the free slots after it.

The number of free slots before \(R_\ell\)
is even. Note 203 forbids a cross-block
free chord over that escape target. The
only opposite-colour same-block chords
across the run are
\[
o_i e_i,\qquad wc.                              \tag{3}
\]
Matching parity permits either both or
neither. If both occur and \(i\ge1\), the
complete prefix \(B_0,\ldots,B_{i-1}\)
contains no escape target and is closed
under \(M\): its possible mates in \(B_i\)
before \(R_\ell\) are used by (3), and
cross-block chords reaching beyond
\(R_\ell\) are forbidden. Only its two
boundary \(C\)-edges leave, contradicting
three-connectivity.

If \(i=0\), take instead the consecutive
\(C\)-interval consisting of
\(S_j,\ldots,S_\ell\) followed by \(B_0\).
All escape targets in \(B_0\) are matched
to these included squares; its four free
slots are used by (3), while its site
chord and the square chords are internal.
Again exactly two old-cycle edges leave.
Thus (3) cannot occur for any \(i\).

With no chord across the shared target
run, the free group before \(R_\ell\)
and the group strictly between
\(L_j,R_{j-1}\) are matching-closed.
If \(i=0\), the first group is just
the adjacent pair \(o_0,w\), which cannot
be matched; hence any actual graph in
this case has \(i\ge1\).
The first group has exactly Note 211's
slot order, so it uses \(o_0w\) and its
ordinary standard links. The second
has exactly Note 212's slot order, so
it uses \(cz\), where \(o_m,z\) precede
\(R_{j-1}\), and its ordinary standard
links. All other free groups follow
the standard chain.

Let \(A\) be the even-starting matching
of \(C\). In Note 196's target-and-square
path, simultaneously replace
\[
xR_\ell\longmapsto x,o_0,w,R_\ell,
\qquad
L_jR_{j-1}\longmapsto L_j,c,z,R_{j-1}.
\tag{4}
\]
The middle edges \(o_0w,cz\) belong to
\(M\); the outer edges belong to \(A\).
The ordinary free path is unchanged.
The two paths are internally disjoint,
cover every vertex, and have endpoints
\(x,v\); their union is a Hamilton cycle
containing \(xy,uv\). The case \(d_R=b=1\)
is the reflection. Notes 001 and 178
give the legal child and longer lobes.
\(\square\)

**A realized shared-block profile.** Set
\(\ell=2,r=3,j=2,i=h=1,m=3\). Take the
old 34-cycle in consecutive blocks
\[
\begin{array}{ll}
B_0:&x,o_0,e_0,y,\\
B_1:&a_1,o_1,w,R_2,L_2,c,e_1,b_1,\\
B_2:&a_2,o_2,e_2,b_2,\\
B_3:&a_3,o_3,z,R_1,e_3,b_3,\\
B_4:&u,o_4,L_1,v,\\
S_t:&\alpha_t,\gamma_t,\delta_t,\beta_t
\quad(t=1,2),\text{ returning to }x.
\end{array}                                      \tag{5}
\]
Its complementary matching is
\[
\begin{split}
M={}&\{xy,uv,a_1b_1,a_2b_2,a_3b_3\}\\
&\cup\{\alpha_t\beta_t,R_t\delta_t,
L_t\gamma_t:t=1,2\}\\
&\cup\{o_0w,e_0o_1,cz,e_1o_2,
e_2o_3,e_3o_4\}.
\end{split}                                      \tag{6}
\]
Every matching edge joins opposite
old-cycle parities. Draw the site,
face, and \(\alpha_t\beta_t\) chords
on one side. On the other side,
\(o_0w\supset e_0o_1\), and
\[
R_2\delta_2\supset L_2\gamma_2
\supset\bigl(cz\supset
\{e_1o_2,e_2o_3\},\
R_1\delta_1\supset
\{e_3o_4,L_1\gamma_1\}\bigr).
\tag{7}
\]
The two chords within each brace are
disjoint. Thus the parent is simple,
cubic, bipartite, plane, and has
cofacial \(xy,uv\).

Its chord-interlacement graph is
connected. One spanning chain is
\[
\begin{split}
xy-o_0w-a_1b_1-e_1o_2-a_2b_2-e_2o_3
-a_3b_3-e_3o_4-uv-L_1\gamma_1\\
-\alpha_1\beta_1-R_1\delta_1
-a_3b_3-cz-a_1b_1-R_2\delta_2
-\alpha_2\beta_2-L_2\gamma_2-a_1b_1.
\end{split}                                      \tag{8}
\]
The remaining \(e_0o_1\) interlaces \(xy\).
Note 217's interval criterion proves
three-connectivity, and its cut map
makes the 38-vertex site expansion
Barnette. The marked parent cycle
is the union of
\[
\begin{split}
&x,o_0,w,R_2,\delta_2,\beta_2,\alpha_2,
\gamma_2,L_2,c,z,R_1,\delta_1,\beta_1,
\alpha_1,\gamma_1,L_1,v,\\
&x,y,e_0,o_1,a_1,b_1,e_1,o_2,a_2,b_2,
e_2,o_3,a_3,b_3,e_3,o_4,u,v.
\end{split}                                      \tag{9}
\]
They share only \(x,v\) and cover all
34 vertices. \(\square\)

The same-block transition is treated
in [Note 240](240-same-block-transition-with-an-endpoint-defect-has-a-marked-hamilton-cycle.md).
Two
nonadjacent inter-lobe transitions
whose block intervals overlap, one
defect with a spare vacancy in its
own group, gap slots, and nonsquare
residual cycles also remain open.
The theorem does not settle
Barnette's conjecture.
