> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One mixed port-vacancy pair absorbs arbitrary nested vacancy cycles

[Note 279](279-single-mixed-vacancy-has-three-spanning-four-port-routes.md)
constructs three four-port states when a missing ordinary link
attaches to one vacant block and all other blocks of the patch
are short. The same states persist when the intervening blocks
contain arbitrarily many vacancy-only matching cycles. They
can then be placed inside further vacancy-only cycles by the
recursion of [Note 275](275-every-vacancy-only-noncrossing-matching-is-marked-hamiltonian.md).

Work in the compressed, gapless, tight-target all-square opening
of Notes [196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md)
and [278](278-missing-chain-ports-separate-and-three-free-vacancies-are-hamiltonian.md),
with \(\ell,r\ge1\). All vacancies lie in distinct target-free
internal face-chord blocks. In one free group let exactly one
ordinary link be missing:
\[
 P_s=(E_s,O_s)=(e_s,o_{s+1}).                         \tag{1}
\]
Use the noncrossing atom partition of Note 278. Suppose the
part containing \(P_s\) consists of \(P_s\) and one vacancy
atom \(V_k=(H_k,I_k)\). Every other part is therefore a
vacancy-only cycle. If \(P_s<V_k\), assume \(B_s\) is a short
target-free internal block. If \(V_k<P_s\), assume instead
that \(B_{s+1}\) is such a short block. Assume the ordinary
links at the ends of this free group are retained; equivalently,
the missing link is internal to its full target-free block
interval.

**Nested mixed-pair theorem.** The group has a vertex-spanning
route with the same ordinary endports as Note 196's free path.
More precisely, its full consecutive target-free block interval
\(D=B_a,\ldots,B_b\) has all three four-port states
\[
\begin{array}{ll}
X(D):&a_a\longleftrightarrow b_b,\quad
       o_a\longleftrightarrow e_b;\\
K(D):&a_a\longleftrightarrow o_a,\quad
       e_b\longleftrightarrow b_b;\\
S(D):&o_a\longleftrightarrow e_b.
\end{array}                                               \tag{2}
\]
The first two states are pairs of disjoint paths; every state
covers every vertex exactly once. In particular, if every other
free group of the opening has a spanning ordinary-endport route
(as happens when those groups are vacancy-only), the parent has
a Hamilton cycle through both site edges and its legal expanded
child is Hamiltonian. The number and nesting depth of the
vacancy-only parts are unrestricted.

**Proof.** Reflect the block order if necessary so that
\(P_s<V_k\). The rainbow rule of Note 278 gives exactly
\[
 E_sI_k,\qquad O_sH_k\in M.                           \tag{3}
\]
The adjacent choices \(k=s,s+1\) would make one edge in (3)
an old-cycle edge, so \(k\ge s+2\). Every atom strictly
between \(P_s,V_k\) belongs to a part wholly between them;
otherwise its matching chords would cross (3). There is no
other port. Consequently the interval
\[
 J=B_{s+1},\ldots,B_{k-1}                            \tag{4}
\]
is closed under its vacancy matching, and all its ordinary
links are retained. It is nonempty. Note 275 supplies its
three states \(S(J),K(J),X(J)\), even when its vacancy-only
cycles are nested. Denote the paths of \(X(J)\) by
\(X_{\rm top}:a_{s+1}\leftrightarrow b_{k-1}\) and
\(X_{\rm bottom}:o_{s+1}\leftrightarrow e_{k-1}\).

First consider the mixed core \(D_0=B_s,\ldots,B_k\).
The following explicit paths give its three states. In each
display, a named path of \(J\) is traversed from the endpoint
next to it:
\[
S(D_0):\quad
o_s,a_s,b_s,e_s,I_k,H_k,o_{s+1}
 \xrightarrow{S(J)}e_{k-1},o_k,a_k,b_k,e_k.              \tag{5}
\]
\[
\begin{aligned}
K_L(D_0):\quad
a_s,b_s,a_{s+1}
 &\xrightarrow{X_{\rm top}}b_{k-1},a_k,o_k,e_{k-1}
 \xrightarrow{X_{\rm bottom}^{-1}}o_{s+1},H_k,I_k,e_s,o_s,\\
K_R(D_0):\quad &e_k,b_k.
\end{aligned}                                               \tag{6}
\]
\[
 X_{\rm bottom}(D_0):\quad o_s,e_s,I_k,e_k.             \tag{7}
\]
\[
\begin{aligned}
X_{\rm top}(D_0):\quad
a_s,b_s,a_{s+1}
 &\xrightarrow{X_{\rm top}}b_{k-1},e_{k-1}
 \xrightarrow{X_{\rm bottom}^{-1}}o_{s+1},H_k,o_k,a_k,b_k.
\end{aligned}                                               \tag{8}
\]
The joins \(e_sI_k,o_{s+1}H_k\) are (3),
\(e_{k-1}o_k\) is a retained ordinary link,
and \(I_kH_k\) is an old-cycle edge.
In (6), \(o_ke_{k-1}\) is the same retained link;
in (8), \(b_{k-1}e_{k-1}\) is an old-cycle edge.
The short block \(B_s\) contributes exactly
\(a_s,o_s,e_s,b_s\); the vacant block \(B_k\)
contributes exactly \(a_k,o_k,H_k,I_k,e_k,b_k\).
For (5), \(S(J)\) covers \(J\). For (6)--(8), the
two disjoint paths of \(X(J)\) cover \(J\). Thus every
state in (5)--(8) has the endpoints in (2) and spans
\(D_0\), with no repeated vertex.

We next record precisely why vacancy-only cycles can surround
this core. Note 275's induction on noncrossing vacancy parts
uses a closed gap between consecutive atoms only through its
three states: its \(X\) state is obtained by joining the top
and bottom \(X\) rails; its prime \(K\) state uses \(X\)
in the first gap and the old-cycle arc through all later gaps;
its prime \(S\) state uses \(K\) in the first gap and
\(S\) in later gaps. The old-cycle arc remains available when
a later gap contains the missing matching link (1), since that
link is not an old-cycle edge. For serial closed intervals,
\(S+S\) joins across the retained ordinary link, while
\(X+X\) and \(K+X\) join across that link and the old-cycle
top-rail edge. These are exactly the joins in Note 275.
It follows by the same induction that a vacancy-only prime
interval has all three states whenever each of its proper
closed gaps already has them, even if one gap contains \(D_0\).

The shortness of \(B_s\) makes the induction block-aligned.
No vacancy-only part can use \(B_s\) as its endpoint block.
If a vacancy-only part surrounds the mixed pair, its first
vacant block precedes \(B_s\), and its last vacant block
follows \(B_k\); hence \(D_0\) lies wholly in one of its
proper block gaps. Parts strictly between \(P_s,V_k\) were
already absorbed into \(J\). All other parts lie in serial
flanks or in a finite chain of surrounding vacancy-only prime
intervals. Starting with (5)--(8), applying the preceding
prime induction from inside out, and finally serially joining
the flanks constructs all three states of \(D\). The only
missing ordinary link is internal to \(D_0\), so every serial
join used in this construction is retained.

Attach the resulting \(S(D)\) to the group's retained end
links. It replaces its ordinary segment in Note 196's free
path without changing the endports. Other group replacements
with the same endports commute, as in Note 273. The unchanged
target-and-square path then closes a Hamilton cycle containing
both site edges. Notes 001 and 178 lift that cycle to the legal
child and restore arbitrary positive lobe lengths. Reflection
proves the case \(V_k<P_s\). \(\square\)

This theorem permits any number of port-free cycles nested
inside or around the mixed pair. It does not classify a port
part containing two or more vacancies, a vacancy in the short
source block of the mixed link, several missing links in the
same group, or vacancies in target-bearing or site blocks.
It does not settle Barnette's conjecture.
