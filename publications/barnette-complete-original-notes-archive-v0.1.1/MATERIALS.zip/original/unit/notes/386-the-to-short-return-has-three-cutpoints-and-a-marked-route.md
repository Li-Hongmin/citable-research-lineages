> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The `to,hp_s` return has three cutpoints and a marked Hamilton route

[Note 385](385-the-to-hj-single-double-corridor-has-a-complete-three-tier-matching-classification.md)
classifies the `to,hJ` branch of an isolated single–double corridor.
This theorem closes the branch where the next return from the single
block ends in a short block.

Use the same compressed, gapless, tight-target all-square selected opening,
old-cycle blocks
\[
 V=(a,o,h,i,e,b),\quad S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),
 \quad D=(A,O,H,I,K,J,E,B),                              \tag{1}
\]
and even left and odd right free endports \(t,z\). The group has no
short flanks; other groups may occur. Assume that the double block
has no internal free matching chord and that \(to,hp_s\) are in the
complementary matching \(M\), where \(s\ge2\).

For
\[
                         2\le s\le r<u<m,              \tag{2}
\]
put
\[
\begin{split}
 T_{m;s,r,u}=\{&hp_s,iq_{s-1},ep_1,q_rJ,p_{r+1}K,
                  q_uI,p_{u+1}H,q_mO\}\\
 &{}\cup\{q_jp_{j+1}:1\le j<m,
                  \ j\notin\{s-1,r,u\}\}.
\end{split}                                               \tag{3}
\]

**Three-cutpoint theorem.** Every actual matching under these
hypotheses is exactly
\[
                    \{to,Ez\}\cup T_{m;s,r,u}            \tag{4}
\]
for one unique triple (2). The branch is empty for \(m<4\)
and has \(\binom{m-1}{3}\) words for \(m\ge4\).
Every word occurs in a \(26+4m\)-vertex Barnette parent
with a Hamilton cycle through both site edges and a legal
Hamiltonian site-expanded child. In any actual opening with
this group, its induced interval has a spanning \(o\)--\(E\)
path. If all vacancies outside the group lie in distinct
internal blocks, [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md)
therefore gives a marked Hamilton parent cycle and child.

**Forced matching.** Use the free-slot order
\[
 t,o,h,i,e,p_1,q_1,\ldots,p_m,q_m,O,H,I,K,J,E,z.        \tag{5}
\]
All free chords in this branch join different blocks and lie
opposite the designated common face, by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
They do not interlace. A proper consecutive run of complete
short blocks matched wholly inside itself would have only its
two boundary old-cycle edges leaving it, contradicting
three-connectivity.

The chord \(hp_s\) encloses \(i,e,p_1,q_1,\ldots,
p_{s-1},q_{s-1}\). Colour and the old-cycle neighbours
restrict \(i\) to some \(q_k\) with \(k<s\). A choice
\(k<s-1\) would leave the complete run
\(S_{k+1},\ldots,S_{s-1}\) matched within itself. Hence
\(iq_{s-1}\) is forced. The leftmost remaining slot must
pair as \(ep_1\), and repeating the same short-block rule
forces \(q_jp_{j+1}\) for \(j<s-1\).

The slot \(J\) cannot meet \(H\), since the double block has
no internal free chord, and \(KJ,JE\) are old-cycle edges.
It cannot reach \(e\) or an earlier \(q_j\) without crossing
\(hp_s\). Thus \(Jq_r\) occurs with \(r\ge s\).
The choice \(r=m\) strands \(O,H,I,K\) inside \(q_mJ\):
their only candidate internal chord is the forbidden \(OK\),
and the other mutual edges are old-cycle edges. Hence
\(r\le m-1\). The gap from \(q_s\) to \(p_r\) forces
\(q_jp_{j+1}\) for \(s\le j<r\).

Inside \(q_rJ\), the slot \(K\) must meet a later \(p_k\);
\(OK\) is excluded and its other double-block neighbours
are old-cycle neighbours. Skipping a complete short-block
run is impossible, so \(Kp_{r+1}\) is forced. Inside this
chord, \(I\) must meet \(q_u\) with \(u\ge r+1\).
The choice \(u=m\) strands the old-cycle pair \(O,H\),
so \(u<m\). The only possible mate of \(H\) is a later
\(p_k\), and the short-block rule gives \(Hp_{u+1}\).
The remaining end slots force \(Oq_m\), followed by all
ordinary links except at \(s-1,r,u\). The mate of \(h\)
and then those of \(J,I\) recover \(s,r,u\) uniquely.
Counting strictly increasing \((s-1,r,u)\) in
\(\{1,\ldots,m-1\}\) gives \(\binom{m-1}{3}\).

**Spanning route.** Use \(U_{1:k}\) and \(W_{v:w}\) from
[Note 385](385-the-to-hj-single-double-corridor-has-a-complete-three-tier-matching-classification.md),
equations (5)–(6). The three \(W\) segments below use
only the links retained in (3). The sequence
\[
\begin{split}
 o,a,b,\ U_{1:s-1},\ e,i,h,\ W_{s:r},\
 J,K,\ W_{r+1:u},\ I,H,\ W_{u+1:m},\ O,A,B,E
\end{split}                                               \tag{6}
\]
visits every vertex of (1) once. Its non-obvious joins
are \(p_1e,hp_s,q_rJ,Kp_{r+1},q_uI,Hp_{u+1},q_mO\),
all in (3). The other joins are old-cycle edges, face
chords or surviving ordinary links. Therefore (6) is a
spanning \(o\)--\(E\) path; \(to,Ez\) extend it to a
spanning \(t\)--\(z\) group route.

**Genuine realizations.** Take the \(26+4m\)-vertex old
Hamilton cycle of Note 385, equation (8), and its
complementary matching (9), with \(T=T_{m;s,r,u}\).
The slots are perfectly paired, every edge joins opposite
old-cycle parities, and the common-face chords are disjoint.
On the opposite page, \(\delta R_1\) encloses all the other
chords; \(e_0o\), \(hp_s\) with its nested left returns,
\(q_rJ\) with its nested right returns, \(Eo_3\) and
\(\gamma L_1\) are mutually nested or disjoint as their
endpoint intervals require. Thus the parent is simple,
cubic, bipartite and plane, and the site edges are cofacial.

Its matching-chord interlacement graph is connected. Put
\(F_0=ab,F_j=c_jd_j,F_D=AB\). The exterior alternating
chain is
\[
 xy-e_0o-F_0,\qquad F_D-Eo_3-uv-\gamma L_1
              -\alpha\beta-\delta R_1-xy.             \tag{7}
\]
The chords \(hp_s,iq_{s-1},ep_1\) join \(F_0\) to
\(F_s,F_{s-1},F_1\), respectively. The chord \(q_rJ\)
joins \(F_r,F_D\); \(p_{r+1}K,q_uI,p_{u+1}H,q_mO\)
join \(F_{r+1},F_u,F_{u+1},F_m\) to \(F_D\).
All other adjacent \(F_j\) are joined by the ordinary
links in (3). These incidences connect every face chord
and every internal chord to (7), including across the
interval from \(F_s\) to \(F_r\). A two-edge cut in a
cubic Hamiltonian graph would give a proper old-cycle
interval closed under the matching and disconnect this
interlacement graph. The Hamilton cycle rules out bridges,
so the parent is three-edge-connected and hence
three-vertex-connected.

Replace the second \(x\)--\(v\) path of Note 385,
equation (11), by the same sequence with (6) between
\(e_0\) and \(o_3\). Together with its unchanged first
path this is a Hamilton cycle through \(xy,uv\): the
two paths are internally disjoint and cover all vertices.
The site expansion is legal for the same old-cycle parity
reason as in Note 385. Note 217's cut projection gives a
Barnette child; Note 001 lifts the marked parent cycle to
a Hamilton child. The selected opening retains the one
residual square and the stated block order. \(\square\)

In the `to` branch, \(hO\) and \(hI\) are impossible:
each chord would leave \(J\) to its right, while its only
possible mates outside the double block, \(e,q_j\), lie
inside that chord and would cross it. The old-cycle edges
\(KJ,JE\) and the excluded internal chord \(HJ\) do not
match \(J\). The edge \(hp_1\) traps the old-cycle pair
\(i,e\). Thus, under the no-internal-chord hypothesis,
Notes 385–386 settle all `to` words except the outer
return \(hz\), up to old-cycle reflection. The outer
return, short flanks and other opening types remain open.
This is a project-internal analytic proof, without local
graph recomputation, independent review or external
priority claim. It does not resolve Barnette's conjecture.
