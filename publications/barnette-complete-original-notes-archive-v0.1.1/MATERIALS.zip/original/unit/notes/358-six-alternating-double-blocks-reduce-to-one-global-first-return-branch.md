> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Six alternating double blocks reduce to one global first-return branch

[Note 357](357-all-forward-four-double-groups-with-arbitrary-short-corridors-have-spanning-routes.md)
settles every actual alternating four-double ordinary free group
with arbitrary short corridors. [Note 335](335-two-oppositely-oriented-double-vacancies-have-one-adjacent-mixed-core.md),
[Note 346](346-the-alternating-rainbow-double-chain-is-square-equivalent-at-every-length.md),
and [Note 347](347-a-nested-four-double-swap-has-the-square-hamilton-signature.md)
provide exact square reductions. These results remove every
six-block first-return branch except one.

Work in the compressed, gapless, tight-target all-square opening
of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
An ordinary target-free free group has even left and odd right
endports \(L,R\) and exactly six consecutive double blocks
\[
 D_t=(a_t,o_t,h_t,i_t,k_t,j_t,e_t,b_t),\qquad 1\le t\le6, \tag{1}
\]
with no short block in the group. Their only same-block free
matching chords are \(i_te_t\) for odd \(t\) and \(o_tk_t\)
for even \(t\), all on the common-face page. Thus the
orientation word is \(J_3,J_1,J_3,J_1,J_3,J_1\).

**Six-block first-return theorem.** In every actual Barnette
matching satisfying (1), the mate of \(h_1\) is one of
\[
               j_2,\quad j_4,\quad o_5,\quad j_6,\quad R. \tag{2}
\]
If it is \(j_2,j_4,o_5\), or \(R\), the group has a
vertex-spanning \(L\)--\(R\) path: every one of those
branches contains a proper exact square-equivalent
two- or four-double patch. Consequently an actual
matching with no such reducible patch must have
\(h_1j_6\). This theorem does not decide that final
first-return branch.
If all vacancies outside a settled group occupy distinct
internal blocks, its Barnette parent has a Hamilton cycle
through both site edges and its legal child is Hamiltonian.

**Proof.** Note 327 excludes further same-block free chords,
and Note 193 puts all cross-block free chords on a single
opposite page, where they cannot cross. The unmatched free
slots, in old-cycle order, are
\[
\begin{split}
L;\ &(o_1,h_1,k_1,j_1);\
(h_2,i_2,j_2,e_2);\
(o_3,h_3,k_3,j_3);\\
 &(h_4,i_4,j_4,e_4);\
(o_5,h_5,k_5,j_5);\
(h_6,i_6,j_6,e_6);\ R.                                  \tag{3}
\end{split}
\]
Every opposite-page chord encloses an even number of free
slots. The old edge \(h_1i_1\) and the isolated same-block
candidate \(h_1j_1\) are unavailable. Counting slots in
(3) leaves exactly \(j_2,o_3,j_4,o_5,j_6,R\) as possible
mates of \(h_1\). If \(h_1o_3\), its interior consists of
\(k_1,j_1,h_2,i_2,j_2,e_2\). The first four force
\(k_1i_2,j_1h_2\), leaving the forbidden old edge
\(j_2e_2\). This eliminates \(o_3\) and proves (2).

If \(h_1j_2\), its four interior slots force
\(k_1i_2,j_1h_2\). Together with the prescribed
internal and closing chords, \(D_1D_2\) is precisely
Note 335's sixteen-vertex square-equivalent patch.
Its four external attachments remain at
\(a_1,o_1,e_2,b_2\), regardless of how \(o_1,e_2\)
are matched outside: the edge \(o_1e_2\) would close
the complete-block interval \(D_1D_2\) and produce a
forbidden two-edge cut. Compressing it leaves one short
block followed by \(D_3,D_4,D_5,D_6\), still in the
forward four-double orientation. The replacement preserves
Barnette membership and the opening, so Note 357 gives a
spanning route in the reduced group. The exact four-terminal
signature of Note 335 lifts it.

Suppose \(h_1j_4\). Every free slot strictly between its
ends must match within that chord. The interior exhaustion
in Note 347's complete no-flank four-block consequence
is therefore unchanged by \(D_5,D_6\): the only possible
wirings are Note 345 at \(m=2\) and Note 347 (3).
The rejected interior choices leave an old pair or close
the proper complete-block interval \(D_2D_3\), so they
remain rejected here. Every vertex of \(D_1,\ldots,D_4\)
except \(a_1,o_1,e_4,b_4\) has all three incident
edges inside this four-block patch. Notes 346--347 show
that either wiring has the exact square signature at
those four attachments. The edge \(o_1e_4\) would close
\(D_1,\ldots,D_4\) under the matching and is excluded by
the same two-edge-cut rule, so \(o_1,e_4\) really do
attach externally. Compress the patch to one short block.
The remaining ordinary group has just the adjacent
\(J_3,J_1\) pair \(D_5,D_6\) and a left short flank;
[Note 336](336-every-two-double-mixed-j1-j3-free-group-has-a-spanning-route.md)
gives its spanning route. Lift through the exact signature.

Suppose \(h_1o_5\). The two free slots \(L,o_1\) precede
this chord. A chord from either to any slot after \(o_5\)
would cross \(h_1o_5\), so \(Lo_1\) is forced. The
remaining free tail, outside \(h_1o_5\), is
\[
                  h_5,k_5,j_5,h_6,i_6,j_6,e_6,R.        \tag{4}
\]
The even slot \(h_5\) can meet only \(j_6\) or \(R\).
The candidate \(h_5j_5\) encloses one free slot,
and \(h_5i_6\) encloses three; other candidates
have its own colour or are unavailable old edges.
If \(h_5R\), the six inner slots force
\(k_5i_6,j_5h_6\), leaving the old pair \(j_6e_6\).
Thus \(h_5j_6\), with forced inner chords
\(k_5i_6,j_5h_6\) and outer edge \(e_6R\).
The two blocks \(D_5D_6\) are precisely Note 335's
square-equivalent patch. Compressing them leaves
\(D_1,D_2,D_3,D_4\) followed by one short block.
Note 357 gives the reduced group's spanning route;
the exact patch signature lifts it.

Finally suppose \(h_1R\). Noncrossing forces \(Lo_1\).
The even slot \(e_6\) can meet only
\(j_2,o_3,j_4,o_5\): these and only these
opposite-colour slots leave an even number of free slots
between themselves and \(e_6\), after old and same-block
edges are excluded. The chord \(o_3e_6\) would close
the complete-block interval \(D_3,\ldots,D_6\);
\(o_5e_6\) would close \(D_5D_6\). Both yield forbidden
two-edge cuts.

If \(j_4e_6\), the first free slot \(e_4\) inside it
can meet only \(o_5\) or \(j_6\). The latter choice
leaves \(o_5\) without an interior mate:
\(o_5h_5\) is old, \(o_5k_5\) is excluded by
chord isolation, and \(o_5h_6\) encloses three
free slots. Hence \(e_4o_5\). The remaining six
slots force \(h_5j_6,k_5i_6,j_5h_6\).
Again \(D_5D_6\) is Note 335's exact square patch.
After compression, Note 357 supplies the route and
the patch signature lifts it.

Thus an unreduced \(h_1R\) matching has \(j_2e_6\).
The chord \(j_2e_6\) prevents \(k_1\) from meeting
any slot after \(j_2\) without crossing; its only
mate before \(j_2\) is \(i_2\), and \(j_1h_2\)
follows. Inside \(j_2e_6\), the first even slot
\(e_2\) can meet only \(o_3,j_4,o_5,j_6\).
The edge \(e_2j_4\) encloses
\(o_3,h_3,k_3,j_3,h_4,i_4\). Its first
slot \(o_3\) has no mate there: \(o_3h_3\)
is old, \(o_3k_3\) is excluded by chord
isolation, and \(o_3h_4\) encloses three
free slots. The edge \(e_2o_5\) closes
the complete-block interval \(D_3D_4\).
Hence \(e_2o_3\) or \(e_2j_6\).

If \(e_2o_3\), the first remaining even slot
\(h_3\) can meet only \(j_4,o_5,j_6\).
The choice \(h_3o_5\) encloses
\(k_3,j_3,h_4,i_4,j_4,e_4\):
\(k_3i_4,j_3h_4\) are forced, leaving
the old edge \(j_4e_4\). The choice
\(h_3j_4\) gives Note 335's local
\(D_3D_4\) patch. If \(h_3j_6\),
the interior classification in Note 347
gives one of the two exact square-equivalent
four-double patches on \(D_3,\ldots,D_6\).
Its boundary slots \(o_3,e_6\) are matched
externally to \(e_2,j_2\), respectively.
Compressing either patch leaves a forward
four-double or mixed two-double ordinary
group, covered by Note 357 or Note 336.

If \(e_2j_6\), the first inner odd slot \(o_3\)
can meet only \(e_4\) or \(h_5\).
The edge \(o_3e_4\) closes \(D_3D_4\),
so \(o_3h_5\). Inside that chord,
\(h_3\) can meet only \(j_4\) or \(o_5\).
The latter choice again leaves the forbidden
old pair \(j_4e_4\); hence \(h_3j_4\),
with \(k_3i_4,j_3h_4\) forced inside it.
The remaining slots of \(o_3h_5\)
force \(e_4o_5\), and those between
\(h_5,j_6\) force \(k_5i_6,j_5h_6\).
Thus \(D_3D_4\) is Note 335's exact
square patch. Compress it: the reduced
group has four forward alternating double
blocks with one central short block, so
Note 357 gives a spanning route and
Note 335 lifts it. This exhausts \(h_1R\)
and proves the theorem. \(\square\)

The result is a route reduction for this specified six-block
word, not a classification of its \(h_1j_6\) branch.
It gives no conclusion for other chord words,
openings, or general Barnette graphs. The proof is
project-internal and makes no external priority claim.
