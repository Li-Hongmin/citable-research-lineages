> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One-sided interior port components have three spanning routes

[Note 283](283-interior-three-atom-port-component-has-three-spanning-routes.md)
handles one vacancy on each side of an interior missing-link
port. The far side can have arbitrarily many vacancies.
The cap route traverses them on the old cycle; the crossed
route folds the gap before the final far-side vacancy,
using the mechanism of
[Note 282](282-end-ports-with-arbitrarily-many-vacancies-have-three-spanning-routes.md).

Use a compressed, gapless, tight-target all-square opening
with \(\ell,r\ge1\). All vacancies lie in distinct
target-free internal face-chord blocks. In one free group
suppose exactly one ordinary link
\(P_s=(e_s,o_{s+1})\) is missing. Its part in
Note 278's noncrossing atom partition has the order
\[
 V_i<P_s<V_{j_1}<\cdots<V_{j_m},
 \qquad m\ge1.                                      \tag{1}
\]
Every other part is vacancy-only. Assume the two links
attaching the group's full target-free internal block
interval to its ordinary endports are retained.
The reflected order with several vacancies left of the
port and one right is included.

**One-sided interior-port theorem.** The full internal
block interval \(D=B_a,\ldots,B_b\) has three
vertex-spanning four-port states:
\[
\begin{array}{ll}
X(D):&a_a\longleftrightarrow b_b,\quad
       o_a\longleftrightarrow e_b;\\
K(D):&a_a\longleftrightarrow o_a,\quad
       e_b\longleftrightarrow b_b;\\
S(D):&o_a\longleftrightarrow e_b.
\end{array}                                               \tag{2}
\]
There is no restriction on \(m\), on vacancy-only parts
inside or around this part, or on the occupancy of
\(B_s,B_{s+1}\) by those other parts. If every other
free group has an ordinary-endport spanning route,
the parent has a Hamilton cycle containing both site
edges and its legal expanded child is Hamiltonian.

**Proof: the prime part.** Write \(u=j_m\). The
matching edges of the part are exactly
\[
 H_iI_u,\qquad I_ie_s,\qquad o_{s+1}H_{j_1},
 \qquad I_{j_t}H_{j_{t+1}}\ (1\le t<m).
                                                            \tag{3}
\]
Old-cycle adjacency forces \(i\le s-1\) and
\(j_1\ge s+2\). Put
\[
 L=B_{i+1},\ldots,B_s,\qquad
 R=B_{s+1},\ldots,B_{j_1-1}.                         \tag{4}
\]
These nonempty intervals are closed under the matching:
a part with one atom in a gap and one beyond it would
interlace (1). They contain no missing ordinary link.
Thus Note 275 gives \(S,K,X\) for both, even if they
contain nested vacancy-only cycles. The gaps between
successive \(V_{j_t}\) are likewise closed; when nonempty
they have the three states of Note 275. Every ordinary
link adjacent to a prime vacancy block is retained,
because \(P_s\) is the only missing link.

For the straight state of the prime block span
\(Q=B_i,\ldots,B_u\), use Note 196's ordinary free
path and replace \(e_so_{s+1}\) by
\[
 e_s,I_i,H_i,I_u,H_u,
 (I_{j_t},H_{j_t})_{t=m-1,m-2,\ldots,1},o_{s+1}.
                                                        \tag{5}
\]
For \(m=1\), the parenthesized descending list is empty.
Every edge in (5) belongs to (3) or is one of the
old-cycle vacancy edges \(H_kI_k\). Use each nonempty
gap's \(S\) state in the ordinary path. This covers
all vertices exactly once and proves \(S(Q)\).

For \(K(Q)\), leave \(e_ub_u\) as the right cap.
The left path is
\[
\begin{split}
a_i,b_i,e_i,I_i,e_s
 &\xrightarrow{X_{\rm bottom}(L)^{-1}}o_{i+1},a_{i+1}
 \xrightarrow{X_{\rm top}(L)}b_s,a_{s+1}\\
 &\xrightarrow{X_{\rm top}(R)}b_{j_1-1},a_{j_1},o_{j_1},
 e_{j_1-1}
 \xrightarrow{X_{\rm bottom}(R)^{-1}}o_{s+1},H_{j_1}\\
 &\xrightarrow{C\text{ forward}}I_u,H_i,o_i.
\end{split}                                               \tag{6}
\]
The first and last non-cycle joins are
\(I_ie_s\) and \(I_uH_i\), and the join from
\(o_{s+1}\) is \(o_{s+1}H_{j_1}\), all from (3).
The old-cycle arc from \(H_{j_1}\) to \(I_u\)
visits every intervening right-side block, including
its nested vacancies, and ends before \(e_u,b_u\).
The two \(X\) rails cover \(L,R\); the displayed
initial and final portions cover all of \(B_i\).
Thus (6) and \(e_ub_u\) are disjoint spanning
paths with the cap pairing.

For \(X(Q)\), take the bottom path
\[
 o_i,H_i,I_u,e_u.                                   \tag{7}
\]
When \(m=1\), Note 283(8) is the required top path.
For \(m\ge2\), let \(p=j_{m-1}\), so \(p<u\).
Begin the top path with
\[
\begin{split}
a_i,b_i,e_i,I_i,e_s
 &\xrightarrow{X_{\rm bottom}(L)^{-1}}o_{i+1},a_{i+1}
 \xrightarrow{X_{\rm top}(L)}b_s\\
 &\xrightarrow{C\text{ forward}}I_p,H_u,o_u,e_{u-1}.
\end{split}                                               \tag{8}
\]
The \(C\)-arc after \(b_s\) covers all of \(R\),
every earlier right-side vacancy block, and all
intervening blocks up to \(I_p\). It leaves only
\(e_p,b_p\) in \(B_p\), the blocks between \(B_p,B_u\),
and \(a_u,o_u,H_u,b_u\) in \(B_u\).
The edge \(I_pH_u\) belongs to (3), and
\(o_ue_{u-1}\) is a retained ordinary link.

If \(u=p+1\), continue from \(e_p\) along
\[
 b_p,a_u,b_u.                                       \tag{9}
\]
If \(u\ge p+2\), the final gap
\(G=B_{p+1},\ldots,B_{u-1}\) has \(X(G)\);
continue instead along
\[
\begin{split}
e_{u-1}&\xrightarrow{X_{\rm bottom}(G)^{-1}}o_{p+1},
 e_p,b_p,a_{p+1}\\
 &\xrightarrow{X_{\rm top}(G)}b_{u-1},a_u,b_u.
\end{split}                                               \tag{10}
\]
The joins \(o_{p+1}e_p\), \(e_pb_p\),
\(b_pa_{p+1}\), and \(b_{u-1}a_u\) are retained
ordinary or old-cycle edges. Equations (8)--(10)
cover the last gap on disjoint \(X\) rails,
then cover \(e_p,b_p\) and finish at \(b_u\).
The bottom path (7) uses exactly \(o_i,H_i,I_u,e_u\);
the top path uses the other four vertices of each
endpoint vacant block and every vertex between them.
Thus the two paths span \(Q\) with the crossed pairing.

**Proof: surrounding parts and flanks.** Every other
part either lies inside one of the closed gaps above,
is serially disjoint from \(Q\), or surrounds \(Q\).
A surrounding vacancy-only part has endpoints in
blocks strictly before \(B_i\) and after \(B_u\);
hence \(Q\) lies in one proper block gap. Note 275's
prime recursion accepts any gap with the three
states (2), and its old-cycle arcs are unaffected
by the missing matching link. Apply that recursion
from inside out and join serial intervals across
retained ordinary links as in Notes 280--281.
This gives (2) for \(D\). Attach \(S(D)\) to
Note 196's free path, compose other groups by
Note 273, and use Notes 001 and 178 for the legal
child and original lobe lengths. Reflection proves
the left-heavy version. \(\square\)

**Unbounded realization.** For \(m\ge1\), take
\(\ell=1,r=m+4\), vacant \(B_1\) and
\(B_5,\ldots,B_r\), and short
\(B_2,B_3,B_4\). Use the site blocks and residual
square of Note 281(8). Keep all standard free links
except \(P_3=e_3o_4\), and add
\[
 H_1I_r,\qquad I_1e_3,\qquad o_4H_5,\qquad
 I_jH_{j+1}\ (5\le j<r).                            \tag{11}
\]
With the site, face, escape, and residual-square edges
of Note 281(9), this is a complementary perfect matching.
All its edges join opposite old-cycle colours. Draw
\(H_1I_r\) as the outer free chord on the side opposite
the designated face; \(I_1e_3\) and the remaining
edges of (11) occupy disjoint or nested inner intervals
alongside the retained standard links. Thus the
embedding is planar and the site edges are cofacial.

The matching-chord interlacement graph is connected.
The retained standard links connect successive face
chords except across \(P_3\); \(I_1e_3\) meets the
face chords of \(B_1,B_3\), \(o_4H_5\) meets those
of \(B_4,B_5\), and the outer edge \(H_1I_r\)
connects the face chords of \(B_1,B_r\).
Every later \(I_jH_{j+1}\) meets its endpoint
face chords. The site/residual-square closing chain
is unchanged. Note 217's cut argument and Note 182's
cubic lemma give three-vertex-connectivity.
This is a Barnette parent on \(6m+30\) vertices;
the theorem gives a marked Hamilton parent cycle and
a legal Hamiltonian child on \(6m+34\) vertices.

The theorem handles any one-sided interior port part,
including the three-vacancy case \(m=2\), and arbitrary
vacancy-only cycles. It does not classify parts with
at least two vacancies on each side of the port,
several missing links in the group, or openings with
target-bearing vacancies, gaps, defective target order,
or nonsquare residual cycles. It does not settle
Barnette's conjecture.
