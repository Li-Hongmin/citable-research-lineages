> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A nonconjugate central/external-spoke expansion tree

Note 009 proves that the two reflected markings of the recurrent central
site give only one unlabelled graph at each depth.  A genuinely different
branch is obtained by allowing two geometrically and algebraically
nonconjugate successor sites after every \(C_4\)-expansion.

Let the current oriented site be

\[
p=uv,\qquad q=xy,
\]

and let its expansion introduce \(a,b,c,d\) and the edges

\[
ua,ab,bv,xc,cd,dy,ad,bc.
\tag{1}
\]

The two successor choices are

\[
\mathrm{CEN}=(bc,da),\qquad
\mathrm{UV}=(ua,bv).
\tag{2}
\]

CEN consists of opposite edges of the new central 4-face.  UV consists of
the two new spokes on the face obtained by replacing \(uv\) with
\(u-a-b-v\).  In both cases the selected edges are vertex-disjoint and the
oriented initial vertices have the same bipartition colour.  Hence both are
legal Barnette expansion sites, and the class-preservation statement of
Note 006 applies recursively.

## The six-role transfer relations

Split the cycle role \(A=C_{11}\) according to the pairing obtained after
deleting the two site edges:

\[
A_0:(uy)(vx),\qquad A_1:(ux)(vy).
\]

Together with

\[
B=C_{10},\qquad C=C_{01},\qquad
D=X_{vx},\qquad E=X_{uy},
\]

these form a complete six-role local interface.  Contracting each external
spanning path or two-path linkage to a subdivided skeleton preserves all
terminal degrees and component pairings relevant to the expansion.  Testing
the \(2^8\) subsets of the gadget edges in (1), including connectivity, gives
the following memberwise transfer relations:

\[
\begin{array}{c|llllll}
 &A_0^+&A_1^+&B^+&C^+&D^+&E^+\\ \hline
\mathrm{CEN}
 &B\vee C&A_1&E&D&A_0\vee A_1&A_0\vee A_1\\
\mathrm{UV}
 &A_0\vee A_1\vee B&A_1&E&D&C&A_0\vee A_1.
\end{array}
\tag{3}
\]

Here a disjunction denotes the union of the concrete output families
obtained independently from every witness in the listed source families.
Every construction retains every old witness edge other than the two edges
deleted at the new site.

Regard each row of (3) as a bipartite relation from the six source roles to
the six target roles.  The target-indegree multisets are

\[
\{1,1,1,2,2,2\}\quad\text{for CEN},
\qquad
\{1,1,1,1,2,3\}\quad\text{for UV}.
\tag{4}
\]

They differ, so the two relations are not conjugate even under independent
permutations of all source and target roles.  In particular, they cannot be
identified by a relabelling of the four-terminal interface.

Every source-role column in each relation is nonzero.  Therefore the image
of every nonempty support state is nonempty under either map.  The greatest
common nonempty robust domain for the support of one retained edge is thus

\[
\boxed{
2^{\{A_0,A_1,B,C,D,E\}}\setminus\{\varnothing\}
},
\tag{5}
\]

consisting of all 63 nonempty states.

## The explicit stable n240 state

Use the order-240 graph and initial site of Note 008.  Its graph6 SHA256 is

`1a45291660df221ace79b053604bae1256f74cb6e413ab76ba2b8c2d50ce308b`,

and

\[
(u,v,x,y)=(48,51,112,97).
\]

Among the eight selected witnesses of Note 008, cycles
\(3,31,32,35\) all have pairing \(A_0\), cycle \(7\) has role \(B\),
cycle \(4\) has role \(C\), and the two spanning paths have roles \(D,E\).
Thus the available-role state is

\[
V_0=\{A_0,B,C,D,E\}.
\tag{6}
\]

Both transfer relations fix this state:

\[
M_{\mathrm{CEN}}(V_0)
=M_{\mathrm{UV}}(V_0)
=V_0.
\tag{7}
\]

The six cycles and two paths cover all 358 edges retained from the root
site.  By (5), the support of each such edge remains nonempty under every
word in the two maps.  For the eight gadget edges in the order used in
(1), the output-interface supports obtained from \(V_0\) are

\[
\begin{array}{c|cccccccc}
 &ua&ab&bv&xc&cd&dy&ad&bc\\ \hline
\mathrm{CEN}
 &A_0BDE&A_0BCD&A_0CDE&A_0CDE&A_0BCE&A_0BDE&A_0C&A_0B\\
\mathrm{UV}
 &A_0B&A_0BCE&A_0C&A_0CDE&A_0BC&A_0BDE&A_0CDE&A_0BDE.
\end{array}
\tag{8}
\]

In particular, every gadget edge retained by the successor site again lies
in an interface witness.  Moreover, the current families \(A_0,B\) provide
the traversal pair \(D_{11},D_{10}\), which covers all eight edges of the
next installed gadget by the exact criterion of Note 002.

It follows inductively that, starting from the marked n240 site and choosing
CEN or UV independently after every expansion, every construction-history
node is an edge-Hamiltonian Barnette graph and again has the stable
availability state \(V_0\) with a witness cover of every edge retained by
its marked site.  The root itself is edge-Hamiltonian by the stored
37-cycle edge cover; the induction supplies all positive-depth nodes.

This conclusion holds for every word in

\[
\{\mathrm{CEN},\mathrm{UV}\}^*.
\tag{9}
\]

It is a statement about edge-Hamiltonicity and recurrent witness support,
not yet a general enumeration of the unlabelled graphs represented by those
words.

## Unlabelled classification through depth five

Encode CEN by \(0\) and UV by \(1\).  A letter records the successor site
carried after the current expansion, so histories may agree as unlabelled
graphs even when their final site markings differ.  Nauty canonicalization
of all histories through depth five gives

\[
\begin{array}{c|c|c|c}
\text{depth}&\text{order}&\text{histories}&
\text{unlabelled isomorphism classes}\\ \hline
0&240&1&1\\
1&244&2&1\\
2&248&4&1\\
3&252&8&2\\
4&256&16&4\\
5&260&32&8.
\end{array}
\tag{10}
\]

Thus the CEN/UV construction produces a genuine unlabelled branch: two
nonisomorphic descendants already occur at order 252.  Equation (10) is an
exact finite classification only for depths \(0\leq k\leq5\).  Although its
class counts agree with \(2^{k-2}\) for \(3\leq k\leq5\), no such formula is
asserted for general \(k\).

## Adjacent mixed sites and certificate

The five faces incident with the first n240 gadget contain 46 legal sites:
six select two gadget edges, 22 select one gadget edge and one old edge, and
18 select two old edges.  Each of the 22 mixed sites has a one-step retained-
edge cover and next-gadget cover using the same stored n240 witnesses.
However, these are certificate-specific one-step closures, not recurrent
local maps: occurrence and cut position of the selected old edge are not
determined by the six-role label.  No recursive theorem for those 22 sites
is claimed.

The complete local enumeration, the n240 witness check and the depth-five
canonical graph6 classes are stored in
`../scratch/worker-barnette/n240-noncentral-local-branch.json`.  The verifier
is `../scratch/worker-barnette/analyze_noncentral_c4_branch_maps.py` and ends
with `BARNETTE_NONCENTRAL_LOCAL_BRANCH_VERIFIED`.  It uses the existing
witness sequences and finite gadget-state algebra; it invokes no Hamilton
solver or Hamilton-witness search.
