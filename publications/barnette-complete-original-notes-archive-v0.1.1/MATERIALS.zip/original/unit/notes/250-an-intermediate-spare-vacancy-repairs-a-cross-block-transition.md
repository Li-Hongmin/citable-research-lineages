> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An intermediate spare vacancy repairs a cross-block transition

[Note 249](249-every-same-block-single-transition-defect-is-hamiltonian-at-second-surplus.md)
closes the same-block single-transition branch at the gapless
second surplus. A cross-block transition has two free boundary
pairs. If its spare vacancy lies in a strictly intermediate
face block, the matching is the endpoint-defect dichotomy of
[Note 245](245-a-delayed-endpoint-composes-with-an-earlier-vacancy.md)
inside that closed free group: either a direct five-edge target
detour or a rainbow detour of the ordinary free path.

Let \(G,C,M\) be a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps, and \(s=2\), so
\(f=4r+6\). Assume \(d_L=d_R=0,b=1\), and let the sole
defective transition be \(L_j,R_{j-1}\), \(2\le j\le\ell\),
with \(L_j\in B_i\), \(R_{j-1}\in B_h\), \(i<h\). Suppose
one vacancy lies in a strictly intermediate face block
\(B_k\), \(i<k<h\). The other is the vacancy required by
the defective transition.

**Intermediate-spare theorem.** The source \(L_j\) is the last
eligible even position of \(B_i\), followed by free slots
\(c_i,e_i\). The destination \(R_{j-1}\) is the third
interior slot of \(B_h\), preceded by free slots \(o_h,w\).
The spare block \(B_k\) is target-free with interiors
\(o_k,H,I,e_k\), and every other strictly intermediate block
is short. For some index \(t\), the complete free matching is
exactly one of
\[
\begin{array}{ll}
\text{direct:}&
\{c_iH,Iw\}\cup\{e_a o_{a+1}:0\le a\le r\},\\[2mm]
\text{rainbow:}&
\{c_iw,e_{t-1}I,Ho_t\}
\cup\{e_a o_{a+1}:0\le a\le r,\ a\ne t-1\},
\end{array}                                             \tag{1}
\]
where the rainbow index satisfies
\[
t\in\{i+1,\ldots,k-1\}\cup\{k+2,\ldots,h\}.
                                                        \tag{2}
\]
Empty ranges contribute no rainbow matching. In either form,
the parent has a Hamilton cycle containing both site edges
\(xy,uv\), and its legal site-expanded child is Hamiltonian.
The conclusion holds for arbitrary positive original lobe
lengths.

**Placement and barriers.** If \(R_{j-1}\) were the first
interior slot of \(B_h\), take the main old-cycle prefix
through \(B_{h-1}\) together with residual squares
\(S_j,\ldots,S_\ell\). Every fixed matching chord is internal.
A free chord leaving it would straddle \(R_{j-1}\) and join
different blocks, contrary to [Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md).
The set would have only two outgoing old-cycle edges, contrary
to three-connectivity. Thus \(R_{j-1}\) is not first. It needs
an eligible vacancy before it. Since the spare in \(B_k\)
uses the other vacancy, \(R_{j-1}\) is third. No eligible
position may follow \(L_j\) in \(B_i\), or occur in another
intermediate block; each would be a third vacancy, as no
target lies between \(L_j,R_{j-1}\). This proves the claimed
block shapes.

Before either defective target, the free-slot prefix is even.
No cross-block chord can straddle that target. At \(L_j\),
only the first free slot of its block could begin a same-block
crossing chord; at \(R_{j-1}\), only its final free slot could
end one. Parity excludes both single chords. The free group
between these targets is therefore closed under \(M\), with
slot order
\[
c_i,e_i,o_{i+1},e_{i+1},\ldots,
o_k,H,I,e_k,\ldots,o_h,w.                       \tag{3}
\]
All cross-block matching chords in (3) lie opposite the site
face and are noncrossing by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).

The only possible non-cycle chord within one block of (3) is
\(o_ke_k\). It cannot occur. If it did, \(H\) would have to
match an odd slot before or after \(B_k\), since \(HI\in E(C)\).
For a mate before \(B_k\), the still-unmatched slots inside
that cross-block chord are the final even slot of its mate's
block, complete short-block pairs, and \(o_k\) (already paired
to \(e_k\)); after deleting \(o_k,e_k\), their number is odd.
For a mate after \(B_k\), the chord encloses \(I\) and complete
short-block pairs, with \(e_k\) already used, again an odd
number. Every remaining interior edge would be a cross-block
chord on the same side of \(C\), so none could leave without
interlacing the chosen chord. Both possibilities contradict a
perfect matching. Consequently every free chord in (3) joins
different blocks and belongs to one noncrossing disk.

**First-slot dichotomy.** The first slot \(c_i\) cannot match
\(e_i\), its old-cycle neighbour, or a free slot after
\(R_{j-1}\), by the target barrier. If it matched any final
slot \(e_a\) with \(i<a<h\), the intervening free slots would
be trapped inside this cross-block chord. Noncrossing and the
absence of any remaining same-block free chord would close
the complete main prefix through \(B_a\), together with
\(S_j,\ldots,S_\ell\), under the complementary matching.
It would have only two outgoing old-cycle edges, contrary to
three-connectivity. Thus \(c_i\) matches either \(H\) or \(w\).

If \(c_iH\in M\), the free slots inside that chord follow
the ordinary links \(e_a o_{a+1}\), \(i\le a<k\), by the
short-block skipping rule of [Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md).
The next unmatched odd slot is \(I\). A mate before \(H\)
would interlace \(c_iH\), and \(Ie_k\) is an old-cycle edge.
If \(I\) matched \(e_a\) with \(k<a<h-1\), the complete
main prefix through \(B_a\) would be matching-closed, another
two-edge cut. Matching \(e_{h-1}\) would strand the adjacent
pair \(o_h,w\). Therefore \(Iw\in M\), and the remaining
ordinary slots take standard links. This is the direct line
of (1).

If \(c_iw\in M\), every remaining slot in (3) lies inside
that opposite-side chord. The group from \(e_i\) to \(o_h\)
is exactly the local target-free single-vacancy group (4)
of [Note 209](209-every-tight-gapless-internal-vacancy-at-first-surplus-is-hamiltonian.md),
with its left and right block indices \(i,h\). Its proof uses
only the already established noncrossing disk, old-cycle
adjacency and two-edge-cut skipping rule. It forces one
missing standard link and the two chords \(e_{t-1}I,Ho_t\),
with precisely the range (2). All ordinary groups outside
(3) use standard links. This is the rainbow line of (1).

**Marked Hamilton routes.** Start with the two paths of
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md).
In the direct form, replace the missing target transition by
\[
L_j,c_i,H,I,w,R_{j-1}.                         \tag{4}
\]
The first, middle and last edges are old-cycle edges, and the
other two are matching edges. The ordinary free path is
unchanged. In the rainbow form, replace the target transition
by \(L_j,c_i,w,R_{j-1}\), and replace its free-path link
\(e_{t-1}o_t\) by
\[
e_{t-1},I,H,o_t.                               \tag{5}
\]
All displayed joins are edges; the two paths are internally
disjoint and cover every parent vertex in either form. Their
union is a Hamilton cycle through \(xy,uv\). [Notes 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
and [178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
give the legal child and longer lobes. \(\square\)

**A 26-vertex direct realization.** Take
\(r=1,\ell=2,i=0,k=1,h=2,j=2\). The old cycle has blocks
\[
\begin{array}{ll}
B_0:&x,R_2,L_2,c_0,e_0,y,\\
B_1:&a_1,o_1,H,I,e_1,b_1,\\
B_2:&u,o_2,w,R_1,L_1,v,\\
S_1,S_2:&\alpha_t,\gamma_t,\delta_t,\beta_t
\quad(t=1,2),\text{ returning to }x.
\end{array}                                             \tag{6}
\]
Its complementary matching consists of the site and face
chords \(xy,a_1b_1,uv\), square and escape chords
\(\alpha_t\beta_t,R_t\delta_t,L_t\gamma_t\)
for \(t=1,2\), and the free chords
\(c_0H,Iw,e_0o_1,e_1o_2\). The marked Hamilton cycle is the
union of
\[
\begin{split}
&x,R_2,\delta_2,\beta_2,\alpha_2,\gamma_2,L_2,
c_0,H,I,w,R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v,\\
&x,y,e_0,o_1,a_1,b_1,e_1,o_2,u,v.
\end{split}                                             \tag{7}
\]
These paths meet only at \(x,v\), cover all 26 vertices and
contain both site edges. Every matching pair has opposite
old-cycle parity, and \(x,u\) have the same parity. On the
site-face side of \(C\), place the disjoint site, face and
\(\alpha_t\beta_t\) chords. On the other side,
\(R_2\delta_2\) contains \(L_2\gamma_2\), which has three
disjoint branches
\(c_0H\supset e_0o_1\), \(Iw\supset e_1o_2\), and
\(R_1\delta_1\supset L_1\gamma_1\).
This is a simple cubic bipartite plane graph with cofacial
site edges. Its matching-chord interlacement graph is connected:
\[
xy-c_0H-a_1b_1-Iw-uv-L_1\gamma_1-
\alpha_1\beta_1-R_1\delta_1,
\tag{8}
\]
while \(e_0o_1\) interlaces \(xy\), \(e_1o_2\) interlaces
\(a_1b_1\), and the remaining chords attach through
\(xy-L_2\gamma_2-\alpha_2\beta_2-R_2\delta_2\).
[Note 217](217-vacancy-squares-absorb-across-arbitrarily-long-short-block-ladders.md)
therefore proves three-connectivity of this parent and its
30-vertex legal site expansion. The paths (7) and Note 001
give their Hamilton cycles.

The theorem covers a spare vacancy in a strictly intermediate
face block of a cross-block transition. Vacancies in its source
or destination block, other outside groups, interblock gaps,
nonsquare residual cycles and Barnette's conjecture remain
undecided here.
