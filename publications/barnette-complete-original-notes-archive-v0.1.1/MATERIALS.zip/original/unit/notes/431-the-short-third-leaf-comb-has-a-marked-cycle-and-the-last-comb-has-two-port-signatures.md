> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The short-third-leaf comb has a marked cycle; the last comb has two port signatures

[Note 427](427-the-first-five-leaf-matching-reduces-to-six-short-wrapper-words.md) leaves two row-I comb words with sites $(j,k)=(1,2)$. Both share the outer shape
\[
 W=F(U_1,T),\qquad T=F(L,U_7),\qquad L=F(U_2,R),       \tag{1}
\]
where $F(P,Q)=(((P Q)))$ and $U_1,U_2,U_7$ are full six-vertex leaves. The two possibilities for the 40-vertex word $R$ are
\[
\begin{array}{ll}
\text{short leaf 6:}&K=F(U_4,U_5),\ S=F(K,U_6^{\rm short}),\ R=F(U_3,S),\\
\text{short leaf 3:}&K=F(U_4,U_5),\ S=F(U_3^{\rm short},K),\ R=F(S,U_6).
\end{array}                                                     \tag{2}
\]
Their depth vectors are respectively $(1,3,4,6,6,5,2)$ and $(1,3,5,6,6,4,2)$. In each word matching I supplies $x_5y_7$ and $y_6x_7$ across the $L\mid U_7$ cut, while $x_3y_4,y_3x_4,y_5x_6$ lie inside $R$.

Write $P_T,Q_T,R_T$ for the bracket-only paths of [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md), equation (2), and $Y_i,X_i$ for its full-leaf paths. Two further six-bracket paths are
\[
 H_T=(\lambda_0^T,\lambda_1^T,\lambda_2^T,
          \rho_2^T,\rho_1^T,\rho_0^T),\qquad
 J_T=(\lambda_0^T,\rho_0^T,\rho_1^T,
          \lambda_1^T,\lambda_2^T,\rho_2^T).             \tag{3}
\]
All consecutive pairs in (3) are old-cycle edges or bracket matching chords.

**Outer-port theorem.** For either word (2), a spanning $y_1$--$x_2$ path of $W$ exists if and only if at least one of the following two signatures exists inside $R$:

1. a spanning $x_5$--$R_\ell$ path;
2. two vertex-disjoint paths covering $R$, paired $(R_r,y_6)$ and $(x_5,R_\ell)$.

In every such $W$ path the face edge $x_5y_7$ is used. Signature 1 uses the old edge $L_rL_7$ and does not need $y_6x_7$; signature 2 uses $y_6x_7$ and does not need $L_rL_7$.

**Proof of necessity.** Work inside $W$; exterior edges at $x_1,y_2,y_7$ are unavailable. The full leaf $U_1$ has the path endpoint $y_1$ and only its two old-cycle boundary edges. A spanning $y_1$--$R_1$ path inside that six-vertex leaf is excluded by bipartite parity, so it exits at $L_1$ and is $Y_1$. Similarly $U_2$ exits at $R_2$ and is traversed by $X_2$ read from $R_2$ to $x_2$. The root bracket vertices of $W$ therefore form $P_W$, entering $T$ at $T_r$; $T_\ell$ has no usable edge to $U_1$.

Across the $L\mid(T-L)$ boundary, the only possible edges are
\[
 e_1=L_\ell\lambda_2^T,quad e_2=L_rL_7,quad
 e_3=x_5y_7,quad e_4=y_6x_7.                       \tag{4}
\]
The path starts outside $L$ and ends at $x_2\in L$, so it uses one or three edges in (4). Here $|L|=52$ and, indexing $w_0$ by zero as in Note 416, $x_2,L_r,y_6$ have even indices while $x_5$ has odd index in both words. A single crossing at $e_1$ leaves $U_7$ disconnected; at $e_2$ it would demand an impossible spanning $L_r$--$x_2$ path of $L$; at $e_3$ it would demand an impossible spanning $y_7$--$R_7$ path of $U_7$; at $e_4$ it would demand an impossible spanning $y_6$--$x_2$ path of $L$. Thus three crossings occur.

If $e_1$ were omitted, all $e_2,e_3,e_4$ would be used. The only remaining attachment of the six $T$-bracket vertices to the word is then $R_7\rho_2^T$; they would require a spanning bracket-only path from $T_r=\rho_0^T$ to $\rho_2^T$. Those two bracket vertices have the same colour, so no such six-vertex path exists. Hence $e_1$ is used. Exactly two of $e_2,e_3,e_4$ are then used, and $R_7\rho_2^T$ is unused because $U_7$ has no path endpoint. The $T$ brackets form $Q_T$ from $T_r$ to $\lambda_2^T$. Pair $e_2,e_4$ would require a spanning $L_7$--$x_7$ path of $U_7$, again excluded by parity. The only possibilities are $e_2,e_3$ and $e_3,e_4$, proving that $x_5y_7$ is forced.

If $e_2,e_3$ are used, $U_7$ has a spanning $L_7$--$y_7$ path. The end leaf $U_2$ uses $R_2R_\ell$. In $R$, the only remaining boundary edges are $x_5y_7$, $R_\ell R_2$, and $R_r\rho_2^L$; parity of boundary crossings forces the last to be absent. Thus $R$ supplies signature 1, and the six $L$ brackets form a path $H_L$ from $L_\ell$ to $L_r$.

If $e_3,e_4$ are used, $U_7$ has a spanning $x_7$--$y_7$ path. The $L$ brackets now attach only at $L_\ell$ and $R_r$, and form $J_L$. The four ports of $R$, in plane boundary order, are $R_\ell,x_5,y_6,R_r$. A two-path cover cannot use the crossing pairing $(R_\ell,y_6),(x_5,R_r)$. The pairing $(R_\ell,R_r),(x_5,y_6)$ would close the $U_7$ excursion as a separate cycle. Hence a spanning $W$ path requires precisely signature 2. This completes necessity.

**Proof of sufficiency.** In both cases begin with $Y_1,P_W,Q_T$. For signature 1, continue with
\[
 L_\ell\xrightarrow{H_L}L_r, L_7\xrightarrow{Y_7^{-1}}y_7,
 x_5\xrightarrow{R\text{-path}}R_\ell,
 R_2\xrightarrow{X_2}x_2.                              \tag{5}
\]
The jump $y_7x_5$ is $e_3$ and $L_rL_7$ is $e_2$. For signature 2, continue instead with
\[
 L_\ell\xrightarrow{J_L}R_r,
 \xrightarrow{R_r\text{--}y_6}y_6,
 x_7,h_7,L_7,R_7,j_7,y_7,
 x_5\xrightarrow{x_5\text{--}R_\ell}R_\ell,
 R_2\xrightarrow{X_2}x_2.                              \tag{6}
\]
The jumps at $y_6x_7$ and $y_7x_5$ are $e_4,e_3$. Each displayed route uses all vertices of each leaf, bracket group and $R$ once; the interfaces not named as face edges are consecutive old-cycle edges. This proves both directions. \(\square\)

**Short-third-leaf comb theorem.** The second word of (2), with short leaf 3, has signature 1. Indeed $S=F(U_3^{\rm short},F(U_4,U_5))$ is a consecutive ordinary word with outer chord $S_\ell S_r$ and consecutive old-cycle vertices $x_5,y_5$. Delete the edge $x_5y_5$ from the cycle consisting of $S$'s complete old-cycle path plus $S_\ell S_r$. The result is the spanning path
\[
 Z_S=(x_5\xrightarrow{\text{old cycle backwards}}S_\ell,
       S_r\xrightarrow{\text{old cycle backwards}}y_5).  \tag{7}
\]
Since $R=F(S,U_6)$, the following spans $R$:
\[
 x_5\xrightarrow{Z_S}y_5,
 x_6\xrightarrow{X_6^{-1}}R_6,
 \rho_2^R\xrightarrow{R_R}\lambda_0^R=R_\ell.         \tag{8}
\]
The only non-ordinary jump in (8) is the available face chord $y_5x_6$; $R_6\rho_2^R$ is an old-cycle edge. The pieces cover $|S|+6+6=40$ vertices exactly once. Substitution in (5) gives a spanning $y_1$--$x_2$ path of all $76$ vertices of $W$, using only $x_5y_7$ and $y_5x_6$ among face chords. For every legal completion, Note 424's fixed outside route closes it to a parent Hamilton cycle through both site edges, and [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts that cycle to the child. \(\square\)

Thus five of Note 427's six necessary row-I words are Hamiltonian in every legal completion. The remaining short-sixth-leaf comb has exactly the two local port tests above; their truth is not asserted here. Matching I, its reflection II, and Barnette's conjecture are not yet settled.
