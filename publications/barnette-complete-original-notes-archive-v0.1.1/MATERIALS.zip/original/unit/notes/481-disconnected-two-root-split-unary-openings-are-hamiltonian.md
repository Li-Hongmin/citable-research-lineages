> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Disconnected two-root split-unary openings are Hamiltonian

[Note 480](480-adjacent-unary-two-root-chord-free-openings-are-hamiltonian.md) closes the adjacent direct-special pair in the two-root chord-free profile of [Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md). When the pair straddles the marked unary node's child, the root-cycle openings of [Notes 461](461-disconnected-root-face-matchings-close-the-split-unary-kernel.md) and [473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md) give a two-terminal path containing the root chord. Removing that chord supplies the four-port cover needed for the split-site exterior paths of Note 480.

Use the two-root chord-free single-hexagon setup of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md), with site edges \(q=w_0u,p=vw_*\), two exposed special positions \(z_1,z_2\), and root face graph \(K\). All root-assigned special positions except \(s,t\) occur in two-special leaves. The two exceptional positions belong directly to one marked unary node \(N\) in the order
\[
                             H,s,A,t,J,
\tag{1}
\]
where \(A\) is its only child word. Ordinary wrappers are unrestricted.

**Disconnected-root theorem.** If \(K\) is disconnected, the parent has a Hamilton cycle containing both site edges, unless the child is already Hamiltonian by the adjacent-escape or one-edge facial-gap switch. In particular, every legal expanded child in this split-unary profile with disconnected \(K\) is Hamiltonian.

**Root-chord path lemma.** Let \(W\) be one ordinary root with exactly two externally matched special positions \(x,y\), while the face matching \(M_W\) of every other assigned special position stays inside \(W\). Suppose \(N\subseteq W\) has the split order (1), and all other assigned positions of \(W\) occur in two-special leaves. Then \(W\) has a spanning \(x\)--\(y\) path containing its root chord \(e_W\).

To prove the lemma, close the old \(W\)-arc by \(e_W\) to form \(C_W\). Let \(L,R\) be the first and last vertices of \(A\), joined by an ordinary chord \(LR\), and let \(E_W\) contain the square-supported adjacent-special old edge of each two-special leaf. Define
\[
 F_{\rm in}=(C_W-E_W-\{sL,Rt\})\cup M_W\cup\{LR\}.
\tag{2}
\]
It has degree one precisely at \(x,y\). If some \(M_W\)-edge crosses between \(A\) and \(W\setminus A\), then \(F_{\rm in}\cup E_W\) is connected: deleting \(sL,Rt\) from \(C_W\) separates exactly the child arc from its complementary arc, and the crossing edge rejoins them. Leaf-square switches along a quotient spanning tree absorb every cycle into the \(x\)--\(y\) path. If \(A\) is itself a two-special leaf, its square edge is a quotient loop because \(LR\) is already in \(F_{\rm in}\), so that square is not switched.

If no \(M_W\)-edge crosses \(A\), the cut of the even-order child interval has the two old boundary edges plus whichever of the two external attachment edges end in \(A\). Cubicity makes this cut even and three-connectivity makes it at least four, so both \(x,y\) lie in \(A\). The special positions \(s,t\) are therefore matched by \(M_W\) outside \(A\). They cannot be matched to each other by the no-self-pairing theorem of [Note 473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md). Hence one of their matching edges ends outside the entire node interval \([H,J]\), and \(N\) is not the root of \(W\). Use the alternative opening
\[
 F_{\rm out}=(C_W-E_W-\{Hs,tJ\})\cup M_W\cup\{HJ\}.
\tag{3}
\]
That matching edge rejoins the two arcs separated by \(Hs,tJ\), so \(F_{\rm out}\cup E_W\) is connected. Leaf-square switches again give a spanning \(x\)--\(y\) path. In both openings the root chord \(e_W\) is present initially. Every switched square lies wholly on the old root arc and replaces only its two old edges incident with the leaf specials; hence it cannot remove \(e_W\). In the second opening \(N\) is not the root, so \(HJ\ne e_W\). This proves the lemma. \(\square\)

Now assume the child is not already Hamiltonian by one of the direct switches. The order and cut argument of Note 458 makes both \(z_i\) face-chord endpoints and gives each root exactly two special attachments. In its orders A and C, both site ports lie in one end root \(W\), as proved in Note 480. The same holds in order B when the site ports are not split between roots. Every face matching edge of \(W\) is internal. If \(N\subset W\), the root-chord path lemma gives a spanning \(u\)--\(v\) path; if \(N\) lies in the other root, Note 458's two-terminal leaf-square splice gives one. The exterior spanning \(w_0\)--\(w_*\) paths (1)–(2) of Note 480 and their reflections close a parent Hamilton cycle through \(q,p\).

It remains to treat order B with \(u\in W_1,v\in W_2\). Noncrossing and the two-attachment cut put the mate \(r_1\) of \(z_1\) in \(W_1\) after \(u\), and the mate \(r_2\) of \(z_2\) in \(W_2\) before \(v\), as in Note 480. Let \(W\) be the root containing \(N\). Its two external special positions are its site port and its \(z_i\)-mate. The root-chord path lemma gives a spanning path between them containing \(e_W\); deleting \(e_W\) yields a spanning two-path cover with terminals the two special positions and the two boundary vertices of \(W\).

Suppose \(W=W_1\). Since deleting an edge of an \(u\)--\(r_1\) path separates its terminals, the resulting internal pairing is either
\[
 (W_{1,\ell},u)(W_{1,r},r_1)
 \quad\text{or}\quad
 (W_{1,\ell},r_1)(W_{1,r},u).
\tag{4}
\]
For the first pairing use the four exterior paths (4) of Note 480; for the second use the B-row exterior paths (5) of Note 458. Directly joining the chosen exterior cover to the \(W_1\) cover leaves, in either case, two paths at the all-leaf root \(W_2\) with pairing \((W_{2,\ell},r_2)(v,W_{2,r})\). Note 458 gives two distinct spanning internal pairings in \(W_2\); one differs and closes a single parent Hamilton cycle.

If \(W=W_2\), the two possible internal pairings are \((W_{2,\ell},r_2)(W_{2,r},v)\) and \((W_{2,\ell},v)(W_{2,r},r_2)\). For the first, use the reflection of Note 480's four exterior paths (4), whose endpoint pairs are \((v,W_{1,r}),(W_{2,r},W_{2,\ell}),(u,W_{1,\ell}),(r_2,r_1)\). For the second, use the B-row paths (5) of Note 458. Either choice leaves the pairing \((W_{1,\ell},u)(W_{1,r},r_1)\) at the all-leaf root \(W_1\), where a different available internal pairing closes a single cycle. The chosen exterior paths cover all vertices outside the roots and contain both site edges. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts every marked parent cycle to the legal child. \(\square\)

**Equality consequence.** Combining this theorem with Note 480, a non-Hamiltonian chord-free \(m=f,R=2,c=5f-8\) child must have the split marked unary pair and a connected root face graph \(K\). The theorem does not determine whether that remaining profile is realizable or Hamiltonian, and it does not settle Barnette's conjecture.
