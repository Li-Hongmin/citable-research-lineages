> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One other vacancy forces the staggered J1 square patch

[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
identifies a fourteen-vertex four-pole with the exact square
Hamilton signature. [Note 328](328-no-short-corridor-between-a-single-vacancy-and-a-j1-double-block.md)
excludes short blocks between its two vacant blocks when the
free group has no flanks. The same obstruction holds with
arbitrarily long short-block flanks. In fact, the distinguished
four-pole is forced without classifying the exterior matching.

Let a Barnette parent have the compressed, gapless, tight-target
all-square opening of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix a free group with ordinary even left and odd right endports.
Its complete face blocks include exactly one singly vacant
target-free block
\[
                       V=(a,o,h,i,e,b)
\]
and exactly one doubly vacant target-free block
\[
                       D=(A,O,H,I,K,J,E,B).
\]
Every other complete block of this group is a short target-free
square \((a_j,o_j,e_j,b_j)\). Any number of these short blocks
may precede, separate, or follow \(V,D\). No assumption is made
about other free groups. Suppose the complementary matching
\(M\) contains the internal chord \(OK=J_1=oh_2\) of \(D\).

**All-flank J1 reduction theorem.** The block \(V\) immediately
precedes \(D\), and the four internal free matching edges of
their induced two-block patch are precisely
\[
                       oe,\quad hI,\quad iH,\quad OK.
                                                               \tag{1}
\]
Their two face-closing matching edges are \(ab,AB\), and
the interblock old-cycle edge is \(bA\). Thus the induced
four-terminal patch is exactly the square-equivalent \(P\)
of Note 327, with attachments at \(a,J,E,B\), regardless of
all flank lengths and matching choices outside the patch.
Replacing \(P\) by its square preserves Barnette membership
and every exterior-marked Hamilton decision in both directions.
Consequently a vertex-minimal non-Hamiltonian Barnette graph
cannot have this opening. If all vacancies outside this group
lie in distinct internal blocks, the parent has a Hamilton
cycle through both site edges, and its legal site-expanded
child is Hamiltonian. Old-cycle reflection gives the same
statements for \(J_3=i_1e\), with \(D\) immediately before
\(V\).

**Proof.** By Note 327's chord-isolation lemma, \(OK\) lies
on the common-face side and no other internal free chord
of \(D\) occurs. The only possible internal free chord of
\(V\) is \(oe\); if present, it also lies on that side.
Every cross-block free chord lies in the opposite-side disk
by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
For such a chord, all free slots strictly between its ends,
after removing endpoints of face-side chords that leave the
interval, must match inside. In particular, an even number
must remain. If a proper consecutive interval of complete
face blocks has all matching edges internal, only its two
boundary old-cycle edges leave it, contradicting
three-connectivity. We use these parity and cut rules below.

First suppose \(V\) precedes \(D\), with \(k\ge0\) short
blocks between them. The even slot \(H\) has no mate in
\(D\): \(O,K\) are used by \(OK\), \(I\) is an old-cycle
neighbor, \(HJ\) is excluded, and \(E\) has the same colour.
It cannot match an ordinary odd slot of a short block
before \(D\). If that slot is before \(H\), its chord
encloses its own block's final even slot, some complete
blocks with even numbers of free slots, and \(O\). Thus
the interior count is even, whereas \(OK\) supplies exactly
one face-side exit. The possible \(oe\) lies wholly inside
or outside this interval. If the ordinary odd slot is
after \(D\), its chord from \(H\) encloses \(I,K,J,E\)
and complete short blocks, again an even number of slots
with the single exit \(OK\). The same argument applies to
the right ordinary endport. The left endport has even colour
and cannot match \(H\).

The remaining odd candidates are \(o,i\) of \(V\).
The chord \(oH\) encloses \(h,i,e\), the \(2k\) intervening
short slots, and \(O\). Its even interior has one exit
\(OK\); \(oe\) is unavailable because \(o\) is used.
Hence \(iH\in M\). It encloses \(e\), the \(2k\) short
slots, and \(O\). The exit \(OK\) makes the parity odd
unless \(oe\in M\), whose \(e\)-end is a second face-side
exit. With both face-side chords fixed, every intervening
short slot must match another such slot: the other two
free slots inside \(iH\), namely \(e,O\), have already
been matched across its boundary, and another opposite-side
edge cannot cross \(iH\). If \(k>0\), the whole short-block
interval is matching-closed and gives a two-edge cut.
Therefore \(k=0\) and \(oe,iH\in M\).

The odd slot \(I\) cannot match a left ordinary even slot,
including the group's left endport: that chord encloses
complete short blocks, all four free slots of \(V\), and
\(O,H\). The interior count is even; \(OK\) is its sole
face-side exit because both ends of \(oe\) lie inside.
It cannot match a right short-block final even slot:
the chord encloses \(K,J,E\), complete short blocks,
and the first odd slot of its endpoint block, again an
even number with one exit \(OK\). Within \(D\), the
edges \(IH,IK\) belong to the old cycle and \(IE\) is
excluded by chord isolation. The vertex \(e\) of \(V\)
is used by \(oe\). Its only remaining even mate is
\(h\), so \(hI\in M\). This proves (1). All other
vertices of the two-block induced patch have internal
degree three; \(a,J,E,B\) have one exterior edge each.
Note 327 gives the exact square replacement.

Suppose instead that \(D\) precedes \(V\), again with
\(k\ge0\) short blocks between them. An ordinary odd
short-block slot before \(D\) cannot match \(H\): the
chord encloses its final even slot, complete short blocks,
and \(O\), with exactly one exit \(OK\). For an ordinary
odd short-block slot after \(D\), the chord from \(H\)
encloses \(I,K,J,E\), complete short blocks, and, if the
slot follows \(V\), all four free slots of \(V\).
Again the count is even and \(OK\) is the only exit;
\(oe\), when present, has both ends inside or outside.
The right endport obeys the same count. The chord \(Ho\)
to \(V\)'s ordinary first slot encloses \(I,K,J,E\)
and the intervening short blocks. It also has one exit;
\(oe\) is unavailable because \(o\) is used. Thus the
only possible mate of \(H\) is \(i\) of \(V\).

The chord \(Hi\) encloses \(I,K,J,E\), the \(2k\)
intervening short slots, and \(o,h\). Its even interior
has the exit \(OK\), so \(oe\in M\) is required to
provide the second exit at \(o\). Every other free slot
strictly inside \(Hi\) must now match inside that chord:
an opposite-side edge leaving it would cross \(Hi\), and
no other face-side free chord is available. The two
face-side exits still have their mates \(O,e\) within
the full block interval from \(D\) through \(V\).
The endpoints \(H,i\) match one another, and all block
closing chords are internal. Hence that entire proper
complete block interval is matching-closed, a forbidden
two-edge cut. This order is impossible.

For the marked Hamilton consequence, compress \(P\) to a
short target-free square. Its old-cycle segment and common-face
order are preserved by Note 327; all other vacancies, by the
extra hypothesis, occupy distinct internal blocks. Note 324
supplies the marked Hamilton cycle, and Note 327 transfers it
back through \(P\); [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives the legal child's cycle. Reflection proves the \(J_3\)
statement. \(\square\)

The theorem does not cover a second singly vacant block in
this free group, repeated vacancies in any other block,
site-block vacancies, positive interblock gaps, defective
target order, nonsquare residual cycles, or all Barnette
graphs. The proof is project-internal and has not had an
independent external review; no priority claim is made.
