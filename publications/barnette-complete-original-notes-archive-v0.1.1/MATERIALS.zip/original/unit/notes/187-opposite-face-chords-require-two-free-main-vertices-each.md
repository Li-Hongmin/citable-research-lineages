> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Opposite-face chords require two free main vertices each

[Note 183](183-sharp-square-traps-have-exactly-one-opposite-face-chord.md)
used the six free vertices at the sharp boundary to exclude
two matching edges on the opposite site-face arc. The same
planar obstruction gives a bound at every main-segment size,
without assuming that this arc alternates.

Use the reduced one-square-per-lobe setting of
[Notes 176--179](179-saturated-square-trap-main-segments-create-two-edge-cuts.md).
Let \(S_0\) be the old main \(C\)-segment from \(x\) to
\(v\), with site ports \(x<y<u<v\), and let \(\ell\ge1\)
be the number of residual squares. Its \(2\ell\) escape
targets occur as \(R_\ell,L_\ell,\ldots,R_1,L_1\), with
each \(R_i\) at an odd \(S_0\)-index and each \(L_i\) at
an even one. Call the vertices of \(S_0\) other than the
four site ports and these escape targets *free*, and put
\[
f=|V(S_0)|-2\ell-4.
\tag{1}
\]
The complementary perfect matching pairs all free vertices
into \(m=f/2\) internal \(S_0\) chords.

**Free-vertex cost theorem.** If the other site-face arc
from \(y\) to \(u\) contains \(r\ge1\) edges of the
complementary matching, then
\[
f\ge 2r+4,
\qquad\text{equivalently}\qquad
|V(S_0)|\ge 2\ell+2r+8.
\tag{2}
\]
At equality in (2), both \(y\) and \(u\) lie strictly
inside escape-pair gaps \((R_i,L_i)\), possibly the same
gap. If \(r\ge2\), those pair gaps are distinct; in
particular, equality with \(r\ge2\) requires \(\ell\ge2\).
The conclusion applies to arbitrary lobe lengths before
compression as well. In particular, eight free main
vertices permit at most two opposite-face matching edges;
six free vertices permit at most one. The \(r=1\) bound
is attained by the sharp families of Notes 182--184.

**Proof.** The facial boundary-order lemma of Note 176
places every interior vertex of the \(y\)-to-\(u\) face arc
strictly inside the \(C\)-interval \((y,u)\). A matching
edge on that arc uses two distinct free vertices there:
the site ports are matched by \(q=xy,p=uv\), and every
escape target is matched to a residual square on the
opposite side of \(C\). Thus the \(r\) face-arc matching
edges use \(2r\) free vertices in \((y,u)\), and
\(m\ge r\).

Suppose toward a contradiction that \(f\le2r+2\), so
\(m-r\le1\). The \(C\)-edge immediately after \(y\) and
the one immediately before \(u\) start at odd indices
of \(S_0\). None of the \(r\) face-arc chords crosses
either edge, since both endpoints lie strictly between
\(y,u\). At most one other internal matching chord is
available. Note 179's even-cut bridge lemma therefore
forces an escape pair to straddle each of these two
\(C\)-edges. Hence \(y\) lies strictly inside some pair
gap \((R_i,L_i)\), and \(u\) inside some pair gap
\((R_j,L_j)\), possibly the same.

Index parity now puts at least one free vertex \(s\)
inside the \(y\)-gap before \(y\), and at least one free
vertex \(t\) inside the \(u\)-gap after \(u\). They are
outside \((y,u)\), so \(f\ge2r+2\). Equality is the
only remaining possibility. Then exactly \(2r\) free
vertices lie in \((y,u)\), all used by the face-arc
matching edges, while \(s,t\) are the only other free
vertices and must be matched to each other.

If \(i\ne j\), the chord \(st\) interlaces \(q=xy\),
so it must lie on the side of \(C\) opposite the common
face. An escape target lies strictly between the distinct
pair gaps. Its escape chord has its other endpoint on the
complementary \(C\)-arc, and therefore interlaces \(st\)
on that opposite side. This contradicts planarity.

If \(i=j\), there is no escape target between \(y,u\).
The \(2r\) free vertices there are consecutive on \(C\).
Their \(r\) face-arc matching edges form a noncrossing
perfect matching in the common-face disk. Every noncrossing
perfect matching on a linearly ordered even set has a pair
of consecutive vertices: choose an edge enclosing the
fewest vertices; if it enclosed any, their mates would
also lie inside, giving a shorter edge. Here such a pair
is adjacent on \(C\),
so its matching edge would duplicate a \(C\)-edge,
contrary to simplicity. Both cases are impossible, proving
(2).

Now assume equality \(f=2r+4\). Precisely two internal
matching chords are not on the \(y\)-to-\(u\) face arc.
If \(y\) lies in a nonpair gap, the edge immediately after
\(y\) is unstraddled by escape pairs. Note 179's even-cut
lemma forces both remaining chords across that edge. Each
interlaces \(q=xy\), so it lies opposite the common face;
it cannot enclose an escape target, since that target's
escape chord would cross it. Thus all four endpoints of
these two chords lie within the target-free gap containing
\(y\).

If \(u\) lies in a different pair gap, parity forces a
free vertex after \(u\) inside that pair gap. It is not
an endpoint of a face-arc chord, so it must be an endpoint
of one of the two remaining chords, contradicting their
confinement to the \(y\)-gap. If \(u\) lies in a different
nonpair gap, its immediately preceding \(C\)-edge is also
unstraddled and requires both remaining chords to cross it;
none reaches that gap. If \(u\) lies in the same nonpair
gap as \(y\), both remaining chords cross the edges after
\(y\) and before \(u\), so all their endpoints lie outside
\((y,u)\). The \(2r\) free face-chord endpoints inside
\((y,u)\) are then consecutive on \(C\) and perfectly
matched on the common-face side. The preceding noncrossing
matching argument again forces a duplicate \(C\)-edge.
Hence \(y\) must lie in a pair gap. Reversing the main
segment and exchanging the two site edges gives the same
conclusion for \(u\).

Suppose these ports lie in the same pair gap \((R_i,L_i)\).
At least one free vertex lies before \(y\) and one after
\(u\) in that gap, while the \(r\) face chords use \(2r\)
free vertices between the ports. Only two free vertices
remain unaccounted for. Every other target gap has an even
number of free vertices, so either both remain in
\((R_i,L_i)\) or both lie in the same other gap, where
they are consecutive on \(C\) and cannot be matched to
each other. If that other gap is earlier, both would have
to match free vertices before \(y\) in \((R_i,L_i)\):
a chord to a vertex after \(y\) would interlace \(q\),
be forced to the opposite side of \(C\), and cross an
intervening escape chord. There is only one such free
vertex before \(y\). The later-gap case is symmetric at
\(u,p\). Thus both extra free vertices also lie in
\((R_i,L_i)\).

The entire open interval \((y,u)\) now lies in one
target-free pair gap and contains at most \(2r+2\)
vertices, all free. By the facial boundary order, its
\(r\) face-arc chords have disjoint, successive endpoint
intervals along \(C\). Each interval contains at least
four vertices: a matching edge cannot duplicate a
\(C\)-edge, and bipartiteness makes its endpoint distance
odd, hence at least three. Thus \((y,u)\) contains at
least \(4r\) vertices. For \(r\ge2\), this exceeds
\(2r+2\), a contradiction. The two pair gaps are distinct.

Lobe compression leaves \(S_0\) and the opposite
site-face arc unchanged, so the inequality holds for the
original all-square opening, as does the equality conclusion.
\(\square\)

The bound controls only the matching-chord count of this
chosen face arc. It does not imply Hamiltonicity at
\(f=8\) or for general Barnette graphs.
[Note 188](188-multiple-opposite-face-chords-need-six-extra-free-vertices.md)
excludes equality in (2) whenever \(r\ge2\).
