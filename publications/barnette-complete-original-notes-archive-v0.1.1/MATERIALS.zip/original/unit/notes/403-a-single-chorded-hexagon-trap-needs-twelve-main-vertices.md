> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A single chorded hexagon trap needs twelve main vertices

[Note 176](176-alternating-facial-arcs-create-one-residual-cycle-per-matching-edge.md)
identifies each cycle trapped by a literal facial opening as
an old Hamilton-cycle segment closed by one face-side matching
edge. [Note 177](177-facial-square-traps-form-bouquet-lobes-with-disjoint-merger-squares.md)
settles the four-vertex segments. The first nonsquare segment
has six vertices. When it has an internal matching chord,
its smallest possible main segment forces a one-edge opposite
facial arc and hence a Hamiltonian child.

Let \(G\) be a simple three-connected cubic bipartite plane
graph with Hamilton cycle \(C\), and let \(M=E(G)\setminus E(C)\).
Choose disjoint matching edges \(q=xy,p=uv\) on a common face.
Assume one facial arc from \(v\) to \(x\) is the three-edge
alternating path
\[
                         v,\alpha,\beta,x,
 \qquad \alpha\beta\in M.                                \tag{1}
\]
The trapped old \(C\)-segment is the six-vertex path
\[
                S_1=(\alpha,a,b,c,d,\beta),
 \qquad \alpha\beta\in M.                                \tag{2}
\]
Assume also that the internal complementary matching chord
\(ad\in M\). Since \(ab,bc,cd\) are old-cycle edges,
\(ad\) is the only possible matching edge with both ends
among \(a,b,c,d\). Thus \(b,c\) have distinct matching
edges into the remaining old \(C\)-segment \(S_0\).
The induced six-vertex patch on (2) is the two-squares-sharing-
an-edge pole of
[Note 185](185-two-squares-sharing-an-edge-have-a-four-terminal-hamilton-signature.md),
with terminals \((\alpha,b,c,\beta)\). Its signature differs
from a labeled square, so the square-trap replacement of
Note 177 does not apply to this patch alone.

Write the main segment in old-cycle order as
\[
 S_0=(w_0=x,w_1,\ldots,w_{s-1}=v),
 \qquad y=w_j,\quad u=w_k.                               \tag{3}
\]
The common-face order gives \(0<j<k<s-1\).
Bipartiteness makes \(s\) even, \(j\) odd, and \(k\)
even. Simplicity excludes \(j=1\) and \(k=s-2\),
since then a site matching edge would duplicate a
cycle edge. Let \(t_b,t_c\in S_0\) be the matching
neighbours of \(b,c\), respectively.

**Short-main hexagon theorem.** Under (1)--(3),
\[
                              s\ge12.                     \tag{4}
\]
If \(s=12\), then \(k=j+1\): the other facial arc
between \(q\) and \(p\) is the single old-cycle
edge \(yu\). Therefore every legal \(C_4\)-expanded
child at this site has a Hamilton cycle, by the
one-edge facial-arc flip of
[Note 174](174-brace-cross-openings-avoid-a-forbidden-matching-edge.md).
The bound (4) is sharp in the Barnette class.

**Order and page constraints.** Colour \(w_0\) with 0.
Then \(\alpha\) and \(b\) have colour 0, while
\(c\) has colour 1. Hence \(t_b\) has odd and
\(t_c\) even index in (3). The escape chords
\(bt_b,ct_c\) lie opposite the common face by
Note 176. As \(b\) precedes \(c\) along \(C\),
their noncrossing order on \(S_0\) must be
\[
                              t_c<t_b.                     \tag{5}
\]
The chord \(ad\) lies on the common-face side:
on the opposite page it would interlace both
escape chords. It nests inside \(\alpha\beta\),
so it does not alter the selected face (1).

The site order, parity and nonadjacency already
give \(s\ge8\), as in Note 177. For \(s=8\),
they force \((j,k)=(3,4)\). The four unused
main slots are \(w_1,w_2,w_5,w_6\). Equation
(5) and colour force \(t_c=w_2,t_b=w_5\).
The remaining edge \(w_1w_6\) cannot lie on
the common-face side because it interlaces both
site chords \(w_0w_3,w_4w_7\); on the opposite
side it interlaces \(w_2c\). Thus \(s=8\) is
impossible.

For \(s=10\), the allowed site-index pairs
are \((j,k)=(3,4),(3,6),(5,6)\).
If \(j=3\), \(w_1\) cannot be an escape
endpoint by (5), and its edge to \(w_2\) is
an old-cycle edge. A face-side mate beyond
\(w_3\) would cross \(q=w_0w_3\).
On the opposite side, a mate \(w_{2h}\)
must precede \(t_c\), or it would cross
\(t_cc\). For \(k=4\), the first possible
mate is \(w_6\), leaving only \(t_c=w_8\)
and no later free odd \(t_b\). For \(k=6\),
\(w_4\) is the only possible mate before
an available \(t_c\), but then \(w_2\)
has no mate before \(w_4\) and cannot
cross \(w_1w_4\). Thus neither \(j=3\)
case occurs.

If \((j,k)=(5,6)\), the same first-slot
argument forces the face-side edge \(w_1w_4\)
nested in \(q=w_0w_5\). The escape order
then forces \(t_c=w_2\) and
\(t_b=w_3\) or \(w_7\). In the first case
the unused \(w_7,w_8\) are old-cycle neighbours.
In the second the unused \(w_3,w_8\) cannot
pair: their chord crosses \(q\) on the face
side and \(w_7b\) on the opposite side.
This proves (4).

**The equality boundary.** Suppose \(s=12\).
The allowed pairs \((j,k)\) are
\[
 (3,4),(3,6),(3,8),(5,6),(5,8),(7,8).
\tag{6}
\]
Only \((3,6),(3,8),(5,8)\) have \(k>j+1\).
If \((j,k)=(3,6)\), the only possible mate of
\(w_1\) before an admissible \(t_c\) is \(w_4\):
\(w_1w_2\) is an old-cycle edge, \(w_6\) is a site
port, and \(w_1w_8\) would require \(t_c=w_{10}\),
leaving no later odd \(t_b\). The chord \(w_1w_4\)
lies opposite the face because it interlaces
\(q=w_0w_3\). Now \(w_2\) cannot escape or cross
\(w_1w_4\), while the only odd index between
\(w_2,w_4\) is the occupied site port \(w_3\).
This is impossible. For \((j,k)=(3,8)\),
\(w_1w_4\) gives the same contradiction;
\(w_1w_6\) would require \(t_c=w_{10}\) with
no later odd \(t_b\), and no later mate of
\(w_1\) is possible.

For \((j,k)=(5,8)\), \(w_1w_4\) is forced on
the face side, nested inside \(q=w_0w_5\).
If \(t_c=w_6\), the free slot \(w_2\) cannot
use its old-cycle neighbour \(w_3\); any later
mate crosses \(q\) on the face side and
\(w_6c\) on the opposite side. Thus \(t_c=w_2\),
and \(t_b\) is \(w_3,w_7\), or \(w_9\).
For \(t_b=w_3\), the remaining free slots
\(w_6,w_7,w_9,w_{10}\) can avoid old-cycle
edges only by \(w_6w_9,w_7w_{10}\); both must
lie opposite the face because they interlace
\(p=w_8w_{11}\), but they cross each other.
For \(t_b=w_7\), pairing \(w_3w_6\) leaves
the forbidden old-cycle pair \(w_9,w_{10}\),
while \(w_3w_{10}\) crosses \(w_7b\) opposite
the face and \(q\) on it. For \(t_b=w_9\),
\(w_3w_{10}\) crosses \(w_9b\); pairing
\(w_3w_6\) instead forces \(w_7w_{10}\),
which crosses \(p\) on the face side and
\(w_9b\) on the other. Thus this last
long-gap case is impossible as well.

Only \(k=j+1\) remains. Since
\(w_jw_{j+1}\) belongs to \(C\), Note 174's
one-edge flip gives the asserted Hamilton child.

**Sharp Barnette realization.** Take the old
Hamilton cycle
\[
 w_0,w_1,\ldots,w_{11},\alpha,a,b,c,d,\beta,w_0
\tag{7}
\]
and add the complementary matching
\[
\begin{split}
\{&w_0w_7,w_8w_{11},\alpha\beta,ad,w_1w_4,\\
  &w_2c,w_3b,w_5w_{10},w_6w_9\}.
\end{split}                                                   \tag{8}
\]
The site edges are \(q=w_0w_7,p=w_8w_{11}\).
On one page of (7), draw \(q,p,\alpha\beta\),
with \(w_1w_4\) nested inside \(q\) and \(ad\)
nested inside \(\alpha\beta\). On the other,
the chords are nested in the order
\[
                 w_2c\supset w_3b\supset
                 w_5w_{10}\supset w_6w_9.
\]
All matching edges join opposite cycle parities,
so this is a simple cubic bipartite plane graph.
Its matching-chord interlacement graph is connected:
\(q\) interlaces \(w_2c,w_3b,w_5w_{10},w_6w_9\);
\(w_5w_{10}\) interlaces \(p\); and \(w_2c\)
interlaces \(\alpha\beta,ad,w_1w_4\). A two-edge
cut would isolate a proper old-cycle interval
closed under the matching and disconnect that
interlacement graph. The Hamilton cycle excludes
bridges, so the cubic graph is three-connected.

The face between \(q,p\) has one arc \(w_7w_8\)
and the other \(w_{11},\alpha,\beta,w_0\).
Thus (7)--(8) realize exactly one trapped chorded
hexagon and \(|S_0|=12\). The one-edge arc also
gives the promised Hamilton cycle after any legal
site expansion. \(\square\)

This theorem concerns one trapped hexagon with
the internal chord \(ad\). It does not cover
a chord-free hexagon, several trapped cycles,
or a general nonfacial opening. The 12-vertex
bound is a local main-segment bound and does not
resolve Barnette's conjecture. The argument is
analytic, project-internal, and has not had
independent review or an external priority check.
