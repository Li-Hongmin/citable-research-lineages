> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Primal cycles are contracted-dual cuts and exclude the six-label blocker

[Note 048](048-integral-two-point-paid-exit-deficits-discharge-through-order-eighteen.md)
shows that every integral two-point paid-exit deficit through order eighteen
can be discharged, while its six-label row--column model proves that
connectivity of the full common-base graph is not sufficient abstractly.
This note identifies the missing joint-rotation axiom and proves that the
six-label model cannot occur at any actual plane site, even as part of an
arbitrarily large ambient completion.

## Cycle--cut compatibility

Let \(F\) be a plane graph with an ordered legal site
\((u,v,z,a)\).  Put

\[
K=F-\{u,a\}.
\]

Let \(Q\) be obtained from the plane dual \(F^*\) by contracting the duals
of the two distinguished edges \(uv\) and \(za\), then retaining the labels
in \(E(K)\), exactly as in Notes 044--048.

> **Cycle--cut theorem.**  For every simple cycle \(C\) of \(K\), there is
> a shore \(S_C\subseteq V(Q)\) such that
> \[
> \boxed{E(C)=\delta_Q(S_C).}
> \tag{1}
> \]
> Consequently the rank-endpoint multigraph carried by the labels of \(C\)
> is bipartite.

The Jordan curve traced by \(C\) partitions the faces of \(F\) into inside
and outside classes.  A primal edge has incident faces in different classes
if and only if it belongs to \(C\); hence before contraction the duals of
the labels in \(E(C)\) form exactly the corresponding face cut.

Neither \(uv\) nor \(za\) belongs to \(C\), because each is incident with
one of the deleted vertices.  A plane edge not belonging to the Jordan
curve lies on one side of it, so its two incident faces have the same
inside--outside colour.  Contracting either special dual edge therefore
identifies only faces of the same colour.  The face colouring descends to
the quotient \(Q\), and a retained label crosses the descended shore
precisely when it belongs to \(C\).  This proves (1).

The proof uses only the common plane embedding and the fact that the
contracted primal edges are not retained cycle edges.  Cubicity,
bipartiteness, simplicity, and brace \(2\)-extendability are not needed for
the implication itself.

## The six-label blocker violates the theorem

Use the six labels of Notes 044 and 048.  Their primal row--column incidence
is

\[
\begin{aligned}
D_0&=\{e_0,e_1\},&
D_1&=\{e_2,e_3\},&
D_2&=\{e_4,e_5\},\\
C_0&=\{e_3,e_4\},&
C_1&=\{e_0,e_2\},&
C_2&=\{e_1,e_5\}.
\end{aligned}
\tag{2}
\]

Interpreting the \(D_i\) and \(C_j\) as the two primal endpoint blocks
makes

\[
e_0,e_2,e_3,e_4,e_5,e_1
\tag{3}
\]

the labels of a simple primal \(6\)-cycle.  Adding further labels to any of
the six blocks does not remove this cycle.

The prescribed contracted-dual endpoints are

\[
e_0,e_1,e_2:12,\qquad
e_3:23,\qquad
e_4:34,\qquad
e_5:13.
\tag{4}
\]

In particular \(e_0,e_3,e_5\) form the rank triangle
\(1\,2\,3\,1\).  The rank multigraph supported by the six cycle labels is
therefore not bipartite and cannot be the cut in (1).  Thus

\[
\boxed{\text{No actual ordered plane site contains the six-label
configuration (2)--(4).}}
\tag{5}
\]

This is a pure joint-rotation obstruction.  It is stronger than checking
that the isolated six-label system is absent through a finite order: no
ambient completion, even with arbitrarily many additional vertices, faces,
labels, or block entries, can repair the fixed primal cycle and fixed rank
triangle simultaneously.

## Consequence and remaining boundary

The exact datum missing from the abstract row--column model is

\[
\boxed{\text{every simple primal label-cycle is an exact cut of the contracted
dual rank graph}.}
\tag{6}
\]

This condition couples the two primal partition marginals to the dual
rotation; it is not implied by their degree sequences, by planarity of the
rank graph, or by connectivity of the common-base exchange graph.

Equation (5) removes the only explicit over-cost connected blocker in
Note 048.  It does not prove general integral paid-exit discharge.  A
different counterexample could satisfy (6) while trapping every full common
base above the binary budget.  Future abstract models and positive proofs
must therefore retain cycle--cut compatibility rather than only the two
partition systems and the graphic-base equations.

The finite incidence core of (2)--(4) is checked by

    python3 \
      units/barnette/computations/verify_six_label_cycle_cut_obstruction.py

with terminal marker
SIX_LABEL_CYCLE_CUT_OBSTRUCTION_VERIFIED.
