> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every gapless first-surplus opening has a marked Hamilton cycle

[Note 210](210-every-tight-gapless-first-surplus-opening-has-a-hamiltonian-child.md)
settles tight target order at the first free-vertex surplus.
[Note 211](211-endpoint-defects-at-first-surplus-have-marked-hamilton-cycles.md)
settles either endpoint defect. The remaining gapless case has
exactly one nonadjacent transition between consecutive lobes.
Its sole feasible shape inserts two free slots between the two
targets, and those slots repair the broken target path.

Let \(G\) be a Barnette parent with a Hamilton cycle \(C\) avoiding
the disjoint cofacial matching site edges \(q=xy,p=uv\). Select an
all-square facial opening and compress each lobe to one square as
in [Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
Let \(\ell,r\ge1\) be the lobe and opposite-face-chord counts, and
suppose every interblock gap is empty and \(f=4r+4\). Write
\(B_0=[x,y]_C\), \(B_t=[a_t,b_t]_C\) for \(1\le t\le r\), and
\(B_{r+1}=[u,v]_C\).

**Gapless first-surplus Hamilton theorem.** The parent \(G\) has a
Hamilton cycle containing both \(p,q\). Hence every legal
site-expanded child admitting this opening is Hamiltonian. This
holds for every \(\ell,r\ge1\) and every positive length of the
original lobes.

In the remaining transition-defect case, let
\(L_j,R_{j-1}\), \(2\le j\le\ell\), be the unique nonadjacent
consecutive targets. Then they lie in distinct blocks \(B_i,B_h\)
with \(0\le i<h\le r+1\). The target \(L_j\) occupies the last
eligible even slot of \(B_i\); its following odd slot \(c_i\)
and final even slot \(e_i\) are free. All blocks strictly between
\(B_i,B_h\) are short. The first two slots of \(B_h\), denoted
\(o_h,w\), are free, and \(R_{j-1}\) is its third slot. With the
usual free first and final slots \(o_t,e_t\) of other blocks, the
complete free matching is
\[
 M_{\rm free}=\{c_iw\}\cup
                 \{e_t o_{t+1}:0\le t\le r\}.
\tag{1}
\]
For \(i=0\), \(e_0\) is the final slot of the left site block;
for \(h=r+1\), \(o_h\) is the first slot of the right site block.

**Proof.** By the defect budget of
[Note 197](197-gapless-square-trap-defect-budget.md), either the
target order is tight, an endpoint is defective, or exactly one
transition \(L_j,R_{j-1}\) is nonadjacent. Notes 210 and 211
prove the first two cases. In the last case the endpoints are
tight, and the unique eligible even position not occupied by a
nonfinal \(L\)-target lies strictly between \(L_j,R_{j-1}\).
All other transitions are adjacent.

First, \(R_{j-1}\) cannot be the first interior slot of a block
strictly later than the block of \(L_j\). If it were first in
\(B_h\), take the main \(C\)-prefix from \(x\) through the right
endpoint of \(B_{h-1}\), together with the contiguous residual-square
suffix \(S_j,\ldots,S_\ell\). Every escape target in this set is
matched to a square in the set; all site and face matching chords
in the prefix are complete. A free matching edge leaving the set
would join distinct main blocks, lie opposite the common site
face by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
and straddle \(R_{j-1}\). It would cross that target's escape edge
by [Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md).
Thus the set is closed under the complementary matching and has
only two departing old-cycle edges, contrary to
three-edge-connectivity. This argument does not depend on the
lengths of the intermediate blocks.

Suppose \(L_j,R_{j-1}\) lie in the same block \(B_i\).
The only vacant eligible even position lies between them.
Since no other target occurs there, their local slot order is
\[
 L_j,c,d,R_{j-1},
\tag{2}
\]
where \(c,d\) are free consecutive old-cycle vertices and \(d\)
is the vacancy. Before \(L_j\), the number of free main slots is
even: it is \(0\) in \(B_0\), \(2i\) in a face block \(B_i\), and
\(2r+2\) in the final site block. A cross-block free edge cannot
straddle \(L_j\). Within \(B_i\), at most one free edge can cross
it, because there is at most one free slot of \(B_i\) before
its target run. Matching parity therefore forbids any such edge.
Before \(R_{j-1}\) the free-slot count has risen by two and is still
even. Again no cross-block edge can straddle the target; among
the two newly free slots only \(c\) could have an opposite-colour
same-block mate after it, so at most one edge could cross.
Parity forbids that edge as well. Thus \(c,d\) would have to
match each other, impossible because \(cd\in E(C)\).
The two defective targets must lie in different blocks.

Let \(L_j\in B_i\), \(R_{j-1}\in B_h\) with \(i<h\).
The first-slot alternative for \(R_{j-1}\) was excluded above.
Its block's second eligible position is the sole vacancy,
so \(R_{j-1}\) is the third slot of \(B_h\), preceded by free
slots \(o_h,w\). Every intervening block is short, since an
eligible position in any such block would hold another
\(L\)-target between \(L_j,R_{j-1}\). Likewise \(L_j\) must
be the last eligible position of \(B_i\); otherwise the next
eligible position would be another vacancy or target between
them. Its next odd and final even slots \(c_i,e_i\) are
consecutive and free.

The free-slot count before \(L_j\) is \(2i\), including the
case \(i=0\). The count before \(R_{j-1}\) is
\[
 2i+2+2(h-i-1)+2=2h+2.
\tag{3}
\]
Both are even. At either target a cross-block free edge is
forbidden by Note 203. At most one same-block free edge can
cross \(L_j\): its only possible earlier endpoint in \(B_i\)
is the first free slot \(o_i\), absent when \(i=0\).
At most one can cross \(R_{j-1}\): its only possible
opposite-colour earlier endpoint in \(B_h\) is \(o_h\).
Matching parity therefore forbids every free edge across
either target. The same even-prefix argument at each other
occupied target run splits all remaining free slots into
ordinary groups, exactly as in Notes 208 and 211.

The group strictly between \(L_j,R_{j-1}\) is
\[
 c_i,e_i,o_{i+1},e_{i+1},\ldots,
 o_{h-1},e_{h-1},o_h,w.
\tag{4}
\]
Its same-block consecutive pairs are old-cycle edges.
Thus all its matching edges join distinct blocks, lie in
the opposite-side disk, and are noncrossing. The odd slot
\(c_i\) cannot match \(e_i\), which is adjacent on \(C\).
If it matched some \(e_t\) with \(i<t<h\), noncrossing
would match all free slots strictly between \(c_i,e_t\)
internally. Since no free edge crosses \(L_j\), the main
prefix through the right endpoint of \(B_t\), together
with \(S_j,\ldots,S_\ell\), would then be closed under
the entire complementary matching and have a forbidden
two-edge cut. Hence \(c_iw\in M\).

Inside that chord the slots are
\(e_i,o_{i+1},e_{i+1},\ldots,e_{h-1},o_h\).
The short-block skipping rule of
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md)
forces \(e_t o_{t+1}\in M\) for \(i\le t<h\):
skipping one complete short block would match adjacent
old-cycle vertices, while skipping more would close a
proper consecutive block interval under \(M\) and create
a two-edge cut. The ordinary free groups before \(L_j\)
and after \(R_{j-1}\) obey the same rule, giving every
remaining edge of (1).

Let \(A\) be the even-starting matching of \(C\), indexed
from \(x\). Tight endpoints and all other tight
transitions give Note 196's square-and-target
\(x\)-to-\(v\) path (4), with its one missing
edge \(L_jR_{j-1}\) replaced by
\[
 L_j,c_i,w,R_{j-1}.
\tag{5}
\]
Here \(L_jc_i,wR_{j-1}\in A\) and \(c_iw\in M\).
Equation (1) gives Note 196's other \(x\)-to-\(v\)
path (5) unchanged. The paths meet only at \(x,v\),
cover all vertices, and form a Hamilton cycle containing
\(xy,uv\). Note 001 lifts this marked cycle through
the legal site expansion; Note 178 restores the original
lobe lengths. \(\square\)

The theorem is universal only for the stated all-square,
gapless, first-surplus opening class. It does not cover
two interblock gap slots, nonsquare residual cycles, or
arbitrary Barnette graphs, and does not settle the
Barnette conjecture.

[Note 213](213-two-slot-gaps-must-split-and-disrupt-a-transition.md)
subsequently shows that the two-slot gap case can only use
distinct gaps and must have a nonadjacent target transition.
