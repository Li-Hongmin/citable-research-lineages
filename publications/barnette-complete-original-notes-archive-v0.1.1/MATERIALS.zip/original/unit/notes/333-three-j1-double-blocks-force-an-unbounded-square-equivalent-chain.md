> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Three J1 double blocks force an unbounded square-equivalent chain

[Note 332](332-two-j1-double-blocks-across-a-short-corridor-have-the-square-signature.md)
classifies two \(J_1\) doubly vacant blocks separated only by short
blocks. Three such blocks have a different, irreducibly three-block
pairing of their \(H/I\) slots. It is forced in the three-block
case and belongs to a square-equivalent family with arbitrarily
many double blocks and arbitrarily long short corridors.

Use a compressed, gapless, tight-target all-square opening of a
Barnette parent. Fix an ordinary target-free free group whose only
nonshort complete blocks are \(n\ge2\) doubly vacant blocks
\[
D_j=(a_j,O_j,H_j,I_j,K_j,J_j,E_j,b_j),
\qquad 1\le j\le n,                                   \tag{1}
\]
listed in old-cycle order. Every \(D_j\) has its internal
\(J_1\) chord \(O_jK_j\). Between \(D_j,D_{j+1}\), let
\(S_{j,t}=(c_{j,t},o_{j,t},e_{j,t},d_{j,t})\),
\(1\le t\le k_j\), be short blocks. Short-block flanks
before \(D_1\) and after \(D_n\) are unrestricted.

**Forced three-block theorem.** If \(n=3\), both corridor
lengths \(k_1,k_2\) are positive and the matching on the
three double blocks and their corridors is uniquely
\[
\begin{split}
&O_jK_j\quad(1\le j\le3),\qquad
H_1I_3,\quad I_1H_2,\quad I_2H_3,\\
&J_je_{j,k_j},\quad E_jo_{j,1},\quad
e_{j,t}o_{j,t+1}\quad
(j=1,2;\ 1\le t<k_j),
\end{split}                                               \tag{2}
\]
besides the face-closing chords. This is independent of
the matching on the short-block flanks.

**Canonical double-chain theorem.** For every \(n\ge2\)
and every \(k_1,\ldots,k_{n-1}\ge1\), let \(R_{n,\mathbf k}\)
be the induced patch on (1) and the intervening short
blocks, with the old-cycle path, all face-closing chords,
and the matching
\[
\begin{split}
&O_jK_j\quad(1\le j\le n),\qquad
H_1I_n,\quad I_jH_{j+1}\quad(1\le j<n),\\
&J_je_{j,k_j},\quad E_jo_{j,1},\quad
e_{j,t}o_{j,t+1}\quad
(1\le j<n,\ 1\le t<k_j).
\end{split}                                               \tag{3}
\]
Its only degree-two vertices are \(a_1,J_n,E_n,b_n\),
in that cyclic order. The complete spanning one-path and
two-path Hamilton linkage signature at these terminals
equals that of a square. Replacing this patch by the
labeled square, or conversely, preserves Barnette membership
and every exterior-marked Hamilton decision. Every parameter
choice occurs in an explicit Hamiltonian Barnette graph.
Consequently no vertex-minimal non-Hamiltonian Barnette
graph contains such an induced patch. In a selected opening,
if every vacancy outside it lies in a distinct internal
block, the parent has a Hamilton cycle through both site
edges and its legal site-expanded child is Hamiltonian.

**Proof of the forced three-block theorem.** Note 327's
chord-isolation lemma puts each \(O_jK_j\) on the
common-face side and excludes all other internal free
chords of \(D_j\). Every cross-block free chord lies
opposite that face by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
For an opposite-side chord, its strictly enclosed free
slots have even count after removing endpoints of
common-face chords that leave the interval. Every full
intermediate block has an even number of free slots and
its \(O_jK_j\), if present, lies wholly within or
outside such an interval.

For any \(j\), the even slot \(H_j\) cannot match an
ordinary odd short-block slot: whether the candidate is
before or after \(D_j\), the enclosed count is even and
\(O_jK_j\) is the sole face-side exit. The same count
excludes the odd \(J_\ell\)-slot of another double block:
if \(D_\ell\) is earlier, the interval contains \(E_\ell\),
complete blocks and \(O_j\); if it is later, it contains
\(I_j,K_j,J_j,E_j\), complete blocks and
\(O_\ell,H_\ell,I_\ell,K_\ell\). In both cases the
candidate block's \(J_1\) chord has both ends inside
or outside, while \(O_jK_j\) has exactly one inside.
Within \(D_j\), the remaining candidates are old-cycle
neighbours, used slots, same-colour slots or excluded
internal chords. Thus \(H_j\) must match \(I_\ell\)
for some \(\ell\ne j\). Reflecting the interval counts,
or counting from \(I_j\) to an ordinary final even slot
or another block's \(E_\ell\), shows that \(I_j\) must
match \(H_\ell\) for some \(\ell\ne j\). The ordinary
endports obey the same counts.

The six special slots therefore form a noncrossing perfect
matching on the order
\(H_1,I_1,H_2,I_2,H_3,I_3\), with no same-block
\(H_jI_j\) edge because each is on the old cycle.
If \(H_1I_2\) occurred, the inner pair \(I_1H_2\)
would be forced and \(H_3,I_3\) could only use their
forbidden old-cycle edge. Hence \(H_1I_3\) occurs.
The four special slots inside it can pair without a
forbidden same-block edge only as \(I_1H_2,I_2H_3\).

For \(j=1,2\), the chord \(I_jH_{j+1}\) traps
\(K_j,J_j,E_j\), the short corridor, and \(O_{j+1}\).
The first and last slots pair across its boundary by
\(O_jK_j,O_{j+1}K_{j+1}\). Every other slot inside
must match inside the chord. With no short block,
\(J_j,E_j\) would have to use their old-cycle edge;
thus \(k_j\ge1\). The noncrossing and two-edge-cut
argument of Note 332 applies separately to each corridor:
\(J_j\) must meet its last \(e\)-slot, \(E_j\) its
first \(o\)-slot, and all intermediate ordinary links
are forced. This gives exactly (2). \(\square\)

**Proof of the Hamilton signature.** For each corridor
\(j<n\), write its spanning zigzag sequence
\[
C_j^+=(o_{j,1},c_{j,1},d_{j,1},e_{j,1},
o_{j,2},c_{j,2},d_{j,2},e_{j,2},\ldots,
o_{j,k_j},c_{j,k_j},d_{j,k_j},e_{j,k_j}).             \tag{4}
\]
Successive groups join by the matching edges in (3).
Put
\[
L=(a_1,b_1,E_1,C_1^+,J_1,K_1,O_1,H_1,I_1),
\quad
M_j=(H_j,O_j,a_j,b_j,E_j,C_j^+,J_j,K_j,I_j)
\ (2\le j<n).                                           \tag{5}
\]
The comma between two sequences means concatenation;
when \(n=2\), the list of \(M_j\)'s is empty. Each
successive \(M_j\) joins the previous segment by
\(I_{j-1}H_j\). The terminal colours are \(a_1,E_n\)
on one side and \(J_n,b_n\) on the other. The four
permitted spanning one-path pairs have these routes:
\[
\begin{array}{c|l}
a_1b_n&\text{the full old-cycle path through }R_{n,\mathbf k}\\
a_1J_n&L,M_2,\ldots,M_{n-1},
H_n,I_n,K_n,O_n,a_n,b_n,E_n,J_n\\
J_nE_n&J_n,K_n,I_n,H_1,O_1,a_1,b_1,E_1,C_1^+,J_1,K_1,I_1,
M_2,\ldots,M_{n-1},H_n,O_n,a_n,b_n,E_n\\
E_nb_n&E_n,J_n,K_n,I_n,H_1,O_1,a_1,b_1,E_1,C_1^+,J_1,K_1,I_1,
M_2,\ldots,M_{n-1},H_n,O_n,a_n,b_n.
\end{array}                                                \tag{6}
\]
Each row visits every patch vertex once, with adjacent
entries joined by the old cycle, a face chord, or (3).
For two-path routings, the old-cycle path from \(a_1\)
through \(J_n\) together with the edge \(E_nb_n\)
realizes \(\{a_1J_n,E_nb_n\}\). The edge \(J_nE_n\)
together with
\[
L,M_2,\ldots,M_{n-1},
H_n,I_n,K_n,O_n,a_n,b_n                              \tag{7}
\]
realizes \(\{a_1b_n,J_nE_n\}\). These are the two
noninterlacing terminal pairings. The third pairing
\(\{a_1E_n,J_nb_n\}\) interlaces the disk boundary
terminals and is impossible. Thus (6)--(7) are exactly
the square's complete Hamilton signature. A global
Hamilton cycle uses two or four of the patch's external
edges; replace the resulting spanning route by the
equal-signature square route, or conversely, retaining
all exterior edges and attachments.

**Barnette realizations and preservation.** For every
parameter choice in the theorem, form an old Hamilton
cycle in the order
\[
x,R_1,w,y,D_1,S_{1,1},\ldots,S_{1,k_1},D_2,
\ldots,D_n,u,o_3,L_1,v,\alpha,\gamma,\delta,\beta,x.
                                                               \tag{8}
\]
Add the complementary matching consisting of the
face-side edges
\[
xy,\quad a_jb_j\ (1\le j\le n),\quad
c_{j,t}d_{j,t}\ (1\le j<n,1\le t\le k_j),\quad
uv,\quad\alpha\beta,\quad O_jK_j\ (1\le j\le n),
                                                               \tag{9}
\]
and the opposite-side edges
\[
\begin{split}
&\delta R_1,\quad \gamma L_1,\quad wJ_n,\quad E_no_3,
\quad H_1I_n,\quad I_jH_{j+1}\ (1\le j<n),\\
&J_je_{j,k_j},\quad E_jo_{j,1},\quad
e_{j,t}o_{j,t+1}\quad(1\le j<n,1\le t<k_j).
\end{split}                                                \tag{10}
\]
Every vertex occurs once in this matching, every edge
joins opposite old-cycle parities, and no edge duplicates
an old-cycle edge. The face-side chords are disjoint or
nested. On the other side, \(\delta R_1\) contains the
other opposite-side chords, \(wJ_n\) contains the whole
patch chord system, \(H_1I_n\) contains the disjoint
\(I_jH_{j+1}\), and the matching of corridor \(j\)
lies inside \(I_jH_{j+1}\). The remaining \(E_no_3\)
and \(\gamma L_1\) lie to the right of \(wJ_n\).
Thus (8)--(10) define a simple cubic bipartite plane
graph with \(xy,uv\) on the same outer common face.

Its matching-chord interlacement graph is connected.
One connected spanning system of endpoint alternations begins with
\[
xy-wJ_n-a_nb_n-H_1I_n-a_1b_1,
\qquad
a_jb_j-I_jH_{j+1}-a_{j+1}b_{j+1}\quad(1\le j<n),
                                                               \tag{11}
\]
together with \(I_jH_{j+1}-O_jK_j\) for \(j<n\),
\(H_1I_n-O_nK_n\), and, for each corridor \(j<n\),
\[
a_jb_j-J_je_{j,k_j}-c_{j,k_j}d_{j,k_j}-
e_{j,k_j-1}o_{j,k_j}-\cdots-c_{j,1}d_{j,1}-E_jo_{j,1}.
                                                               \tag{12}
\]
When \(k_j=1\), omit the intervening \(e o\) terms.
Finally \(a_nb_n-E_no_3-uv-\gamma L_1-\alpha\beta-
\delta R_1\) connects the exterior chords. Every
displayed dash is alternation in (8), so all matching
chords belong to one interlacement component. A two-edge
cut in a cubic Hamiltonian graph would be a proper old-cycle
interval closed under the complementary matching and would
disconnect this interlacement graph. The old cycle rules out
bridges; therefore the graph is three-edge-connected and,
in the cubic case, three-vertex-connected. It has
\(8n+4\sum_jk_j+12\) vertices and contains the indicated
\(R_{n,\mathbf k}\) as an induced patch. For an explicit
Hamilton cycle through the site edges, join
\(x,R_1,\delta,\beta,\alpha,\gamma,L_1,v\) to the
\(x\)--\(v\) path obtained by prefixing \(x,y,w\)
and suffixing \(o_3,u,v\) to the \(J_nE_n\) route
in (6).

To prove Barnette preservation in both directions,
contract the connected old-cycle path in \(R_{n,\mathbf k}\)
from \(a_1\) through \(K_n\), leaving \(J_n,E_n,b_n\).
The edges \(K_nJ_n,J_nE_n,E_nb_n,a_nb_n\) yield the
labeled square, so the reduction is a planar minor.
Conversely, the two-page drawing inserts the patch into
the free side of a square with connected exterior.
Deleting one patch vertex leaves the patch connected:
each block cycle remains connected, and the double-block
cycles are linked in a cycle by \(H_1I_n\) and the
\(I_jH_{j+1}\); deleting one vertex destroys at most
one of those joins. Every intervening short corridor
remains attached to its left double block through one
of the two vertex-disjoint joins at each step.
After deleting any two patch vertices, every surviving
component has a terminal: otherwise it would be a
component of the three-connected realization (8)--(10)
separate from its nonempty exterior. The four-attachment
deletion comparison of Note 330 then proves
three-connectivity for either replacement direction.
Terminal colours, cubicity and simplicity also agree.
This proves the class equivalence. \(\square\)

Compressing \(R_{n,\mathbf k}\) in a selected opening
turns its contiguous common-face block arc into one
short target-free square, retains the old Hamilton cycle
and the cyclic order of external matching edges at
\(J_n,E_n\), and touches no escape target or site edge.
If the remaining vacancies lie in distinct internal
blocks, Note 324 gives a Hamilton cycle containing both
site edges in the reduced parent. The exact signature
lifts it, and [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives the legal site-expanded child's Hamilton cycle.

For \(n=2\), the patch is the family \(Q_k\) of Note 332.
For \(n=3\), the forced three-block theorem shows that
every group with exactly three \(J_1\) double blocks and
only short blocks contains such a patch. For \(n>3\),
the theorem proves the stated canonical family but does
not classify every noncrossing pairing among the blocks.
Singly vacant blocks, other internal chord types, further
multiply vacant blocks of another kind, target-bearing
terminal vacancies, positive gaps, defective target order,
nonsquare residual cycles, and the general Barnette
conjecture remain outside the classification. This is a
project-internal analytic result without an external
priority claim or independent review.
