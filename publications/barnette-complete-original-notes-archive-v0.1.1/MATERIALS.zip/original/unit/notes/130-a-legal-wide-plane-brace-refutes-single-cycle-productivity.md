> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A legal-wide plane brace refutes single-cycle productivity

[Note 128](128-good-sibling-or-nonrooted-portal-covers-the-frozen-mixed-sector-family.md)
suggested that every sterile state-\(11\) endpoint with a mixed rooted
neighbour and a same-sector child target might have either a productive
mixed neighbour or a productive non-rooted phase portal.  [Note
129](129-productivity-is-demand-cycle-containment-and-braces-do-not-force-it.md)
reduced productivity to containment of the complete retained demand in one
parent alternating cycle, but left open whether the actual legal-wide patch
and child root separation force that containment.

They do not.  This note gives an explicit order-\(24\to28\) legal-wide
plane-brace endpoint for which

\[
 |\mathcal M_\chi|=2,\qquad |\mathcal E_\chi|=0,\qquad
 |\mathcal X^b|=2,\qquad G=P=0.
\tag{1}
\]

Thus the \(G\lor P\) statement is false even with all of its actual graph,
brace, patch, and root-separation hypotheses.  The child nevertheless has
two same-sector targets, so this refutes the proposed single-cycle proof
mechanism, not \(H^{+-}\) preservation itself.

## 1. The graph and legal-wide decoration

Take three cubes on the vertex sets \(0,\ldots,7\), \(8,\ldots,15\), and
\(16,\ldots,23\), with local cube edges joining labels whose three-bit
coordinates differ in one position.  In the first annular splice delete

~~~text
01, 23, 89, 10-11
~~~

and add

~~~text
0-9, 1-8, 3-10, 2-11.
~~~

For the second splice use the middle square \((8,10,14,12)\) and the third
cube square \((16,18,22,20)\).  Delete

~~~text
10-14, 8-12, 16-18, 20-22
~~~

and add

~~~text
8-16, 10-18, 14-22, 12-20.
~~~

The resulting graph \(H\) is a cubic bipartite plane brace on \(24\)
vertices.  It has vertex connectivity three, \(244\) perfect matchings, and
face-length multiset

\[
 4^{10}6^2 10^2.
\tag{2}
\]

Use the decoration

~~~text
root edge          1-8
forced gate edge   3-10
surviving gate     2-11
expansion site     0-9, 16-20.
~~~

The root and forced gate are opposite edges of the facial square
\((1,3,10,8)\).  The two site edges lie on a decagonal face and are disjoint
from the interface.  Expanding this site by the standard facial \(C_4\)
patch produces a cubic bipartite plane brace \(H^+\) on \(28\) vertices,
also of vertex connectivity three.  The forced and surviving gates lie on
a root-free face with odd arc lengths \((5,7)\).  Hence the expansion is an
actual legal-wide endpoint, not merely a port quotient.

## 2. A sterile endpoint

Let

\[
\begin{aligned}
M_\chi=\{&0\!-\!9,1\!-\!8,2\!-\!11,3\!-\!10,4\!-\!6,5\!-\!7,\\
          &12\!-\!14,13\!-\!15,16\!-\!20,17\!-\!21,
            18\!-\!19,22\!-\!23\}.
\end{aligned}
\tag{3}
\]

This matching belongs to the \(17\)-element rooted parent fibre and uses
both site edges.  The rooted child fibre has \(25\) elements, but none of
the three direct \(R_{00},X_{uy},X_{vx}\) lifts of \(M_\chi\) belongs to it.
Thus \(\chi\) is a sterile state-\(11\) endpoint.

There are exactly two opposite-sector rooted matchings \(\eta\) for which
\(M_\chi\triangle M_\eta\) is one alternating cycle, and there is no
same-sector rooted one-cycle escape.  There are exactly two same-sector
new-cell child targets, both of type \(X_{uy}\).  This proves the first
three equalities in (1).

## 3. Failure of both productive alternatives

For a child target \(\theta\), write as in Note 129

\[
D_\chi(\theta)=
(M_\theta\cap E_{\rm ret})\setminus M_\chi.
\tag{4}
\]

For the two mixed neighbours and two targets, the four sets of retained
demand not covered by \(M_\chi\cup M_\eta\) are respectively

\[
\begin{aligned}
&\{12\!-\!20,14\!-\!15,17\!-\!19,18\!-\!22,21\!-\!23\},\\
&\{12\!-\!20,14\!-\!15\},\\
&\{9\!-\!13,12\!-\!20,14\!-\!15,17\!-\!19,18\!-\!22,21\!-\!23\},\\
&\{9\!-\!13,12\!-\!20,14\!-\!15\}.
\end{aligned}
\tag{5}
\]

Every set in (5) is nonempty.  By the exact equivalence in Note 129, none
of the four mixed-neighbour/target pairs has a parent alternating cycle
carrying the complete retained demand.  Hence \(G=0\).

There are \(19\) same-label non-rooted parent matchings.  None has the
required phase-portal signature: its difference from \(M_\chi\) must be one
alternating cycle, must toggle both site edges, must avoid all three labelled
edges, and must preserve the sector.  Therefore the phase-portal family is
empty and \(P=0\).  This completes (1).

## 4. Two rooted witnesses still do not suffice

The two retained demand sets are

\[
\begin{aligned}
D_0={}&\{9\!-\!13,12\!-\!20,14\!-\!15,
         17\!-\!19,18\!-\!22,21\!-\!23\},\\
D_1={}&\{9\!-\!13,12\!-\!20,14\!-\!15\}.
\end{aligned}
\tag{6}
\]

Exact set cover over the complete \(17\)-element rooted parent fibre gives

\[
 \tau_{\rm rooted}(D_0)=\tau_{\rm rooted}(D_1)=3.
\tag{7}
\]

For \(D_0\), any two rooted matchings cover at most five of its six edges;
for \(D_1\), any two cover at most two of its three edges.  Hence replacing
one productive rooted witness by two rooted witnesses is still false on the
same actual endpoint.

The label obstruction is stronger.  There are \(22\) parent perfect
matchings containing the same root, forced-gate, and surviving-gate edges
as \(M_\chi\), and none contains \(9\!-\!13\).  Thus no number of same-label
parent matchings covers either demand.  Allowing an arbitrary positive
number of alternating components while retaining the phase-portal labels
also leaves the candidate family empty.

The demand itself is not intrinsically difficult to cover.  After dropping
the root and label conditions, one single-cycle matching covers \(D_1\),
and two single-cycle matchings cover \(D_0\); a single unrestricted matching
whose difference from \(M_\chi\) consists of a \(6\)-cycle and a
\(14\)-cycle covers both.  The obstruction therefore lies precisely in
coupling demand coverage to root/label topology, not in matching incidence
alone.

## 5. The annular boundary behind the failure

There is a general four-port reason that one-cycle productivity is too
rigid.  Label the connector edges cyclically by \(0,1,2,3\).  For any
perfect matching \(N\), bipartite balance restricts its connector state to

\[
s(N)\in
\{\varnothing,\Omega,A_0,A_1,A_2,A_3\},\qquad
\Omega=\{0,1,2,3\},\quad A_i=\{i,i+1\}.
\tag{8}
\]

For two matchings \(M,Q\), put \(d=|s(M)\triangle s(Q)|\).  The \(36\)
ordered state pairs split as

\[
d=0:6,\qquad d=2:24,\qquad d=4:6.
\tag{9}
\]

Let \(z_1,z_2\) be the numbers of closed local components of
\(M\triangle Q\) in the two factors.  The exact number of canonical demand
components is

\[
 \kappa=z_1+z_2+a,
\tag{10}
\]

where

\[
a=
\begin{cases}
0,&d=0,\\
1,&d=2,\\
1,&\{s(M),s(Q)\}=\{\varnothing,\Omega\}
       \text{ and the two pairings differ},\\
2,&\{s(M),s(Q)\}=\{\varnothing,\Omega\}
       \text{ and the two pairings agree},\\
2,&\{s(M),s(Q)\}=\{A_i,A_{i+2}\}.
\end{cases}
\tag{11}
\]

Indeed, when \(d=2\), the two local terminal paths glue to one annular
alternating cycle.  When \(d=4\), they glue as recorded in (11); opposite
adjacent states \(A_i,A_{i+2}\) always give two.

If a factor contains a closed component \(K\) of \(M\triangle Q\), any
\(M\)-alternating cycle containing all \(Q\setminus M\) edges of \(K\) is
forced to equal \(K\).  Thus separate closed demand components cannot be
absorbed by one parent cycle.  The six connector states impose no bound on
\(z_1+z_2\), so they do not even imply a universal two-cycle replacement.
A strict port-quotient witness takes \(s(M)=\varnothing\), \(s(Q)=A_0\),
one closed component in each factor, and the single cross-annular component.
If these three components are the only carrier rows, the minimum demand
cover has size three.

The unmarked connector state and path pairing also do not determine rooted
escape.  Rooted escape requires a third matching whose complement quotient
has exactly two components with the ordered root fragments separated.
Changing only those root marks can preserve all unmarked annular transfer
data while changing whether such an escape exists.  Consequently neither
brace connectivity nor unmarked four-port transfer can repair the failed
single-cycle implication.

## 6. Consequence and remaining boundary

The implications proposed in Notes 128 and 129 must be replaced as follows:

\[
\boxed{
\text{actual legal-wide patch + child root separation}
\not\Longrightarrow G\lor P.}
\tag{12}
\]

In particular, a proof of \(H^{+-}\) preservation cannot insist that one
mixed sibling or one non-rooted single-cycle portal simultaneously supply
every retained edge of a child target.  It must instead allow at least one
of the following genuinely stronger couplings:

1. a componentwise family of parent alternating cycles whose size is not
   bounded by the six connector states alone and which cannot in general
   preserve all three parent labels;
2. several parent matchings with compatible root-marked quotients; or
3. a child-intrinsic matching construction not represented by a parent
   one-cycle portal.

The explicit graph and all predicates in (1)--(7) are checked by the
[legal-wide single-cycle productivity counterexample bundle](../computations/bundles/legal-wide-single-cycle-productivity-counterexample/README.md).
No minimal-order claim is made.
