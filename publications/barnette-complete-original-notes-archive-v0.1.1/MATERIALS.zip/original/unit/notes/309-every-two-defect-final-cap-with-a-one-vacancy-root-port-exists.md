> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every two-defect final cap with a one-vacancy root port exists

[Note 306](306-a-final-gap-cap-is-exactly-a-rooted-crossed-linkage.md)
proves the rooted cap when the final gap has at most one
missing ordinary link. Notes
[307](307-a-backward-port-before-the-last-vacancy-has-a-rooted-cap.md)
and [308](308-a-rooted-final-cap-shields-arbitrarily-many-prefix-ports.md)
handle selected larger patterns. If the port at the left
boundary of the final gap has only one vacancy in its own
component, the second missing link can be placed anywhere.

Use the compressed, gapless, tight-target all-square opening
of Notes 275--308 and an actual Barnette parent. Let
\(B_v,B_u\) be vacant, with \(u\ge v+3\). Assume
\[
 I_vH_u,\qquad P_{u-1}=e_{u-1}o_u                 \tag{1}
\]
belong to the complementary matching. Suppose \(P_v\)
is missing and its component contains exactly one
vacancy \(V_t\), so Note 278's noncrossing port
classification gives
\[
 v+2\le t\le u-1,\qquad
 e_vI_t,\quad o_{v+1}H_t\in M.                    \tag{2}
\]
Among the remaining links
\(P_{v+1},\ldots,P_{u-2}\), at most one,
say \(P_s\), is missing. Vacancies in other components
may be arbitrarily numerous, subject to the actual
Barnette parent and the fixed edges.

**One-vacancy two-defect cap theorem.** There is always
a path
\[
 D:e_{u-1}\leadsto b_{u-1},\qquad
 V(D)=\{e_v,b_v\}\cup
       \bigcup_{k=v+1}^{u-1}V(B_k).               \tag{3}
\]
Thus this entire two-defect class satisfies Note 305's
cap interface. Under its remaining outer hypotheses,
the free group has spanning \(S,K,X\) states, the parent
has a Hamilton cycle through both site edges, and the
legal expanded child is Hamiltonian.

**Proof when \(s\ne t\).** Put
\(G=B_{v+1},\ldots,B_{t-1}\) and
\(J=B_{t+1},\ldots,B_{u-1}\). The interval \(G\)
is nonempty. Whenever \(G\) has the crossed
two-path state, write its paths as
\[
 X_{\rm top}(G):a_{v+1}\leadsto b_{t-1},
 \qquad
 X_{\rm bottom}(G):o_{v+1}\leadsto e_{t-1}.
\]
They are disjoint and span \(G\). Then
\[
\begin{split}
 U:\quad b_v,a_{v+1}
 &\xrightarrow{X_{\rm top}(G)}b_{t-1},e_{t-1}
 \xrightarrow{X_{\rm bottom}(G)^{-1}}o_{v+1},
 H_t,o_t,a_t,b_t
\end{split}                                                   \tag{4}
\]
is a path from \(b_v\) to \(b_t\) spanning
\(B_{v+1},\ldots,B_t\) except \(I_t,e_t\).
The fold \(b_{t-1}e_{t-1}\) and the last two
joins in \(B_t\) are old-cycle edges, while
\(o_{v+1}H_t\) is fixed by (2). In particular,
(4) never uses \(P_{t-1}\).

If \(s<t-1\), the link \(P_s\) is internal to
\(G\), while both its boundary slots are already
matched to the exterior: \(o_{v+1}\) to \(H_t\)
and \(e_{t-1}\) to \(o_t\). All nonboundary
matching slots of \(G\) lie inside the chord
\(o_{v+1}H_t\). A mate outside that chord would
cross it in the opposite-side disk, so these
slots are matched internally. Note 288's
boundary-local one-defect theorem gives \(X(G)\).
If \(s=t-1\), every internal link of \(G\) is
retained, so its elementary crossed rails give
\(X(G)\), even though \(P_{t-1}\) is missing.
If \(s>t\) or no second link is missing, all
internal links of \(G\) are retained and the
same elementary rails apply.

Set
\[
 A:\quad e_t,I_t,e_v,b_v\xrightarrow{U}b_t.      \tag{5}
\]
It covers \(e_v,b_v\) and every block through
\(B_t\). If \(J=\varnothing\), set \(D=A\).
Otherwise \(P_t\) is retained because \(s\ne t\).
Whenever \(J\) has \(X(J)\), set
\[
 D:\quad e_{u-1}
 \xrightarrow{X_{\rm bottom}(J)^{-1}}o_{t+1},
 e_t\xrightarrow{A}b_t,a_{t+1}
 \xrightarrow{X_{\rm top}(J)}b_{u-1}.             \tag{6}
\]
The joins are the retained \(P_t\) and the
old-cycle edge \(b_ta_{t+1}\). The two paths
of \(X(J)\) span \(J\) and are disjoint from
\(A\), proving (3).

If \(s\le t-1\) or no second link is missing,
all internal links of \(J\) are retained and its
elementary crossed rails give \(X(J)\).
If \(s>t\), \(P_s\) is its only internal missing
link. The fixed chords \(e_vI_t,I_vH_u\)
separate its interior slots from earlier and
later free slots: a matching edge to a slot
before \(I_t\) crosses one of these chords,
and an edge to a slot after \(H_u\) crosses
\(I_vH_u\). There is no free slot between the
consecutive vertices \(I_v,e_v\); the only
boundary slots \(e_t,o_u\) are already matched
by \(P_t,P_{u-1}\). Thus its nonboundary
matching slots are matched internally, and
Note 288's boundary-local theorem gives \(X(J)\).
This completes every case \(s\ne t\).

**Proof when \(s=t\).** Here \(P_t\) is the
second missing link. Its vacancy component
lies entirely to the right of \(V_t\).
Indeed, a matching edge from either port slot
\(e_t,o_{t+1}\) to a vacancy before \(B_t\)
would cross the fixed chord \(o_{v+1}H_t\)
or \(e_vI_t\); a vacancy after \(B_u\)
would require crossing \(I_vH_u\).
Note 278 therefore makes it a right end-port
component
\[
 P_t<V_{w_1}<\cdots<V_{w_m}=V_w,
 \qquad t+2\le w\le u-1.                           \tag{7}
\]
All ordinary links other than \(P_v,P_t\)
are retained. Equation (4), now with the
elementary \(X(G)\), gives a path \(U_1\)
from \(b_v\) to \(b_t\) omitting \(I_t,e_t\).
Note 286(6)--(8) gives a right continuation
\(U_2:b_t\leadsto b_w\) spanning
\(B_{t+1},\ldots,B_w\) except \(I_w,e_w\);
its source block is used only at \(b_t\).
Let \(A_1\) be (5) with \(U_1\), and put
\[
 A_2:\quad e_w,I_w,e_t
       \xrightarrow{A_1}b_t
       \xrightarrow{U_2}b_w.                       \tag{8}
\]
The edge \(e_tI_w\) is the outer chord of
(7). By the disjoint vertex inventories,
\(A_2:e_w\leadsto b_w\) covers exactly
\(e_v,b_v\) and all blocks
\(B_{v+1},\ldots,B_w\). If \(w=u-1\),
take \(D=A_2\). Otherwise fold the all-retained
suffix \(B_{w+1},\ldots,B_{u-1}\) around
\(A_2\) as in (6), replacing \(t\) by \(w\).
This is Note 303's two-component cap recurrence
and proves (3). \(\square\)

The hardest boundary case \(s=t-1\), with a
backward port whose vacancy is adjacent to
\(B_v\), has the explicit 56-vertex Barnette
parent and 60-vertex legal Hamiltonian child
of Note 307(14)--(17). Thus the theorem
applies beyond a formal matching interface.
It is conditional on the stated opening and
one-vacancy component; it does not settle
every rooted cap or Barnette's conjecture.
