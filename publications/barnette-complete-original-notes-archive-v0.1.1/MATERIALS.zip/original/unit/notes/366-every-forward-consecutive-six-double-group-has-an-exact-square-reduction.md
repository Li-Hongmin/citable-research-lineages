> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every forward consecutive six-double group has an exact square reduction

[Note 358](358-six-alternating-double-blocks-reduce-to-one-global-first-return-branch.md)
classifies the first return of a consecutive forward six-double
group, and [Note 361](361-every-consecutive-forward-six-double-group-has-a-spanning-route.md)
closes its last spanning-route branches. The exact four-terminal
results of Notes 335, 346--347, and 362--365 strengthen that
route statement to a reduction statement without a hypothesis
on vacancies outside the group.

Work in the compressed, gapless, tight-target all-square opening
of Note 358. Let an ordinary target-free free group consist of
exactly six consecutive doubly vacant blocks
\[
D_s=(a_s,o_s,h_s,i_s,k_s,j_s,e_s,b_s),
                 \qquad 1\le s\le6,                         \tag{1}
\]
with no short block and prescribed common-face chords
\(i_se_s\) for odd \(s\), \(o_sk_s\) for even \(s\).
The group has ordinary endports \(L,R\) and the forward
orientation word \(J_3,J_1,J_3,J_1,J_3,J_1\).

**Six-double square-reduction theorem.** Every complementary
matching actually occurring in a Barnette parent under (1)
contains an induced disk patch on two, four or six consecutive
blocks with the exact Hamilton single-path and two-path
four-terminal signature of a square. Substituting the square
in either direction preserves Barnette class membership and
every Hamilton decision on exterior and attachment edges.
The reduction needs no assumption on the placement of vacancies
outside the group. Each of the listed induced disk patches is
also excluded, on its own, from any vertex-minimal
non-Hamiltonian Barnette graph.

**Exhaustion.** Note 358 (2) restricts the mate of \(h_1\)
to \(j_2,j_4,o_5,j_6,R\). Its proofs give the following
exact square-equivalent patches in the first, second, third
and fifth branches:

| Mate of \(h_1\) | Patch supplied by the matching | Exact signature source |
| --- | --- | --- |
| \(j_2\) | \(D_1D_2\) | Note 335 |
| \(j_4\) | \(D_1\ldots D_4\) | Notes 346--347 |
| \(o_5\) | \(D_5D_6\) | Note 335 |
| \(R\) | \(D_3D_4\), \(D_5D_6\), or \(D_3\ldots D_6\) | Notes 335--347, as selected in Note 358 |

In the remaining \(h_1j_6\) branch, Notes 359--361
restrict the mate of \(k_1\) to
\(j_3,i_2,i_4,i_6\); \(k_1j_5\) is impossible.
For each surviving mate, the complete reduction is:

| Mate of \(k_1\) | Patch supplied by the matching | Exact signature source |
| --- | --- | --- |
| \(j_3\) | all six blocks | Note 364 |
| \(i_2\), local-square subbranches | \(D_3D_4\) | Notes 335 and 360 |
| \(i_2\), standard nonlocal subbranch | all six blocks | Note 346 at \(N=6\) |
| \(i_2\), swapped nonlocal subbranch | all six blocks | Note 365 |
| \(i_4\) | all six blocks | reflection in Note 365 |
| \(i_6\) | all six blocks | Note 362 |

The tables exhaust actual matchings by the cited
noncrossing, parity, old-edge and two-edge-cut arguments.
Every listed patch has four distinct degree-two terminals
and its cited proof gives all four colour-permitted spanning
single paths and both noncrossing spanning two-path pairings.
Those proofs also establish the four-attachment deletion
comparison, so substitution preserves three-connectivity as
well as planarity, cubicity, bipartiteness and simplicity.
Each patch has at least 16 vertices and its square replacement
has four. If a smallest non-Hamiltonian Barnette graph
contained any one of these induced disk patches, substituting
it would give a smaller non-Hamiltonian Barnette graph,
a contradiction.
\(\square\)

The theorem is limited to one ordinary target-free group with
six consecutive forward alternating double blocks in the
specified all-square opening. It does not cover short corridors,
other orientation words, other opening types, or general
Barnette graphs. The constituent proofs are project-internal
and have not had an independent external review.
