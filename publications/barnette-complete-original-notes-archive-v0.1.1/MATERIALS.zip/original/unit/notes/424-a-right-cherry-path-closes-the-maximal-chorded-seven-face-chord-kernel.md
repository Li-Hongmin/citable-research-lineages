> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A right-cherry path closes the maximal chorded seven-face-chord kernel

The last word in [Note 421](421-maximal-chorded-seven-face-chord-failures-reduce-to-four-outer-words.md), equation (12), row 4, has a spanning route that does not use any face-side main chord. The route depends only on its three rightmost leaves; its left subtree may have arbitrary size and matching structure.

Let \(U_i=((x_i y_i))\) have old-cycle order \(L_i,h_i,x_i,y_i,j_i,R_i\), and let \(F(P,Q)=(((P Q)))\) have opening brackets \(\lambda_0,\lambda_1,\lambda_2\), closing brackets \(\rho_2,\rho_1,\rho_0\), and outer vertices \(F_\ell=\lambda_0,F_r=\rho_0\). Parenthesis pairs are ordinary matching chords. For any nonempty word \(A\) occupying one consecutive old-cycle interval, write \(\overleftarrow A\) for the reverse old-cycle path from \(A_r\) to \(A_\ell\), including every vertex of \(A\).

**Right-cherry path lemma.** Put
\[
E=F(U_6,U_7),\qquad B=F(U_5,E),\qquad W=F(A,B).
\tag{1}
\]
Regardless of the chords internal to \(A\) and regardless of the matching on the special positions of \(W\), the old-cycle edges and ordinary parenthesis chords contain a spanning \(y_6\)--\(x_7\) path of \(W\). The same construction works for every size of \(A\).

Set
\[
Y_6=(y_6,x_6,h_6,j_6,R_6,L_6),\quad
O_5=(L_5,h_5,x_5,y_5,j_5,R_5),\quad
X_7=(R_7,L_7,h_7,j_7,y_7,x_7).
\tag{2}
\]
The promised path is
\[
\begin{aligned}
y_6&\xrightarrow{Y_6}L_6,
\lambda_2^E,\lambda_1^E,E_\ell,
R_5\xrightarrow{O_5^{-1}}L_5,
\lambda_2^B,\lambda_1^B,B_\ell,
A_r\xrightarrow{\overleftarrow A}A_\ell,\\
&\lambda_2^W,\lambda_1^W,W_\ell,W_r,\rho_1^W,\rho_2^W,
B_r,\rho_1^B,\rho_2^B,
E_r,\rho_1^E,\rho_2^E,
R_7\xrightarrow{X_7}x_7.
\end{aligned}
\tag{3}
\]
Every junction in (3), except \(W_\ell W_r\), joins consecutive old-cycle vertices. Indeed the left side of \(E\) follows \(U_5\), the left side of \(B\) follows \(A\), and the right sides of \(W,B,E\) respectively follow \(B,E,U_7\); reading these incidences backwards gives exactly the displayed junctions. The edge \(W_\ell W_r\) is the outer ordinary chord of \(W\). The three paths in (2) use only old-cycle edges and the ordinary chords \(h_6j_6,L_6R_6,L_7R_7,h_7j_7\). Thus (3) uses no face-side matching edge.

The left and right bracket triples of \(E\) occur once each, as do those of \(B\); all six brackets of \(W\) occur once. The three leaves contribute eighteen vertices, and \(\overleftarrow A\) contributes every vertex of \(A\) once. These sets are disjoint and exhaust the \(|A|+36\) vertices of \(W\), proving the lemma. \(\square\)

**Sibling-site path theorem.** Let \(U_j,U_{j+1}\) be sibling six-vertex leaves \(((x y))\) in any nested binary matching word. Each branch may have any positive number of nested ordinary wrapper pairs; write \(F_r(P,Q)\) for a branch with \(r\ge1\) pairs. Then the entire word has a spanning \(y_j\)--\(x_{j+1}\) path using only old-cycle edges and ordinary parenthesis chords. The path contains the outer chord of the root and is independent of all face-side matchings and of the siblings' position in the tree.

For the base subtree \(S=F_s(U_j,U_{j+1})\), use \(Y_j\), its opening brackets from innermost to outermost, the outer chord \(S_\ell S_r\), its closing brackets from outermost to innermost, and \(X_{j+1}\). Suppose the path for a subtree \(S\) contains \(S_\ell S_r\). At its parent, replace just that edge by one of two routes, according to the child's side:
\[
\begin{array}{ll}
F_r(A,S):& S_\ell,A_r\xrightarrow{\overleftarrow A}A_\ell,
 \lambda_{r-1},\ldots,\lambda_0,\rho_0,\ldots,\rho_{r-1},S_r,\\
F_r(S,B):& S_\ell,\lambda_{r-1},\ldots,\lambda_0,
 \rho_0,\ldots,\rho_{r-1},B_r\xrightarrow{\overleftarrow B}B_\ell,S_r.
\end{array}
\tag{4}
\]
In each route the three joins between subwords and parent brackets follow consecutive old-cycle vertices; \(\lambda_0\rho_0\) is the new root's outer chord. The route adds every vertex of the sibling word and parent wrappers once, while retaining the old path's two endpoints. Induction from the sibling subtree to the root proves the assertion. Formula (3) is the instance in which the sibling subtree lies twice on the right spine. \(\square\)

**Consequence at the first submaximal count.** Note 416's \(c=31\) normal form has thirteen marked or branching core nodes and eighteen plain wrappers, one fewer than the nineteen allowed at \(c=32\). Thus exactly one leaf or branch has one fewer ordinary wrapper. Suppose the two site leaves \(U_j,U_{j+1}\) are siblings. If the short wrapper belongs to either site leaf, their \(x\)-vertices have opposite old-cycle-index parities: both leaves have the same ancestor openings, while the missing leaf opening flips only one \(x\)-parity. The site edges \(w_0y_j,x_{j+1}w_*\) require both \(x_j,x_{j+1}\) to have even indices, so this case is impossible. If the short wrapper is elsewhere, both site leaves are full six-vertex leaves and the sibling-site path theorem supplies a spanning \(y_j\)--\(x_{j+1}\) path. The fixed outside route of Note 416 then gives a marked parent Hamilton cycle and a Hamiltonian child. Hence a non-Hamiltonian \(c=31\) child cannot have sibling site leaves anywhere in its tree.

**Maximal-kernel theorem.** In the chorded single-hexagon, seven-main-face-chord setting of Notes 416 and 421, every legal child whose doubly ladder-reduced representative has \(c=32\) ordinary chords is Hamiltonian. Therefore a non-Hamiltonian child in this setting, if one exists, must have reduced count \(c=31\).

To finish row 4 of Note 421 (12), take
\[
D=F(U_2,U_3),\qquad C_0=F(U_1,D),\qquad A=F(C_0,U_4).
\tag{5}
\]
This \(A\) has four leaves, three branches, and \(|A|=4\cdot6+3\cdot6=42\). Its row-4 word is exactly (1). Hence (3) spans all \(78\) vertices of \(W\), regardless of row 4's matching III. In the 90-vertex Barnette parent constructed in [Note 422](422-all-four-maximal-outer-words-have-legal-barnette-expansions.md), adjoin its two site edges and the twelve-vertex outside route
\[
w_0\xrightarrow{q}y_6\xrightarrow{(3)}x_7\xrightarrow{p}w_*,
z_R,t_b,b,a,\alpha,\beta,d,c,t_c,z_L,w_0.
\tag{6}
\]
This is a Hamilton cycle containing both \(q=w_0y_6\) and \(p=x_7w_*\). Clause 1 of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the 94-vertex child.

Now suppose a doubly reduced \(c=32\) child in the stated setting were non-Hamiltonian. Note 421 shows that, after reflection, its word must be row 1, 2, 4, or 5 of (12). [Note 423](423-three-maximal-outer-words-have-marked-hamilton-cycles.md) gives marked Hamilton cycles for rows 1, 2, and 5; (3), (5), and (6) give one for row 4. This is a contradiction. Reversing the two ladder reductions preserves Hamiltonicity by Note 410, so the conclusion also applies to the unreduced child. Finally Note 416 excludes \(c\le30\) for any hypothetical failure, leaving only \(c=31\). \(\square\)

This theorem covers the selected chorded single-hexagon \(f=7\) branch. It does not decide its \(c=31\) kernel, other selected openings, or Barnette's conjecture as a whole.
