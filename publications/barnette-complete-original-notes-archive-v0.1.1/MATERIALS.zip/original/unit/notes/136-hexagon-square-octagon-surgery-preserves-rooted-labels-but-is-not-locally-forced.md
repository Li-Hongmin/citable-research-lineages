> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Hexagon--square octagon surgery preserves rooted labels but is not locally forced

[Note 135](135-a-plane-brace-common-cycle-counterexample-leaves-rooted-cell-restricted-cyclability.md)
shows that ordinary three-edge cyclability in a plane brace cannot supply
the rooted new-cell matching required by the split-bond problem.  There is,
however, a local configuration in which the root condition is preserved
identically.  This note proves that surgery and gives the exact local
boundary of its applicability.

## 1. The hexagon--square patch

Let \(G\) be a plane cubic graph.  Let

\[
 H=x_0x_1x_2x_3x_4x_5x_0
\tag{1}
\]

be a facial hexagon, with alternating edges

\[
 p=x_0x_1,\qquad q=x_2x_3,\qquad r=x_4x_5.
\tag{2}
\]

Suppose the other face incident with \(r\) is the square

\[
 Q=x_4x_5y_5y_4x_4,
\tag{3}
\]

and \(H\cap Q=r\).  Then

\[
 C_8=\partial H\mathbin\triangle\partial Q
 =x_0x_1x_2x_3x_4y_4y_5x_5x_0
\tag{4}
\]

is a simple octagon.

Let \(M\) be a perfect matching with \(p,q\in M\), and suppose that
\(C_8\) is \(M\)-alternating.  Put

\[
 F=M\mathbin\triangle E(C_8).
\tag{5}
\]

Perform the standard \(C_4\)-expansion at \(p,q\), oriented into \(H\),
and let \(F^R\) be the \(R_{00}\)-extension of \(F\).

**Theorem 1 (rooted octagon surgery).**  The set \(F^R\) is a perfect
matching of the child.  The complementary two-factors of \(M\) in \(G\)
and of \(F^R\) in the child have canonically identical component incidence
outside \(H\cup Q\).  Consequently:

1. if \(M\) is root-admissible and its root matching edge \(e\) avoids
   \(E(C_8)\), then \(F^R\) is root-admissible with the same ordered
   root-component labels;
2. a forced matching edge \(g_0\in M\setminus E(C_8)\) remains in \(F^R\);
3. for every retained surviving-gate edge \(g_1\),

   \[
   \mathbf 1_{g_1\in F^R}=\mathbf 1_{g_1\in M}
   \quad\Longleftrightarrow\quad
   g_1\notin E(C_8).
   \tag{6}
   \]

Thus root admission requires only root-edge avoidance.  Preservation of
the surviving-gate sector requires the additional sharp condition
\(g_1\notin E(C_8)\).

## 2. The six-port identity

The state-\(11\) condition fixes the alternating phase on \(C_8\):

\[
 M\cap E(C_8)
 =\{x_0x_1,x_2x_3,x_4y_4,x_5y_5\}.
\tag{7}
\]

In particular \(r\notin M\), while

\[
 F\cap E(C_8)
 =\{x_1x_2,x_3x_4,y_4y_5,x_5x_0\}.
\tag{8}
\]

The disk \(H\cup Q\) has six exterior ports, at
\(x_0,x_1,x_2,x_3,y_4,y_5\).  Denote their exterior edges by
\(a_0,a_1,a_2,a_3,b_4,b_5\).  Inside the disk, the complement of \(M\)
consists of the three paths

\[
\begin{aligned}
 a_0&-x_0-x_5-x_4-x_3-a_3,\\
 a_1&-x_1-x_2-a_2,\\
 b_4&-y_4-y_5-b_5.
\end{aligned}
\tag{9}
\]

Hence it induces the port pairing

\[
 \Pi_M=\bigl\{\{a_0,a_3\},\{a_1,a_2\},\{b_4,b_5\}\bigr\}.
\tag{10}
\]

Write the two subdivided site paths as

\[
 x_0-A-B-x_1,\qquad x_2-C-D-x_3,
\tag{11}
\]

and add the cross edges \(AD,BC\).  The \(R_{00}\) patch matching is
\(\{AB,CD\}\).  The complement of \(F^R\) inside the enlarged disk has
the paths

\[
\begin{aligned}
 a_0&-x_0-A-D-x_3-a_3,\\
 a_1&-x_1-B-C-x_2-a_2,\\
 b_4&-y_4-x_4-x_5-y_5-b_5.
\end{aligned}
\tag{12}
\]

Therefore

\[
 \boxed{\Pi_{F^R}=\Pi_M.}
\tag{13}
\]

Suppressing internal degree-two vertices gives identical connectors in
the two complementary two-factors.  Neither local complement contains a
closed component, so (13) preserves both the number of global components
and every ordered exterior component label.  This proves Theorem 1.
Reversing the facial orientation only relabels and reverses the paths in
\((9)\) and \((12)\).

The mark conditions in Theorem 1 are exact.  Every vertex of \(C_8\) is
already matched by (7), so a matching edge outside \(E(C_8)\) cannot touch
the local disk.  An edge on \(C_8\), on the other hand, is toggled by
(5).  Thus a root or forced edge on \(C_8\) leaves its required fibre, and
a surviving gate on \(C_8\setminus\{p,q\}\) changes sector.

## 3. Pure-\(11\) bonds do not force the octagon

Fix \(p,q\) in a state-\(11\) matching.  On the four remaining local
vertices there are exactly three perfect-matching patterns:

\[
\begin{aligned}
 X&=\{x_4y_4,x_5y_5\},\\
 T&=\{r,y_4y_5\},\\
 P&=\{r,b_4,b_5\}.
\end{aligned}
\tag{14}
\]

Here \(b_4,b_5\) denote the two square-side port edges.  The unique phase
of \(C_8\) containing \(p,q\) gives

\[
 C_8\text{ is }M\text{-alternating}
 \iff M\text{ has type }X
 \iff r\notin M.
\tag{15}
\]

For two state-\(11\) endpoints, the nontrivial local difference traces are

\[
 X\mathbin\triangle T=\partial Q,
 \qquad
 X\mathbin\triangle P=\text{one square-port path},
 \qquad
 T\mathbin\triangle P=\text{one square-port path}.
\tag{16}
\]

The last trace gives a strict local countermodel to endpoint selection.
Join its two exposed port ends by one exterior alternating connector.  The
result is a single alternating cycle avoiding \(p,q\); an edge of the
connector may be the surviving gate.  Both endpoints are nevertheless of
types \(T,P\), so neither alternates on \(C_8\).  This construction retains
cubic incidence at every patch vertex and actual local perfect-matching
incidence.  It is a port countermodel, not an actual rooted plane-brace
counterexample.

The exact two-endpoint identities are

\[
 r\in M_0\mathbin\triangle M_1
 \iff\text{exactly one endpoint has type }X,
\tag{17}
\]

and

\[
 \exists i:\ C_8\text{ is }M_i\text{-alternating}
 \iff r\notin M_0\cap M_1.
\tag{18}
\]

Thus requiring the bond cycle to contain \(r\) is sufficient for the
surgery, but not necessary because an \(X\)--\(X\) bond selects both
endpoints while avoiding \(r\).

## 4. Consequence for rooted split-bond supplementation

Whenever a pure-\(11\) parent bond has an endpoint of type \(X\) and the
required marks avoid \(C_8\), Theorem 1 constructs a root-admissible
\(R_{00}\) child matching.  Hence this local configuration proves new-cell
unary occupancy.  If the surviving gate also avoids \(C_8\), the supplier
lies in the same gate sector as the chosen endpoint.

Equations (14)--(18) show that the existence of a pure-\(11\) bond does not
locally force such an endpoint.  The remaining selection statement must
therefore use the complete perfect-matching family of the actual rooted
plane brace; local patch incidence and one-cycle extendibility are
insufficient.  Even successful unary occupancy does not by itself prove
the rooted split-bond lemma: full child supplementation still requires an
opposite-sector root-admissible partner whose symmetric difference is one
gate-changing cycle.
