> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Facial square traps form bouquet lobes with disjoint merger squares

The escape network of [Note 176](176-alternating-facial-arcs-create-one-residual-cycle-per-matching-edge.md)
is connected and outerplanar, but that alone does not give a Hamilton
opening. When every residual component of the literal facial
opening is a square, its internal mergers have an exact form.

Use the notation \(C,M,p,q,P,h_i,m_i,S_0,\ldots,S_k,J(P)\)
of Note 176. Assume \(G\) is simple, cubic, plane and
3-edge-connected, \(k\ge1\), and every trapped \(C\)-segment
\(S_i\), \(1\le i\le k\), has exactly four vertices. Write its
directed \(C\)-path as
\[
S_i:\quad \alpha_i,a_i,b_i,\beta_i,
\qquad m_i=\beta_i\alpha_i.
\tag{1}
\]
The literal facial opening has \(k\) residual squares
\(\alpha_i a_i b_i\beta_i\alpha_i\), besides the component
\(S_0\) containing the new square.

**Bouquet and merger theorem.** The escape network \(J(P)\)
is a bouquet of cycles meeting only at \(S_0\). Each cycle
contains a consecutive block \(S_a,S_{a+1},\ldots,S_b\) of
residual vertices in their \(C\)-order. For \(a<b\), the
two edges to \(S_0\) use \(a_a\) and \(b_b\), respectively,
and every internal escape edge \(S_iS_{i+1}\), \(a\le i<b\),
is precisely \(b_i a_{i+1}\). For \(a=b\), the two edges to
\(S_0\) use \(a_a\) and \(b_a\). Together with the cut \(C\)-edge
\(h_i=\beta_i\alpha_{i+1}\), it forms the
\(M_P\)-alternating square
\[
Q_i=\beta_i,b_i,a_{i+1},\alpha_{i+1},\beta_i,
\tag{2}
\]
where \(M_P\) is the perfect matching complementary to the
literal opened 2-factor. All squares (2) over all blocks are
vertex-disjoint and are faces of \(G\). Flipping them, in any
order or simultaneously,
merges all residual squares in each block into one cycle and
leaves \(S_0\) unchanged. If the bouquet has \(\ell\) cycles,
the resulting child 2-factor has exactly \(\ell+1\) components.
Moreover \(\deg_{J(P)}(S_0)=2\ell\) and
\(|E(J(P))|=k+\ell\).

**Proof.** The endpoints \(\alpha_i,\beta_i\) are already
matched to each other by \(m_i\). The interior vertices
\(a_i,b_i\) are adjacent along \(C\), so simplicity prevents
their matching edge from joining them. Their two matching edges
must leave \(S_i\). Consequently \(\deg_{J(P)}(S_i)=2\).
By Note 176, \(J(P)\) is connected and noncrossing on the
opposite side of \(C\). Removing \(S_0\) leaves path components:
a cycle disjoint from \(S_0\) could not reconnect without a
residual vertex of degree at least three. Each path plus its
two edges to \(S_0\) is a cycle, with a single residual vertex
and two parallel edges allowed.

The residual vertices of each cycle form a consecutive block
on the boundary. For a cycle with at least two residual vertices,
the noncrossing drawing visits its own vertices in their cyclic
boundary order: otherwise two of its edges have interlacing
endpoints. If two successive residual vertices along that cycle
enclosed another residual vertex on the boundary arc avoiding
\(S_0\), their joining edge would separate that vertex from
\(S_0\). Its path in \(J(P)\) to \(S_0\) would have to cross
the edge, unless it met the cycle first; meeting the cycle
would put it in the same path component of \(J(P)-S_0\),
contrary to the choice of successive cycle vertices. Thus
there is no gap. A one-residual cycle is already a singleton
block. Thus each path visits its consecutive block in boundary
order.

For a block with at least two residual vertices, the two
escape edges at each \(S_i\) run to opposite sides of its
four-vertex boundary interval. The earlier edge must use
\(a_i\) and the later edge \(b_i\): the reverse assignment
would interlace the four chord endpoints. This gives the
claimed \(S_0\)-attachment vertices and the internal edge
\(b_i a_{i+1}\). For a singleton block, both \(a_i\) and
\(b_i\) must connect to \(S_0\), since they are its only
unmatched vertices. The four edges of (2) now exist.
Its edges \(\beta_i b_i\) and \(a_{i+1}\alpha_{i+1}\)
belong to the opened 2-factor; its other two edges
\(b_i a_{i+1}\) and \(h_i\) belong to \(M_P\).
The square is alternating and its 2-factor edges lie in
different residual components, so its flip merges them.
It is facial in \(G\): on the side opposite the chosen common
face, its chord \(b_i a_{i+1}\) cuts off the \(C\)-arc
\(b_i,\beta_i,\alpha_{i+1},a_{i+1}\). The two intermediate
vertices have their matching edges \(m_i,m_{i+1}\) on the
other side of \(C\), and there are no other vertices in this
arc. As \(C\) is spanning, the cut-off disk is empty.

Squares for consecutive internal block edges use
\(\{\alpha_i,a_i\}\) and \(\{b_i,\beta_i\}\) on their
shared residual segment, respectively; these sets are
disjoint. Different blocks have disjoint residual segments.
The flips therefore commute. Within one block the selected
intercomponent links form the path
\(S_aS_{a+1}\cdots S_b\). After any subset of its square
flips, the current components are exactly the connected
components of that selected path. Thus each next flip still
merges two distinct cycles. A block of \(b-a+1\) residual
squares has \(b-a\) internal merger squares and becomes one
cycle. Summing over the \(\ell\) blocks leaves one residual
cycle per block plus \(S_0\). Each block contributes exactly
two edges at \(S_0\), yielding \(\deg_J(S_0)=2\ell\);
the degree sum gives \(|E(J)|=k+\ell\). \(\square\)

**One-lobe Hamiltonicity criterion.** Suppose \(\ell=1\),
so the block is \(S_1,\ldots,S_k\). Let \(g\) be its
escape edge between \(S_0\) and \(S_1\), whose residual
endpoint is \(a_1\). If the other endpoint \(t\in S_0\)
is adjacent to the facial port \(z_0\) along the opened
2-factor, then
\[
z_0,\alpha_1,a_1,t,z_0
\tag{3}
\]
is an alternating square. After the internal flips (2),
the factor edges \(z_0t\) and \(\alpha_1a_1\) are still present:
the internal squares use neither. They lie in the two remaining
components, so flipping (3) joins them and yields a Hamilton
cycle of the child. The symmetric criterion uses the escape
edge at \(b_k\) and the port \(z_{2k+1}\). For \(k=1\), the
two parallel \(S_0S_1\) edges give these two respective tests.

**Short-main-segment corollary.** Assume in addition that \(G\) is
bipartite, \(\ell=1\), and \(|V(S_0)|\le8\), where \(S_0\) counts only
old vertices. Then \(|V(S_0)|=8\), both end merger squares exist,
and the square-expanded child has at least two Hamilton cycles.
This holds for every \(k\ge1\).

**Proof.** Write the old vertices of \(S_0\) in \(C\)-order as
\(w_0=x,w_1,\ldots,w_{s-1}=v=z_0\), with \(s=|V(S_0)|\).
The other site ports occur in the order \(x,y,u,v\), by the
facial boundary order of Note 176. Since \(p=uv\) and \(q=xy\)
are matching edges in a simple graph, neither can join adjacent
vertices of \(C\). Hence \(y\ne w_1\) and \(u\ne w_{s-2}\).
The trapped segments have even order and \(G\) is bipartite,
so \(s\) is even. Along \(S_0\), \(y\) has odd index, being
opposite in colour to \(x\), whereas \(u\) has even index,
being opposite in colour to \(v\). With \(s\le8\), the site
order and the two nonadjacency conditions rule out \(s=4,6\).
For \(s=8\), they force
\[
 x=w_0,\quad y=w_3,\quad u=w_4,\quad v=w_7.
\tag{4}
\]

Let \(t_L\) be the \(S_0\) endpoint of the escape edge at
\(a_1\), and \(t_R\) the endpoint of the escape edge at
\(b_k\). The vertices \(a_1\) and \(b_k\) have, respectively,
the colours opposite to and equal to that of \(x\). Thus
\(t_L\) has even \(S_0\)-index and \(t_R\) odd index. Neither
is a site port, since all site ports are already matched by
\(p,q\). Consequently (4) gives
\[
t_L\in\{w_2,w_6\},\qquad t_R\in\{w_1,w_5\}.
\tag{5}
\]
The two escape chords \(a_1t_L\) and \(b_kt_R\) are
noncrossing. Since \(a_1\) precedes \(b_k\) on \(C\), their
endpoints on the \(S_0\)-arc occur in reverse order:
\(t_R\) precedes \(t_L\). The only possibilities in (5) are
\((t_R,t_L)=(w_1,w_2),(w_1,w_6),(w_5,w_6)\).
The two \(S_0\)-vertices besides the four ports and
\(t_R,t_L\) must be matched to each other: the bouquet has
exactly two escape edges incident with \(S_0\). In the first
and third possibilities they are, respectively,
\(w_5,w_6\) and \(w_1,w_2\), adjacent on \(C\). Their matching
edge would duplicate a \(C\)-edge, contrary to simplicity.
Therefore \(t_R=w_1\) and \(t_L=w_6\). Both are adjacent to
their corresponding ports \(x\) and \(v\) in the opened
2-factor. After the internal flips, the two end squares are
vertex-disjoint and each separately merges the two remaining
cycles. Their flips give two distinct Hamilton cycles.
\(\square\)

The theorem supplies all internal mergers under the square
trap hypothesis. It does not force the final adjacency in
(3), and a required or forbidden edge on a chosen merger
square may prevent that flip. The even-prism interpolation
of [Note 172](172-unbounded-nonlocality-of-joint-hamilton-witness-transfer.md)
is the one-lobe case with the final adjacency present.
