> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# No short corridor after the middle block of an alternating triple

[Note 337](337-every-consecutive-j1-j3-three-double-group-reduces-to-a-square.md)
classifies three adjacent \(J_1/J_3\) double blocks, and
[Note 340](340-a-k-block-corridor-before-an-alternating-triple-has-exactly-k-matching-types.md)
classifies a positive short-block corridor before the middle
block of a \(J_1,J_3,J_1\) triple. A corridor after the
middle block cannot occur, even if another corridor precedes it.
This completes the two internal-corridor positions for
the alternating triple with no other nonshort complete block.

Use the compressed, gapless, tight-target all-square opening
of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
In one ordinary target-free free group, take three double blocks
in old-cycle order
\[
\begin{split}
D_1&=(a,o,h,i,k_0,j,e,b),\\
D_2&=(A,O,H,I,K,J,E,B),\\
D_3&=(\hat a,\hat o,\hat h,\hat i,\hat k,\hat j,\hat e,\hat b),
\end{split}                                                     \tag{1}
\]
with internal chords \(ok_0=J_1,IE=J_3,\hat o\hat k=J_1\).
There may be \(p\ge0\) short blocks
\(S_t=(c_t,o_t,e_t,d_t)\) between \(D_1,D_2\), and
\(q\ge1\) short blocks \(T_s=(c'_s,u_s,v_s,d'_s)\)
between \(D_2,D_3\). All other complete blocks, if any,
are short and lie outside this interval.

**Forbidden-position theorem.** No Barnette graph realizes
this selected opening for \(q\ge1\), regardless of \(p\) and
the outer short flanks. By old-cycle reflection, a
\(J_3,J_1,J_3\) triple cannot have a positive corridor
between its first two double blocks.

**Proof.** Chord isolation from
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
excludes all other same-block free chords. By
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
cross-block free chords lie opposite the common face and
form a noncrossing matching. After the three internal chord
pairs are removed, the core free-slot order is
\[
h,i,j,e,(o_t,e_t)_{t=1}^{p},O,H,K,J,
(u_s,v_s)_{s=1}^{q},\hat h,\hat i,\hat j,\hat e .        \tag{2}
\]
The odd/even colours in each short block are respectively
\(o_t/e_t\) and \(u_s/v_s\).

The even slot \(h\) can meet only \(J\) or \(\hat i\).
Its same-block choices \(i,j\) are an old-cycle edge
and a forbidden isolated chord. Its other odd core
candidates are excluded by interval parity:
\(ho_t\) encloses \(3+2(t-1)\) free slots,
\(hO\) encloses \(3+2p\),
\(hu_s\) encloses \(7+2p+2(s-1)\), and
\(h\hat j\) encloses \(9+2p+2q\).
An odd slot in a left outer short flank encloses that
block's second slot plus complete flank pairs. A candidate
in the right outer flank or at the right endport encloses
\(11+2p+2q\) core slots after \(h\), plus complete pairs.
All these counts are odd.

Suppose \(hJ\). The even slot \(\hat h\) cannot reach
any odd slot inside \(hJ\) without crossing that chord.
The right-corridor candidate \(u_s\) is excluded because
the interval from \(u_s\) to \(\hat h\) contains \(v_s\)
and later complete short-block pairs, an odd count.
The same-block candidates \(\hat i,\hat j\) are an
old-cycle edge and a forbidden isolated chord. A left
outer-flank odd candidate encloses its block's second
slot, complete flank pairs and \(8+2p+2q\) core slots;
a right outer candidate or the endport encloses
\(\hat i,\hat j,\hat e\) plus complete pairs. They have
odd counts. Thus \(hJ\) leaves \(\hat h\) unmatched,
and \(h\hat i\) is forced.

Inside \(h\hat i\), the odd slot \(i\) can meet only
\(K\) or \(\hat h\). The same-block \(ie\) is forbidden;
\(iH\) encloses \(3+2p\) free slots. Each \(ie_t\)
or \(iv_s\) also encloses an odd number, and a mate
outside \(h\hat i\) would cross it. If \(i\hat h\)
occurred, the even slot \(K\) would have no mate:
\(jK\) encloses \(3+2p\) slots;
each \(o_tK\) encloses \(3+2(p-t)\);
each \(Ku_s\) encloses \(1+2(s-1)\).
The same-block \(OK\) is excluded by chord isolation
and \(KJ\) is an old-cycle edge. Every other candidate
lies outside \(i\hat h\) or crosses it. Hence \(iK\)
is forced.

The odd slot \(J\), now between \(K\) and \(\hat i\)
inside \(h\hat i\), can meet only \(\hat h\).
For \(Jv_s\), the intervening \(u_1,v_1,\ldots,u_s\)
are \(2s-1\) free slots, so parity forbids the chord.
An earlier mate inside \(iK\) would cross \(iK\);
\(K\) is already matched; an exterior mate would
cross \(h\hat i\). Therefore \(J\hat h\) is forced.

All \(2q\) free slots of the consecutive complete
right-corridor blocks \(T_1,\ldots,T_q\) lie strictly
inside \(J\hat h\). Noncrossing forces them to match
among themselves. Their face chords \(c'_sd'_s\) are
internal too. Thus the entire right corridor is
closed under the complementary matching, and exactly
its two boundary old-cycle edges \(Bc'_1\) and
\(d'_q\hat a\) leave it. This
contradicts three-edge-connectivity. \(\square\)

**Alternating-position corollary.** Under the same opening
and with exactly these three nonshort complete blocks,
all internal short blocks of a feasible
\(J_1,J_3,J_1\) triple lie between the first and
middle double blocks. With none, Note 337 forces its
single square-equivalent core. With \(p\ge1\),
Note 340 gives exactly \(p\) matching types, each
square-equivalent and realized in a Barnette graph.
For \(J_3,J_1,J_3\), reflection reverses the
permitted corridor position. The numbers of outer
short flanks are unrestricted. Consequently, none
of the feasible induced four-poles classified here
can occur in a vertex-minimal non-Hamiltonian
Barnette graph.

This excludes only the specified alternating internal
chords in an ordinary target-free group. Other double-block
direction orders with internal corridors, singly vacant
blocks in the same group, target defects, positive gaps,
non-square residual cycles and the general Barnette
conjecture are not decided here. The proof is project-internal;
no external priority or independent review is claimed.
