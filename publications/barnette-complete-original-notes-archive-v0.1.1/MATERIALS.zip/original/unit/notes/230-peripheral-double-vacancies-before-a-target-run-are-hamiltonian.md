> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Peripheral same-block double vacancies are Hamiltonian

[Note 229](229-concentrated-target-runs-admit-a-two-path-hamilton-route.md)
handles a run of occupied targets between two vacancies.
A different target-bearing shape places both vacancies
on the same side of every occupied target in their block.
The first target run then separates a one-sided free group;
its two vacancy pairs have only nested rainbow detours.

Work in a compressed all-square Barnette opening as in
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md),
with \(\ell,r\ge1\), empty interblock gaps, tight target
order and exactly two eligible vacancies. Suppose both
vacancies lie in a face-chord block \(D=B_k\),
\(1\le k\le r\), and \(D\) has at least one
occupied nonfinal target position. Assume the two
vacancies are its first two eligible positions.
Its interior old-cycle order begins
\[
o,h_1,i_1,h_2,i_2,
\ L_j,R_{j-1},L_{j-1},R_{j-2},\ldots,\ e,
\tag{1}
\]
where the displayed target run is nonempty;
\(h_1,h_2\) are the vacant even slots and
\(i_1,i_2\) their following odd slots.
Other blocks may have occupied target runs.
The reflected case, in which the vacancies
are the last two eligible positions of \(D\),
is included in the conclusion.

**Peripheral double-vacancy theorem.** The parent
has a Hamilton cycle containing both site edges
\(xy,uv\), and its legal site-expanded child is
Hamiltonian. The result holds for arbitrary
positive original lobe lengths. In the orientation
(1), the free matching group immediately before
the target run must contain at least two short
target-free face blocks; it has precisely two
independent three-edge detours.

**Target barrier.** Before the first occupied
\(L\)-target in \(D\), the number of free main slots
is even: one final slot of the left site block,
two in each earlier face block, and the five slots
\(o,h_1,i_1,h_2,i_2\) in \(D\). Earlier target
runs do not change this count. More explicitly,
the free-slot prefix before a run in \(B_j\) has
size \(2j\) for \(j<k\), \(2k+4\) for \(j=k\),
and \(2j+4\) for \(j>k\); the corresponding
counts in the two site blocks are \(0\) and
\(2r+6\). A cross-block free chord
cannot straddle this target by Note 203.
Within \(D\), only the final free slot \(e\)
lies after the nonempty occupied run, so at
most one same-block free chord could cross it.
The number of matching edges leaving an even
set is even; therefore none crosses the
target run. The identical argument at every
other occupied run closes the free matching
groups. The group ending at \(i_2\) has the form
\[
e_0,(o_1,e_1),\ldots,(o_t,e_t),
o,h_1,i_1,h_2,i_2, \qquad t\ge0,
\tag{2}
\]
where the \(t\) preceding face blocks are short.
The group starting at \(e\), and every other
group, is ordinary and follows the standard
chain by Note 208.

**Free matching classification.** In (2), for
some \(0\le d<a\le t-1\), the matching is
\[
\begin{split}
&\{e_j o_{j+1}:0\le j\le t,\ j\notin\{d,a\}\}\\
&\quad\cup\{e_di_2,\ o_{d+1}h_2,\
             e_ai_1,\ o_{a+1}h_1\},
\qquad o_{t+1}=o.
\end{split}                                           \tag{3}
\]
In particular \(t\ge2\).

To prove this, scan (2) from its first unmatched
even slot \(e_d\), after any preceding standard
links. An edge to a later first slot \(o_j\)
would enclose complete short blocks and make
a forbidden two-edge cut; the next first slot
\(o_{d+1}\) is the only ordinary choice.
If \(d=t\), matching \(e_to\) leaves the four
extra slots, whose only non-cycle internal pair
is \(h_1i_2\); \(i_1h_2\) is an old-cycle edge.
No matching is then possible.

An edge \(e_di_1\) is impossible. If at least
one short block remains, that opposite-side
chord encloses all its slots and \(o,h_1\).
The only same-block exits for \(o,h_1\)
are \(oh_2,h_1i_2\), respectively. Both
interlace \(e_di_1\), so they would have
to lie on the site-face side, where they
interlace one another. At most one can
occur. Parity of the even number of short
slots then makes the number matched to
\(\{o,h_1\}\) either zero or two. Zero
would close a nonempty complete short-block
interval and give a two-edge cut; hence
both \(o,h_1\) match short slots. The remaining
\(h_2,i_2\) are adjacent on the old cycle
and cannot match. If no short block remains,
the only proposed completion is
\(oh_2,h_1i_2\); both interlace
\(e_di_1\), so they would both have to
lie on the site-face side, where they
interlace one another.

If \(d=t\), the last remaining choice
\(e_ti_2\) leaves \(o,h_1,i_1,h_2\).
Their only possible non-cycle pairing uses
\(oh_2\), after which \(h_1i_1\) is an
old-cycle edge. Thus the first nonstandard
edge is \(e_di_2\), with \(d<t\). Its opposite-side
chord encloses all remaining short slots
and \(o,h_1,i_1,h_2\). The only possible
same-block free chord still available is
\(oh_2\). If it occurred, the first
short-block odd slot \(o_{d+1}\) would
have to match \(h_1\): a match to a
later short-block even slot closes
a complete short-block interval, and
its own even slot is adjacent on the
old cycle. Then \(i_1\) must match
a short-block even slot \(e_j\), but
the opposite-side chords
\(o_{d+1}h_1,e_ji_1\) interlace.
Thus \(oh_2\) is absent. All remaining
free chords join different blocks and
lie in one noncrossing opposite-side disk.

The short-block skipping rule now makes
every ordinary-to-ordinary edge a
standard link. The first missing link
\(e_do_{d+1}\) has its endpoints
matched to \(i_2,h_2\); the latter
match \(o_{d+1}h_2\) is forced by
noncrossing and the two-edge-cut rule.
Indeed, a later ordinary even mate of
\(o_{d+1}\) would close complete short
blocks, while \(o_{d+1}h_1\) would
interlace every possible cross-block mate
of \(h_2\), since \(oh_2\) is absent.
The remaining \(i_1,h_1\) must use
the endpoints of exactly one other
missing link \(e_ao_{a+1}\), giving
\(e_ai_1,o_{a+1}h_1\). Here \(a>d\),
and \(a=t\) would require the
old-cycle edge \(oh_1\); hence
\(a\le t-1\). This proves (3).
The four long chords are nested in
the order
\[
e_di_2\supset o_{d+1}h_2
\supset e_ai_1\supset o_{a+1}h_1.
\tag{4}
\]

**Marked route.** In Note 196's ordinary free
\(x\)-to-\(v\) path, replace its two
chain edges \(e_do_{d+1}\) and
\(e_ao_{a+1}\) by, respectively,
\[
e_d,i_2,h_2,o_{d+1}
\quad\text{and}\quad
e_a,i_1,h_1,o_{a+1}.                           \tag{5}
\]
The outer edges of each detour lie in \(M\),
and \(i_2h_2,i_1h_1\) lie in the even-starting
old-cycle matching. The detours are
vertex-disjoint, so the free path stays
connected and spans all free slots.
The target-and-square \(x\)-to-\(v\)
path is unchanged. Their union is
a Hamilton cycle containing \(xy,uv\).
Note 001 lifts it through the legal
site expansion, and Note 178 restores
longer lobes. Reversing the old-cycle
order and site labels proves the
last-two-eligible-position case.
\(\square\)

**A realized peripheral profile.** Take
\(\ell=2,r=3,k=3,t=2,d=0,a=1\)
and the 34-cycle in the following
consecutive blocks:
\[
\begin{array}{ll}
B_0:&x,R_2,e_0,y,\\
B_1:&a_1,o_1,e_1,b_1,\\
B_2:&a_2,o_2,e_2,b_2,\\
D:&a_3,o,h_1,i_1,h_2,i_2,L_2,R_1,e,b_3,\\
B_4:&u,o_4,L_1,v,\\
S_j:&\alpha_j,\gamma_j,\delta_j,\beta_j
\quad(j=1,2),\text{ returning to }x .
\end{array}                                           \tag{6}
\]
Add the complementary perfect matching
\[
\begin{split}
M={}&\{xy,uv,a_1b_1,a_2b_2,a_3b_3\}\\
&\cup\{\alpha_j\beta_j,\gamma_jL_j,
\delta_jR_j:j=1,2\}\\
&\cup\{e_0i_2,o_1h_2,e_1i_1,o_2h_1,e_2o,eo_4\}.
\end{split}                                           \tag{7}
\]
All pairs have opposite old-cycle parity.
Draw the site, face and \(\alpha_j\beta_j\)
chords on the site-face side. On the
other side, the five long free chords
are nested, \(eo_4\) is disjoint
from them, and the escape chords nest
as \(R_2\delta_2\supset L_2\gamma_2
\supset R_1\delta_1\supset L_1\gamma_1\).
This is a simple cubic bipartite plane
graph with cofacial \(xy,uv\).

Its matching-chord interlacement graph
is connected. The chain
\[
xy-e_0i_2-a_3b_3-eo_4-uv-\gamma_1L_1-
\alpha_1\beta_1-\delta_1R_1-a_3b_3-
\gamma_2L_2-\alpha_2\beta_2-\delta_2R_2-xy
\tag{8}
\]
is joined to \(a_1b_1\) by \(o_1h_2\),
which also interlaces \(a_3b_3\), and to
\(a_2b_2\) by \(o_2h_1\), which also
interlaces \(a_3b_3\),
to \(e_1i_1\) by \(a_1b_1\),
and to \(e_2o\) by \(a_2b_2\).
Note 217's interlacement criterion
proves three-connectivity, and its
cut projection makes the 38-vertex
site expansion Barnette. Explicitly,
the marked Hamilton cycle is the union
of these internally disjoint \(x\)-to-\(v\) paths:
\[
\begin{split}
&x,y,e_0,i_2,h_2,o_1,a_1,b_1,e_1,i_1,h_1,o_2,
 a_2,b_2,e_2,o,a_3,b_3,e,o_4,u,v,\\
&x,R_2,\delta_2,\beta_2,\alpha_2,\gamma_2,L_2,R_1,
 \delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v.
\end{split}                                           \tag{9}
\]
They cover all 34 vertices and contain \(xy,uv\);
Note 001 lifts the cycle to the child.
\(\square\)

The theorem covers two vacancies at
one end of a target-bearing face block.
Vacancies separated by occupied targets
are handled by Notes 228--229 under
their stated conditions. Vacancies
in different target-bearing blocks,
outer-block vacancies, target-order
defects, gaps and nonsquare residual
cycles remain outside these results.
