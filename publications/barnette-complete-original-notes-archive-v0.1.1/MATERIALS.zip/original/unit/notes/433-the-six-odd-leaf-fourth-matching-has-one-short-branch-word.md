> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The six-odd-leaf fourth matching has one short-branch word

[Note 432](432-the-first-five-leaf-face-matching-and-its-reflection-are-hamiltonian.md) closes rows I and II of [Note 426](426-five-leaf-face-matchings-have-three-unresolved-shapes.md). This note treats the extreme odd-depth spectra of row IV, whose permitted ineligible sibling boundaries are $b\mid c$ and $d\mid e$. It is a necessary-tree theorem, not a Hamilton assertion for its surviving word.

Work in the two-eligible, chorded single-hexagon $f=7,c=31$ setting of [Note 425](425-short-wrapper-parity-and-terminal-spine-paths.md). Let $b_T$ be the number of odd-depth leaves of the seven-leaf full binary tree, and let $v$ be its unique short node at odd depth. Note 425 gives $b_T\in\{0,3,6\}$ and
\[
 2=b_T+E_v-O_v,                                      \tag{1}
\]
where $E_v,O_v$ count even- and odd-depth leaves below $v$. The two eligible leaves are the site leaves.

**Closed-compartment lemma.** A proper ordinary subtree whose leaves are exactly one whole face-matching compartment cannot occur in a three-connected parent. All of its ordinary matching chords are internal to its consecutive old-cycle interval, and all special matching chords of the compartment are internal as well. Only the two old-cycle edges at the interval's ends leave it, a forbidden two-edge cut. In particular, the five ineligible leaves in the $(5,0,0)$ distribution cannot themselves form a proper ordinary subtree.

**Extreme-spectrum theorem for row IV.** If a legal row-IV child is non-Hamiltonian, then $b_T\ne0$. If $b_T=6$, its site placement is $(j,k)=(1,7)$ and its complete ordinary word is necessarily
\[
\begin{aligned}
 H_L&=F(U_3,U_4),& H_R&=F(U_5,U_6),\\
 V&=F_0(H_L,H_R),&D&=F(V,U_7),\\
 E&=F(U_2,D),&W&=F(U_1,E),
\end{aligned}                                                    \tag{2}
\]
where $F(P,Q)=(((P Q)))$, $F_0(P,Q)=((P Q))$, and all seven leaves are full $U_i=((x_i y_i))$. Its depths are $(1,2,5,5,5,5,3)$, with $V$ the short branch at depth three. Row IV's face chords on leaves $2,\ldots,6$ are
\[
 x_2y_6,\quad y_2x_3,\quad y_3x_6,\quad x_4y_5,\quad y_4x_5. \tag{3}
\]
No claim is made that (2)--(3) has a legal Barnette completion or a non-Hamiltonian child. Up to reflection, this is the only row-IV word left by the $b_T=6$ analysis; the $b_T=3$ case is not classified here.

**Proof.** If $b_T=0$, all leaves have even depth. The only eligible leaves are then those below $v$, so (1) forces exactly two leaves below $v$. They are sibling site leaves, and the sibling-site theorem of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md) makes the child Hamiltonian.

Now let $b_T=6$. Equation (1) says $E_v-O_v=-4$. Since $v$ is a proper subtree and its number $t=E_v+O_v$ of leaves is even, $4\le t\le6$, hence $t=4$ or $6$.

If $t=6$, then $v$ is a child of the root and has one even-depth and five odd-depth leaves. The outside root leaf and the unique even-depth leaf within $v$ are the sites. Relative to $v$, its six leaves have exactly one odd-depth leaf. Splitting at $v$ shows that its two child subtrees have leaf counts $1+5$ or $2+4$, up to order: a one-leaf child contributes one odd-relative leaf, a two-leaf child contributes none, a three-leaf child contributes two, a four-leaf child contributes one or four, and a five-leaf child contributes zero or three. In the $1+5$ case the one-leaf child is the inside site and the other child contains exactly the five ineligible leaves. The closed-compartment lemma excludes it.

In the $2+4$ case the two-leaf child is an ineligible sibling pair at one end of the five-leaf block. The four-leaf child is a comb with the inside site at its outer end; its unique even-depth relative leaf is that site, so its cherry is the middle pair of its four leaves. If the sites are $(1,2)$, these two ineligible sibling boundaries are $a\mid b$ and $d\mid e$. If the sites are $(1,7)$, the same two boundaries occur, in the opposite order. Row IV permits $b\mid c,d\mid e$ only; $a\mid b$ is excluded by Note 426. Thus $t=6$ cannot support a non-Hamiltonian legal row-IV child.

If $t=4$, all four leaves below $v$ have odd global depth. Their relative depths from $v$ are even, forcing the balanced four-leaf tree with two cherries. Both sibling boundaries must be among row IV's permitted $b\mid c,d\mid e$, so the subtree consists exactly of leaves $b,c,d,e$ in that order, with cherries $(b,c)$ and $(d,e)$.

There are three leaves outside $v$. Since $v$ has odd depth and each ancestor has another nonempty child subtree, its depth is one or three. At depth one, the four-leaf subtree must occupy one extreme of the seven-leaf order. For sites $(1,7)$, $b,c,d,e$ occupy the middle four leaves, so this is impossible. For sites $(1,2)$ they occupy leaves $4,5,6,7$, and the other root child is a three-leaf tree on $1,2,3$. Making both site leaves odd-depth forces $(1,2)$ to be siblings, giving a Hamiltonian child by Note 424.

At depth three, collapse $v$ to a leaf. The resulting four-leaf tree is a comb, with the other three leaves at depths $1,2,3$. Sites must occupy its odd-depth leaves, and the remaining outside leaf its depth-two position. For sites $(1,2)$, the four-leaf subtree occupies the rightmost positions $4,\ldots,7$; the outside leaves $1,2,3$ then have depths $1,2,3$, making site 2 ineligible, a contradiction. For sites $(1,7)$, the subtree occupies leaves $3,\ldots,6$, and the unique allowed skeleton has leaves $1,2,v,7$ at depths $(1,2,3,3)$. The subtree is balanced beneath $v$, giving exactly (2) and the stated depths. Substituting $a=2,b=3,c=4,d=5,e=6$ into row IV of Note 426 yields (3). This exhausts $b_T=6$. \(\square\)

The theorem's remaining word requires a Hamilton or illegality analysis, and row IV with $b_T=3$ remains broader. Reflection gives the corresponding necessary statement for row V. It does not settle row VI or Barnette's conjecture.
