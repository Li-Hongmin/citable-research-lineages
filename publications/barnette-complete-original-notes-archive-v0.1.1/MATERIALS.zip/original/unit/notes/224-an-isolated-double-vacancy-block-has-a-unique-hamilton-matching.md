> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An isolated double-vacancy block has a unique Hamilton matching

[Note 223](223-two-target-free-vacancies-in-one-group-always-have-a-marked-hamilton-cycle.md)
settles two vacancies in distinct target-free face blocks.
Two vacancies can instead occupy the same target-free
face block. When no additional short block shares its
free group, the matching is unique and a local path
absorbs the canonical alternating four-cycle.

Use a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps, tight target
order and precisely two eligible vacancies. Suppose
both lie in one target-free face block \(B_k\),
\(1\le k\le r\), whose six free interior slots are
\[
o,h_1,i_1,h_2,i_2,e                         \tag{1}
\]
in old-cycle order. Assume its whole free group is
\[
e_{k-1},o,h_1,i_1,h_2,i_2,e,o_{k+1}.
\tag{2}
\]

**Isolated double-block theorem.** The free complementary
matching on (2) is uniquely
\[
\{e_{k-1}i_1,\ oe,\ h_1i_2,\ h_2o_{k+1}\}.
\tag{3}
\]
The parent has a Hamilton cycle containing both
site edges \(q=xy,p=uv\), and its legal site-expanded
child is Hamiltonian. Arbitrary positive original
lobe lengths are allowed.

**Proof of the matching classification.** Number the
free slots of (2) from \(0\) to \(7\). The even
endpoint \(0=e_{k-1}\) can match only odd positions
\(1,3,5,7\). A chord \(0\!-\!7\) would enclose
the entire target-free block \(B_k\), making it
matching-closed and producing a two-edge cut.

If \(0\!-\!5\) occurs, positions \(1,\ldots,4\)
lie inside that opposite-side chord. Among their
possible matching edges, only \(1\!-\!6=oe\)
or \(3\!-\!6=i_1e\) could leave the interval
without crossing the chord: both use position
\(6\), so at most one can leave. One exit leaves
an odd number of inside vertices. With no exit,
positions \(1,\ldots,4\) have no perfect matching:
\(1\!-\!4=oh_2\) leaves the adjacent old-cycle
pair \(2,3\), and the other noncrossing pairings
use old-cycle edges. Thus \(0\!-\!5\) is impossible.

Suppose \(0\!-\!1\). The even vertex \(6=e\)
can match only \(3=i_1\) or \(7=o_{k+1}\);
\(5=i_2\) is its old-cycle neighbour.
If \(6\!-\!7\), the remaining \(2,3,4,5\)
cannot be matched: \(2\!-\!5=h_1i_2\)
would leave the old-cycle pair \(3,4\).
If \(6\!-\!3\), the remaining vertices force
\(2\!-\!5=h_1i_2\) and
\(4\!-\!7=h_2o_{k+1}\). The chord
\(4\!-\!7\) joins different blocks and lies
opposite the site face. Both same-block chords
\(2\!-\!5\) and \(3\!-\!6\) interlace it,
so they would both have to lie on the site-face
side; but they interlace each other there.
This case is impossible.

Thus \(0\!-\!3=e_{k-1}i_1\). Its internal
positions \(1=o,2=h_1\) cannot pair because
they are adjacent on \(C\). The even slot
\(2\) cannot connect to \(7\) across
\(0\!-\!3\), so it must match \(5=i_2\).
That edge crosses \(0\!-\!3\) as chords
and therefore lies on the site-face side.
The remaining odd slot \(1\) cannot match
\(4=h_2\): on the site-face side it
would cross \(2\!-\!5\), and on the
opposite side it would cross \(0\!-\!3\).
It therefore matches \(6=e\).
Finally \(4=h_2\) matches \(7=o_{k+1}\).
The two same-block chords \(1\!-\!6\) and
\(2\!-\!5\) are nested on the site-face side;
the two cross-block chords \(0\!-\!3\) and
\(4\!-\!7\) are disjoint on the opposite
side. This proves (3).

**Marked Hamilton route.** Let \(a_k,b_k\)
be the endpoints of the face chord of \(B_k\).
In Note 196's ordinary free path, replace
the segment from \(e_{k-1}\) to \(o_{k+1}\)
by
\[
e_{k-1},i_1,h_1,o,a_k,b_k,e,i_2,h_2,o_{k+1}.
\tag{4}
\]
The first and last edges of (4), \(a_kb_k\),
are in \(M\); \(h_1i_1,h_2i_2\) are in
the even-starting old-cycle matching \(A\).
The remaining displayed transitions are
old-cycle edges. Thus (4) visits all six
interior slots and both face-chord endpoints
once, retaining the outside free-path
endpoints. It is disjoint from Note 196's
target-and-square path, and their union is
one Hamilton cycle containing \(xy,uv\).
Notes 001 and 178 give the child and
longer-lobe conclusions. \(\square\)

**A real Barnette instance.** At \(\ell=r=1\),
take the 20-cycle
\[
x,R_1,e_0,y,a_1,o,h_1,i_1,h_2,i_2,e,b_1,
u,o_2,L_1,v,\alpha_1,\gamma_1,\delta_1,\beta_1,x
\tag{5}
\]
and add the perfect matching
\[
\begin{split}
M={}&\{xy,uv,a_1b_1,\alpha_1\beta_1,
\delta_1R_1,\gamma_1L_1\}\\
&\cup\{e_0i_1,oe,h_1i_2,h_2o_2\}.
\end{split}                                               \tag{6}
\]
All matching pairs have opposite cycle parity.
Draw \(xy,a_1b_1,uv,\alpha_1\beta_1\)
on one side of the cycle; \(oe,h_1i_2\)
nest inside \(a_1b_1\) on that side.
Draw \(\delta_1R_1,e_0i_1,h_2o_2,
\gamma_1L_1\) on the other side.
These chords are disjoint or nested, giving
a plane bipartite cubic graph with \(xy,uv\)
on a common face.

Its matching-chord interlacement graph is
connected: the chain
\[
xy-e_0i_1-a_1b_1-h_2o_2-uv-
\gamma_1L_1-\alpha_1\beta_1-
\delta_1R_1-xy
\tag{7}
\]
has \(oe,h_1i_2\) attached through
\(e_0i_1\). Each alternation follows from
(5). As in Note 217, a two-edge cut in a
cubic Hamiltonian graph would give a proper
cycle interval closed under the matching,
which would disconnect the interlacement
graph. Hence the parent is three-connected.
The site colours are compatible, and
Note 217's square-expansion cut projection
shows that the expanded child is Barnette
as well. Both are Hamiltonian by (4).
\(\square\)

The theorem classifies the isolated eight-slot
group only. Additional short blocks in the
same group, target-bearing vacancy blocks,
outer-block vacancies, defects, gaps and
nonsquare residual cycles remain outside
its scope.
