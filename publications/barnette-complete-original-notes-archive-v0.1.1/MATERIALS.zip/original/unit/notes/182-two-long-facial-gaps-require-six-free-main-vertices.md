> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two long facial gaps require six free main vertices

The one-lobe bound in [Note 181](181-one-lobe-long-facial-gaps-need-twelve-main-vertices.md)
extends sharply to any number of square-trap lobes. The obstruction is
the placement of the two site ports among the escape endpoints; it does
not require a separate enumeration for each lobe count.

Use the legal Barnette expansion, parent Hamilton cycle \(C\), and
all-square-trap facial opening of Notes
[176](176-alternating-facial-arcs-create-one-residual-cycle-per-matching-edge.md)--[180](180-first-feasible-square-trap-main-segments-force-one-edge-gap.md).
Compress every lobe as in
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
Orient the old-vertex main segment \(S_0\) from \(x\) to \(v\), with
the other site ports \(x<y<u<v\). Let \(\ell\ge1\) be the number
of residual squares. Their escape targets occur in the order
\[
R_\ell,L_\ell,R_{\ell-1},L_{\ell-1},\ldots,R_1,L_1,
\tag{1}
\]
where each \(R_i\) has odd index and each \(L_i\) even index
along \(S_0\). The site matching edges are \(q=xy\) and
\(p=uv\), both on the common-face side of \(C\).

**Theorem.** If both facial arcs between the site edges have
length at least three and every trapped segment is a square, then
\[
|V(S_0)|\ge 2\ell+10.
\tag{2}
\]
In particular, the bound \(2\ell+8\) from Note 180 cannot be
attained, regardless of the number or original lengths of the
lobes. Bound (2) is sharp for every \(\ell\ge1\), and remains
sharp with arbitrary positive lengths of the individual lobes.

**Proof.** Note 180 gives \(|V(S_0)|\ge2\ell+8\), and
\(|V(S_0)|\) is even. The facial order used in Note 181
also gives at least two \(S_0\)-vertices strictly between
\(y,u\) when their facial gap has length at least three.
Suppose equality. Apart from the four site
ports and \(2\ell\) escape targets, exactly four vertices of
\(S_0\) remain. Call them *free*. Their complementary-matching
edges form exactly two internal \(S_0\) chords.

Partition the interior of \(S_0\) into the open gaps between
successive members of
\[
x,R_\ell,L_\ell,\ldots,R_1,L_1,v.
\tag{3}
\]
Every gap contains an even number of non-target vertices:
successive boundary indices in (3) have opposite parity.
The six non-target interior vertices are precisely \(y,u\)
and the four free vertices. Call \((R_i,L_i)\) a *pair gap*;
the other gaps are *nonpair gaps*.

We use two planar observations. First, an internal chord drawn
on the side of \(C\) opposite the common face cannot have an
escape target strictly between its endpoints on \(S_0\). Such
a target's escape chord comes from the complementary \(C\)-arc;
the two chords would have alternating endpoints on \(C\) and
would cross. Second, by Note 179's even-cut bridge lemma, each
of the \(C\)-edges immediately after \(y\) and immediately
before \(u\) is straddled by an escape pair or crossed by both
internal chords. Both edges start at odd indices, and both lie
between \(y\) and \(u\).

The ports cannot lie in the same gap. If their common gap is
a nonpair gap, neither of those two edges is straddled. Each
internal chord must then cross both edges, so all four free
endpoints lie outside the open interval \((y,u)\). But the
second facial gap has length at least three; its at least two
interior vertices are in this target-free gap and are free.
This is impossible. If the common gap is a pair gap \((R,L)\),
the parity of \(R,y\), of \(u,L\), and the long \(y\)-to-\(u\)
gap force at least one free vertex before \(y\), at least two
between \(y,u\), and at least one after \(u\). These are all
four free vertices, and their exact order is
\[
R,s,y,a,b,u,t,L.
\tag{4}
\]
Here \(s,a\) have even indices and \(b,t\) odd indices.
The pairing \(st,ab\) is impossible because \(a,b\) are
adjacent on \(C\). The only other bipartite pairing is
\(sb,at\). The chord \(sb\) interlaces \(q=xy\), while
\(at\) interlaces \(p=uv\); both must therefore lie opposite
the common face. Their endpoints interlace in the order
\(s<a<b<t\), so they cross. This is also impossible.
Thus \(y,u\) occupy distinct gaps, with at least one escape
target between them.

The edge immediately after \(y\) must be straddled. Otherwise
both internal chords cross it. Their left endpoints lie strictly
between \(x,y\) and their right endpoints strictly after \(y\),
so both chords interlace \(q=xy\) and must lie opposite the
common face. The first planar observation then puts both
endpoints of each chord in the gap containing \(y\). This
would put all four free vertices in that gap. Along with \(y\)
it would have five non-target vertices, contradicting its even
size because \(u\) lies in a different gap. Symmetrically,
the edge immediately before \(u\) must be straddled: a chord
crossing it interlaces \(p=uv\), and the same parity argument
applies. Hence \(y,u\) lie strictly inside two different pair
gaps. In particular \(\ell\ge2\).

The pair gap containing \(y\) has at least two non-target
vertices. If it has exactly two, they occur as \(s,y\) with
\(s<y\). The pair gap containing \(u\) likewise has at least
two; at size two they occur as \(u,t\) with \(u<t\). Their
combined size is at most six, so the only possible size
distributions are \((4,2)\), \((2,4)\), and \((2,2)\) with
one further gap of size two.

In a size-two \(y\)-gap, the sole free vertex \(s\) can be
matched outside its gap only to a free vertex in an *earlier*
gap. Indeed, every vertex in a later gap lies after \(y\).
The chord to it would interlace \(q\), forcing it to the
opposite side of \(C\), but would enclose the escape target
at the right end of the \(y\)-gap. Similarly, the sole free
vertex \(t\) of a size-two \(u\)-gap can be matched outside
its gap only to a vertex in a *later* gap: a chord to an
earlier gap interlaces \(p\) and encloses the target at the
left end of the \(u\)-gap. In distributions \((4,2)\) and
\((2,4)\), the sole free vertex of the size-two gap has no
eligible partner. In distribution \((2,2,2)\), the third
gap cannot be both earlier than the \(y\)-gap and later than
the \(u\)-gap, so at least one of \(s,t\) has no eligible
partner. Each case contradicts the perfect matching.

Therefore equality in Note 180's bound is impossible. The
even order of \(S_0\) gives (2). Compression leaves \(S_0\)
and the opposite site gap unchanged; the chosen facial arc
becomes length \(2\ell+1\ge3\). Hence the conclusion
transfers to the original lobes. \(\square\)

**Sharpness for every lobe count.** Note 181 supplies \(\ell=1\).
For \(\ell\ge2\), define a Hamilton cycle \(C_\ell\) whose main
segment, in cyclic order from \(x\) to \(v\), is
\[
x, R_\ell,L_\ell,\ldots,R_3,L_3,
R_2,s,y,a,b,L_2,R_1,c,d,u,t,L_1,v.
\tag{5}
\]
For \(\ell=2\), the initial list \(R_\ell,L_\ell,\ldots,R_3,L_3\)
is empty. From \(v\) back to \(x\), place \(\ell\) four-vertex
segments in order
\[
S_i=\alpha_i,\gamma_i,\delta_i,\beta_i,
\qquad 1\le i\le\ell.
\tag{6}
\]
Add the following complementary perfect-matching edges:
\[
xy,\ uv,\ sb,\ ad,\ ct,
\qquad
\alpha_i\beta_i,\quad \gamma_iL_i,\quad\delta_iR_i
\quad(1\le i\le\ell).
\tag{7}
\]
Together with \(C_\ell\), these specify a simple cubic
bipartite graph on \(6\ell+10\) vertices. Place \(xy,uv,ad\)
and all \(\alpha_i\beta_i\) on one side of \(C_\ell\).
Their endpoint intervals are disjoint, so they do not cross.
Place \(sb,ct\) and all escape chords on the other side.
The former lie strictly inside the separate pair gaps
\((R_2,L_2)\) and \((R_1,L_1)\); the escape chords have
reversed source and target order, so these chords do not
cross either. This gives a plane embedding. Its face between
the two site edges has alternating arcs
\[
y,a,d,u \quad\text{and}\quad
v,\alpha_1,\beta_1,\alpha_2,\beta_2,\ldots,
\alpha_\ell,\beta_\ell,x,
\tag{8}
\]
of lengths three and \(2\ell+1\), respectively. Opening
the latter arc leaves exactly the \(\ell\) square traps
\(S_1,\ldots,S_\ell\), each a singleton lobe. The main segment
has exactly \(2\ell+10\) vertices.

It remains to establish three-connectivity. For \(\ell=2\),
number the cyclic vertices of \(C_2\) from \(0\) through \(21\),
starting at \(x\). The matching pairs are
\[
(0,3),(1,20),(2,5),(4,9),(6,19),(7,16),
(8,11),(10,13),(12,15),(14,17),(18,21).
\tag{9}
\]
In a graph consisting of a Hamilton cycle and a perfect matching,
a two-edge cut exists exactly when some proper cyclic interval
of the Hamilton cycle is closed under the matching: the Hamilton
cycle must contribute both cut edges. Suppose such an interval
exists here. Taking its complement if necessary, it avoids 0
and hence also 3, the mate of 0. It lies in \([1,2]\) or
\([4,21]\). The first is impossible because 1 and 2 have
mates outside it. In \([4,21]\), mates force exclusion of 5
and 20, leaving only \([6,19]\) or singletons. Next 9 and
18 have mates outside \([6,19]\), leaving \([6,8]\) or
\([10,17]\) or a singleton. Vertex 6 rules out \([6,8]\).
In \([10,17]\), vertices 11 and 16 have mates outside,
leaving \([12,15]\) or singletons. Finally 13 and 14 have
mates outside \([12,15]\). No nonempty singleton is closed
under this perfect matching. Thus the base graph has no
two-edge cut and is three-edge-connected.

For the induction from \(\ell\) to \(\ell+1\), replace the
two \(C_\ell\)-edges \(xR_\ell\) and \(\beta_\ell x\) by
the paths \(xR_{\ell+1}L_{\ell+1}R_\ell\) and
\(\beta_\ell\alpha_{\ell+1}\gamma_{\ell+1}
\delta_{\ell+1}\beta_{\ell+1}x\), then add
\(\alpha_{\ell+1}\beta_{\ell+1}\),
\(\gamma_{\ell+1}L_{\ell+1}\), and
\(\delta_{\ell+1}R_{\ell+1}\). The six new vertices
induce two squares sharing the edge
\(\gamma_{\ell+1}\delta_{\ell+1}\), and exactly four edges
join this patch to old vertices. Every nontrivial edge cut
*inside* the patch has size at least two. Moreover, a cut of
size two inside the patch puts at least one of its four
attachment vertices on each shore: isolating a set consisting
only of its two nonattachment vertices, or its complement,
needs at least three patch edges.

If the enlarged graph had a cut of at most two edges and all
new vertices lay on one shore, the old vertices on that shore
would give a cut of no larger size in the old graph; replacing
an old edge by a path cannot decrease a cut size. The degenerate
case with all old vertices on the other shore has four crossing
attachment edges. If the new vertices lay on both shores,
their internal patch cut already contributes at least two
edges. Hence a cut of size at most two would have exactly two
internal patch edges and no crossing old or attachment edge.
Both shores would contain old vertices, by the preceding
attachment observation. Their cut in the old graph could then
use only the two replaced edges, contradicting its
three-edge-connectivity. Induction proves three-edge-connectivity
for every \(\ell\).

A cubic three-edge-connected graph is three-vertex-connected.
A cut vertex would leave at least two components, each needing
three incident edges, although the vertex has degree three.
If deleting two vertices \(z,z'\) disconnects the graph, their
adjacency would leave at most four edges to the components and
is impossible. Otherwise there are exactly two components,
each with three incident edges. Connectivity forces one of
\(z,z'\) to have two neighbors in one component and one in
the other; adjoining it to the former component produces a
two-edge cut. This is again impossible.
Thus each parent graph above is a Barnette graph. The site
expansion is also three-edge-connected: its four new vertices
form a square with one attachment at each corner. Any partial
cut of this square has at least two internal square edges, so
a cut of size at most two would have no crossing attachment
or old edge and would project to a cut using at most the two
deleted site edges in the parent. If the square lies wholly
on one shore, projection does not increase cut size. The same
cubic argument gives three-vertex-connectivity of the child;
planarity and bipartiteness follow from the cofacial site
embedding. Hence every displayed site expansion is legal.

These sharpness examples also have explicit Hamilton cycles after
site expansion. In the base graph, the following cyclic order uses
every matching edge in (9), alternating with the even-indexed
edges of \(C_2\):
\[
0,3,2,5,4,9,8,11,10,13,12,15,14,17,16,7,6,19,
18,21,20,1,0.
\tag{10}
\]
It is a Hamilton cycle containing both site edges \(xy\) and
\(uv\), as well as the main edge \(xR_2\). At each six-vertex
insertion, replace its edge \(xR_\ell\) by the spanning path
\[
x,R_{\ell+1},\delta_{\ell+1},\beta_{\ell+1},
\alpha_{\ell+1},\gamma_{\ell+1},L_{\ell+1},R_\ell.
\tag{11}
\]
Each consecutive pair in (11) is an edge of the new graph;
all six new vertices occur once, and both site edges remain
on the cycle. Induction gives a Hamilton parent cycle through
\(p,q\) for every \(\ell\). Clause 1 of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
then lifts it to a Hamilton cycle of the expanded child.

Finally, replace each residual square by an even-column
four-terminal ladder of any chosen length. Note 178 preserves
the Barnette parent and child, the site and Hamilton routing,
while leaving \(S_0\) untouched. It also transfers the
Hamilton cycle of each expanded child. Thus (2) is sharp for
every lobe count and every positive lobe length. \(\square\)

The theorem constrains this chosen all-square facial opening.
It does not prove that every Barnette expansion has such an
opening or that the child has a Hamilton cycle when (2) holds.
