> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every consecutive forward six-double group has a spanning route

[Note 358](358-six-alternating-double-blocks-reduce-to-one-global-first-return-branch.md)
reduces the consecutive forward six-double group to \(h_1j_6\).
[Notes 359](359-a-six-double-global-return-has-two-reflected-spanning-halves.md)
and [360](360-a-two-path-splice-closes-the-six-double-k1i2-global-return.md)
settle \(k_1j_3\) and \(k_1i_2\). The remaining three possible
mates of \(k_1\) are \(i_4,j_5,i_6\). One is impossible; the
other two have explicit spanning routes.

Use the compressed, gapless, tight-target all-square opening of
Note 358, with ordinary endports \(L,R\), six consecutive blocks

\[
 D_t=(a_t,o_t,h_t,i_t,k_t,j_t,e_t,b_t),\qquad 1\le t\le6,
\]

and common-face internal matching chords \(i_te_t\) for odd \(t\)
and \(o_tk_t\) for even \(t\). There are no short blocks in this
group. The block-closing chords \(a_tb_t\) are also present.

**Six-double theorem.** Every complementary matching actually
occurring in a Barnette parent under these assumptions gives a
vertex-spanning \(L\)--\(R\) path. If all vacancies outside this
group occupy distinct internal blocks, the parent has a Hamilton
cycle through both site edges and its legal site-expanded child
is Hamiltonian. This conclusion concerns the specified opening
and orientation word, not all Barnette graphs.

**Last three first-return branches.** Assume \(h_1j_6\).
Noncrossing and the proper complete-block cut rule give
\(Lo_1,e_6R\), as in Note 359. The free-slot list in
Note 358 (3) leaves only \(i_2,j_3,i_4,j_5,i_6\) as possible
mates of \(k_1\): its neighbour \(j_1\) is an old edge,
and the other odd slots enclose an odd number of free slots.
The first two possibilities are settled by Notes 360 and 359.
If \(k_1j_5\), the only free slots after \(j_5\) and before
\(j_6\) are \(h_6,i_6\). They would have to match each other,
but \(h_6i_6\) is an old-cycle edge. Hence \(k_1j_5\) is
impossible.

Suppose \(k_1i_4\). Inside it, the first slot \(j_1\)
can meet only \(h_2,k_3,h_4\). The choice \(j_1k_3\)
strands \(h_2\), whose only other interior candidates are an
old edge, an excluded same-block chord, or an odd-slot interval.
The choice \(j_1h_4\) closes the proper complete-block interval
\(D_2D_3\) under the matching, a forbidden two-edge cut.
Thus \(j_1h_2\). The next slot \(i_2\) can meet \(k_3\)
or \(h_4\); the latter forces \(j_2h_3,e_2o_3\)
and strands the old pair \(k_3j_3\). Consequently the
inside is forced to be

\[
 j_1h_2,\quad i_2k_3,\quad j_2h_3,\quad e_2o_3,
 \quad j_3h_4.                                             \tag{1}
\]

The free tail between \(i_4,j_6\) starts at \(j_4\).
The only admissible mate of \(j_4\) is \(h_5\), then
\(e_4o_5,k_5i_6,j_5h_6\) are forced. Thus this branch
has a unique complementary matching.

Let \(W\) be Note 347 (4), relabeled on \(D_1,\ldots,D_4\).
Its only absent edge in the present matching is \(h_1j_4\).
Deleting that edge gives disjoint paths \(W^-\) from \(o_1\)
to \(h_1\), and \(W^+\) from \(j_4\) to \(e_4\), covering
the first four blocks. The last two blocks have disjoint paths

\[
\begin{split}
 P&=(j_6,k_6,i_6,k_5,i_5,h_5),\\
 Q&=(o_5,a_5,b_5,e_5,j_5,h_6,o_6,a_6,b_6,e_6).
\end{split}                                                \tag{2}
\]

They cover \(D_5D_6\) once; their non-old joins are
\(k_5i_6,j_5h_6,a_5b_5,a_6b_6\). The concatenation

\[
       L,\ W^-,\ h_1j_6,\ P,\ h_5j_4,\ W^+,\ e_4o_5,\ Q,\ R
                                                               \tag{3}
\]

is the required spanning path. The displayed edge names in
(3) specify joins, not additional vertex visits.

It remains to consider \(k_1i_6\). The possible mates of
\(j_1\) are \(h_2,k_3,h_4,k_5,h_6\).
The \(k_3\) choice strands \(h_2\), the \(h_4\) choice
closes \(D_2D_3\), and the \(h_6\) choice closes
\(D_2,\ldots,D_5\). If \(j_1k_5\), the first inner
slot \(h_2\) can meet \(j_3\) or \(i_4\).
The former strands \(h_4\); the latter forces
\(i_2k_3,j_2h_3,e_2o_3,j_3h_4,j_4h_5,e_4o_5\),
while the tail gives \(j_5h_6\). This is type \(A_4\)
below. Otherwise \(j_1h_2\). In that branch \(i_2\)
can meet \(k_3,h_4,k_5,h_6\); \(i_2h_4\) strands
the old pair \(k_3j_3\).

The matching must be one of the following five
wirings. The table lists all opposite-page chords after the
fixed \(Lo_1,h_1j_6,k_1i_6,e_6R\).

| Type | Remaining chords |
| --- | --- |
| \(A_0\) | \(j_1h_2,i_2k_3,j_2h_3,e_2o_3,j_3h_4,i_4k_5,j_4h_5,e_4o_5,j_5h_6\) |
| \(A_1\) | \(j_1h_2,i_2k_5,j_2h_3,e_2o_3,k_3i_4,j_3h_4,j_4h_5,e_4o_5,j_5h_6\) |
| \(A_2\) | \(j_1h_2,i_2k_5,j_2h_5,e_2o_3,h_3j_4,k_3i_4,j_3h_4,e_4o_5,j_5h_6\) |
| \(A_3\) | \(j_1h_2,i_2h_6,j_2h_3,e_2o_3,k_3j_5,j_3h_4,i_4k_5,j_4h_5,e_4o_5\) |
| \(A_4\) | \(j_1k_5,h_2i_4,i_2k_3,j_2h_3,e_2o_3,j_3h_4,j_4h_5,e_4o_5,j_5h_6\) |

To finish the \(j_1h_2\) exhaustion, if \(i_2k_3\), then
\(j_2h_3,e_2o_3\) are forced. The next slot \(j_3\)
could meet \(h_4,k_5,h_6\). The second strands \(h_4\);
the third closes \(D_4D_5\). Hence \(j_3h_4\), and
\(i_4k_5,j_4h_5,e_4o_5,j_5h_6\) follow, giving
\(A_0\). If \(i_2k_5\), the tail forces \(j_5h_6\).
The mate of \(j_2\) can be \(h_3,e_4,h_5\).
The \(e_4\) choice leaves the old pair \(o_5h_5\).
The \(h_3\) choice forces
\(e_2o_3,k_3i_4,j_3h_4,j_4h_5,e_4o_5\), giving \(A_1\);
the \(h_5\) choice forces
\(e_2o_3,h_3j_4,k_3i_4,j_3h_4,e_4o_5\), giving \(A_2\).
Finally, if \(i_2h_6\),
the \(j_2e_4\) choice strands \(o_5\), and \(j_2h_5\)
leaves the old pair \(k_5j_5\). Thus \(j_2h_3,e_2o_3\).
Now \(k_3\) can meet \(i_4\) or \(j_5\). The first
ultimately leaves \(k_5j_5\); the second forces
\(j_3h_4,i_4k_5,j_4h_5,e_4o_5\), giving \(A_3\).
Each stated force follows by noncrossing, parity, and the
ban on old-cycle and isolated same-block matching edges.

For completeness, the following four paths span \(D_2,\ldots,D_5\).
The first three run from \(h_2\) to \(j_5\); the last runs
from \(h_2\) to \(i_2\):

\[
\begin{split}
M_0={}&(h_2,o_2,a_2,b_2,e_2,o_3,a_3,b_3,e_3,i_3,h_3,\\
 &j_2,k_2,i_2,k_3,j_3,h_4,o_4,a_4,b_4,e_4,\\
 &o_5,a_5,b_5,e_5,i_5,h_5,j_4,k_4,i_4,k_5,j_5),\\[2pt]
M_1={}&(h_2,o_2,a_2,b_2,e_2,o_3,a_3,b_3,e_3,i_3,h_3,\\
 &j_2,k_2,i_2,k_5,i_5,h_5,j_4,k_4,i_4,k_3,j_3,\\
 &h_4,o_4,a_4,b_4,e_4,o_5,a_5,b_5,e_5,j_5),\\[2pt]
M_2={}&(h_2,o_2,a_2,b_2,e_2,o_3,a_3,b_3,e_3,j_3,\\
 &h_4,i_4,k_3,i_3,h_3,j_4,k_4,o_4,a_4,b_4,e_4,\\
 &o_5,a_5,b_5,e_5,i_5,h_5,j_2,k_2,i_2,k_5,j_5),\\[2pt]
M_3={}&(h_2,o_2,a_2,b_2,e_2,o_3,a_3,b_3,e_3,j_3,\\
 &h_4,o_4,a_4,b_4,e_4,o_5,a_5,b_5,e_5,i_5,h_5,\\
 &j_4,k_4,i_4,k_5,j_5,k_3,i_3,h_3,j_2,k_2,i_2).
\end{split}                                                 \tag{4}
\]

For each type \(A_t\), \(0\le t\le3\), insert \(M_t\)
in the common route

\[
 L,o_1,a_1,b_1,e_1,i_1,h_1,j_6,k_6,i_6,k_1,j_1,
       M_t,h_6,o_6,a_6,b_6,e_6,R.                         \tag{5}
\]

The joins at the ends of \(M_t\) are \(j_1h_2\) and
\(j_5h_6\) for \(t=0,1,2\), or \(j_1h_2\) and
\(i_2h_6\) for \(t=3\). Every \(M_t\) lists exactly
the 32 vertices of \(D_2,\ldots,D_5\), once each.
Each consecutive pair in (4)--(5) is an old-cycle edge,
a block-closing or prescribed internal chord, or a matching
chord in the corresponding table row. The fixed outer pieces
list each vertex of \(D_1,D_6\) once. Thus (5) spans the group.
Let \(\rho\) be Note 346 (4) for \(N=6\), extended by
\(\rho(L)=R,\rho(R)=L\). It preserves the old-cycle edges,
block-closing chords and prescribed alternating internal chords,
and takes the \(A_3\) matching to \(A_4\). Therefore applying
\(\rho\) to the \(A_3\) route (5) and reversing its vertex order
gives a spanning \(L\)--\(R\) path for \(A_4\).
The same reflection fixes \(A_0,A_1,A_2\), providing a check
on the five-row exhaustion.

Together with Notes 358--360, this proves the theorem.
The group route composes with the other free groups by
[Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md)
under the stated outside-vacancy condition; the exact
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
then gives the legal child's Hamilton cycle. \(\square\)

This is a project-internal analytic proof. It does not cover
short corridors among six double blocks, other orientation words,
other opening types, or the general Barnette conjecture; no
external priority or independent review is claimed.
