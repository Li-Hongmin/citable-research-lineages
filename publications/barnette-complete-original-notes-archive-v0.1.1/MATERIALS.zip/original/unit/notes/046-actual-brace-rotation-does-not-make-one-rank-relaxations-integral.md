> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Actual brace rotation does not make one-rank relaxations integral

[Note 044](044-small-laminar-leaf-deletion-is-a-restricted-dual-and-joint-rotation-problem.md)
reduces unrestricted deletion of a positive laminar leaf \(W\) to a
partition--graphic relaxation with the rank inequality of \(W\) omitted.
[Note 045](045-one-omitted-small-rank-inequality-can-create-a-fractional-local-block-extreme-point.md)
shows that separate planar block data do not make this relaxation integral,
but leaves open whether the joint primal--dual rotation of an actual brace
site restores integrality.  It does not.  A genuine order-sixteen brace site
already has a half-integral extreme point with one omitted three-point rank
row.

There is a second, independent failure.  At a legal cube site an integral
transversal can violate one two-point rank row because two selected labels
are absorbed by a restored primal cubic star.  The labels are not independent
edges, so brace \(2\)-extendability supplies no contradiction.  Hence actual
rotation and the brace hypothesis imply neither one-hole integrality nor an
uncosted extraction of a nonextendable independent edge pair.

## An integral star-absorbed obstruction in the cube

Let \(F\) be the cube with edge set

\[
 01,03,04,12,17,23,26,35,45,47,56,67
\]

and take the ordered legal site

\[
 (u,v,z,a)=(0,3,2,1).
\tag{1}
\]

After deleting \(u,a\), the \(X\)-partition blocks are

\[
 D_2=\{23,26\},\qquad
 D_5=\{35,45,56\},\qquad
 D_7=\{47,67\}.
\tag{2}
\]

In the contracted dual, the labels \(23,26,35\) join rank vertices \(1,2\),
the labels \(45,67\) join \(1,3\), label \(56\) joins \(2,3\), and label
\(47\) joins \(0,3\).  Therefore

\[
 R=\{23,35,47\}
\tag{3}
\]

is an \(X\)-block transversal whose only violated proper rank inequality is

\[
 W=\{1,2\},\qquad |R\cap E_Q(W)|=2>|W|-1.
\tag{4}
\]

As a vertex of the product of the three block simplices, \(\chi_R\) remains
extreme after the satisfied rank halfspaces are added.  Yet the two labels
inside \(W\) lift to the adjacent primal edges \(23,35\), and

\[
 \delta_F(3)=\{03,23,35\}.
\tag{5}
\]

Thus the dual two-cycle is exactly the image of a cubic star after the
distinguished edge \(03\) is restored.  Since the cube is a brace, this is a
counterexample to the implication

\[
 \boxed{
 \text{unique small rank violation}
 \Longrightarrow
 \text{nonextendable independent primal pair}.}
\tag{6}
\]

This obstruction is uncosted.  For every \(A\subseteq\{3,4,6\}\), the full
partition--graphic common-base minimum satisfies

\[
 \mu(A)\le |A|.
\tag{7}
\]

Hence no binary layer at this site satisfies the strict premise of
Note 044(26).

## A full-\(X\) obstruction before joint rotation

It is useful to separate the size at which fractional block geometry first
appears from the size at which it is realized by a brace.  On rank vertices
\(0,\ldots,5\), take the labelled blocks

\[
\begin{aligned}
D_0&=\{01,02,12\},&D_1&=\{04,14\},\\
D_2&=\{13_a,13_b\},&D_3&=\{24,34\},\\
D_4&=\{01',05,15\}.&&
\end{aligned}
\tag{8}
\]

These are precisely two triangles, two paths, and one root-parallel pair.
Define

\[
 x_{12}=x_{13_b}=x_{05}=1,\qquad
 x_{04}=x_{14}=x_{24}=x_{34}=\frac12,
\tag{9}
\]

with all other coordinates zero.  The block equations hold, and the unique
violated proper rank row is

\[
 W=\{1,2,3,4\},\qquad x(E(W))=\frac72>3.
\tag{10}
\]

The five block rows, five zero-coordinate rows, and the tight rank rows on
\(\{1,2,4\}\) and \(\{1,3,4\}\) form a \(12\times12\) matrix with determinant
\(-2\).  Thus (9) is an extreme point.

This fixed rooted block system is not an actual order-twelve obstruction.
Among the \(85\) connected simple cubic graphs of order twelve, exactly one
is bipartite, planar, \(3\)-connected, and a brace.  Its \(96\) ordered legal
sites realize no rooted block-coloured rank multigraph isomorphic to (8).
Consequently the full one-colour signature alone is insufficient, but this
particular rank-six obstruction still fails the joint-rotation test.

## A fractional extreme point at an actual brace site

Let \(F_{16}\) be the graph with edge set

\[
\begin{gathered}
01,03,0\,15,12,18,23,27,34,45,4\,13,56,5\,12,\\
67,69,78,89,9\,10,10\,11,10\,15,11\,12,11\,14,\\
12\,13,13\,14,14\,15.
\end{gathered}
\tag{11}
\]

It is simple, plane, cubic, bipartite, \(3\)-connected, and \(2\)-extendable.
Take the ordered legal site

\[
 (u,v,z,a)=(15,14,13,4).
\tag{12}
\]

The resulting \(X\)-vertices are \(1,3,5,7,9,11,13\), and the contracted
dual has rank vertices \(0,\ldots,7\).  Put

\[
\begin{aligned}
x_{18}&=x_{23}=x_{11,12}=x_{13,14}=1,\\
x_{56}&=x_{5,12}=x_{67}=x_{69}=x_{78}=x_{9,10}=\frac12,
\end{aligned}
\tag{13}
\]

and set the other eight retained coordinates to zero.  Every \(X\)-block
has total weight one.  Exact evaluation of all proper shores gives the
single violation

\[
 W=\{4,5,7\},\qquad x(E_Q(W))=\frac52>2.
\tag{14}
\]

All other proper rank inequalities hold.  Extremality is certified by the
following eighteen independent active rows:

- the seven \(X\)-block equations;
- the zero rows for \(01,03,12,27,89,10\,11,11\,14,12\,13\);
- the tight rank rows on
  \(\{1,4,5,7\}\), \(\{4,5,6,7\}\), and \(\{3,4,5,6,7\}\).

Their coefficient matrix has rank eighteen.  Hence (13) is a fractional
extreme point of the actual one-rank-relaxed partition slice, not merely a
fractional feasible average.  This proves

\[
 \boxed{
 \text{actual joint rotation}+\text{brace \(2\)-extendability}
 \not\Longrightarrow
 \text{one-hole integrality}.}
\tag{15}
\]

For the seven remaining \(Y\)-vertices

\[
 (0,2,6,8,10,12,14),
\]

the load vector of (13) is

\[
 \left(0,1,\frac32,\frac32,\frac12,\frac32,1\right).
\tag{16}
\]

Nevertheless all \(128\) binary layers at this site satisfy (7).  The
strict cost premise is again empty, independently of the existence of the
fractional point.

## No strict binary defect through order eighteen

Generate every connected simple cubic graph of each even order at most
sixteen, retain the planar bipartite \(3\)-connected graphs which are
\(2\)-extendable, and test every ordered legal site without quotienting by
automorphisms.  The retained counts are

\[
\begin{array}{c|r|r|r|r}
|V(F)|&\text{cubic graphs}&\text{braces}&\text{ordered sites}&
\text{binary layers}\\\hline
8&5&1&48&384\\
12&85&1&96&3072\\
16&4060&2&304&38912.
\end{array}
\tag{17}
\]

Orders six, ten, and fourteen contribute no braces.  The \(448\) ordered
sites in (17) comprise \(28\) site-isomorphism orbits.  Exact minimization
over every \(X\)-partition/graphic common-base family gives

\[
\begin{array}{c|r|r|r|r}
|V(F)|&\mu(A)-|A|=-3&-2&-1&0\\\hline
8&0&0&192&192\\
12&0&696&1896&480\\
16&3664&18928&14584&1736.
\end{array}
\tag{18}
\]

No positive gap occurs among these \(42\,368\) binary layers.

At order eighteen, direct bipartite generation gives \(149\) connected
simple cubic bipartite graphs.  Exactly two are planar and \(3\)-connected,
and exactly one is a brace.  That brace has \(168\) ordered legal sites in
\(14\) automorphism orbits, each of size twelve.  An automorphism carrying
one ordered site to another bijects the \(X\)-blocks, the spanning trees of
the contracted rank graph, and the subsets of \(Y\setminus\{a\}\), while
preserving every block load.  Evaluating all \(2^8\) layers on one
representative of each orbit therefore recovers all \(43\,008\) unquotiented
layers.  Their distribution is

\[
\begin{array}{c|r|r|r|r|r}
\mu(A)-|A|&-4&-3&-2&-1&0\\\hline
\text{layers}&336&9420&22248&10020&984.
\end{array}
\tag{19}
\]

Again no positive gap occurs.  Consequently the strict antecedent of
Note 044(26) is empty for every actual site through order eighteen.  A
cost-qualified one-hole counterexample, for any omitted shore size, must
satisfy

\[
 \boxed{|V(F)|\ge20,\qquad |V(Q)|\ge10.}
\tag{20}
\]

The smallest nonempty tight layer already occurs in the cube: at site
\((4,0,5,1)\) and \(A=\{2\}\), the four common-base costs are
\(1,1,2,2\).  Thus a singleton \(Y\)-vertex can be unavoidable, but some
common base still meets it only once.

## Remaining cost-qualified statement

The actual examples close the uncosted route, but they do not refute
Note 044(26).  Its surviving local content is:

> **Costed collision-to-hole problem.**  At an actual legal brace site, let
> \(x\) satisfy the \(X\)-block equations and all graphic-rank inequalities
> except possibly that of \(W\), where \(|W|\le4\).  If
> \(c_Ax\le|A|\), must either the full common-base polytope contain a point
> \(y\) with \(c_Ay\le|A|\), or the lifted tight system expose two
> independent primal edges which do not extend to a perfect matching?

For an integral point, the omitted-rank cycle may be absorbed by restored
cubic stars, as in (5).  A positive argument must route each resulting
\(Y\)-collision to a \(Y\)-hole while breaking the cycle, preserving all
other rank inequalities, and paying no more than the binary deficit.  For a
fractional point it must additionally resolve the odd residual incidence
component exhibited by (13).  Actual rotation and \(2\)-extendability alone
do not supply either step.

The fixed claims and finite boundaries are checked by

    uv run --python 3.12 --with networkx --with sympy \
      units/barnette/computations/verify_actual_brace_one_rank_boundaries.py
    uv run --python 3.12 --with networkx \
      units/barnette/computations/verify_no_strict_binary_defect_through_order_sixteen.py
    uv run --python 3.12 --with networkx \
      units/barnette/computations/verify_no_strict_binary_defect_at_order_eighteen.py

with terminal markers ACTUAL_BRACE_ONE_RANK_BOUNDARIES_VERIFIED,
ACTUAL_BRACE_COST_QUALIFIED_ONE_HOLE_EXCLUDED_THROUGH_16, and
ACTUAL_BRACE_COST_QUALIFIED_ONE_HOLE_EXCLUDED_AT_ORDER_18.
