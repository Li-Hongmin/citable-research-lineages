> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Per-stratum additive projections do not force mixed-sector survival

[Note 117](117-mixed-sector-survival-is-a-gate-even-parent-child-exchange-alternative.md)
reduces the mixed part of the rooted split-bond lemma to the implication

\[
 {\cal L}_{\neg 11}^{\,b}=\varnothing,\qquad
 \chi^b-\eta^{1-b}\in E(\mathfrak B_{g_1}(T)),
 \quad
 \chi\in{\cal L}_{11},\quad
 \eta\in{\cal L}_{\neg11}
 \quad\Longrightarrow\quad
 {\cal N}^b\ne\varnothing.
\tag{1}
\]

Here \({\cal N}^b\) is the union of the three nondirect child cells
\(R_{00},X_{uy},X_{vx}\) in gate sector \(b\).  The mixed bond in (1)
supplies a connected gate-odd shore, whereas both the missing parent
family and the desired child family are gate-even switch languages.

This note closes the most direct signed-counting attempt to bridge that
parity gap.  Even after retaining the complete ordered root-component
signature of each old exterior and a distinguished mixed bond, no
integer or mod-two identity which is valid separately on each exterior
stratum can imply (1).  The countermodel is a strict projection, not the
complete NAE family of an actual triangulation.  Consequently identities
which couple which exterior strata can coexist in one actual family
remain open.

## 1. Exterior strata

Let \(T\rightsquigarrow T^+\) be a labelled split as in Notes 108 and
117, and put

\[
 H=T-z=T^+-\{A,B,C\}.
\tag{2}
\]

An exterior stratum \(\sigma\) records one binary NAE colouring of \(H\)
together with

1. its surviving-gate bit;
2. the two ordered root fragments;
3. the two monochromatic-component partitions of \(H\);
4. the incidences of those components with
   \(J_A,J_B,\{P,Q\}\); and
5. the two ordered split-interval colour words.

This information determines, by the labelled component-gluing test of
[Note 109](109-root-admissible-nae-colourings-have-an-exact-shore-rank-calculus.md),
whether either parent apex colour and each of the seven child local rows
is NAE and root-admissible.

For \(s\in\{00,10,01,11\}\), write

\[
 p_s^b(\sigma)\in\{0,1\}
\tag{3}
\]

for the parent target indicator in state \(s\) and sector \(b\).  For the
three canonical child cells and three nondirect cells, write

\[
 c_s^b(\sigma),\qquad
 x_R^b(\sigma),\quad x_U^b(\sigma),\quad x_V^b(\sigma)
 \in\{0,1\}.
\tag{4}
\]

The canonical extension preserves the old exterior and its complete
ordered root signature.  Hence the canonical bijection of
[Note 108](108-kill-cover-supplementation-is-exactly-a-rooted-split-bond-lemma.md)
is stratumwise:

\[
 \boxed{p_s^b(\sigma)=c_s^b(\sigma)
 \qquad(s=00,10,01).}
\tag{5}
\]

The \(C_{11}\) row has an isolated monochromatic patch component and is
never root-admissible.  There is no analogous parent closure for the
three \(x\)-coordinates: they use different gluings of the same exterior
components to the split patch.

## 2. Pointwise independence is already actual

The octagonal-bipyramid split of
[Note 115](115-state-11-new-cell-fertility-is-exact-but-a-covered-endpoint-can-be-sterile.md)
contains two complementary actual strata.  Its sterile state-\(11\)
endpoint \(\alpha\) has interval words

\[
 01110,\qquad 01110,
\tag{6}
\]

and an ordered three-region tree whose centre is the zero component and
whose two leaves are the labelled one-components.  Nevertheless both
intervals contain a \(11\)-edge, so

\[
 p_{11}^1(\sigma_\alpha)=1,\qquad
 x_R^1(\sigma_\alpha)=x_U^1(\sigma_\alpha)
 =x_V^1(\sigma_\alpha)=0.
\tag{7}
\]

Changing the old exterior only at \(r_6\) gives another stratum
\(\sigma_\gamma\).  It has no root-admissible parent closure, but its
\(V\)-closure is a root-admissible child target:

\[
 p_{00}^1(\sigma_\gamma)=p_{10}^1(\sigma_\gamma)
 =p_{01}^1(\sigma_\gamma)=p_{11}^1(\sigma_\gamma)=0,
\qquad
 x_V^1(\sigma_\gamma)=1.
\tag{8}
\]

Thus new-cell occupancy may be absent from a parent-target stratum and
appear in a stratum having no parent target.  Any implication of the form
(1) must couple distinct old exteriors.

There is also a useful fixed-instance boundary.  In the selected sector,
the examples of Notes 115 and 116 both have

\[
 |{\cal L}_{11}^1|=1,\qquad
 |{\cal L}_{\neg11}^1|=|{\cal C}^1|=2,
\tag{9}
\]

and their sterile endpoints have the same two interval words (6) and the
same displayed centre--two-leaf region-tree form.  Yet Note 115 has a
\(V^1\)-target and Note 116 has

\[
 {\cal N}^1=\varnothing.
\tag{10}
\]

Their opposite-sector data differ, so (9)--(10) rule out only a formula
using the displayed selected-sector marginals; they do not rule out an
identity using the complete actual families.

## 3. The additive projection

Fix \(R=\mathbb Z\) or \(\mathbb F_2\).  Let

\[
 v(\sigma)=
 (p_{00}^b,p_{10}^b,p_{01}^b,p_{11}^b,
  c_{00}^b,c_{10}^b,c_{01}^b,
  x_R^b,x_U^b,x_V^b)_\sigma,
\tag{11}
\]

with the gate bit and complete ordered exterior signature retained as
labels.

A **per-stratum additive identity** is an equality

\[
 \sum_\sigma n_\sigma\,
 \lambda_{\tau(\sigma)}(v(\sigma))=0
 \quad\text{in }R,
\tag{12}
\]

where the linear functional may depend on the full ordered-signature
label \(\tau(\sigma)\), and where

\[
 \lambda_{\tau(\sigma)}(v(\sigma))=0
\tag{13}
\]

is valid for every individual stratum.  Equivalently, (12) remains valid
after arbitrary deletion or duplication of strata.  This class includes
the canonical identities (5), their restrictions to any fixed ordered
signature, and all definitional sums such as

\[
 P_{\neg11}^b=P_{00}^b+P_{10}^b+P_{01}^b,\qquad
 N^b=X_R^b+X_U^b+X_V^b.
\tag{14}
\]

It deliberately excludes identities whose proof constrains which
different strata occur together in the complete NAE family of one actual
triangulation.

## 4. Exact route closure

**Proposition.**  Even after retaining a distinguished mixed parent
rooted bond, the collection of all per-stratum additive identities over
\(\mathbb Z\) or \(\mathbb F_2\) does not imply mixed-sector survival
(1).

**Proof.**  Start with the actual exterior-signature table of the
crossed-double-split example in
[Note 116](116-a-mixed-parent-bond-does-not-force-same-sector-new-cell-occupancy.md).
Retain its sterile state-\(11\) stratum \(\sigma_\chi\) in sector \(1\),
the opposite-sector non-\(11\) stratum containing the displayed endpoint
\(\eta\), its canonical child, and the distinguished mixed rooted bond

\[
 \chi^1-\eta^0.
\tag{15}
\]

Delete the two sector-\(1\) non-\(11\) exterior strata and therefore
their two signature-identical canonical \(C_{10}^1\) closures.  The
resulting formal projection has

\[
 {\cal L}_{\neg11}^{\,1}=\varnothing,\qquad
 {\cal C}^1=\varnothing,\qquad
 {\cal N}^1=\varnothing,
\tag{16}
\]

while (15) remains.  Every identity (12) remains valid because its
contribution vanishes on each retained stratum separately.  The projected
table therefore satisfies the antecedent of (1), including the mixed
bond, and falsifies its conclusion. \(\square\)

The table in this proof is not the complete NAE family of an actual
triangulation split.  This is not a defect in the proposition: it is
exactly the distinction between a stratumwise projection and a
complete-family identity.

## 5. Remaining boundary

The maximal conclusion established here is

\[
\boxed{\text{per-exterior integer and mod-two additive projections do
not force }P_{\rm sector}.}
\tag{17}
\]

The following stronger possibilities remain open:

* a linear or parity identity valid only for complete actual NAE
  families;
* a non-additive exchange rule coupling different exterior colourings;
* an actual \(P_{\rm sector}\) counterexample.

Accordingly, further counting is relevant only if it retains a
cross-stratum realizability constraint from the common
\(4\)-connected Eulerian triangulation.  Marginal sector counts and
ordered component signatures treated independently cannot decide the
rooted split-bond lemma.
