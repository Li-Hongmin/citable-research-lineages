> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One-sided flanks of a double-vacancy block are Hamiltonian

[Note 224](224-an-isolated-double-vacancy-block-has-a-unique-hamilton-matching.md)
settles a target-free face block with two vacancies when its free
matching group has no short face block on either side. Here any
number of short blocks may precede that block, but none follows it.
The matching is either the isolated local pattern or a two-link
rainbow detour. Every case has a Hamilton cycle through both site edges.

Work in the compressed all-square Barnette opening of
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md),
with \(\ell,r\ge1\), empty interblock gaps, tight target order,
and exactly two eligible vacancies. Both vacancies lie in one
target-free face-chord block \(D\), whose six free slots, in
old-cycle order, are
\[
o,h_1,i_1,h_2,i_2,e.                                      \tag{1}
\]
Suppose the complete free matching group containing them is
\[
e_0,(o_1,e_1),\ldots,(o_t,e_t),
 (o,h_1,i_1,h_2,i_2,e),o_R,\qquad t\ge0,                 \tag{2}
\]
where the \(t\) intervening face-chord blocks are short and
target-free. The endpoint blocks containing \(e_0,o_R\) may
contain occupied target runs. Put \(o_{t+1}=o\), and call
\(e_j o_{j+1}\), \(0\le j\le t\), the ordinary chain links.

**One-sided double-vacancy theorem.** The free matching on (2)
has one of the following forms:
\[
\begin{aligned}
\text{local: }&
 \{e_j o_{j+1}:0\le j<t\}
 \cup\{e_ti_1,\ oe,\ h_1i_2,\ h_2o_R\};             \tag{3}\\
\text{rainbow }(d,a):&
 \{e_j o_{j+1}:0\le j\le t,\ j\notin\{d,a\}\}\\
&\quad\cup
 \{e_di_2,\ o_{d+1}h_2,\ e_ai_1,\ o_{a+1}h_1,\ eo_R\},
 \qquad 0\le d<a\le t-1.                            \tag{4}
\end{aligned}
\]
In particular, the local form is forced when \(t\le1\).
For every form the parent has a Hamilton cycle containing both
site edges \(xy,uv\). Its legal site-expanded child is Hamiltonian.
Reversal gives the same conclusion for any number of short blocks
on the right and none on the left; arbitrary positive original
lobe lengths are allowed.

**Proof of classification.** We use two facts from
[Notes 193 and 196](193-three-lobes-have-the-exact-chord-packing-bound.md):
every free chord joining different blocks lies in the disk
opposite the site face, and a proper complete consecutive
block interval closed under the complementary matching would
have exactly two exiting old-cycle edges, contradicting
three-connectivity. No two opposite-side chords interlace.

Start at a left boundary \(e_d\) after the preceding short
blocks, if any, have followed their standard chain links.
There are \(s=t-d\) short blocks before \(D\). Its odd mate
is one of the first slots \(o_{d+1},\ldots,o_t,o\),
the two long-block slots \(i_1,i_2\), or \(o_R\).
Matching a first slot other than \(o_{d+1}\) encloses a
nonempty complete interval of short blocks. Matching \(o_R\)
encloses all the remaining complete blocks. Both make a
forbidden two-edge cut. Thus the choices are
\(o_{d+1},i_1,i_2\); when \(s=0\), the first choice
means \(o\).

Suppose \(s\ge1\) and \(e_di_1\in M\). Its opposite-side
chord encloses all \(2s\) short-block slots and \(o,h_1\).
A short-block slot cannot match outside this chord. If no
short slot matched \(o\) or \(h_1\), all \(s\) complete
short blocks would be matching-closed. The number of their
matching edges to \(\{o,h_1\}\) is even, since they have
\(2s\) vertices. Hence both \(o,h_1\) must match short
slots. The four remaining slots \(h_2,i_2,e,o_R\) admit no
perfect matching: \(h_2i_2\) and \(i_2e\) are old-cycle
edges, and colours leave only the pairings
\((h_2i_2)(eo_R)\) or \((h_2o_R)(i_2e)\).
Therefore \(e_di_1\notin M\).

Now suppose \(s\ge1\) and \(e_di_2\in M\). The final
slot \(o_R\) can match no vertex inside that opposite-side
chord; its only remaining mate is \(e\), so \(eo_R\in M\).
The only possible same-block free chord in \(D\) is then
\(oh_2\). If it existed, the first short-block slot
\(o_{d+1}\) could match only \(h_1\) or some later
short-block \(e_j\): its own \(e_{d+1}\) is adjacent on
the old cycle. The choice \(o_{d+1}e_j\) encloses a
matching-closed complete short-block interval, so
\(o_{d+1}h_1\) is forced. But \(i_1\) must then match
some short-block even slot \(e_j\). The opposite-side
chords \(o_{d+1}h_1\) and \(e_ji_1\) interlace, a
contradiction. Thus \(oh_2\notin M\); every remaining
free chord joins different blocks and lies in the
opposite-side disk.

An edge between two ordinary slots is now necessarily a
standard chain link. Indeed, an \(e_j o_k\) skipping a
block encloses complete short blocks, whereas a backward
\(o_k e_j\) encloses a complete block interval; either
would be a two-edge cut. Same-block ordinary pairs are
old-cycle edges. The fixed edges \(e_di_2,o_Re\) remove
\(e_d,o_R,i_2,e\). The first short slot \(o_{d+1}\)
must match \(h_2\): any later short \(e_j\) would close
a complete block interval, and its only other long-block
even candidate \(h_1\) would leave \(i_1\) crossing it
as above. All remaining ordinary slots therefore follow
the standard chain except for exactly one missing link
\(e_a o_{a+1}\), whose ends match \(i_1,h_1\), respectively.
Here \(d<a\le t-1\): \(a=d\) is already the first
missing link, while \(a=t\) would require the old-cycle
edge \(oh_1\). This is (4). Its long chords are nested
in the order
\[
e_di_2\supset o_{d+1}h_2\supset
e_ai_1\supset o_{a+1}h_1.                            \tag{5}
\]

If instead \(e_d o_{d+1}\in M\), remove that completed
short block and repeat at \(e_{d+1}\). At \(d=t\)
the remaining eight slots have precisely the setting of
Note 224, which forces \(e_ti_1,oe,h_1i_2,h_2o_R\).
This proves (3)--(4) by induction. \(\square\)

**Marked Hamilton route.** Let \(A\) be the even-starting
old-cycle matching from \(x\). Note 196 gives the
target-and-square \(x\)-to-\(v\) path, unchanged here.
Each short face block contributes the ordinary segment
\(o_j,a_j,b_j,e_j\), and \(D\) contributes
\(o,a_D,b_D,e\). For (3), follow the short-block chain
and use Note 224's replacement
\[
e_t,i_1,h_1,o,a_D,b_D,e,i_2,h_2,o_R.                \tag{6}
\]
For (4), retain every standard chain link except the
two missing ones and replace them, in path order, by
\[
e_d,o_{d+1}\ \longmapsto\ e_d,i_2,h_2,o_{d+1},
\qquad
e_a,o_{a+1}\ \longmapsto\ e_a,i_1,h_1,o_{a+1}.     \tag{7}
\]
The outer edges of each replacement lie in \(M\), and
\(i_2h_2,i_1h_1\in A\). Both replacements are
vertex-disjoint and keep the free vertices on one
spanning \(x\)-to-\(v\) path. With the unchanged
target-and-square path they form a Hamilton cycle using
\(xy,uv\). Note 001 lifts that cycle through the legal
site expansion; Note 178 restores longer lobes.
\(\square\)

**A realized rainbow.** The \(t=2,d=0,a=1\) form occurs
in a Barnette graph. Take the 28-cycle, displayed as
consecutive blocks,
\[
\begin{array}{ll}
B_0:&x,R,e_0,y,\\
B_1:&a_1,o_1,e_1,b_1,\\
B_2:&a_2,o_2,e_2,b_2,\\
D:&a_3,o,h_1,i_1,h_2,i_2,e,b_3,\\
B_4:&u,o_R,L,v,\\
\text{last arc}:&\alpha,\gamma,\delta,\beta,
\text{ returning to }x.
\end{array}                                               \tag{8}
\]
Add the complementary perfect matching consisting of
\[
\begin{split}
&xy,uv,\ a_1b_1,a_2b_2,a_3b_3,
 \alpha\beta,\delta R,\gamma L,\\
&e_0i_2,o_1h_2,e_1i_1,o_2h_1,e_2o,eo_R.
\end{split}                                               \tag{9}
\]
All matching edges join opposite cycle parities. Draw
the site, face, and \(\alpha\beta\) chords on the
site-face side. On the other side, the five long free
chords in (9) are nested in the displayed order;
\(eo_R\) is disjoint from them, and \(\delta R,\gamma L\)
nest around the appropriate suffix. Thus the graph is
plane, simple, cubic and bipartite, with \(xy,uv\)
cofacial. Its matching-chord interlacement graph is
connected: the chain
\[
xy-e_0i_2-a_3b_3-eo_R-uv-\gamma L-
\alpha\beta-\delta R-xy                               \tag{10}
\]
is joined to \(a_1b_1\) through \(o_1h_2\), to
\(a_2b_2\) through \(o_2h_1\), to \(e_1i_1\) through
\(a_1b_1\), and to \(e_2o\) through \(a_2b_2\).
Each stated interlacement follows from (8). A
matching-closed proper cycle interval would disconnect
this interlacement graph, so the parent has no two-edge
cut and is three-connected, as in Note 217. The site
colours permit the standard four-vertex expansion;
Note 217's cut projection verifies that the 32-vertex
child is also Barnette. The Hamilton route is (7).
\(\square\)

This theorem covers arbitrary flanks on **one** side of a
target-free same-block double vacancy. It does not decide
groups with short blocks on both sides, vacancy blocks with
occupied targets, outer-block vacancies, defective target
order, interblock gaps, or nonsquare residual cycles.

