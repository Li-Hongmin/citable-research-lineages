> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every tight gapless internal double vacancy is Hamiltonian

[Note 233](233-all-tight-gapless-same-block-double-vacancies-are-hamiltonian.md)
settles two vacancies in one face block. For distinct
face blocks, [Note 215](215-separated-vacancies-compose-marked-hamilton-routes.md)
settles a separating occupied target,
[Note 223](223-two-target-free-vacancies-in-one-group-always-have-a-marked-hamilton-cycle.md)
settles two target-free blocks in one free group, and
[Note 232](232-facing-target-bearing-vacancies-are-hamiltonian.md)
settles two target-bearing blocks facing a shared free
group. The remaining shared group has one target-free
vacancy block and one target-bearing vacancy block.
Its only possible same-block free chord is impossible.

Use a compressed all-square Barnette opening, with
\(\ell,r\ge1\), empty interblock gaps, tight target
order, and exactly two eligible vacancies. Both lie
in internal face-chord blocks \(B_k\), \(1\le k\le r\).
Equivalently, the free-main-vertex count is
\(f=4r+6\) in the notation of Note 197.

**Internal double-vacancy theorem.** The parent has
a Hamilton cycle through both cofacial site edges
\(xy,uv\), and its legal site-expanded child is
Hamiltonian. This holds for arbitrary positive
original square-trap lobe lengths and every
placement of the two vacancies among internal
face blocks.

Only the mixed distinct-block case remains to prove.
Reflect the old-cycle order if necessary, so the
left vacancy lies in a target-free block \(X=B_k\)
and the right vacancy in a target-bearing block
\(Y=B_m\), \(k<m\), with no occupied target between
them. Then the vacancy of \(Y\) is its first
eligible position and all its occupied target
pairs lie after it. Let \(h_X,i_X\) and
\(h_Y,i_Y\) be the vacant even slot and its
following odd slot in the two blocks. The free
matching group containing them starts at some
ordinary final even slot \(E_0\), passes through
zero or more short blocks, the complete free
interior \(o_X,h_X,i_X,e_X\) of \(X\), zero
or more short blocks, and ends at
\(o_Y,h_Y,i_Y\) immediately before the
occupied run of \(Y\). The other free groups
contain no vacancy.

All occupied target runs are matching barriers.
For every run the preceding free-slot prefix is
even: each earlier vacancy contributes two slots.
Note 203 forbids a cross-block free chord over an
escape target. In \(Y\), only its final free slot
lies after the occupied run, so at most one
same-block free chord could cross; parity excludes
it. The same argument applies in the other
target-bearing blocks. Thus the displayed group
is closed under the free matching, and other
groups follow Note 208's standard chain.

Enumerate its ordinary standard links from left
to right as \(P_j=(E_j,O_j)\). Both slots
\(h_X,i_X\) lie between two consecutive port
pairs, denoted \(P_L=(E_L,o_X)\) and
\(P_R=(e_X,O_R)\). The slots \(h_Y,i_Y\)
follow the last port pair \(P_N=(E_N,o_Y)\),
so every port pair lies wholly before \(Y\).
The only non-cycle matching edge with both
endpoints in one block is
\[
J=o_Xe_X.                                         \tag{1}
\]
As in Note 227's ordinary-edge rule, every
ordinary-to-ordinary matching edge other than
\(J\) is a standard link \(P_j\). Indeed, a
nonstandard cross-block edge would enclose or
run backward around a nonempty complete block
interval. Every other cross-block free chord
leaving that interval would interlace it in
the opposite-side disk. Any same-block chord
stays within its block. The interval would be
matching-closed, with only two exiting old-cycle
edges, contrary to three-connectivity.

**The internal chord cannot occur.** Suppose
\(J\in M\). It uses the ordinary endpoints
\(o_X=O_L\) and \(e_X=E_R\), so both
\(P_L,P_R\) are missing. The even port
\(E_L\) can match only one of the extra odd
slots \(i_X,i_Y\). If \(E_Li_X\) occurred,
the even slot \(h_X\) would have no mate:
\(o_X\) is used, \(h_Xi_X\) is an old-cycle
edge, and every free odd mate outside
\(E_Li_X\) would interlace that opposite-side
chord. Hence \(E_Li_Y\in M\).

The odd port \(O_R\) can now match only one
of the extra even slots \(h_X,h_Y\). If
\(h_XO_R\) occurred, the odd slot \(i_X\)
would have no mate: \(e_X\) is used,
\(h_Xi_X\) is an old-cycle edge, and every
free even mate outside \(h_XO_R\) would
interlace it. Thus \(O_Rh_Y\in M\).
Finally \(h_X\) has no mate. Every earlier
ordinary odd port lies before \(E_L\), so
its chord to \(h_X\) would interlace
\(E_Li_Y\). Every later ordinary odd port
lies after \(O_R\), so its chord to \(h_X\)
would interlace \(O_Rh_Y\). The only ordinary
odd ports between \(E_L,O_R\) are
\(o_X=O_L\), already used by \(J\);
\(i_X\) is an old-cycle neighbour and
\(i_Y\) is used. This contradiction proves
\(J\notin M\).

Consequently all free matching edges in this
group join different blocks, lie in one
noncrossing disk opposite the site face,
and every ordinary-to-ordinary edge is a
standard link. Let \(c\in\{0,1,2\}\) be the
number of edges among the four vacancy slots.
Exactly \(2-c\) standard links are missing.

If \(c=2\), the only possible extra matching
edges are \(h_Xi_Y,i_Xh_Y\), and all standard
links remain. The vacancies lie in one
target-free interval from some \(R_j\) to
\(L_j\). Note 231's same-square sweep follows
old-cycle edges through both vacant pairs
and standard links between blocks. Its
second path follows the exposed face chords;
the two paths give a marked Hamilton cycle.

If \(c=1\), one link \(P_a=(E_a,O_a)\) is
missing. When the extra edge is \(h_Xi_Y\),
replace \(E_aO_a\) in Note 196's ordinary
free path by
\[
E_a,i_X,h_X,i_Y,h_Y,O_a.                         \tag{2}
\]
When it is \(i_Xh_Y\), use instead
\[
E_a,i_Y,h_Y,i_X,h_X,O_a.                         \tag{3}
\]
The first, middle and last new edges belong
to the complementary matching, and the other
two are old-cycle edges. Each replacement
spans all four vacancy slots.

If \(c=0\), two standard links
\(P_a,P_b\), \(a<b\), are missing.
Their four endpoints match the four
vacancy slots. If each vacancy pair
reconnects one port pair, replace
\(E_jO_j\) by \(E_j,i,h,O_j\) for each.
A crossed reconnection is impossible by
the exact planarity and two-edge-cut
argument in Note 223 (3). Its proof
uses only the order of the two vacancy
pairs and the port pairs. Here all port
pairs are either left of \(X\) or
between \(X,Y\), with none right of
\(Y\): the type-I assignment would
need its later port right of \(Y\),
while type II either has interlacing
chords or closes the complete block
interval between its two ports into a
two-edge cut. Thus the two independent
three-edge replacements give one
spanning free path.

In the \(c=1,0\) cases, that free path
and Note 196's unchanged target-and-square
path meet only at \(x,v\). All cases
therefore have a Hamilton parent cycle
through \(xy,uv\). Reflecting proves
the mixed case with the target-bearing
block on the left. Notes 001 and 178
give the legal child and longer original
lobes. \(\square\)

**Exhaustion of internal placements.** If the two
vacancies share a face block, Note 233 applies.
Otherwise, if an occupied target separates them,
Note 215 applies. If no target separates them,
each vacancy block is either target-free or
target-bearing. Two target-free blocks are
Note 223; two target-bearing blocks must face
their shared free group and are Note 232;
exactly one target-bearing block is the mixed
case just proved. These alternatives exhaust
the theorem's hypotheses. \(\square\)

**A realized mixed profile.** Let \(\ell=r=2\),
\(X=B_1\), \(Y=B_2\), with the old 30-cycle
\[
\begin{array}{ll}
B_0:&x,R_2,e_0,y,\\
X:&a_1,o_1,h_X,i_X,e_1,b_1,\\
Y:&a_2,o_Y,h_Y,i_Y,L_2,R_1,e_2,b_2,\\
B_3:&u,o_3,L_1,v,\\
S_j:&\alpha_j,\gamma_j,\delta_j,\beta_j
\quad(j=1,2),\text{ returning to }x.
\end{array}                                           \tag{4}
\]
The complementary perfect matching is
\[
\begin{split}
M={}&\{xy,uv,a_1b_1,a_2b_2\}\\
&\cup\{\alpha_j\beta_j,\gamma_jL_j,
          \delta_jR_j:j=1,2\}\\
&\cup\{e_0o_1,e_1o_Y,e_2o_3,
          h_Xi_Y,i_Xh_Y\}.
\end{split}                                           \tag{5}
\]
Put the site, face and \(\alpha_j\beta_j\)
chords on the site-face side. Opposite it,
the escape chords nest as
\(R_2\delta_2\supset L_2\gamma_2
\supset R_1\delta_1\supset L_1\gamma_1\).
The free chords \(e_0o_1,e_2o_3\) lie in
separate gaps, and
\(h_Xi_Y\supset i_Xh_Y\supset e_1o_Y\)
is nested in the gap before \(L_2\gamma_2\).
Thus this 30-vertex parent is simple,
cubic, bipartite, plane, with cofacial
site edges.

Its matching-chord interlacement graph
is connected: the alternation chain
\[
xy-e_0o_1-a_1b_1-e_1o_Y-a_2b_2-e_2o_3-
uv-L_1\gamma_1-\alpha_1\beta_1-R_1\delta_1-
a_2b_2-L_2\gamma_2-\alpha_2\beta_2-
R_2\delta_2-xy
\tag{6}
\]
contains all its matching edges except
\(h_Xi_Y,i_Xh_Y\), which each interlace
\(a_1b_1\). Note 217's interval
criterion gives three-connectivity;
its cut projection makes the 34-vertex
site expansion Barnette. The marked
Hamilton cycle consists of the
internally disjoint paths
\[
\begin{split}
&x,y,a_1,b_1,a_2,b_2,u,v,\\
&x,\beta_2,\delta_2,R_2,e_0,o_1,h_X,i_X,e_1,
o_Y,h_Y,i_Y,L_2,\gamma_2,\alpha_2,\beta_1,
\delta_1,R_1,e_2,o_3,L_1,\gamma_1,\alpha_1,v.
\end{split}                                           \tag{7}
\]
They cover all 30 vertices and contain \(xy,uv\).
\(\square\)

This proves the entire internal two-vacancy
branch at \(f=4r+6\) under the all-square,
tight-target, empty-gap hypotheses. It
does not treat vacancies in the two
outer site blocks, target-order defects,
gaps, nonsquare residual cycles, or all
Barnette graphs.
