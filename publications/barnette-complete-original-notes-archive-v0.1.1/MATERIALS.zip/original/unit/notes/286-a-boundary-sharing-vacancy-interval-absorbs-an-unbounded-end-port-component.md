> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A boundary-sharing vacancy interval absorbs an unbounded end-port component

Note 282 gives three spanning four-port routes when a port is the
first atom of its component and its source block is short. The
source block may instead be vacant in a separate component. The
following attachment rule handles that overlap, including an
arbitrary vacancy-only interval to the left and arbitrarily many
vacancies in the port component to the right.

Work in the compressed, gapless, tight-target all-square opening
of Notes 196 and 278. Vacancies lie in distinct target-free
internal face-chord blocks. Let \(L=B_a,\ldots,B_s\) be a nonempty
consecutive interval whose vacancy matching is closed inside it
and whose internal ordinary links are retained. It has the
vertex-spanning \(S(L),K(L),X(L)\) routes of Note 275. The ordinary
link \(P_s=e_so_{s+1}\) is missing. To its right, let the component
containing \(P_s\) have the atoms
\[
 P_s<V_{k_1}<\cdots<V_{k_m},\qquad
 m\ge1,\quad k_1\ge s+2,\quad u=k_m.                 \tag{1}
\]
All other atoms in \(B_{s+1},\ldots,B_u\) belong to vacancy-only
components in the proper gaps of (1); all other ordinary links
in \(Q=B_a,\ldots,B_u\) are retained. In particular, \(B_s\)
may be vacant, and its vacancy may be the final atom of a
component entirely inside \(L\).

**Boundary-sharing attachment theorem.** The full interval \(Q\)
has all three vertex-spanning four-port states
\[
\begin{array}{ll}
S(Q):&o_a\longleftrightarrow e_u,\\
K(Q):&a_a\longleftrightarrow o_a,\quad
       e_u\longleftrightarrow b_u;\\
X(Q):&a_a\longleftrightarrow b_u,\quad
       o_a\longleftrightarrow e_u.
\end{array}                                             \tag{2}
\]
The reflected statement holds when the port is last in its
component and the target block on its other side belongs to a
closed right interval. Thus the short source or target condition
of Note 282 is unnecessary for this boundary-sharing pattern.

**Proof.** The matching edges in the port component are
\[
 e_sI_u,\qquad o_{s+1}H_{k_1},\qquad
 I_{k_t}H_{k_{t+1}}\quad(1\le t<m).                    \tag{3}
\]
Noncrossing makes each proper gap of (1) closed under the
matching. The first gap
\(G=B_{s+1},\ldots,B_{k_1-1}\) is nonempty; every nonempty
gap has \(S,K,X\) by Note 275. The boundary link before or
after each \(V_{k_t}\), other than \(P_s\), is retained.

Let \(\Pi_R\) be the ordinary path from \(o_{s+1}\) to \(e_u\)
through \(B_{s+1},\ldots,B_u\), using \(S\) in each closed
gap and the face chord \(a_{k_t}b_{k_t}\) in every displayed
vacant block. It visits every vertex of this right interval
except the pairs \(H_{k_t},I_{k_t}\). The detour
\[
 \Delta:\quad e_s,I_u,H_u,
 (I_{k_t},H_{k_t})_{t=m-1,\ldots,1},o_{s+1}             \tag{4}
\]
uses exactly those omitted vertices. Its joins are (3) and the
old-cycle edges \(H_{k_t}I_{k_t}\). Consequently
\[
 o_a\xrightarrow{S(L)}e_s
 \xrightarrow{\Delta}o_{s+1}
 \xrightarrow{\Pi_R}e_u                              \tag{5}
\]
is a spanning straight path.

Next construct a path \(T:b_s\longleftrightarrow b_u\) through
all vertices of \(B_{s+1},\ldots,B_u\) except \(I_u,e_u\).
For \(m=1\), traverse both \(X(G)\) rails:
\[
 b_s,a_{s+1}\xrightarrow{X_{\rm top}(G)}b_{u-1},
 e_{u-1}\xrightarrow{X_{\rm bottom}(G)^{-1}}o_{s+1},
 H_u,o_u,a_u,b_u.                                      \tag{6}
\]
Here \(o_{s+1}H_u\) is in (3). For \(m\ge2\), put
\(v=k_{m-1}\). Begin with
\[
 b_s\xrightarrow{C\text{ forward}}I_v,H_u,o_u,e_{u-1}.
                                                            \tag{7}
\]
The edge \(I_vH_u\) is in (3), and \(o_ue_{u-1}\) is a
retained ordinary link. This covers all blocks through \(B_v\)
except \(e_v,b_v\). If \(u=v+1\), finish with \(b_v,a_u,b_u\).
Otherwise the final gap \(F=B_{v+1},\ldots,B_{u-1}\) has
\(X(F)\); finish by
\[
 e_{u-1}\xrightarrow{X_{\rm bottom}(F)^{-1}}o_{v+1},
 e_v,b_v,a_{v+1}
 \xrightarrow{X_{\rm top}(F)}b_{u-1},a_u,b_u.       \tag{8}
\]
Equations (7)--(8) use both rails of \(F\) and the retained
link \(e_vo_{v+1}\). The old-cycle arc covers every earlier
gap and vacancy, independently of their matching. Thus (6)
or (7)--(8) has precisely the claimed coverage.

Write \(K_R(L)\) for the path \(e_s\longleftrightarrow b_s\)
in \(K(L)\), and \(X_{\rm top}(L),X_{\rm bottom}(L)\) for its
two crossed paths. The cap state of \(Q\) is the untouched
\(a_a\longleftrightarrow o_a\) path of \(K(L)\), together with
\[
 e_u,I_u,e_s\xrightarrow{K_R(L)}b_s
 \xrightarrow{T}b_u.                                  \tag{9}
\]
The crossed state is
\[
 a_a\xrightarrow{X_{\rm top}(L)}b_s
 \xrightarrow{T}b_u,
 \qquad
 o_a\xrightarrow{X_{\rm bottom}(L)}e_s,I_u,e_u.    \tag{10}
\]
The path \(T\) omits exactly \(I_u,e_u\), supplied by the
two-edge prefix or suffix in (9)--(10). The routes of \(L\)
cover \(L\) once, and (3) supplies \(e_sI_u\). Hence both
pairs of paths are disjoint and span \(Q\). Reflection gives
the other orientation. \(\square\)

**Signature-only attachment.** Equations (5), (9), and (10)
use \(L\) solely through its three spanning states and the
right boundary vertices \(e_s,b_s\). Thus the same conclusion
holds when \(L\) contains already resolved port components:
it suffices that its induced interval has \(S(L),K(L),X(L)\),
the new port edges are (3), and the proper gaps to the
right have the stated routes and retained attachments.
No matching classification inside \(L\) is needed for
this composition rule.

This pattern occurs in Barnette parents of unbounded order.
For every \(m\ge1\), use the site blocks and residual square
of Note 281(8), take \(r=m+3\), make \(B_1,B_2\) and
\(B_4,\ldots,B_r\) vacant, and make \(B_3\) short. Keep
every standard free link except \(P_2=e_2o_3\). Along with
the unchanged site, face, escape, and residual-square edges,
take the free matching edges
\[
 H_1I_2,\quad I_1H_2,\quad e_2I_r,\quad o_3H_4,
 \quad I_jH_{j+1}\ (4\le j<r).                      \tag{11}
\]
The first two edges form a vacancy-only component in
\(L=B_1,B_2\), while the remaining edges form the
component \(P_2<V_4<\cdots<V_r\). Every free slot is
matched exactly once. All matching edges join opposite
old-cycle colours. In the disk opposite the common site
face, \(H_1I_2\) encloses \(I_1H_2\), while \(e_2I_r\)
encloses the right-hand edges of (11); these two chord
systems are disjoint, and the retained standard links
lie inside or outside them without crossing.

The matching-chord interlacement graph is connected:
the retained standard links connect the face chords up to
\(B_2\) and from \(B_3\) through \(B_r\), while \(e_2I_r\)
interlaces the face chords of \(B_2\) and \(B_r\), joining
these chains. Every other edge in (11) interlaces an
endpoint face chord, and the unchanged site and residual
square have Note 281's closing chain. Note 217's cut
argument and Note 182's cubic lemma give three-vertex
connectivity. The parent has \(6m+28\) vertices; (2) gives
a marked Hamilton cycle, and its legal expanded child has
\(6m+32\) vertices and a Hamilton cycle.

The theorem settles the boundary overlap in which the
source-block vacancy belongs to a closed preceding interval.
It does not cover a source-block vacancy in a component
that surrounds the port component, nor multiple missing
links without the stated three-state left interface.
