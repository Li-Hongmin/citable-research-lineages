> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every three-double J1/J3 free group has a spanning route

[Note 343](343-a-j3-j1-j1-triple-needs-a-right-corridor-and-occurs.md)
forces the position of a \(J_3,J_1,J_1\) triple but leaves its
matching types and spanning route open. Here all matching edges
inside the triple and its required corridor are forced except
the optional chord \(h_1j_3\) and attachments to the outer short
flanks. Both possibilities admit a spanning route.

Use the compressed, gapless, tight-target all-square Barnette opening
of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix an ordinary target-free free group with exactly three doubly
vacant complete blocks, all other complete blocks being short. In
old-cycle order write
\[
D_s=(a_s,o_s,h_s,i_s,k_s,j_s,e_s,b_s),\qquad s=1,2,3,
                                                               \tag{1}
\]
and assume its internal free chords are
\(i_1e_1=J_3,o_2k_2=J_1,o_3k_3=J_1\). Let
\(L,R\) be the ordinary even left and odd right endports.

**Triple-group theorem.** The first two double blocks are adjacent.
Between the second and third are \(q\ge1\) short blocks
\(S_t=(c_t,r_t,s_t,d_t)\), \(1\le t\le q\). Independently of
the numbers and matching choices of short blocks before \(D_1\)
and after \(D_3\), the opposite-side matching inside the interval
from \(D_1\) through \(D_3\) has the forced edges
\[
j_1h_2,\quad k_1i_3,\quad i_2h_3,\quad
j_2s_q,\quad e_2r_1,\quad
s_tr_{t+1}\ (1\le t<q).                              \tag{2}
\]
Its only still-free matching slots are
\(o_1,h_1,j_3,e_3\), in that order. Every matching of these
slots to each other and to arbitrary outer short flanks that occurs
in such a Barnette opening gives a vertex-spanning \(L\)--\(R\)
path through the entire group. Consequently, if all vacancies
outside this group occupy distinct internal blocks, the parent has
a Hamilton cycle through both site edges and its legal site-expanded
child is Hamiltonian. Old-cycle reflection gives the same assertion
for the \(J_3,J_3,J_1\) order with the corridor on the other side.

**Forced core.** Note 343 already proves adjacency of \(D_1,D_2\),
\(q\ge1\), and \(j_1h_2\in M\). Its chord-isolation and
opposite-page rules reduce the ordered free slots of the core to
\[
o_1,h_1,k_1,j_1,h_2,i_2,j_2,e_2,
(r_t,s_t)_{t=1}^{q},h_3,i_3,j_3,e_3.                 \tag{3}
\]
The even slot \(k_1\) can meet only \(i_2\) or \(i_3\).
Indeed, \(o_1k_1\) is forbidden by chord isolation and
\(k_1j_1\) is an old-cycle edge. The odd slots \(j_2,r_t,j_3\)
to its right enclose respectively \(3,5+2(t-1),7+2q\)
other slots in (3), so noncrossing excludes them. A right outer
odd slot or \(R\) encloses \(9+2q\) core slots plus complete
outer pairs. A left outer odd slot encloses its own even slot,
complete left pairs, and \(o_1,h_1\). These counts are odd.

Suppose \(k_1i_2\) occurred. Every possible mate of the even
slot \(h_3\) to the left of \(k_1\) would cross \(k_1i_2\).
The slots \(j_1,i_2\) are already matched. A chord \(j_2h_3\)
would enclose \(e_2\) and \(2q\) corridor slots; a chord
\(r_th_3\) would enclose \(s_t\) and \(2(q-t)\) later
corridor slots. Both enclose an odd number of free slots.
The same-block choices \(h_3i_3,h_3j_3\) are respectively
an old-cycle edge and a forbidden internal chord. Any right
outer odd mate or \(R\) leaves \(i_3,j_3,e_3\) and complete
outer pairs inside, again an odd number. There is no mate for
\(h_3\). Thus \(k_1i_3\) is forced.

Now \(i_2\) lies inside \(k_1i_3\). Its same-block even mate
\(e_2\) is forbidden. A chord \(i_2s_t\) encloses
\(j_2,e_2\), the previous \(2(t-1)\) corridor slots, and
\(r_t\), an odd number. Every other available even mate is
outside \(k_1i_3\), so \(i_2h_3\) is forced. Inside it
remain \(j_2,e_2,(r_t,s_t)_{t=1}^{q}\).
The old-cycle edge \(j_2e_2\) is unavailable. If \(j_2\)
met \(s_t\) for \(t<q\), the suffix of complete short
blocks \(S_{t+1},\ldots,S_q\) would be matching-closed and
give a two-edge cut. Hence \(j_2s_q\). If \(e_2\) met
\(r_t\) for \(t>1\), the prefix \(S_1,\ldots,S_{t-1}\)
would give the same cut. Hence \(e_2r_1\), and noncrossing
forces the remaining links \(s_tr_{t+1}\). This proves (2).

**Three paths in the core.** Put
\[
U_q=(c_t,r_t,s_t,d_t)_{t=1}^{q},\qquad
V_q=(s_q,r_q,s_{q-1},r_{q-1},\ldots,s_1,r_1,
      c_1,d_1,c_2,d_2,\ldots,c_q,d_q).                 \tag{4}
\]
The tuples in \(U_q\) use only consecutive old-cycle edges.
In \(V_q\), the descending joins \(r_ts_{t-1}\) use (2),
the ascending joins \(c_td_t\) use face chords, and all
other joins use old-cycle edges. The two vertex-disjoint paths
\[
\begin{split}
A_q={}&(o_1,a_1,b_1,a_2,o_2,h_2,i_2,k_2,j_2,e_2,b_2,
       U_q,a_3,b_3,e_3),\\
B_q={}&(j_3,k_3,o_3,h_3,i_3,k_1,j_1,e_1,i_1,h_1)
\end{split}                                               \tag{5}
\]
cover every vertex of the core. Their endpoint pairing is
\(\{o_1e_3,j_3h_1\}\). Every join follows from the old
cycle, the block-closing and internal chords, or (2).

If the still-optional opposite-side chord \(h_1j_3\) occurs,
there is also one spanning \(o_1\)--\(e_3\) path:
\[
\begin{split}
P_q={}&(o_1,a_1,b_1,e_1,i_1,h_1,j_3,k_3,o_3,h_3,i_3,
       k_1,j_1,h_2,i_2,k_2,o_2,a_2,b_2,e_2,j_2,\\
      &\hspace{15mm}V_q,a_3,b_3,e_3).
\end{split}                                               \tag{6}
\]
The joins \(h_1j_3,k_1i_3,j_1h_2,j_2s_q\), the descending
corridor links, and the face chords are the only non-old-cycle
joins in (6). Thus (5) handles the absent-chord case and (6)
handles the present-chord case for every \(q\ge1\).

**Four-slot transfer.** We use the following elementary form of
the boundary-link argument of
[Notes 335--336](336-every-two-double-mixed-j1-j3-free-group-has-a-spanning-route.md).
Let a consecutive complete-block core have exactly four residual
matching slots \(o,h,J,E\) in this order; all its other matching
edges are internal. Assume \(oh,JE\) are old-cycle edges,
\(oE\) would close the whole core under the matching, and
all other blocks of its ordinary free group are short flanks.
If the core has a spanning \(o\)--\(E\) path when \(hJ\in M\),
and disjoint spanning paths \(o\)--\(E\) and \(J\)--\(h\)
when \(hJ\notin M\), then the group has a spanning
\(L\)--\(R\) path.

Here is the matching and routing proof, to make the transfer
independent of any symmetry of the core. The chord \(oE\)
is impossible: it would leave only the two old-cycle boundary
edges of the complete core interval. If \(hJ\in M\), only
\(o,E\) remain. Noncrossing and the same two-edge-cut rule
force successive ordinary links through both short flanks,
from \(L\) to \(o\) and from \(E\) to \(R\): if an
endport skipped the next complete block, all skipped blocks
would be matching-closed inside that chord. Insert the
stipulated spanning core path between them.

Suppose \(hJ\notin M\). If there are short blocks on both
sides, at least one of the outer boundary links \(Lr_1\)
or \(v_mR\) is present, where \(r_1\) is the first left
odd free slot and \(v_m\) the final right even free slot.
If \(Lr_1\) were absent, a later left mate of \(L\) would
close a nonempty complete short-block prefix; \(Lo\) would
close the whole left flank; and \(LR\) would close the
whole group. Thus \(L\) would have to meet \(J\) or a
right-flank odd slot. If \(v_mR\) were also absent, a
mate of \(R\) earlier in its right flank, at \(E\), or
in a left short block would close a nonempty complete-block
suffix; \(LR\) is already excluded. The only remaining
even mate of \(R\) is \(h\). But \(hR\) crosses either
remaining possibility for \(L\). This proves the link claim.

For a left boundary link, reserve the spanning five-vertex
segment \(L,r_1,c_1,d_1,s_1\) and use \(s_1\) as the
new left endport. For a right boundary link, reserve
\(u_m,C_m,D_m,v_m,R\) and use \(u_m\) as the new right
endport. The same proof applies to the remaining consecutive
original blocks: any supposedly closed skipped interval is
still a forbidden two-edge cut in the original graph.
Peeling terminates with at most one nonempty flank.

With no flank, the residual word \(L,o,h,J,E,R\) forces
\(Lo,hJ,ER\), contrary to the absent-chord assumption.
For a left-only flank \(S_t=(c_t,r_t,s_t,d_t)\),
\(1\le t\le p\), put \(s_0=L\). The exact remaining
matching has one \(0\le\mu<p\) and is
\[
\begin{split}
&s_{t-1}r_t\quad(1\le t\le\mu),\qquad
s_\mu J,\qquad r_{\mu+1}h,\\
&s_tr_{t+1}\quad(\mu+1\le t<p),\qquad
s_po,\qquad ER.                                       \tag{7}
\end{split}
\]
Indeed \(R\) cannot meet \(L\) or a short even slot
without closing a complete-block interval, and \(hR\)
would trap the forbidden pair \(JE\); hence \(ER\).
The mate of \(J\) is \(s_\mu\), including \(s_0=L\).
The choice \(\mu=p\) traps \(oh\). On either side of
\(s_\mu J\), a skipped short-block interval would be
matching-closed, forcing exactly the links in (7).
The route is
\[
L,(r_t,c_t,d_t,s_t)_{t=1}^{\mu},
J\xrightarrow{B}h,
(r_t,c_t,d_t,s_t)_{t=\mu+1}^{p},
o\xrightarrow{A}E,R,                                     \tag{8}
\]
where \(A,B\) are the stipulated disjoint spanning core
paths. Reversing the abstract four-slot word and both core
paths proves the right-only case; no graph automorphism of
the core is assumed. Reinsert the reserved boundary segments
in reverse order. This completes the four-slot transfer.

Apply it with \((o,h,J,E)=(o_1,h_1,j_3,e_3)\),
\(A=A_q,B=B_q\) from (5), and \(P=P_q\) from (6).
The old-cycle edges \(o_1h_1,j_3e_3\) are indeed forbidden
matching edges, and \(o_1e_3\) would close the whole
triple-and-corridor interval. Thus every actual outer-flank
matching has the promised spanning route. Substituting that
route for the ordinary free-path segment in Note 324 gives
the marked parent cycle; Note 001 transfers it to the legal
child. Reflection proves the final assertion. \(\square\)

**Complete three-double \(J_1/J_3\) consequence.** Suppose instead
that an ordinary target-free free group has exactly three doubly
vacant complete blocks, every other block is short, and each double
block carries an internal free chord of type \(J_1\) or \(J_3\).
The internal corridors and outer short flanks are arbitrary. Then
every such Barnette opening has a spanning \(L\)--\(R\) route.
For the two pure orders, [Note 334](334-every-all-j1-double-vacancy-group-reduces-to-squares.md)
reduces canonical chains to short squares and the ordinary route
lifts. For the two alternating orders, Notes 337 and 340 give the
square route for zero or positive allowed-corridor length, while
Note 341 excludes a positive corridor in the other position.
Note 342 excludes \(J_1,J_1,J_3\) and \(J_1,J_3,J_3\)
at all corridor lengths. The present theorem handles
\(J_3,J_1,J_1\) and its reflection \(J_3,J_3,J_1\).
These are all eight orientation words. Therefore the marked-parent
and legal-child Hamilton conclusion also holds if this specified
group is replaced by any of these eight words, provided all other
vacancies lie in distinct internal blocks. This classification
concerns the \(J_1/J_3\) chord subset, not other internal types.

This settles every outer-flank matching of the realizable
\(J_3,J_1,J_1\) and reflected \(J_3,J_3,J_1\) triple
orders with arbitrary positive required corridor. The
assumptions remain a compressed, gapless, tight-target
all-square opening and an ordinary target-free group with
exactly these three double blocks and no singly vacant block.
Other internal chord types, target defects, positive gaps,
nonsquare residual cycles, and the general Barnette conjecture
are outside the theorem. The proof is project-internal and
does not claim external priority or independent review.
A targeted literature check on 2026-09-30 found Tobias
Schnieders, [arXiv:2508.03531](https://arxiv.org/abs/2508.03531),
whose Theorem 5.2 treats graphs with every face of size at most eight
by graph substitutions and a computational case distinction. The
present marked-route hypothesis and conclusion differ; no exhaustive
novelty comparison is claimed.
