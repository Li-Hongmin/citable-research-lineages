> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The direct target is an ordered Hamilton path, and fixed-\(y\) Helly fails

[Note 063](063-rca-and-the-direct-two-path-target-have-distinct-exact-dual-forms.md)
expresses the planar direct two-path target as a common base of two partition
matroids and two contracted-dual graphic matroids. This note gives an exact
primal interpretation of the first three bases and determines two boundaries
of the proposed fundamental-exchange route. Neither boundary is an abstract
matroid example: both occur in the plane cubic bipartite brace of
[Note 062](062-the-planar-boundary-chord-lemma-fails-on-a-sixteen-vertex-brace.md).

The universal direct target remains open.

## Three common bases are an order-unresolved Hamilton path

Use the notation of Note 063. Let \(F\) have bipartition \(X\sqcup Y\),
let \(r\in Y\), write \(N_F(r)=\{a,b,s\}\), and put \(T=F^*\). The edges
of the root triangle are

\[
d_a=(ra)^*,\qquad d_b=(rb)^*,\qquad (rs)^*.
\]

Fix \(y\in Y\setminus\{r\}\). Let \(E_0\) be the dual ground set with the
three root-triangle edges forbidden, and suppose

\[
H\in
\mathcal B(\mathcal P_X)\cap
\mathcal B(\mathcal P_{Y,y})\cap
\mathcal B(M(T/d_a)).
\tag{1}
\]

Continue to label a dual edge by its primal edge, and let \(K_H\subseteq
E(F)\) be the primal labels in \(H\). Since \(H+d_a\) is a spanning tree
of \(T\), plane tree--cotree duality says that

\[
R_a=E(F)\setminus(K_H\cup\{ra\})
\tag{2}
\]

is a spanning tree of \(F\). The partition loads give degree one at
\(a,y\) and degree two at every other vertex. Hence \(R_a\) is an
\(a\)--\(y\) Hamilton path. At \(r\), it has exactly one of the two orders

\[
a\leadsto b-r-s\leadsto y,
\qquad
a\leadsto s-r-b\leadsto y.
\tag{3}
\]

Conversely, the dual complement of either Hamilton path in (3) recovers
(1). Thus (1) is exactly an order-unresolved rooted Hamilton path, not
merely a necessary relaxation.

The fourth base selects the first order. Indeed,

\[
H\in\mathcal B(M(T/d_b))
\quad\Longleftrightarrow\quad
E(F)\setminus(K_H\cup\{rb\})
\text{ is a spanning tree}.
\tag{4}
\]

Starting from \(R_a\), the graph in (4) is obtained by deleting \(rb\) and
adding \(ra\). This reconnects the two resulting path pieces exactly in
the first order of (3); in the second order it creates a cycle on the
\(a\leadsto r\) side and leaves the \(b\leadsto y\) side disconnected.
Consequently the universal direct target is equivalently the following
ordered Hamilton-path statement:

> For every rooted simple plane cubic bipartite brace \((F,r,s)\), and either
> naming \(\{a,b\}=N_F(r)\setminus\{s\}\), there are
> \(y\in Y\setminus\{r\}\) and an \(a\)--\(y\) Hamilton path that passes
> through \(r\) in the order \(b-r-s\).

## The exact fundamental-cycle bit

Put \(B=H+d_a\), a dual spanning tree, and define

\[
\varepsilon_B=\mathbf 1\{d_a\in C_B(d_b)\},
\tag{5}
\]

where \(C_B(g)\) is the fundamental cycle of a non-tree edge \(g\). The
fourth graphic-base condition is exactly \(\varepsilon_B=1\).

For a tree pivot

\[
B'=B-e+f,\qquad e\in H,\quad f\notin B,\quad e\in C_B(f),
\tag{6}
\]

the binary graphic-matroid update gives

\[
\boxed{
\varepsilon_{B'}=\varepsilon_B\oplus
\mathbf 1\{e\in C_B(d_b)\}
\mathbf 1\{d_a\in C_B(f)\}.}
\tag{7}
\]

Thus an ordinary basis exchange flips the missing bit only when the
deleted edge lies on the \(d_b\) fundamental cycle and the inserted edge
has a fundamental cycle through \(d_a\). The exchange axiom supplies
neither crossing condition.

For fixed \(y\), the two partition bases make every nontrivial one-element
exchange impossible. The removed and inserted edges would have to lie in
the same \(X\)-block and the same \(Y\)-block; since \(F\) is simple, they
would be the same primal edge. If \(y\) may change, the only possible form is

\[
xy\longmapsto xy',
\tag{8}
\]

which transports the load-two face along a primal two-edge path. Brace
\(2\)-extendability does not by itself impose the two extra crossings in
(7).

## A genuine fixed-\(y\) pairwise-Helly counterexample

Take the 16-vertex plane brace of Note 062, with

\[
r=0,\qquad s=8,\qquad a=9,\qquad b=10,
\tag{9}
\]

and fix \(y=3\). In the order

\[
\mathcal P_X,\quad \mathcal P_{Y,3},\quad
M(T/d_a),\quad M(T/d_b),
\]

the six pairwise common-base family sizes, for pairs
\(01,02,03,12,13,23\), are

\[
(15,356,356,192,468,5436).
\tag{10}
\]

They are all positive, but the fourfold common-base family is empty. Hence
even for an actual plane cubic bipartite brace,

\[
\text{all six pairwise intersections nonempty}
\centernot\Longrightarrow
\text{fourfold intersection nonempty}
\tag{11}
\]

when the free face is fixed. This is not a counterexample to the direct
target: for the same root split, \(y=1,2,5,6\) each has two four-common
bases, while \(y=3,4,7\) has none. The outer existential choice of \(y\)
is essential.

## A three-step trap in the variable-free-face exchange graph

In the same brace, take free face \(y=2\) and

\[
\begin{split}
H_0=\{&(1,9),(2,8),(2,10),(3,11),\\
       &(4,12),(5,13),(6,15),(7,14)\}.
\end{split}
\tag{12}
\]

It satisfies the first three bases but not the fourth. Its path (2) is

\[
9-3-13-7-15-5-11-1-8-0-10-4-14-6-12-2,
\tag{13}
\]

which exhibits the wrong order \(s-r-b\). In the complete one-element
exchange graph allowing the free face to change, \(H_0\) has only one
three-base neighbour. A shortest route to a four-common base is

\[
\begin{aligned}
H_1&=H_0-(2,10)+(4,10),\\
H_2&=H_1-(4,12)+(6,12),\\
H_3&=H_2-(6,15)+(5,15).
\end{aligned}
\tag{14}
\]

The first three states \(H_0,H_1,H_2\) all have
\(\varepsilon=0\); only \(H_3\) has \(\varepsilon=1\). The complete
fixed instance has 106 load states, 32 three-common bases and 8
four-common bases. Of the 24 bad three-bases, 15 have no good neighbour,
and the distance from \(H_0\) to the good set is exactly three. Therefore
neither a one-step nor a two-step fundamental-exchange repair is forced by
actual plane-brace incidence.

The exact verifier is
[verify_direct_two_path_ordered_exchange_boundary.py](../computations/verify_direct_two_path_ordered_exchange_boundary.py).
It checks the spherical rotation, cubic bipartition, strict-Hall brace
criterion, tree--cotree conditions, all fixed-\(y\) pairwise intersections,
and the complete three-base exchange graph.

## Boundary

The ordered-Hamilton-path equivalence and (7) are proof-level. Equations
(10)--(14) are exact finite counterexamples to two proof interfaces, not to
the universal target. A positive proof must choose the free face globally
and either select a good three-common base at the outset or control a
genuinely multistep free-face transport. It remains unknown whether every
actual plane-brace three-base exchange component meets the four-base set,
or whether some \((F,r,s)\) has no good free face at all.
