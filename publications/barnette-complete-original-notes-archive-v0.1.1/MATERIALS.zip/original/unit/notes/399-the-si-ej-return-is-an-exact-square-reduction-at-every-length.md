> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(si,eJ\) return is an exact square reduction at every length

[Note 396](396-two-short-flanks-reduce-outside-one-boundary-branch.md)
leaves \(si\) among the possible mates of the right short slot
under \(tp,qo,hz\). [Note 397](397-a-right-short-return-core-has-the-exact-square-signature.md)
excludes the \(si,eJ\) subbranch when the corridor has only one
short block. At longer lengths this subbranch has a forced
cutpoint word and an exact four-terminal square reduction.

Use the block order
\[
 S_0=(c,p,q,d),\quad V=(a,o,h,i,e,b),\quad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\quad
 D=(A,O,H,I,K,J,E,B),\quad T=(C,r,s,F),\qquad m\ge1
\tag{1}
\]
and the selected opening hypotheses of Note 396. Let \(M\)
be its complementary matching. All cross-block free matching
chords lie opposite the selected common face and do not
interlace. A proper complete-block interval closed under
\(M\) would give a forbidden two-edge cut.

For \(1\le r<m\), define
\[
\begin{split}
 Q_{m,r}=\{&si,eJ,Er,p_1K,q_rI,p_{r+1}H,q_mO\}\\
 &{}\cup\{q_jp_{j+1}:1\le j<m,\ j\ne r\}.
\end{split}                                                   \tag{2}
\]
The subscript \(r\) is a corridor cutpoint; the unsubscripted
\(r\) in \(Er\) is the vertex of the right short block.

**\(si,eJ\) return theorem.** Suppose \(tp,qo,hz,si,eJ\in M\)
under (1). Then \(m\ge2\), and the matching inside
\(V,S_1,\ldots,S_m,D,T\) is exactly \(Q_{m,r}\) for
one unique \(1\le r<m\). This induced disk four-pole has
terminals \((a,o,h,F)\) and precisely the square's four
spanning one-path and two spanning two-path Hamilton states.
Replacing it by the labeled square, or reversing that
replacement, preserves Barnette membership and every
exterior- and attachment-marked Hamilton decision. Thus
every actual matching in this subbranch contains a strict
exact square reduction.

**The forced word.** The chord \(si\) encloses the remaining
slots \(e,(p_j,q_j)_{j=1}^m,O,H,I,K,J,E,r\).
Once \(eJ\) occurs, the only possible mate of \(r\)
is \(E\): an opposite-side return into \(eJ\) would
cross it; \(rs\) is an old-cycle edge, and \(s\) is
already used. Thus \(Er\in M\). The chords \(OE,IE,HJ\)
are unavailable. If \(OK\) occurred, it would lie on
the common-face side by the isolation lemma of
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md).
The even slot \(H\) would have to meet some \(p_j\)
on the opposite side. Its chord \(p_jH\) encloses
\(q_j,p_{j+1},q_{j+1},\ldots,p_m,q_m,O\), an even
number of free slots with exactly one face-side exit,
\(OK\). This contradicts matching parity. Hence \(D\)
has no internal free matching chord.

Inside \(eJ\), the four free slots \(O,H,I,K\)
must meet short-block slots. Write their mates as
\[
 Kp_u,\qquad Iq_r,\qquad Hp_s,\qquad Oq_t.              \tag{3}
\]
Noninterlacement forces \(u\le r<s\le t\).
If \(u>1\), the complete prefix
\(S_1,\ldots,S_{u-1}\) is matching-closed, so \(u=1\).
If \(t<m\), the complete suffix
\(S_{t+1},\ldots,S_m\) is matching-closed, so \(t=m\).
If \(r<s-1\), the complete intervening run
\(S_{r+1},\ldots,S_{s-1}\) is matching-closed, so
\(s=r+1\). Between these cutpoints the remaining
short slots must pair as successive ordinary links:
skipping an adjacent link would match-close the
complete short-block run thereby skipped. This gives
exactly (2). In particular \(1\le r<m\), so no such
word exists for \(m=1\), and \(q_rI\) determines \(r\).

**Six states.** For \(m>2\), the ordinary-link ladders
\(S_1\cup\cdots\cup S_r\) and
\(S_{r+1}\cup\cdots\cup S_m\) have four distinct
attachments each. By
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md),
each can be replaced by one square without changing
any exterior or attachment-marked Hamilton decision
or Barnette membership. Their respective attachment
edges are
\[
 (bc_1,p_1K,q_rI,d_rc_{r+1}),\qquad
 (d_rc_{r+1},p_{r+1}H,q_mO,d_mA).
\]
The resulting core is
\(m=2,r=1\), with matching
\(si,eJ,p_1K,q_1I,p_2H,q_2O,Er\).
Its four spanning one-path states are
\[
\begin{array}{c|l}
aF&
 a,o,h,i,e,b,c_1,p_1,q_1,d_1,c_2,p_2,q_2,d_2,
 A,O,H,I,K,J,E,B,C,r,s,F\\
oh&
 o,a,b,e,J,K,p_1,c_1,d_1,q_1,I,H,p_2,c_2,d_2,q_2,
 O,A,B,E,r,C,F,s,i,h\\
ao&
 a,b,e,J,K,p_1,c_1,d_1,q_1,I,H,p_2,c_2,d_2,q_2,
 O,A,B,E,r,C,F,s,i,h,o\\
hF&
 h,o,a,b,c_1,p_1,K,I,q_1,d_1,c_2,p_2,H,O,
 q_2,d_2,A,B,E,J,e,i,s,r,C,F .
\end{array}                                                   \tag{4}
\]
The two spanning two-path states are
\[
\begin{array}{c|l}
\{ao,hF\}&
 (a,o),\quad
 (h,i,s,r,E,J,e,b,c_1,p_1,K,I,q_1,d_1,c_2,p_2,
 H,O,q_2,d_2,A,B,C,F)\\
\{aF,oh\}&
 (o,h),\quad
 (a,b,e,i,s,r,E,J,K,p_1,c_1,d_1,q_1,I,H,p_2,
 c_2,d_2,q_2,O,A,B,C,F).
\end{array}                                                   \tag{5}
\]
Every consecutive pair is an old-cycle edge, a
block-closing face chord, or an edge in (2). Each
row visits every one of the 26 core vertices once.
The terminal colours are \(a,h\) versus \(o,F\),
so no other one-path terminal pair is possible.
The unused two-path pairing \(\{ah,oF\}\) interlaces
the disk order \((a,o,h,F)\), so it is impossible.
Thus (4)--(5) give precisely the square's six
states, which Note 178 lifts through both ladders.

**Barnette-class comparison.** Cap the 26-vertex core
with a fresh square \((x_a,x_o,x_h,x_F)\), attaching
its respective corners to \(a,o,h,F\). A Hamilton
cycle follows the complete old-cycle path through
the core and then \(x_F,x_h,x_o,x_a,a\).
The complementary matching has the disjoint
common-face chords
\[
              ab,c_1d_1,c_2d_2,AB,CF,x_ax_F
\]
and the nested or disjoint opposite-page chords
\[
              si,eJ,p_1K,q_1I,p_2H,q_2O,Er,ox_o,hx_h.
\tag{6}
\]
All chords join opposite Hamilton-cycle parities.
Hence the 30-vertex cap is simple, cubic, bipartite
and plane. Its matching-chord interlacement graph
has the connected spanning tree
\[
\begin{gathered}
 x_ax_F-ox_o-ab-si-CF,\\
 ab-eJ-AB-p_1K-c_1d_1-q_1I,\\
 AB-p_2H-c_2d_2-q_2O,\qquad AB-Er,\qquad ab-hx_h.
\end{gathered}                                                  \tag{7}
\]
Each dash denotes alternating endpoints along the
displayed Hamilton order. A two-edge cut would bound
a proper old-cycle interval closed under the matching,
disconnecting this interlacement graph. The Hamilton
cycle excludes bridges, so the cap is three-edge-
connected and therefore three-vertex-connected.

Deleting any one core vertex leaves the pole connected.
Each of its five block cycles remains connected after
one deletion. The \(S_1\)--\(D\) joins \(p_1K,q_1I\),
the \(S_2\)--\(D\) joins \(d_2A,p_2H,q_2O\), and the
\(D\)--\(T\) joins \(BC,Er\) survive with at least
one edge each, since each set has distinct endpoints.
The \(V\)--\(S_1,D,T\) joins \(bc_1,eJ,is\) have
distinct endpoints as well, so at least two survive.
After deletion of any two core vertices, each remaining
component must meet a surviving terminal; otherwise
the same deletions would disconnect the three-connected
cap. The square has these same one- and two-deletion
properties. The four-attachment comparison of
[Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md)
therefore gives three-connectivity in both replacement
directions. The same terminal colours and disk order
preserve bipartiteness and planarity, while the six
states preserve all exterior edges and used attachments.
Finally, Note 178 reversibly restores both ladders.
The pole has \(18+4m>4\) vertices, so the reduction
is strict. \(\square\)

**Boundary of the remaining \(si\) return.** Under
\(tp,qo,hz,si\), the even slot \(e\) can meet only
\(p_j,O,I,J,r\). For \(j>1\), \(ep_j\) match-closes
\(S_1,\ldots,S_{j-1}\); \(eO\) match-closes all
\(S_1,\ldots,S_m\); and \(er\) match-closes
\(S_1,\ldots,S_m,D\). All three possibilities
contradict three-connectivity. If \(eI\) occurs,
the odd slot \(J\) can only meet \(H\): every
cross-block return to a slot inside \(eI\) would
interlace it, while its other same-block neighbours
are old-cycle edges. This \(HJ\) edge lies on the
common-face side, and the isolation lemma excludes
\(OK\). The chord \(eI\) encloses the \(2m+2\)
slots \((p_j,q_j)_{j=1}^m,O,H\). Exactly one of
these, \(H\), exits through \(HJ\), so parity
forces another face-side exit. It can only be
\(OE\). Then all complete short blocks
\(S_1,\ldots,S_m\) are matching-closed inside
\(eI\), another forbidden two-edge cut. Thus
\(eI\) is impossible at every length.

Only \(ep_1\) and \(eJ\) remain. The latter is
reduced by the theorem above. In the \(ep_1\)
case, \(J\) can meet only \(H\) or a \(q_u\).
If \(HJ\) occurs, it must lie on the common-face
side: on the opposite side it would trap \(K\),
and \(OK\) cannot coexist with \(HJ\) by the
isolation lemma. The chord \(IE\) cannot occur
either. It would have to lie opposite the face
to avoid crossing \(HJ\), then trap \(K\) with
no available mate. Hence \(I\) must meet some
\(q_u\). Its opposite-side chord \(q_uI\)
encloses \(2(m-u)+2\) free slots, namely
\((p_j,q_j)_{j=u+1}^m,O,H\). Among them \(H\)
exits through face-side \(HJ\); if \(OE\) were
absent, no second face-side exit would exist,
contradicting parity. Therefore \(OE,HJ\in M\),
and \(D\) is the rainbow square reduction of
[Note 325](325-even-rainbow-multivacancy-blocks-are-exact-square-reductions.md).
Consequently every \(si\) matching not already
reduced here must have
\[
                         ep_1,q_uJ\in M
           \quad\text{for some }1\le u\le m.              \tag{8}
\]
This is a necessary boundary, not a classification
of the words in (8).

The proof is analytic and project-internal; no
external priority claim or independent review is
asserted. The remaining \(si\) words (8), other
right returns, other openings, and Barnette's
conjecture remain outside this theorem.
