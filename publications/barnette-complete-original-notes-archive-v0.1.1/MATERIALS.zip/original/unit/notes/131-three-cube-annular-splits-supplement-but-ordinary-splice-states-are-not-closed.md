> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Three-cube annular splits supplement, but ordinary splice states are not closed

[Note 108](108-kill-cover-supplementation-is-exactly-a-rooted-split-bond-lemma.md)
reduces one-step \(H^{+-}\) preservation to the rooted split-bond lemma.
[Note 130](130-a-legal-wide-plane-brace-refutes-single-cycle-productivity.md)
shows that one productive parent cycle, and even two rooted parent
witnesses, are not forced by a single sterile endpoint.  That example does
not satisfy the global kill-cover antecedent.

This note tests the actual rooted split-bond statement on the complete
three-cube annular family and identifies the precise failure of the
corresponding unmarked transfer state.

1. Every kill-cover decoration in the fixed order-\(24\) three-cube family
   is supplemented in the child.
2. Connector states, alternating path pairings, complement pairings and
   ordered root marks are not closed under a later \(C_4\) split.  Even
   decorating every parent perfect-matching row by a two-site deletion
   signature and retaining the complete Boolean bond graph is insufficient:
   cross cells require near-perfect boundary rows, and bond transport
   requires a pairwise marked deletion profile.

The first result is a complete finite classification.  The second is a
general port-quotient non-sufficiency theorem.  Neither proves the rooted
split-bond lemma for arbitrary braces.

## 1. Fixed three-cube family

Start with three cubes and perform two standard plane four-port annular
splices.  The cube automorphism group is transitive on the \(48\) oriented
facial squares, so the first splice may be fixed.  The second splice then
has exactly

\[
 3\cdot2\cdot6\cdot2\cdot4=288
\tag{1}
\]

embedded choices: a surviving middle-cube square, an opposite-edge pair,
a third-cube square, an opposite-edge pair, and a cyclic noncrossing port
shift.  Exact graph isomorphism reduces these choices to four parent types,
each represented \(72\) times.

For each parent, retain every cofacial bipartite \(C_4\)-expansion site and
every interface-disjoint legal-wide root, forced-gate, and surviving-gate
decoration.  Exact parent automorphisms reduce the resulting \(4094\)
labelled decorations to \(437\) orbits.  For every orbit, enumerate the
complete parent and child rooted fibres and their cross-sector single-cycle
graphs

\[
 \Gamma(\mathcal L),\qquad \Gamma(\mathcal L^+).
\tag{2}
\]

The four parent types and the kill-cover counts are:

\[
\begin{array}{c|c|c|c|c}
\text{face spectrum}&\#\mathrm{PM}&|\operatorname{Aut}|&
\text{legal-wide orbits}&\text{kill-cover orbits}\\ \hline
4^{10}8^4&226&8&95&16\\
4^8 6^4 8^2&202&4&70&9\\
4^{10}6^2 10^2&244&4&223&28\\
4^{12}12^2&324&48&49&9.
\end{array}
\tag{3}
\]

Every one of the \(437\) parent crossing graphs is nonempty.  In exactly
\(62\) orbits, corresponding to \(690\) labelled decorations, the
state-\(11\) slice \(\mathcal L_{11}\) is a vertex cover of
\(\Gamma(\mathcal L)\).  These are precisely the rooted split-bond
antecedents in this family.

## 2. Complete supplementation in the fixed family

All \(62\) kill-cover children satisfy

\[
 \Gamma(\mathcal L^+)\ne\varnothing.
\tag{4}
\]

Their crossing-edge counts have the exact orbit distribution

\[
\begin{array}{c|rrrrrrrrrrrr}
\#E(\Gamma(\mathcal L^+))
 &4&6&8&10&11&12&13&14&16&18&21&30\\ \hline
\#\text{orbits}
 &5&23&3&2&2&7&2&1&4&10&2&1.
\end{array}
\tag{5}
\]

In particular, every child has at least four crossings.  Under the
kill-cover antecedent, the canonical--canonical child crossing graph is
empty by Note 103.  The classification independently verifies this at
every hit, and every crossing counted in (5) is incident with one of

\[
 R_{00},\qquad X_{uy},\qquad X_{vx}.
\tag{6}
\]

Thus the fixed three-cube annular family contains no rooted split-bond
counterexample.

The explicit \(G/P\) counterexample of Note 130 lies in the third parent
type of (3), but it is outside this antecedent.  Its parent rooted fibre has
sector sizes \((14,3)\) and six crossings; its state-\(11\) slice has size
two and is not a vertex cover.  Hence Note 130 closes a local productivity
mechanism without providing evidence against (4).

## 3. What the ordinary annular state decides

For a perfect matching \(N\), record its connector state \(s(N)\), the
terminal path pairing and closed components of \(M\triangle N\), and the
terminal path pairing, closed components, and ordered root marks of the
complement.  Gluing the two factor partitions along the annular connectors
is a finite union--find operation.

If the fixed root and forced-gate matching bits are included, this state
decides whether \(N\) is root-admissible: the glued complement quotient
must have the required two components and the ordered roots must lie in
different components.  It also decides whether \(M\triangle N\) is one
unlabelled alternating cycle.

It does not decide cross-sector adjacency until one adds the surviving-gate
change bit

\[
 \gamma_g(M,N)=\mathbf 1_{\{g\in M\triangle N\}}.
\tag{7}
\]

Even after adding (7), the state is not closed under a subsequent split.

## 4. A strict equal-state nonclosure pair

Fix a future state-\(11\) site \(p=uv,q=xy\), and cut the relevant
difference and complement components at these two incidences.  The four
labelled ends \(u,v,x,y\) inherit a pairing and root/gate fragment marks.
None of this information is determined by the outer annular ports.

Take two finite port quotients with identical outer data:

\[
 s(M)=\varnothing,\qquad s(Q)=A_0,
\tag{8}
\]

no closed component of \(M\triangle Q\), the same complement pairings and
ordered root marks, the same fibre labels, the same \(\gamma_g=1\), and the
same parent bond graph consisting of one gate-changing edge incident with
a state-\(11\) row.  The kill-cover antecedent therefore holds in both.

Let a fixed new-cell patch row pair the four site ends according to
\(\pi_J=\alpha\).  Change only the unrecorded exterior site-cut pairing:

\[
 \pi_F=\alpha\quad\text{in }\mathcal P^+,\qquad
 \pi_F=\beta\ne\alpha\quad\text{in }\mathcal P^-.
\tag{9}
\]

In \(\mathcal P^+\), gluing the exterior and patch pairings produces two
cycles, with one ordered root fragment on each; the new-cell row is
root-admissible.  In \(\mathcal P^-\), the same patch row produces one
cycle and the roots coalesce; the row is not root-admissible.  Adding the
same second child row to both quotients therefore gives a new-cell bond in
\(\mathcal P^+\) and no such bond in \(\mathcal P^-\).

All recorded annular data and the parent kill-cover truth value are
identical, while child supplementation differs.  This is a strict
port-quotient proof that the ordinary root-marked annular state is not
future-split closed.  It is not asserted to be realized by an actual brace.

## 5. Perfect-matching row atoms are still insufficient

The first missing local datum is the marked two-site deletion signature

\[
\delta_{p,q}(M,N)=
\bigl(
\Pi_{p,q}^{\triangle},\Pi_{p,q}^{c};
\lambda_{r_0},\lambda_{r_1},\lambda_g;
\text{residual closed components}
\bigr).
\tag{10}
\]

Here \(\Pi_{p,q}^{\triangle}\) and \(\Pi_{p,q}^{c}\) are the partitions of
the four site ends after cutting \(p,q\); the \(\lambda\)'s assign the two
ordered roots and surviving gate to the resulting paths or closed
components.  The unmarked pairing alone is insufficient because the two
roots may occupy the same or different components.

However, adjoining (10) to every parent perfect-matching row still does not
generate the complete child fibre.  Removing the patch edges from the two
cross rows gives near-perfect exterior matchings with holes

\[
\mathcal R_{\varnothing},\qquad
\mathcal R_{uy},\qquad
\mathcal R_{vx},
\tag{11}
\]

where \(\mathcal R_{\varnothing}\) is the ordinary no-hole class and the
other two classes leave precisely the displayed old endpoints unmatched.
The \(X_{uy}\) and \(X_{vx}\) rows do not contract to parent perfect
matchings; they are obtained by adjoining respectively
\(\{ua,bc,dy\}\) and \(\{ad,bv,xc\}\) to the two-hole classes.

This failure already occurs in the first actual three-cube decoration.
For the \(4^{10}8^4\) parent, take

~~~text
root 0-4, forced 2-6, surviving 10-14,
site p=5-7, q=1-3.
~~~

The parent has \(226\) perfect matchings.  Their restrictions outside
\(p,q\) have only the four canonical defect sets

\[
\varnothing,\quad\{5,7\},\quad\{1,3\},\quad\{1,3,5,7\},
\]

with multiplicities \(97,20,41,68\).  These rows reconstruct exactly

\[
C_{00}:97,\ C_{10}:20,\ C_{01}:41,\ C_{11}:68,\ R_{00}:97,
\]

or \(323\) of the \(475\) child perfect matchings.  The missing \(152\)
rows are exactly \(76\) \(X_{uy}\) rows and \(76\) \(X_{vx}\) rows.  The
direct rooted child fibre has \(27\) members, while the PM-only
reconstruction has \(13\); the missing rooted rows are exactly seven of
each cross type.  Their exterior defect sets are
\(\{u,y\}=\{5,1\}\) and \(\{v,x\}=\{7,3\}\).  Thus the missing boundary
support is an actual plane-brace phenomenon, not only a formal possibility.

There is also a strict equal-state quotient pair.  Keep the complete parent
perfect-matching rows, all their \(\delta_{p,q}\) data, the parent Boolean
bond graph, and the kill-cover truth value identical.  Let one quotient
admit a root-marked \(\{u,y\}\)-hole row and the other admit none.  The
first quotient obtains a root-admissible \(X_{uy}\) row and a new-cell
child bond; the second has no such row, while all canonical child bonds are
already killed.  Supplementation differs although every perfect-matching
row atom is identical.  Therefore the boundary-row support in (11), with
its connector, complement, root, gate, and fibre data, is indispensable.

There is a second, pairwise obstruction.  A Boolean parent bond bit says
that \(r\triangle s\) is one gate-changing cycle, but does not record how
that cycle is cut by \(p,q\).  The two possible four-end pairings can glue
to one or two child difference cycles under the same pair of patch rows.
Thus each ordered row pair needs a bond-deletion atom

\[
\varepsilon_{p,q}(r,s)=
\bigl(
\Pi_{\rm ann}^{\triangle},z_{\rm ann}^{\triangle};
\Pi_{p,q}^{\triangle},z_{p,q}^{\triangle};
\lambda_g;\text{endpoint row types}
\bigr).
\tag{12}
\]

The old Boolean bond relation is a predicate derived from (12), not
sufficient transition data.

For one fixed current site and a deterministically relabelled next patch
site, the resulting formal quotient calculus is finite and deterministic
only after it propagates the coupled atom

\[
\boxed{
(\text{boundary row in (11)},\delta_{p,q};
 \text{pairwise bond atom }\varepsilon_{p,q}).}
\tag{13}
\]

Annular gluing joins row complement partitions and pairwise difference
partitions along their respective connector sets.  A patch row then joins
the corresponding row atom, while a pair of patch rows joins the pairwise
atom.  Component counts and root/gate marks decide admission and bond
status, after which deterministic relabelling cuts the next named site.
All terminal partitions have bounded size, and component counts may be
saturated at \(0,1,2,\ge3\), so the formal atom set is finite.

This is a closure statement for the augmented quotient language, not a
proof that its reachable actual-brace supports satisfy supplementation.
The next valid word theorem must use (13); the smaller state consisting of
perfect-matching rows, (10), and Boolean bond incidence is already refuted.

The complete fixed-family classification is reproduced by the
[three-cube rooted split-bond bundle](../computations/bundles/three-cube-rooted-split-bond-classification/README.md).
Its scope is only the four order-\(24\) parent types in (3).
