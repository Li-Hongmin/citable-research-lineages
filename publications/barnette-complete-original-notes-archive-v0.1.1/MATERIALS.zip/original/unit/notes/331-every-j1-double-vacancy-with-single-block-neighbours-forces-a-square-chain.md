> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every J1 double vacancy with single-block neighbours forces a square chain

[Note 330](330-staggered-vacancy-chains-have-the-square-hamilton-signature.md)
shows that a double vacancy carrying \(J_1=OK\) has a singly
vacant immediate predecessor, and that its other free slot \(I\)
must meet the \(h\)-slot of a singly vacant block. An \(I\)-edge
to the left forces a square-equivalent staggered chain. The
remaining right-oriented case is excluded here without a bound
on the number or positions of singly vacant and short blocks.

Use the same compressed, gapless, tight-target all-square opening
of a Barnette parent. Fix a target-free free group with ordinary
even left and odd right endports. Its complete blocks comprise
exactly one doubly vacant block
\(D=(A,O,H,I,K,J,E,B)\), with \(OK=J_1\) in the
complementary matching, and otherwise any number of target-free
short or singly vacant blocks. No assumption is made about
other free groups.

**Complete J1-chain theorem.** Some \(q\ge1\) consecutive
singly vacant blocks immediately before \(D\), together
with \(D\), induce exactly the four-terminal patch \(P_q\)
of Note 330. In particular, the matching edge at \(I\)
always reaches a singly vacant block to the *left* of \(D\);
the right-oriented possibility cannot occur. The patch can
be replaced by a square in either direction, preserving
Barnette membership and every exterior-marked Hamilton
decision. If every vacancy outside the patch lies in a
distinct internal block, the parent has a Hamilton cycle
through both site edges and its legal site-expanded child
is Hamiltonian. Reflection gives the corresponding \(J_3\)
theorem, with the block order reversed.

**Proof.** We use [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md)'s
side-placement rule and the parity and cut rules of Notes
327--330. Every cross-block free matching chord lies on the side
opposite the designated common face; the only possible
internal free chord of a singly vacant block
\((a,o,h,i,e,b)\) is \(oe\), and it lies on the common-face
side. For any opposite-side chord, the number of free
slots strictly between its endpoints is even after removing
endpoints of common-face chords that leave that interval.
A proper consecutive interval of complete blocks closed
under the complementary matching gives a forbidden
two-edge cut.

Note 330 supplies the immediate predecessor
\(V_L=(a_L,o_L,h_L,i_L,e_L,b_L)\) of \(D\), with
\(o_Le_L,i_LH,OK\) fixed. It also shows that \(I\)
matches \(h\) of a singly vacant block with its \(oe\)
chord present. If that block is left of \(D\), Note 330's
forced left-chain theorem gives \(P_q\), and its exact
reduction and marked-opening consequence prove all the
claims. Suppose instead that \(Ih_R\) joins a singly
vacant block \(V_R=(a_R,o_R,h_R,i_R,e_R,b_R)\) after
\(D\). Then \(o_Re_R\) is also fixed. At least one
complete block lies between \(D\) and \(V_R\): otherwise
\(Ih_R\) traps \(J,E\), which cannot match across its
boundary and whose mutual edge is on the old cycle.

Let \([L,R]\) be the complete block interval from \(V_L\)
through \(V_R\). Every free slot in this interval except
\(h_L,i_R\) is matched inside it. Indeed,
\(o_L,e_L,i_L,H,O,K,I,h_R,o_R,e_R\) have the displayed
internal mates. Every remaining slot between \(I\) and
\(h_R\) must match inside the opposite-side chord \(Ih_R\),
apart from \(K,o_R\), whose common-face mates \(O,e_R\)
are still in \([L,R]\). Call any consecutive complete
block interval with this property a **two-port interval**:
its first block is singly vacant with an \(oe\) chord,
its only unmatched free slots are that first block's
\(h\)-slot and its last block's \(i\)-slot, and the
last block is singly vacant with an \(oe\) chord. The
interval \([L,R]\) is one.

Consider a two-port interval \([L,R]\), writing its
unmatched slots as \(h_L,i_R\). Matching them to each
other would close the entire proper interval under the
matching and give a two-edge cut. We locate every other
possible mate of \(h_L\). Its old-cycle neighbours and
the other free slots inside \([L,R]\) are used or
unavailable. The ordinary even left endport has the wrong
colour. An odd ordinary slot of a short block before \(L\)
gives a chord enclosing that block's final even slot,
complete blocks, and \(o_L\); the interior has even size
and just the one face-side exit through \(o_Le_L\). An
odd ordinary short-block slot after \(R\), or the right
odd endport, gives a chord enclosing \(i_L,e_L\) and
complete blocks, again with even interior and precisely
the one exit through \(o_Le_L\). If the proposed mate
is the first slot \(o_W\) of a singly vacant block
outside \([L,R]\), the count before \(L\) gains the
pair \(h_W,i_W\), while the count after \(R\) is
unchanged. Its own \(o_We_W\) cannot occur because
\(o_W\) is used, so parity fails in either case. Thus
\(h_L\) can only meet an \(i_W\)-slot of a singly vacant
block strictly before \(L\) or strictly after \(R\).

Suppose first that \(W\) is before \(L\). The chord
\(i_Wh_L\) encloses \(e_W\), complete intervening
blocks, and \(o_L\). Its even interior has the one
face-side exit \(o_Le_L\); parity therefore forces
\(o_We_W\) as the second exit. Any complete blocks
strictly between \(W\) and \(L\) would have all their
free slots paired among themselves: an opposite-side
edge cannot cross \(i_Wh_L\), while \(e_W,o_L\)
already have their face-side mates outside that chord.
That is a forbidden two-edge cut. Hence \(W\) immediately
precedes \(L\). The enlarged interval \([W,R]\) is
again a two-port interval, now with unmatched slots
\(h_W,i_R\).

Suppose instead that \(W\) is after \(R\). The chord
\(h_Li_W\) encloses \(i_L,e_L\), complete blocks,
and \(o_W,h_W\). Its even interior has one exit through
\(o_Le_L\), so parity forces \(o_We_W\). The slot
\(i_R\) lies inside \(h_Li_W\); its mate must also lie
inside that chord, since cross-block chords are all on
the opposite side. Starting at \(V_R\), apply the same
interval parity used in Note 330's forced left-chain
proof, now moving right. A proposed mate at a later
short block's final even slot encloses \(e_R\), complete
blocks, and that block's first odd slot, with the single
face-side exit through \(o_Re_R\), so it is impossible.
The final even slot of a later singly vacant block fails
identically because its own \(oe\) would be unavailable.
A mate at a later singly vacant block's \(h\)-slot forces
that block's \(oe\) chord as the second exit. Any complete
blocks skipped by such a mate would be matching-closed,
again a two-edge cut. Therefore the immediately next
block is singly vacant, with its \(oe\) chord and the
matching edge from the current \(i\)-slot to its \(h\)-slot.
Repeat this forced step until \(W\), whose \(i_W\) is
already matched to \(h_L\). Every block from \(L\)
through \(W\) is now matched internally, including the
two old ports \(h_L,i_R\). This proper complete block
interval gives a two-edge cut. Thus \(h_L\) cannot
match to a later singly vacant block either.

We have proved that the left port of any two-port interval
can only match the \(i\)-slot of the immediately preceding
singly vacant block, extending the interval one block to
the left. Repeating this operation must stop because the
free group has finitely many blocks. At the leftmost
interval no mate remains for its left port, a contradiction.
The assumption \(Ih_R\) was false. Thus \(I\) matches
left, and Note 330 supplies the induced \(P_q\), its
square reduction, and the marked Hamilton conclusion.
\(\square\)

For each \(q\), Note 330's explicit \(6q+20\)-vertex
Barnette parent realizes the forced chain, so the theorem
does not exclude \(J_1\) itself. It classifies this one
multiply vacant block amid arbitrary singly vacant and
short blocks of an ordinary target-free group. It does not
cover another multiply vacant block in the same group,
target-bearing terminal vacancies, positive gaps, defective
target order, nonsquare residual cycles, or the general
Barnette conjecture. The result is project-internal and
has not had independent external review or a priority check.
