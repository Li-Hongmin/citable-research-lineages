> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Short-wrapper parity and terminal-spine paths

The first submaximal chorded single-hexagon kernel of [Note 416](416-a-chorded-seven-face-chord-failure-has-one-seven-leaf-root.md) has seven marked leaves, six binary branches, and $c=31$ ordinary chords. Compared with the maximal word of [Note 419](419-depth-parity-forces-three-odd-leaves-in-the-maximal-seven-face-chord-kernel.md), exactly one node has one fewer ordinary wrapper. This note derives its parity spectrum, proves Hamiltonicity when two eligible leaves leave a $3+2$ split of the other five, and gives a face-chord-free route for a family of non-sibling site leaves. The path transfer uses [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md).

## The short-wrapper parity spectrum

Let $T$ be the ordered full binary tree with seven leaves. Its root has depth zero, leaf $i$ has depth $d_i$, and $v$ is the unique short node at depth $h$. A full leaf has word $U_i=((x_i y_i))$, and a full branch has word $F(P,Q)=(((P Q)))$. At $v$, delete one outer ordinary wrapper: a short leaf has one pair of parentheses and a short branch has two. Write $V(v)$ for the leaves below $v$. The full old-cycle order is
\[
 w_0,z_L,t_c,W,t_b,z_R,w_*,\alpha,a,b,c,d,\beta,
\]
as in Note 416, with $W$ beginning at index $3$ when $w_0$ has index $0$.

**Parity-spectrum theorem.** Put
\[
 \varepsilon_i=1+d_i+\mathbf1_{i\in V(v)}\pmod2.
 \tag{1}
\]
Then the index of $x_i$ has parity $\varepsilon_i$. A leaf can be a site leaf only when $\varepsilon_i=0$. In particular, the two site-leaf depths have opposite parity exactly when $V(v)$ contains one of them. If $s$ is the number of leaves with $\varepsilon_i=0$, a legal word with two site leaves satisfies
\[
 s\in\begin{cases}\{4,7\},&h\text{ even},\\
                  \{2,5\},&h\text{ odd}.
     \end{cases}                                      \tag{2}
\]
In particular, when $s=2$, the two eligible leaves are exactly the site leaves. The two exterior face chords are then forced to be $z_Lx_j$ and $y_kz_R$, where the site edges are $w_0y_j,x_kw_*$. The five other leaves occupy the three face-matching compartments in sizes $(5,0,0)$ or $(3,2,0)$, up to permutation. Consequently $k-j\in\{1,3,4,6\}$. The $(3,2,0)$ distribution has exactly one formal noncrossing face matching on those five leaves; the $(5,0,0)$ distribution has exactly six. These counts impose no three-connectivity condition.

**Proof.** Every complete subtree has even word length, so preceding sibling words do not affect the parity of $x_i$. In the maximal word, the initial index $3$, the three opening parentheses at each ancestor, and the two opening parentheses at a leaf give
\[
 \operatorname{index}(x_i)\equiv3+3d_i+2\equiv1+d_i\pmod2.
\]
Deleting one wrapper removes one opening parenthesis on the route to $i$ exactly when $i\in V(v)$; deletion of its closing parenthesis and any preceding whole word changes indices by an even number. This proves (1). The site edges require $y_j$ odd and $x_k$ even, because $w_0$ is even-indexed and $w_*$ odd-indexed. Since $x_j,y_j$ are adjacent, both site leaves have $\varepsilon=0$.

Let $b$ be the number of odd-depth leaves of $T$. Replacing one leaf at depth $d$ by a branch and its two children changes $\sum_i(-1)^{d_i}$ by $-3(-1)^d$. Thus this sum is $1\pmod3$ for every full binary tree. With seven leaves it equals $7-2b$, so $b\equiv0\pmod3$. If $E_v,O_v$ count the even- and odd-depth leaves below $v$, applying the same identity relative to the root of that subtree gives
\[
 E_v-O_v=\sum_{i\in V(v)}(-1)^{d_i}\equiv(-1)^h\pmod3.
\]
The eligible leaves are the odd-depth leaves outside $v$ and the even-depth leaves inside $v$, whence
\[
 s=b-O_v+E_v\equiv(-1)^h\pmod3.
\]
Since $2\le s\le7$, (2) follows.

The rank-parity argument of Note 419 applies unchanged to each face-matching compartment: every face chord between leaves joins an $x$ to a $y$, and bipartiteness requires both leaves to have the same $\varepsilon$. The exterior terminal $z_L$ can meet only an eligible $x$, and $z_R$ can meet only an eligible $y$. If $s=2$, no eligible leaf other than the two site leaves is available, forcing $z_Lx_j,y_kz_R$. Each of the five ineligible leaves contributes both special positions to one compartment. A compartment containing exactly one such leaf would have to pair its adjacent $x_i,y_i$, duplicating an old-cycle edge. Thus none of the three compartment sizes is one. Their sum is five, so their unordered sizes are $(5,0,0)$ or $(3,2,0)$. The middle compartment has $k-j-1$ leaves, proving the asserted gap list.

For a compartment of $m$ such leaves, all $2m$ terminals are consecutive and must be noncrossingly matched, with each old-cycle pair $x_i y_i$ forbidden. Let $C_m$ be the $m$th Catalan number. Inclusion-exclusion on those $m$ disjoint adjacent forbidden pairs gives the exact formal count
\[
 N_m=\sum_{a=0}^m(-1)^a\binom ma C_{m-a}.             \tag{3}
\]
Indeed, forcing any $a$ of the adjacent pairs leaves $2(m-a)$ terminals with an arbitrary noncrossing matching. Thus $N_2=N_3=1$ and $N_5=6$, proving the two distribution counts. For three leaves $a<b<c$, the unique matching is $x_ay_c,y_ax_b,y_bx_c$; for two leaves $d<e$, it is $x_dy_e,y_dx_e$. \(\square\)

The spectrum and matching counts are necessary combinatorial conditions, not an assertion that every listed possibility is realized by a legal Barnette graph.

**Forced-matching Hamilton theorem.** Suppose $s=2$ and the five ineligible leaves have distribution $(3,2,0)$ among the three compartments. Then every legal child in this $c=31$ chorded single-hexagon branch is Hamiltonian. Consequently a non-Hamiltonian child with $s=2$ could only have the $(5,0,0)$ distribution, whose five-leaf compartment has six formal face matchings. Up to reflection its site-leaf pair is then $(j,k)=(1,2)$ or $(1,7)$.

**Proof.** The short node has odd depth by (2). Were it a site leaf, (1) would give $\varepsilon_v=1+h+1\equiv1\pmod2$, contradicting site eligibility. If a short leaf belongs to a sibling-leaf pair, its full sibling has the same depth but the opposite value of $\varepsilon$. Since the only eligible leaves are the two sites, such a pair must consist of the short leaf and a site leaf.

Every ordered full binary tree with at least two leaves has a sibling-leaf pair. Suppose one consists of two ineligible leaves. Both leaves are full: a short leaf could not have an ineligible sibling by the preceding paragraph. The pair lies within one of the ineligible compartments, since the only boundaries between compartments are site leaves. In the two-leaf compartment the forced matching pairs all four special terminals inside the sibling pair, leaving only its two extreme old-cycle edges to the rest of the cubic graph. This contradicts three-connectivity. In the three-leaf compartment, the forced matching $x_ay_c,y_ax_b,y_bx_c$ joins either possible adjacent sibling pair by a chord $y_ax_b$ or $y_bx_c$, with its other two special terminals attached outside the pair. The full six-vertex leaves therefore form the serial odd pole of Note 412; reducing it gives a legal $f=6$ child, Hamiltonian by Note 414, and the Hamilton cycle lifts back. Thus a non-Hamiltonian child has no two-ineligible sibling pair.

The two site leaves cannot themselves be siblings in a non-Hamiltonian child by Note 424. Hence some sibling pair contains exactly one site and one ineligible leaf. Their values of $\varepsilon$ differ despite their equal depth. Equation (1) then forces $v$ to be one of those two leaves; as shown above it cannot be the site leaf. Therefore $v$ is the ineligible sibling leaf. Since $v$ is the only flipped leaf and is odd-depth, $s=b-1$ in the notation above. Thus $b=3$, and this sibling pair has odd depth.

A full binary tree with exactly one sibling-leaf pair is a comb: if an internal node had two internal children, their two subtrees would each contain a sibling-leaf pair. The unique pair in a seven-leaf comb has depth six, which is even. Our tree has an odd-depth sibling pair, so it has a second sibling-leaf pair, disjoint from the first. That second pair cannot contain a site leaf: the two sites are not siblings by Note 424, while a site and an ineligible full leaf have different $\varepsilon$ values despite the same depth; the sole short leaf $v$ already lies in the first pair. Therefore the second pair consists of two ineligible leaves, contradicting the two-compartment analysis above. This rules out the assumed non-Hamiltonian child.

For the remaining $(5,0,0)$ distribution, the five-leaf group is wholly before $j$, wholly between $j,k$, or wholly after $k$. These give $(j,k)=(6,7),(1,7),(1,2)$ respectively, and reflection identifies the first with the last. \(\square\)

## Terminal-spine path transfer

The next lemma concerns ordinary words of arbitrary size. A branch $F_r(P,Q)$ has $r\ge1$ nested ordinary bracket pairs around its child words, with left brackets $\lambda_0,\ldots,\lambda_{r-1}$ and right brackets $\rho_{r-1},\ldots,\rho_0$ in old-cycle order. A site leaf has either the full six-vertex word $((x_i y_i))$ or the short four-vertex word $(x_i y_i)$. Off-spine sibling words may have arbitrary nested ordinary chords; only their consecutive old-cycle interval is used. For a word $A$, write $\overrightarrow A,\overleftarrow A$ for its forward and reverse spanning old-cycle paths.

Call a spanning one-site path's **exit** left or right according to whether it ends at the first or last vertex of its word. The leaf paths are
\[
\begin{array}{c|c|c}
 &\text{one-site path}&\text{exit}\\\hline
y\text{-site }((xy))&(y,x,h,j,R,L)&L\\
x\text{-site }((xy))&(x,y,j,h,L,R)&R\\
y\text{-site }(xy)&(y,x,L,R)&R\\
x\text{-site }(xy)&(x,y,R,L)&L.
\end{array}                                                    \tag{4}
\]
Here $L,h,x,y,j,R$ or $L,x,y,R$ is the leaf's old-cycle order. Every path in (4) contains the leaf's outer ordinary chord.

At a branch $F_r(A,S)$, a path exiting the right child $S$ on its **left** can be extended through the whole parent. At a branch $F_r(S,B)$, a path exiting the left child $S$ on its **right** can likewise be extended. In either case the new exit flips sides when $r$ is odd and retains its side when $r$ is even. These are the *terminal-spine transfer rules*.

**Terminal-spine theorem.** Let the least common ancestor of the $y_j$- and $x_k$-site leaves be $F_r(P,Q)$, with $y_j$ in $P$ and $x_k$ in $Q$. Ascend from each site leaf using the exit given in (4). At each intermediate branch require that the site-bearing child is on the side specified by the transfer rule above, and update the exit using the parity of that branch's number of wrapper pairs. If the resulting $y_j$ path exits $P$ on its left and the $x_k$ path exits $Q$ on its right, the entire root word has a spanning $y_j$--$x_k$ path using only old-cycle edges and ordinary chords. No condition is imposed on the wrapper counts at the least common ancestor or above it. The site leaves may be non-siblings or short.

For Note 416's $c=31$ normal form, every legal candidate satisfying this condition has a parent Hamilton cycle containing both site edges: close the constructed word path by the fixed outside route of Note 424, equation (6). Its child is Hamiltonian by Note 001. Thus any non-Hamiltonian $c=31$ candidate must fail the terminal-spine condition as well as Note 424's sibling-site condition.

**Proof.** Starting at the innermost left bracket $\lambda_{r-1}$, traverse its chord to $\rho_{r-1}$, then the old-cycle edge to $\rho_{r-2}$, then that bracket's chord to $\lambda_{r-2}$, and continue alternately toward the outer brackets. Call the resulting bracket-only path $T_r^L$. Its mirror $T_r^R$ starts at $\rho_{r-1}$. Both visit all $2r$ bracket vertices once, and their last edge is the outer chord $\lambda_0\rho_0$. Their endpoints are
\[
\begin{array}{c|cc}
 &r\text{ odd}&r\text{ even}\\\hline
T_r^L&\rho_0&\lambda_0\\
T_r^R&\lambda_0&\rho_0.
\end{array}                                                     \tag{5}
\]
For example, $T_2^L=(\lambda_1,\rho_1,\rho_0,\lambda_0)$ and $T_3^L=(\lambda_2,\rho_2,\rho_1,\lambda_1,\lambda_0,\rho_0)$; all consecutive pairs are old-cycle edges or ordinary chords.

If the current path ends at $S_\ell$ in $F_r(A,S)$, append
\[
 A_r\xrightarrow{\overleftarrow A}A_\ell,\quad T_r^L.           \tag{6}
\]
The joins $S_\ell A_r$ and $A_\ell\lambda_{r-1}$ are old-cycle edges. Formula (6) adds every vertex of $A$ and all parent brackets exactly once. By (5), its new exit is right for odd $r$ and left for even $r$. Similarly, if the current path ends at $S_r$ in $F_r(S,B)$, append
\[
 B_\ell\xrightarrow{\overrightarrow B}B_r,\quad T_r^R.         \tag{7}
\]
This exits left for odd $r$ and right for even $r$. Both extensions retain the site's endpoint and end with the new outer chord.

Apply (6) or (7) up each specified site spine. Write the least common ancestor as $F_r(P,Q)$. The two spanning one-site paths have endpoints $P_\ell$ and $Q_r$, so join them by
\[
 P_\ell,\lambda_{r-1},\ldots,\lambda_0,
 \rho_0,\ldots,\rho_{r-1},Q_r.                              \tag{8}
\]
This spans the ancestor and contains its outer chord. At each higher ancestor, replace that outer chord by the appropriate left- or right-child insertion of Note 424, equation (4). The insertion adds the other child and all ancestor brackets exactly once, with no face-side chord. The resulting root path has endpoints $y_j,x_k$, as claimed. \(\square\)

In the full six-leaf word
\[
 F\bigl(F(F(U_1,U_2),U_3),\ F(U_4,F(U_5,U_6))\bigr),
\]
the $y_2$ spine goes right then left and the $x_5$ spine goes left then right. Two odd-wrapper transfers on each side give the required exits; the site leaves are not siblings. Short site leaves are also possible in the theorem: for example, a short $y$-site leaf starts with a right exit and can acquire a left exit through one full branch in which it is the left child. These are word-level instances; no Barnette-class completion is asserted for unspecified face matchings.

Neither theorem decides the remaining $c=31$ words outside its hypotheses, the chord-free single-hexagon branch, or Barnette's conjecture.
