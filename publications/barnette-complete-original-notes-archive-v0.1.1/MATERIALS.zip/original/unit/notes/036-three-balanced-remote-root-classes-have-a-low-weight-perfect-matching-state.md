> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Three balanced remote root classes have a low-weight perfect-matching state

[Note 035](035-one-two-and-three-vertex-regions-do-not-obstruct-single-layer-fec-support.md)
shows that one remote two-edge root class is either exact-one in every
perfect matching or has zero- and two-edge states.  Treating three such
classes separately leaves the abstract obstruction
\(\{110,101,011\}\).  This note proves that the actual plane incidence
excludes that obstruction.

Use the setting of Notes 028--035.  Thus \(F\) is a plane cubic bipartite
brace, \(p=uv\) and \(h=za\) are an ordered legal cofacial site, and

\[
 K=F-\{u,a\}.
\]

In \(\Delta=F^*\), write

\[
 p^*=cc_p,\qquad h^*=cc_h,
\]

where \(c\) is the common-face vertex.  Let \(s_1,s_2,s_3\) be distinct
remote common neighbours of \(c_p,c_h\): each is adjacent to
\(c_p,c_h\), but not to \(c\).  Let \(D_i\) be the two retained primal
labels dual to

\[
 c_ps_i,\qquad c_hs_i.
\]

Assume that each \(D_i\) is balanced, so every perfect matching of \(K\)
uses zero or two members of \(D_i\), and both possibilities occur.

> **Three-cut zero-state Helly theorem.** There is a perfect matching
> \(M\) of \(K\) such that
> \[
>  \sum_{i=1}^3\frac{|M\cap D_i|}{2}\le1.
> \tag{1}
> \]

In particular, if the three remote vertices are pairwise nonadjacent,
then for \(W=\{r,s_1,s_2,s_3\}\) their six root labels satisfy

\[
 |M\cap E_Q(W)|\le2<|W|-1.
\tag{2}
\]

## The balanced remote bonds have nested shores

Put

\[
 P_c=c_p-c-c_h,
 \qquad
 P_i=c_p-s_i-c_h.
\]

The edge \(c_pc_h\) is absent.  Otherwise \(cc_pc_h\) would be a
triangle in the simple 4-connected triangulation \(\Delta\), hence a
facial triangle, forcing the disjoint primal edges \(p,h\) to share an
endpoint.  Consequently \(P_c\cup P_i\) is a simple dual four-cycle.
Plane cycle--bond duality gives the primal four-bond

\[
 B_i=\{p,h\}\mathbin{\dot\cup}D_i.
\tag{3}
\]

Every shore \(R\) of a four-edge cut in a cubic graph has even order,
because

\[
 3|R|=2|E_F(R)|+4.
\tag{4}
\]

If \(u,a\) lay on opposite shores of \(B_i\), deleting them would leave
an odd shore of the two-edge cut \(D_i\) in \(K\).  Perfect-matching cut
parity would then force every perfect matching to use exactly one member
of \(D_i\), contrary to the balanced hypothesis.  Thus \(u,a\) lie on
the same shore of every \(B_i\).

This choice is compatible across the three cycles.  The ordered legal
facial order is

\[
 u,v,\ldots,z,a,\ldots,u,
\]

so the dual faces \(u,a\) lie beside one boundary copy of the embedded
path \(P_c\), while \(v,z\) lie beside the other.  Cut the sphere open
along a thin neighbourhood of \(P_c\).  The paths \(P_i\) become
pairwise noncrossing crosscuts of a disc and therefore have a linear
order.  The regions between the fixed \(u,a\)-boundary copy and these
ordered crosscuts are nested.  After reindexing, the corresponding primal
shores satisfy

\[
 R_1\subsetneq R_2\subsetneq R_3,
 \qquad
 \delta_F(R_i)=\{p,h\}\mathbin{\dot\cup}D_i.
\tag{5}
\]

Since \(u,a\in R_i\), deleting them gives

\[
 T_i=R_i\setminus\{u,a\},
 \qquad
 T_1\subsetneq T_2\subsetneq T_3,
 \qquad
 \delta_K(T_i)=D_i.
\tag{6}
\]

In particular, both edges of \(D_1\) lie wholly on the \(T_2\)-side of
\(K-D_2\), and both edges of \(D_3\) lie wholly on the other side.

## Matching splicing excludes the abstract blocker

For a perfect matching \(N\) of \(K\), define

\[
 \sigma_i(N)=\frac{|N\cap D_i|}{2}\in\{0,1\}.
\]

Suppose that every attained state has Hamming weight at least two.  A
zero-state witness for \(D_1\) must then have state \(011\), and a
zero-state witness for \(D_3\) must have state \(110\).  Call these
matchings \(N^-\) and \(N^+\), respectively.  Both use the two edges of
the middle cut \(D_2\).

Take the matching of the \(T_2\)-side from \(N^-\), the matching of the
opposite side from \(N^+\), and retain both common cut edges in \(D_2\).
Every vertex away from the cut keeps its old matching edge, and the four
cut endpoints are matched by the two edges of \(D_2\).  Hence the splice
is a perfect matching.  By (6), it inherits state zero on \(D_1\) from
\(N^-\), state one on \(D_2\), and state zero on \(D_3\) from \(N^+\).
Its state is therefore \(010\), contradicting the assumed lower bound.
This proves (1).

## Consequence and boundary

The theorem supplies exactly the joint information absent from the
one-class analysis: balanced remote classes inherited from one common
\(c_p,c_h\) annulus occur in series, and the perfect-matching projection
is closed under an inside--outside splice at the middle cut.  Ordinary
edge avoidability, cut parity for each class separately, and abstract
1-extendability do not imply this closure.

No global \(H^{+-}\) hypothesis or order bound is used.  Adjacency among
the \(s_i\) is irrelevant to (1), but any retained labels between them
must be added when applying the result to the full region
\(E_Q(\{r,s_1,s_2,s_3\})\).  Thus this note closes the first
three-balanced-remote profile; it does not claim the complete rooted
four-vertex region theorem or rule out a single-region obstruction of a
different four-vertex incidence type.
