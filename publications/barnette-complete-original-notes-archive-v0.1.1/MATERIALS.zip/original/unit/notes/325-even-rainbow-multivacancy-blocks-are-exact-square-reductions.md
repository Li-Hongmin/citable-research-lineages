> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Even rainbow multivacancy blocks are exact square reductions

[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
proves that an induced even-column ladder with four corner
attachments has exactly the spanning Hamilton linkage signature
of a square. A target-free face block with an even number of
vacancies becomes such a ladder when its internal matching
follows a complete nested rainbow. The reduction removes every
vacancy of that block without changing the selected opening
outside it.

Let \(G\) be a Barnette parent with the compressed, gapless,
tight-target all-square opening of Note 324. Fix a target-free
internal face block \(B\) with \(q=2m\ge2\) vacant eligible
positions and old-cycle order
\[
 a,o,h_1,i_1,h_2,i_2,\ldots,h_q,i_q,e,b.
 \tag{1}
\]
The face chord is \(ab\). Assume the complementary matching
contains exactly these \(q\) edges with both ends among the free
slots of \(B\):
\[
 oe,\qquad
 h_ti_{q+1-t}\ (1\le t\le m),\qquad
 i_th_{q+1-t}\ (1\le t<m).
 \tag{2}
\]
The only free slots of \(B\) not matched inside it are
\(i_m,h_{m+1}\); each has one matching edge to the exterior.
For \(q=2\), (2) is \(oe,h_1i_2\), the local pattern of Note 224.

**Rainbow-block reduction.** The induced subgraph \(G[V(B)]\)
is \(L_{q+2}=P_{q+2}\square K_2\), with exactly four
exterior edges at \(a,b,i_m,h_{m+1}\). Replacing it by a square
with the same four labeled attachments yields another Barnette
graph \(G'\). Hamilton cycles of \(G\) and \(G'\) transfer in
both directions with the same exterior edges and the same used
attachments. The replacement also preserves the compressed
all-square, gapless, tight-target opening and turns \(B\) into
one short target-free face block.

**Proof.** The two ladder rails, written from left to right,
are the old-cycle paths
\[
 a,o,h_1,i_1,\ldots,h_m,i_m
 \quad\text{and}\quad
 b,e,i_q,h_q,\ldots,i_{m+1},h_{m+1}.
 \tag{3}
\]
Their paired columns are
\[
 (a,b),(o,e),
 (h_1,i_q),(i_1,h_q),\ldots,
 (h_m,i_{m+1}),(i_m,h_{m+1}).
 \tag{4}
\]
The first rung \(ab\) is the face chord. Every intermediate
rung is one of the matching edges (2). The last rung
\(i_mh_{m+1}\) is an old-cycle edge. Thus (3)--(4) list
precisely the edges of \(L_{q+2}\); \(q+2\) is even.
Every nonterminal ladder vertex has all three edges inside
\(B\). The terminals \(a,b\) have their old-cycle edges
outside \(B\), while \(i_m,h_{m+1}\) have their complementary
matching edges outside. These are the four distinct
attachments.

Apply Note 178's exact even-ladder replacement with terminal
labels \((a,b,i_m,h_{m+1})\). It preserves Barnette
membership and every exterior Hamilton decision. Choose the
replacement square's old-cycle path as
\(a',i_m',h_{m+1}',b'\), with closing face chord \(a'b'\).
The original old cycle traverses all of \(B\) from \(a\)
to \(b\), so this local substitution keeps it Hamiltonian.
The two old-cycle boundary edges, the two external matching
edges, and the site edges keep their labels and cyclic order.
No target occurs in \(B\), and every other face block and
residual square is untouched. Hence gaplessness, tight target
order, the all-square opening, and cofacial site placement
survive. The new square has no eligible vacancy. \(\square\)

**Marked Hamilton theorem with rainbow blocks.** Suppose every
multiply vacant internal face block of the selected opening is
target-free and satisfies (1)--(2) with even \(q\). All other
vacant positions may lie in arbitrary distinct internal face
blocks, including target-bearing blocks, with at most one
vacancy per such block. Then \(G\) has a Hamilton cycle
containing both site edges \(xy,uv\), and its legal
site-expanded child is Hamiltonian. There is no bound on the
number or sizes of the rainbow blocks.

**Proof.** Compress the rainbow blocks one at a time by the
reduction above. They are vertex-disjoint, and each
replacement preserves the hypotheses for every other
rainbow block. The process ends after finitely many strict
vertex reductions. The resulting Barnette opening has
vacancies only in distinct internal blocks, so Note 324
supplies a Hamilton cycle through \(xy,uv\). Reverse the
exact four-terminal replacements, preserving both site
edges. Notes 001 and 178 give the legal child and the
original lobe lengths. \(\square\)

The profile is nonvacuous at every even \(q\): start from
Note 224's \(q=2\) Barnette example and replace its
four-terminal \(L_4\) block by \(L_{q+2}\) using Note 178.
The perimeter is the new old-cycle block, and the rungs
give exactly (2). This produces a Barnette parent and
legal child with the indicated rainbow block without
graph enumeration.

The recognition (1)--(4) and its combination with Note 324
are project-internal analytic results. The even-ladder
signature and replacement themselves are already proved
in Note 178; no new graph operation or external priority
is claimed. Blocks with odd multiplicity or another
internal matching pattern, site-block vacancies, positive
gaps, defective target order, nonsquare residual cycles,
and general Barnette graphs remain outside this theorem.
