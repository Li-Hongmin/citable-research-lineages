> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The h1R branch closes the arbitrary central-corridor four-double group

[Note 351](351-a-delayed-central-corridor-return-has-a-forced-hamilton-route.md)
leaves two branches of an alternating four-double free group with an
arbitrary central short-block corridor. [Note 352](352-the-long-central-corridor-h1j4-branch-has-exactly-two-q-hamilton-matchings.md)
settles the \(h_1j_4\) branch. The remaining \(h_1R\) branch has
one cut position, including a final local-square state.

Use the compressed, gapless, tight-target all-square opening of
[Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Let an ordinary target-free free group, with even left endport \(L\)
and odd right endport \(R\), consist exactly of
\[
D_1,D_2,S_1,\ldots,S_q,D_3,D_4,\qquad q\ge1,                \tag{1}
\]
with no outer short flank. As in [Note 350](350-an-arbitrary-central-corridor-gives-a-square-equivalent-four-double-core.md),
\[
D_t=(a_t,o_t,h_t,i_t,k_t,j_t,e_t,b_t),\qquad
S_u=(c_u,r_u,s_u,d_u),                                      \tag{2}
\]
in old-cycle order. The common-face internal matching chords are
\[
                 i_1e_1,\quad o_2k_2,\quad i_3e_3,\quad o_4k_4 .
                                                                  \tag{3}
\]
All cross-block free chords lie on the opposite page by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
and [Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
excludes additional same-block free chords.

Put
\[
 B=\{Lo_1,h_1R,k_1i_2,j_1h_2,j_2e_4,k_3i_4,j_3h_4\}.       \tag{4}
\]
For \(0\le p\le q\), define
\[
\begin{split}
C_{q,0}={}&
 \{e_2j_4,r_1h_3,s_qo_3\}
 \cup\{s_ur_{u+1}:1\le u<q\},\\
C_{q,p}={}&
 \{e_2r_1,s_pj_4,r_{p+1}h_3,s_qo_3\}
 \cup\{s_ur_{u+1}:1\le u<q,\ u\ne p\}
       &&(1\le p<q),\\
C_{q,q}={}&
 \{e_2r_1,s_qo_3,h_3j_4\}
 \cup\{s_ur_{u+1}:1\le u<q\}.
\end{split}                                                  \tag{5}
\]
The range in the middle row is empty when \(q=1\).

**Exact \(h_1R\)-branch theorem.** If the complementary
matching of (1)--(3) contains \(h_1R\), then its complete
free-chord set is exactly \(B\cup C_{q,p}\) for one
\(p\in\{0,\ldots,q\}\). These \(q+1\) words are pairwise
distinct, and each occurs in a \((44+4q)\)-vertex
three-connected cubic bipartite plane parent with a
Hamilton cycle through both edges of a legal facial
\(C_4\)-expansion site. Its \((48+4q)\)-vertex legal child
is Hamiltonian. Every actual matching in this branch
has a vertex-spanning \(L\)--\(R\) group route.
The word \(p=q\) has Note 335's local square on \(D_3,D_4\);
the other \(q\) words use a nonlocal return to \(h_3\).

Combining this theorem with Notes 349--352 and the
first-slot consequence of Note 351, **every** actual
ordinary target-free group of form (1)--(3) has a
vertex-spanning \(L\)--\(R\) route, for every \(q\ge1\).
If all vacancies outside this group occupy distinct
internal blocks, its parent has a Hamilton cycle
through both site edges and its legal child is Hamiltonian.

**Exhaustion.** A nonempty proper interval of complete
blocks closed under the complementary matching would
have only its two boundary old-cycle edges leaving it,
contrary to three-connectivity. We use this cut rule
throughout.

Outside \(h_1R\), only \(L,o_1\) are free, so \(Lo_1\)
is forced. Inside \(h_1R\), the even slot \(k_1\) can
meet only \(i_2,j_3,i_4\). The choice \(k_1j_3\)
leaves \(h_4\) without a mate: \(h_4i_4\) is an old
edge, \(h_4j_4\) is forbidden by chord isolation,
and an earlier mate would cross \(k_1j_3\).
The choice \(k_1i_4\) leaves the old pair
\(j_4e_4\) at the right end. Thus \(k_1i_2\)
and its inner pair \(j_1h_2\) are forced.

The odd slot \(j_2\) can now meet only
\(s_1,\ldots,s_q,h_3,e_4\).
If \(j_2h_3\), its interior forces
\(e_2r_1,s_ur_{u+1}\ (1\le u<q),s_qo_3\).
Indeed \(e_2o_3\) would close all the short blocks;
a later first \(e_2r_v\), an earlier
last \(s_vo_3\), or a skipped standard link
would close a nonempty interval of complete
short blocks. The remaining tail forces
\(k_3i_4,j_3h_4\), then leaves the forbidden
old pair \(j_4e_4\).

If \(j_2s_p\), its interior forces
\(e_2r_1\) and \(s_ur_{u+1}\) for
\(1\le u<p\) by the same prefix cut rule.
For \(p=q\), all free slots of \(D_3,D_4\)
must match inside that proper complete-block
interval, giving a two-edge cut. For \(p<q\),
the first remaining odd slot \(r_{p+1}\)
can meet only \(h_3\) or \(e_4\):
its edge to \(s_{p+1}\) is old; one to
a later \(s_v\) closes \(S_{p+1},\ldots,S_v\);
the candidate edges to \(k_3,h_4\) enclose
odd numbers of free slots. The choice
\(r_{p+1}e_4\) closes the complete-block suffix
\(S_{p+1},\ldots,S_q,D_3,D_4\), so
\(r_{p+1}h_3\) is forced. Inside that chord
the suffix cut rule forces \(s_qo_3\) and
all links \(s_ur_{u+1}\) with \(p+1\le u<q\).
The tail again forces \(k_3i_4,j_3h_4\)
and leaves \(j_4e_4\). Thus \(j_2e_4\)
is forced.

Inside \(j_2e_4\), the even slot \(e_2\)
can meet only \(r_1,\ldots,r_q,o_3,j_4\).
An edge \(e_2r_t\) with \(t>1\) closes
\(S_1,\ldots,S_{t-1}\); \(e_2o_3\) closes
all \(q\) short blocks. Hence \(e_2r_1\)
or \(e_2j_4\).

If \(e_2j_4\), the first inner slot \(r_1\)
must meet \(h_3\): \(r_1s_1\) is old,
\(r_1s_v\) for \(v>1\) closes
\(S_1,\ldots,S_v\), and the other
colour-compatible inner candidates
enclose odd numbers of free slots.
The usual suffix argument forces
\(s_qo_3\) and all standard corridor
links. The last four free slots
force \(k_3i_4,j_3h_4\). This is \(C_{q,0}\).

Suppose \(e_2r_1\). Follow the first
unmatched even slot \(s_p\) after any
initial standard links. Its available
mates are \(r_{p+1}\), \(o_3\), or \(j_4\):
a later \(r_v\) would close the intervening
complete short blocks, and candidates
\(j_3,i_4\) enclose odd numbers of free
slots. If \(p<q\), \(s_po_3\) closes
\(S_{p+1},\ldots,S_q\), so \(s_pj_4\).
Inside \(s_pj_4\), the first odd slot
\(r_{p+1}\) must meet \(h_3\):
\(r_{p+1}s_{p+1}\) is old, a later
\(r_{p+1}s_v\) closes
\(S_{p+1},\ldots,S_v\), and
\(r_{p+1}e_4\) would cross \(s_pj_4\).
The suffix links and \(s_qo_3\)
are then forced; the tail forces
\(k_3i_4,j_3h_4\). This is \(C_{q,p}\)
for \(1\le p<q\). If \(p=q\),
\(s_qj_4\) leaves \(o_3\) without a
mate: \(o_3h_3\) is old, \(o_3k_3\)
is forbidden, and \(o_3h_4\) encloses
three free slots. Thus \(s_qo_3\);
the remaining six slots force
\(h_3j_4,k_3i_4,j_3h_4\).
This is \(C_{q,q}\). The classification
is complete. \(\square\)

**Spanning routes.** Put
\(F_u=(r_u,c_u,d_u,s_u)\), a path
through all four vertices of \(S_u\).
For every \(0\le p<q\), the following
sequence is a spanning \(L\)--\(R\) path:
\[
\begin{split}
L,o_1,a_1,b_1,a_2,b_2,e_2,
F_1,\ldots,F_p,\;
j_4,k_4,i_4,k_3,i_3,h_3,\;
F_{p+1},\ldots,F_q,\\
o_3,a_3,b_3,e_3,j_3,h_4,o_4,a_4,b_4,e_4,
j_2,k_2,o_2,h_2,i_2,k_1,j_1,e_1,i_1,h_1,R .
\end{split}                                                   \tag{6}
\]
When \(p=0\), the join \(e_2j_4\) is
in \(C_{q,0}\); otherwise the join from
\(F_p\) to \(j_4\) is \(s_pj_4\).
The join from \(h_3\) to \(F_{p+1}\)
is \(h_3r_{p+1}\). The remaining corridor
joins are exactly the links in (5).
All other consecutive pairs are old edges,
block-closing or internal face chords,
or edges of (4)--(5). The four double
blocks and all \(q\) short blocks appear
exactly once.

For \(p=q\), a spanning route is
\[
\begin{split}
L,o_1,a_1,b_1,a_2,b_2,e_2,
F_1,\ldots,F_q,
o_3,a_3,b_3,e_3,i_3,h_3,
j_4,k_4,i_4,k_3,j_3,h_4,\\
o_4,a_4,b_4,e_4,
j_2,k_2,o_2,h_2,i_2,k_1,j_1,e_1,i_1,h_1,R .
\end{split}                                                   \tag{7}
\]
The three joins \(h_3j_4,i_4k_3,j_3h_4\)
are exactly Note 335's local-square
chords. This row again visits every
vertex once. \(\square\)

**Barnette realizations.** Use the old
Hamilton cycle
\[
x,R_1,w,y,D_1,D_2,S_1,\ldots,S_q,D_3,D_4,
u,z,L_1,v,\alpha,\gamma,\delta,\beta,x.                    \tag{8}
\]
Put \(xy,uv,\alpha\beta\), every block-closing
chord \(a_tb_t,c_ud_u\), and (3) on
the common-face page. Put
\(\delta R_1,wo_1,h_1z,\gamma L_1\),
the five fixed chords of (4) other
than \(Lo_1,h_1R\), and \(C_{q,p}\)
on the opposite page.
Every vertex has exactly one matching
chord of the opposite old-cycle colour,
and no matching chord is an old edge.
The opposite-page intervals are nested
or disjoint: \(j_2e_4\) surrounds the
corridor and right double-block chords.
For \(p=0\), \(e_2j_4\) surrounds
\(r_1h_3\); for \(0<p<q\),
\(s_pj_4\) surrounds \(r_{p+1}h_3\);
for \(p=q\), \(h_3j_4\) surrounds
the local-square chords. The standard
corridor links are nested or disjoint
within these intervals. Thus the
realization is simple, cubic, bipartite
and plane.

Here is a connected spanning certificate
for chord interlacement on (8). Every
dash means that the two chords' endpoints
alternate along the old cycle. The
common spine and fixed branches are
\[
\begin{gathered}
xy-wo_1-a_1b_1-h_1z-uv-\gamma L_1-\alpha\beta-\delta R_1,\\
a_1b_1-k_1i_2-a_2b_2-j_2e_4-a_4b_4-j_3h_4-a_3b_3,\\
a_1b_1-j_1h_2-o_2k_2,\qquad k_1i_2-i_1e_1,\\
a_3b_3-k_3i_4-i_3e_3,\qquad k_3i_4-o_4k_4,\\
a_3b_3-s_qo_3-c_qd_q .
\end{gathered}                                                 \tag{9}
\]
For every standard link in (5), add
\[
             c_ud_u-s_ur_{u+1}-c_{u+1}d_{u+1}.             \tag{10}
\]
For \(p=0\), add
\[
a_2b_2-e_2j_4-a_4b_4,\qquad
c_1d_1-r_1h_3-a_3b_3.                                     \tag{11}
\]
For \(0<p<q\), add
\[
\begin{gathered}
a_2b_2-e_2r_1-c_1d_1,\qquad
c_pd_p-s_pj_4-a_4b_4,\\
c_{p+1}d_{p+1}-r_{p+1}h_3-a_3b_3 .
\end{gathered}                                                 \tag{12}
\]
For \(p=q\), add
\[
a_2b_2-e_2r_1-c_1d_1,\qquad
a_3b_3-h_3j_4-a_4b_4 .                                     \tag{13}
\]
For example,
\(c_p<s_p<d_p<j_4\) and
\(s_p<a_4<j_4<b_4\) verify the
middle branch of (12); the other
alternations follow from (8).
Equations (9)--(13) contain every
matching chord in one connected
interlacement graph. Any two-edge
cut in a cubic Hamiltonian graph
would bound a matching-closed old-cycle
interval and disconnect this graph.
The old cycle excludes bridges.
Thus every realization is
three-edge-connected and, since
it is cubic, three-vertex-connected.

The site edges \(xy,uv\) remain
cofacial, with face arcs of lengths
\(2q+9\) and \(3\). They form a
legal bipartite \(C_4\)-expansion
site; the residual square and tight
targets are those in Note 350.
Replace \(L,R\) in (6) or (7)
by \(w,z\), and call the resulting
\(w\)--\(z\) route \(Q\). The paths
\[
(x,R_1,\delta,\beta,\alpha,\gamma,L_1,v)
\quad\text{and}\quad
(x,y,Q,u,v)                                                \tag{14}
\]
are internally disjoint \(x\)--\(v\) paths
covering (8). Their union
is a Hamilton cycle through \(xy,uv\).
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives a Hamilton cycle in the legal child.
For another actual parent in this branch,
the group route (6) or (7) composes with
the other groups of Note 324 under the
stated outside-vacancy hypothesis.
\(\square\)

The conclusion covers precisely the
no-flank \(J_3,J_1,J_3,J_1\) four-double
word with one arbitrary positive central
short-block corridor in the specified
opening. It does not cover the opposite
orientation word, outer short flanks,
other opening types, or the general
Barnette conjecture. This is a
project-internal analytic proof,
without an external priority claim.
