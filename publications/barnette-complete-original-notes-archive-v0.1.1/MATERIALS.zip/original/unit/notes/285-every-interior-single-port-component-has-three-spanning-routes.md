> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every interior single-port component has three spanning routes

[Note 284](284-one-sided-interior-port-components-have-three-spanning-routes.md)
handles one vacancy on one side of an interior missing-link
port and arbitrarily many on the other. Two rail folds,
one near the first two left vacancies and one near the
last two right vacancies, remove both one-sided bounds.
The result covers an interior port with any positive
number of vacancy atoms on each side.

Use a compressed, gapless, tight-target all-square opening
with \(\ell,r\ge1\). Every vacancy lies in a different
target-free internal face-chord block. In one free group
suppose exactly one ordinary link \(P_s=e_so_{s+1}\)
is missing. Its noncrossing atom component is
\[
 V_{l_1}<\cdots<V_{l_p}<P_s<
 V_{r_1}<\cdots<V_{r_q},
 \qquad p,q\ge1.                                     \tag{1}
\]
Every other atom component is vacancy-only. Assume
the two ordinary links attaching the group's full
target-free internal block interval to its endports
are retained. No shortness condition is imposed on
\(B_s,B_{s+1}\); their vacancies, if any, belong to
closed parts inside the corresponding gaps.

**Interior-port routing theorem.** The group's full
target-free interval \(D=B_a,\ldots,B_b\) has all three
vertex-spanning four-port states
\[
\begin{array}{ll}
X(D):&a_a\longleftrightarrow b_b,\quad
       o_a\longleftrightarrow e_b;\\
K(D):&a_a\longleftrightarrow o_a,\quad
       e_b\longleftrightarrow b_b;\\
S(D):&o_a\longleftrightarrow e_b.
\end{array}                                               \tag{2}
\]
All vacancy-only components may be arbitrarily nested.
If every other free group has an ordinary-endport
spanning route, the parent has a Hamilton cycle through
both site edges and its legal expanded child is
Hamiltonian. Reflection exchanges \(p,q\).

**The prime matching and straight state.** Put
\(u=r_q\). Note 278's rainbow rule gives the edges
\[
\begin{gathered}
H_{l_1}I_u,\qquad
I_{l_t}H_{l_{t+1}}\ (1\le t<p),\qquad
I_{l_p}e_s,\\
o_{s+1}H_{r_1},\qquad
I_{r_t}H_{r_{t+1}}\ (1\le t<q).
\end{gathered}                                             \tag{3}
\]
Old-cycle adjacency implies \(l_p\le s-1\) and
\(r_1\ge s+2\). All gaps between consecutive atoms
of (1) are closed under the matching by noncrossing.
The unique absent ordinary link is \(P_s\), so
ordinary joins at all prime vacancy blocks are
retained. Every nonempty closed gap has the states
of Note 275.

Replace \(P_s\) in Note 196's ordinary free path by
the alternating path from \(e_s\) through the left
vacancies in descending order, then the outer edge
\(H_{l_1}I_u\), then the right vacancies in descending
order, ending at \(o_{s+1}\):
\[
\begin{split}
e_s,I_{l_p},H_{l_p},
 &(I_{l_t},H_{l_t})_{t=p-1,\ldots,1},
 I_u,H_u,\\
 &(I_{r_t},H_{r_t})_{t=q-1,\ldots,1},o_{s+1}.
\end{split}                                               \tag{4}
\]
The parenthesized lists are empty when their side
has one vacancy. Each step is an edge of (3) or an
old-cycle vacancy edge \(H_kI_k\). Use \(S\) in
each nonempty closed gap. This spans the prime block
interval and proves its straight state.

**A left path ending at \(b_s\).** We construct a path
\(\Lambda:a_{l_1}\longleftrightarrow b_s\)
through \(B_{l_1},\ldots,B_s\) that covers every
vertex of these blocks except \(o_{l_1},H_{l_1}\).
If \(p=1\), this is
\[
 a_{l_1},b_{l_1},e_{l_1},I_{l_1},e_s
 \xrightarrow{X_{\rm bottom}(F)^{-1}}o_{l_1+1},
 a_{l_1+1}\xrightarrow{X_{\rm top}(F)}b_s,
 \quad F=B_{l_1+1},\ldots,B_s.                    \tag{5}
\]
The gap \(F\) is nonempty because \(l_1\le s-1\).

Suppose \(p\ge2\). Put \(h=l_2\), \(t=l_p\),
\(G=B_{l_1+1},\ldots,B_{h-1}\), and
\(F=B_{t+1},\ldots,B_s\). The latter is
nonempty. When \(G\) is nonempty, take
\[
\begin{split}
a_{l_1},b_{l_1},a_{l_1+1}
 &\xrightarrow{X_{\rm top}(G)}b_{h-1},a_h,o_h,e_{h-1}
 \xrightarrow{X_{\rm bottom}(G)^{-1}}o_{l_1+1},
 e_{l_1},I_{l_1},H_h\\
 &\xrightarrow{C\text{ forward}}I_t,e_s
 \xrightarrow{X_{\rm bottom}(F)^{-1}}o_{t+1},
 e_t,b_t,a_{t+1}
 \xrightarrow{X_{\rm top}(F)}b_s.
\end{split}                                               \tag{6}
\]
When \(G\) is empty, replace the initial
top-and-bottom traversal between \(b_{l_1}\) and
\(e_{l_1}\) by \(b_{l_1},a_h,o_h,e_{l_1}\);
the rest of (6) is unchanged. The three
exceptional matching edges in (6) are
\(I_{l_1}H_h\), \(I_te_s\), and the retained
ordinary link \(o_{t+1}e_t\). The joins
\(o_{l_1+1}e_{l_1}\) and \(o_he_{h-1}\)
are retained when \(G\) is nonempty.
The \(C\)-arc from \(H_h\) to \(I_t\)
covers every intermediate left vacancy and
block, stopping before \(e_t,b_t\);
the two rails of \(F\) cover its vertices
and then supply \(e_t,b_t\). The two rails of
\(G\), if present, cover that gap. Hence (5)
or (6) has the asserted endpoints and vertex
coverage. It uses neither \(o_{l_1}\) nor
\(H_{l_1}\).

**Cap state.** Put \(R=B_{s+1},\ldots,B_{r_1-1}\),
which is nonempty. Leave \(e_ub_u\) as the right
cap path. Starting with \(\Lambda\), continue
its \(b_s\) end along
\[
\begin{split}
b_s,a_{s+1}
 &\xrightarrow{X_{\rm top}(R)}b_{r_1-1},a_{r_1},
 o_{r_1},e_{r_1-1}
 \xrightarrow{X_{\rm bottom}(R)^{-1}}o_{s+1},H_{r_1}\\
 &\xrightarrow{C\text{ forward}}I_u,H_{l_1},o_{l_1}.
\end{split}                                               \tag{7}
\]
Here \(o_{s+1}H_{r_1},I_uH_{l_1}\) are
edges of (3), and \(o_{r_1}e_{r_1-1}\)
is retained. The old-cycle arc from
\(H_{r_1}\) to \(I_u\) covers every later
right vacancy and intervening block, stopping
before \(e_u,b_u\). Together with \(\Lambda\)
and both rails of \(R\), this is a path
from \(a_{l_1}\) to \(o_{l_1}\) through
all prime-block vertices except \(e_u,b_u\).
The cap edge joins the latter two, proving \(K\).

**Crossed state.** Its bottom path is
\[
 o_{l_1},H_{l_1},I_u,e_u.                           \tag{8}
\]
If \(q=1\), the top path follows \(\Lambda\)
and then
\[
 b_s,a_{s+1}
 \xrightarrow{X_{\rm top}(R)}b_{u-1},e_{u-1}
 \xrightarrow{X_{\rm bottom}(R)^{-1}}o_{s+1},
 H_u,o_u,a_u,b_u.                                    \tag{9}
\]
This is the right-hand end of Note 283's
crossed route and covers \(R\) on both rails.

If \(q\ge2\), put \(v=r_{q-1}\). From \(b_s\),
take the old-cycle arc forward to \(I_v\),
then the matching edge \(I_vH_u\), and
then \(H_u,o_u,e_{u-1}\):
\[
 b_s\xrightarrow{C\text{ forward}}I_v,H_u,o_u,e_{u-1}.
                                                            \tag{10}
\]
This covers all blocks from \(B_{s+1}\) through
\(B_v\) up to \(I_v\), leaving \(e_v,b_v\).
If \(u=v+1\), finish with \(b_v,a_u,b_u\).
Otherwise let \(T=B_{v+1},\ldots,B_{u-1}\),
which is closed and has \(X(T)\), and finish by
\[
\begin{split}
e_{u-1}&\xrightarrow{X_{\rm bottom}(T)^{-1}}o_{v+1},
 e_v,b_v,a_{v+1}\\
 &\xrightarrow{X_{\rm top}(T)}b_{u-1},a_u,b_u.
\end{split}                                               \tag{11}
\]
All joins outside these gap routes are edges
of (3), retained ordinary links, old-cycle
edges, or face chords. The left path
\(\Lambda\) uses every vertex through \(B_s\)
except \(o_{l_1},H_{l_1}\), which lie on
(8). The right construction uses every
later vertex except \(I_u,e_u\), also on
(8). The two paths are disjoint, spanning,
and have the \(X\) endpoints.

**Surrounding parts and realization.** Every other atom
part is vacancy-only. It lies within one of the closed
gaps above, in a serial flank, or around the prime part.
A surrounding part's first and last vacant blocks are
strictly before \(B_{l_1}\) and after \(B_u\), so this
prime patch lies in one proper block gap. Note 275's
prime recursion uses that gap only through \(S,K,X\);
its old-cycle arcs remain present across \(P_s\).
Join serial flanks across retained ordinary links as
in Notes 280--281. This proves (2) for \(D\);
Notes 196, 273, 001, and 178 give the marked parent
cycle, legal child, and original lobe lengths.

The hypotheses occur for every \(p,q\ge1\). Put
\(\ell=1\), \(s=p+2\), \(r=p+q+3\), make
\(B_1,\ldots,B_p\) and
\(B_{s+2},\ldots,B_r\) vacant, and make
\(B_{p+1},B_s,B_{s+1}\) short. Use the
site blocks and residual square of Note 281(8).
Take all standard free links except \(P_s\),
and replace it with the edges
\[
\begin{gathered}
H_1I_r,\qquad I_jH_{j+1}\ (1\le j<p),
 \qquad I_pe_s,\qquad o_{s+1}H_{s+2},\\
I_jH_{j+1}\ (s+2\le j<r).
\end{gathered}                                             \tag{12}
\]
These edges and the retained links form a perfect
matching of the free slots. They pair opposite
old-cycle colours and draw as nested or disjoint
chords in the disk opposite the common face;
\(H_1I_r\) encloses the other special chords.
The site and face chords occupy the other side,
so the graph is planar with cofacial site edges.

The matching-chord interlacement graph is connected.
Retained standard links connect successive face
chords except across \(P_s\). The outer
\(H_1I_r\) joins the face chords of \(B_1,B_r\);
the two port-incident edges meet the face chords
on their respective sides of the missing link;
each remaining vacancy edge meets its endpoint
face chords. The site/residual-square closing chain
of Note 217 is unchanged. Thus the graph has no
two-edge cut, and Note 182's cubic lemma gives
three-vertex-connectivity. It is a Barnette parent
on \(6(p+q)+24\) vertices. The theorem gives a
marked Hamilton parent cycle and a legal Hamiltonian
child on \(6(p+q)+28\) vertices. In particular,
\(p=q=2\) realizes the first two-sided case.

This theorem resolves every interior single-port
component in the stated tight, gapless, all-square
setting, regardless of its vacancy count. End-port
components whose outward block is itself vacant,
multiple missing links in one group, target-bearing
vacancies, positive gaps, defective target order,
and nonsquare residual cycles remain outside its
scope. It does not settle Barnette's conjecture.
