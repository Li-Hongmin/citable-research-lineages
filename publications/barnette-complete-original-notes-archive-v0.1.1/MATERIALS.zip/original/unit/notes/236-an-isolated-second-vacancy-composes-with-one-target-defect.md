> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An isolated second vacancy composes with one target defect

[Note 235](235-every-tight-gapless-two-vacancy-square-opening-is-hamiltonian.md)
settles the tight, gapless second-surplus boundary. At the
same free-vertex count, Note 197 permits target-order defects.
The one-defect routes of Notes 211--212 and the one-vacancy
detours of Notes 208--209 remain compatible when they occur
in different free-matching groups.

Use a compressed all-square Barnette opening with
\(\ell,r\ge1\), no interblock gaps, and exactly two vacant
eligible even positions, so \(f=4r+6\). The main blocks
are \(B_0=[x,y]_C\), \(B_1,\ldots,B_r\), and
\(B_{r+1}=[u,v]_C\), as in Note 197. Define
\(d_L,b,d_R\) there.

**Separated-defect theorem.** Suppose
\(d_L+b+d_R=1\), and one of the following holds.

1. \(d_L=1\). The first target \(R_\ell\) is in a
   block \(B_h\), and exactly one vacant eligible
   position precedes it. The other vacancy lies in
   an internal face block \(B_k\) with \(k>h\).
2. \(d_R=1\). The last target \(L_1\) is in a
   block \(B_h\) at an eligible position
   before its final interior slot. It accounts
   for one of the two vacancies; the other
   lies in an internal face block \(B_k\)
   with \(k<h\).
3. \(b=1\). The unique nonadjacent transition
   \(L_j,R_{j-1}\) has exactly one vacant eligible
   position strictly between its targets. They lie
   in blocks \(B_i,B_h\), respectively, with
   \(i<h\), and the
   other vacancy lies in an internal face block
   \(B_k\) with \(k<i\) or \(k>h\).

Then the parent has a Hamilton cycle containing both
site edges \(xy,uv\). Consequently its legal
site-expanded child is Hamiltonian. The statement
holds for arbitrary positive original lobe lengths.

**Matching barriers.** The second vacancy is
outside the defective block or blocks. Tight
target order at its position makes it and its
following odd slot a free pair. Thus the
free-slot count preceding every occupied target
run differs from the count in the corresponding
one-defect opening by either zero or two. It
remains even. A free chord joining
different blocks cannot straddle an escape target
by Note 203. At each run, at most one same-block
free chord can cross: the other vacancy is outside
the block or blocks of the defect, and a block
with a single vacancy has at most one free slot
on one side of each occupied run, as in Note 215.
Matching parity therefore forbids that chord.
All occupied runs are free-matching barriers.

In case 1, the sole vacant position before
\(R_\ell\), together with Note 197's endpoint
barrier, makes \(R_\ell\) the third interior slot
of \(B_h\). Every preceding block is short.
The possibility \(h=0\) leaves two adjacent free
slots before \(R_\ell\) with no matching mate,
exactly as in Note 211, so \(h\ge1\).
Write \(o_0,e_0,\ldots,o_{h-1},e_{h-1},o_h,w\)
for the free slots before \(R_\ell\). They form
a closed matching group. Note 211's noncrossing
and two-edge-cut proof applies verbatim inside it:
\[
o_0w\in M,\qquad
e_t o_{t+1}\in M\quad(0\le t<h).
\tag{1}
\]
The later vacancy lies in a different block and
group, so no edge incident with it enters this proof.
The reflected assertion handles case 2.

In case 3, the unique vacancy between
\(L_j,R_{j-1}\) and the absence of any other
defect give Note 212's placement:
\(L_j\) is the last eligible even slot of \(B_i\);
its following free slots are \(c_i,e_i\);
the intervening blocks are short; and
\(R_{j-1}\) is the third interior slot of \(B_h\),
preceded by \(o_h,w\). Note 212's two-edge-cut
argument excludes a first-slot destination and
its parity argument excludes a same-block defect.
An extra vacancy in \(B_k\), \(k<i\) or \(k>h\),
adds two to any relevant free prefix but no slot
to the group between these two targets. The same
noncrossing proof therefore gives
\[
c_iw\in M,\qquad
e_t o_{t+1}\in M\quad(i\le t<h).
\tag{2}
\]

Outside the group in (1) or (2), precisely one
free-matching group contains the second vacancy.
It has no target-order defect and contains only
that vacancy. Notes 208--209 prove locally that
either this placement cannot be matched, or
its matching is the ordinary standard chain
with one link \(E O\) replaced by
\[
E i,\qquad h O,
\tag{3}
\]
where \(h,i\) are the free even--odd vacancy
slots. Their proofs use the barriers above,
opposite-side noncrossing, forbidden old-cycle
edges, and the two-edge-cut skipping rule;
the defect is in another closed group and
changes none of these conditions. Every other
free group follows the standard chain.

Let \(A\) be the even-starting matching of the
old Hamilton cycle, indexed from \(x\).
In cases 1--2, Note 211's target-and-square
\(x\)-to-\(v\) path uses (1) to join the delayed
endpoint; in case 3, Note 212's path replaces
the missing transition by \(L_j,c_i,w,R_{j-1}\).
Neither target path enters the extra vacancy
group. The complementary \(x\)-to-\(v\) path
is Note 196's ordinary free path, with the
single link \(EO\) replaced by
\[
E,i,h,O.
\tag{4}
\]
The first and last new edges come from (3),
and \(ih\in A\). The two paths are internally
disjoint and cover every vertex, so their
union is a Hamilton cycle containing \(xy,uv\).
Notes 001 and 178 give the child and restore
the original lobe lengths. \(\square\)

**A realized endpoint-defect profile.** Take
\(\ell=1,r=3\), with the old 28-cycle in
consecutive blocks
\[
\begin{array}{ll}
B_0:&x,o_0,e_0,y,\\
B_1:&a_1,o_1,w,R_1,e_1,b_1,\\
B_2:&a_2,o_2,h,i,e_2,b_2,\\
B_3:&a_3,o_3,e_3,b_3,\\
B_4:&u,o_4,L_1,v,\\
S_1:&\alpha,\gamma,\delta,\beta
\quad\text{returning to }x.
\end{array}
\tag{5}
\]
Its complementary matching is
\[
\begin{split}
M={}&\{xy,uv,a_1b_1,a_2b_2,a_3b_3,
\alpha\beta,R_1\delta,L_1\gamma\}\\
&\cup\{o_0w,e_0o_1,e_1o_2,e_2o_3,
e_3i,ho_4\}.
\end{split}
\tag{6}
\]
The chord intervals \(o_0w\supset e_0o_1\)
and \(ho_4\supset ie_3\supset e_2o_3\)
are nested on the side opposite the site
and face chords. The remaining opposite-side
chords \(R_1\delta,e_1o_2,L_1\gamma\) are
disjoint from these nests or contain them.
Thus (5)--(6) give a simple cubic bipartite
plane graph with cofacial \(xy,uv\).
Its chord-interlacement graph is connected:
\[
xy-o_0w-a_1b_1-e_1o_2-a_2b_2-ho_4-uv
-L_1\gamma-\alpha\beta-R_1\delta-a_1b_1,
\tag{7}
\]
while \(e_0o_1\) attaches to \(xy\),
\(e_2o_3\) joins \(a_2b_2\) to \(a_3b_3\),
and \(e_3i\) attaches to \(a_3b_3\).
Note 217's interval criterion proves
three-connectivity, and its cut projection
proves the 32-vertex legal child is Barnette.
The marked parent cycle is the union of
\[
\begin{split}
&x,o_0,w,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,e_0,o_1,a_1,b_1,e_1,o_2,a_2,b_2,
e_2,o_3,a_3,b_3,e_3,i,h,o_4,u,v.
\end{split}
\tag{8}
\]
These paths share only \(x,v\) and
cover all 28 vertices. \(\square\)

The theorem covers a separated part of the
non-tight \(f=4r+6\) boundary. Two defects,
two vacancies in the defect group or its
endpoint blocks, gap slots, and nonsquare
residual cycles remain outside its hypotheses.
It does not settle Barnette's conjecture.
