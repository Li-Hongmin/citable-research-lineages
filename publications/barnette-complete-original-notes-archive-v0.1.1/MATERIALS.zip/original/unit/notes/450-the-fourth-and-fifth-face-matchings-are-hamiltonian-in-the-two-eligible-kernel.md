> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The fourth and fifth face matchings are Hamiltonian in the two-eligible kernel

[Note 447](447-the-fourth-matching-short-sixth-leaf-word-has-a-four-chord-path.md) reduces a hypothetical non-Hamiltonian legal row-IV/V child in the two-eligible, chorded single-hexagon \(f=7,c=31\) kernel to one ordinary word. This note gives that word a spanning marked path. Consequently rows IV and V are Hamiltonian throughout this kernel; the other matching row VI and other kernel branches remain outside the conclusion.

Use the full leaf paths \(Y_i,X_i,O_i\) and full-branch bracket paths \(P_H,Q_H,R_H\) of [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md). For a full branch \(H\), also put
\[
J_H=(\lambda_0^H,\rho_0^H,\rho_1^H,
\lambda_1^H,\lambda_2^H,\rho_2^H).
\tag{1}
\]
Every consecutive pair in these paths is an old-cycle edge or an ordinary matching chord. Let
\[
\begin{aligned}
S_3&=(L_3,x_3,y_3,R_3),& E&=F(U_2,S_3),& D&=F(E,U_4),\\
C&=F(U_1,D),& A&=F(C,U_5),& B&=F(U_6,U_7),& W&=F(A,B).
\end{aligned}
\tag{2}
\]
The sites are \(y_1,x_2\), and the ordered depth vector is \((3,5,5,4,2,2,2)\). Row IV of [Note 426](426-five-leaf-face-matchings-have-three-unresolved-shapes.md), with ineligible leaves \(3,\ldots,7\), contains the face chords \(x_3y_7\) and \(y_3x_4\).

**Residual-word marked path.** The following is a spanning \(y_1\)--\(x_2\) path of the \(76\)-vertex word \(W\):
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,
\lambda_2^C,\rho_2^C,\rho_1^C,
\lambda_1^C,\lambda_0^C,\rho_0^C=C_r,\\
&L_5\xrightarrow{O_5}R_5,
\rho_2^A\xrightarrow{R_A}\lambda_0^A=A_\ell,
\lambda_2^W\xrightarrow{P_W}\rho_2^W,
B_r=\rho_0^B\xrightarrow{Q_B}\lambda_2^B,\\
&L_6\xrightarrow{O_6}R_6,
L_7\xrightarrow{Y_7^{-1}}y_7,
x_3,y_3,
x_4\xrightarrow{X_4^{-1}}R_4,\\
&\rho_2^D\xrightarrow{P_D^{-1}}\lambda_2^D,
E_\ell=\lambda_0^E\xrightarrow{J_E}\rho_2^E,
R_3,L_3,
R_2\xrightarrow{X_2}x_2.
\end{aligned}
\tag{3}
\]
The two nonordinary jumps are exactly \(y_7x_3\) and \(y_3x_4\), the stated row-IV face chords. The first six \(C\)-bracket vertices in (3) form the path \((\lambda_2,\rho_2,\rho_1,\lambda_1,\lambda_0,\rho_0)\): its first, third and fifth edges are ordinary chords and its other edges are old-cycle edges. The short-leaf edge \(R_3L_3\) is its outer ordinary chord.

All joins between displayed pieces, other than the two face chords, are consecutive old-cycle edges:
\[
\begin{gathered}
L_1\lambda_2^C,\quad C_rL_5,\quad R_5\rho_2^A,\quad
A_\ell\lambda_2^W,\quad \rho_2^WB_r,\quad
\lambda_2^BL_6,\quad R_6L_7,\\
R_4\rho_2^D,\quad \lambda_2^DE_\ell,\quad
\rho_2^ER_3,\quad L_3R_2.
\end{gathered}
\tag{4}
\]
The six full leaves \(U_1,U_2,U_4,U_5,U_6,U_7\) contribute \(36\) vertices; the short leaf contributes four; and the six complete bracket groups \(C,A,W,B,D,E\) contribute \(36\). The pieces in (3) are disjoint and cover exactly these \(76\) vertices. Thus every vertex is visited once and every step is an edge. \(\square\)

The two site edges and the fixed twelve-vertex outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), close (3) to a parent Hamilton cycle containing both site edges. Clause 1 of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to a Hamilton cycle in every corresponding legal child. The path uses \(x_3y_7\), consistent with the necessary condition of [Note 449](449-the-residual-forty-vertex-core-has-no-internal-marked-path.md).

**Row-IV/V theorem.** Every legal child in face-matching row IV or V of the two-eligible, chorded single-hexagon \(f=7,c=31\) kernel is Hamiltonian. For row IV, Notes 433--436 reduce a hypothetical failure to the thirteen short-leaf words of Note 437. The shared-chord corollary of Note 437 and Notes 438--447 close twelve of them; (3) closes the last. Reflection gives row V. This conclusion does not cover row VI, other eligibility spectra, the chord-free single-hexagon branch, multiple residual cycles, or Barnette's conjecture in general. \(\square\)
