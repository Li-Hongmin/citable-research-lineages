> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One-lobe long facial gaps need twelve main vertices

[Note 180](180-first-feasible-square-trap-main-segments-force-one-edge-gap.md)
shows that an all-square-trap facial opening with \(\ell\)
escape lobes and two long site gaps needs at least
\(2\ell+8\) old vertices in its main \(C\)-segment.
For a single lobe, the equality case is itself excluded by
planarity, and the next bound is sharp at every trap length.

Use the legal Barnette expansion, Hamilton parent cycle \(C\),
and all-square-trap facial opening of Notes 176--180. Suppose
the escape network has one lobe, and both residual facial arcs
between the site edges have length at least three.

**Theorem.** The old-vertex main segment satisfies
\[
|V(S_0)|\ge12.
\tag{1}
\]
This is sharp: for every \(k\ge1\) there is a legal Barnette
expansion with one lobe of \(k\) square traps, two facial gaps
of lengths \(2k+1\) and \(3\), and \(|V(S_0)|=12\).

**Exclusion of ten vertices.** Compress the single lobe to
one residual square by Note 178; this preserves \(S_0\),
the site, planarity, bipartiteness and legality. Note 180
already gives \(|V(S_0)|\ge10\) under the two-long-gap
assumption. Suppose equality and write
\[
S_0:\quad w_0=x,w_1,\ldots,w_9=v.
\tag{2}
\]
The site ports occur in the order \(x,y,u,v\). Since \(q=xy\)
and \(p=uv\) are matching edges distinct from \(C\),
\(y\ne w_1\) and \(u\ne w_8\). Bipartiteness makes the
index of \(y\) odd and that of \(u\) even. The face-boundary
order lemma of Note 176 puts the second facial arc inside the
\(C\)-interval from \(y\) to \(u\). Its length is at least
three, so the index difference
between \(u\) and \(y\) is at least three. These conditions
force
\[
y=w_3,\qquad u=w_6.
\tag{3}
\]

Let \(R=t_1^R\) and \(L=t_1^L\) be the two escape targets.
By Note 179, \(R\) has odd index, \(L\) even index, and
\(R\) precedes \(L\). Excluding the four site ports leaves
exactly five possibilities. The other four \(S_0\)-vertices
must be matched to one another. In each row below, the displayed
pairing is the only one respecting the bipartition and avoiding
a matching edge parallel to a \(C\)-edge:

| \((R,L)\) | Forced other two matching edges |
|---|---|
| \((w_1,w_2)\) | \(w_4w_7,\ w_5w_8\) |
| \((w_1,w_4)\) | \(w_2w_7,\ w_5w_8\) |
| \((w_1,w_8)\) | \(w_2w_5,\ w_4w_7\) |
| \((w_5,w_8)\) | \(w_1w_4,\ w_2w_7\) |
| \((w_7,w_8)\) | \(w_1w_4,\ w_2w_5\) |

In every row the two displayed chords have interlacing
endpoints. Moreover, each displayed chord interlaces either
\(q=w_0w_3\) or \(p=w_6w_9\); it therefore cannot lie on
the common-face side of \(C\). Both would have to lie on
the opposite side, where their interlacing makes them cross.
This contradicts planarity. Thus \(|V(S_0)|\ne10\);
its parity and Note 180 give (1). \(\square\)

**Sharpness.** Take the eight-column prism
\(G_2=C_8\square K_2\) and its zigzag Hamilton cycle
\(C_2\) from [Note 172](172-unbounded-nonlocality-of-joint-hamilton-witness-transfer.md).
The legal top-face site
\[
p=T_1T_2,\qquad q=T_5T_6
\tag{4}
\]
has the facial arc \(T_2,T_3,T_4,T_5\) of length three,
with one trapped square
\(T_3,B_3,B_4,T_4,T_3\). The opposite facial arc from
\(T_6\) to \(T_1\) also has length three. The parent has
sixteen vertices, so its remaining main segment has twelve.

For arbitrary \(k\ge1\), replace that induced four-terminal
square by \(L_{2k}\), attaching its four corners to the same
outside edges. Note 178 proves that this replacement preserves
the Barnette class in both parent and child and commutes with
the site expansion. Its explicit top-to-top Hamilton routing
lifts \(C_2\). The selected facial arc now has length
\(2k+1\), contains exactly \(k\) square traps in one lobe,
and leaves the twelve old vertices of \(S_0\) untouched.
The opposite arc still has length three. This proves sharpness
for every \(k\). \(\square\)

The theorem is an exact planar boundary for the one-lobe
all-square-trap branch. It does not decide the Hamilton
transfer at longer main segments or with several lobes.
