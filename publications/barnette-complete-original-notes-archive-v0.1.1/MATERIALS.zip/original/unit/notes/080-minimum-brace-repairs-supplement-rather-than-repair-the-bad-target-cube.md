> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Minimum brace repairs supplement rather than repair the bad target cube

[Note 079](079-sector-collision-calculus-exposes-the-essential-brace-boundary.md)
gives an order-\(20\) complete target family in a nonbrace graph that fails
every eligible sector incidence.  Its two displayed long-collision hole
pairs both extend to perfect matchings, while two other tight \(3\)-cuts
prevent global \(2\)-extendability.  This note determines what happens under
the two smallest natural ways of removing that nonbrace layer while keeping
the wide octagonal interface fixed.

Every same-boundary bipartite three-port replacement preserves a tight cut
unless it collapses the wide face.  In the complete class of minimum
two-\(C_4\) repairs, every plane brace completion acquires neutral targets.
The old bad target cube itself remains bad: the successful targets are new
states forced by the completed perfect-matching incidence.

## 1. Same-boundary caps cannot remove the obstruction

Consider a connected cubic bipartite three-pole \(K\) whose three deficits
lie in bipartition class \(B\), with none in class \(A\).  Counting internal
incidences gives

\[
3|A|=3|B|-3,
\qquad\text{so}\qquad
|B|=|A|+1.
\tag{1}
\]

In a perfect matching of any cubic completion, every vertex in \(A\) is
matched internally.  Those \(|A|\) edges cover \(|A|\) vertices in \(B\),
so precisely one vertex of \(B\) is matched through a port.  Hence every
perfect matching uses exactly one attachment:

\[
|M\cap\delta(K)|=1.
\tag{2}
\]

Every nontrivial same-boundary cap therefore preserves a nontrivial tight
\(3\)-cut and cannot occur in a brace.  The only trivial exception has
\(|A|=0,|B|=1\), namely one cubic vertex.  At either tight cut of the
order-\(20\) object, this replaces a five-vertex facial segment such as

\[
5-13-2-12-4
\]

by \(5-b-4\).  The facial \(C_8\) becomes a \(C_6\), so the wide
\((5,5)\) interface is destroyed.  Thus no same-three-port cap or
\(3\)-sum supplies a wide brace repair, at any order.

## 2. Complete minimum two-\(C_4\) repair class

Keep pointwise fixed the facial octagon

\[
C=(13,5,17,7,16,4,12,2),
\tag{3}
\]

the gates \(5\,13,4\,16\), and root \(3\,15\).  Permit the standard
noncrossing bipartite \(C_4\)-expansion only on two cofacial edges outside
\(E(C)\cup\{3\,15\}\).  Such an expansion preserves the named interface.

There are exactly \(24\) admissible first moves.  None produces a brace.
Their remaining nonextendible independent edge pairs have the distribution

\[
\begin{array}{c|cc}
\text{remaining pairs}&6&3\\ \hline
\text{first moves}&17&7.
\end{array}
\tag{4}
\]

The seven moves in the second column repair one original tight cut; the
other seventeen repair neither.

From every one-step child, perform every admissible second expansion under
the same frozen-edge restriction.  This gives \(868\) labelled two-step
sequences.  Exactly \(32\) final graphs are \(2\)-extendable.  Each is
simple, plane, cubic, bipartite and \(3\)-connected, hence a plane brace;
all \(32\) follow one of the seven first moves that left three bad pairs.
This is the complete minimum two-\(C_4\) repair class, not a selected sample.

## 3. Brace repair adds new neutral targets

For each repaired brace \(G\), enumerate the complete rooted target family

\[
\mathcal T_e=
\{M:e\in M,\ G-M\text{ is two cycles separating the ends of }e\}.
\tag{5}
\]

Every one of the \(32\) families is nonempty and contains a target using
neither gate:

\[
\boxed{
\min_{M\in\mathcal T_e}
|M\cap\{5\,13,4\,16\}|=0.}
\tag{6}
\]

Thus no repaired brace satisfies the forced-double-gate premise of
Note 076.  In fact, throughout this finite class,

\[
\boxed{
M\text{ has a rooted-sector lift}
\iff |M\cap\{5\,13,4\,16\}|\le1.}
\tag{7}
\]

Across the \(32\) labelled sequences, the complete families contain \(612\)
target occurrences:

\[
\begin{array}{c|ccc}
\text{gate load}&0&1&2\\ \hline
\text{target occurrences}&222&210&180.
\end{array}
\tag{8}
\]

Exactly \(432=222+210\) targets lift.

The old four-target cube can be tracked through both gadgets by contracting
each canonical noncross matching pattern.  There are \(126\) target
occurrences projecting to an original bad target, and

\[
\boxed{
\text{all \(126\) remain double-gate and nonliftable}.}
\tag{9}
\]

The other \(486\) occurrences are new complete-family states.  Exactly
\(432\) of them are neutral and liftable; the remaining \(54\) are
double-gate and nonliftable.  The brace repair therefore does not improve
the inherited bad states.  It changes global perfect-matching incidence so
that completeness supplements the family with new good states.

The full enumeration, target equality, local rows and two-step projections
are checked by the
[minimum two-\(C_4\) brace-repair bundle](../computations/bundles/minimum-two-c4-brace-repairs/README.md).

## 4. Boundary

Within the smallest natural repair mechanisms,

\[
\boxed{
\begin{gathered}
\text{same-boundary three-port replacement}\\
\Longrightarrow\text{tight cut persists or wideness is lost},\\
\text{minimum two-\(C_4\) brace repair}\\
\Longrightarrow\text{new zero-gate targets enter the complete family}.
\end{gathered}}
\tag{10}
\]

This rules out a plane-brace counterexample throughout the complete local
repair class.  More importantly, it identifies a positive mechanism:
global \(2\)-extendability need not shorten the monochromatic path behind an
old collision; it can instead enlarge the complete target family until a
neutral lift appears.

**Exact conclusion.**  Same-boundary caps cannot remove the nonbrace layer
while preserving the wide site.  Every minimum two-\(C_4\) brace repair
adds a zero-gate target, while all projected descendants of the old bad cube
remain bad.

**Evidence level.**  The cap obstruction is an arbitrary-order counting
proof.  The two-\(C_4\) statement is an exact bounded structural
classification of \(868\) labelled repair sequences.

**Unresolved boundary.**  A larger or qualitatively different brace
completion may preserve the same site and still force both gates.  Any such
completion must avoid the target-supplementation mechanism in (6)--(9); it
cannot be a same-boundary cap or a minimum two-\(C_4\) repair.

