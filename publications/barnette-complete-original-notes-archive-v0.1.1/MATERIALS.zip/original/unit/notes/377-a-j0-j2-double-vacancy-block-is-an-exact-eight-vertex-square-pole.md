> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A J0,J2 double-vacancy block is an exact eight-vertex square pole

[Note 325](325-even-rainbow-multivacancy-blocks-are-exact-square-reductions.md)
already proves this reduction as the \(q=2\) even-ladder
case. The argument below is a direct six-state proof
with a twelve-vertex Barnette cap.
[Note 227](227-all-target-free-same-block-double-vacancies-are-hamiltonian.md)
shows, when one doubly vacant target-free block is
the only vacancy in its free group, that its
\(J_0=oe\) chord forces \(J_2=hj\).
It gives a marked Hamilton route. The two chords
together make the eight-vertex block an
exact square-equivalent four-pole, independently
of every other vacancy or matching choice outside
the block.

Let \(P\) have old-cycle path
\[
                         a,o,h,i,k,j,e,b             \tag{1}
\]
and the three additional edges
\[
                         ab,\qquad oe,\qquad hj.       \tag{2}
\]
Its four degree-two terminals, in old-cycle
and disk-boundary order, are \((a,i,k,b)\).
All other vertices have degree three.

**Eight-vertex double-block theorem.** The
complete spanning one-path and two-path Hamilton
signature of \(P\) equals that of a square with
the four corresponding labeled corners
\((a',i',k',b')\). Replacing an induced disk
copy of \(P\) in a Barnette graph by this
square, or reversing the replacement, preserves
Barnette membership and every exterior- and
attachment-marked Hamilton decision.

In a compressed, gapless, tight-target
all-square selected opening, any target-free
doubly vacant block whose complementary
matching contains both \(J_0=oe\) and
\(J_2=hj\) is exactly such an induced patch.
Its replacement preserves the selected old
cycle, common-face arc, site edges and legal
site expansion. There is no condition on the
number, locations, or types of other
vacancies. Consequently no vertex-minimal
non-Hamiltonian Barnette graph contains
an induced disk copy of \(P\).

**Six routing states.** In the order (1),
\(a,k\) have one bipartition colour and
\(i,b\) the other. The four possible
single-path endpoint pairs all occur:
\[
\begin{array}{c|l}
ab&(a,o,h,i,k,j,e,b)\\
ik&(i,h,o,a,b,e,j,k)\\
ai&(a,b,e,o,h,j,k,i)\\
kb&(k,i,h,j,e,o,a,b).
\end{array}                                             \tag{3}
\]
All joins are path edges or edges in (2).
The two noninterlacing two-path pairings occur:
\[
\begin{array}{c|l}
\{ai,kb\}&(a,o,h,i),\quad(k,j,e,b)\\
\{ab,ik\}&(a,b),\quad(i,h,o,e,j,k).
\end{array}                                             \tag{4}
\]
The remaining pairing \(\{ak,ib\}\)
interlaces the cyclically ordered disk
terminals and is impossible. Thus (3)--(4)
are exactly the square's six routing states.
A global Hamilton cycle meets the patch
cut in two or four edges; replacing its
one or two spanning patch paths by the
same state of the square works in both
directions without changing exterior edges.

**The disk side in an actual opening.** In a
selected opening \(ab\) is the common-face
block-closing chord. The only unmatched
interior slots of (1) after \(oe,hj\) are
\(i,k\). Their mutual edge \(ik\) belongs
to the old cycle, so each receives a
matching edge from outside the block.
Every cross-block free matching chord is
on the opposite side of the common face
by Note 193. If \(oe\) lay on that
opposite side, it would enclose both
\(i,k\), and either external chord would
cross it. The same argument applies to
\(hj\). Therefore both nested chords in
(2) lie on the common-face side under
\(ab\). The two external matching edges
at \(i,k\) can leave on the other side.
The four terminals lie on one disk
boundary in the order claimed.

**Barnette-class preservation.** Cap the
four terminals by a fresh square
\((t_b,t_k,t_i,t_a)\), attaching
\(bt_b,kt_k,it_i,at_a\).
The old path (1), followed by
\(t_b,t_k,t_i,t_a,a\), is a Hamilton
cycle of the resulting 12-vertex graph.
Its complementary perfect matching is
\[
            ab,\ oe,\ hj,\ it_i,\ kt_k,\ t_bt_a .
\tag{5}
\]
Draw \(ab\supset oe\supset hj\) and
\(t_bt_a\) on one page of this cycle;
draw \(it_i\supset kt_k\) on the other.
Both pages are noncrossing. Each chord
joins opposite old-cycle parities,
so the cap is simple, cubic, bipartite
and plane. Each of \(it_i,kt_k\)
interlaces each of the four one-page
chords \(ab,oe,hj,t_bt_a\); the
matching-chord interlacement graph
is \(K_{2,4}\). A two-edge cut would
close a proper Hamilton-cycle interval
under the matching and disconnect that
interlacement graph. The Hamilton cycle
excludes bridges. A cubic graph without
one- or two-edge cuts is
three-vertex-connected, proving that
this cap is a Barnette graph.

The cycle \(a,o,h,i,k,j,e,b,a\)
shows that \(P-v\) is connected for
each patch vertex \(v\). If deleting
two patch vertices left a component
without a surviving terminal, that
component would also disconnect
the three-connected cap after the same
deletion. The square has the same
one- and two-deletion properties.
In any three-connected cubic host
containing either induced disk patch,
the exterior is connected: two exterior
components would each need at least
three of the four attachment edges.
The four-attachment deletion comparison
of Note 370 therefore preserves
three-connectivity in both replacement
directions. The terminal colour pattern
and disk order preserve bipartiteness
and planarity; degrees and simplicity
are immediate. This completes the
proof. \(\square\)

The theorem handles the \(J_0,J_2\)
combination only. It does not claim
that either chord alone forces the
other when further vacancies share
the free group. Such matchings,
other internal chord types, other
opening types, and Barnette's
conjecture remain unresolved.
The proof is project-internal and
has not had independent review.
