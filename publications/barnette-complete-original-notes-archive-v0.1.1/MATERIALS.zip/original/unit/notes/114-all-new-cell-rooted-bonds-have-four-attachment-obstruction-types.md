> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All new-cell rooted bonds have four attachment obstruction types

[Note 108](108-kill-cover-supplementation-is-exactly-a-rooted-split-bond-lemma.md)
reduces one-step kill-cover supplementation to a rooted bond incident with
one of three new local cells after a vertex split in an Eulerian plane
triangulation.  [Note 112](112-canonical-cross-supplementation-is-exactly-wrong-interval-island-exclusion.md)
classifies only canonical--cross pairs, while
[Note 113](113-wrong-interval-islands-reduce-to-rooted-island-exchange-flexibility.md)
shows that this restricted target has an additional occupancy premise.
This note gives the arbitrary-order attachment criterion for every pair
allowed by the original rooted split-bond lemma.

After the three split vertices are deleted, every XOR shore has zero, one,
or two connected local cores.  Consequently every failure is witnessed by
one of four forms: absence of an opposite-gate new-cell pair, fragmentation
of a shore without a local core, an old component missing the attachment
set of one local core, or failure to join the two local cores of a
cross--cross pair.

## 1. The split interface

Use the notation of Note 108.  The split patch has vertices
\(A,B,C,P,Q\) and local edges

\[
 AP,BP,CP,AQ,BQ,CQ,AC,BC.
\tag{1}
\]

Put

\[
 H=T^+-\{A,B,C\},\qquad
 J_A=N_{T^+}(A)\cap V(H),\qquad
 J_B=N_{T^+}(B)\cap V(H).
\tag{2}
\]

The sets \(J_A,J_B\) are the two closed rotation intervals inherited from
the split vertex, and both contain \(P,Q\).  Write

\[
 R=R_{00},\qquad U=X_{uy},\qquad V=X_{vx},\qquad
 {\cal C}=\{C_{00},C_{10},C_{01}\},\qquad
 {\cal N}=\{R,U,V\}.
\tag{3}
\]

The \(C_{11}\) row is not root-admissible: its isolated \(C\)-component is
dual to the isolated central complement cycle.  Hence the complete rooted
child family uses precisely the six cells in
\({\cal C}\cup{\cal N}\).

Let \(\chi,\eta\) be root-admissible NAE colourings in two of these cells.
Choose the representatives given by the five-bit rows of Note 108 and set

\[
 D=D(\chi,\eta)=\{v\in V(H):\chi(v)\ne\eta(v)\}.
\tag{4}
\]

Simultaneous global reversal does not change \(D\).  If the surviving-gate
bits are opposite, the gate dual edge crosses \(D\), so both \(D\) and
\(\bar D=V(H)\setminus D\) are nonempty.

For \(S\subseteq V(H)\), define

\[
\begin{aligned}
 h_A(S)&\Longleftrightarrow
   \text{every component of }H[S]\text{ meets }J_A,\\
 h_B(S)&\Longleftrightarrow
   \text{every component of }H[S]\text{ meets }J_B,\\
 h_{AB}(S)&\Longleftrightarrow
   \text{every component of }H[S]\text{ meets }J_A\cup J_B,\\
 j_{AB}(S)&\Longleftrightarrow
   \text{some component of }H[S]\text{ meets both }J_A\text{ and }J_B,\\
 e_{PQ}(S)&\Longleftrightarrow
   \text{every component of }H[S]\text{ meets }\{P,Q\}.
\end{aligned}
\tag{5}
\]

Write \({\rm conn}(S)\) when \(H[S]\) is nonempty and connected.

## 2. Complete attachment calculus

**Theorem 1.**  Let \(\chi,\eta\) be root-admissible NAE colourings with
opposite surviving-gate bits, and suppose that at least one of their local
cells belongs to \({\cal N}\).  Their XOR cut is a bond if and only if the
condition in the last column below holds.

\[
\begin{array}{c|c|c}
\text{cell pair}&
D\cap\{A,B,C,P,Q\}&
\text{bond criterion}\\ \hline
C_{00}\!-\!U,\ C_{10}\!-\!U,\ C_{01}\!-\!U&
ACPQ,\ AQ,\ AP&
h_A(D)\wedge h_B(\bar D)\\
C_{00}\!-\!V,\ C_{10}\!-\!V,\ C_{01}\!-\!V&
BCPQ,\ BQ,\ BP&
h_B(D)\wedge h_A(\bar D)\\
R\!-\!V&AC&h_A(D)\wedge h_B(\bar D)\\
R\!-\!U&BC&h_B(D)\wedge h_A(\bar D)\\
C_{10}\!-\!R,\ C_{01}\!-\!R&
ABCQ,\ ABCP&
h_{AB}(D)\wedge {\rm conn}(\bar D)\\
C_{00}\!-\!R&ABPQ&\text{never}\\
R\!-\!R,\ U\!-\!U,\ V\!-\!V&
\varnothing&
{\rm conn}(D)\wedge h_{AB}(\bar D)\\
U\!-\!V&AB&
h_{AB}(D)\wedge j_{AB}(D)\wedge e_{PQ}(\bar D).
\end{array}
\tag{6}
\]

In a same-cell row the endpoints are two distinct colourings in that cell.

*Proof.*  Contract each component of \(H[D]\) and of \(H[\bar D]\), retain
the new vertices \(A,B,C\), and retain the edges \(AC,BC\).  A retained
\(A\) is adjacent precisely to component nodes meeting \(J_A\), a retained
\(B\) to those meeting \(J_B\), and a retained \(C\) to those containing
\(P\) or \(Q\).  Each XOR shore is connected exactly when its attachment
quotient is connected.

For a \({\cal C}\)--\(U\) pair, and also for an \(R\)--\(V\) pair, the
\(D\)-shore has one connected local core attached through \(J_A\), while
the complementary shore has one connected local core attached through
\(J_B\).  This gives the first and third rows.  Exchanging \(A,B\) gives
the second and fourth rows.

For \(C_{10}\)--\(R\) and \(C_{01}\)--\(R\), the \(D\)-shore contains the
connected core \(ABC\), attached through \(J_A\cup J_B\), whereas the
other shore contains no new local vertex.  Its two connectivity conditions
are therefore \(h_{AB}(D)\) and \({\rm conn}(\bar D)\).

For \(C_{00}\)--\(R\), the complementary local core is the singleton
\(C\), but both old neighbours \(P,Q\) of \(C\) belong to \(D\).  Its
shore could be connected only if \(\bar D\) were empty.  Opposite gate
bits imply \(\bar D\ne\varnothing\), so this pair is impossible.

For a same-cell pair, the \(D\)-shore contains no new local vertex and must
be connected inside \(H\).  The other shore contains the connected core
\(ABC\), attached through \(J_A\cup J_B\).  This gives the seventh row.

For \(U\)--\(V\), the \(D\)-shore has two local cores, \(A\) and \(B\).
Every old component must attach to at least one core, and some old component
must attach to both in order to join them.  These conditions are
\(h_{AB}(D)\) and \(j_{AB}(D)\).  The complementary local core is \(C\),
which attaches to old components only through \(P,Q\); this gives
\(e_{PQ}(\bar D)\).  The rows exhaust all unordered cell pairs having a
new-cell endpoint. \(\square\)

The theorem assumes that both endpoints are already root-admissible.  Its
conditions test only shore connectivity.  The opposite gate bits ensure
that every resulting bond contains the surviving-gate dual edge.

## 3. Four obstruction forms

Under parent kill cover, Note 108 excludes every canonical--canonical
rooted bond.  The rooted split-bond conclusion therefore fails precisely
when no opposite-gate pair in Theorem 1 satisfies its row.  Every such
failure has at least one of the following forms.

1. **Occupancy void \(\mathsf O\).**  No opposite-gate pair has a new-cell
   endpoint.
2. **Bare-shore fragmentation \(\mathsf F_0\).**  A shore with no new local
   core is disconnected inside \(H\); equivalently, one of the required
   \({\rm conn}\) predicates fails.
3. **Unattached island \(\mathsf F_1\).**  A shore has one connected local
   core, but an old component misses its attachment set; equivalently, one
   of \(h_A,h_B,h_{AB},e_{PQ}\) fails.  The \(C_{00}\)--\(R\) pair is a
   forced instance on the \(C\)-shore.
4. **Unbridged double core \(\mathsf F_2\).**  For a \(U\)--\(V\) pair,
   every old \(D\)-component attaches to \(A\) or \(B\), but no component
   attaches to both; equivalently,
   \(h_{AB}(D)\wedge\neg j_{AB}(D)\).

These forms need not be mutually exclusive for a given pair.  They are
complete because, after \(H\) is deleted, an XOR shore in (6) has zero,
one, or two connected local cores.  Zero cores leave only internal
fragmentation; one core leaves only an attachment failure; two cores add
only the possibility that the cores remain unjoined.  Occupancy fails
before an attachment quotient exists.  Thus the full failure alphabet is

\[
\boxed{\{\mathsf O,\mathsf F_0,\mathsf F_1,\mathsf F_2\}.}
\tag{7}
\]

## 4. The cell-pair union is irreducible at the attachment level

Let

\[
 \mathscr P^*=
 \bigl\{\{K,L\}:K,L\in{\cal C}\cup{\cal N},\
 \{K,L\}\cap{\cal N}\ne\varnothing\bigr\}
 \setminus\bigl\{\{C_{00},R\}\bigr\}.
\tag{8}
\]

Thus \(\mathscr P^*\) contains the fourteen cell pairs permitted by
Theorem 1.  The union over these pairs cannot be replaced, at the
attachment-quotient level, by any fixed proper subfamily.

**Proposition 2.**  For every \(p\in\mathscr P^*\), there is a two-shore
attachment quotient satisfying the bond row of \(p\).  Consequently, for
every proper \(S\subsetneq\mathscr P^*\), the parent kill-cover incidence
and the full child supplementation conclusion admit a strict abstract
model in which the unique child bond has type
\(p\in\mathscr P^*\setminus S\).

*Proof.*  Use one old component node on each shore and join their
realizations by the external gate edge.  Place \(P,Q\) on the shores
prescribed by the local XOR row.

For a canonical--cross or \(R\)--cross pair, mark one old component by the
required \(J_A\) or \(J_B\) attachment on each shore.  For a
\(C_{10}/C_{01}\)--\(R\) pair, mark the \(D\)-component by
\(J_A\cup J_B\) and leave the complementary old shore connected.  For a
same-cell pair, both old shores are single components and mark the
complementary component by \(J_A\cup J_B\).  For \(U\)--\(V\), put one
\(J_A\)-vertex and one \(J_B\)-vertex in the same \(D\)-component, and put
\(P,Q\) in the complementary component.  Replacing a component node by a
short path through its marked vertices realizes each quotient by a
connected old graph.  These constructions satisfy exactly the zero-, one-,
and two-core connectivity conditions of Theorem 1.

Couple the chosen quotient to a parent incidence graph consisting of one
\(L_{11}\)--non-\(11\) bond, canonically retain the non-\(11\) child
endpoint when it is needed, and admit only the two child endpoints of
\(p\).  Give every admitted endpoint the formal labelled region tree
\(L_r-K-L_s\), and give the unique bond a balanced four-rank profile with
separated root fragments.  Each named cell is one of the valid local NAE
rows.  The parent graph is nonempty and kill-covered, while the child has
one rooted bond of type \(p\). \(\square\)

This is an attachment-quotient model, not the complete NAE family of one
actual \(4\)-connected Eulerian plane triangulation.  It nevertheless gives
the exact logical boundary at this level: canonical--canonical pairs are
excluded by kill cover, \(C_{00}\)--\(R\) is excluded by attachment, and
no other fixed cell-pair deletion is forced.  In particular,
canonical--cross, canonical--\(R\), new--new, a specified new cell, and
direct parent ancestry are all too narrow without an additional common
actual-incidence theorem.

## 5. Consequence and boundary

Canonical--cross failure is only the \(h_A/h_B\) part of Theorem 1.  It
does not decide the original rooted split-bond lemma because a successful
bond may instead be canonical--\(R\), \(R\)--cross, same-cell, or
\(U\)--\(V\).  In particular, the opposite-gate occupancy condition
\(\mathsf{OX}\) isolated in Note 113 is not needed by the full theorem.

The remaining arbitrary-order statement is now exact:

\[
\boxed{
\begin{gathered}
\text{parent kill cover in an actual legal split pair}\\
\Longrightarrow
\text{the complete root-admissible child family avoids}\\
\mathsf O,\mathsf F_0,\mathsf F_1,\mathsf F_2
\text{ simultaneously.}
\end{gathered}}
\tag{9}
\]

The attachment calculus proves neither this implication nor its negation.
It shows exactly what an actual counterexample must protect across every
opposite-gate new-cell pair.  Conversely, a proof may use any of the rows
in (6); it need not force a canonical--cross witness or a direct parent
ancestor.  The missing input remains coupling among the complete NAE
family, labelled root-admissibility, and the common actual triangulation
incidence.
