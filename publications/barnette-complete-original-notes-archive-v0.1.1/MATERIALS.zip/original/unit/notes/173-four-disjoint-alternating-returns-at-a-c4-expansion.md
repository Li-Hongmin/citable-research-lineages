> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Four disjoint alternating returns at a \(C_4\) expansion

Let \(H\) be a finite cubic bipartite graph containing a square
\(Q=abcda\). Suppose its four external edges are
\(ua,vb,xc,yd\), with distinct external vertices, and a perfect matching
\(M\) contains all four of these edges. Thus \(Q\) is a component of the
complementary 2-factor \(H-M\). Choose the bipartition so that
\(u,x,b,d\) lie on one side. The assertion below does not require a plane
embedding or 3-connectivity.

**Four-return theorem.** There are four simple \(M\)-alternating cycles
\(A_1,\ldots,A_4\) with the following properties.

1. Each \(A_i\) uses exactly one edge of \(Q\), two external edges of
   \(Q\), and no other edge incident with \(Q\). Consequently
   \((H-M)\triangle A_i\) opens the square into a path through its four
   vertices.
2. No edge of \(E(H)\setminus(M\cup E(Q))\) lies in two of the cycles.
   Every edge of \(M\) lies in at most two of them.

In particular, let \(R\) be a set of nonmatching edges outside \(Q\), and
\(S\) any set of matching edges. At least
\[
\max\{0,4-|R|-2|S|\}
\tag{1}
\]
of the four openings avoid \(R\cup S\). This includes the marked
opening lemma of the [September 26 analysis](../advisor/gpt6pro-2026-09-26-marked-opening-shortest-return.md): one retained edge required in a Hamilton cycle belongs to \(R\), and one retained edge forbidden from it belongs to \(S\), so at least one opening preserves both marks. The present theorem also gives three openings when only one nonmatching edge is protected, and two when only one matching edge is protected.

## Proof

Contract every matching edge, naming its contracted vertex by its endpoint
in the chosen bipartition class. For each nonmatching edge, direct its arc
from the contracted pair containing its chosen-class endpoint to the pair
containing its other endpoint. The resulting
directed multigraph \(D\) has indegree and outdegree two at every vertex.
The four square edges become all four arcs from \(V=\{b,d\}\) to
\(U=\{u,x\}\). Delete these four arcs to form \(D_0\).

For any vertex set \(X\), balance in \(D\) and the complete
\(V\)-to-\(U\) square give
\[
d^+_{D_0}(X)-d^-_{D_0}(X)
   =2\bigl(|U\cap X|-|V\cap X|\bigr).
\tag{2}
\]
Add a source with capacity-two arcs to each vertex of \(U\), and
capacity-two arcs from each vertex of \(V\) to a sink. Give every arc of
\(D_0\) unit capacity. The capacity of the cut whose original-vertex
side is \(X\) is, by (2),
\[
 d^+_{D_0}(X)+2|U\setminus X|+2|V\cap X|
 =d^-_{D_0}(X)+4\geq4.
\tag{3}
\]
The source has total outgoing capacity four. Integral max-flow/min-cut
therefore supplies four arc-disjoint directed \(U\)-to-\(V\) paths in
\(D_0\), twice from each vertex of \(U\) and twice into each vertex of
\(V\). Delete flow cycles and shorten each path to make it simple.
Since \(U\) has no incoming arc and \(V\) has no outgoing arc in \(D_0\),
no path contains another terminal internally.

Close each path from \(r\in U\) to \(t\in V\) with the square arc
\(t\to r\). Expanding the matching contractions yields a simple
\(M\)-alternating cycle. The four paths use disjoint nonmatching arcs of
\(D_0\), proving the first edge-incidence assertion. A contracted
matching vertex has only two incoming arcs in \(D_0\), so at most two
of the paths visit it. This proves the second assertion and (1) by the
union bound. The cut capacity in (3) equals four when \(X=U\), so the
four-unit packing is maximal. \(\square\)

If \(n_{rt}\) counts packed paths from \(r\in U\) to \(t\in V\),
their source and sink multiplicities force the exact endpoint matrix
\[
\begin{pmatrix}n_{ub}&n_{ud}\\n_{xb}&n_{xd}\end{pmatrix}
=\begin{pmatrix}j&2-j\\2-j&j\end{pmatrix},
\qquad j\in\{0,1,2\}.
\tag{4}
\]
Thus every maximum packing closes through either the two same-seal square
edges \(ab,cd\), the two cross square edges \(ad,bc\), or all four.

**All-four-edge refinement.** If \(H-M=Q\dot\cup C\), where \(C\) is one
cycle through every vertex outside \(Q\), the four cycles \(A_i\) can be
chosen to use \(ab,bc,cd,da\) once each. They retain the edge-incidence
bounds of the four-return theorem. In particular, for every prescribed
edge \(e\in C\), at least one of the two cross openings, through
\(ad\) or \(bc\), avoids \(e\).

To prove the refinement, contracting \(M\) turns the connected cycle
\(C\) into a connected underlying graph for \(D_0\): each contracted
matching pair contains a vertex of \(C\). Thus \(D\) is connected and
Eulerian. Remove the four square arcs from an Euler tour of \(D\). Its
four intervening pieces are directed \(U\)-to-\(V\) trails that partition
all arcs of \(D_0\). Their vertex-intersection graph is connected because
the underlying graph of \(D_0\) is connected.

If the endpoint matrix of these trails already has \(j=1\) in (4),
there is one trail for each ordered pair. Otherwise it has \(j=0\) or
\(j=2\). The connected intersection graph then contains two trails
with different starting vertices \(u,x\) that meet at a vertex. Split
both at one such common vertex and exchange their suffixes. This keeps
all arcs partitioned into four directed trails, while changing their
endpoints so the matrix becomes \(j=1\). Erase any closed subtrail from
each trail to leave four simple, arc-disjoint paths with the same
endpoints. Closing them with their four distinct square arcs gives the
required alternating cycles. A nonmatching edge of \(C\) appears in at
most one of these paths, proving the final assertion. \(\square\)

## Consequence and boundary

If a parent Hamilton cycle \(C\) avoids both deleted site edges, then
\(C\dot\cup Q\) has precisely the required form. A retained edge
\(e\in C\) is nonmatching, while a retained edge \(f\notin C\) is a
matching edge outside the four spokes: at each old site endpoint the
omitted incident edge is already a deleted site edge. Hence the theorem
produces an opening that keeps \(e\) and avoids \(f\). If the parent has
\(n\) vertices, the selected simple return avoids the pair contracted
from \(f\) and the two unused terminals among \(U\cup V\). Its
alternating cycle therefore has at most
\(2((n+4)/2-3)=n-2\) edges, recovering the length bound of the
marked opening lemma.

The opened complementary 2-factor may still contain old closed
components. The theorem proves four return routes and their protected-edge
robustness; it does not prove that any one return creates a Hamilton cycle.
For a hard state-\(00\) joint-witness transfer, the endpoint-pairing
question is settled before imposing the forbidden old matching edge:
both cross square edges have openings, and at least one survives the
required old cycle edge. The remaining tests are whether a cross opening
can also avoid the forbidden matching edge and whether its old complement
has one component. The four-unit flow count does not settle either test.
