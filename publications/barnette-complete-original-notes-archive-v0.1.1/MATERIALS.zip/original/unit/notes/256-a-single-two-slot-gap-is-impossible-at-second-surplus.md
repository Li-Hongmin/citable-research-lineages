> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A single two-slot gap is impossible at second surplus

[Note 255](255-capacity-saturation-excludes-every-positive-gap.md)
shows that a positive interblock gap requires a free matching
chord inside one block on the designated-face side of the old
Hamilton cycle. At the second surplus, if both gap slots occupy
one gap, the unique vacant eligible block position makes that
chord possible in only one local shape. Its required matching
then creates a two-edge cut.

Use the compressed all-square opening of Notes 195 and 255.
Let \(\ell,r\ge1\), and write
\[
\sigma=\sum_{i=0}^{r+1}k_i-(\ell-1),\qquad
T=\sum_{a=0}^{r}t_a.
\]
Assume \(\sigma=1\), and that one gap \(G_a\) has exactly
two slots \(g,h\) in main-segment order, with every other gap
empty. Thus \(T=2\) and \(f=4r+6\). The slots have colours
\(g=E,h=O\), and \(gh\in E(C)\). Every block is forward.

**Single-gap exclusion theorem.** No three-connected cubic
bipartite plane parent \(G\) admits this selected all-square
opening. Consequently, at \(f=4r+6\), every opening with
positive gaps has two singleton gaps in distinct positions.

**Proof.** There is exactly one eligible even block position
not occupied by a nonfinal \(L\)-target. It may be free or
occupied by \(L_1\). The target-order charging argument of
[Note 197](197-gapless-square-trap-defect-budget.md) still gives
at most one endpoint or nonadjacent-transition defect here.
The endpoint barrier in that note allows arbitrary gaps.
For a cross-block transition, a destination at the first
slot of a later block is excluded by the same prefix
two-edge cut: take the prefix through the *whole gap*
before that block, together with the appropriate square
suffix. A departing free chord would straddle the
destination target on the opposite side of \(C\).
Since all blocks are forward, every remaining defect
receives an eligible position before, between, or at its
targets, exactly as in Note 197. These charged positions
are disjoint, proving the one-defect bound.

At every escape target the free-slot prefix has even size,
by the index calculation in Note 255. A cross-atom free
chord cannot straddle it by Note 203. With at most one
eligible vacancy, at least one side of each target has at
most one free slot in its own block. In a tight target
block its possible free slots are its first odd slot, its final
even slot, and, if present, the adjacent vacancy pair
\(H,I\). For a target before that pair only the first
odd slot can be free before it; for a target after the
pair only the final even slot can be free after it.
A delayed first target has \(o,H\) before it and at most
the final even slot after it; an advanced last target
has at most the first odd slot before it and an adjacent
odd-even pair after it. At a cross-block defective
transition, the source has at most one free odd slot before its
target and two adjacent free slots after, while the
destination has two adjacent free slots before its
target and at most one final slot after. For a same-block
defective transition, the sole vacancy and its
preceding free odd slot lie between the two targets,
leaving at most the first or final free slot on the
opposite side. These are all one-defect shapes.
Matching parity therefore forbids any same-block free
chord across a target. In a target-free run inside a
block, consecutive free slots are old-cycle neighbours;
a nonconsecutive opposite-colour pair can occur only when
a target-free *face* block \(B_k\), \(1\le k\le r\), has
the four free slots
\[
o_k,H,I,e_k,                                  \tag{1}
\]
where \(H\) is the vacant even position. Its sole
possible internal free matching chord is \(o_ke_k\).
A site block cannot have (1): the first and last targets
remain at their site blocks if the vacancy is free; moving
either target to another block would consume the unique
vacancy by the endpoint barrier. If the eligible position
is occupied by \(L_1\), it creates no four-slot free run.
Thus the gap-face-chord obstruction of Note 255 forces
the target-free block (1) and
\[
o_ke_k\in M,                                  \tag{2}
\]
drawn on the designated-face side. Every other free-slot
matching edge lies on the opposite side and those edges
do not interlace.

Reflect the opening if necessary so that \(B_k\) follows
the gap, hence \(k>a\). Consider the mate of \(g\).
If a target lies between them, Note 203 forbids the
chord. Otherwise Note 255's parity argument gives an
odd number of free slots strictly inside a proposed
gap-to-block chord. Since (2) is the only matching edge
on the other side, the proposed chord can be matched
only if exactly one of \(o_k,e_k\) lies inside it.
The only available odd block slot with this property
is \(I\): earlier odd slots enclose neither endpoint
of (2), and odd slots after \(B_k\) enclose both.
The slot \(o_k\) is already used by (2). Also \(gh\)
is an old-cycle edge. Therefore
\[
gI\in M.                                      \tag{3}
\]
The chord (3) cannot straddle a target, so every complete
block strictly between \(G_a\) and \(B_k\) is short and
target-free.

The slot \(h\) lies inside the opposite-side chord \(gI\);
its mate must lie inside that chord as well. An even
slot in an intervening short block would again enclose
an odd number of free slots, with neither endpoint of
(2) inside. The only viable even slot is \(H\), because
\(o_k\) lies between \(h,H\) while \(e_k\) lies after them.
Thus
\[
hH\in M.                                      \tag{4}
\]
If \(k>a+1\), every complete block
\(B_{a+1},\ldots,B_{k-1}\) lies inside the chord \(hH\).
Its fixed face edge is internal; its free slots cannot
leave that block interval without interlacing \(hH\),
since \(o_k\) is already paired to \(e_k\).
The interval is matching-closed and has only two
old-cycle boundary edges, contradicting
three-connectivity. If \(k=a+1\), the consecutive
interval consisting of \(g,h\) and all vertices of
\(B_k\) is matching-closed by (2)--(4) and its fixed
face chord. It too has exactly two departing old-cycle
edges. Both cases are impossible. \(\square\)

Combined with Notes 254--255, this leaves exactly the
*split-gap* parameter shape at the all-square second surplus:
\(\sigma=1\) and two distinct singleton gaps. The theorem
does not decide that shape, nonsquare residual cycles, or
Barnette's conjecture for arbitrary graphs.
