> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A port-free central vacancy gives three states between separated ports

[Note 312](312-a-short-block-corridor-reduces-separated-ports-to-consecutive-ports.md)
compresses the short runs between two nonconsecutive ports. [Note 313](313-square-buffers-monotonically-enlarge-six-port-hamilton-linkages.md)
gives a one-way six-port route lift and proves that alias-free square
buffer reversal preserves the Barnette class at a vacant face-chord
block. Together they give a structural reduction of a one-vacancy
corridor to the
consecutive-port theorem of [Note 300](300-every-consecutive-two-port-free-group-has-three-routes.md).

Let a Barnette parent have the compressed, gapless, tight-target
all-square opening. In one free group with retained ordinary end
links, suppose exactly \(P_s,P_t\), \(s<t\), are missing, and exactly
one block \(B_j\) in the corridor \(B_{s+1},\ldots,B_t\) is vacant.
All other blocks of that corridor are short; vacancies elsewhere
and their noncrossing matching are unrestricted.

Compress the maximal short run before \(B_j\), if nonempty, to one
short block, and do the same after \(B_j\). Note 312 preserves the
Barnette class, the marked opening, and the free group's \(S,K,X\)
existence. The resulting corridor has at most three blocks, with
one vacant block \(V\) and at most one short neighbor on either side.

For a short neighbor on the left, the matching edge at its left
ordinary port has the form \(x o_L\), where \(o_L\) is that short
block's \(o\)-slot. Its right link \(e_Lo_V\) is retained. *Left
unbuffering* deletes the short block and its face chord, replaces
\(x o_L\) by \(x o_V\), and joins the preceding old-cycle block
directly to \(a_V\). This is a valid simple cubic bipartite plane
graph with the shortened old Hamilton cycle unless \(x=H_V\):
then \(x o_V=H_Vo_V\) would be an old-cycle edge. For a right short
neighbor, define reflected unbuffering. Its only analogous alias is
the proposed matching edge \(I_Ve_V\).

The reduced atom order is \(P_s<V<P_t\) with no intervening atom.
Note 278's rainbow rule therefore makes the left alias occur exactly
when \(V\) belongs to the \(P_s\) component, and the right alias
exactly when \(V\) belongs to the \(P_t\) component. Note 278 also
separates the two port components. Hence at most one alias can occur;
if \(V\) belongs to a vacancy-only component, neither occurs.

**Port-free vacancy theorem.** If \(V\) belongs to a vacancy-only
component, the original free group has vertex-spanning \(S,K,X\)
states. Under the usual routes in the other free groups, the parent
has a Hamilton cycle through both site edges and its legal
site-expanded child is Hamiltonian. More generally, any one-vacancy
corridor in this class whose available unbufferings avoid the
old-cycle aliases has the same conclusion. Consequently a free group
in this class lacking one of \(S,K,X\) must have its central vacancy
in one of the two port components.

**Proof.** In a short block every internal edge is an edge of its
four-cycle and all four vertices have exactly one outside incidence.
Its two old-cycle incidences and the two matching incidences are
exactly the four attachments of Note 313's square buffer. The
retained link next to \(V\) is the bridge incidence of that buffer.
Note 276 excludes any nonstandard ordinary-to-ordinary matching
edge, so \(x\) is a vacancy slot of type \(H\). The only possible
edge duplication in the left reattachment is \(o_VH_V\), the old
cycle edge at \(V\). The right statement is its reflection.

In the opposite-side disk, there is no surviving matching endpoint
between \(o_L\) and \(o_V\): the intervening \(e_L\) is deleted, and
the face-chord endpoints lie on the other side. Moving the endpoint
of \(x o_L\) to \(o_V\) therefore preserves noncrossing. The new
old-cycle edge replaces a path through four deleted vertices, and
the central block and all other face chords keep their order.
Thus, without the alias, the shortened graph is simple, cubic,
bipartite, plane, and Hamiltonian with the same type of site
opening. The reflected argument handles the right side.

The graph before each unbuffering is Barnette. Note 313's strengthened
reverse-cut argument excludes every possible new two-edge cut:
a cut through \(a_Vo_V\) extending past \(b_V\) crosses the face
chord \(a_Vb_V\), whereas a shorter cut traps a nonempty subset of
\(o_V,H_V,I_V,e_V\) and crosses one of its exterior matching edges.
The reflected argument applies at \(e_Vb_V\). Thus every alias-free
unbuffering preserves the Barnette class. After at most two such
steps, the two missing links are consecutive and share the vacant
block \(V\). Note 300 gives all three states. Reinsert the removed
short blocks in reverse order. Note 313's six-port theorem lifts
each spanning route without changing its exterior endpoint pairing,
and Note 312 reverses the initial short-run compressions with exact
four-port signatures. The resulting states span the original free
group. Notes 273, 001, and 182 give the marked parent and legal
child conclusions. The atom-order observation above shows that a
port-free \(V\) makes both available unbufferings alias-free.
Taking the contrapositive proves the final assertion. \(\square\)

An alias blocks this reduction only; it does not prove the absence
of an \(X\) state or a Hamilton cycle. The remaining two ownership
cases have \(V\) in the left or right port component and require
direct routes that keep the adjacent old-cycle edge out of the
complementary matching.
