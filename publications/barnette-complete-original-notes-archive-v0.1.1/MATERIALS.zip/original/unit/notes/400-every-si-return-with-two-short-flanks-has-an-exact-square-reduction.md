> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every \(si\) return with two short flanks has an exact square reduction

[Note 399](399-the-si-ej-return-is-an-exact-square-reduction-at-every-length.md)
reduces the \(si,eJ\) branch and shows that an unreduced \(si\)
matching must contain \(ep_1,q_uJ\). The latter branch has only
one viable tail state. Its two-cutpoint core is again exactly
square-equivalent. Thus the full \(si\) return is reduced at
every positive corridor length.

Use the selected compact all-square opening and the block order
\[
 S_0=(c,p,q,d),\quad V=(a,o,h,i,e,b),\quad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\quad
 D=(A,O,H,I,K,J,E,B),\quad T=(C,r,s,F),\qquad m\ge1.
\tag{1}
\]
Let \(M\) be the complementary matching and assume
\(tp,qo,hz,si\in M\). Cross-block free chords lie
opposite the selected common face and cannot interlace.
Every proper complete-block interval closed under \(M\)
is excluded by three-connectivity, since it would have
only its two boundary old-cycle edges leaving it.

For \(1\le u<r<m\), put
\[
\begin{split}
 R_{m;u,r}=\{&si,ep_1,q_uJ,p_{u+1}K,q_rI,
                   p_{r+1}H,q_mO,Er\}\\
 &{}\cup\{q_jp_{j+1}:1\le j<m,\ j\notin\{u,r\}\}.
\end{split}                                                   \tag{2}
\]
The subscript \(r\) is a corridor cutpoint; the unsubscripted
\(r\) in \(Er\) is the vertex of the right short block.

**Complete \(si\)-return theorem.** Under (1), every actual
matching with \(tp,qo,hz,si\) contains an induced disk
four-pole with precisely the square's four spanning
one-path and two spanning two-path Hamilton states.
The labeled square replacement is strict, preserves
Barnette membership in both directions, and preserves
every exterior- and attachment-marked Hamilton decision.
More precisely, Note 399 reduces the \(eJ\) branch;
an \(HJ\) return forces the rainbow reduction of
[Note 325](325-even-rainbow-multivacancy-blocks-are-exact-square-reductions.md);
and every remaining actual matching is exactly
\(R_{m;u,r}\) for a unique \(1\le u<r<m\), besides
the boundary edges \(tp,qo,hz\). Consequently no
vertex-minimal non-Hamiltonian Barnette graph contains
this \(si\) return.

**The tail cannot bypass \(Er\).** The boundary consequence
of Note 399 leaves \(ep_1,q_uJ\) in an unreduced case.
The opposite-side chord \(q_uJ\) encloses
\[
 (p_j,q_j)_{j=u+1}^m,O,H,I,K,                             \tag{3}
\]
an even number \(2(m-u)+4\) of free slots. If \(E\)
met \(O\) or \(I\) on the common-face side, exactly one
slot in (3) would exit that chord. No second face-side
exit is possible: \(J\) is matched to \(q_u\), \(OE\)
and \(IE\) share \(E\), while \(OK\) cannot coexist
with \(IE\) by the isolation lemma of
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
and shares \(O\) with \(OE\). This contradicts parity.
Thus \(E\) meets either \(r\) or a short-block odd slot
\(p_v\). In the latter case \(v\le u\), since a later
\(p_vE\) would interlace \(q_uJ\). The odd slot \(r\)
then cannot meet a slot inside \(q_uJ\) without crossing
it, and its only available mate is some earlier even
short slot \(q_w\). Noninterlacement of \(p_vE,q_wr\)
requires \(w<v\). Now the proper complete interval
\(S_{w+1},\ldots,S_m,D\) is matching-closed: its
free chords all stay within the interval, whereas
\(q_wr\) lies outside and \(q_uJ,p_vE\) stay inside.
This is a forbidden two-edge cut. Hence \(Er\in M\).

The internal free chords \(OE,IE,HJ\) of \(D\) are now
unavailable. Were \(OK\) present, the isolation lemma
would put it on the common-face side. The even slot
\(H\) would have to meet some \(p_s\) inside
\(q_uJ\). Its opposite-side chord \(p_sH\) encloses
the even slot set \(q_s,p_{s+1},q_{s+1},\ldots,q_m,O\),
with exactly one face-side exit \(O\) through \(OK\).
Parity excludes this. Thus \(D\) has no internal free
matching chord.

Inside \(q_uJ\), the four slots \(K,I,H,O\) must
therefore meet short-block slots. Write their mates
as \(p_v,q_r,p_s,q_t\), respectively. Opposite-side
noninterlacement gives \(u<v\le r<s\le t\).
If \(v>u+1\), the proper complete interval
\(S_{u+1},\ldots,S_{v-1}\) is matching-closed;
thus \(v=u+1\). If \(t<m\), the suffix
\(S_{t+1},\ldots,S_m\) is matching-closed;
thus \(t=m\). If \(s>r+1\), the run
\(S_{r+1},\ldots,S_{s-1}\) is matching-closed;
thus \(s=r+1\). The short slots between these
cutpoints pair by the ordinary links
\(q_jp_{j+1}\): skipping any such link would
match-close the intervening complete short-block
run. This is precisely (2). In particular \(m\ge3\),
and the mates of \(J,I\) determine \((u,r)\) uniquely.

**Six-state core.** The three ordinary-link subladders
\(S_1,\ldots,S_u\), \(S_{u+1},\ldots,S_r\), and
\(S_{r+1},\ldots,S_m\) have respective four
attachment lists
\[
\begin{split}
 &(bc_1,ep_1,q_uJ,d_uc_{u+1}),\\
 &(d_uc_{u+1},p_{u+1}K,q_rI,d_rc_{r+1}),\\
 &(d_rc_{r+1},p_{r+1}H,q_mO,d_mA).
\end{split}                                                   \tag{4}
\]
Compress each to one square by
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
The resulting 30-vertex core has \(m=3,u=1,r=2\)
and matching
\(si,ep_1,q_1J,p_2K,q_2I,p_3H,q_3O,Er\).
Its four spanning one-path states are
\[
\begin{array}{c|l}
aF&
 a,o,h,i,e,b,c_1,p_1,q_1,d_1,c_2,p_2,q_2,d_2,
 c_3,p_3,q_3,d_3,A,O,H,I,K,J,E,B,C,r,s,F\\
oh&
 o,a,b,e,p_1,c_1,d_1,q_1,J,K,p_2,c_2,d_2,q_2,
 I,H,p_3,c_3,d_3,q_3,O,A,B,E,r,C,F,s,i,h\\
ao&
 a,b,e,p_1,c_1,d_1,q_1,J,K,p_2,c_2,d_2,q_2,
 I,H,p_3,c_3,d_3,q_3,O,A,B,E,r,C,F,s,i,h,o\\
hF&
 h,o,a,b,c_1,p_1,e,i,s,r,E,J,q_1,d_1,c_2,p_2,
 K,I,q_2,d_2,c_3,p_3,H,O,q_3,d_3,A,B,C,F .
\end{array}                                                   \tag{5}
\]
The two spanning two-path states are
\[
\begin{array}{c|l}
\{ao,hF\}&
 (a,o),\quad
 (h,i,s,r,E,J,q_1,p_1,e,b,c_1,d_1,c_2,p_2,
 K,I,q_2,d_2,c_3,p_3,H,O,q_3,d_3,A,B,C,F)\\
\{aF,oh\}&
 (o,h),\quad
 (a,b,c_1,p_1,e,i,s,r,E,J,q_1,d_1,c_2,p_2,
 K,I,q_2,d_2,c_3,p_3,H,O,q_3,d_3,A,B,C,F).
\end{array}                                                   \tag{6}
\]
Every row visits the 30 vertices once, and every
consecutive pair is an old-cycle edge, a block-closing
face chord, or an edge of (2). The terminal colours
are \(a,h\) versus \(o,F\), excluding other one-path
pairs. The third two-path pairing \(\{ah,oF\}\)
interlaces the disk order \((a,o,h,F)\) and is
impossible. Equations (5)--(6) therefore give the
complete square signature; Note 178 lifts it at
all corridor lengths.

**Barnette-class comparison.** Cap the 30-vertex
core by a fresh square \((x_a,x_o,x_h,x_F)\),
attaching its corners to \(a,o,h,F\), respectively.
The full old-cycle path through the core, followed
by \(x_F,x_h,x_o,x_a,a\), is a Hamilton cycle of
the 34-vertex cap. Its complementary matching
has the disjoint common-face chords
\[
 ab,c_1d_1,c_2d_2,c_3d_3,AB,CF,x_ax_F
\]
and the nested or disjoint opposite-page chords
\[
 si,ep_1,q_1J,p_2K,q_2I,p_3H,q_3O,Er,ox_o,hx_h.
\tag{7}
\]
All join opposite Hamilton-cycle parities, so the cap
is simple, cubic, bipartite and plane. The following
is a connected spanning tree of its matching-chord
interlacement graph; each dash means alternating
endpoints in that Hamilton order:
\[
\begin{gathered}
 x_ax_F-ox_o-ab-si-CF,\\
 ab-ep_1-c_1d_1-q_1J-AB,\\
 AB-p_2K-c_2d_2-q_2I,\\
 AB-p_3H-c_3d_3-q_3O,\qquad AB-Er,\qquad ab-hx_h.
\end{gathered}                                                  \tag{8}
\]
A two-edge cut would bound a proper old-cycle
interval closed under the complementary matching,
disconnecting this tree. The Hamilton cycle excludes
bridges; in a cubic graph three-edge-connectivity
implies three-vertex-connectivity. Hence the cap is
Barnette.

Deleting any one uncapped core vertex leaves it
connected. Each of its six block cycles remains
connected after one deletion. The \(V\)--\(S_1\)
joins \(bc_1,ep_1\), \(S_2\)--\(D\) joins
\(p_2K,q_2I\), \(S_3\)--\(D\) joins
\(d_3A,p_3H,q_3O\), and \(D\)--\(T\) joins
\(BC,Er\) each retain an edge after any one
deletion. Also the \(S_1\)--\(S_2\) and
\(S_1\)--\(D\) joins \(d_1c_2,q_1J\) have
distinct endpoints, so at least one remains.
These joins connect all surviving blocks.
After deletion of any two core vertices, every
remaining component meets a surviving terminal;
otherwise it would be disconnected from the rest
of the three-connected cap after the same deletions.
The square satisfies the same one- and two-deletion
properties. The four-attachment comparison of
[Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md)
gives three-connectivity in both replacement
directions. Terminal colours, disk order, and the
six linkage states preserve bipartiteness, planarity,
and all exterior Hamilton marks. Note 178 reversibly
restores the three ladders. The pole has
\(18+4m>4\) vertices, so the reduction is strict.
\(\square\)

This completes the \(si\) return within the specified
two-flank opening. Combining Notes 396, 398, and this
theorem, an unreduced \(hz\) return in this opening
must have \(sp_j\in M\) for some \(j<m\).
Those earlier \(sp_j\) returns,
the \(zK\) complete six-state question, other
openings, and Barnette's conjecture remain open.
The proof is project-internal and has not had an
independent review or an external priority check.
