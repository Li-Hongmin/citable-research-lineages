> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two odd-ladder poles compose to one odd-ladder signature

[Note 326](326-odd-ladders-have-the-single-vacancy-four-pole-signature.md) identifies the exact four-terminal Hamilton signature of the three-column ladder \(L_3=P_3\square K_2\). A different twelve-vertex four-pole, made by joining two copies of \(L_3\) along two edges, has the same signature and can replace one copy in a Barnette graph. This is useful when an old-cycle edge and a face-side matching chord join two consecutive leaf modules in the containment forest of [Note 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md).

For each \(i\in\{A,B\}\), take a copy \(T_i\) of \(L_3\) with four corner terminals \(L_i,X_i,Y_i,R_i\) in this cyclic order. Equivalently, its six vertices occur on a spanning perimeter path as
\[
 L_i,h_i,X_i,Y_i,j_i,R_i,
\]
with additional chords \(L_iR_i,h_ij_i\). Form the pole \(P\) from \(T_A,T_B\) by adding the two edges
\[
                         R_AL_B,\qquad Y_AX_B.            \tag{1}
\]
Its four exterior terminals are \(L_A,X_A,Y_B,R_B\), in that cyclic order in the plane embedding where \(R_AL_B\) lies on the old-cycle boundary and \(Y_AX_B\) lies on its face side. Every other vertex has degree three inside \(P\); each exterior terminal has degree two inside and one attachment edge outside.

For this embedding, place the two perimeter paths consecutively along the old-cycle arc, draw each module's chords \(L_iR_i,h_ij_i\) on the opposite side, and draw \(Y_AX_B\) on the face side. One outer boundary cycle of the resulting pole is
\[
 L_A,h_A,X_A,Y_A,X_B,Y_B,j_B,R_B,L_B,R_A,L_A.
\]
Thus the four exterior terminals occur on the disk boundary in the stated order. The same four boundary sectors occur in the corresponding disk embedding of \(L_3\), so the replacement preserves which exterior attachment edges border a common face.

**Serial odd-pole theorem.** The spanning one-path terminal pairs of \(P\) are precisely
\[
 (L_A,Y_B),\ (L_A,R_B),\ (X_A,Y_B),\ (X_A,R_B).       \tag{2}
\]
Its spanning two-path terminal pairings are precisely
\[
 \{(L_A,R_B),(X_A,Y_B)\},\qquad
 \{(L_A,X_A),(Y_B,R_B)\}.                              \tag{3}
\]
Under the terminal correspondence
\[
 (L_A,X_A,Y_B,R_B)\longleftrightarrow(L,X,Y,R),
\]
this is exactly the signature of \(L_3\). If an induced copy of \(P\) has exactly one exterior edge at each terminal in a simple cubic graph, replacing it by \(L_3\) preserves every exterior and attachment-edge Hamilton mark and Hamiltonicity in both directions. In the plane embedding with the stated attachment order, the replacement also preserves bipartiteness, planarity and three-connectivity in both directions; hence it preserves membership in the Barnette class.

**Hamilton signature proof.** In \(L_3\), \(L,X\) have one bipartite colour and \(Y,R\) the other. All four cross-colour spanning terminal paths exist, and the two noncrossing spanning two-path pairings are
\[
 \pi_1=\{(L,R),(X,Y)\},\qquad
 \pi_2=\{(L,X),(Y,R)\},                                  \tag{4}
\]
by Note 326. The joining edges in (1) are vertex-disjoint. For any desired pair in (2), take a spanning path in \(T_A\) from the chosen left exterior terminal to \(R_A\), a spanning path in \(T_B\) from \(L_B\) to the chosen right exterior terminal, and join them through \(R_AL_B\). This realizes all four pairs. The external terminals of \(P\) have colour pattern \(0,0,1,1\), so no other one-path pair is possible.

For the first pairing in (3), use \(\pi_1\) in both modules and both joining edges. The two resulting paths run from \(L_A\) to \(R_B\) and from \(X_A\) to \(Y_B\). For the second, use \(\pi_1\) in \(T_A\), \(\pi_2\) in \(T_B\), and both joining edges. The path \(L_A R_A L_B X_B Y_A X_A\), with each module pair interpreted as its spanning internal route, joins \(L_A\) to \(X_A\); the other path joins \(Y_B\) to \(R_B\). Both routes cover every vertex once. The remaining pairing \(\{(L_A,Y_B),(X_A,R_B)\}\) interlaces in the disk and is impossible for disjoint paths. This proves (2)--(3). As in Note 178, a Hamilton cycle meets a four-edge patch boundary in two or four edges; replacing its spanning one-path or two-path routing by the same terminal routing in the other pole retains the exterior and its connectivity. \(\square\)

**Barnette preservation proof.** The terminal colour pattern \(0,0,1,1\) is the same for \(P\) and \(L_3\), so an exterior bipartition extends across one exactly when it extends across the other. Both poles embed in a disk with terminal order \(L,X,Y,R\); replacing one disk by the other preserves the embedding of every exterior edge and face. Cubicity and simplicity follow from the four distinct terminal attachments.

For three-connectivity, note first that \(L_3\) remains connected after deleting at most one vertex. After deleting any two vertices, each surviving component contains a surviving terminal: each of its two internal vertices has three internally disjoint paths to three different corners. The pole \(P\) has the same two deletion properties. With one deletion, both module remnants remain connected and at least one of the two vertex-disjoint joining edges in (1) survives. With two deletions in one module, every remnant component of that module reaches a surviving module terminal; an exterior terminal reaches the outside directly, and a joining terminal reaches the intact other module and then one of its exterior terminals. With one deletion in each module, each module remnant is connected. If a joining edge survives, the whole remnant reaches a surviving exterior terminal. If neither survives, each module still has at least one of its two exterior terminals. Thus every component of \(P\) after at most two deletions reaches a surviving exterior terminal.

If either ambient cubic graph is three-connected, its exterior after deleting the pole is connected: two exterior components would each require at least three of the four attachment edges by three-edge-connectivity. Compare deletion of at most two ambient vertices before and after replacement. With at most one pole vertex deleted, the remaining pole is connected; delete the corresponding corner in the other pole if the deleted vertex is a terminal, and no pole vertex there if it is internal. Three-connectivity of the original ambient graph ensures that every remaining exterior component has a surviving attachment. With two pole vertices deleted, no exterior vertex is deleted, the exterior is connected, and every remaining pole component reaches it through a terminal. The comparison is symmetric. Hence three-connectivity is preserved in both directions. \(\square\)


**Serial-chain corollary.** For \(k\ge1\), take \(k\) labeled copies \(T_1,\ldots,T_k\) of \(L_3\) and join each consecutive pair by \(R_iL_{i+1}\) and \(Y_iX_{i+1}\), all in the same plane orientation. The resulting four-pole has exterior terminals \(L_1,X_1,Y_k,R_k\) and exactly the \(L_3\) signature. Repeatedly replace the first two modules by one \(L_3\); the terminal labels of the replacement are \(L_1,X_1,Y_2,R_2\), so the next pair has the same form. The Barnette and marked-Hamilton equivalence follows at every step. In the old-cycle/face-chord realization, the chain reduces by \(6(k-1)\) vertices and \(k-1\) face-side chords while retaining the two outer matching attachments and the old-cycle path through the pole. \(\square\)

**Single-trap consequence.** In the setting of [Note 411](411-one-trapped-segment-with-few-face-chords-has-a-hamiltonian-expansion.md), suppose the main segment contains such a chain of \(k\ge2\) leaf modules, disjoint from the trapped segment, and that all its \(k-1\) joining matching edges lie on the common-face side. Compress the chain before applying Note 410. The selected trapped length \(\ell\), escape count \(e\), legal site and six-witness interface survive, while the face-side main-chord count becomes \(f-k+1\). Consequently
\[
 \ell+e+12(f-k+1)\le78\quad\Longrightarrow\quad G^+\text{ is Hamiltonian},
\]
and the same inequality with \(54\) in place of \(78\) guarantees all six parent site witnesses. In particular, for one trapped hexagon and \(f=6\), a single two-module pole anywhere in the main segment forces the child to be Hamiltonian, because \(\ell=6\), \(e\le4\), and \(6+4+12(6-1)=70\le78\). This conclusion does not require first reducing the ordinary-chord forest. \(\square\)

The later six-face-chord theorem of [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md) strengthens the last application: for one trapped hexagon, a chain of \(k\) modules makes the child Hamiltonian whenever \(f-k+1\le6\). In particular, one two-module pole excludes a non-Hamiltonian child at \(f=7\), irrespective of the reduced child order.

**Consecutive-leaf consequence.** Suppose two consecutive ordinary-chord leaves in Note 410 each have exactly one plain-unary ancestor and exactly two special positions. If their two six-vertex intervals are consecutive in the *full* old-cycle order, and a face-side matching chord joins the right special position of the first leaf to the left special position of the second, their union induces the pole \(P\): the old-cycle edge between the intervals is \(R_AL_B\), and the face chord is \(Y_AX_B\). Compression to \(L_3\) removes six vertices and one face-side main chord while preserving the old Hamilton cycle and the exterior attachments. If a legal site uses a surviving corner, its site edge is an exterior attachment; compression and site expansion commute. The gadget-edge incidence patterns, hence the six parent site-witness existence clauses, remain unchanged. In particular, if the selected trapped segment is outside this patch, its length \(\ell\) and escape count \(e\) remain unchanged, while \(f\) decreases by one.

Explicitly, the old cycle traverses the pole along \(L_A,h_A,X_A,Y_A,j_A,R_A,L_B,h_B,X_B,Y_B,j_B,R_B\). After replacement it traverses \(L,h,X,Y,j,R\). If a site edge is an attachment at \(X_A\) or \(Y_B\), expanding it changes only the endpoint outside the pole to a gadget vertex. The pole in the expanded child is therefore still a four-pole with the same labeled attachment, while every other gadget edge lies in the exterior. Applying the Hamilton signature in that child keeps each complete gadget-edge pattern, which distinguishes the six witness clauses of Notes 001 and 013.

At \(f=6\), the single-trap consequence already proves Hamiltonicity whenever this pole occurs. [Note 413](413-a-seven-leaf-barnette-kernel-can-avoid-the-serial-odd-pole.md) constructs a Hamiltonian legal child whose Barnette parent has the extremal seven-leaf kernel but no such pole, so the pole is not forced by the kernel shape alone. [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md) proves the full \(f=6\) single-hexagon case by analyzing escape targets. The serial-pole theorem remains an exact four-terminal reduction for other parameters; none of these results settles the general Barnette conjecture.
