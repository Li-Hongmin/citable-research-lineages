> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every one-sided right return of the J3,J1,J1 triple has a square signature

[Note 373](373-the-first-right-return-of-a-j3-j1-j1-triple-has-the-exact-square-signature.md)
settles the first right-only return of the
\(J_3,J_1,J_1\) triple. The remaining deeper
right-only returns also have exact square signatures.

Use Note 344's three double blocks and required
\(q\ge1\) internal short-block corridor. Let
\(p\ge2\) right short blocks
\(T_t=(\bar c_t,\bar r_t,\bar s_t,\bar d_t)\)
follow \(D_3\), with no left short flank.
Reverse the abstract four-slot word in
[Note 344](344-every-three-double-j1-j3-free-group-has-a-spanning-route.md),
equation (7). Its remaining right-only matching
types have a unique split index \(1\le m<p\):
\[
Lo_1,\quad e_3\bar r_1,\quad
\bar s_t\bar r_{t+1}\ (1\le t<m),\quad
j_3\bar s_m,\quad h_1\bar r_{m+1},\quad
\bar s_t\bar r_{t+1}\ (m+1\le t<p),\quad
\bar s_pR.                                             \tag{1}
\]
Here \(L,R\) are the ordinary endports outside
the patch. Let \(H_{p,m,q}\) be the induced interval
from \(D_1\) through \(T_p\). Its degree-two
terminals, in cyclic disk order, are
\((a_1,o_1,\bar s_p,\bar d_p)\).

**All-right-return theorem.** For all
\(p\ge2\), \(1\le m<p\), \(q\ge1\), the patch
\(H_{p,m,q}\) has exactly the square's four
spanning one-path and two spanning two-path
terminal states. Replacing it by the labeled
square, or reversing the replacement, preserves
Barnette membership and every exterior- and
attachment-marked Hamilton decision.
It has \(24+4(p+q)\) vertices. Together with
Note 373, this covers every right-only matching
type in Note 344, without conditions on other
vacancies.

**Three ladder reductions.** The prefix
\(T_1,\ldots,T_m\) is an induced \(L_{2m}\),
with attachments at \(\bar c_1,\bar r_1,\bar d_m,
\bar s_m\): the old edge from \(b_3\),
\(e_3\bar r_1\), the old edge to
\(\bar c_{m+1}\), and \(j_3\bar s_m\).
The suffix \(T_{m+1},\ldots,T_p\) is a disjoint
\(L_{2(p-m)}\), with attachments at
\(\bar c_{m+1},\bar r_{m+1},\bar d_p,\bar s_p\):
the preceding old edge, \(h_1\bar r_{m+1}\),
the exterior old edge, and the exterior
matching edge. Note 370's internal corridor
is a third disjoint \(L_{2q}\).
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
reduces all three to single short squares,
preserving the Barnette class, terminal usage,
and the selected old cycle and common-face arc.
It remains to prove the claim at
\((p,m,q)=(2,1,1)\).

**The 36-vertex atom.** Write its right squares as
\[
T_1=(C,R_0,S,D),\qquad T_2=(A,U,V,B),                 \tag{2}
\]
where \(R_0\) is a vertex, not the external endport.
Its matching edges outside Note 344 (2) are
\(e_3R_0,j_3S,h_1U\); the face chords are
\(CD,AB\). The terminals are \((a_1,o_1,V,B)\).

Let \(X_{aD}\), \(X_{hD}\), and \(X^\circ_{aD}\),
\(X^\circ_{hD}\) denote, respectively, the
\(a_1\)--\(D\) full old-cycle path, the
\(h_1\)--\(D\) spanning path of Note 373 (4),
the \(a_1\)--\(D\) path of Note 373 (6)
omitting \(o_1,h_1\), and the
\(h_1\)--\(D\) path of Note 373 (5)
omitting \(a_1,o_1\). These are paths in
the 32-vertex first-right-return patch;
their complete vertex sequences are displayed
in Note 373.

The \(a_1\)--\(B\) path is the full old-cycle
path through both right squares. An
\(o_1\)--\(V\) spanning path concatenates
Note 344 (5)'s two disjoint core paths and
the two square routes as follows, identifying
shared endpoints:
\[
o_1\xrightarrow{A_q}e_3,\ R_0,C,D,S,\
j_3\xrightarrow{B_q}h_1,\ U,A,B,V.                 \tag{3}
\]
The other two spanning single paths are
\[
\begin{split}
a_1\to o_1:\quad&
X^\circ_{aD},A,B,V,U,h_1,o_1,\\
V\to B:\quad&
V,U,X_{hD},A,B .
\end{split}                                             \tag{4}
\]
In the first, \(D A\), \(AB\), \(BV\),
\(VU\), \(Uh_1\), and \(h_1o_1\) are the
new joins. In the second, \(VU\), \(Uh_1\),
\(DA\), and \(AB\) are the new joins.
Each route spans the atom exactly once.

For \(\{a_1o_1,VB\}\), use the edge
\(a_1o_1\) and
\[
                  V,U,X^\circ_{hD},A,B.             \tag{5}
\]
For \(\{a_1B,o_1V\}\), use
\[
(o_1,h_1,U,V)
\quad\hbox{and}\quad
X^\circ_{aD},A,B .                                   \tag{6}
\]
These are disjoint spanning path pairs. Terminal
colours are \(a_1,V\) versus \(o_1,B\),
excluding the other two one-path pairs, while
the remaining two-path pairing crosses the disk.
Equations (3)--(6) therefore give the complete
square signature.

**A 40-vertex Barnette cap.** Cap the four
terminals by the square \((t_B,t_V,t_O,t_A)\),
attaching \(Bt_B,Vt_V,o_1t_O,a_1t_A\).
The full old-cycle path from \(a_1\) to \(B\),
followed by \(t_B,t_V,t_O,t_A,a_1\), is a
Hamilton cycle. Its complementary matching has
one-page chords
\[
a_sb_s\ (s=1,2,3),\ i_1e_1,\ o_2k_2,\ o_3k_3,\
c_1d_1,\ CD,\ AB,\ t_Bt_A,
\tag{7}
\]
and opposite-page chords
\[
j_1h_2,\ k_1i_3,\ i_2h_3,\ j_2s_1,\ e_2r_1,\
e_3R_0,\ j_3S,\ h_1U,\ o_1t_O,\ Vt_V .
\tag{8}
\]
The chords on each page are disjoint or nested,
and each joins opposite old-cycle parities.
The following endpoint alternations span their
interlacement graph:
\[
\begin{gathered}
t_Bt_A-o_1t_O-a_1b_1-j_1h_2-a_2b_2-i_2h_3
-a_3b_3-j_3S-CD-e_3R_0,\\
a_1b_1-h_1U-AB-Vt_V,\qquad
j_1h_2-i_1e_1,\qquad
a_1b_1-k_1i_3-o_3k_3,\qquad
j_1h_2-o_2k_2,\\
a_2b_2-j_2s_1-c_1d_1-e_2r_1 .
\end{gathered}                                         \tag{9}
\]
The old Hamilton cycle excludes bridges;
connected interlacement excludes two-edge cuts,
which proves three-connectivity in the cubic cap.
Thus the cap is Barnette. Note 178's three
ladder expansions give a Barnette cap for
every \(H_{p,m,q}\).

The atom minus any one vertex is connected:
its old-cycle path has every internal position
bridged by one of \(a_1b_1,h_1U,AB\) not
incident with that vertex. This property survives
ladder expansion by the one-vertex attachment
argument of Note 372. After deleting two patch
vertices, every surviving component meets a
surviving terminal, or else the corresponding
Barnette cap would disconnect. The square has
both properties. Note 370's four-attachment
comparison now proves the Barnette-class
replacement in both directions. The exact
signature yields the stated exterior Hamilton
equivalence. \(\square\)

In the specified opening the replacement square
is one short target-free block, with old-cycle
segment \((a_1,o_1,\bar s_p,\bar d_p)\) and
common-face chord \(a_1\bar d_p\).
Simultaneous left and right short flanks are
not asserted here; Note 344 supplies their
spanning routes. The general Barnette conjecture
remains unresolved. This is a project-internal
analytic proof without independent review.
