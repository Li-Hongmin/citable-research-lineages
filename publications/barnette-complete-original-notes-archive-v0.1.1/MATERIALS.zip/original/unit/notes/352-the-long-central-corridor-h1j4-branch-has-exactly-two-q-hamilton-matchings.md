> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The long central-corridor h1j4 branch has exactly 2q Hamilton matchings

[Note 349](349-every-no-flank-central-one-short-alternating-four-double-group-has-a-spanning-route.md)
classifies the \(h_1j_4\) branch when the central corridor
has one short block. [Note 351](351-a-delayed-central-corridor-return-has-a-forced-hamilton-route.md)
settles every \(h_1r_t\) branch for an arbitrary corridor.
The \(h_1j_4\) branch has a similarly exact classification,
with one cut position and two nonlocal double-block wirings.

Work in the compressed, gapless, tight-target all-square
opening of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
An ordinary target-free free group with even left endport
\(L\) and odd right endport \(R\) consists exactly of
\[
D_1,D_2,S_1,\ldots,S_q,D_3,D_4,\qquad q\ge1,              \tag{1}
\]
without outer short flanks. Use the block notation of
[Note 350](350-an-arbitrary-central-corridor-gives-a-square-equivalent-four-double-core.md)
and the internal common-face complementary chords
\[
                 i_1e_1,\quad o_2k_2,\quad i_3e_3,\quad o_4k_4 .
                                                                  \tag{2}
\]
All other free chords are on the opposite page by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md);
the chord-isolation lemma of
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
excludes additional same-block free chords.

For \(0\le p<q\), let
\[
\begin{split}
C_{q,0}={}&
\{e_2r_1,\ s_ur_{u+1}\ (1\le u<q),\
  s_qo_3,\ j_2h_3\},\\
C_{q,p}={}&
\{e_2r_1,\ s_ur_{u+1}\ (1\le u<q,\ u\ne p),\
  s_qo_3,\ j_2s_p,\ r_{p+1}h_3\}
  \quad(1\le p<q).
\end{split}                                                \tag{3}
\]
Define two outer wirings
\[
\begin{split}
A&=\{h_1j_4,k_1i_2,j_1h_2,k_3i_4,j_3h_4\},\\
B&=\{h_1j_4,k_1i_4,j_1h_2,i_2k_3,j_3h_4\}.
\end{split}                                                \tag{4}
\]

**Exact \(h_1j_4\)-branch theorem.** If the complementary
matching of (1)--(2) contains \(h_1j_4\), its
remaining free chords are exactly
\[
                \{Lo_1,e_4R\}\ \cup\ A\ \cup\ C_{q,p}
\quad\hbox{or}\quad
                \{Lo_1,e_4R\}\ \cup\ B\ \cup\ C_{q,p}
                                                                  \tag{5}
\]
for one \(p\in\{0,\ldots,q-1\}\).
Every one of these \(2q\) words occurs in a
\((44+4q)\)-vertex three-connected cubic bipartite
plane parent with a Hamilton cycle through both
edges of a legal facial \(C_4\)-expansion site;
its \((48+4q)\)-vertex legal child is Hamiltonian.
Every actual group in this branch has a
vertex-spanning \(L\)--\(R\) route. If all
vacancies outside it occupy distinct internal
blocks, its parent and legal child have the same
marked Hamilton conclusion.

**Exhaustion.** Outside \(h_1j_4\), the only
unmatched slots are \(L,o_1,e_4,R\). Their
alternative pairing \(LR,o_1e_4\) would close
the entire complete-block group under the matching,
creating a two-edge cut. Hence \(Lo_1,e_4R\).

Inside \(h_1j_4\), the even slot \(k_1\)
can meet only \(i_2,j_3,i_4\). The choice
\(k_1j_3\) traps the old pair \(h_4i_4\).
If \(k_1i_2\), its two inner slots force
\(j_1h_2\), giving the left half of \(A\).
If \(k_1i_4\), the odd slot \(j_1\) can
meet only \(h_2,k_3,h_4\). The choice
\(j_1k_3\) leaves \(h_2\) without an inner
mate: \(h_2i_2\) is an old edge, \(h_2j_2\)
is a forbidden same-block chord, and
\(h_2r_v,h_2o_3\) enclose odd numbers
of free slots. The choice \(j_1h_4\)
forces \(h_2j_3,i_2k_3\);
all free matching chords of the proper
complete-block interval
\(D_2,S_1,\ldots,S_q,D_3\) then stay
inside it, another forbidden two-edge cut.
Thus \(j_1h_2\).

Inside \(k_1i_4\), the only possible
mates of \(i_2\) are \(k_3,h_4\).
If \(i_2h_4\), the even slot \(k_3\)
has no mate inside that chord:
\(k_3j_2\) and every \(k_3r_v\)
enclose odd numbers of remaining free slots,
\(k_3o_3\) is excluded by (2), and
\(k_3j_3\) is an old edge.
Hence \(i_2k_3\), giving the left
half of \(B\).
In either wiring, \(j_3h_4\) is then
forced in the right tail. The unpaired
interior slots reduce to
\[
              j_2,e_2,r_1,s_1,\ldots,r_q,s_q,o_3,h_3.
                                                                  \tag{6}
\]
The only possible mates of \(j_2\) are
\(h_3,s_1,\ldots,s_q\).

If \(j_2h_3\), the interior of this chord
forces \(s_qo_3\): an earlier \(s_v\)
would close the short-block suffix.
The even slot \(e_2\) must meet \(r_1\);
\(e_2o_3\) would close all \(q\) short
blocks, while \(e_2r_v\) with \(v>1\)
would close their proper prefix.
Every remaining link is \(s_ur_{u+1}\),
since a first skipped complete short-block
interval would be matching-closed.
This is \(C_{q,0}\).

If \(j_2s_p\), the same prefix argument
forces \(e_2r_1\) and
\(s_ur_{u+1}\) for \(1\le u<p\).
The choice \(p=q\) leaves only
\(o_3,h_3\) unmatched after the two
outer wirings are fixed, but \(o_3h_3\)
is an old-cycle edge.
Thus \(p<q\). The first remaining
odd slot \(r_{p+1}\) can only meet
\(h_3\). Its neighbour \(s_{p+1}\)
is an old edge; a later \(s_v\)
would close \(S_{p+1},\ldots,S_v\);
and \(k_3,h_4\) each enclose an odd
number of still-free slots.
Inside \(r_{p+1}h_3\), the same
suffix argument forces \(s_qo_3\)
and \(s_ur_{u+1}\) for \(p+1\le u<q\).
This is \(C_{q,p}\). The classification
in (5) is complete. \(\square\)

**Spanning routes.** Write
\(F_u=(r_u,c_u,d_u,s_u)\), the route
through \(S_u\). For \(p=0\),
[Note 345](345-an-unbounded-alternating-double-block-chain-has-a-marked-hamilton-route.md)
(13) at \(m=2\) gives the \(A\)-wiring
\(o_1\)--\(e_4\) path, and
[Note 347](347-a-nested-four-double-swap-has-the-square-hamilton-signature.md)
(4) gives the \(B\)-wiring path.
Both contain the chord \(e_2o_3\).
Replace that edge by
\[
                e_2,F_1,\ldots,F_q,o_3.                 \tag{7}
\]
The new joins are exactly the corridor
chords of \(C_{q,0}\), so the replacement
visits all \(4q\) inserted vertices once.

For \(1\le p<q\), the following two
sequences are spanning \(o_1\)--\(e_4\)
paths, with each \(F_u\) expanded to its
four vertices:
\[
\begin{split}
W^A_{q,p}={}&
(o_1,a_1,b_1,a_2,b_2,e_2,\
F_1,\ldots,F_p,\
j_2,k_2,o_2,h_2,i_2,k_1,j_1,e_1,i_1,h_1,\\
&j_4,k_4,i_4,k_3,i_3,h_3,\
F_{p+1},\ldots,F_q,\
o_3,a_3,b_3,e_3,j_3,h_4,o_4,a_4,b_4,e_4),\\
W^B_{q,p}={}&
(o_1,a_1,b_1,e_1,i_1,h_1,j_4,k_4,i_4,
k_1,j_1,h_2,o_2,a_2,b_2,e_2,\
F_1,\ldots,F_p,\\
&j_2,k_2,i_2,k_3,i_3,h_3,\
F_{p+1},\ldots,F_q,\
o_3,a_3,b_3,e_3,j_3,h_4,o_4,a_4,b_4,e_4).
\end{split}                                                \tag{8}
\]
In each row the joins involving a corridor
are \(e_2r_1,s_pj_2,h_3r_{p+1},
s_qo_3\) and the standard links away
from \(p\). All other consecutive pairs
are old edges or the chords (2),(4).
Each row lists every block vertex exactly
once. Prepend \(L\) and append \(R\)
using \(Lo_1,e_4R\) to obtain the
required group route.

**Realizations.** Use the old Hamilton cycle
\[
x,R_1,w,y,D_1,D_2,S_1,\ldots,S_q,D_3,D_4,
u,z,L_1,v,\alpha,\gamma,\delta,\beta,x.                  \tag{9}
\]
Put \(xy,uv,\alpha\beta\), all block-closing
chords and (2) on the common-face side.
On the opposite side put
\(\delta R_1,wo_1,e_4z,\gamma L_1\)
and \(A\cup C_{q,p}\) or \(B\cup C_{q,p}\).
Every vertex has one matching chord, joining
opposite old-cycle colours without repeating
an old edge. The two pages are noncrossing:
\(h_1j_4\) surrounds the other core chords;
\(j_2s_p\), when present, surrounds the
left corridor links, and \(r_{p+1}h_3\)
surrounds the right ones and \(s_qo_3\).
For \(p=0\), \(j_2h_3\) surrounds the
whole corridor chain. The two wirings in
(4) are nested as in Notes 345 and 347.
Thus each realization is simple, cubic,
bipartite and plane.

For three-connectivity, a connected
chord-interlacement certificate has the
common spine and branches
\[
\begin{gathered}
xy-wo_1-a_1b_1-h_1j_4-a_4b_4-e_4z-uv
 -\gamma L_1-\alpha\beta-\delta R_1,\\
a_1b_1-j_1h_2-o_2k_2,\qquad
a_2b_2-e_2r_1-c_1d_1,\qquad
c_qd_q-s_qo_3-a_3b_3,\\
a_4b_4-j_3h_4-a_3b_3 .
\end{gathered}                                             \tag{10}
\]
For wiring \(A\), add
\[
a_1b_1-k_1i_2-a_2b_2,\quad
k_1i_2-i_1e_1,\quad
a_3b_3-k_3i_4-i_3e_3,\quad
k_3i_4-o_4k_4;                                            \tag{11}
\]
for wiring \(B\), add
\[
\begin{gathered}
a_1b_1-k_1i_4-i_1e_1,\quad
k_1i_4-o_4k_4,\quad
a_2b_2-j_1h_2,\quad
a_2b_2-i_2k_3-i_3e_3 .
\end{gathered}                                             \tag{12}
\]
Finally, if \(p=0\), add
\(a_2b_2-j_2h_3-a_3b_3\); if \(p>0\), add
\[
a_2b_2-j_2s_p-c_pd_p,\qquad
c_{p+1}d_{p+1}-r_{p+1}h_3-a_3b_3.                        \tag{13}
\]
For every standard link \(s_ur_{u+1}\)
in (3), add
\[
             c_ud_u-s_ur_{u+1}-c_{u+1}d_{u+1}.          \tag{14}
\]
Every dash is endpoint alternation on (9).
Equations (10)--(14) contain every
matching chord in one connected graph:
the corridor blocks before and after a
positive cut \(p\) attach respectively
at \(a_2b_2\) and \(a_3b_3\), which
are connected through the outer spine.
A two-edge cut in a cubic Hamiltonian
graph would bound a matching-closed
old-cycle interval and disconnect its
chord-interlacement graph; the old cycle
also excludes bridges. Hence every
realization is three-connected.

The site edges \(xy,uv\) are cofacial.
Their face arcs have lengths \(2q+9\)
and \(3\), and the residual square has
tight targets \(R_1,L_1\), as in Note 350.
The two internally disjoint \(x\)--\(v\) paths
\[
x,R_1,\delta,\beta,\alpha,\gamma,L_1,v
\quad\text{and}\quad
x,y,w,W^{A/B}_{q,p},z,u,v                              \tag{15}
\]
cover the parent and give a Hamilton cycle
through both site edges. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives a Hamilton cycle in the legal child.
For any other parent in this branch,
the group route above composes with the
other groups of Note 324 whenever its
outside-vacancy hypothesis holds.
\(\square\)

The theorem settles the entire \(h_1j_4\)
branch for an arbitrary positive central
corridor and no outer short flanks.
Together with Notes 350--351, only the
\(h_1R\) branch remains for the specified
four-double group when \(q\ge2\).
The opposite orientation, outer short
flanks, other opening types and the general
Barnette conjecture remain open. This
is a project-internal analytic proof,
without an external priority claim.
