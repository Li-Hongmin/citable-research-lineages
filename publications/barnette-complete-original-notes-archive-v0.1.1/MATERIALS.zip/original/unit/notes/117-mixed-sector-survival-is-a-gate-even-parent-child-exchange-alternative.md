> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mixed-sector survival is a gate-even parent--child exchange alternative

[Note 116](116-a-mixed-parent-bond-does-not-force-same-sector-new-cell-occupancy.md)
shows that a sterile state-\(11\) endpoint of a mixed parent rooted bond may
have an empty same-sector new-cell family. That example also has non-\(11\)
parent targets in the same sector, so canonical child targets keep the sector
alive and the global kill-cover antecedent fails.

This note isolates the exact strengthening that removes both escapes. If one
gate sector contains no non-\(11\) parent target, then every parent rooted bond
is automatically covered by state \(11\) on that side, and the corresponding
child sector consists only of new cells. The remaining statement is an
exchange alternative between two complete gate-even switch languages. A
counterexample would directly refute the rooted split-bond lemma; the results
through Note 116 do not decide the alternative.

## 1. The sector-survival statement

Let \(T\rightsquigarrow T^+\) be an interface-disjoint legal split with
inherited root and surviving-gate labels. Suppose that, for some
\(b\in\{0,1\}\),

\[
 {\cal L}_{\neg11}^{\,b}=\varnothing
\tag{1}
\]

and that the parent rooted bond graph contains a mixed edge

\[
 \chi^b-\eta^{1-b},
\qquad
 \chi\in{\cal L}_{11}^{\,b},\quad
 \eta\in{\cal L}_{\neg11}^{\,1-b}.
\tag{2}
\]

The sharp mixed-sector question is

\[
 (P_{\rm sector})\qquad
 (1)\text{--}(2)\quad\Longrightarrow\quad {\cal N}^b\ne\varnothing,
\tag{3}
\]

where

\[
 {\cal N}^b={\cal A}_{R_{00}}^b\cup
 {\cal A}_{X_{uy}}^b\cup{\cal A}_{X_{vx}}^b.
\tag{4}
\]

Every parent rooted bond has endpoints in opposite gate sectors. Under
(1), its endpoint in sector \(b\) therefore has state \(11\). Consequently

\[
 \boxed{\text{the nonempty parent rooted bond graph is globally
 covered by }{\cal L}_{11}.}
\tag{5}
\]

The canonical bijection of Note 108 gives

\[
 {\cal L}_{\neg11}^{\,b}=\varnothing
 \quad\Longleftrightarrow\quad
 {\cal C}^b=\varnothing,
\tag{6}
\]

where \({\cal C}^b\) is the union of the three root-admissible canonical
cells. Since \(C_{11}\) is never root-admissible, the complete child target
sector \(b\) is exactly \({\cal N}^b\). Thus failure of (3) would make the
whole child sector empty and hence make the child rooted bond graph empty.
Together with (5), this proves

\[
 \boxed{\text{an actual counterexample to }P_{\rm sector}
 \text{ is an actual counterexample to the rooted split-bond lemma}.}
\tag{7}
\]

## 2. Complete gate-even switch languages

Globally reverse \(\chi\) so that

\[
 \chi(z)=\chi(P)=\chi(Q)=0,
\qquad
 H=T-z=T^+-\{A,B,C\}.
\tag{8}
\]

For \(K\subseteq V(H)\), put

\[
 \psi_K=\chi|_H\mathbin\triangle K.
\tag{9}
\]

If \(g_1^*=xy\), then \(\psi_K\) has the same surviving-gate bit as
\(\chi\) exactly when

\[
 {\bf1}_K(x)={\bf1}_K(y),
\qquad\text{or equivalently}\qquad
 g_1^*\notin\delta_H(K).
\tag{10}
\]

Call such a set \(K\) **gate-even**. No connectivity or ancestry condition
is imposed.

Define \({\mathscr P}_{\neg11}^b(\chi)\) to be the family of gate-even
sets \(K\) for which \(\psi_K\), with a suitable colour at \(z\), is a
root-admissible parent NAE colouring of non-\(11\) state. For
\(N\in\{R,U,V\}\), define \({\mathscr X}_{N}^b(\chi)\) to be the family
of gate-even sets \(K\) for which \(\psi_K\) extends, in one global
orientation of the \(N\)-row, to a root-admissible child NAE colouring.
These are complete difference-set languages, so

\[
\begin{aligned}
 {\cal L}_{\neg11}^{\,b}=\varnothing
 &\quad\Longleftrightarrow\quad
 {\mathscr P}_{\neg11}^b(\chi)=\varnothing,\\
 {\cal N}^b=\varnothing
 &\quad\Longleftrightarrow\quad
 {\mathscr X}_{R}^b(\chi)\cup
 {\mathscr X}_{U}^b(\chi)\cup
 {\mathscr X}_{V}^b(\chi)=\varnothing.
\end{aligned}
\tag{11}
\]

Membership in a child language is intrinsic. It requires:

1. \(\psi_K(P)=\psi_K(Q)\), so an orientation of the local row agrees
   with the old exterior;
2. every old, interval, and central patch triangle is NAE;
3. the root edge and gate bit are retained;
4. after attaching the monochromatic components of \(H\) to \(A,B,C\)
   through \(J_A,J_B,\{P,Q\}\), the two gluing graphs have total component
   count three and keep the two labelled root fragments separate.

The last condition is exactly the labelled region-tree criterion of
Note 109.

## 3. Why the mixed bond has the wrong parity

Orient \(\eta\) so that \(\eta(z)=\chi(z)\), and let

\[
 S=\{v:\chi(v)\ne\eta(v)\}\subseteq V(H).
\tag{12}
\]

Since (2) is a rooted bond, \(S\) is a connected bond shore. But the two
endpoints of (2) have opposite gate bits, so

\[
 g_1^*\in\delta_H(S).
\tag{13}
\]

Thus \(S\) and its complementary shore are gate-odd. They belong to
neither gate-even language in (11). The connected switch supplied by the
mixed bond is therefore in the wrong parity class for both the excluded
parent target and the desired child target.

Combining (3) and (11) gives the exact remaining implication:

\[
\boxed{
\begin{gathered}
\text{a connected gate-odd mixed rooted-bond shore exists},\\
{\mathscr P}_{\neg11}^b(\chi)=\varnothing
\\[1mm]\Longrightarrow\\[1mm]
{\mathscr X}_{R}^b(\chi)\cup
{\mathscr X}_{U}^b(\chi)\cup
{\mathscr X}_{V}^b(\chi)\ne\varnothing.
\end{gathered}}
\tag{14}
\]

This is the **gate-even parent--child exchange alternative**.
Note 109 tests the component ranks of a specified switch but does not
change its gate parity. Note 114 begins only after child cells are occupied.
Notes 115 and 116 give, respectively, a positive child repair and an empty
new-cell language in cases where the same-sector parent language is nonempty.
None of them couples the two gate-even languages in (14).

## 4. Strict abstract boundary

At the state, gate, bond, and canonical-incidence level, (14) is false.
Take a parent family with one state-\(11\) vertex \(\chi^b\), one
non-\(11\) vertex \(\eta^{1-b}\), and their unique rooted bond. In the
child retain only the canonical image of \(\eta\). Then

\[
 {\mathscr P}_{\neg11}^b(\chi)=\varnothing,
\qquad
 {\cal N}^b=\varnothing,
\tag{15}
\]

while the parent graph is nonempty and globally kill-covered. The model
respects the canonical induced-graph identity and the local cell table.
It is not the complete NAE family of one actual triangulation split.

Hence local states, gate bits, parent bondness, and canonical incidence
cannot prove (14). The missing input is precisely the common complete NAE
family of an actual \(4\)-connected Eulerian triangulation and its split.

## 5. The Note 116 split cannot be upgraded by relabelling

For completeness, keep the single crossed-double-split graph of Note 116
and vary all interface-disjoint root and gate labels. There are twelve
eligible root edges and \(168\) eligible root--gate pairs. Complete
enumeration of its \(89\) parent NAE colour orbits, followed by the exact
labelled-root and bond-shore tests, gives

\[
\begin{array}{c|r}
\text{parent rooted bond graph empty}&28\\
\text{parent graph nonempty but global }{\cal L}_{11}\text{ cover fails}&140\\
\text{parent graph nonempty and globally kill-covered}&0.
\end{array}
\tag{16}
\]

Thus the same-sector vacuum of Note 116 cannot be converted into a
\(P_{\rm sector}\) counterexample merely by relabelling that fixed split.
This is a complete exclusion for one graph, not evidence for arbitrary
legal splits.

The finite check is reproduced by

    python3 units/barnette/scratch/worker-actual-occupancy-countermodel/audit_crossed_double_split_sector_global.py

and terminates with

    CROSSED_SPLIT_P_SECTOR_EXCLUDED

## 6. Remaining boundary

The actual gate-even parent--child exchange alternative (14) is presently
unproved and has no actual counterexample. Its two outcomes have different
consequences:

* a proof eliminates every mixed single-sector stranding obstruction;
* an actual counterexample refutes the rooted split-bond lemma and the
  associated kill-cover supplementation route.

The all-\(11\)--\(11\) parent-bond case is separate and is not included in
(14). No further graph order or parameter is implied by this reduction.
