> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mixed port pairs and vacancy cycles have three spanning routes

[Note 280](280-one-mixed-pair-absorbs-arbitrary-nested-vacancy-cycles.md)
allows one missing ordinary link paired with one vacancy atom,
while any number of port-free vacancy cycles nest inside or
around it. The same three-state construction admits arbitrarily
many mixed pairs. Consecutive missing links can make two
otherwise disjoint mixed patches share one short block; an
explicit two-pair route handles that overlap.

Use the compressed, gapless, tight-target all-square opening
and the free-group atom diagram of
[Notes 275](275-every-vacancy-only-noncrossing-matching-is-marked-hamiltonian.md),
[276](276-distinct-target-free-vacancies-have-only-chain-defects.md),
and [278](278-missing-chain-ports-separate-and-three-free-vacancies-are-hamiltonian.md).
All vacancies of the opening lie in distinct target-free
internal face-chord blocks. Fix one free group and let \(J\)
be the indices of its missing ordinary links
\(P_s=e_so_{s+1}\). Assume:

1. every part of the noncrossing atom partition that contains
   a port consists of that port and exactly one vacancy atom;
2. for a port \(P_s\) paired with vacancy \(V_k\), the block
   \(B_s\) is short and target-free when \(P_s<V_k\), while
   \(B_{s+1}\) is short and target-free when \(V_k<P_s\);
3. the two ordinary links attaching the group's full internal
   target-free block interval to its endports are retained.

There is no bound on \(|J|\), the number of port-free parts,
the distances between atoms, or their nesting depth.

**Mixed-pair theorem.** Let \(D=B_a,\ldots,B_b\)
be that full target-free internal interval, with external
ports \(a_a,o_a,e_b,b_b\). It has all three vertex-spanning
states
\[
\begin{array}{ll}
X(D):&a_a\longleftrightarrow b_b,\quad
       o_a\longleftrightarrow e_b;\\
K(D):&a_a\longleftrightarrow o_a,\quad
       e_b\longleftrightarrow b_b;\\
S(D):&o_a\longleftrightarrow e_b.
\end{array}                                               \tag{1}
\]
Thus this group replaces its ordinary segment by one
spanning route. If every other free group also has an
ordinary-endport spanning route, the parent has a Hamilton
cycle containing both site edges and the legal expanded
child is Hamiltonian.

**Proof.** A vacancy-only part spans from its first to its
last vacant block. For a mixed two-atom part, define its
*block span* to be \(B_s,\ldots,B_k\) when \(P_s<V_k\),
and \(B_k,\ldots,B_{s+1}\) when \(V_k<P_s\).
The immediate-neighbour cases \(k=s,s+1\) are excluded by
old-cycle adjacency, as in Note 280.

The atom spans of distinct parts form a noncrossing nesting
forest. A part nested between two atoms of another part has
its whole block span inside the corresponding proper block
gap. At a vacant endpoint block, a nested port would require
that same block to be short under condition 2; a nested
vacancy cannot use an already occupied vacant block. Thus
nesting is block-aligned.

Two disjoint atom spans can share one block \(B_j\) in
their block spans. The earlier span can end there only at
vacancy \(V_j\) or port \(P_{j-1}\); the later span can
begin there only at \(V_j\) or port \(P_j\). Distinct
parts cannot both use \(V_j\), and a vacancy-port
combination would make a block required short by condition
2 vacant. Hence the only overlap is the consecutive-port
pair \(P_{j-1},P_j\), with a short shared block \(B_j\).
The earlier mixed part has its vacancy to the left of
\(P_{j-1}\), and the later one has its vacancy to the
right of \(P_j\). There is no atom between the two ports:
their intervening block is short. Each mixed part can
therefore participate in at most one such overlap, and a
third part cannot separate the two. We combine the pair
into one block-aligned patch below.

Proceed from the leaves of the resulting nesting forest.
A closed interval with no special atom is a short-block
ladder and has the three states of Note 275. For a
vacancy-only part, Note 275's prime construction accepts
any proper closed gap already having \(S,K,X\): its prime
\(X\) joins the two \(X\) rails, its prime \(K\) uses
\(X\) in the first gap, and its prime \(S\) uses \(K\)
there and \(S\) in later gaps. The old-cycle arc used by
\(K\) across later gaps remains present when a gap
contains a missing ordinary matching link.

For a mixed part \(P_s<V_k\) that is not in an overlap,
all parts strictly between its atoms have block spans
inside \(F=B_{s+1},\ldots,B_{k-1}\). By induction
\(F\) has \(S(F),K(F),X(F)\). Its right attachment
\(e_{k-1}o_k\) is retained: a missing \(P_{k-1}\)
paired with an atom to the left would require the vacant
\(B_k\) to be short, and a mate to the right would
interlace \(P_s,V_k\). The paths (5)--(8) of Note 280
use only \(S(F),X(F)\), the two mixed matching edges
\(e_sI_k,o_{s+1}H_k\), that retained attachment, and
old-cycle or face-chord edges. Thus they give \(S,K,X\)
even when \(F\) contains further mixed parts. Reflection
handles \(V_k<P_s\).

It remains to give the three states for an overlapping pair.
Write its atoms in the order
\[
 V_k<P_s<P_{s+1}<V_m,
 \qquad T=B_{s+1}=(a_T,o_T,e_T,b_T),                 \tag{2}
\]
where \(k\le s-1\) and \(m\ge s+3\). Put
\(L=B_{k+1},\ldots,B_s\) and
\(R=B_{s+2},\ldots,B_{m-1}\). They are nonempty
proper closed gaps, so by induction they have \(S,K,X\).
The four matching edges of the two mixed parts are
\[
 e_sI_k,\quad o_TH_k,\quad e_TI_m,\quad
 o_{s+2}H_m.                                          \tag{3}
\]
The boundary ordinary links \(e_ko_{k+1}\) and
\(e_{m-1}o_m\) are retained by the same adjacency
and noncrossing argument used for \(e_{k-1}o_k\) above.

Here are the \(S\) and \(X\) states of the combined patch
\(Q=B_k,\ldots,B_m\). Named routes through \(L,R\)
are traversed in the displayed direction:
\[
\begin{split}
S(Q):\quad o_k,a_k,b_k,e_k,o_{k+1}
 &\xrightarrow{S(L)}e_s,I_k,H_k,o_T,a_T,b_T,e_T,\\
 &I_m,H_m,o_{s+2}\xrightarrow{S(R)}e_{m-1},o_m,
 a_m,b_m,e_m.
\end{split}                                             \tag{4}
\]
For \(X(Q)\), its bottom path is
\[
 o_k,H_k,o_T,e_T,I_m,e_m.                             \tag{5}
\]
Its top path is
\[
\begin{split}
a_k,b_k,e_k,I_k,e_s
 &\xrightarrow{X_{\rm bottom}(L)^{-1}}o_{k+1},a_{k+1}
 \xrightarrow{X_{\rm top}(L)}b_s,a_T,b_T,a_{s+2}\\
 &\xrightarrow{X_{\rm top}(R)}b_{m-1},e_{m-1}
 \xrightarrow{X_{\rm bottom}(R)^{-1}}o_{s+2},H_m,o_m,a_m,b_m.
\end{split}                                             \tag{6}
\]
Every join in (4)--(6) is one of (3), a retained ordinary
link, an old-cycle edge, or a face chord. The two \(X\)
paths are disjoint and cover \(Q\): in \(B_k\) the
bottom uses \(o_k,H_k\) and the top uses its other four
vertices; in \(T\) the bottom uses \(o_T,e_T\) and
the top uses \(a_T,b_T\); in \(B_m\) the bottom uses
\(I_m,e_m\) and the top uses its other four vertices.
The gap routes cover \(L,R\) once each. The same check
shows that (4) is a spanning straight path.

For \(K(Q)\), first apply the reflected mixed construction
to \(Q_L=B_k,\ldots,B_{s+1}\). Its two paths have
endpairs \(a_k-o_k\) and \(e_T-b_T\), and cover
\(Q_L\). Keep the first path. Extend the second, from
its \(e_T\) end and then its \(b_T\) end, to the right:
\[
\begin{split}
e_m,I_m,e_T
 &\xrightarrow{K_R(Q_L)}b_T,a_{s+2}
 \xrightarrow{X_{\rm top}(R)}b_{m-1},e_{m-1}\\
 &\xrightarrow{X_{\rm bottom}(R)^{-1}}o_{s+2},H_m,o_m,a_m,b_m.
\end{split}                                             \tag{7}
\]
This path has endpoints \(e_m,b_m\), is disjoint from
the unchanged \(a_k-o_k\) path, and together they cover
\(Q\). Equations (4)--(7) establish all three states
for an overlap.

The combined patches, all remaining mixed parts, and the
vacancy-only parts now have block-aligned nested or disjoint
spans. Join disjoint closed spans and intervening short
blocks in boundary order. Every serial join uses a retained
ordinary link and its parallel old-cycle top-rail edge:
\(S+S\) gives \(S\), \(X+X\) gives \(X\), and
\(K+X\) gives \(K\), as in Note 275. The resulting
states cover the full interval \(D\). Attach \(S(D)\)
to the group's retained end links and the free-path template
of Note 196. Group composition is Note 273's disjoint splice;
Notes 001 and 178 give the legal child and arbitrary original
lobe lengths. \(\square\)

**An unbounded realized subfamily.** For every \(d\ge2\),
put \(r=3d+2\) and \(\ell=1\). Use one old Hamilton cycle
whose consecutive blocks are
\[
\begin{array}{ll}
B_0:&x,R_1,e_0,y,\\
B_j:&a_j,o_j,e_j,b_j
       \quad(j\notin W),\\
B_j:&a_j,o_j,H_j,I_j,e_j,b_j
       \quad(j\in W),\\
B_{r+1}:&u,o_{r+1},L_1,v,\\
\text{last arc}:&\alpha_1,\gamma_1,\delta_1,\beta_1
       \quad\text{returning to }x,
\end{array}                                               \tag{8}
\]
where \(1\le j\le r\) in the two internal-block rows and
\[
 W=\{3,6,\ldots,3d\}\cup\{3d+1,3d+2\}.
\]
Give it the complementary perfect matching
\[
\begin{split}
M={}&\{xy,uv,\alpha_1\beta_1,
       \delta_1R_1,\gamma_1L_1\}
 \cup\{a_jb_j:1\le j\le r\}\\
 &\cup\{e_jo_{j+1}:0\le j\le r,
               j\notin\{3t-2:1\le t\le d\}\}\\
 &\cup\{e_{3t-2}I_{3t},\
          o_{3t-1}H_{3t}:1\le t\le d\}\\
 &\cup\{H_{3d+1}I_{3d+2},\
          I_{3d+1}H_{3d+2}\}.
\end{split}                                             \tag{9}
\]
The old cycle and (9) make every vertex cubic; each matching
edge joins opposite old-cycle parities. Draw the site, face,
and \(\alpha_1\beta_1\) chords on the common-face side.
On the opposite side, \(\delta_1R_1\) and
\(\gamma_1L_1\) enclose the free chords. For each \(t\),
\(e_{3t-2}I_{3t}\) encloses
\(o_{3t-1}H_{3t}\) and the retained intervening link;
different \(t\)-intervals are disjoint. The final two
vacancy edges are nested. Thus the matching has a
crossing-free two-page drawing and the site edges are
cofacial. Every block has even order, so \(x,u\) have
the same bipartition colour and the site expansion is legal.

The matching-chord interlacement graph is connected.
The standard links connect successive face chords except
at \(j=3t-2\); there, the replacement edge
\(e_jI_{j+2}\) interlaces both \(a_jb_j\) and
\(a_{j+2}b_{j+2}\), while \(o_{j+1}H_{j+2}\)
interlaces both \(a_{j+1}b_{j+1}\) and
\(a_{j+2}b_{j+2}\). The final two vacancy chords
each interlace their own face chord. The unchanged
closing chain from \(xy\) through the first and last
standard links, \(uv,\gamma_1L_1,\alpha_1\beta_1,
\delta_1R_1\) back to \(xy\) connects every remaining
matching chord. As in Note 217, connected interlacement
excludes a matching-closed proper consecutive old-cycle
interval, hence a two-edge cut. The graph is simple,
cubic, Hamiltonian, and three-edge-connected; the cubic
lemma of Note 182 makes it three-vertex-connected.
It is a Barnette parent on \(14d+24\) vertices.

Its \(d\) missing links \(P_{3t-2}\) each form a
two-atom port part with \(V_{3t}\) and short source
block \(B_{3t-2}\). The last two vacancies form a
port-free square. Both group-end links are retained,
so the theorem gives the marked Hamilton parent cycle
and a legal Hamiltonian child on \(14d+28\) vertices.
For \(d\ge2\), the group has at least two mixed parts
and a separate vacancy-only cycle.

The conclusion is a structural theorem for an unbounded
number of interacting mixed pairs and vacancy-only cycles,
including consecutive missing links. It does not cover a
port part with multiple vacancy atoms, a vacant
block at the port's required short side, or openings with
target-bearing vacancies, positive gaps, defective target
order, or nonsquare residual cycles. It does not settle
Barnette's conjecture.
