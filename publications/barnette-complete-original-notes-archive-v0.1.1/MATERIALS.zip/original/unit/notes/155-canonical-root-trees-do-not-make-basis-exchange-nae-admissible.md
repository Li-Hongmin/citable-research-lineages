> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Canonical root trees do not make basis exchange NAE-admissible

[Note 124](124-root-smoothing-does-not-turn-mixed-sector-survival-into-parity.md)
identifies rooted two-cycle targets with a prescribed Hamilton family, while
[Note 154](154-a-crossing-bridge-can-be-an-isolated-mixed-component.md)
shows that a mixed exchange edge may be an isolated component.  In the dual,
every rooted target also has a canonical spanning-tree representation.  This
representation is exact, and a single-cycle exchange becomes a bond between
two canonical trees.  Nevertheless ordinary graphic basis exchange cannot
preserve the perfect-matching, equivalently facewise-NAE, condition even for
one nontrivial step.  Thus spanning-tree connectivity does not supply the
cross-component compensation left open by Note 154.

## 1. The canonical tree

Let \(G\) be a simple plane cubic bipartite graph with a facial square

\[
 Q=(u,v,x,y),\qquad e=uv,\quad g_0=xy,
\]

and write \(s_1=vx,s_2=yu\) for the lateral square edges.  Let \(M\) be a
perfect matching containing \(e,g_0\) such that \(G-M\) consists of two
cycles, one closed through \(s_1\) and the other through \(s_2\), with the
prescribed rooted pairing.  Put \(D=G^*\) and \(H_M=M^*\).  The graph \(H_M\)
is the monochromatic-edge graph of the corresponding facewise-NAE colouring
of \(D\).

Root smoothing gives the Hamilton cycle

\[
 C_M=(G-M)+e+g_0-s_1-s_2.
\tag{1}
\]

Define

\[
 S_M=(H_M-e^*)\cup\{s_1^*,s_2^*\}.
\tag{2}
\]

The primal dual complement of \(S_M\) is

\[
 C_M-g_0=(G-M)+e-s_1-s_2,
\tag{3}
\]

which is a spanning Hamilton path.  By plane tree--cotree duality,
\(S_M\) is therefore a spanning tree of \(D\).

There is also an exact region description.  The two cycles of \(G-M\)
divide the sphere into two disks and their intervening annulus.  The three
components of \(H_M\) are the dual cell-adjacency graphs of these regions.
The two disk components are trees and the annular component is unicyclic.
Since \(e\) joins the two boundary cycles of the annulus, \(e^*\) lies on
the unique cycle of the annular component.  Removing \(e^*\) breaks that
cycle, while \(s_1^*,s_2^*\) join the three resulting trees.  Hence (2)
also follows directly from the rooted region structure; the bare numerical
conditions of three components and total cycle rank one would not by
themselves locate \(e^*\).

## 2. Bond flips and the common-forest quotient

Let \(M,N\) be two rooted targets, with dual NAE colourings \(\chi,\eta\),
and choose representatives so that

\[
 W=\{z\in V(D):\chi(z)\ne\eta(z)\}.
\]

A dual edge changes monochromatic status exactly when it crosses this
shore.  Consequently

\[
 H_M\mathbin\triangle H_N=\delta_D(W).
\tag{4}
\]

The correction in (2) is fixed throughout the rooted family, so it cancels:

\[
 \boxed{S_M\mathbin\triangle S_N=\delta_D(W).}
\tag{5}
\]

If \(M\triangle N\) is one alternating cycle, then (5) is a bond.  Put

\[
 F=S_M\cap S_N,\qquad A=S_M-F,\qquad B=S_N-F.
\]

After contracting every component of the common forest \(F\), both \(A\)
and \(B\) are spanning trees of the same quotient multigraph, they are
edge-disjoint, and

\[
 A\cup B=\delta_D(W).
\tag{6}
\]

Thus the canonical-tree and two-disjoint-bases reductions are both valid.

## 3. Ordinary basis exchange necessarily exits NAE

The inverse of (2) is

\[
 M^*=\bigl(S_M-\{s_1^*,s_2^*\}\bigr)\cup\{e^*\}.
\tag{7}
\]

Consider a nontrivial one-edge graphic basis exchange

\[
 S'=S_M-a^*+b^*,\qquad a^*\ne b^*.
\tag{8}
\]

None of the three fixed correction edges in (7) belongs to the quotient
difference.  If \(S'\) were the canonical tree of another rooted target,
then (7) would give

\[
 M'=M-a+b.
\tag{9}
\]

This cannot be a perfect matching.  Removing \(a=rs\) leaves precisely
\(r,s\) unmatched, so the one added edge must have endpoint set
\(\{r,s\}\); simplicity then forces \(b=a\), contrary to (8).  Equivalently,
the symmetric difference of two distinct perfect matchings is a disjoint
union of even cycles and cannot consist of two edges.

It follows that no nontrivial ordinary symmetric basis exchange preserves
the facewise-NAE class.  A sequence whose every intermediate tree is
NAE-admissible cannot take its first step.  If several edges are exchanged
at once, re-entry into the perfect-matching class requires complete
alternating cycles; imposing that the two endpoints remain rooted and that
their total dual difference is one bond is exactly the original rooted
exchange problem.  The graphic reduction then becomes an equivalent
encoding rather than a new existence theorem.

## 4. Consequence for the one-crossing problem

The obstruction in Section 3 is local and does not depend on legal-wide
placement, bipartite brace connectivity or dual \(4\)-connectivity.  Those
hypotheses cannot repair a degree defect created by a one-edge exchange.
For the isolated pair of Note 154, strong symmetric basis exchange does
operate in the six-vertex common-forest quotient, but its inverse has
matching degrees \(0\) and \(2\) at two primal vertices, exactly as (9)
predicts.

Therefore the still-open implication

\[
 \Gamma_{g_1}(\mathcal T_e)\ne\varnothing
 \Longrightarrow |E\Gamma_{g_1}(\mathcal T_e)|\ne1
\]

cannot follow from ordinary basis-pair connectivity.  The missing statement
must preserve all primal degree-one equations during a **multi-edge** move:
it must produce two complete-fibre NAE states in opposite gate sectors whose
canonical trees differ by one bond and whose rooted region pairing is still
the prescribed one.
