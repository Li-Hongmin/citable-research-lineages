> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A middle-root bridge splice leaves one ordered path obstruction

[Note 492](492-two-mixed-openings-reduce-end-middle-split-pairs-to-direct-cross-chords.md) leaves a specific middle-root complement as a terminal-free component of a mixed opening. Its ordinary root chord provides a further splice through the two old main-cycle boundary edges. The only path order not settled by that splice is explicit.

Use the three-root chord-free single-hexagon order of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md), with base cycles \(D=C_1\cup C_2\cup C_3\). Let \(u,v\) be the site ports, \(q=w_0u,p=vw_*\), and let \(Z\subset C_2\cup W_2\) be a cycle supported on a middle-root complement. Suppose \(Z\) contains the root chord \(e_2=\ell_2r_2\), where \(\ell_2,r_2\) are the first and last vertices of \(W_2\). Let \(P\) be a spanning \(u\)--\(v\) path on \(V(D)\setminus V(Z)\) containing the two inner escape edges
\[
                         e_c=t_cc,\qquad e_b=t_bb,
\]
and suppose \(P\) and \(Z\) are vertex-disjoint and together cover \(D\). All these conditions hold after the componentwise leaf-square switches in the direct-cross profile of Note 492: the middle root contains a marked nonleaf node, so its root chord belongs to no leaf-square support, and the switches touch neither that chord nor any escape edge.

**Middle-bridge splice theorem.** Delete \(e_2\) from \(Z\), add the old edges \(t_c\ell_2,r_2t_b\), delete \(e_c,e_b\) from \(P\), and add the unused old edge \(bc\). If the resulting graph is one \(u\)--\(v\) path, the parent has a Hamilton cycle through both site edges. If it is a path plus a cycle containing \(t_dd\) or \(t_aa\), the same conclusion holds. Failure of these two closures requires, after possibly reversing \(P\), that \(P\) traverse the two four-vertex exterior arcs in the order
\[
                 (t_d,d,c,t_c)\quad\cdots\quad(t_b,b,a,t_a),       \tag{1}
\]
where the subpath between \(t_c\) and \(t_b\) contains neither end escape edge. Thus a non-Hamiltonian legal child in the exact direct-cross profile of Note 492 requires **every** spanning path obtained by its componentwise leaf-square switches to have order (1).

**Proof.** The cycle \(Z-e_2\) is a spanning \(\ell_2\)--\(r_2\) path of \(Z\). The edges \(t_c\ell_2,r_2t_b\) are old main-cycle edges unused by the base cycles \(D\). They turn it into a path
\[
                   R=(t_c,\ell_2)\ (Z-e_2)\ (r_2,t_b)       \tag{2}
\]
from \(t_c\) to \(t_b\). The unused old edge \(bc\) joins the other two endpoints left by deleting \(e_c,e_b\). The two replacements preserve degree at every vertex; the resulting graph has degree one exactly at \(u,v\) and otherwise degree two. It therefore consists either of one \(u\)--\(v\) path or of such a path and one cycle. The first outcome closes through the outside path \((u,w_0,\beta,\alpha,w_*,v)\) of [Note 489](489-two-end-escape-edges-absorb-both-residual-cycles.md).

For the second outcome, if the cycle contains \(t_dd\), delete that edge and use the two outside paths (3) of Note 489 to absorb it into the marked path. If it contains \(t_aa\), use (4) of that note. All four vertices outside \(D\) are then covered once, and \(q,p\) are included. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts the marked parent cycle to the expanded child.

It remains to identify when the new cycle avoids both end escapes. Orient \(P\) from \(u\) to \(v\) and, first, suppose \(e_c\) occurs before \(e_b\). If they are traversed in the same direction relative to the ordered pairs \((t_c,c)\) and \((t_b,b)\), the connections \(R\) and \(bc\) join the three pieces of \(P-\{e_c,e_b\}\) into one path. If their directions differ, the middle piece of \(P\) becomes the unique residual cycle, completed by either \(R\) or \(bc\). When \(e_c\) is traversed \(t_c\to c\), the forced degree-two arc \(c\to d\to t_d\) follows immediately, so that middle piece contains \(t_dd\). Hence a residual cycle without an end escape requires \(e_c\) to be traversed \(c\to t_c\) and \(e_b\) to be traversed \(t_b\to b\). The forced degree-two arcs then give (1): \(t_d\to d\to c\to t_c\), followed later by \(t_b\to b\to a\to t_a\). If \(e_b\) occurs before \(e_c\), reverse \(P\) and apply the same argument. Conversely, order (1) places \(t_dd\) before the first cut and \(t_aa\) after the second, so the residual cycle produced by the switch has neither. This proves the stated necessary path order. \(\square\)

The theorem is an explicit marked-cycle splice criterion. It does not show whether order (1) can be avoided in every legal end-middle opening, or decide other selected openings or Barnette's conjecture.
