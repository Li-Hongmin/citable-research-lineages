> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Single-cycle portals and Hamilton suppliers need not coincide

[Note 126](126-even-the-complete-parent-rooted-support-need-not-contain-a-child-escape.md)
shows that the complete parent rooted fibre may omit retained edges required
by every same-sector child escape.  In its order-(20) example, the missing
incidence is repaired unusually cleanly: one same-sector non-rooted perfect
matching is both a single-cycle portal from the sterile endpoint and a
Hamilton-complement supplier for the child patch.

That coincidence is not forced.  A second actual legal-wide split separates
the two roles sharply.  Its unique single-cycle portal has a two-cycle
complement, whereas every Hamilton-complement supplier differs from the
endpoint in at least two alternating components.  Thus a proof of
mixed-sector survival cannot require one non-rooted perfect matching to
carry both properties.

## 1. The one-hub strengthening

Let \(\chi^b\) be a sterile state-(11) rooted parent target at the
cofacial expansion site \(\{p,q\}\).  Call a parent perfect matching (Q)
a **single non-rooted Hamilton hub** for \(\chi\) when:

1. (Q) contains the root and forced gate, has surviving-gate bit (b),
   and is not a rooted target;
2. (Q\mathbin\triangle\chi) is one alternating cycle, avoids the three
   labelled root/gate edges, contains (p,q), and changes local state
   (11) to (00);
3. (G-Q) is a Hamilton cycle;
4. some same-sector child target (N) in
   \(R_{00},X_{uy},X_{vx}\) satisfies

   \[
   N\cap E_{\rm ret}
   \subseteq(\chi\cup Q)\cap E_{\rm ret}.
   \tag{1}
   \]

The first example of Note 126 has such a hub.  Its portal is a (C_{12})
through the two site edges; after those two edges are cut, the remaining
proper arcs and the three patch rows directly give the
\(R_{00},X_{uy},X_{vx}\) targets.  This explains that example but does not
follow from the mixed-sector hypotheses.

## 2. An actual separation example

Consider the plane cubic bipartite graph and legal-wide split

```text
graph6 = W???????????w?s?P_BC?I_?L??J??B_?AW??F??_W?AC_?
root = 11-22
forced gate = 3-23
surviving gate = 5-14
site = {4-17, 9-20}
```

with sector (b=1).  The sterile state-(11) endpoint is

\[
\begin{aligned}
\chi=\{&0\!-!12,1\!-!13,2\!-!15,3\!-!23,
4\!-!17,5\!-!14,\\
&6\!-!16,7\!-!18,8\!-!19,9\!-!20,
10\!-!21,11\!-!22\}.
\end{aligned}
\tag{2}
\]

Its exact endpoint profile is

\[
 (|{\cal M}_\chi|,|{\cal E}_\chi|,|{\cal X}^1|)=(2,0,5),
\tag{3}
\]

and the five child targets have cells

\[
 X_{uy},R_{00},X_{vx},X_{uy},X_{uy}.
\tag{4}
\]

Among all (200) parent perfect matchings, exactly (20) have the labels,
sector and non-rooted status in item 1.  Exactly one also satisfies the
single-cycle portal condition in item 2.  It is

\[
\begin{aligned}
Q_{23}=\{&0\!-!12,1\!-!13,2\!-!15,3\!-!23,
4\!-!16,5\!-!14,\\
&6\!-!20,7\!-!17,8\!-!18,9\!-!19,
10\!-!21,11\!-!22\},
\end{aligned}
\tag{5}
\]

and it supports an (X_{uy}) target through (1).  Nevertheless

\[
 Q_{23}\mathbin\triangle\chi=C_{10},
 \qquad
 G-Q_{23}=C_6\mathbin{\dot\cup}C_{18}.
\tag{6}
\]

Hence the unique single-cycle portal is not Hamilton-complement.

Conversely, exactly four of the twenty candidates are Hamilton-complement.
One of them is

\[
\begin{aligned}
Q_{93}=\{&0\!-!13,1\!-!12,2\!-!15,3\!-!23,
4\!-!16,5\!-!14,\\
&6\!-!20,7\!-!17,8\!-!18,9\!-!19,
10\!-!21,11\!-!22\}.
\end{aligned}
\tag{7}
\]

It supports one child target in each of the three new cells, but

\[
 G-Q_{93}=C_{24},
 \qquad
 Q_{93}\mathbin\triangle\chi=C_4\mathbin{\dot\cup}C_{10}.
\tag{8}
\]

Thus no parent perfect matching satisfies both items 2 and 3, and there is
no single non-rooted Hamilton hub:

\[
\boxed{
\#\{Q:\text{single-cycle portal}\}=1,quad
\#\{Q:G-Q\text{ Hamiltonian}\}=4,quad
\#\{Q:\text{both}\}=0.}
\tag{9}
\]

The parent and child have orders (24,28), respectively (200,344)
perfect matchings, and rooted fibres of sizes (11,13).  Both are plane
cubic bipartite braces, and the gate arcs of the expanded face have lengths
\((5,5)\).  Hence (9) is an actual legal-wide separation, not an abstract
matching system.

## 3. The surviving local criterion

For any fixed portal pair, target admission itself still has an exact
topological test.  Delete the two site edges from the alternating portal
and contract every maximal common complement path.  Add the complement
connections prescribed by one patch row.  The resulting child matching is
root-admissible exactly when the component quotient has the required two
labelled root components: for (R_{00}), the two exterior spanning paths
must receive the other noncrossing pairing; for a cross row, the prescribed
endpoint pair must lie on one spanning path and no residual quotient cycle
may remain.  This is the portal form of the traversal criterion in
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md).

The criterion checks a proposed pair; it does not produce one.  Example
(9) proves that production cannot insist simultaneously on single-cycle
adjacency to \(\chi\) and a Hamilton complement.  A general proof must
either couple distinct perfect matchings carrying the two roles, allow a
multi-component portal such as (C_4\dot\cup C_{10}), or derive child
quotient connectivity directly from the complete perfect-matching family.
None of these alternatives is proved here.

The frozen certificate is
[single-cycle-portal--Hamilton-supplier separation](../computations/bundles/single-cycle-portal-hamilton-supplier-separation/README.md).

