> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Theorem-level corrections and the positive-depth support theorem

This note gives a self-contained corrected formulation of the local
Hamiltonian interface and the recurrent support theorem used in Notes
001--003.  In particular, the support hypothesis below implies
edge-Hamiltonicity only after the first expansion.  It does not, by itself,
imply edge-Hamiltonicity of the starting graph.

## The six local states

Let (G) be a finite simple graph, let

\[
p=uv,\qquad q=xy
\]

be vertex-disjoint edges, and put (R=G-\{p,q\}), deleting edges but not
vertices.  Thus (u,v,x,y) are four distinct terminals.  Form (H) by
adding new vertices (a,b,c,d) and the edges

\[
ua,ab,bv,xc,cd,dy,ad,bc.
\]

Here a Hamilton path is spanning.  A spanning two-path linkage consists of
two vertex-disjoint positive-length simple paths whose vertex sets partition
(V(G)) and whose endpoints are exactly (u,v,x,y).  Its endpoint pairing
is the corresponding perfect matching of the four terminals.

Then (H) is Hamiltonian if and only if at least one of the following
structures exists:

1. a Hamilton cycle of (G) containing (p) and (q);
2. a Hamilton cycle of (G) containing (p) and avoiding (q);
3. a Hamilton cycle of (G) containing (q) and avoiding (p);
4. a spanning (v)-(x) path in (R);
5. a spanning (u)-(y) path in (R);
6. a spanning two-path linkage in (R) whose endpoint pairing is not
   ((uy)(vx)).

Indeed, imposing degree two at (a,b,c,d) leaves seven local edge patterns.
One is the isolated square and cannot occur in a Hamilton cycle containing
the old vertices.  Four patterns use two spokes and a three-edge path in the
square; the other two use all four spokes and one of the two perfect
matchings of the square.  In the four-spoke case the external linkage and
the gadget each induce a perfect matching on (u,v,x,y).  Their union is one
cycle precisely when the matchings differ; equal matchings give two cycles.
This explains the pairing restriction in the sixth state and is the step not
captured by degree equations alone.  No planarity, bipartiteness, cubicity or
connectivity assumption is used in this equivalence.

For a Barnette expansion the labels must additionally agree with the plane
embedding.  Up to reversal, orient the common facial boundary as

\[
u,v,\ldots,x,y,\ldots,u.
\]

This is the noncrossing orientation of the inserted square.  Bipartiteness is
preserved exactly when (u,x) lie in the same bipartition class, equivalently
when the two residual facial paths obtained after deleting (p,q) both have
odd length.  With these conditions the expansion preserves simplicity,
cubicity, planarity, bipartiteness and 3-vertex-connectivity.  The next
oriented central pair is

\[
p^+=bc=(u^+v^+),\qquad q^+=da=(x^+y^+),\qquad
(u^+,v^+,x^+,y^+)=(b,c,d,a).
\]

## Exact gadget covers

In edge order

\[
(ua,ab,bv,xc,cd,dy,ad,bc),
\]

the six usable traversal types have incidence vectors

\[
\begin{array}{c|c}
D_{11}&11111100\\
D_{10}&10101011\\
D_{01}&01010111\\
X_{vx}&01111010\\
X_{uy}&11001101\\
L&10110111.
\end{array}
\]

The inclusion-minimal sets of types covering all eight gadget edges are
exactly

\[
\begin{gathered}
\{D_{11},D_{10}\},\quad \{D_{11},D_{01}\},\quad
\{D_{10},D_{01}\},\quad \{D_{11},L\},\\
\{X_{vx},X_{uy}\},\quad \{X_{vx},L\},\quad
\{X_{uy},L\}.
\end{gathered}
\]

The two admissible external pairings represented by (L) are different
concrete linkage witnesses, but they have the same local incidence vector;
they therefore need not be split in this set-cover statement.  Availability
of a type is Boolean for new-edge coverage, whereas multiple witnesses can
be essential for coverage of retained old edges.

## Memberwise support transfer

Write

\[
A=C_{11},\quad B=C_{10},\quad C=C_{01},\quad
D=X_{vx},\quad E=X_{uy}.
\]

For the central orientation above, the canonical child witnesses have
origins

\[
A^+\leftarrow B,\qquad B^+\leftarrow E,\qquad
C^+\leftarrow D,\qquad D^+\leftarrow A,\qquad
E^+\leftarrow A.
\]

Every construction retains every parent edge other than (p,q).  Therefore
the support of each concrete retained edge transforms exactly as

\[
(a,b,c,d,e)\longmapsto(b,e,d,a,a).
\]

This assertion is memberwise, not merely a statement about nonempty roles.
For witness families the construction is applied independently to every
member.  In particular, the same (A)-witness may produce both child path
roles; no injectivity, disjointness or multiplicity condition is required.
The closed recurrent package is already

\[
\{A,B,E\}=\{C_{11},C_{10},X_{uy}\}.
\]

The five-role hypothesis used previously is consequently sufficient but
unnecessary.

## Positive-depth support theorem

Suppose the oriented site (p=uv,q=xy) admits three nonempty finite
families:

* ​\(\mathcal A\), Hamilton cycles containing both (p,q);
* ​\(\mathcal B\), Hamilton cycles containing (p) and avoiding (q);
* ​\(\mathcal E\), spanning (u)-(y) paths in (G-\{p,q\}).

Assume only the retained-edge cover

\[
E(G)\setminus\{p,q\}\subseteq
E(\mathcal A)\cup E(\mathcal B)\cup E(\mathcal E),
\tag{1}
\]

where (E(\mathcal W)) denotes the union of the edges of all witnesses in
the family.  Recursively expand the selected central pair with the
orientation above.  Then every positive-depth descendant (G_k),
(k\geq1), is edge-Hamiltonian, and every stage again has nonempty families
satisfying (1) for its selected site.

To prove this, transfer the three families memberwise by

\[
\mathcal A^+\leftarrow\mathcal B,\qquad
\mathcal B^+\leftarrow\mathcal E,\qquad
\mathcal E^+\leftarrow\mathcal A.
\]

Their gadget intersections are respectively

\[
\begin{array}{c|l}
A^+&ua,ad,cd,bc,bv\\
B^+&ua,ab,bc,cd,dy\\
E^+&ua,bv,xc,cd,dy,
\end{array}
\]

whose union is the full gadget.  Thus (1) is inherited.  For
edge-Hamiltonicity of the child, also lift every member of
(\mathcal A) directly.  An old edge supported in
(\mathcal A,\mathcal B,\mathcal E) then lies respectively on a direct
(D_{11})-lift, a cycle in (\mathcal A^+), or a cycle in
(\mathcal B^+).  The direct (D_{11})-lifts together with the
(D_{10})-cycles in (\mathcal A^+) cover all eight gadget edges.  Hence
the child is edge-Hamiltonian, while the inherited three-family cover permits
iteration.

The reflected statement requires simultaneous relabelling, not only an
informal reflection of the drawing.  Under the reflected convention its
core is

\[
\{C_{11},C_{01},X_{vx}\},
\]

and the next oriented pair is (p^+=da,q^+=bc), with the corresponding
endpoint orientations.

## Sharp boundary at depth zero

Condition (1) need not make (G_0) edge-Hamiltonian.  A smallest unrestricted
example has

\[
E(G)=\{02,03,05,12,13,23,24,34,45\},\qquad
(u,v,x,y)=(1,2,3,4).
\]

Thus (p=12,q=34).  The witnesses

\[
\begin{aligned}
A&=0-2-1-3-4-5-0,\\
B&=0-3-1-2-4-5-0,\\
E&=1-3-2-0-5-4
\end{aligned}
\]

have roles (C_{11},C_{10},X_{uy}) and cover every retained edge.  Yet edge
(23) lies on no Hamilton cycle: vertices (1) and (5) have degree two,
and a Hamilton cycle using (23) would be forced to use (12,13), isolating
the triangle on (1,2,3).  Exhaustion of connected simple graphs on four
and five vertices gives no such example, so order six is minimal in the
unrestricted setting.  This proves that the correct conclusion is
(k\geq1), unless edge-Hamiltonicity of (G_0) is separately assumed.

The 240-vertex application of Note 004 is unaffected.  Its base graph has an
independent edge cover by 37 Hamilton cycles, while its selected expansion
site satisfies the three-family support hypothesis.  The former certifies
(G_0); the theorem above certifies every (G_k) with (k\geq1).

## Scope and novelty boundary

These results concern one recursively selected legal central expansion
chain.  They neither prove preservation under every legal expansion nor
resolve Barnette's conjecture.  They are also not presently ready for
submission as an independent short paper.  The local six-state theorem and
the seven covers are elementary interface results, and a bare infinite
edge-Hamiltonian family is already known by simpler constructions.

A remaining literature boundary is Kao and Chen, *A Simple Scheme of
Generating Bipartite Graphs with Fault-tolerant Hamiltonian Properties*
(2005), DOI `10.6358/JCYU.200503.0011`.  Its abstract describes an edge
replacement construction with stronger but differently phrased
fault-tolerant Hamiltonian conclusions, but the full replacement theorem has
not yet been compared with the present four-terminal support mechanism.
Accordingly, the present submission decision is **NO-GO** until that
full-text comparison is resolved and a non-routine class-level consequence
beyond the bare infinite-family construction is obtained.  This is a
boundary on applicability and novelty, not a qualification of the corrected
positive-depth theorem proved above.
