> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The positive-gap bound is sharp for every lobe and face-chord count

[Note 258](258-every-all-square-second-surplus-opening-is-hamiltonian.md)
gives the universal lower bound \(f\ge4r+8\) when a
selected all-square facial opening has a positive interblock
gap. [Note 260](260-a-twenty-two-vertex-sharp-positive-gap-opening.md)
attains it for \(\ell=r=1\). The known incident-edge cube
insertion of [Note 185](185-two-squares-sharing-an-edge-have-a-four-terminal-hamilton-signature.md)
turns *any* equality opening of [Note 190](190-fixed-lobe-chord-amplification-preserves-two-hamilton-witnesses.md)
into a sharp positive-gap opening.

**Uniform insertion and sharpness theorem.** Let \(X\) be
*any* Barnette parent with a legal site expansion at two
disjoint cofacial matching edges \(q=xy,p=uv\notin E(C_X)\)
and a selected all-square equality opening
\(f=4r+2\), where \(\ell,r\ge1\). For every inner
face-chord block of this opening, one incident-edge cube
insertion produces a Barnette parent \(G\) with a selected
opening having the same \(\ell,r\) and
\[
 (\sigma,T,f)=(2,2,4r+8).                              \tag{1}
\]
Its legal site-expanded child is Barnette. Both graphs are
Hamiltonian, and \(G\) has a Hamilton cycle containing
both site edges. The two gap slots form one gap immediately
after the chosen block. Every residual lobe may be replaced
by a ladder of arbitrary positive length.

Such an \(X\) exists for every \(\ell,r\ge1\) by Note 190.

For fixed \(\ell,r\ge1\), the exact minimum parent and child
orders among legal selected all-square positive-gap openings
are respectively
\[
 4r+6\ell+12,\qquad 4r+6\ell+16.                     \tag{2}
\]
For every \(\ell\ge2,r\ge1\), equality can moreover be
attained with both vacant eligible positions in one
*target-bearing* inner face-chord block.

**Proof.** Take any equality parent \(X\) in the theorem,
with its old Hamilton cycle \(C_X\), designated face and
legal site expansion. Compress
the lobes to one square each, if needed, using Note 178.
At equality all interblock gaps are empty by Note 195.
Choose any inner face-chord block
\(B_i=[a,b]_{C_X}\), \(1\le i\le r\), and name its final
two interior slots \(w_1,w_2\). Let \(c\) be the first
vertex of the next block. Thus \(w_2b,bc\) are two distinct
cycle edges incident at \(b\), while \(ab\) is the third
edge there. In particular, neither selected cycle edge is
a site edge.

Apply Note 185's incident-edge insertion to \(w_2b,bc\),
with its six patch vertices labeled
\[
(\alpha,\gamma,\delta,\beta,L,R)
 =(w_3,w_4,w_5,w_6,h,g).                              \tag{3}
\]
Its prescribed attachment edges are \(w_2w_3,w_6b,bg,hc\).
The resulting graph \(G\) has an old Hamilton cycle \(C\)
obtained by replacing \(w_2,b,c\) with
\[
w_2,w_3,w_4,w_5,w_6,b,g,h,c.                          \tag{4}
\]
The new complementary matching edges are exactly
\[
w_3w_6,\qquad w_4h,\qquad w_5g.                       \tag{5}
\]
In the plane incident-edge insertion, the designated
face's boundary segment \(a,b,c\) becomes
\(a,b,g,h,c\). The edges \(w_4h,w_5g\) interlace
\(ab\) along \(C\), so planarity puts them opposite the
designated-face side. The edge \(w_3w_6\) interlaces
\(w_4h\), so it lies on the designated-face side,
inside the \(ab\) block.
Thus the face still contains both site edges and has the
same \(r\) boundary matching chords. The chosen alternating
site-face arc and all residual squares are untouched.
The vertices \(g,h\) make one two-slot interblock gap,
and the chosen block gains four interior slots. Its capacity
\(k_i\) increases by two; the two vacant eligible positions
are its old final slot \(w_2\) and the new slot \(w_4\).
Hence \(\sigma\) increases from zero
to two, \(T\) from zero to two, and \(f\) from \(4r+2\)
to \(4r+8\). This proves (1).

Note 185 makes \(G\) Barnette. The site expansion commutes
with this insertion: the two incident edges are away from the
site, and they persist in the expanded child. Applying
Note 185 to \(X\)'s Barnette child therefore also makes
the new child Barnette. For an explicit marked Hamilton
cycle in \(G\), take the equality cycle \(M_X\cup A_X\)
from Note 196. Since every equality block has even order,
\(A_X\) contains \(w_2b\). Replace just that edge by
\[
w_2,w_3,w_4,h,g,w_5,w_6,b.                            \tag{6}
\]
All seven consecutive pairs are edges of \(G\); its six
new vertices appear once, and both site edges are unchanged.
Note 001 lifts this marked cycle through the legal site
expansion. Note 178 restores arbitrary positive lobe
lengths without changing the exterior marks or (1).

Finally, Note 190 provides such an equality parent for each
\(\ell,r\ge1\). Note 258 gives \(f\ge4r+8\) for every positive-gap
opening in this class. A compressed parent has
\(|V(G)|=f+6\ell+4\), while longer lobes only add vertices;
every site-expanded child has four more vertices. Our
one-square-per-lobe construction attains both lower bounds
in (2).

For the last assertion, use Note 182's equality family when
\(r=1\) and \(\ell\ge2\). Its inner face-chord block
\([a,d]_{C_X}\) contains the escape targets \(L_2,R_1\).
Note 189's first chord amplification replaces \(ad\) by
two boundary face chords, one of which is \(\eta d\);
the block \([\eta,d]_{C_X}\) still contains \(L_2,R_1\).
The subsequent amplifier of Note 190 acts on the newly
created left-hand square and leaves this latter block
unchanged. Thus for every \(r\ge1\) the equality family
has an inner target-bearing block. Choose that block for
the insertion above. Its two new vacancies are in this
target-bearing block, as identified after (5).
\(\square\)

The cube insertion itself is the known operation of
Holton--Manvel--McKay (1985), as restated by
Gorsky--Steiner--Wiederrecht (2023, Section 5). The theorem
establishes uniform sharpness within the selected all-square
positive-gap class. It does not assert that arbitrary
third-surplus positive-gap openings are Hamiltonian or decide
Barnette's conjecture.
