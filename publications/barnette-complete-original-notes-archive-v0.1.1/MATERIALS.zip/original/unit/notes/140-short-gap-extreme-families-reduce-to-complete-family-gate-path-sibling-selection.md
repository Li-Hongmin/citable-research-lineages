> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Short-gap extreme families reduce to complete-family gate-path sibling selection

[Note 139](139-a-one-edge-facial-gap-leaves-only-h-avoiding-11-00-bonds.md)
shows that a short-gap failure of ChildSupplement can only occur when every
parent bond is an \(h\)-avoiding \(11\)--\(00\) bond.  This note proves the
two matching recombinations forced by each such bond, shows that neither
rooted admission nor supplementation follows bondwise, and isolates the
remaining complete-family selection problem.

[Note 145](145-legal-wide-is-essential-for-short-gap-complete-family-compensation.md)
supersedes the unrestricted form of that selection problem: a real
interface-disjoint complete family satisfies the extreme parent antecedent
but has an empty child bond graph. The analytic recombination lemmas below
remain valid, while the unresolved implication in Section 6 must be read
with the historical legal-wide hypothesis.

## 1. Setup

Use the interface-disjoint plane-brace setting of Note 139.  Around the
expanded face write

\[
 p=uv,\qquad q=xy,\qquad
 u,p,v,A,x,q,y,h,u,qquad h=yu,
\tag{1}
\]

and let the child patch have edges

\[
 ua,ab,bv,xc,cd,dy,ad,bc.
\tag{2}
\]

Let \(M,N\) be opposite-sector rooted parent targets with states \(11,00\),
respectively, such that

\[
 C=M\mathbin\triangle N
\tag{3}
\]

is one alternating cycle and \(h\notin N\).  The plane pairing argument in
Note 139 gives the unique decomposition

\[
 C-\{p,q\}=P_{uy}\mathbin{\dot\cup}P_{vx},
\tag{4}
\]

where the paths join \(u\) to \(y\) and \(v\) to \(x\), respectively.
Both paths begin and end with edges of \(N\).

## 2. The forced parent recombination

**Lemma 1 (the \(h\)-toggle).**  The set

\[
 N^h=N\mathbin\triangle\bigl(P_{uy}\cup\{h\}\bigr)
\tag{5}
\]

is a perfect matching of the parent.  It has state \(00\), contains \(h\),
and retains the inherited root and forced-gate edges.  Moreover

\[
 N\mathbin\triangle N^h=P_{uy}\cup\{h\},
\qquad
 M\mathbin\triangle N^h=P_{vx}\cup\{p,h,q\},
\tag{6}
\]

and both right-hand sides are single alternating cycles.

**Proof.**  Along each path in (4), the endpoint edges belong to \(N\) and
membership alternates.  Closing \(P_{uy}\) by \(h\notin N\) therefore gives
an \(N\)-alternating cycle, proving the first equality and perfect-matching
claim.  Since \(M\triangle N=C\), cancellation with (4) gives the second
equality.  The interface-disjoint root and forced gate lie outside the
flipped edges. \(\square\)

Let \(g_1\) be the surviving gate.  It lies on exactly one path in (4).  If
it lies on \(P_{uy}\), rooted admission of \(N^h\) gives an opposite-sector
\(00\)--\(00\) parent bond, contradicting ParentKill.  If it lies on
\(P_{vx}\), rooted admission gives an opposite-sector \(11\)--\(00\) bond
whose \(00\) endpoint contains \(h\), and Note 139 transfers that bond to a
child supplement.  Hence

\[
 \boxed{
 \text{ParentKill and failure of ChildSupplement force every }N^h
 \text{ from a bad bond to be nonrooted.}}
\tag{7}
\]

In particular, in a complete family whose entire bond graph has the extreme
profile of Note 139, every matching (5) is present in the complete
perfect-matching family but necessarily fails rooted admission.

This loss is real.  In the fixed bad pair from Note 139, \(N^h\) has a
Hamiltonian complement rather than two labelled complement cycles.  Thus
perfect-matching closure alone does not preserve the rooted fibre.

## 3. The forced child siblings

Let

\[
 \widehat N=N\cup\{ad,bc\}
\tag{8}
\]

be the canonical \(C_{00}\) child target and define

\[
\begin{aligned}
 S_U&=\widehat N\mathbin\triangle
       \bigl(P_{uy}\cup\{ua,ad,dy\}\bigr),\\
 S_V&=\widehat N\mathbin\triangle
       \bigl(P_{vx}\cup\{bv,bc,cx\}\bigr).
\end{aligned}
\tag{9}
\]

**Lemma 2 (gate-path sibling criterion).**  The sets \(S_U,S_V\) are child
perfect matchings in cells \(X_{uy},X_{vx}\), respectively.  Each differs
from \(\widehat N\) by one alternating cycle.  Exactly one changes the
surviving-gate sector; denote it by \(S_g\).  Then

\[
 \boxed{
 S_g\text{ is rooted-admitted}
 \quad\Longleftrightarrow\quad
 \widehat N-S_g\text{ is a new-cell child rooted bond}.}
\tag{10}
\]

**Proof.**  The endpoint alternation used in Lemma 1 shows that both cycles
in (9) alternate with respect to \(\widehat N\).  Their local patch edges
give the stated cells.  Interface disjointness places \(g_1\) on exactly one
of the exterior paths, so precisely that flip changes its sector.  Since
\(\widehat N\) is already a rooted target and its symmetric difference with
\(S_g\) is the defining single cycle, the only missing bond condition is
rooted admission of \(S_g\). \(\square\)

Thus a counterexample under the extreme antecedent must reject the specified
gate-path sibling for every parent bond, unless an unrelated child matching
supplies a nondirect supplement.

## 4. Bondwise rooted admission is false

The implication

\[
 h\text{-avoiding }11\text{--}00\text{ bond}
 \Longrightarrow S_g\text{ rooted}
\tag{11}
\]

fails in a real legal-wide Barnette fibre.  A fixed order-20 witness is

~~~text
S???????F?Y?b?W_CW?F?AW?KO?`_?g_?
~~~

with root \(1\!-13\), forced gate \(2\!-10\), surviving gate
\(4\!-16\), site \(p=5\!-12,q=3\!-19\), and \(h=5\!-19\).  Its
gate-path sibling is a genuine \(X_{uy}\) perfect matching, lies in the
opposite sector, and is one alternating \(C_8\) flip from the canonical
\(C_{00}\) lift.  Its complement nevertheless has three components, so it
is not rooted.

Across the already frozen 262 short-gap ParentKill fibres through order 26,
there are 278 bad bonds.  Exactly two gate-path siblings are rooted; the
other 276 have three complement components.  This is a finite statement
about that frozen stratum, not an arbitrary-order census.

## 5. Extreme complete families are realizable

The extreme parent profile itself also occurs in a real legal-wide fibre.
In the same frozen stratum there is exactly one such record, first at order
26.  Its graph is

~~~text
Y?????????????w?Y?CW?Ao??w?@K?S_?cC?CQ??`C??a_?W?_??q???
~~~

with root \(1\!-13\), forced gate \(0\!-14\), surviving gate
\(7\!-16\), and facial site

\[
 (6,19,9,17,10,25),qquad
 p=6\!-19,\quad q=10\!-25,\quad h=25\!-6.
\tag{12}
\]

Its complete parent rooted fibre has states and sectors

\[
 (11,11,00,00),\qquad (1,1,0,0),
\tag{13}
\]

and its bond graph consists of two \(h\)-avoiding \(11\)--\(00\) edges.
Thus the assertion that an extreme complete family is unrealizable is
false.

For both bonds, \(N^h\) is nonrooted, but the gate-path sibling \(S_g\) is
rooted in \(X_{uy}\).  The two resulting
\(C_{00}\)--\(X_{uy}\) bonds are exactly the complete child supplement.
The child fibre has eight targets with histogram

\[
 C_{00}^{,2},\quad R_{00}^{,2},\quad
 X_{uy}^{,2},\quad X_{vx}^{,2}.
\tag{14}
\]

The two successful gate-path siblings are the only rooted ones among all
278 bad bonds in the frozen scope.  Consequently the data support the
complete-family extreme implication while providing only one family that
tests it.  They do not prove that implication.  The order-26 minimum is
only within the frozen root-opposite-square legal-wide stratum.

## 6. Exact remaining boundary

The short-gap problem has now passed from local transfer to complete-family
selection.  Any counterexample must simultaneously satisfy

\[
\begin{array}{ll}
\text{(i)}&\text{every parent bond is }h\text{-avoiding }11\text{--}00;\\
\text{(ii)}&\text{every associated }N^h\text{ is nonrooted};\\
\text{(iii)}&\text{every associated gate-path sibling }S_g\text{ is nonrooted};\\
\text{(iv)}&\text{the complete child family has no unrelated new-cell bond.}
\end{array}
\tag{15}
\]

Items (i)--(ii) are forced by Notes 139 and Lemma 1.  Item (iii) cannot be
proved bondwise by Lemma 2, and item (iv) is genuinely a complete-family
condition.  The precise unresolved statement is therefore

\[
 \boxed{
 \begin{minipage}{0.82\linewidth}
 For a legal-wide decoration, if every bond in a complete short-gap
 ParentKill family has the extreme profile, must at least one gate-path
 sibling be rooted, or must some other child perfect matching supply a
 new-cell rooted bond?
 \end{minipage}}
\tag{16}
\]

The fixed realizability claims and finite counts are verified by the
[short-gap extreme-family boundary bundle](../computations/bundles/short-gap-extreme-family-boundary/README.md).
