> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first two-sided vacant shared block has three spanning routes

Note 292 shows that a vacant block shared by two
consecutive missing links belongs to a third,
vacancy-only atom component. If its vacancy atom
is internal in that component, the component has
at least three vacancies. With one vacancy for
each port component, the total is at least five.
This bound is attained by a Barnette parent whose
entire shared-block interval has \(S,K,X\).

Use the compressed, gapless, tight-target all-square
opening and the block notation of Notes 275 and 281.
Take \(\ell=1,r=7\), vacant
\[
 B_1,B_2,B_4,B_6,B_7,
\]
and short \(B_3,B_5\). Retain all standard free
links except \(P_3=e_3o_4\) and
\(P_4=e_4o_5\). Along with the unchanged site,
face, escape, and residual-square matching edges
of Note 281(8)--(9), add
\[
\begin{array}{lll}
H_1I_7,&I_1H_4,&I_4H_7,\\
H_2o_4,&I_2e_3,&\\
e_4I_6,&o_5H_6.&
\end{array}                                             \tag{1}
\]
The first row is the vacancy-only part
\(\{V_1,V_4,V_7\}\); the second is
\(\{V_2,P_3\}\); the third is
\(\{P_4,V_6\}\). Thus \(V_4\), in the
shared block, is internal in its part.

**Sharp two-sided example.** This matching produces
a 50-vertex Barnette parent with a Hamilton cycle
through both site edges and a legal 54-vertex
Hamiltonian child. The interval
\(Q=B_1,\ldots,B_7\) has all three
vertex-spanning four-port states
\[
S(Q):o_1\longleftrightarrow e_7,\qquad
K(Q):a_1\longleftrightarrow o_1,\
e_7\longleftrightarrow b_7,\qquad
X(Q):a_1\longleftrightarrow b_7,\
o_1\longleftrightarrow e_7.                         \tag{2}
\]
Five vacancies are necessary for any configuration
in which the shared-block vacancy is internal in
its vacancy-only part: that part has at least
three atoms, and Note 278 puts each port in a
different part with at least one vacancy.

**Planarity and connectivity.** The edges of (1)
pair all ten vacancy slots and the four ends of
the two missing links exactly once. Each joins
opposite old-cycle colours. On the side of the
old cycle opposite the common site face,
\(H_1I_7\) encloses the other special chords.
The intervals of \(I_1H_4\) and \(I_4H_7\)
are disjoint; the former encloses both
\(H_2o_4,I_2e_3\), and the latter encloses
\(e_4I_6,o_5H_6\). The retained standard
links occupy nested or disjoint intervals.
Hence this is a crossing-free two-page drawing,
with cofacial site edges.

The retained standard links connect the face
chords through \(B_3\) and from \(B_5\)
through \(B_7\). The chords \(H_1I_7\)
and \(I_1H_4\) attach \(B_4\) to the left
segment; \(e_4I_6\) attaches it to the right.
Every other edge of (1) interlaces an endpoint
face chord. The retained end links connect the
site and residual-square closing chain. Thus
the matching-chord interlacement graph is
connected, ruling out a two-edge cut by Note
217. Note 182's cubic lemma gives three-vertex
connectivity. The block count is
\(4r+12+2\cdot5=50\); Note 001's legal
expansion adds four vertices.

**Three routes.** A straight route is
\[
\begin{split}
o_1,a_1,b_1,a_2,o_2,e_1,I_1,H_1,I_7,H_7,I_4,H_4,\\
o_4,H_2,I_2,e_3,o_3,e_2,b_2,a_3,b_3,a_4,b_4,\\
e_4,I_6,H_6,o_5,a_5,b_5,e_5,o_6,a_6,b_6,e_6,\\
o_7,a_7,b_7,e_7 .
\end{split}                                             \tag{3}
\]
The matching edges used by (3), in order, are
\(o_2e_1,H_1I_7,H_7I_4,o_4H_2,
I_2e_3,o_3e_2,e_4I_6,H_6o_5,
e_5o_6,e_6o_7\). Its other joins are
old-cycle edges or face chords.

For the cap state, keep the path \(e_7b_7\).
The other path begins
\[
\begin{split}
a_1,b_1,a_2,b_2,e_2,I_2,e_3,o_3,a_3,b_3,
a_4,o_4,H_2,o_2,e_1,I_1,H_4\\
\xrightarrow{C\text{ forward}}I_7,H_1,o_1 .
\end{split}                                             \tag{4}
\]
The old-cycle arc from \(H_4\) to \(I_7\)
includes \(I_4,e_4,b_4\), all of
\(B_5,B_6\), and \(a_7,o_7,H_7,I_7\).
Equation (4) covers the remaining vertices
of \(B_1,\ldots,B_4\) exactly once and leaves
only \(e_7,b_7\) for the right cap.

For the crossed state, the bottom path is
\[
 o_1,H_1,I_7,e_7.                                  \tag{5}
\]
The top path is
\[
\begin{split}
a_1,b_1,e_1,I_1,H_4,o_4,H_2,o_2,a_2,b_2,
e_2,I_2,e_3,o_3,a_3,b_3,a_4,b_4,\\
a_5,o_5,H_6,o_6,e_5,b_5,a_6,b_6,e_6,I_6,
e_4,I_4,H_7,o_7,a_7,b_7 .
\end{split}                                             \tag{6}
\]
All non-cycle joins in (3)--(6) are in (1),
are retained ordinary links, or are the face
chords \(a_jb_j\). In (3) every block vertex
appears exactly once. In (4) the cap uses
precisely the two vertices omitted by the
other path. In (5)--(6), the bottom uses
\(o_1,H_1,I_7,e_7\) and the top uses
all other vertices once. This verifies the
three pairings in (2). Attach \(S(Q)\) to
the retained group end links and the fixed
target-and-square path of Note 196; Notes 273,
001, and 178 give the asserted parent and child
Hamilton cycles. \(\square\)

This sharp example does not prove a general
two-sided shared-vacancy theorem. Its route
shows that the first two-sided component
configuration has no three-state obstruction;
the arbitrary-length joint-boundary splice
remains to be established.
