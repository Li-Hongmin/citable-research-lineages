> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An outside site vacancy composes with a cross-block transition

[Note 236](236-an-isolated-second-vacancy-composes-with-one-target-defect.md)
composes a cross-block transition defect with a spare vacancy
in an internal face block outside the defective interval.
The two site blocks require a separate boundary argument.
At the left site, an occupied target after the spare vacancy
would trap its adjacent free pair; otherwise that pair makes
one ordinary free-path detour and does not disturb the
transition repair.

Let \(G,C,M\) be a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps and \(s=2\), hence
\(f=4r+6\). Assume \(d_L=d_R=0,b=1\), and let the sole
defective transition be \(L_j\in B_i\),
\(R_{j-1}\in B_h\), \(2\le j\le\ell\), \(i<h\).
Suppose the spare vacancy lies in the left site block
\(B_0=[x,y]_C\), strictly before the source block, so \(i>0\).
Write \(H\) for that vacant even slot and \(I\) for its
following odd free slot. The other vacancy lies between the
two defective targets.

**Outside-site composition theorem.** No occupied target
follows \(H,I\) in \(B_0\). Let \(R_s\) be the final target
before \(H\), and \(L_s\) the next target, in a later block
\(B_m\). Necessarily \(m\ge2\), and for some
\(t\in\{2,\ldots,m\}\), the complete free matching is
\[
M_{\rm free}=
\{Ho_t,Ie_{t-1},c_iw\}
\cup\{e_a o_{a+1}:0\le a\le r,\ a\ne t-1\},
                                                        \tag{1}
\]
where \(c_i,e_i\) are the free slots after \(L_j\), and
\(o_h,w\) the free slots before \(R_{j-1}\). The parent
has a Hamilton cycle containing both site edges \(xy,uv\),
and its legal site-expanded child is Hamiltonian. Reflection
handles a spare vacancy in the right site block strictly
after the defective destination block. Original lobes may
have arbitrary positive lengths.

**Target and vacancy locations.** The first target
\(R_\ell\) is the first interior slot of \(B_0\), and all
transitions before the sole defect are tight. If a target
followed \(H,I\) in \(B_0\), consider the first such target.
Exactly the adjacent pair \(H,I\) of free slots precedes it
after the previous occupied run. A free chord from either
slot to a later block would straddle that target and is
forbidden by [Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md).
Only the final free slot \(e_0\) of \(B_0\) could receive a
same-block chord across the target; the free prefix has even
size, so matching parity excludes that one chord. The pair
\(H,I\) would have to match itself, but \(HI\in E(C)\).
Hence the block has no later target and ends with
\(H,I,e_0,y\). The target immediately before \(H\) is an
\(R_s\), and the next is \(L_s\) in a later block.

As in [Note 212](212-every-gapless-first-surplus-opening-has-a-marked-hamilton-cycle.md),
the defective destination cannot be the first slot of
\(B_h\): the earlier complete main prefix plus squares
\(S_j,\ldots,S_\ell\) would expose a two-edge cut. Since
the site vacancy uses one eligible position, the destination
is third, preceded by \(o_h,w\). The source \(L_j\) is last
eligible in \(B_i\), followed by \(c_i,e_i\); all blocks
strictly between them are short. The site vacancy is before
that interval, so it changes each relevant free-prefix count
by two and leaves the even-prefix barriers intact. Note 212's
noncrossing and two-edge-cut argument forces
\[
c_iw\in M,
\qquad e_a o_{a+1}\in M\quad(i\le a<h).
                                                        \tag{2}
\]

**The left-site free group.** No target lies between
\(R_s,L_s\), so each complete face block strictly between
\(B_0,B_m\) is short. The free group in that interval has
order
\[
H,I,e_0,o_1,e_1,\ldots,o_m.               \tag{3}
\]
No two of its same-block free slots can form a complementary
matching edge: \(HI,Ie_0,o_a e_a\) are old-cycle edges,
and \(H,e_0\) have the same colour. Thus every chord in
(3) is cross-block, lies opposite the common site face by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
and belongs to one noncrossing disk. The even slot \(H\)
must match some \(o_t\). If \(t=1\), the enclosed pair
\(I,e_0\) would have to match despite being adjacent on
\(C\). Hence \(t\ge2\), so \(m\ge2\). Noncrossing and the
short-block skipping rule of
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md)
force \(Ie_{t-1}\) inside \(Ho_t\): an earlier mate would
leave a complete short-block interval internally matched,
either an old-cycle pair or a forbidden two-edge cut.
All other slots in (3), and every other ordinary free group,
take standard links. Combined with (2), this proves (1).

**Marked Hamilton route.** Start with Note 196's two paths.
In its target-and-square path, replace the missing transition
by \(L_j,c_i,w,R_{j-1}\). In its ordinary free path,
replace \(e_{t-1}o_t\) by
\[
e_{t-1},I,H,o_t.                              \tag{4}
\]
The first and last edges of (4) are in \(M\), while
\(IH\in E(C)\). The two replacements use disjoint free
groups, so the resulting paths meet only at \(x,v\) and
cover the parent. Their union is a Hamilton cycle through
\(xy,uv\). [Notes 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
and [178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
give the legal child and longer lobes. \(\square\)

**A 30-vertex realization.** Take
\(r=2,\ell=2,i=2,h=3,j=s=2,m=t=2\). The old cycle
has blocks
\[
\begin{array}{ll}
B_0:&x,R_2,H,I,e_0,y,\\
B_1:&a_1,o_1,e_1,b_1,\\
B_2:&a_2,o_2,L_2,c_2,e_2,b_2,\\
B_3:&u,o_3,w,R_1,L_1,v,\\
S_1,S_2:&\alpha_q,\gamma_q,\delta_q,\beta_q
\quad(q=1,2),\text{ returning to }x.
\end{array}                                             \tag{5}
\]
Add the fixed matching chords \(xy,a_1b_1,a_2b_2,uv\)
and \(\alpha_q\beta_q,R_q\delta_q,L_q\gamma_q\)
for \(q=1,2\), together with the free chords
\[
Ho_2,\quad Ie_1,\quad e_0o_1,\quad c_2w,
\quad e_2o_3.                                      \tag{6}
\]
The marked Hamilton cycle is the union of
\[
\begin{split}
&x,R_2,\delta_2,\beta_2,\alpha_2,\gamma_2,L_2,
c_2,w,R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v,\\
&x,y,e_0,o_1,a_1,b_1,e_1,I,H,o_2,a_2,b_2,e_2,o_3,u,v.
\end{split}                                             \tag{7}
\]
Every consecutive pair in (7) is an old-cycle edge or one
of the listed matching edges. The paths share only \(x,v\)
and cover all 30 vertices.

Every matching pair joins opposite old-cycle parities,
and \(x,u\) have the same parity. Draw the site, face
and \(\alpha_q\beta_q\) chords as disjoint intervals on
one side of \(C\). On the other, the escape chords nest
in target order. The free chords form two disjoint nests:
\(Ho_2\supset Ie_1\supset e_0o_1\) before \(L_2\gamma_2\),
and \(c_2w\supset e_2o_3\) between \(L_2\gamma_2\)
and \(R_1\delta_1\). This is a simple cubic bipartite
plane graph with cofacial site edges. Its matching-chord
interlacement graph is connected: one spine is
\[
xy-Ho_2-a_2b_2-c_2w-uv-L_1\gamma_1-
\alpha_1\beta_1-R_1\delta_1-uv,
                                                        \tag{8}
\]
while \(Ie_1,e_0o_1,a_1b_1\) attach through \(Ho_2\)
or each other, \(e_2o_3\) attaches to \(a_2b_2\),
and \(L_2\gamma_2,\alpha_2\beta_2,R_2\delta_2\)
attach through \(a_2b_2,\alpha_2\beta_2,xy\), respectively.
[Note 217](217-vacancy-squares-absorb-across-arbitrarily-long-short-block-ladders.md)
therefore proves three-connectivity of the parent and its
34-vertex legal site expansion; (7) and Note 001 give their
Hamilton cycles.

This closes the outside-site spare-vacancy placements for a
cross-block transition, by reflection for the right site.
Other same-source or same-destination placements, interblock
gaps, nonsquare residual cycles and Barnette's conjecture
remain undecided.
