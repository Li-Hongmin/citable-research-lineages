> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two free vacancies with flanks have at most two chain defects

[Note 220](220-two-vacancy-free-groups-have-only-three-boundary-states.md)
excludes same-block free chords and noncanonical ordinary-to-ordinary
edges when two vacant blocks have no short-block flanks. These two
exclusions survive arbitrary short-block flanks. This leaves at most
two altered ordinary chain links throughout the target-free
two-vacancy group.

Use a compressed all-square Barnette opening with \(\ell,r\ge1\),
empty interblock gaps, tight target order, and precisely two
eligible vacancies. Suppose they lie in distinct target-free
four-slot face blocks \(B_k,B_m\), \(1\le k<m\le r\), in the
same free matching group. Write the group's endpoints as
\(e_a,o_b\), where \(0\le a<k<m<b\le r+1\).
Every face block strictly between \(B_a\) and \(B_b\), except
\(B_k,B_m\), is short and target-free. The free-slot order is
\[
e_a,o_{a+1},e_{a+1},\ldots,
o_k,h_k,i_k,e_k,\ldots,
o_m,h_m,i_m,e_m,\ldots,o_b.                    \tag{1}
\]
The ellipses contain only ordinary \(o_j,e_j\) pairs.
The endpoint blocks \(B_a,B_b\) may have occupied target runs.

**Two-defect structural theorem.** Neither same-block free
chord \(o_ke_k,o_me_m\) belongs to the complementary
matching \(M\). Every free matching edge with both endpoints
among the ordinary slots
\[
e_a,o_{a+1},e_{a+1},\ldots,o_{b-1},e_{b-1},o_b
\]
is a standard chain edge \(e_jo_{j+1}\), \(a\le j<b\).
If \(c\) matching edges join pairs of the four extra slots
\(h_k,i_k,h_m,i_m\), exactly \(2-c\) standard chain
edges are missing. In particular, at most two chain links
can be altered, independent of both flank lengths.

**Proof: same-block chords.** Suppose \(o_ke_k\in M\).
The even free slot \(h_k\) cannot match its old-cycle
neighbour \(i_k\) or the already matched \(o_k\).
Its odd mate is either an ordinary first slot \(o_j\)
elsewhere in the group or the extra slot \(i_m\).

Consider \(h_ko_j\). Both endpoints have opposite
bipartition colours. The free slots in (1) alternate
in colour, so an even number lie strictly between them.
Exactly one endpoint of \(o_ke_k\) lies in that interval:
\(o_k\) if \(o_j<h_k\), and \(e_k\) if \(o_j>h_k\).
No other same-block free chord can have exactly one
endpoint inside. Indeed, the only candidate is \(o_me_m\);
both its endpoints lie outside the interval when \(o_j\)
precedes \(B_m\), both lie inside when \(o_j\) follows
\(B_m\), and \(o_j=o_m\) uses one of its endpoints.
Every cross-block free chord lies in the opposite-side
disk by Note 193 and cannot cross \(h_ko_j\).
After the one endpoint matched through \(o_ke_k\)
is removed, an odd number of internal free slots would
have to match among themselves, impossible.

Thus \(h_k\) could only match \(i_m\). The free interval
strictly between \(h_k,i_m\) again has even size and has
one endpoint of \(o_ke_k\) inside. Its only possible
second same-block exit is \(o_me_m\): here \(o_m\) is
inside and \(e_m\) outside. Parity therefore forces
\(o_me_m\in M\). Now the complete consecutive
old-cycle interval \(B_k,\ldots,B_m\) is closed
under \(M\). Its block-closing face chords and both
same-block chords are internal. Every other free slot
lies strictly inside the opposite-side chord
\(h_ki_m\), so its matching edge cannot leave
without crossing that chord. The interval has only
two outgoing old-cycle edges, contradicting
three-edge-connectivity. Hence \(o_ke_k\notin M\).
Reflection gives \(o_me_m\notin M\). All free
matching edges consequently join different blocks
and lie in the same noncrossing opposite-side disk.

**Proof: ordinary edges and defect count.** Consider a
free edge \(e_io_j\) with two ordinary endpoints.
If \(j=i+1\), it is standard. If \(j\ge i+2\),
its opposite-side chord encloses the nonempty
complete target-free block interval
\(B_{i+1},\ldots,B_{j-1}\). Noncrossing makes
that interval matching-closed, a forbidden two-edge
cut. If \(j=i\), the edge is a same-block chord
already excluded. If \(j<i\), the chord from
the first free slot of \(B_j\) to the last
free slot of \(B_i\) encloses every free slot
of the complete interval \(B_j,\ldots,B_i\).
An edge leaving that interval would cross the
chord, while its face-chord endpoints are
internally matched; this is again a two-edge cut.
Thus every ordinary-to-ordinary matching edge is
standard.

The ordinary chain pairs all ordinary slots.
Each missing chain edge has its two endpoints
matched to extra slots, because no other
ordinary-to-ordinary edge is available. If
\(c\) extra-to-extra matching edges occur,
\(4-2c\) extra slots match ordinary slots.
Hence the number of missing chain edges is
\((4-2c)/2=2-c\). \(\square\)

The theorem does not decide Hamiltonicity when the
two missing chain links reconnect in a way that
creates a separate alternating cycle. The no-flank
case is settled by
[Note 221](221-every-isolated-two-vacancy-corridor-has-a-marked-hamilton-cycle.md).
[Note 223](223-two-target-free-vacancies-in-one-group-always-have-a-marked-hamilton-cycle.md)
subsequently excludes every crossed reconnection using
planarity or a two-edge cut, and settles arbitrary flanks.
Target-bearing vacancy blocks, two vacancies in one
block, gap slots and nonsquare residual cycles lie
outside this statement.
