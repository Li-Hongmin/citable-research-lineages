> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Middle-block near-equality Hamilton routes and the two-deep-side obstruction

[Note 199](199-single-lobe-one-face-chord-eight-free-vertices-have-hamiltonian-children.md)
settles the single-lobe case at \(r=1,f=8\). The same
six-free-slot interface persists with arbitrarily many
lobes. When the unique vacant eligible slot is in the
middle face-chord block and the escape-target order has
no endpoint or transition defect, its complementary
matching has exactly three possible patterns. Two directly
give a Hamilton cycle; the third is repaired by one
alternating square whenever either side of the vacancy
contains a single target pair.

Work in the one-square-per-lobe compressed setting of
Notes 176--179. Let a Barnette parent \(G\) have a
Hamilton cycle \(C\) avoiding the cofacial site matching
edges \(q=xy,p=uv\). Assume the chosen all-square facial
opening has \(r=1\), \(f=8\), and \(\ell\ge1\) lobes.
By [Note 198](198-one-face-chord-excludes-two-gap-near-equality.md),
all block gaps are empty. Write the three blocks as
\(B_0=[x,y]_C\), \(B_1=[a,b]_C\), and \(B_2=[u,v]_C\).

Assume further that:

1. \(R_\ell\) is the first interior slot of \(B_0\);
2. \(L_1\) is the final interior slot of \(B_2\);
3. each \(L_j,R_{j-1}\), \(j\ge2\), is adjacent on \(C\);
4. the unique eligible even position not occupied by a
   nonfinal \(L_j\) lies in \(B_1\).

These assumptions describe one branch of Note 197's
one-defect budget; they are not asserted for every opening.
The free interior slots, in \(C\)-order, are
\[
e,\ g,\ h,\ i,\ j,\ z,
\qquad\text{with colours }E,O,E,O,E,O.
\tag{1}
\]
Here \(e\) is the final slot of \(B_0\), \(g\) the first
slot of \(B_1\), \(h\) the vacant eligible slot, \(i\)
the next slot, \(j\) the final slot of \(B_1\), and
\(z\) the first slot of \(B_2\). In particular
\(hi\in E(C)\), whereas \(gh\) and \(ij\) may each
span a run of escape targets.

**Middle-block routing theorem.** The free-slot part of
the complementary matching \(M=E(G)\setminus E(C)\)
must be one of exactly these three patterns, with a
same-block edge allowed only when its endpoints are
nonadjacent on \(C\):
\[
\begin{array}{c|c}
\text{left route}&ei,\ gh,\ jz\\
\text{right route}&eg,\ hz,\ ij\\
\text{double inner route}&ez,\ gh,\ ij.
\end{array}
\tag{2}
\]
The left and right routes give Hamilton parent cycles
containing both site edges. The double inner route gives
exactly two cycles in \(M\cup A\), where \(A\) is the
even-starting matching of \(C\) indexed from \(x\).
If either \(gh\) or \(ij\) spans exactly one adjacent
target pair \(L_t,R_{t-1}\), one alternating-square
flip joins those two cycles, again giving a Hamilton
parent cycle through \(p,q\). Consequently the legal
site-expanded child is Hamiltonian in all these cases.
In particular, under the four assumptions above it is
Hamiltonian whenever \(\ell\le4\).

**Proof.** The slot description follows from capacity:
\(k_0+k_1+k_2=\ell\), exactly \(\ell-1\) eligible
positions hold nonfinal \(L\) targets, and the sole
vacancy is in \(B_1\). The tight transitions pair each
such \(L\) with the following odd \(R\) inside its block.
The first and last targets use one slot in \(B_0,B_2\),
respectively. Hence those outer blocks each have one
free slot, and \(B_1\) has four, in the order (1).

Any matching edge joining different blocks lies opposite
the common face by Note 193, so such edges are noncrossing.
Inside \(B_1\), the opposite-colour pairs are
\(gh,hi,ij,gj\); \(gi\) joins two \(O\) slots and
\(hj\) joins two \(E\) slots. The pair \(hi\)
is a cycle edge and cannot belong to \(M\). Thus the
only possible same-block free chords are \(gh,ij,gj\).

There are six bipartite perfect matchings of the three
\(E\) slots \(e,h,j\) to the three \(O\) slots
\(g,i,z\). Two contain the forbidden \(hi\). Of the
other four, the matching \(ei,hz,gj\) is impossible:
its cross-block chords \(ei\) and \(hz\) interlace on
the common opposite side. The remaining three are
precisely (2). This proves the classification. In the
left and right routes, the vertices outside the residual
squares and escape targets form, respectively, the
following \(M\cup A\) paths from \(x\) to \(v\):
\[
\begin{aligned}
P_{\rm left}&:x,y,e,i,h,g,a,b,j,z,u,v,\\
P_{\rm right}&:x,y,e,g,a,b,j,i,h,z,u,v.
\end{aligned}
\tag{3}
\]
The edges \(xy,ab,uv\) and the free-slot pairs in (2)
belong to \(M\); the remaining displayed edges belong
to \(A\). The target and residual-square vertices form
a second \(M\cup A\) path from \(x\) to \(v\):
\[
x,R_\ell,\delta_\ell,\beta_\ell,\alpha_\ell,
\gamma_\ell,L_\ell,R_{\ell-1},\ldots,
R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v.
\tag{4}
\]
Here the edges \(L_tR_{t-1}\) belong to \(A\) by
assumption 3; for \(\ell=1\), (4) is simply
\(x,R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v\).
Paths (3) and (4) have only their endpoints
in common and cover all vertices, so either pair forms
one Hamilton cycle containing \(xy,uv\).

For the double inner route, the site path
\(x,y,e,z,u,v\) and target path (4) form one cycle
of \(M\cup A\). The other is
\[
a,g,h,i,j,b,a.
\tag{5}
\]
If \(gh\) spans just the consecutive target pair
\(L_t,R_{t-1}\), the four edges
\[
gL_t,\quad L_tR_{t-1},\quad R_{t-1}h,\quad hg
\tag{6}
\]
form a square. In \(M\cup A\), \(L_tR_{t-1}\) lies
on the first cycle and \(hg\) on (5); the other two
edges are outside the factor. Flipping (6) therefore
joins the two cycles into one. The same argument applies
to \(ij\) when its interior consists of one adjacent
target pair. The flip changes neither site edge.

For the final numerical claim, the numbers of target
pairs strictly between \(g,h\) and \(i,j\) are both
positive whenever the double inner route exists:
otherwise \(gh\) or \(ij\) would duplicate a cycle
edge. If neither number were one, they would total at
least four. Together with the vacant eligible position
this gives \(k_1\ge5\); since \(k_1\le\sum k_i=\ell\),
we would have \(\ell\ge5\). Thus \(\ell\le4\)
forces one of the square flips above. Finally Note 001
lifts the resulting parent cycle through the legal site
expansion, and Note 178 restores any original lobe
length. \(\square\)

The remaining double inner route with at least two target
pairs on **each** side of the vacancy is a precise
unresolved case of this branch. The obstruction is to this
specific alternating-factor construction. Its two-cycle factor
does not establish that the parent or child lacks any
other Hamilton cycle.

[Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md)
subsequently excludes this route, and in fact every middle-vacancy
route in (2), by checking each cross-block free chord against the
fixed escape chords on the opposite side of \(C\).
