> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Separated vacancies compose marked Hamilton routes

[Notes 208--209](209-every-tight-gapless-internal-vacancy-at-first-surplus-is-hamiltonian.md)
classify a single eligible vacancy at the first free-vertex
surplus. Their matching barriers and detours are local to the
free-slot interval between occupied target runs. Thus several
vacancies can be handled at once when those intervals separate them.

Let \(G\) be a Barnette parent with a Hamilton cycle \(C\) avoiding
the disjoint cofacial matching site edges \(q=xy,p=uv\). Select an
all-square facial opening and compress its lobes to one square each
as in Note 178. Let \(\ell,r\ge1\), assume all interblock gaps
are empty, and assume tight target order:
\(R_\ell\) is the first slot of \(B_0\), \(L_1\) is the final
slot of \(B_{r+1}\), and \(L_jR_{j-1}\in E(C)\) for all \(j\ge2\).
Call an eligible even block position *vacant* when it does not hold
a nonfinal \(L\)-target, as in Note 197.

**Separated-vacancy theorem.** Suppose no block has more than one
vacancy, and an occupied \(L\)-target lies strictly between every
two vacant positions along the main \(C\)-segment. Then \(G\) has a Hamilton
cycle containing both \(p,q\), and its legal site-expanded child is
Hamiltonian. The number of vacancies is unrestricted.

In particular, at \(f=4r+6\), two vacancies separated
by an occupied target cannot belong to a non-Hamiltonian child.
The conclusion also holds for arbitrary positive original lobe
lengths.

**Proof.** Let \(s\) be the number of vacancies. Note 197's
counting identity gives \(f=4r+2+2s\). Since the endpoint
targets are tight, every vacant position is a genuinely free
even slot \(h\), and its following odd slot \(i\) is free as well:
if \(i\) were an \(R\)-target, its immediately preceding
\(L\)-target would have to be \(h\). Thus each vacancy adds
precisely the adjacent free pair \(h,i\) to the ordinary free
slots. A face block without a vacancy has its free first odd
slot \(o_k\) and final even slot \(e_k\); a block with one
vacancy has \(o_k,h,i,e_k\). The left site block normally
has only its final free slot \(e_0\), and the right site
block only its first free slot \(o_{r+1}\).

First peel any occupied boundary target pairs before a vacancy
in \(B_0\), or after one in \(B_{r+1}\), using Note 186.
Each inverse is simple until its vacancy reaches the first
eligible position from that side, exactly as in Note 210.
Peeling removes no separator target between two vacancies,
does not change any other vacancy block, and preserves
gaplessness and tight target order. It also preserves the
ability to lift a reduced parent cycle through both site
edges: at the shared boundary vertex such a cycle uses
its site edge and one of the two restored edges, and
Note 185 supplies a spanning one-path route for either
choice. We work in the reduced parent and reverse these
peels after constructing its marked Hamilton cycle.

Every occupied target run is a barrier for the free matching.
Before its first \(L\)-target, the ordinary free-slot prefix
has even size, as in Note 208. Each earlier vacancy contributes
two more free slots, so the prefix remains even. A free edge
joining different blocks cannot straddle the target by
[Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md).
Within its block, at most one free edge can cross the run.
Indeed, with no vacancy its only possible crossing is
\(o_ke_k\); with one vacancy before the run only \(e_k\)
is free after it, and with one vacancy after the run only
\(o_k\) is free before it. In either outer block, the
free slots on one side of an occupied target run number
at most one when that block has a vacancy; without one
the bound is stronger. The number of matching
edges leaving an even set must be even, so no free matching
edge crosses any occupied target run.

The free slots therefore divide into consecutive groups between
those runs. By the hypothesis on separation, each group contains
at most one vacancy. An ordinary group has Note 208's sequence
\(e_a,o_{a+1},e_{a+1},\ldots,e_{b-1},o_b\), with only short
intervening blocks. All its matching edges join distinct blocks,
lie in the opposite-side disk by Note 193, and are noncrossing.
The short-block skipping rule of Note 196 forces
\(e_t o_{t+1}\) throughout that group.

Consider a group with one vacancy in an internal block \(B_k\).
If occupied target
runs lie on both sides of its vacant pair \(h,i\) within \(B_k\),
the barriers isolate exactly \(h,i\) between those runs. They
are adjacent on \(C\) and cannot be paired by the complementary
matching, so this shape is impossible. Otherwise the group's
free-slot order is exactly one of the local forms (2)--(3) of
Note 208 or (3)--(4) of Note 209: the vacancy has targets only
on one side of its block, or no target in that block. Those
proofs use only the group's noncrossing chords, the forbidden
old-cycle edges and the two-edge-cut skipping rule; all hold
here because the other vacancies are behind target barriers.
Consequently this group has the ordinary chain except for
one replacement
\[
 e_{d-1}o_d\ \longmapsto\
 \{e_{d-1}i,\;h o_d\}
\tag{1}
\]
for a suitable \(d\) in that group. For a one-sided vacancy
with targets to its left, use the reflected form of Note 208.
The proof of Note 209 also excludes its only possible
same-block free chord \(o_ke_k\) when the block is target-free;
no other vacancy enters that parity argument.

It remains to classify an exceptional group at an outer block.
After the boundary peels, a left vacancy is the second
interior slot \(s\) of \(B_0\), followed by the free odd
slot \(t\). Note 210's mate argument is local: if \(B_0\)
had a later occupied target, \(s\) would have no mate;
if \(B_1\) had an occupied target, \(t\) would have no
mate. Separation excludes a second vacancy before that
target, so the argument applies unchanged. Thus \(B_0\)
has exactly four interior slots and \(B_1\) is short.
The first free group contains only this vacancy, and
Note 210's noncrossing classification replaces one
ordinary chain edge \(e_{d-1}o_d\) by
\(\{e_{d-1}t,\;s o_d\}\). Its free path inserts
\(e_{d-1},t,s,o_d\). A right outer vacancy has the
reflected final-group route. These outer routes touch
no other exceptional group.

Different exceptional groups use disjoint chain edges
and disjoint vacant pairs. Let \(A\) be the even-starting
old-cycle matching from \(x\). Tight targets and the residual
squares give the \(x\)-to-\(v\) path (4) of Note 196. Its
other \(x\)-to-\(v\) path (5) follows the ordinary free chain.
For each internal exceptional group, replace its edge
\(e_{d-1}o_d\) by \(e_{d-1},i,h,o_d\);
the two outer edges come from (1), and \(ih\in A\).
Insert the corresponding Note 210 segment for any outer
group. Because the groups are disjoint, all replacements
commute and the resulting free path visits every added
slot exactly once. It shares
only \(x,v\) with the target-and-square path, so their union
is one Hamilton cycle containing \(xy,uv\). Reverse the
boundary peels; the marked Note 185 routings retain both
site edges in the original compressed parent. Note 001
then lifts that cycle through the legal site expansion,
and Note 178 restores the original lobe lengths.
\(\square\)

The theorem gives a compositional Hamilton mechanism without
a fixed bound on \(s\). It does not handle two vacancies
in one block or one free-slot group,
target-order defects, gap slots, or nonsquare residual cycles.
