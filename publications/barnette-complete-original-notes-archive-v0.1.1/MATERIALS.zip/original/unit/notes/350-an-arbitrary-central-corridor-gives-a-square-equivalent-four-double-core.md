> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An arbitrary central corridor gives a square-equivalent four-double core

[Note 348](348-a-central-short-block-supports-another-square-equivalent-four-double-core.md)
gives a 36-vertex square-equivalent patch with one short block
between the middle two blocks of an alternating four-double
chain. Its complete four-terminal signature and its forced
matching extend to every positive corridor length.

Use the compressed, gapless, tight-target all-square opening
of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
For \(q\ge1\), put
\[
D_t=(a_t,o_t,h_t,i_t,k_t,j_t,e_t,b_t)\ (1\le t\le4),
\qquad S_u=(c_u,r_u,s_u,d_u)\ (1\le u\le q)               \tag{1}
\]
in the old-cycle order \(D_1,D_2,S_1,\ldots,S_q,D_3,D_4\).
The four double blocks have common-face internal matching
chords \(i_1e_1,o_2k_2,i_3e_3,o_4k_4\), of types
\(J_3,J_1,J_3,J_1\). Let \(T_q\) consist of the full
old-cycle path through (1), all block-closing chords
\(a_tb_t,c_ud_u\), those four internal chords, and the
opposite-face chords
\[
\begin{gathered}
o_1h_3,\ h_1o_3,\ k_1i_2,\ j_1h_2,\
k_3i_4,\ j_3h_4,\\
e_2r_1,\quad s_ur_{u+1}\ (1\le u<q),\quad j_2s_q .
\end{gathered}                                             \tag{2}
\]
Its four degree-two terminals, in disk-boundary order,
are \((a_1,j_4,e_4,b_4)\).

**Central-corridor theorem.** For every \(q\ge1\),
the \((32+4q)\)-vertex patch \(T_q\) has exactly the
labeled square's complete vertex-spanning one-path and
two-path Hamilton signature. Replacing an induced disk
copy of \(T_q\) with that square, or conversely,
preserves three-connected cubic bipartite planarity
and all Hamilton decisions marked on exterior or
attachment edges. Thus a vertex-minimal non-Hamiltonian
Barnette graph has no such patch. For every \(q\),
\(T_q\) occurs in a \((44+4q)\)-vertex Barnette
parent with a Hamilton cycle through two legal site
edges, and its \((48+4q)\)-vertex legal child is
Hamiltonian.

Suppose moreover that an ordinary target-free free
group consists exactly of the blocks (1), with
ordinary endports \(L,R\) and no outer short flank.
If its complementary matching contains \(h_1o_3\),
then either \(D_3,D_4\) form the local square
of [Note 335](335-two-oppositely-oriented-double-vacancies-have-one-adjacent-mixed-core.md),
or the whole matching is (2) together with
\(Lj_4,e_4R\). Both cases have a spanning
\(L\)--\(R\) route. If all other vacancies occupy
distinct internal blocks, the parent has a Hamilton
cycle through both site edges and its legal child
is Hamiltonian.

**Exact signature.** Every path or path pair in
Note 348 (4)--(7), except its full old-cycle path,
contains the same consecutive segment
\[
                     e_2,r,c,d,s,j_2.                   \tag{3}
\]
Replace that segment by
\[
e_2,r_1,c_1,d_1,s_1,r_2,c_2,d_2,s_2,\ldots,
r_q,c_q,d_q,s_q,j_2.                                    \tag{4}
\]
The first and last joins use \(e_2r_1,j_2s_q\);
successive blocks join by \(s_ur_{u+1}\).
Within \(S_u\), the route \(r_u,c_u,d_u,s_u\)
uses two old edges and its face chord.
Thus (4) uses every new vertex exactly once
and has the same ends as (3). The full
\(a_1\)--\(b_4\) old-cycle path traverses
all \(q\) short blocks in order. Therefore
Note 348's four one-path states and two two-path
states lift with unchanged terminal pairings.
The third two-path pairing joins equal-colour
terminals and remains impossible. This proves
the exact signature and two-way Hamilton transfer.

**Barnette realization.** Take the old Hamilton cycle
\[
x,R_1,w,y,D_1,D_2,S_1,\ldots,S_q,D_3,D_4,
u,z,L_1,v,\alpha,\gamma,\delta,\beta,x.                  \tag{5}
\]
Place \(xy,uv,\alpha\beta\), every block-closing
chord and the four internal double-block chords
on the common-face side. Put
\(\delta R_1,wj_4,e_4z,\gamma L_1\) and (2)
on the opposite side. Every vertex receives
one matching chord joining opposite old-cycle
colours and distinct from an old edge.
Both pages are noncrossing: \(o_1h_3\)
surrounds \(h_1o_3\), while \(j_2s_q\)
surrounds the successive corridor links.
All other nesting is that of Note 348.
The graph is simple, cubic, bipartite and plane.

For three-connectivity, start with the connected
chord-interlacement system in Note 348 (9).
Insertion of complete short blocks preserves
all alternations among its old chord endpoints.
Replace its two corridor branches by
\[
\begin{gathered}
a_2b_2-j_2s_q-c_qd_q,\qquad
a_2b_2-e_2r_1-c_1d_1,\\
c_ud_u-s_ur_{u+1}-c_{u+1}d_{u+1}\quad(1\le u<q).
\end{gathered}                                             \tag{6}
\]
Each dash is endpoint alternation on (5):
\(c_u<s_u<d_u<r_{u+1}\) and
\(s_u<c_{u+1}<r_{u+1}<d_{u+1}\).
These chains attach every new matching chord
to one connected interlacement graph.
A two-edge cut of a cubic Hamiltonian graph
would give a matching-closed old-cycle interval
and disconnect that graph; the old cycle excludes
bridges. Hence the realization is three-connected.

The site chords \(xy,uv\) bound a face whose
\(y\)--\(u\) arc uses \(q+4\) block-closing
chords and has length \(2q+9\); its other
arc has length three via \(\alpha\beta\).
The vertices \(x,u\) have the same colour,
so this is a legal facial bipartite
\(C_4\)-expansion site. The residual cycle
\(\alpha\gamma\delta\beta\alpha\) is a
square with tight targets \(R_1,L_1\), and
there is no interblock gap. Replace (3)
by (4) in Note 348's \(j_4\)--\(e_4\)
spanning path \(W\). Joining it to the
exterior edges \(wj_4,e_4z\) and the
disjoint path
\(x,R_1,\delta,\beta,\alpha,\gamma,L_1,v\)
gives a Hamilton cycle through both site
edges. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives the legal child's Hamilton cycle.

For class preservation, every face-closed block
cycle remains connected after one vertex
deletion. The vertex-disjoint joins
\(b_1a_2,j_1h_2\);
\(b_2c_1,e_2r_1\);
\(d_uc_{u+1},s_ur_{u+1}\);
\(o_1h_3,h_1o_3\);
and \(b_3a_4,k_3i_4,j_3h_4\)
keep the entire patch connected after that
deletion: the single old join \(d_qa_3\)
closes the block chain, and if it is lost,
the two joins from \(D_1\) to \(D_3\)
close the alternate route. After two patch
vertices are deleted, every surviving
component contains a surviving terminal;
otherwise the explicit three-connected
realization would be disconnected.
The exterior of a four-attachment patch
in any three-connected cubic host is
connected, since each exterior component
would otherwise require at least three
of the four attachments. The same
four-attachment deletion comparison as
[Note 330](330-staggered-vacancy-chains-have-the-square-hamilton-signature.md)
proves three-connectivity of the substitution
in both directions. Terminal colours,
disk order and distinct attachments
preserve the other Barnette conditions.
Compressing \(T_q\) to one short target-free
square retains the old-cycle path, common-face
arc, targets, gaps and site edges. Note 324
and the exact signature give the
marked-opening consequence. \(\square\)

**Forcing the \(h_1o_3\) branch.** By
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md),
the displayed \(J_1/J_3\) edges are the
only same-block free chords. By
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
all cross-block free chords form a
noncrossing matching on the opposite page.
Inside \(h_1o_3\), \(k_1\) must meet \(i_2\):
\(k_1j_1\) is an old edge and every
other odd candidate encloses an odd
number of free slots. This forces
\(j_1h_2\). The remaining inner slots are
\[
        j_2,e_2,r_1,s_1,\ldots,r_q,s_q.                  \tag{7}
\]
The slot \(j_2\) can meet only an \(s_t\).
If \(t<q\), the complete short-block suffix
\(S_{t+1},\ldots,S_q\) must match internally:
its chords cannot cross \(j_2s_t\) or
\(h_1o_3\). Its two old boundary edges
would form a forbidden cut. Hence \(j_2s_q\).
Inside this chord \(e_2\) must meet an
\(r_t\). If \(t>1\), the complete prefix
\(S_1,\ldots,S_{t-1}\) is likewise
matching-closed. Thus \(e_2r_1\), and the
same argument successively forces
\(s_ur_{u+1}\) for \(1\le u<q\):
any first skipped complete short-block interval
would be matching-closed and give a two-edge cut.

Outside \(h_1o_3\), inserting whole
short blocks does not change the parity
list: \(h_3\) can meet only
\(o_1,j_4,R\). The choice \(h_3R\)
traps the forbidden old pair \(j_4e_4\).
If \(h_3j_4\), then \(k_3i_4,j_3h_4\)
are forced, giving Note 335's local
square on \(D_3,D_4\). The outer
slots must pair \(Lo_1,e_4R\);
\(LR,o_1e_4\) would close the entire
group under the matching. Compress
the local square, then use
[Note 336](336-every-two-double-mixed-j1-j3-free-group-has-a-spanning-route.md)
for the two remaining mixed double
blocks with short flanks.

Otherwise \(o_1h_3\). The left endport
can meet only \(j_4\) or \(R\);
the latter leaves \(j_4e_4\) as
a forbidden old pair after the other
tail slots are forced. Hence
\(Lj_4,e_4R,k_3i_4,j_3h_4\)
are forced, giving exactly (2).
The \(j_4\)--\(e_4\) route lifted
by (4), preceded by \(L\) and
followed by \(R\), spans the group.
\(\square\)

This theorem settles the \(h_1o_3\)
branch at every positive central-corridor
length. Other mates of \(h_1\) for
\(q\ge2\), outer short flanks, the
opposite orientation word, other
internal chord types, target defects,
positive gaps, nonsquare residual
cycles and the general Barnette
conjecture remain outside its scope.
The proof is project-internal and
analytic, without an independent
review or external priority claim.
