> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A short-block corridor reduces separated ports to consecutive ports

[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
identifies the exact Hamilton routing signature of an even four-terminal
ladder. [Note 291](291-every-consecutive-two-port-short-shared-block-group-has-three-routes.md)
gives three spanning states when two missing ordinary links share one
short block. Together these results cover two links separated by an
arbitrarily long corridor of short blocks.

Let \(G\) be a Barnette parent with a compressed, gapless,
tight-target all-square opening. Fix a free group with retained ordinary
end links and full target-free block interval \(D=B_a,\ldots,B_b\).
Suppose its only missing ordinary links are
\[
 P_s=e_so_{s+1},\qquad P_t=e_to_{t+1},
 \qquad a\le s<t<b,\qquad t\ge s+2,              \tag{1}
\]
and every block \(B_{s+1},\ldots,B_t\) is short. Vacancies elsewhere
in the group and their noncrossing matching may be arbitrary.

**Short-corridor reduction theorem.** Replacing
\(B_{s+1},\ldots,B_t\) by one short block gives another Barnette
parent \(G'\) with the same site opening and exactly two consecutive
missing links in the corresponding free group. For each of the three
vertex-spanning states
\[
\begin{array}{ll}
S(D):&o_a\longleftrightarrow e_b,\\
K(D):&a_a\longleftrightarrow o_a,\quad
       e_b\longleftrightarrow b_b,\\
X(D):&a_a\longleftrightarrow b_b,\quad
       o_a\longleftrightarrow e_b,
\end{array}                                                   \tag{2}
\]
existence in \(G\) is equivalent to existence in \(G'\), preserving
the route outside the replaced corridor and its four labeled
attachment edges. Hence all three states exist in \(G\). If the other
free groups have their ordinary spanning routes, \(G\) has a Hamilton
cycle through both site edges and its legal site-expanded child is
Hamiltonian.

**Proof.** Put \(d=t-s\ge2\). Each short block has cycle order
\(a_j,o_j,e_j,b_j\) and face chord \(a_jb_j\). Since the only missing
links are (1), every \(P_j=e_jo_{j+1}\) for \(s+1\le j<t\) is present.
The induced subgraph on the \(4d\) corridor vertices is exactly
\(L_{2d}=P_{2d}\square K_2\), with successive columns
\[
 (a_j,o_j),(b_j,e_j),\qquad s+1\le j\le t.       \tag{3}
\]
Its top rail alternates the face chords \(a_jb_j\) and the old-cycle
edges \(b_ja_{j+1}\); its bottom rail alternates the old-cycle edges
\(o_je_j\) and the retained links \(e_jo_{j+1}\). The rungs are
\(a_jo_j\) and \(b_je_j\). Exactly four edges leave it: the old-cycle
edges at \(a_{s+1},b_t\) and the two diverted matching edges at
\(o_{s+1},e_t\). The latter two mates lie outside the corridor:
there are no vacancy slots within it, and Note 276 rules out
nonstandard ordinary-to-ordinary matching edges. Thus Note 178's
four-pole replacement applies.

Replace \(L_{2d}\) by \(L_2\), naming its corners
\(a',o',e',b'\) in old-cycle order and keeping those four attachments.
The old Hamilton cycle crosses the replacement as
\(a',o',e',b'\), with face chord \(a'b'\). All other blocks, vacancy
atoms, and matching edges keep their order. The two missing links
now lie on the two sides of this one short block, so they are
consecutive. The target-free compact opening and the site face are
unchanged. Note 178(7) gives Barnette membership of \(G'\) from that
of \(G\), and the legal site expansion remains at the same exterior
edges.

Every endpoint of (2) lies in \(B_a\) or \(B_b\), outside the corridor
by \(a\le s<t<b\).
The intersection of a state with the corridor is therefore either one
spanning path using two attachments or two disjoint spanning paths
using all four. It cannot contain a closed component. Note 178(2)--(3)
says that \(L_{2d}\) and \(L_2\) admit exactly the same terminal
pairs and pairings. Replacing one local routing by the other preserves
the external paths, their endpoints, and their connectivity, in both
directions. This proves the asserted equivalence of all three states.

The same argument gives a general short-run normalization. For any
internal run \(B_p,\ldots,B_q\) of short blocks with \(a<p\le q<b\)
and all \(P_p,\ldots,P_{q-1}\) retained, the induced graph is
\(L_{2(q-p+1)}\) with the same four attachments, regardless of whether
\(P_{p-1}\) or \(P_q\) is retained. Compressing that run preserves
Barnette membership, the marked site opening, and each of the three
states of the containing free group. Only the final step below uses
the two-defect hypothesis.
If the corridor between two missing links contains \(m\) vacant blocks,
compress every maximal short run inside it. There are at most \(m+1\)
such runs, so the resulting corridor has at most \(2m+1\) blocks.
In particular, a corridor with one vacancy reduces to at most three
blocks without changing its group's three-state signature. This
normalization bounds the corridor geometry, not the matching outside it.

The compressed group satisfies Note 291's short shared-block
hypotheses, so it has \(S,K,X\); lift those routes to \(G\). Note 273
splices the other free groups, while Notes 001 and 178 give the marked
Hamilton parent cycle and the legal Hamiltonian child. \(\square\)

The hypothesis occurs at every corridor length. In Note 291(2),
replace its shared short block \(B_4\) by \(d\) short blocks using
Note 178 in reverse. The two missing links become separated by
\(d\) short blocks, and the parent and child have respectively
\(46+4(d-1)\) and \(50+4(d-1)\) vertices. Both remain Barnette
and Hamiltonian with the stated marked opening.

The theorem covers a nonconsecutive two-defect group whenever the
whole corridor between its ports is short. It does not cover a vacancy
inside that corridor, three missing links, or arbitrary Barnette graphs.
[Note 313](313-square-buffers-monotonically-enlarge-six-port-hamilton-linkages.md)
gives a Barnette family with one such vacancy by a one-way six-port
buffer extension. [Note 314](314-port-free-central-vacancy-gives-three-states-between-separated-ports.md)
proves the full three-state theorem when the corridor's central
vacancy belongs to a port-free component; the two port-bearing
ownership cases remain open.
