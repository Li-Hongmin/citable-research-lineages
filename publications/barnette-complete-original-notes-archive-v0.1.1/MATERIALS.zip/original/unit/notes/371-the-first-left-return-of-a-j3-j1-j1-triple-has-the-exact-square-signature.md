> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first left return of a J3,J1,J1 triple has the exact square signature

[Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md)
reduces the \(h_1j_3\)-present triple to a square.  Here that chord
is absent.  One nonstandard left-flank matching type also has a
complete square signature, including two-way Barnette preservation.

Use the triple and right corridor of [Note 344](344-every-three-double-j1-j3-free-group-has-a-spanning-route.md):
\[
D_s=(a_s,o_s,h_s,i_s,k_s,j_s,e_s,b_s),\quad
S_t=(c_t,r_t,s_t,d_t),\quad 1\le t\le q,
\tag{1}
\]
with \(D_1,D_2,S_1,\ldots,S_q,D_3\) in old-cycle order,
\(q\ge1\), and all chords in Note 344 (2).  Put \(p\ge1\)
short blocks immediately before \(D_1\), denoted
\(T_t=(\bar c_t,\bar r_t,\bar s_t,\bar d_t)\) in
old-cycle order.  Assume these are the entire left flank,
there is no right flank, and the left-only matching of
Note 344 (7) has \(\mu=0\):
\[
\bar r_1h_1,\qquad
\bar s_t\bar r_{t+1}\ (1\le t<p),\qquad
\bar s_po_1 .                                          \tag{2}
\]
The two unmatched free slots of the whole interval are
\(j_3,e_3\), attaching to the ordinary endports outside it.
Let \(F_{p,q}\) be the induced patch on
\(T_1,\ldots,T_p,D_1,D_2,S_1,\ldots,S_q,D_3\).
Its four degree-two terminals, in cyclic disk order, are
\[
                     (\bar c_1,j_3,e_3,b_3).           \tag{3}
\]

**First-left-return theorem.** Every \(F_{p,q}\) with
\(p,q\ge1\) has exactly the complete Hamilton four-terminal
signature of a square.  Replacing any induced disk copy by
that labeled square, or reversing the replacement, preserves
Barnette membership and every exterior- and attachment-marked
Hamilton decision.  The patch has \(24+4(p+q)\) vertices.
Old-cycle reflection gives the corresponding right-return
statement for the reflected \(J_3,J_3,J_1\) order.  The theorem
does not assume that vacancies elsewhere occupy distinct blocks.

**Two independent ladder reductions.** The right corridor
\(S_1,\ldots,S_q\) is Note 370's induced \(L_{2q}\), with
attachments \(b_2c_1,e_2r_1,j_2s_q,d_qa_3\).
Independently, the left flank \(T_1,\ldots,T_p\) is
\(L_{2p}\), with columns
\[
(\bar c_t,\bar r_t),(\bar d_t,\bar s_t)
\quad(1\le t\le p),                                   \tag{4}
\]
and attachments at \(\bar c_1,\bar r_1,\bar d_p,\bar s_p\):
the exterior old-cycle edge, \(\bar r_1h_1\),
\(\bar d_pa_1\), and \(\bar s_po_1\), respectively.
The two ladders are disjoint.  By
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md),
each can be replaced by one square, in either direction,
preserving all exterior and attachment decisions and Barnette
membership.  The old-cycle route and common-face top rail
map exactly as in Note 370, so the selected facial opening
and legal site expansion also survive.  It therefore suffices
to prove the signature and patch deletion properties for
\(F_{1,1}\).

**Six paths in the reduced patch.** Write its left square as
\(T_1=(\bar c,\bar r,\bar s,\bar d)\), and keep the
notation \(U_q,W_q\) of Note 370 (7) to display routes valid
for every \(q\ge1\).  The full old-cycle path from
\(\bar c\) to \(b_3\) is one spanning path.
For \(j_3\)--\(e_3\), take Note 344's disjoint core paths
\(B_q:j_3\to h_1\) and \(A_q:o_1\to e_3\), joined by
\[
                 h_1,\bar r,\bar c,\bar d,\bar s,o_1.
\tag{5}
\]
This visits the left square exactly once.  An
\(e_3\)--\(b_3\) spanning path is obtained from the
\(e_3\)--\(b_3\) path in Note 370 (9), which does not use
\(h_1j_3\), by replacing its edge \(h_1o_1\) with (5).
The fourth spanning path, from \(\bar c\) to \(j_3\), is
\[
\begin{split}
(\bar c,\bar d,a_1,o_1,\bar s,\bar r,h_1,i_1,k_1,
 i_3,k_3,o_3,h_3,i_2,h_2,j_1,e_1,b_1,a_2,o_2,\\
\hspace{37mm}k_2,j_2,e_2,b_2,U_q,a_3,b_3,e_3,j_3).
\end{split}                                             \tag{6}
\]
The only joins in (5)--(6) away from old-cycle edges and
face chords are listed in (2) or Note 344 (2).

For the pairing
\(\{\bar c j_3,e_3b_3\}\), take the edge \(e_3b_3\)
and the disjoint spanning path
\[
\begin{split}
(\bar c,\bar d,a_1,o_1,\bar s,\bar r,h_1,i_1,k_1,
 j_1,e_1,b_1,a_2,o_2,h_2,i_2,k_2,j_2,e_2,b_2,\\
\hspace{37mm}U_q,a_3,o_3,h_3,i_3,k_3,j_3).
\end{split}                                             \tag{7}
\]
For \(\{\bar c b_3,j_3e_3\}\), take the initial segment
of (6) ending at \(b_3\) and the single edge \(j_3e_3\).
Each path pair covers the patch exactly once.  Terminal
colours are \(\bar c,e_3\) versus \(j_3,b_3\), excluding
the other two single-path pairs; the third two-path pairing
interlaces the disk boundary terminals.  This proves the
complete square signature for \(p=1\), and the two ladder
replacements give it for all \(p,q\).

**A three-connected cap.** For \(p=q=1\), cap (3) with a
square in the cyclic order
\((t_B,t_E,t_J,t_C)\), attaching
\(b_3t_B,e_3t_E,j_3t_J,\bar c t_C\).
The full old-cycle path through the patch, followed by
\(t_B,t_E,t_J,t_C,\bar c\), is a Hamilton cycle of the
36-vertex capped graph.  Its complementary matching has
one-page chords
\[
\bar c\bar d,\ a_sb_s\ (s=1,2,3),\ i_1e_1,
\ o_2k_2,\ o_3k_3,\ c_1d_1,\ t_Bt_C,
\tag{8}
\]
and opposite-page chords
\[
\bar r h_1,\ \bar s o_1,\ j_1h_2,\ k_1i_3,
\ i_2h_3,\ j_2s_1,\ e_2r_1,\ j_3t_J,\ e_3t_E.
\tag{9}
\]
Each page is noncrossing and each chord joins opposite
old-cycle colours, so the cap is simple, cubic, bipartite,
and plane.  Its matching-chord interlacement graph has the
following connected spanning tree:
\[
\begin{gathered}
t_Bt_C-j_3t_J-a_3b_3-i_2h_3-a_2b_2-j_1h_2
 -a_1b_1-\bar r h_1-\bar c\bar d,\\
t_Bt_C-e_3t_E,\qquad
a_3b_3-k_1i_3-o_3k_3,\qquad
a_2b_2-j_2s_1-c_1d_1-e_2r_1,\\
j_1h_2-i_1e_1,\qquad j_1h_2-o_2k_2,\qquad
a_1b_1-\bar s o_1 .
\end{gathered}                                          \tag{10}
\]
Every dash is endpoint alternation in the displayed
Hamilton order.  As in Note 370, this excludes any
two-edge cut; Hamiltonicity excludes bridges, and a cubic
graph without either is three-vertex-connected.  Thus the
cap is Barnette.  Expanding either disjoint ladder by
Note 178 gives a Barnette cap for every \(F_{p,q}\).

Deleting any one vertex from \(F_{p,q}\) leaves it
connected.  Indeed, its full old-cycle path is bridged at
every internal position by one of the overlapping chords
\[
\bar c_1\bar d_1,\quad \bar r_1h_1,\quad
a_1b_1,\quad k_1i_3,\quad a_3b_3,                 \tag{11}
\]
not incident with the deleted vertex.  After deleting any
two patch vertices, a component lacking all surviving
terminals would remain disconnected in the corresponding
three-connected cap, which is impossible.  These are the
two patch deletion properties used in Note 370's
four-attachment comparison.  That comparison, the exact
signature, the disk order and terminal colours prove
the two-way Barnette and Hamilton assertions. \(\square\)

In the selected opening the square replacement is a single
short target-free block, with old-cycle segment
\((\bar c_1,j_3,e_3,b_3)\) and face chord
\(\bar c_1b_3\).  Thus this first-left-return subbranch
can be removed without conditions on vacancies outside it.
For \(\mu>0\), standard short blocks precede the first
return, but their two attachment terminals in this patch
are not adjacent; Note 367's buffer theorem does not
directly cover them.  Other outer-flank matching types and
the general Barnette conjecture remain outside this result.
This is a project-internal analytic proof without an
independent review or external priority claim.
