> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Five-leaf face matchings have three unresolved shapes

[Note 425](425-short-wrapper-parity-and-terminal-spine-paths.md) proves that a non-Hamiltonian child in the chorded single-hexagon $f=7,c=31$ branch with exactly two eligible site leaves cannot put its five other leaves into a $3+2$ split. The five leaves must occupy one face-matching compartment, and their noncrossing matching has six formal possibilities. Here one possibility is Hamiltonian in every legal completion, and the other five have exact necessary sibling-leaf positions.

Write the five consecutive ineligible leaves as $a,b,c,d,e$ in old-cycle order. All their $x$-positions have odd old-cycle index and all their $y$-positions have even index. Their ten special terminals are matched among themselves on the face page. Outside this block, $z_Lx_j$ and $y_kz_R$ are forced by Note 425, and, up to reflection, $(j,k)=(1,2)$ or $(1,7)$.

**Five-leaf matching theorem.** The six formal matchings and the only boundaries at which an ineligible sibling-leaf pair can occur in a legal non-Hamiltonian child are:

| Row | Matching chords on $a,b,c,d,e$ | Permitted ineligible sibling boundary |
| --- | --- | --- |
| I | $x_ay_b,\ y_ax_b,\ x_cy_e,\ y_cx_d,\ y_dx_e$ | $b\mid c$ |
| II | $x_ay_c,\ y_ax_b,\ y_bx_c,\ x_dy_e,\ y_dx_e$ | $c\mid d$ |
| III | $x_ay_e,\ y_ax_b,\ y_bx_c,\ y_cx_d,\ y_dx_e$ | none |
| IV | $x_ay_e,\ y_ax_b,\ y_bx_e,\ x_cy_d,\ y_cx_d$ | $b\mid c,\ d\mid e$ |
| V | $x_ay_e,\ y_ax_d,\ x_by_c,\ y_bx_c,\ y_dx_e$ | $a\mid b,\ c\mid d$ |
| VI | $x_ay_e,\ y_ax_e,\ x_by_d,\ y_bx_c,\ y_cx_d$ | $a\mid b,\ d\mid e$ |

Every legal child in row III is Hamiltonian. For any hypothetical non-Hamiltonian child in another row, at least one of that row's permitted sibling boundaries must actually be a sibling-leaf pair. Reflection exchanges I with II and IV with V, while fixing III and VI. Thus the remaining two-eligible branch has, up to reflection, only rows I, IV and VI, each with the two site placements stated above.

**Proof of completeness.** Each row pairs the ten terminals once, uses no adjacent old-cycle pair $x_i y_i$, and has nested or disjoint chords. The rows are distinct. Note 425, equation (3), proves that the number of noncrossing matchings avoiding the five old-cycle pairs is exactly
\[
\sum_{t=0}^{5}(-1)^t\binom5t C_{5-t}
=42-70+50-20+5-1=6.
\]
The displayed rows are therefore exhaustive. Reversing the order of the five leaves and swapping $x,y$ gives the stated reflection pairs.

**Sibling restrictions.** In this $s=2$ case the unique short node has odd depth. A short leaf cannot be a site leaf: its $x$-index would be odd by Note 425 (1). If it is a member of a sibling-leaf pair, its sibling has the opposite $x$-parity and must be one of the two site leaves. Hence every sibling pair wholly inside the five-leaf block consists of two full six-vertex leaves.

For such a pair, a face chord $y_i x_{i+1}$ with the other special terminals attached outside the pair gives the serial odd pole of [Note 412](412-two-odd-ladder-poles-compose-to-one-odd-ladder-signature.md). Compression leaves a legal $f=6$ child, Hamiltonian by [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md), and the Hamilton cycle lifts back. If both face chords match the two leaves wholly to each other, their twelve vertices have just the two extreme old-cycle edges to the rest of the graph, contradicting three-connectivity. Inspecting the six chord lists, the boundaries not excluded by these two mechanisms are exactly those in the last column.

It remains to show that a hypothetical failure has an ineligible sibling pair. Suppose it has none. A full binary tree has a sibling-leaf pair, and the two site leaves cannot themselves be siblings in a non-Hamiltonian child by [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md). Thus one sibling pair contains a site leaf and the short ineligible leaf, since sibling leaves have equal depth and their differing $x$-parities require the unique short node to be one of them. This pair has odd depth: $s=2$ makes the short node's depth odd by Note 425 (2). A seven-leaf full binary tree with exactly one sibling-leaf pair is a comb whose sole pair has even depth six. Therefore the tree has a second sibling-leaf pair. It is disjoint from the first; it cannot contain the other site and a full ineligible leaf, whose equal depths would give equal $x$-parities. It must be a pair of ineligible leaves, contrary to the supposition. Hence at least one permitted ineligible sibling boundary occurs.

Row III has no permitted boundary, so it is Hamiltonian. The other conclusions follow from the table and reflection. \(\square\)

The theorem classifies face matchings and excludes one row; it does not certify Barnette-class realizability of the other formal rows or decide their Hamiltonicity. It also does not address $s=4,5,7$ or the chord-free single-hexagon branch.
