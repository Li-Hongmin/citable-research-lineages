> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The balanced short-third-leaf word has a marked path

The row-IV word in [Note 437](437-the-fourth-matching-short-leaf-has-thirteen-necessary-depth-words.md) with sites \((1,2)\), short leaf \(3\), and depth vector \((1,3,3,4,4,4,4)\) has a spanning path between its site terminals. The proof uses only two of the row-IV face chords and works for every legal completion of this word.

Use the full leaf and branch notation and the paths \(Y_i,X_i,O_i,P_H,Q_H,R_H\) of [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md). For a full branch \(H\), also put
\[
J_H=(\lambda_0^H,\rho_0^H,\rho_1^H,\lambda_1^H,
     \lambda_2^H,\rho_2^H).
\tag{1}
\]
Each consecutive pair in \(J_H\) is an ordinary chord or an old-cycle edge. Set
\[
\begin{aligned}
S_3&=(L_3,x_3,y_3,R_3),& C&=F(U_2,S_3),\\
B&=F(U_4,U_5),& D&=F(U_6,U_7),& R&=F(B,D),\\
T&=F(C,R),& W&=F(U_1,T).
\end{aligned}
\tag{2}
\]
The only face chords needed below are \(y_3x_4\) and \(x_3y_7\), both present in row IV of [Note 426](426-five-leaf-face-matchings-have-three-unresolved-shapes.md).

First, the ordinary edges of \(R\) have the following spanning \(x_4\)--\(y_7\) path. In \(B\), take
\[
\mathcal B=(x_4\xrightarrow{X_4^{-1}}R_4,
 L_5\xrightarrow{O_5}R_5,
 \rho_2^B\xrightarrow{R_B}\lambda_0^B).
\tag{3}
\]
It spans \(B\) and ends at its leftmost vertex. In \(D\), take
\[
\mathcal D=(\rho_0^D,\lambda_0^D,\lambda_1^D,
 \rho_1^D,\rho_2^D,\lambda_2^D,
 L_6\xrightarrow{O_6}R_6,
 L_7\xrightarrow{Y_7^{-1}}y_7).
\tag{4}
\]
It spans \(D\) from its rightmost vertex. The joins \(R_4L_5,R_5\rho_2^B,\lambda_2^DL_6,R_6L_7\) are consecutive old-cycle edges. Therefore
\[
\mathcal R=(x_4\xrightarrow{\mathcal B}\lambda_0^B,
\lambda_2^R\xrightarrow{P_R}\rho_2^R,
\rho_0^D\xrightarrow{\mathcal D}y_7)
\tag{5}
\]
spans all \(18+6+18=42\) vertices of \(R\). Its two additional joins \(\lambda_0^B\lambda_2^R\) and \(\rho_2^R\rho_0^D\) are old-cycle edges.

The short-leaf subtree \(C\) has two disjoint paths, with endpoints \((C_\ell,y_3)\) and \((x_3,x_2)\):
\[
\mathcal C_1=(C_\ell=\lambda_0^C\xrightarrow{J_C}\rho_2^C,R_3,y_3),
\qquad
\mathcal C_2=(x_3,L_3,R_2\xrightarrow{X_2}x_2).
\tag{6}
\]
Their vertex sets partition \(C\): \(J_C\) covers its six brackets, \(R_3,y_3,x_3,L_3\) cover the short leaf, and \(X_2\) covers the full leaf \(U_2\). The joins \(\rho_2^CR_3\) and \(L_3R_2\) are old-cycle edges.

**Marked-path theorem.** The following is a spanning \(y_1\)--\(x_2\) path of \(W\):
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,
\lambda_2^W\xrightarrow{P_W}\rho_2^W,
\rho_0^T\xrightarrow{Q_T}\lambda_2^T,
C_\ell\xrightarrow{\mathcal C_1}y_3,\\
&x_4\xrightarrow{\mathcal R}y_7,
x_3\xrightarrow{\mathcal C_2}x_2.
\end{aligned}
\tag{7}
\]
The two jumps in the second line are precisely the face chords \(y_3x_4\) and \(y_7x_3\). The other joins \(L_1\lambda_2^W,\rho_2^W\rho_0^T,\lambda_2^TC_\ell\) are consecutive old-cycle edges. The disjoint pieces in (7) cover \(U_1\) (six vertices), the wrappers of \(W,T\) (twelve), \(C\) (sixteen), and \(R\) (forty-two), totalling all \(76\) vertices of \(W\).

Adjoin the two site edges and the fixed twelve-vertex outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), with site endpoints \(y_1,x_2\). This gives a parent Hamilton cycle through both site edges. Clause 1 of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to a Hamilton cycle in every corresponding legal child. Reflection gives the row-V statement. \(\square\)

Together with Notes 437--443, this leaves five structurally necessary row-IV/V short-leaf words. Row VI, other kernel branches, and Barnette's conjecture remain unresolved.
