> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RCA and the direct two-path target have distinct exact dual forms

[Note 057](057-planar-two-path-covers-require-root-preserving-cycle-absorption.md)
gives two possible routes to the planar prescribed two-path target: complete a
root-separated 2-factor through RCA, or construct its face-constrained dual
unicycle directly.  [Note 060](060-rca-is-a-two-cycle-minimum-and-root-fixed-kempe-connectivity-is-nonmonotone.md)
identifies the exact global content of RCA.  The two routes admit exact dual
forest formulations, but they are different formulations: the RCA branch has
perfect-matching face loads, whereas a general direct witness has one free
face of load two.

## The RCA branch is a rooted exact-one three-forest

Let \(F\) be a simple plane cubic bipartite brace on \(2n\) vertices, let
\(e=rs\in E(F)\), and put \(T=F^*\).  Write \(a=e^*=uv\).  The triangular
faces of \(T\) corresponding to \(r,s\) are denoted by
\(\tau_r,\tau_s\); they share \(a\).

For a perfect matching \(M\ni e\), define

\[
K=M^*,\qquad L=K-\{a\}=(M-\{e\})^*.
\tag{1}
\]

The perfect-matching condition is equivalent to the facial loads

\[
|L\cap\partial\tau_r|=|L\cap\partial\tau_s|=0,
\qquad
|L\cap\partial\tau_w|=1\quad(w\ne r,s).
\tag{2}
\]

Conversely, every \(L\) satisfying (2) gives a unique perfect matching
containing \(e\).  Thus (2) is an exact parametrization.

The root-separation bit is also exact:

\[
r,s\text{ lie on distinct cycles of }F-M
\quad\Longleftrightarrow\quad
u\leftrightarrow_L v.
\tag{3}
\]

Indeed, \(u\leftrightarrow_L v\) says that \(a\) lies on a cycle of
\(K=L+a\).  By planar cycle--cut duality this is equivalent to a primal
bond contained in \(M\) and containing \(e\), which separates \(r\) from
\(s\) in \(F-M\).  Conversely, the cut of the component cycle of \(F-M\)
containing \(r\) is contained in \(M\), contains \(e\), and its dual
Eulerian subgraph contains a cycle through \(a\).

Let \(\beta(H)=|E(H)|-|V(H)|+\operatorname{comp}(H)\).  If
\(k=c(F-M)\), planar graphic-matroid duality gives

\[
\beta(K)=k-1.
\tag{4}
\]

Under (3), \(a\) is not a bridge of \(K\), so deleting it lowers the cycle
rank by one without changing the component count.  Hence

\[
\boxed{c(F-M)=\beta(L)+2.}
\tag{5}
\]

Since \(L\) has \(n-1\) edges on the \(n+2\) vertices of \(T\), (2)--(5)
show that the endpoint-separated two-cycle condition, and therefore RCA,
is equivalent to the existence of a spanning forest \(L\) with exactly
three components satisfying (2), with \(u,v\) in the same tree.  Equivalently,

\[
\min\{\beta(L):L\text{ satisfies (2) and }u\leftrightarrow_Lv\}=0.
\tag{6}
\]

There is no additional alternating-reachability condition: the symmetric
difference of any two perfect matchings containing \(e\) is already a
disjoint union of alternating cycles avoiding \(e\).

## Equivalent facewise-NAE colouring statement

The preceding perfect matchings are also parametrized, up to a global
colour swap, by vertex 2-colourings of \(T\) in which **every triangular
face is nonmonochromatic**.  The monochromatic edges form \(K=M^*\): every
nonmonochromatic triangle has exactly one such edge.  Conversely,
\(E(T)\setminus K=(F-M)^*\) is a cut because \(F-M\) is Eulerian, so its
two shores give the colouring.

In this language the RCA target is

> a facewise-NAE 2-colouring whose monochromatic-edge graph has total
> cycle rank one and whose unique cycle contains the prescribed edge
> \(a=e^*\).

The facewise qualification is essential; a merely nonconstant colouring
of \(V(T)\) need not define a perfect matching.

## The direct target is a rooted two-forest

Now use the notation of Note 057.  Let the bipartition of \(F\) be
\(X\sqcup Y\), let \(r\in Y\), write
\(N_F(r)=\{a,b,s\}\), and put \(P=F-r\).  Label the vertices of the root
triangle \(\tau_r\) as \(p,q,z\) so that

\[
(rs)^*=pq,
\qquad
d_a=(ra)^*,\quad d_b=(rb)^*
\tag{7}
\]

are the three root-triangle edges.  Put
\(E_0=E(T)\setminus E(\tau_r)\).  Deleting \(r\) in the primal identifies
\(p,q,z\) in the dual, so \(P^*\) is obtained from \(T\) by collapsing
\(\tau_r\) to one vertex and deleting its three edges.

For a fixed free endpoint \(y\in Y\setminus\{r\}\), the direct target is
equivalent to an edge set \(H\subseteq E_0\) satisfying

\[
|H\cap\partial\tau_x|=1\quad(x\in X),
\tag{8}
\]

\[
|H\cap\partial\tau_w|=1
\quad(w\in Y\setminus\{r,y\}),
\qquad
|H\cap\partial\tau_y|=2,
\tag{9}
\]

such that \(H\) is a spanning forest of \(T\) with exactly two components
and root partition

\[
p\leftrightarrow_H q,
\qquad
z\not\leftrightarrow_H p.
\tag{10}
\]

To see this directly, (8)--(9) give \(|H|=n\).  Let \(\bar H\) be the
image after identifying \(p,q,z\), and put \(c=\operatorname{comp}(H)\).
Whenever \(\bar H\) is connected, every component of \(H\) meets the root
triple and

\[
\beta(\bar H)=\beta(H)+3-c.
\tag{11}
\]

The unique dual cycle of Note 057 realizes the split
\(\{s\}\mid\{a,b\}\) exactly when it passes through the collapsed root
face at the two corners \(p,q\).  Lifting that cycle therefore puts
\(p,q\) in the same component.  Equation (11), connectedness, and
\(\beta(\bar H)=1\) force \(c=2\) and \(\beta(H)=0\), with \(z\) in the
other component.  Conversely, (10) first identifies two vertices of one
tree, creating the unique cycle, and then attaches the other tree through
\(z\).  This recovers precisely the connected unicycle and prescribed
bond of Note 057.

Consequently the universal direct statement is exactly

\[
\forall(F,r,s)\ \exists y\in Y\setminus\{r\}\ \exists H
\text{ satisfying (8)--(10)}.
\tag{12}
\]

## Four-common-base form

On \(E_0\), let \(\mathcal P_X\) be the partition matroid with capacity one
on each \(X\)-face block.  Let \(\mathcal P_{Y,y}\) have capacity one on
each \(Y\setminus\{r,y\}\)-face block and capacity two on the \(y\)-block.
Let

\[
\mathcal G_a=M(T/d_a),\qquad
\mathcal G_b=M(T/d_b),
\tag{13}
\]

with the unused root-triangle edges forbidden.  All four ranks are \(n\).
Then (8)--(10) are equivalent to

\[
H\in
\mathcal B(\mathcal P_X)\cap
\mathcal B(\mathcal P_{Y,y})\cap
\mathcal B(\mathcal G_a)\cap
\mathcal B(\mathcal G_b).
\tag{14}
\]

The two partition bases encode (8)--(9).  Moreover,

\[
H\in\mathcal B(\mathcal G_a)
\quad\Longleftrightarrow\quad
H+d_a\text{ is a spanning tree of }T,
\tag{15}
\]

and similarly for \(d_b\).  Both augmentations are trees exactly when
\(H\) is the two-forest in (10).  Equivalently, after choosing a common
\(\mathcal P_X,\mathcal P_{Y,y},\mathcal G_a\)-base, the final condition is
the single fundamental-cut requirement that \(d_b\) cross the fundamental
bond of \(d_a\) in \(H+d_a\).

## The two dual routes do not parametrize the same witnesses

The facewise-NAE/RCA state has loads zero on \(\tau_r,\tau_s\) and one on
every other triangular face.  A general direct state has load zero on
\(\tau_r\), load two on a free face \(\tau_y\), and load one elsewhere.
It becomes an RCA state only when its free endpoint can be completed to a
root port as in Note 057(4).

This distinction occurs in a genuine plane brace.  In the 16-vertex
example of [Note 062](062-the-planar-boundary-chord-lemma-fails-on-a-sixteen-vertex-brace.md),
the direct witness of its equation (12) has free endpoint \(y=6\), and
the two complementary edges at \(y\) are \(6\!-\!12\) and \(6\!-\!14\).
Neither meets the root ports \(\{8,9,10\}\).  That witness therefore has no
perfect-matching completion of the form used by RCA.  This does not show
that the graph lacks some other completable witness; it proves that the
direct witness space itself is strictly larger and that the NAE reduction
cannot replace the direct formulation.

## Boundary

Both statements remain open.  RCA is now exactly the rooted exact-one
three-forest problem (6), or the prescribed-edge facewise-NAE pseudoforest
problem.  The more general direct target is exactly the four-common-base
problem (12)--(14).  Its thinnest remaining form is to choose a common
\(\mathcal P_X,\mathcal P_{Y,y},M(T/d_a)\)-base whose fundamental bond at
\(d_a\) is crossed by \(d_b\).  Neither ordinary matroid intersection nor
the RCA colouring alone supplies this fourth simultaneous condition.
