> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every three-block single-defect vacancy group is marked Hamiltonian

[Note 276](276-distinct-target-free-vacancies-have-only-chain-defects.md)
settles a three-vacancy group with one missing ordinary link
when the vacancy slots themselves form one alternating path.
The only other two-vacancy-edge pattern is an alternating
square on two vacancy pairs, alongside a third pair whose
slots attach to the missing link. The square may enclose
that third pair. Both positions admit a marked spanning
route.

Use a compressed, gapless, tight-target all-square opening
with \(\ell,r\ge1\). Assume its only three vacancies lie
in different target-free internal face-chord blocks of
one free group. Write them \(B_{k_1}<B_{k_2}<B_{k_3}\),
with free slots \(o_i,H_i,I_i,e_i\) in each vacant
block. Let \(M\) be the complementary perfect matching
and \(A\) the even-starting old-cycle matching of
Note 196. Let \(c\) count the \(M\)-edges between the
six vacancy slots.

**Three-vacancy single-defect theorem.** If \(c=2\),
the parent has a Hamilton cycle containing both site
edges \(xy,uv\); its legal expanded child is Hamiltonian.
This holds for arbitrary distances between the three
vacant blocks and arbitrary positive original lobe
lengths. In particular, the tight gapless third-surplus
case with three distinct target-free vacancies in one
group remains undecided only when \(c\le1\).

**Proof.** Note 276 excludes same-block ordinary chords
and nonstandard ordinary-to-ordinary edges. Exactly one
standard link \(P_s=e_so_{s+1}\) is missing. Its two
ordinary ends match the two vacancy slots not used by
the \(c=2\) vacancy edges.

If the graph on vacancy slots with edges from \(A\cup M\)
is connected, Note 276's single-defect corollary gives
the marked Hamilton cycle. Otherwise it consists of
one alternating square on two vacancy blocks \(B_u<B_w\)
and the single old-cycle edge \(H_vI_v\) of the third
block. The square edges of \(M\) are
\[
 H_uI_w,\qquad I_uH_w,                              \tag{1}
\]
and the missing-link ends necessarily match
\[
 e_sI_v,\qquad o_{s+1}H_v.                          \tag{2}
\]
All these cross-block chords lie in the same noncrossing
disk by Notes 193 and 276.

First suppose \(B_v\) lies outside the interval
\(B_u,\ldots,B_w\). Both ends of \(P_s\) must also
lie outside the chord \(H_uI_w\): an edge from an
inside ordinary slot to \(H_v\) or \(I_v\) outside
would cross that chord. Hence \(s\le u-1\) or
\(s\ge w\). All standard links through the two
square blocks and their intervening short blocks
are retained. Apply the local path replacement
(4) or (6) of Note 217 to that interval; it uses
only these retained links and the four square slots.
Separately replace \(P_s\) in
the free path by
\[
 e_s,I_v,H_v,o_{s+1}.                              \tag{3}
\]
The two replacements insert disjoint vacancy slots
and alter different ordinary-chain segments, so
together they give one spanning free path.

It remains to suppose \(u<v<w\). Both ends of
\(P_s\) must lie strictly inside the inner square
chord \(I_uH_w\), since the ends of (2) lie there.
Thus \(u\le s\le w-1\). The choices \(s=v-1\)
and \(s=v\) would make \(o_vH_v\) or \(e_vI_v\)
a matching edge, respectively, duplicating an
old-cycle edge. Reverse the old-cycle order if
necessary. We may therefore assume
\[
 u\le s\le v-2.                                    \tag{4}
\]
In particular \(B_{u+1},\ldots,B_{v-1}\) contains
at least one short block; every complete block
between \(B_u,B_w\), except \(B_v\), is short.

We now give two disjoint paths whose union covers the
intervening blocks \(D=B_{u+1},\ldots,B_{w-1}\).
When \(s=u\), the left path also has its final endpoint
\(e_u\) outside \(D\). Begin the left
path at \(a_{u+1}\). Follow the face-chord top rail
\[
 a_{u+1},b_{u+1},a_{u+2},b_{u+2},\ldots,a_v,o_v,
\]
then follow the ordinary-slot bottom rail backwards,
using its retained links, from \(o_v\) to \(o_{s+1}\).
Finish through
\[
 o_{s+1},H_v,I_v,e_s
\]
using (2) and \(H_vI_v\in A\). If \(s>u\),
continue backwards along the ordinary bottom rail
from \(e_s\) to \(o_{u+1}\). If \(s=u\), stop at
\(e_u\), which is the ordinary slot of the left
outer vacant block. The route visits all vertices
of \(B_{u+1},\ldots,B_v\) except \(e_v,b_v\).
The edge \(e_vb_v\) is the second path there.

For each short block from \(B_{v+1}\) through
\(B_{w-1}\), extend these two paths using the
crossed two-path state \(X\) of Note 275: connect
the current right path to its top and bottom
paths by the two rail edges. This leaves a
left path with the same left endpoint and a right
path
\[
 e_{w-1}\longleftrightarrow b_{w-1},              \tag{5}
\]
and covers every vertex of \(D\). The suffix may
be empty, in which case (5) is \(e_vb_v\).

Replace the ordinary free-path segment from \(b_u\)
through \(D\) to \(a_w\) as follows. Go from \(b_u\)
to \(a_{u+1}\), traverse the left covering path.
If \(s>u\), its endpoint is \(o_{u+1}\), so take
the retained link \(o_{u+1}e_u\); if \(s=u\), its
endpoint is already \(e_u\). Then follow
\[
 e_u,I_u,H_u,I_w,H_w,o_w,e_{w-1},               \tag{6}
\]
traverse the right path (5) from \(e_{w-1}\) to
\(b_{w-1}\), and finish with the old-cycle edge
\(b_{w-1}a_w\). The joins in (6) are, in order,
an old-cycle edge, an \(A\)-edge, the first
edge of (1), an \(A\)-edge, an old-cycle edge,
and a retained standard link. The left path
uses (2). Thus every displayed join is an
edge of the parent. The two covering paths
are disjoint; (6) visits the four outer-square
vacancy slots exactly once. This replacement
has the original endpoints \(b_u,a_w\), spans
all the removed ordinary vertices and all six
vacancy slots, and does not meet the rest of the
free path. It therefore gives a spanning free
\(x\)-to-\(v\) path. Together with Note 196's
unchanged target-and-square path it forms one
Hamilton cycle containing \(xy,uv\).
Notes 001 and 178 give the child and the
original lobe lengths. \(\square\)

**A nested realization.** The inner case of the theorem
is nonempty. Take \(\ell=1,r=4\), one short
block \(B_2=(a_2,o_2,e_2,b_2)\), and vacant
blocks \(B_1,B_3,B_4\) in the order
\((a_j,o_j,H_j,I_j,e_j,b_j)\); use the ordinary
site blocks and last residual square of Note 274.
Besides the site, face-block, square-closing and
escape edges of that note, take
\[
\begin{gathered}
e_0o_1,\ e_2o_3,\ e_3o_4,\ e_4o_5,\\
H_1I_4,\ I_1H_4,\ e_1I_3,\ o_2H_3 .
\end{gathered}                                      \tag{7}
\]
Here \(B_3\) is the mixed vacancy block, with
\(v=3,s=1,u=1,w=4\); the three labels in
(7) refer to the actual block indices.
The opposite-side chords are nested or disjoint:
\(H_1I_4\) encloses \(I_1H_4\);
that chord encloses \(e_1I_3\), which encloses
\(o_2H_3\) and the link \(e_2o_3\).
The other standard links lie in the remaining
disjoint intervals. The unchanged closing
interlacement chain of Note 274 connects the site
and residual-square chords. The edge \(e_1I_3\)
interlaces the face chords of \(B_1,B_3\),
while \(e_2o_3\) interlaces those of \(B_2,B_3\);
every other chord interlaces one of these face
chords or the closing chain. Thus the full
interlacement graph is connected, excluding
two-edge cuts; the cubic lemma of Note 182
gives three-vertex-connectivity. The parent is
a 34-vertex Barnette graph.

Its free spanning path across the four internal
blocks is explicitly
\[
\begin{split}
o_1,a_1,b_1,a_2,b_2,a_3,o_3,e_2,o_2,H_3,I_3,e_1,\\
I_1,H_1,I_4,H_4,o_4,e_3,b_3,a_4,b_4,e_4.
\end{split}
\]
Every consecutive pair is an old-cycle or matching
edge, and every vertex of those blocks occurs once.
The ordinary free-path flanks and the fixed
target-and-square path finish the marked cycle.

The theorem leaves the two- and three-link defect
patterns \(c=1,0\), target-bearing or site-block
vacancies, repeated vacancies in one block, gaps,
defective target order and nonsquare residual
cycles outside its scope.
[Note 278](278-missing-chain-ports-separate-and-three-free-vacancies-are-hamiltonian.md)
settles those two remaining defect counts and completes
the three-distinct-target-free-vacancy branch.
