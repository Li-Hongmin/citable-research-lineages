> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Five-root all-leaf openings with separated escape targets have marked Hamilton cycles

Consider a three-connected cubic bipartite plane parent with a selected chord-free single-hexagon opening, old Hamilton cycle
\[
 C=(w_0,Y_L,t_d,X_1,t_c,X_2,t_b,X_3,t_a,Y_R,w_*,
       \alpha,a,b,c,d,\beta,w_0).                         \tag{1}
\]
The trap chord is \(\alpha\beta\), the four escape edges are \(t_dd,t_cc,t_bb,t_aa\), and the site edges are \(q=w_0u,p=vw_*\). Suppose the ordinary-chord forest has exactly five roots; \(X_1,X_2,X_3\) are nonempty consecutive root-word sequences; \(Y_L,Y_R\) are possibly empty root-word sequences; and there are no exposed assignable special positions outside these roots. Every assigned special position belongs to a two-special leaf. No restriction is made on the number of leaves or ordinary wrappers.

We use the two-terminal form of Note 458 also when the starting graph is one path plus disjoint cycles. If restoring the leaf old edges makes those pieces connected, contract the path and cycles, choose a spanning tree of the leaf-edge quotient rooted at the path, and apply its disjoint square switches. Each switch joins a cycle to the growing path, preserves its two endpoints, and leaves all non-leaf edges untouched.

**Five-root all-leaf theorem.** The parent has a Hamilton cycle containing both \(p,q\); hence its legal \(C_4\)-expanded child is Hamiltonian.

**Proof.** Each \(X_i\) contains a root, leaving at most two roots in \(Y_L\cup Y_R\). Put
\[
 T=(c,d,t_d,X_1,t_c,X_2,t_b,X_3,t_a,a,b,c).       \tag{2}
\]
This is one cycle, using only old and escape edges, on the target span. Close each exterior root's old arc by its root chord. The resulting cycles cover every parent vertex except \(w_0,w_*,\alpha,\beta\). Let \(E\) be the old edge at each two-special leaf, and \(M\) the face matching except at \(u,v\). On these base cycles every edge of \(E\) has the disjoint square support of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md). Whenever their graph joined by \(M\) is connected, Note 458 gives a spanning \(u\)--\(v\) path; adjoining \((u,w_0,\beta,\alpha,w_*,v)\) closes the required Hamilton cycle. This covers zero exterior roots and every connected base-cycle case. One exterior root, with or without a cross-root face chord, is the all-leaf end-root theorem of [Note 500](500-two-cycle-inner-outer-splice-excludes-the-chord-free-12f-boundary.md). It remains to handle exactly two exterior roots and a disconnected face-matching graph on the three base cycles.

First suppose both exterior roots \(W_1,W_2\) lie before \(t_d\); the right-hand version follows by reflection. An isolated root \(W_i=[L_i,R_i]\) has only its two old boundary edges and its site edges in its cut. Its order is even, so cut parity and three-connectivity force \(u,v\in W_i\). All its other face edges are internal. The open-arc theorem of Note 458 supplies two spanning pairings on \(L_i,R_i,u,v\). The following two exterior paths cover every vertex outside \(W_i\):
\[
 (u,w_0\xrightarrow{\rm old}L_i),\qquad
 (R_i\xrightarrow{\rm old}t_d)\,(T-t_dd)\,
             (d,\beta,\alpha,w_*,v).                \tag{3}
\]
The two old runs in (3) traverse whichever of \(W_1,W_2\) lies outside \(W_i\); they contain no vertex of \(W_i\) except their endpoints. Their pairing is \((u,L_i)(R_i,v)\). Choose an internal pairing different from it.

If neither exterior root is isolated but the three-cycle face graph is disconnected, then \(T\) is isolated and \(W_1,W_2\) are face-matched to each other. Their consecutive union \(U=W_1\cup W_2\) has only two old boundary edges plus site edges in its cut, so parity and three-connectivity put \(u,v\) in \(U\). Apply Note 458's open-arc argument to the entire old \(L_1\)--\(R_2\) arc of \(U\), whose internal face matching stays in \(U\). It gives two spanning pairings of \(L_1,R_2,u,v\). The exterior paths \((u,w_0,L_1)\) and \((R_2,t_d)(T-t_dd)(d,\beta,\alpha,w_*,v)\) have pairing \((u,L_1)(R_2,v)\); choose the other. This finishes the same-side case.

Now let one exterior root \(L=[L_\ell,L_r]\) lie before \(t_d\) and the other \(R=[R_\ell,R_r]\) after \(t_a\). If \(L\) is isolated in the three-cycle face graph, the even-cut argument puts both site ports in \(L\). The other two cycles \(T\) and the root cycle of \(R\) must be face-matched to each other: otherwise \(R\) would also be isolated and would require both site ports. The zero-terminal square-switch theorem of Note 458 gives a spanning cycle \(Z\) on their union, preserving \(t_dd\). Two pairings on the old \(L_\ell\)--\(L_r\) arc of \(L\) close with
\[
 (u,w_0,L_\ell),\qquad
 (L_r,t_d)(Z-t_dd)(d,\beta,\alpha,w_*,v).           \tag{4}
\]
An isolated \(R\) is symmetric. Thus assume the face graph is disconnected with \(T\) isolated and \(L,R\) face-matched to each other.

In this last case all three target intervals contain exactly one root, say \(W_1,W_2,W_3\). Both site ports lie in \(L\cup R\). Indeed, for a face edge \(yx\) with \(y\in L,x\in R\), a site \(u\) in \(T\) would make \(w_0<y<u<x\), so \(q=w_0u\) crosses \(yx\) on the common-face side; a site \(v\) in \(T\) would make \(y<v<x<w_*\), so \(p=vw_*\) crosses it.

View the target span as a four-pole \(X\), with boundary terminals \(t_d,t_a,d,a\). It has the old-edge spanning two-path cover
\[
 (t_d,W_1,t_c,W_2,t_b,W_3,t_a),\qquad(d,c,b,a),
 \quad\pi_X^0=(t_d,t_a)(d,a).                         \tag{5}
\]
It also has a cover with the different pairing \(\pi_X^1=(t_d,d)(t_a,a)\). Keep \(t_dd\) as the first path. Start the second with
\[
       (a,b,c,t_c,W_2,t_b,W_3,t_a),                 \tag{6}
\]
and close the old \(W_1\)-arc by its root chord. No face edge leaves \(X\), and no site lies in it. The even cut of \(W_1\) has only its two old boundary edges unless it sends face edges to \(W_2\) or \(W_3\); three-connectivity therefore forces such a face edge. Match the leaf specials by \(M_X\), delete their edges \(E_X\), and apply the two-terminal leaf-square switches of Note 458 to the path (6) and the \(W_1\)-cycle. Their quotient is connected by this cross-root face edge. The switches absorb the latter cycle into one spanning \(a\)--\(t_a\) path while leaving \(t_dd\) untouched. This proves \(\pi_X^1\).

Let \(Y\) contain \(L,R,w_0,w_*,\alpha,\beta\). Its four boundary terminals are \(L_r,R_\ell,\beta,\alpha\), joined to \(X\) by the four actual edges
\[
               L_rt_d,\quad R_\ell t_a,\quad\beta d,\quad\alpha a. \tag{7}
\]
Write \(P_L,P_R\) for the old root arcs, \(E_Y\) for their leaf edges, and \(M_Y\) for their face matching outside \(u,v\). Form
\[
 F_Y=(P_L\cup P_R-E_Y)\cup M_Y
      \cup\{uw_0,w_0L_\ell,vw_*,w_*R_r,\alpha\beta\}. \tag{8}
\]
Every vertex has degree two except the four boundary terminals. The edge \(\alpha\beta\) is one terminal path. Restoring \(E_Y\) makes the root part connected because a face edge links \(L\) and \(R\); leaf-square switches then give one spanning \(L_r\)--\(R_\ell\) path. Hence \(Y\) has pairing \((L_r,R_\ell)(\beta,\alpha)\), which corresponds under (7) to \(\pi_X^0\). Join this cover of \(Y\) to the cover \(\pi_X^1\) of \(X\). Distinct pairings on four ports form one cycle; (7) produces a spanning Hamilton cycle. The two site edges occur in (8), so the cycle is marked. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the legal child. \(\square\)

**Next-boundary consequence.** At \(c=5f-10\), the chord-free charge profile \((m,R)=(f+1,5)\) has zero slack in equation (9) of [Note 499](499-rethreaded-one-defect-splice-leaves-one-12f-boundary-profile.md), so all assigned special positions belong to two-special leaves and no assignable position is exposed. If its child were non-Hamiltonian, no two escape targets could be adjacent by the merger of [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md), so the three \(X_i\) would be nonempty and the theorem would apply. Thus the entire profile is excluded from a non-Hamiltonian child, regardless of root placement or the number of leaf and wrapper vertices.

At the same count, \((m,R)=(f,3)\) has charge deficit one. The nonnegative slack identity forces \(h=d=e=0,\delta=1\): \(h=0\) implies \(M_0=L=f\) and every assigned position lies in a two-special leaf, so \(e=0\). Exactly two assignable positions are exposed. The three-root all-leaf closure in Note 499 treats those two exposed positions without using wrapper saturation, and therefore also excludes this profile. Combining the charge bound with the escape restrictions of [Note 457](457-single-hexagon-failures-have-at-most-six-plus-twelve-f-vertices.md), a remaining hypothetical non-Hamiltonian opening at \(c=5f-10\) must have
\[
 (m,R)\in\{(f-1,1),(f,2),(f+1,3),(f+1,4)\}.       \tag{9}
\]
This is only a necessary profile list for one selected opening; it does not decide those four profiles, other openings, or Barnette's conjecture. The upstream classification in Notes 483–500 and the new pairing proof here have not had independent external review.
