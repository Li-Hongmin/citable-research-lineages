> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RCA is a two-cycle minimum, while root-fixed Kempe connectivity is nonmonotone

[Note 058](058-every-planar-brace-root-edge-has-a-separated-initial-factor.md)
proves that every root edge of a simple plane cubic bipartite brace has a
complementary 2-factor separating its endpoints. This note identifies the
exact global content of the absorption statement in
[Note 057](057-planar-two-path-covers-require-root-preserving-cycle-absorption.md)
and the strictly stronger local move that it does not assert.

## RCA is exactly the endpoint-separated two-cycle condition

Let \(F\) be a simple plane cubic bipartite brace and let \(e=rs\). Define

\[
\mathcal S_e=
\left\{
M:\ M\text{ is a perfect matching of }F,\ e\in M,\ 
r,s\text{ lie on distinct cycles of }F-M
\right\}.
\tag{1}
\]

By Note 058, \(\mathcal S_e\ne\varnothing\). Put

\[
\mu_F(e)=\min_{M\in\mathcal S_e} c(F-M),
\tag{2}
\]

where \(c(D)\) denotes the number of components of a 2-factor \(D\).
Then RCA for the fixed pair \((F,e)\) is equivalent to

\[
\mu_F(e)=2.
\tag{3}
\]

Indeed, if (3) holds, a minimizer \(M_*\) supplies, for every separated
factor with more than two cycles, another factor with the same root
invariants and fewer cycles. Conversely, RCA repeatedly decreases the
positive integer \(c(F-M)\); it terminates at two rather than one because
the two root vertices remain on distinct cycles.

Thus universal RCA is exactly the endpoint-separated two-cycle condition
(T) of Note 057 for every root edge. RCA, as stated there, does not require
the new factor to be obtained from the old one by one alternating flip.
A one-flip descent theorem is a sufficient strengthening, not an equivalent
restatement. Condition (T), and hence RCA, remains sufficient for the planar
two-path statement (A), but no converse is asserted.

## Exact effect of an alternating flip

Fix \(M\in\mathcal S_e\), write \(D=F-M\), and let \(A\) be an
\(M\)-alternating cycle with \(e\notin E(A)\). Set

\[
M'=M\triangle E(A),\qquad D'=D\triangle E(A).
\tag{4}
\]

An alternating cycle avoiding \(e\) also avoids \(r\) and \(s\), because
\(e\) is their unique incident \(M\)-edge. Let

\[
S=E(A)\cap E(D)
\]

and let \(p\) be the number of old cycles of \(D\) meeting \(S\). Cutting
the edges of \(S\) turns those cycles into path segments. On their
\(2|S|\) endpoints define two perfect pairings:

- \(\alpha\) pairs the two ends of each path segment of \(D-S\);
- \(\beta\) pairs endpoints joined by the new edges
  \(E(A)\cap M\).

If

\[
q=\operatorname{comp}(\alpha\cup\beta),
\tag{5}
\]

then the \(q\) alternating polygon components of
\(\alpha\cup\beta\) are exactly the new affected cycles. Hence

\[
c(D')=c(D)-p+q.
\tag{6}
\]

If an affected old cycle contains a root, mark the unique segment
containing that root. Root separation survives precisely when the
\(r\)-marked and \(s\)-marked segments occur in different components of
\(\alpha\cup\beta\), with an untouched root cycle treated as its own marked
component.

The same construction applies to any disjoint union of alternating cycles.
Consequently, if \(\mu_F(e)\ge3\), a minimizing separated factor satisfies

\[
q\ge p
\tag{7}
\]

for every alternating union that preserves the two root marks. Equation
(7) is the exact decorated obstruction in a counterexample.

One useful sufficient move is also immediate. If a single alternating
cycle meets each of its \(p\) affected old cycles in exactly one
\(D\)-edge, then \(q=1\). In a simple graph \(p\ge2\), so the flip strictly
decreases the cycle count. If it does not meet both root cycles, it also
preserves root separation. The undecorated matching quotient does not
detect this criterion: it records the visited old cycles but omits their
cyclic cut order, which is exactly the pairing \(\alpha\).

## What planar Kempe equivalence actually supplies

Belcastro and Haas prove that every planar bipartite cubic graph has one
3-edge-colouring Kempe-equivalence class, and that two equivalent proper
edge colourings which agree on the edges incident with a vertex can be
joined by a Kempe-switch sequence that never changes those incident
colours (Theorem 3.1 and Corollary 4.3).

Applied here, these results imply a genuine but weaker connectivity
statement. Every perfect matching \(M\ni e\) extends to a 1-factorization
of \(F\), because the cycles of \(F-M\) are even. Globally permute the
three colours so that every such colouring has the same colours on the
three edges incident with \(r\). The root-fixed colourings then form one
Kempe-connected space. Projecting away the two complementary colour
phases connects the perfect matchings containing \(e\) by alternating
switches that retain \(e\).

The projected matching connectivity itself is elementary: for two perfect
matchings containing \(e\), their symmetric difference is a disjoint union
of alternating cycles avoiding \(e\). The additional Belcastro--Haas
content is that the path lifts to compatible ordered 1-factorizations while
the complete root star remains colour-fixed.

This does not imply (3). The theorem starts with two already existing
colourings and supplies a path between them; it does not produce a
colouring whose complementary 2-factor has two cycles. Moreover,
root-fixed switches need not preserve the condition that \(r,s\) lie on
different complementary cycles, and (6) gives no monotone sign for their
cycle-count changes. Invoking root-fixed connectivity with a two-cycle
target would therefore assume precisely the missing conclusion.

The failure of root separation is already visible in the cube \(Q_3\).
Label its vertices by binary strings and let

\[
r=000,\qquad s=001,\qquad e=000\,001,
\]

with perfect matching

\[
M=\{000\,001,\ 010\,011,\ 100\,101,\ 110\,111\}.
\tag{8}
\]

The complement \(Q_3-M\) is the union of the two square layers with last
coordinate zero and one, so its two cycles contain \(r\) and \(s\)
separately. Colour \(M\) with colour one and alternate colours two and
three on the squares so that \(010\,110\) and \(011\,111\) have colour
two. Then

\[
A=010-011-111-110-010
\]

is a one--two Kempe cycle avoiding \(r,s\). Switching on \(A\) fixes the
root star and retains \(e\) in the colour-one matching, but the new
complement is the Hamilton cycle

\[
000-010-011-001-101-111-110-100-000.
\tag{9}
\]

Here \(p=2,q=1\): the switch decreases the unmarked cycle count precisely
by merging the two marked root cycles. Its reverse increases the count.
Thus root-star preservation neither preserves endpoint separation nor
orients the cycle-count potential, even inside a plane cubic bipartite
brace.

The source is S.-M. Belcastro and R. Haas, *Counting
edge-Kempe-equivalence classes for 3-edge-colored cubic graphs*,
**Discrete Mathematics** 325 (2014), 77--84,
DOI [10.1016/j.disc.2014.02.014](https://doi.org/10.1016/j.disc.2014.02.014),
arXiv:[1209.1730](https://arxiv.org/abs/1209.1730). The statements and
proof of Theorem 3.1 and Corollary 4.3 were checked on 2026-08-26.

## Boundary

Neither RCA nor the endpoint-separated two-cycle condition is proved or
refuted. The local-flip route is reduced to forcing an alternating union
with \(q<p\) and the two root marks in distinct
\(\alpha\cup\beta\)-components. Planarity must act on the cyclic attachment
orders, not merely on the bare matching quotient or the connectivity of
the root-fixed Kempe graph. The direct face-constrained dual-unicycle route
from Note 057 remains independent.
