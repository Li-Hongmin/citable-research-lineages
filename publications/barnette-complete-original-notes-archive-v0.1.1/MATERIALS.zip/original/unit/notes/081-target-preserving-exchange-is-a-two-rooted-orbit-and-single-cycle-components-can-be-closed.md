> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Target-preserving exchange is a two-rooted orbit, and single-cycle components can be closed

[Note 079](079-sector-collision-calculus-exposes-the-essential-brace-boundary.md)
turns every repeated one-sided sector block into a bond saturated by a rooted
target matching except for two independent holes.  The brace axiom extends
those holes to a perfect matching, but it does not say whether the resulting
alternating surgery preserves the two rooted complement cycles.  This note
gives the exact missing topological condition.

For an arbitrary vertex-disjoint union of alternating cycles, target
preservation is equivalent to a two-rooted endpoint-orbit condition.  In the
one-carrier case this becomes a simultaneous chord-order test.  Two
same-orientation holes alone necessarily fail that test, and a smallest
order-\(12\) plane brace shows that \(2\)-extendability does not supply a more
useful alternating cycle through them.

There is a separate family-level obstruction.  In the complete minimum
two-\(C_4\) brace-repair class of [Note 080](080-minimum-brace-repairs-supplement-rather-than-repair-the-bad-target-cube.md),
six repaired target families contain a closed four-state, all-double-gate
single-cycle exchange component even though neutral targets exist elsewhere
in the same family.  Thus neither local hole extension nor iterated
single-cycle target exchange is the missing complete-family theorem.

## 1. The endpoint transition quotient

Let \(G\) be a cubic graph, let \(M\) be a perfect matching and suppose

\[
F=G-M=C_0\mathbin{\dot\cup}C_1
\tag{1}
\]

is the disjoint union of two cycles.  Fix a root edge \(e=rs\in M\), where
\(r\in C_0\) and \(s\in C_1\).  Thus \(M\) is a rooted target.

Let 

\[
\mathcal A=A_1\mathbin{\dot\cup}\cdots\mathbin{\dot\cup}A_k
\tag{2}
\]

be a vertex-disjoint union of \(M\)-alternating cycles with
\(e\notin E(\mathcal A)\).  Put

\[
D=E(\mathcal A)\cap E(F),\qquad
T=E(\mathcal A)\cap M,
\qquad M'=M\mathbin\triangle E(\mathcal A).
\tag{3}
\]

The edges of \(D\) form a matching.  Let \(\Omega\) be their endpoint set.
There are three fixed-point-free involutions on \(\Omega\):

- \(h\) pairs the endpoints of each deleted edge in \(D\);
- \(t\) pairs endpoints joined by an inserted matching edge in \(T\);
- \(p\) pairs the endpoints of every path component obtained by deleting
  \(D\) from a touched cycle \(C_i\).

Let \(u\) be the number of cycles among \(C_0,C_1\) untouched by \(D\), and
let \(c(p,t)\) be the number of components of the two-regular multigraph
\((\Omega,p\cup t)\).  Equivalently,

\[
c(p,t)=\frac12\operatorname{cyc}(pt),
\tag{4}
\]

where fixed points of \(pt\) are counted and a doubled \(p=t\) edge is one
component.

**Rooted transition-orbit theorem.**  One has

\[
\boxed{
\#\operatorname{comp}(G-M')
=u+c(p,t)
=u+\frac12\operatorname{cyc}(pt).}
\tag{5}
\]

Moreover,

\[
\boxed{
M'\text{ is a rooted target}
\iff
u+c(p,t)=2
\text{ and the residual paths containing }r,s
\text{ lie in different components}.}
\tag{6}
\]

**Proof.**  Deleting \(D\) cuts every touched \(C_i\) into paths whose
endpoints are paired by \(p\); untouched cycles remain components.  Toggling
\(\mathcal A\) inserts exactly the edges paired by \(t\).  Hence every
component of \(G-M'=(F-D)+T\) is either an untouched cycle or an alternating
component of \(p\cup t\), proving (5).  Since \(e\notin\mathcal A\), the
root remains in \(M'\).  No edge of \(D\) is incident with \(r\) or \(s\):
otherwise alternation would force their unique incident matching edge \(e\)
into \(\mathcal A\).  The two root labels therefore lie on well-defined
residual paths, and they are separated precisely by the last condition in
(6).  \(\square\)

This is an endpoint theorem rather than a disguised target hypothesis.  It
constructs \(G-M'\) from the deleted complement edges and inserted matching
edges, and then reads both its component count and root placement.

If \(D\subseteq E(C_0)\), then \(C_1\) is untouched and already contains
one root endpoint.  The carrier component contains the other, so root
separation is automatic.  Consequently

\[
\boxed{
D\subseteq E(C_0)
\Longrightarrow
\bigl(M'\text{ is a rooted target}\iff p\cup t\text{ is connected}\bigr).}
\tag{7}
\]

## 2. A constructive chord-order family

Orient the carrier \(C_0\).  Suppose \(D\) consists of \(m\) holes of one
bipartite orientation, appearing as

\[
h_i=x_i y_i,\qquad x_i\in X,\ y_i\in Y,\qquad i\in\mathbb Z/m\mathbb Z.
\tag{8}
\]

Then

\[
h=(x_i,y_i)_i,\qquad p=(y_i,x_{i+1})_i.
\tag{9}
\]

Suppose \(M\) contains the chord system

\[
t_s=(y_i,x_{i+s})_i.
\tag{10}
\]

The edges \(D\cup t_s\) form one alternating cycle exactly when following
\(h\) and \(t_s\) advances the index transitively, or
\(\gcd(m,s)=1\).  The toggled carrier stays connected exactly when following
\(p\) and \(t_s\) is transitive, or \(\gcd(m,s-1)=1\).  Hence

\[
\boxed{
D\cup t_s\text{ is one alternating cycle and its toggle preserves the target}
\iff
\gcd(m,s)=\gcd(m,s-1)=1.}
\tag{11}
\]

For every odd \(m\ge3\), the choice \(s=2\) satisfies (11).  This is a
nonvacuous sufficient surgery pattern, but the brace axiom does not force
its chord system to occur.

## 3. Two same-orientation holes necessarily split the carrier

For \(m=2\), write the same-orientation holes in carrier order as

\[
x_1y_1,\ldots,x_2y_2,\ldots,
\qquad x_1,x_2\in X,\quad y_1,y_2\in Y.
\tag{12}
\]

Deleting them gives the residual-path pairing

\[
p=(y_1,x_2)(y_2,x_1).
\tag{13}
\]

Among the three pairings of their four endpoints, the hole pairing itself
cannot be supplied by distinct matching edges, while the remaining pairing
the pairing \((x_1,x_2)(y_1,y_2)\) is forbidden by bipartiteness.  Thus any
alternating cycle using exactly these two complement edges must have
\(t=p\).  The deleted holes and \(t\) do form one alternating \(4\)-cycle,
but \(p\cup t\)
has two doubled-edge components.  With the untouched second complement
cycle, the toggle has three components:

\[
\boxed{
\text{a two-hole-only toggle through same-orientation carrier holes
splits the carrier and is not a rooted target}.}
\tag{14}
\]

The orientation assumption is essential.  For opposite-orientation holes,
the pairing in (13) is the same-colour pairing and is forbidden; the other
cross-colour pairing connects the residual paths.  Conditional on the two
required matching chords existing, the two-hole toggle then preserves the
carrier.

In a sector collision, the two holes lie on the same complement cycle:
every cycle crosses the collision bond evenly, and the whole complement has
only two edges in that bond.  Their same orientation follows from their
same-parity positions on the alternating facial arc.  Thus (14), not merely
the weaker same-carrier statement, applies to the two-hole-only candidate
from Note 079.

## 4. A minimum plane-brace surgery counterexample

The failure is not caused by a tight cut.  Let \(G\) have vertex set
\(\{0,\ldots,11\}\), complement cycles

\[
C_0=(0,1,2,3,4,5,6,7),\qquad C_1=(8,9,10,11),
\tag{15}
\]

and perfect matching

\[
M=\{05,14,29,38,6\,11,7\,10\}.
\tag{16}
\]

Take root \(e=6\,11\), gates \(29,38\), holes \(01,45\), and shore
\(S=\{1,2,3,4\}\).  Then

\[
\delta(S)=\{01,45,29,38\},qquad
\delta(S)-M=\{01,45\}.
\tag{17}
\]

The unique \(M\)-alternating cycle containing both holes is

\[
A=(0,1,4,5,0).
\tag{18}
\]

It avoids the root and both gates, but after toggling it the complement
cycles are

\[
(1,2,3,4),\qquad(0,5,6,7),\qquad(8,9,10,11).
\tag{19}
\]

The graph is simple, cubic and bipartite.  A spherical rotation system has
face lengths \(4,4,4,4,4,4,6,6\).  Its \(20\) perfect matchings extend every
independent edge pair, so it is a plane brace.  Uniqueness in (18) is local:
at the four hole endpoints alternation forces the matching edges \(14,05\),
which already close the displayed cycle.

This order is sharp for the same-orientation two-hole obstruction.  Each of
the two residual carrier arcs has odd length.  Length one would make a
forced matching chord parallel to a carrier edge, so both have length at
least three and \(|C_0|\ge8\); the second simple bipartite complement cycle
has length at least four.  Hence \(|V(G)|\ge12\), with equality above.

The [permanent verifier](../computations/bundles/target-exchange-orbits-and-closed-components/README.md)
checks the embedding, complete perfect-matching family, \(2\)-extendability,
bond, uniqueness and toggled component count.  This example refutes every
surgery lemma using only rooted-target, brace, fixed-gate and same-carrier
two-hole data.  It does not specify the full wide facial interface of
Note 076 and therefore is not a counterexample to ordinary \(C_4\)-lifting.

## 5. Single-cycle target-exchange components can be closed

For a complete rooted target family \(\mathcal T_e\), define

\[
V(X_e)=\mathcal T_e,\qquad
MN\in E(X_e)
\iff M\mathbin\triangle N\text{ is one alternating cycle}.
\tag{20}
\]

In each of the \(32\) minimum repaired braces of Note 080, let

\[
\mathcal N_e=
\{M\in\mathcal T_e:|M\cap\{5\,13,4\,16\}|\le1\}
\tag{21}
\]

be the neutral target set.  Canonical contraction through the two repair
gadgets identifies \(126\) target occurrences descending from the original
four-state bad cube.  Their exact distances to \(\mathcal N_e\) in \(X_e\)
are

\[
\begin{array}{c|cc}
\operatorname{dist}_{X_e}(M,\mathcal N_e)&1&\infty\\ \hline
\text{occurrences}&102&24.
\end{array}
\tag{22}
\]

The \(24\) unreachable occurrences occur in exactly six of the \(32\)
labelled brace sequences.  In every failing sequence the four inherited
boundary words form a closed four-vertex component of \(X_e\), and all four
targets use both gates.  Four such components have internal exchange-length
multiset \(\{6,6,10,10\}\); two have \(\{6,6,6,6\}\).  The smallest complete
families have \(11\) targets.

For example, sequence \(350\) has \(11\) targets with gate-load profile
\((2,4,5)\) at loads \(0,1,2\).  Its four inherited targets form a \(4\)-cycle
under single-cycle exchange.  Every symmetric difference between one of
these four targets and any of the other seven targets has two or three
alternating components.  Hence the distance in (22) is genuinely infinite,
not merely greater than two.

For the \(102\) reachable inherited occurrences, every shortest path has
length one.  Across all \(510\) directed shortest witnesses, the exchange
cycle lengths are

\[
6^{12},\qquad10^{82},\qquad14^{204},\qquad18^{212}.
\tag{23}
\]

Of these, \(490\) meet both complement cycles, \(396\) meet both old tight-cut
small shores, \(316\) remove both gates and \(194\) remove one gate.  These
figures classify all shortest witnesses in the fixed repair class.

The [bundle](../computations/bundles/target-exchange-orbits-and-closed-components/README.md)
reconstructs all \(868\) two-step sequences from the permanent Note 080
bundle, selects the \(32\) braces, builds every complete target family and
checks (22)--(23).  This is not an order-\(28\) census.

## 6. Exact boundary

The alternating topology is now exact: a union of alternating cycles
preserves a rooted target if and only if its endpoint transition graph has
two root-separated components.  The criterion supports explicit positive
constructions such as (11), but the brace axiom does not force even the
smallest two-hole candidate to satisfy it.

Nor can a complete-family proof proceed by walking through single-cycle
target exchanges.  Neutral targets exist in every repaired family of
Note 080, yet six families place the inherited bad cube in another exchange
component.  Multi-cycle symmetric differences are essential.

For any two targets \(M,N\in\mathcal T_e\), the symmetric difference
\(M\triangle N\) is already a vertex-disjoint union of alternating cycles
and automatically satisfies (6).  Thus “allow all multi-cycle exchanges”
does not itself prove supplementation; it merely identifies the full target
family.  The unresolved wide-site statement remains the existence of a
neutral member of that family, or equivalently a union satisfying (6) that
removes a gate.  A face-fixed alternative is a union satisfying (6) whose
post-toggle punctured forest removes a sector collision and satisfies the
root-placement clause of Note 079(6).

**Exact conclusion.**  Target preservation under arbitrary alternating
exchange is the two-rooted orbit condition (6).  Same-orientation
two-hole-only surgery fails in a minimum plane brace, and single-cycle
target-exchange components can remain closed inside complete repaired-brace
families.

**Evidence level.**  Equations (5)--(14) and the order-\(12\) lower bound are
arbitrary-order analytic results.  The order-\(12\) realization has an
independent exhaustive certificate.  Equation (22) is an exact finite
classification of the \(868\)-sequence minimum-repair class.

**Unresolved boundary.**  It remains unknown whether every complete
terminal-fixed target family at a wide site in a plane brace contains a
neutral target.  Any proof must use common perfect-matching incidence beyond
local hole extension and beyond connectivity of the single-cycle target
exchange graph.
