> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# No short corridor between a single vacancy and a J1 double block

[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
finds an exact square-equivalent patch when a singly vacant block
immediately precedes a doubly vacant block carrying the internal
matching chord \(J_1=oh_2\). It also classifies the free group
with those two blocks and no others. Here the number of complete
short blocks *between* them is unrestricted. A positive corridor
is impossible under the same isolated-group boundary condition.

Work in a compressed, gapless, tight-target all-square opening
of a Barnette parent. Fix one target-free free group with ordinary
endports \(s\) (even) and \(t\) (odd). Its complete face blocks
are exactly a singly vacant block
\[
                 V=(a,o,h,i,e,b),
\]
a doubly vacant block
\[
                 D=(A,O,H,I,K,J,E,B),
\]
and \(k\ge0\) consecutive short blocks
\(S_j=(a_j,o_j,e_j,b_j)\), all strictly between \(V\)
and \(D\). There are no other blocks in this group. The
face-closing chords of all these blocks belong to the
complementary matching \(M\), and \(OK=J_1\in M\).

**Corridor exclusion theorem.** Necessarily \(k=0\), the
block order is \(V,D\), and the free matching is exactly
\[
                    \{sJ,oe,hI,iH,OK,Et\}.            \tag{1}
\]
In particular, every such parent has a Hamilton cycle through
both site edges if all vacancies outside this group lie in
distinct internal blocks: compress the forced patch by
Note 327, apply [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md),
and lift the marked cycle. Its legal site-expanded child is
then Hamiltonian. By reversing
the old-cycle order, the analogous statement for an internal
\(J_3=i_1e\) has the double block before the single block.

**Proof.** Note 327 proves the \(k=0\) classification. Assume
\(k\ge1\). Its chord-isolation lemma puts \(OK\) on the
common-face side and excludes every other internal free chord
of \(D\). The only possible internal free chord of \(V\) is
\(oe\); if present, it too lies on that side. Every other
free matching chord joins different blocks and lies in the
opposite-side disk by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
Thus no two cross-block chords interlace. For an opposite-side
chord, count the free slots strictly between its ends. Each
face-side chord with exactly one end inside removes one slot
from that interior; face-side chords with both ends inside
remove two. The remaining number must be even. We also use
the standard three-connectivity rule: if a proper complete
consecutive block interval is matched wholly inside itself,
its only two outgoing edges are old-cycle edges, a forbidden
two-edge cut.

First suppose the block order is \(V,S_1,\ldots,S_k,D\).
The free-slot order is
\[
 s,o,h,i,e,o_1,e_1,\ldots,o_k,e_k,O,H,I,K,J,E,t.
                                                               \tag{2}
\]
The final even slot \(E\) can match only \(o,i,o_j,t\).
The odd slots \(O,K\) are used by \(OK\), \(IE\) is
excluded by chord isolation, and \(JE\) is an old-cycle
edge. A backward chord \(Eo\) or \(Eo_j\) would close
the complete interval from its endpoint block through \(D\),
giving a two-edge cut. Suppose \(Ei\) occurs. Its
\(2k+6\) interior free slots contain both ends of \(OK\).
If \(oe\) occurs, its \(e\)-end is the sole face-side
exit and parity fails. If \(oe\) is absent, \(H\) can
match neither \(i\) (already used), \(o,t\) (outside \(Ei\)),
the old-cycle neighbor \(I\), nor \(J\) (excluded internal
chord). It must match some \(o_j\). But \(o_jH\)
encloses \(e_j\), the two slots of each later short block,
and \(O\): an even number \(2(k-j)+2\) with exactly one
face-side exit \(OK\). This violates parity. Hence
\(Et\in M\).

The left endport \(s\) can now match only \(o,i,o_j,I,J\).
An edge \(so_j\) skips the complete interval from \(V\)
through \(S_{j-1}\), giving a two-edge cut. An edge
\(si\) traps the adjacent old-cycle pair \(o,h\); the
optional \(oe\) would provide one face-side exit instead,
which also violates parity. An edge \(sI\) encloses
\(2k+6\) free slots with exactly one face-side exit
\(OK\); optional \(oe\) is wholly inside and cannot
change the parity. If \(so\) occurs, then \(oe\) is absent.
The slot \(H\) must match \(i\) or some \(o_j\): its
other available odd mates are the old-cycle neighbor \(I\),
the excluded internal chord \(HJ\), and the used slot
\(o\). The \(o_jH\) case has just failed. The chord
\(iH\) encloses \(e\), all \(2k\) short slots, and
\(O\): \(2k+2\) slots with one exit \(OK\), again
impossible. Therefore \(so\notin M\).

It remains to consider \(sJ\). Now \(H\) can match only
\(o,i\), or an \(o_j\); the last option again violates
the \(o_jH\) parity count. The chord \(oH\) encloses
\(h,i,e\), all short slots, and \(O\), giving
\(2k+4\) slots with one exit \(OK\); \(oe\) is
unavailable because \(o\) is used. Finally, \(iH\)
has \(2k+2\) interior slots and the exit \(OK\).
To restore parity it would require \(oe\), whose
\(e\)-end is a second face-side exit. Then every free
slot of \(S_1,\ldots,S_k\) must match another slot in
that same short-block interval: the only other slots
inside \(iH\) are \(e,O\), already matched by \(oe,OK\),
and an opposite-side edge cannot leave \(iH\). The entire
nonempty short-block interval would be matching-closed,
a forbidden two-edge cut. Thus \(sJ\) is impossible too.

Now suppose the order is \(D,S_1,\ldots,S_k,V\), with
free slots
\[
 s,O,H,I,K,J,E,o_1,e_1,\ldots,o_k,e_k,o,h,i,e,t.
                                                               \tag{3}
\]
The possible mates of \(s\) are \(I,J,o_j,o,i,t\).
The chord \(sI\) traps \(O,H\) with one exit \(OK\);
\(sJ\) leaves the old-cycle pair \(HI\) after the
internally matched \(O,K\). A chord \(so_j\) encloses
the complete block \(D\) and possibly earlier short
blocks; \(so\) encloses \(D\) and all the short blocks;
\(st\) encloses the whole group. Each of these three
cases gives a forbidden two-edge cut.

If \(si\) occurs, its \(2k+8\) interior free slots
contain both ends of \(OK\). An optional \(oe\)
would have exactly its \(o\)-end inside, so parity
excludes it. Without \(oe\), the slot \(H\) must match
some \(o_j\) or \(o\): \(I\) is its old-cycle neighbor,
\(HJ\) is excluded, \(i\) is used, and a mate beyond
\(si\) would cross that opposite-side chord. The chord
\(Ho_j\) encloses \(I,K,J,E\) and the two slots of each
preceding short block, an even number \(2j+2\) with
one face-side exit \(OK\). The chord \(Ho\) encloses
those four slots and all \(2k\) short slots, again an
even number with one exit. Both violate parity. This
exhausts the mates of \(s\), proving that \(k\ge1\)
is impossible in either order. \(\square\)

The theorem is conditional on this isolated free group.
Short-block flanks outside the two vacant blocks may carry
nonstandard matching links, and other vacant blocks may
interact with the corridor; neither case is classified here.
Site-block vacancies, positive gaps, defective target order,
nonsquare residual cycles, and the general Barnette conjecture
remain outside the result. The proof is analytic and project-
internal; no external priority claim is made.
