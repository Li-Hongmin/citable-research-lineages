> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A two-face-chord route closes the noncomb five-leaf word

[Note 427](427-the-first-five-leaf-matching-reduces-to-six-short-wrapper-words.md) leaves one noncomb word in row I of the five-leaf matching, with sites $(j,k)=(1,7)$. Here that word has a spanning $y_1$--$x_7$ path. Consequently every legal child with this word is Hamiltonian; the five comb words of Note 427 remain outside the conclusion.

Use the word and leaf notation of Note 427:
\[
 A=F(U_3,U_4),\quad D=F(U_6^{\rm short},U_7),\quad
 B=F(U_5,D),\quad C=F(A,B),\quad E=F(U_2,C),\quad W=F(U_1,E),
\]
where $F(P,Q)=(((P Q)))$, $U_i=((x_i y_i))$, and $U_6^{\rm short}=(x_6y_6)$. For a full leaf, its old-cycle order is $L_i,h_i,x_i,y_i,j_i,R_i$, and set
\[
\begin{aligned}
Y_i&=(y_i,x_i,h_i,j_i,R_i,L_i),\\
X_i&=(R_i,L_i,h_i,j_i,y_i,x_i),\\
O_i&=(L_i,h_i,x_i,y_i,j_i,R_i).
\end{aligned}                                                     \tag{1}
\]
The short leaf has order $L_6,x_6,y_6,R_6$ and ordinary chord $L_6R_6$.

For each occurrence $T=F(P,Q)$, denote its six bracket vertices in old-cycle order by $\lambda_0^T,\lambda_1^T,\lambda_2^T,\rho_2^T,\rho_1^T,\rho_0^T$, with the child words between $\lambda_2^T$ and $\rho_2^T$. The three bracket-only paths
\[
\begin{aligned}
P_T&=(\lambda_2^T,\lambda_1^T,\lambda_0^T,
       \rho_0^T,\rho_1^T,\rho_2^T),\\
Q_T&=(\rho_0^T,\lambda_0^T,\lambda_1^T,
       \rho_1^T,\rho_2^T,\lambda_2^T),\\
R_T&=(\rho_2^T,\lambda_2^T,\lambda_1^T,
       \rho_1^T,\rho_0^T,\lambda_0^T)
\end{aligned}                                                     \tag{2}
\]
each visit the six vertices exactly once. Every consecutive pair is an old-cycle edge or the ordinary chord $\lambda_m^T\rho_m^T$ for some $m\in\{0,1,2\}$.

**Two-chord path theorem.** In every row-I word (above), the following is a spanning $y_1$--$x_7$ path:
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,
\lambda_2^W\xrightarrow{P_W}\rho_2^W,
\rho_0^E\xrightarrow{Q_E}\lambda_2^E,
L_2\xrightarrow{Y_2^{-1}}y_2,\\
&x_3\xrightarrow{X_3^{-1}}R_3,
L_4\xrightarrow{O_4}R_4,
\rho_2^A\xrightarrow{R_A}\lambda_0^A,
\lambda_2^C\xrightarrow{P_C}\rho_2^C,\\
&\rho_0^B\xrightarrow{Q_B}\lambda_2^B,
L_5\xrightarrow{Y_5^{-1}}y_5,
x_6,y_6,R_6,L_6,
\lambda_2^D\xrightarrow{P_D}\rho_2^D,
R_7\xrightarrow{X_7}x_7.
\end{aligned}                                                     \tag{3}
\]
The two jumps between lines and leaf pieces are exactly the available face chords $y_2x_3$ and $y_5x_6$ from Note 427. All other joins in (3) are consecutive old-cycle edges:
\[
\begin{gathered}
L_1\lambda_2^W,\quad \rho_2^W\rho_0^E,\quad
\lambda_2^E L_2,\quad R_3L_4,\quad R_4\rho_2^A,\\
\lambda_0^A\lambda_2^C,\quad \rho_2^C\rho_0^B,\quad
\lambda_2^B L_5,\quad L_6\lambda_2^D,\quad \rho_2^D R_7.
\end{gathered}                                                     \tag{4}
\]
The segment $(x_6,y_6,R_6,L_6)$ uses two old-cycle edges and the short leaf's ordinary chord. Formula (1) supplies spanning paths within the six full leaves. Formula (2) supplies all six vertices of each of the six branches $W,E,A,C,B,D$ exactly once. Thus (3) contains $6\cdot6+4+6\cdot6=76$ distinct vertices, all of $W$, and every step is an edge.

For a legal completion in the normal form of [Note 416](416-a-chorded-seven-face-chord-failure-has-one-seven-leaf-root.md), close (3) by the two site edges and the fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), replacing its site labels by $y_1,x_7$. This is a Hamilton cycle of the parent containing both site edges. The square expansion therefore has a Hamilton cycle by [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md). The unused five main face chords have no bearing on this certificate. \(\square\)

This result removes the last, two-cherry row of Note 427's necessary list. Up to reflection, any non-Hamiltonian legal row-I child must now use one of its five comb words. It does not classify their realizability or Hamiltonicity, the other face-matching rows, or Barnette's conjecture.
