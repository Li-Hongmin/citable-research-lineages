> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A prescribed mixed Hamilton overlay need not contain its escape

[Note 124](124-root-smoothing-does-not-turn-mixed-sector-survival-into-parity.md)
turns each rooted target into a Hamilton cycle through two distinguished
root-smoothing edges.  It leaves open the possibility that a mixed pair
itself contains a useful partial surgery even though parity and bondwise
pairing fail.  This note closes that route with an actual legal-wide split.

For one sterile state-(11) endpoint (chi^b), the Boolean escape exists,
but four of its six mixed neighbours individually admit no same-sector
escape under any proper-arc surgery of their Hamilton overlay.  The global
escape is obtained only after selecting a different mixed sibling.  Thus a
proof of mixed-sector survival must select over the complete endpoint star;
it cannot begin with an arbitrary prescribed mixed bond.

## 1. The complete two-target surgery class

Let (Gightsquigarrow G^+) be a legal (C_4)-expansion at
(p,q), and put

\[
 E_0=E(G)\setminus\{p,q\}.
\tag{1}
\]

Let (M_\chi,M_\eta) be parent rooted-target matchings such that

\[
 K=M_\chi\mathbin\triangle M_\eta
\tag{2}
\]

is one alternating cycle.  A parent matching (N) is
**overlay-local** when

\[
 N\mathbin\triangle M_\chi\subseteq K.
\tag{3}
\]

A child matching (N^+) is overlay-local when

\[
 N^+\cap E_0
 \subseteq
 (M_\chi\cup M_\eta)\cap E_0.
\tag{4}
\]

Condition (4) is exactly the full class of proper-arc surgeries in the
two-target Hamilton overlay.  Off (K), the two parent matchings coincide,
so the degree-one matching equation forces their common edge.  On (K), a
choice between the two alternating edge classes can change only where an
expansion port is exposed.  The seven local patch rows

\[
 C_{00},C_{10},C_{01},C_{11},R_{00},X_{uy},X_{vx}
\tag{5}
\]

repair all possible sets of (0,2), or (4) exposed ports.  Conversely,
every proper-arc switch repaired inside the patch satisfies (4) and one row
of (5).  Thus (4) omits no local (2)-opt or arc reconnection; it excludes
only a retained old edge outside the prescribed overlay.

After root smoothing, (K) is the symmetric-difference cycle of two
Hamilton cycles.  Their common edges form disjoint paths pairing the
vertices of (K): every vertex of (K) has one common incident edge, and
there can be no common cycle disjoint from (K).  Contracting the common
paths gives a cycle with a chord pairing, and adjoining either alternating
edge class of (K) gives one cycle.  This is the exact finite object on
which (4) performs its arc surgeries.

## 2. An actual prescribed-overlay counterexample

Use the fixed parent

```text
graph6 = W???????????w?s?P_BC?I_?L??J??B_?AW??F??_W?AC_?
root = 7-17
forced gate = 5-18
surviving gate = 3-13
site = {1-15, 10-22}
```

and the sterile state-(11) matching (chi) in sector (1) from
[Note 124](124-root-smoothing-does-not-turn-mixed-sector-survival-into-parity.md).
Its parent rooted fibre has (13) matchings, and (chi) has six
single-cycle mixed neighbours.  The lexicographically first is

\[
\begin{split}
M_{\eta_0}=\{&(0,12),(1,13),(2,15),(3,23),(4,14),(5,18),\\
&(6,16),(7,17),(8,19),(9,20),(10,21),(11,22)\}.
\end{split}
\tag{6}
\]

It has state (00) and sector (0).  The alternating difference cycle is

\[
K=(1,13,3,23,11,22,10,21,9,20,6,16,2,15).
\tag{7}
\]

After root smoothing, the endpoint pairing of the seven maximal common
Hamilton paths is

\[
(1{:}2)(3{:}22)(6{:}15)(9{:}16)
(10{:}20)(11{:}21)(13{:}23).
\tag{8}
\]

Equation (3) produces only (M_\chi) and (M_{\eta_0}), so it contains no
same-sector non-(11) parent target.  Complete enumeration of (4) gives
exactly five child matchings:

\[
\begin{array}{c|c|c|c}
\text{cell}&\text{repaired old endpoints}&\text{root-separated}
&\text{sector}\\ \hline
R_{00}&1,10,15,22&\text{no}&0\\
C_{00}&1,10,15,22&\text{yes}&0\\
X_{vx}&1,22&\text{yes}&0\\
X_{uy}&10,15&\text{no}&1\\
C_{11}&\varnothing&\text{no}&1.
\end{array}
\tag{9}
\]

The two natural state-(00) hybrids therefore split the two essential
predicates: (X_{vx}) is Hamiltonian and root-separated but lies in the
wrong gate sector, whereas (X_{uy}) lies in the correct sector but is not
root-separated.  None of the five rows is a same-sector new-cell rooted
target.

This is a genuine counterexample to the prescribed-overlay implication

\[
 \eta\in{\cal M}_\chi
 \quad\Longrightarrow\quad
 \operatorname{OL}^+(\chi,\eta)\cap{\cal X}^b\ne\varnothing,
\tag{10}
\]

even with every patch row and every proper-arc surgery allowed.

## 3. The Boolean escape comes from a sibling

The complete child family nevertheless contains two same-sector targets,
both of type (X_{uy}).  Across the six mixed neighbours, the numbers of
overlay-local child matchings are

\[
(5,5,2,5,5,2),
\tag{11}
\]

and the corresponding accepted new-cell rooted-target counts are

\[
(0,0,0,1,1,0).
\tag{12}
\]

Thus mixed ordinals (0,1,2,5) fail completely, while ordinals (3,4)
each produce one accepted (X_{uy}) target.

Relative to
((M_\chi\cup M_{\eta_0})\cap E_0), the two global targets use exactly one
additional retained matching edge:

\[
\{10{-}20\},\qquad \{6{-}15\}.
\tag{13}
\]

Each edge has five suppliers in the complete parent rooted fibre.  Among
the six single-cycle mixed neighbours of (chi), however, its supplier is
unique: ordinal (3) supplies (10{-}20), and ordinal (4) supplies
(6{-}15).  Both suppliers have state (00), and
(M_\chi\cup M_{\eta_3}), respectively
(M_\chi\cup M_{\eta_4}), already contains the entire retained support of
the associated child target.  The repair is therefore not a three-target
overlay.  It discards the bad prescribed neighbour and selects a good
sibling mixed bond.

## 4. Alternating-square component bridges

The failed same-sector (X_{uy}) surgery for (eta_0) has a smoothed
complement consisting of the path

\[
10-20-6-15
\]

and one residual (18)-cycle.  The two sibling repairs act through the
alternating squares

\[
9-20-10-21-9,
\qquad
2-15-6-16-2.
\tag{14}
\]

In the first square, the failed complement uses (10{-}20) on the short
path and (9{-}21) on the residual cycle.  Flipping the square removes
those two edges and inserts (9{-}20,10{-}21), joining the path and cycle
into one spanning path.  The second square performs the analogous switch
with (6{-}15,2{-}16).  Both squares avoid the root, gates, and patch, so
the required sector, local row, and labelled endpoints are unchanged.

This is an instance of a general sufficient move.  Let a new-cell matching
(N) have the correct local row, root labels, and gate sector, while its
smoothed complement consists of one prescribed-endpoint path and some
cycles.  If an (N)-alternating (C_4), disjoint from the labelled
interfaces, has its two complement edges in distinct components, then
flipping that (C_4) merges the two components and preserves every labelled
endpoint.  Consequently a family of such squares whose component-incidence
edges form a tree removes all residual cycles.  We call this an
**alternating-square component bridge**.

The lemma is purely sufficient: a matching edge supplied somewhere in the
complete parent family matters only when its alternating square actually
bridges two complement components.  Ordinary edge coverage or
(2)-extendability does not state this connectivity condition.

## 5. Consequence

The example proves the strict boundary

\[
\boxed{
\begin{gathered}
\text{a fixed mixed Hamilton overlay need not contain any surviving
escape;}\\
\text{the complete endpoint star may still contain a good mixed sibling.}
\end{gathered}}
\tag{15}
\]

Hence non-target intermediates and multi-cycle moves inside one prescribed
overlay are not the first missing ingredient.  The smallest surviving
selection statement is instead

\[
 {\cal E}_\chi=\varnothing,quad {\cal M}_\chi\ne\varnothing
 \quad\Longrightarrow\quad
 \exists\eta\in{\cal M}_\chi:
 \operatorname{OL}^+(\chi,\eta)\cap{\cal X}^b\ne\varnothing.
\tag{16}
\]

Equation (16) is stronger than the Boolean adjacent-escape assertion and is
not proved here.  It is a complete-family sibling-selection problem, not a
pairwise surgery, parity, cardinality, or injection problem.  The fixed
counterexample and the sibling mechanism are independently reconstructed by
the [mixed-overlay surgery bundle](../computations/bundles/mixed-overlay-local-surgery-counterexample/README.md).
