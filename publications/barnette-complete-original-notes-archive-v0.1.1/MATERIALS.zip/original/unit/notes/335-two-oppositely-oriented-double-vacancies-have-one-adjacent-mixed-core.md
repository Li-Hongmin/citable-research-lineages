> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two oppositely oriented double vacancies have one adjacent mixed core

[Note 334](334-every-all-j1-double-vacancy-group-reduces-to-squares.md)
reduces a target-free group made of short blocks and double blocks of
one chord orientation. Here there are exactly two double blocks, one
carrying \(J_1\) and the other \(J_3\). Their order has a sharp
asymmetry. One order is impossible; in the other they must be adjacent.
A further cross chord then gives a new, realizable square-equivalent
four-terminal patch.

Work in the compressed, gapless, tight-target all-square opening of
[Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix an ordinary target-free free group with even left and odd right
endports. Exactly two complete blocks are doubly vacant, all other
complete blocks of the group being short and target-free. Write the
double blocks in old-cycle order as
\[
D=(a,o,h,i,k,j,e,b),\qquad
D'=(A,O,H,I,K,J,E,B).                                      \tag{1}
\]
The only internal free chord of a \(J_1\) block is \(ok\), and the
only one of a \(J_3\) block is \(ie\), both on the common-face side,
by the chord-isolation lemma of [Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md).
All cross-block free chords lie on the opposite side by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).

**Mixed-pair theorem.** If \(D\) carries \(J_1=ok\) and \(D'\)
carries \(J_3=IE\), the opening is impossible. If \(D\) carries
\(J_3=ie\) and \(D'\) carries \(J_1=OK\), there is no short block
between them, and the cross-block matching edges
\[
                         jH,\qquad kI                       \tag{2}
\]
are forced. No claim is made here about the remaining free slots
\(o,h,J,E\) when they meet the short-block flanks.
If there are no short-block flanks either, then \(hJ\) is forced;
thus every valid group consisting of just these two mixed double
blocks has the square reduction below.
The extra condition \(hJ\) is necessary when short-block flanks
are allowed: a thirty-two-vertex Barnette realization below has
one short block before \(D\) and matches \(h\) and \(J\) outside
the two-block interval.
Nevertheless, if all short blocks of the group lie on just one
side of the adjacent mixed pair, with no bound on their number,
the group has a spanning path between its ordinary endports.
The right-sided assertion follows by reflection. When all other
vacancies occupy distinct internal blocks, this path gives a
Hamilton parent cycle through both site edges and a Hamiltonian
legal site-expanded child.

If, in the second case, \(hJ\) is also a matching edge, the two
adjacent double blocks induce the sixteen-vertex patch \(T\) with
old-cycle path (1), face-side chords
\[
                    ab,\quad ie,\quad AB,\quad OK,           \tag{3}
\]
and opposite-side chords \(kI,jH,hJ\). Its degree-two terminals
are \((a,o,E,B)\) in disk-boundary order. Its complete spanning
one-path and two-path Hamilton signature equals that of the
labeled square \((a',o',E',B')\). Replacing \(T\) by the square,
or conversely, preserves Barnette membership and every Hamilton
decision marked on exterior or attachment edges. The patch occurs
in an explicit Hamiltonian Barnette graph. Consequently a
vertex-minimal non-Hamiltonian Barnette graph has no induced \(T\).
If all other vacancies of the selected opening occupy distinct
internal blocks, the parent has a Hamilton cycle through both site
edges and its legal site-expanded child is Hamiltonian.

**Proof of the two orientations.** For an opposite-side chord,
if the free slots strictly between its ends have even cardinality,
an odd number of those slots cannot already be matched across the
interval boundary on the face side: the remaining slots would have
odd cardinality but would have to match among themselves. Full
short blocks contribute two free slots, and a full double block
contributes six. We use this count without assuming how the short
flanks are matched.

First let \(ok,IE\) be the two internal chords. The even slot
\(h\) cannot meet an ordinary odd short-block slot or the ordinary
right endport. For a candidate before \(D\), the interval contains
the candidate block's final even slot and \(o\); for a candidate
in or after the intervening corridor, it contains the four-slot
tail \(i,k,j,e\), followed by whole blocks. In every case the
free-slot count is even and \(ok\) is the sole face-side chord
with exactly one end inside. The \(J_3\) chord \(IE\), when present
in the interval, has both ends inside. The same obstruction rules
out \(hO\): its interval contains \(i,k,j,e\), the short corridor,
and one endpoint of \(ok\). Within \(D\), \(hi\) is an old-cycle
edge, \(hj\) is excluded by chord isolation, and the other odd
slot \(o\) is already used. The slot \(I\) of \(D'\) is used by
\(IE\). Thus the only possible mate of \(h\) is \(J\), and
\(hJ\) is forced.

Every unmatched free slot strictly between \(h\) and \(J\) must
now meet another slot there: an opposite-side edge leaving this
interval would cross \(hJ\), cross-block face-side edges are
unavailable, and neither double block has another internal free
chord. The only free slots of \(D\cup D'\) outside that interval
are \(o\) and \(E\), already matched to \(k\) and \(I\)
respectively. Face-closing chords of all intervening short blocks
also stay inside. Therefore the complete block interval from
\(D\) through \(D'\) is closed under the complementary matching.
Only its two boundary old-cycle edges leave it, a forbidden
two-edge cut. This excludes the \(J_1,J_3\) order.

Now let \(ie,OK\) be the internal chords. The even slot \(H\)
of \(D'\) cannot meet an ordinary odd slot: a candidate to its
left gives an even interior with \(OK\) as the sole face-side
exit, and a candidate to its right encloses the four-slot tail
\(I,K,J,E\) with the same single exit. The odd slot \(o\) of
\(D\) gives an even interior containing all of \(ie\) but only
\(O\) of \(OK\); \(I\) is the old-cycle neighbour of \(H\),
\(J\) is excluded by chord isolation, and \(O\) is used. The
only remaining mate is \(j\). Here the interval from \(j\) to
\(H\) contains \(e\) and \(O\); each belongs to a face-side
chord leaving that interval, so the parity obstruction does not
apply. Hence \(jH\) is forced.

Suppose a nonempty short corridor lay between the two blocks.
Its free slots lie strictly between \(j\) and \(H\). They cannot
meet slots outside that chord on the opposite side; they have no
usable same-block free chord and no cross-block chord on the face
side. Thus all corridor free slots match within the corridor.
Its face-closing chords also stay there, so the entire nonempty
consecutive corridor is matching-closed and has a two-edge cut,
a contradiction. The blocks are adjacent.

Finally consider the even slot \(k\) of \(D\). An ordinary odd
slot before, between or after the double blocks, or the right
endport, gives an even interior with \(ie\) as the sole face-side
exit. Among the odd slots of \(D'\), \(O\) is used, \(kJ\) has
that same one-exit obstruction, and \(kI\) has two face-side
exits, one from \(ie\) and one from \(OK\). Within \(D\),
\(ko\) is excluded, \(kj\) is an old-cycle edge, and \(i\)
is used. Therefore \(kI\) is forced, proving (2).

For the no-flank assertion, let \(L,R\) be the ordinary left and
right endports. After (2), the only unmatched free slots have the
order \(L,o,h,J,E,R\). The slot \(L\) has even colour, so its
possible mates are \(o,J,R\). If \(LJ\) occurred, the two enclosed
unmatched slots \(o,h\) would have to use their forbidden old-cycle
edge. If \(LR\) occurred, noncrossing would force the remaining
slots to pair as \(oE,hJ\), since \(oh,JE\) are old-cycle edges;
then the complete two-block interval would have a two-edge cut.
Thus \(Lo\) is forced. The remaining matching is \(hJ,ER\):
\(hR\) would trap the forbidden pair \(JE\). This proves the
no-flank assertion.

**Proof of the square signature.** Assume also \(hJ\). The
remaining free slots \(o,E\) cannot match each other: that would
close the whole two-block interval under the matching and make a
two-edge cut. Thus each has one exterior matching edge. Together
with the old-cycle edges at \(a,B\), these are exactly four
attachments. The one-path routings are
\[
\begin{array}{c|l}
aB&\text{the full old-cycle path through }T\\
ao&a,b,A,B,E,J,K,O,H,I,k,j,e,i,h,o\\
oE&o,a,b,e,j,H,I,k,i,h,J,K,O,A,B,E\\
EB&E,J,K,O,H,I,k,j,e,i,h,o,a,b,A,B.
\end{array}                                                \tag{4}
\]
Each row uses every vertex once and each successive pair is an
old-cycle edge or one of (2)--(3), including \(hJ\). The terminal
colours permit exactly these four endpoint pairs. The two
noninterlacing two-path pairings are realized by
\[
\begin{array}{c|l}
\{ao,EB\}&(a,o),\quad(E,J,h,i,k,I,K,O,H,j,e,b,A,B)\\
\{aB,oE\}&(a,b,A,B),\quad(o,h,i,e,j,k,I,H,O,K,J,E).
\end{array}                                                \tag{5}
\]
The third pairing interlaces the terminals in the disk and is
impossible. Equations (4)--(5) are precisely the square's
complete signature. Any global Hamilton cycle meets the four-edge
attachment cut in two or four edges; replacing the corresponding
spanning route preserves the exterior edges and their marks in
both directions.

**Realization and Barnette preservation.** Give an old Hamilton
cycle the order
\[
x,R_1,w,y,D,D',u,o_3,L_1,v,\alpha,\gamma,\delta,\beta,x.
                                                               \tag{6}
\]
Add the face-side matching chords
\[
xy,ab,ie,AB,OK,uv,\alpha\beta                          \tag{7}
\]
and the opposite-side chords
\[
\delta R_1,\ w o,\ hJ,\ kI,\ jH,\ Eo_3,\ \gamma L_1.
                                                               \tag{8}
\]
They pair every vertex exactly once, join opposite old-cycle
colours, and do not repeat old-cycle edges. Chords on either
side are nested or disjoint, so this is a simple plane cubic
bipartite graph with cofacial site edges \(xy,uv\). Its
matching-chord interlacement graph is connected: a spanning
set of endpoint alternations is
\[
xy-wo-ab-hJ-AB-Eo_3-uv-\gamma L_1-\alpha\beta-\delta R_1,
\quad ab-kI-ie-jH,\quad kI-OK.                         \tag{9}
\]
Every dash is verified directly in the cyclic order (6).
A two-edge cut in a cubic Hamiltonian graph would bound a
proper old-cycle interval closed under the matching and
disconnect this interlacement graph. There is no bridge
because of the old Hamilton cycle. Hence this graph is
three-edge-connected and, in the cubic case, three-vertex-
connected. It realizes \(T\). A Hamilton cycle through both
site edges is obtained by joining the two \(x\)--\(v\) paths
\[
x,R_1,\delta,\beta,\alpha,\gamma,L_1,v
\quad\text{and}\quad
x,y,w,(\text{the }oE\text{ route of (4)}),o_3,u,v.        \tag{10}
\]

For class preservation, the paths
\((a,b,A,B)\) and
\((o,h,i,e,j,k,I,H,O,K,J,E)\) in (5) are disjoint and
spanning. Contract their interiors to the edges \(a'B'\)
and \(o'E'\), retaining the old edges \(ao,EB\) and all four
attachments. After deleting surplus edges, the square is a
planar minor. Conversely, (1)--(3) have a two-page disk
drawing with terminals \(a,o,E,B\) in that boundary order,
so the patch inserts into the empty side of a square with
connected exterior.

Deleting any one vertex leaves \(T\) connected: each of its
two block cycles remains connected, and the four joins
\(bA,hJ,kI,jH\) have pairwise distinct endpoints. After
deleting two patch vertices, every surviving component of
\(T\) contains a surviving terminal; otherwise the same
component would disconnect the three-connected realization
(6)--(8) from its nonempty exterior. In any three-connected
host the exterior of either four-pole is connected, since two
exterior components would each require at least three of the
four attachment edges. The four-attachment deletion comparison
of [Note 330](330-staggered-vacancy-chains-have-the-square-hamilton-signature.md)
now proves three-connectivity in both replacement directions.
Terminal colours, cubicity, simplicity and planarity also agree.

Compressing \(T\) in the selected opening replaces its two
consecutive target-free blocks by a short target-free square.
The two exterior matching edges at \(o,E\) retain their cyclic
order, and no site edge, escape target or interblock gap changes.
When all other vacancies occupy distinct internal blocks,
Note 324 gives a Hamilton parent cycle through both site edges
after compression. Lift that cycle through (4)--(5); then
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives a Hamilton cycle in the legal site-expanded child.
\(\square\)

**A real one-flank interaction.** Let
\(S_-=(c_-,o_-,e_-,d_-)\) be a short block. Give an old
Hamilton cycle the order
\[
x,R_1,w,y,S_-,D,D',u,o_3,L_1,v,
\alpha,\gamma,\delta,\beta,x,                         \tag{11}
\]
where \(D,D'\) carry \(J_3,J_1\) as above. Its
complementary matching has face-side chords
\[
xy,\ c_-d_-,\ ab,\ ie,\ AB,\ OK,\ uv,
\alpha\beta                                              \tag{12}
\]
and opposite-side chords
\[
\delta R_1,\ wJ,\ o_-h,\ e_-o,\ kI,\ jH,
\ Eo_3,\ \gamma L_1.                                 \tag{13}
\]
These lists match each vertex once, respect old-cycle
parities, use no old-cycle edge, and are noncrossing on each
side. The matching-chord interlacement graph has the connected
spanning system
\[
\begin{gathered}
xy-wJ-AB-Eo_3-uv-\gamma L_1-
\alpha\beta-\delta R_1,\\
AB-kI-ie-jH,\qquad kI-OK,\\
kI-ab-o_-h-c_-d_--e_-o.
\end{gathered}                                             \tag{14}
\]
All displayed alternations follow from (11). As above,
connected interlacement excludes a two-edge cut, so the
simple cubic bipartite plane graph is three-connected. It
has the same one-square, tight-target, gapless opening as
the realizations in Notes 332--333, with exactly these two
doubly vacant blocks and just one short flank. In particular,
\(hJ\) is absent in a genuine Barnette instance. This
example only separates the forced-core theorem from the
conditional square reduction. It even has a Hamilton cycle
through both site edges, obtained by joining
\[
\begin{split}
&x,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,w,J,K,O,H,I,k,j,e,i,h,o_-,c_-,d_-,e_-,
o,a,b,A,B,E,o_3,u,v.
\end{split}                                                \tag{15}
\]

**All one-flank matchings.** Let \(S=(c,s,t,d)\) be the only
short block of the group, immediately before \(D,D'\), and let
\(L,R\) be the ordinary even and odd endports. Once \(jH,kI\)
are fixed, the remaining free slots occur in the order
\(L,s,t,o,h,J,E,R\). The internal edges \(st,oh,JE\) are
old-cycle edges and cannot belong to the complementary matching.
Noncrossing and the absence of a two-edge cut leave exactly
\[
\begin{array}{c|l}
\text{I}&Ls,\ to,\ hJ,\ ER,\\
\text{II}&LJ,\ sh,\ to,\ ER.
\end{array}                                                \tag{16}
\]
Indeed, \(Lo\) traps the forbidden pair \(st\). If \(LJ\)
occurs, its four inner free slots can only pair as \(sh,to\),
and \(ER\) follows. If \(LR\) occurs, its inner matching
must be \(sE,to,hJ\), closing the entire three-block
interval and making a two-edge cut. Finally, if \(Ls\)
occurs, the mate of \(t\) cannot be \(J\), which would trap
\(oh\); nor can it be \(R\), which would force \(oE,hJ\)
and close the two-double-block interval. Thus \(to,hJ,ER\)
are forced. This proves (16).

In state I the square-equivalent patch \(T\) is present.
The path from \(L\) through \(s,c,d,t\), followed by the
\(oE\) spanning path in (4) and the edge \(ER\), spans
the group from \(L\) to \(R\). In state II the route is
\[
L,J,K,O,H,I,k,j,e,i,h,s,c,d,t,o,a,b,A,B,E,R.          \tag{17}
\]
Every successive pair in (17) is an old-cycle, face-side,
or displayed matching edge; the route visits every block
vertex once. Old-cycle reflection proves the right-flank
case. These routes replace the standard free-path segment
with the same two endports while leaving the target-and-
square path untouched. If other vacancies lie in distinct
internal blocks, the groupwise composition of Note 324
gives the stated marked Hamilton parent circle; Note 001
gives the legal child's Hamilton circle.

**Arbitrary one-sided short flanks.** Let
\(S_t=(c_t,o_t,e_t,d_t)\), \(1\le t\le p\), be all the
short blocks before \(D,D'\), with no short block after them.
Write \(L,R\) for the ordinary even and odd endports. For
\(p=0\), the no-flank argument forces \(hJ\) and the square
reduction. For \(p\ge1\), if \(hJ\) occurs, compress \(T\)
to a short square. The resulting all-short group has its
ordinary links by the skipping and two-edge-cut argument of
Note 275. Its \(L\)--\(R\) spanning path lifts through \(T\).

Suppose \(hJ\) is absent. Put \(e_0=L\). Then exactly one
index \(\mu\in\{0,\ldots,p-1\}\) occurs, and the remaining
complementary matching is
\[
\begin{split}
&e_{t-1}o_t\quad(1\le t\le\mu),\qquad e_\mu J,
\qquad o_{\mu+1}h,\\
&e_to_{t+1}\quad(\mu+1\le t<p),\qquad e_po,
\qquad ER.
\end{split}                                                \tag{18}
\]
The first range is empty at \(\mu=0\), when \(e_0J=LJ\).

First \(R\) must meet \(E\). If it met \(L\), all complete
blocks of the group would be matching-closed. If it met any
short-block even slot \(e_t\), the opposite-side chord
\(e_tR\) would trap the complete suffix
\(S_{t+1},\ldots,S_p,D,D'\); all its free matching and
face-side chords would stay in that suffix, giving a
forbidden two-edge cut. The only other even free slot is
\(h\), but \(hR\) traps \(J,E\), whose mutual edge lies
on the old cycle. Thus \(ER\) is forced.

The odd slot \(J\) must now meet \(h,L\), or one of
\(e_1,\ldots,e_p\); all other candidates are used or
have the wrong colour. Since \(hJ\) is absent, call its
mate \(e_\mu\), using \(e_0=L\). The case \(\mu=p\)
would trap just \(o,h\), whose mutual edge is on the old
cycle. Thus \(\mu<p\). A free slot before \(e_\mu\)
cannot match one after it: a mate before \(J\) would
cross \(e_\mu J\), while \(E,R\) are already used.
The prefix therefore matches within itself. When \(\mu>0\),
its first link must be \(Lo_1\), since a later mate \(Lo_t\)
would close the intervening complete short blocks.
Inductively, the prefix links are
\(e_{t-1}o_t\), \(1\le t\le\mu\).

Inside \(e_\mu J\), the first odd short slot
\(o_{\mu+1}\) cannot use its old-cycle neighbour
\(e_{\mu+1}\). If it met a later \(e_t\), the entire
short-block interval \(S_{\mu+1},\ldots,S_t\) would
be matching-closed: all its other free slots lie inside
that chord and cannot match across it. Thus
\(o_{\mu+1}h\) is forced. Between these two ends,
\(e_{\mu+1}\) cannot skip a short block: a mate
\(o_t\) with \(t>\mu+2\) closes the skipped blocks,
and a mate \(o\) with \(p>\mu+1\) closes all later
short blocks. Hence it meets \(o_{\mu+2}\), or \(o\)
when \(\mu+1=p\). Repetition gives the suffix links
in (18).

For every \(\mu\), the single path
\[
L,\ (o_t,c_t,d_t,e_t)_{t=1}^{\mu},\
J,K,O,H,I,k,j,e,i,h,\
(o_t,c_t,d_t,e_t)_{t=\mu+1}^{p},\
o,a,b,A,B,E,R                                             \tag{19}
\]
visits the two endports and every block vertex exactly
once. Consecutive short-block tuples join by the links
in (18); \(e_\mu J,o_{\mu+1}h,e_po,ER\) give the
other joins. Within each tuple the route uses an old
edge, its face chord, then another old edge. The middle
uses the forced \(jH,kI\) chords and the original block
edges. Empty tuples at \(\mu=0\) are omitted. This is
the required \(L\)--\(R\) spanning route. Reflecting
the old-cycle order proves the right-only flank case.
Its endports agree with the standard free-path segment,
so Note 324's groupwise composition gives the marked
parent and legal-child conclusion when other vacancies
occupy distinct internal blocks.

Every parameter \(p\ge1\), \(0\le\mu<p\) in (18) occurs.
Use the old Hamilton order
\[
x,R_1,w,y,S_1,\ldots,S_p,D,D',u,o_3,L_1,v,
\alpha,\gamma,\delta,\beta,x,
\]
take face-side matching chords
\(xy,c_td_t\ (1\le t\le p),ab,ie,AB,OK,uv,\alpha\beta\),
and take the opposite-side matching of (18) with
\(L=w,R=o_3\), together with \(kI,jH,\delta R_1,\gamma L_1\).
These chords match every vertex once, join opposite old-cycle
colours, and are nested or disjoint on each side. Their
interlacement graph is connected: \(xy\) meets the first
prefix link, or \(wJ\) when \(\mu=0\); every short face
chord meets a neighbouring prefix or suffix link, with
\(c_\mu d_\mu\) meeting \(e_\mu J\) when \(\mu>0\) and
\(c_{\mu+1}d_{\mu+1}\) meeting \(o_{\mu+1}h\).
The chords \(e_\mu J,o_{\mu+1}h,e_po\) meet \(AB\),
\(ab\), and \(ab\), respectively. The core connections
\(AB-kI-ie-jH\) and \(kI-OK\), plus
\(AB-Eo_3-uv-\gamma L_1-\alpha\beta-\delta R_1\),
join all remaining chords. Thus no two-edge cut exists,
and the cubic plane bipartite graph is three-connected.
It has \(28+4p\) vertices. Joining (19), with
\(L=w,R=o_3\), to the exterior paths as in (15)
gives a Hamilton cycle through both site edges.

The six-terminal core with \(hJ\) absent is not equivalent to a
single singly vacant six-cycle with terminal order
\((a,o,h,J,E,B)\). It has the spanning three-path routing
\[
(a,b,A,O,H,j,e,i,k,I,K,J),\qquad(o,h),\qquad(E,B),      \tag{20}
\]
whose terminal pairing is \(\{aJ,oh,EB\}\). In a six-cycle
on these six terminals, a spanning three-path routing must
consist of three cycle edges, whereas \(aJ\) is not a cycle
edge. Thus the real flank case cannot be eliminated by that
simple six-cycle substitution. The signatures also differ in
the opposite direction. The six-cycle has the spanning
two-path pairing \(\{ah,JB\}\), by the paths
\((a,o,h)\) and \((J,E,B)\). In the six-terminal core, if
\(a,h,J,B\) are the four endpoints, the nonendpoint \(o\)
must use both \(ao,oh\), making \((a,o,h)\) a whole path.
The nonendpoint \(E\) must use both \(JE,EB\), making
\((J,E,B)\) another whole path. Ten internal vertices
would then be left uncovered. Therefore this pairing is
absent from the core. Neither six-terminal signature
contains the other.

The mixed-pair theorem concerns exactly two multiply vacant blocks
in an ordinary target-free group. [Note 336](336-every-two-double-mixed-j1-j3-free-group-has-a-spanning-route.md)
supplies a spanning endport route when the surviving slots \(h,J\)
do not match each other and short flanks occur on both sides.
The full case of three consecutive \(J_1/J_3\) double blocks
with arbitrary short flanks is handled separately in
[Note 337](337-every-consecutive-j1-j3-three-double-group-reduces-to-a-square.md).
Other groups with a third multiply vacant block, groups with a
singly vacant block, and the general Barnette conjecture remain
outside these results.
The argument is project-internal; no external priority or independent
review is claimed.
