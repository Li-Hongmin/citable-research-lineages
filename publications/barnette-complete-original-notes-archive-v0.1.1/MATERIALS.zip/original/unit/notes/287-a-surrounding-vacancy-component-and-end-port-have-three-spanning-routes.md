> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A surrounding vacancy component and end port have three spanning routes

Note 277 gives a marked Hamilton route when one vacancy
square surrounds a single port–vacancy pair whose port starts
at the square's first vacant block. Both alternating components
may be arbitrarily long and their shared block span has all
three spanning four-port states. The port component supplies
the two covering paths required in Note 275's straight route;
its other right continuation gives the cap and crossed states.

Use the compressed, gapless, tight-target all-square opening
of Notes 196 and 278. All vacancies lie in distinct target-free
internal face-chord blocks. Fix one free group with exactly one
missing ordinary link \(P_s=e_so_{s+1}\). In its noncrossing
atom partition, let a vacancy-only component have atoms
\[
 V_s=V_{j_1}<V_{j_2}=V_t<\cdots<V_{j_h}=V_w,
 \qquad h\ge2.                                      \tag{1}
\]
The port component starts immediately after the first atom
of (1) and has atoms
\[
 P_s<V_{k_1}<\cdots<V_{k_m}=V_u,
 \qquad m\ge1,\quad s+2\le k_1,\quad u<t.          \tag{2}
\]
Every other component is vacancy-only, and the group's
ordinary end links are retained.

**Surrounding-component theorem.** The span
\(Q=B_s,\ldots,B_w\) has all three vertex-spanning states
\[
\begin{array}{ll}
S(Q):&o_s\longleftrightarrow e_w,\\
K(Q):&a_s\longleftrightarrow o_s,\quad
       e_w\longleftrightarrow b_w;\\
X(Q):&a_s\longleftrightarrow b_w,\quad
       o_s\longleftrightarrow e_w.
\end{array}                                             \tag{2a}
\]
The full free group has the same three states after
vacancy-only surrounding components and serial flanks are
composed. If every other free group has an ordinary-endport
spanning path, the parent has a Hamilton cycle containing
both site edges and its legal expanded child is Hamiltonian.
There is no bound on \(h,m\), on the distances between their
atoms, or on the number and nesting depth of other
vacancy-only components. Reflection gives the corresponding
port after the last atom of the surrounding component.

**Proof.** The port matching edges are
\[
 e_sI_u,\quad o_{s+1}H_{k_1},\quad
 I_{k_a}H_{k_{a+1}}\ (1\le a<m),                    \tag{3}
\]
and the surrounding matching edges are
\[
 H_sI_w,\quad I_{j_a}H_{j_{a+1}}\ (1\le a<h).
                                                            \tag{4}
\]
Noncrossing closes the gap
\(G=B_{s+1},\ldots,B_{k_1-1}\), the suffix
\(J=B_{u+1},\ldots,B_{t-1}\), and all proper gaps
after \(V_t\) under the matching. The first gap \(G\)
is nonempty by old-cycle adjacency. Each nonempty such
gap has \(S,K,X\) by Note 275; \(J\) may be empty.
All ordinary links other than \(P_s\) are retained.

Construct a left path \(L:a_{s+1}\longleftrightarrow e_s\).
First traverse both \(X(G)\) rails, then follow the old
cycle from the first port vacancy to the last:
\[
\begin{split}
a_{s+1}&\xrightarrow{X_{\rm top}(G)}b_{k_1-1},
 a_{k_1},o_{k_1},e_{k_1-1}\\
&\xrightarrow{X_{\rm bottom}(G)^{-1}}o_{s+1},
 H_{k_1}\xrightarrow{C\text{ forward}}I_u,e_s.
\end{split}                                             \tag{5}
\]
The joins \(o_{s+1}H_{k_1}\) and \(I_ue_s\) are (3),
while \(o_{k_1}e_{k_1-1}\) is a retained link.
The \(C\)-arc in (5) includes every intermediate port
vacancy and every intervening block, independently of
their matching. Hence \(L\) covers every vertex of
\(B_{s+1},\ldots,B_u\) except \(e_u,b_u\).

Construct a right path
\(R:e_{t-1}\longleftrightarrow b_{t-1}\) covering exactly
\(e_u,b_u\) and all blocks of \(J\). If \(t=u+1\),
take \(R=e_ub_u\). Otherwise set
\[
 e_{t-1}\xrightarrow{X_{\rm bottom}(J)^{-1}}o_{u+1},
 e_u,b_u,a_{u+1}
 \xrightarrow{X_{\rm top}(J)}b_{t-1}.              \tag{6}
\]
The two joins at \(B_u\) are the retained ordinary
link \(e_uo_{u+1}\) and the old-cycle edge \(b_ua_{u+1}\).
Thus \(L,R\) are disjoint and cover the entire first
surrounding-component gap \(B_{s+1},\ldots,B_{t-1}\).

The rainbow edges (4) give an alternating detour from
\(e_s\) to \(o_t\):
\[
 \Omega:\quad e_s,I_s,H_s,
 (I_{j_a},H_{j_a})_{a=h,h-1,\ldots,2},o_t.
                                                            \tag{7}
\]
Each pair \(I_{j_a}H_{j_a}\) is an old-cycle edge; the
joins between consecutive pairs, including
\(H_sI_w\), are exactly (4). Starting at \(o_s\),
take
\[
 o_s,a_s,b_s,a_{s+1}
 \xrightarrow{L}e_s
 \xrightarrow{\Omega}o_t,e_{t-1}
 \xrightarrow{R}b_{t-1},a_t.                        \tag{8}
\]
The link \(o_te_{t-1}\) is retained. From \(a_t\)
follow Note 275's ordinary straight route through
\(B_t,\ldots,B_w\): use each face chord \(a_{j_a}b_{j_a}\),
each later closed gap's \(S\) route, and retained
ordinary links, ending at \(e_w\). This last route omits
all vacancy slots of (1), already visited by \(\Omega\).
Equation (8) visits the other four vertices of \(B_s\);
\(L,R\) cover the first gap once; and the final ordinary
route visits every remaining block vertex once. Therefore
it is \(S(Q)\).

For the other states, use the right continuation
\(T:b_s\longleftrightarrow b_u\) of Note 286(6)--(8).
It covers \(B_{s+1},\ldots,B_u\) except \(I_u,e_u\).
Its construction uses the two \(X(G)\) rails when \(m=1\).
For \(m\ge2\), it follows \(C\) to the penultimate port
vacancy, jumps to \(H_u\), and folds the final gap on
its two \(X\) rails. None of its edges uses \(B_s\).

For \(K(Q)\), keep the right cap \(e_wb_w\). The left
path begins \(a_s,b_s\), follows \(T\) to \(b_u\), and
then crosses the suffix \(J\) on its top rail and
returns on its bottom rail:
\[
\begin{split}
a_s,b_s\xrightarrow{T}b_u,a_{u+1}
 &\xrightarrow{X_{\rm top}(J)}b_{t-1},a_t,o_t,
 e_{t-1}\\
 &\xrightarrow{X_{\rm bottom}(J)^{-1}}o_{u+1},
 e_u,I_u,e_s,I_s,H_t\\
 &\xrightarrow{C\text{ forward}}I_w,H_s,o_s .
\end{split}                                             \tag{8a}
\]
When \(J\) is empty, replace its two rail traversals
by \(b_u,a_t,o_t,e_u\). The joins \(I_ue_s\),
\(I_sH_t\), and \(I_wH_s\) are in (3)--(4);
\(o_te_{t-1}\) and \(o_{u+1}e_u\) are retained links.
The old-cycle arc from \(H_t\) to \(I_w\) covers
every later block, stopping before \(e_w,b_w\).
Thus (8a) and the right cap are disjoint and span \(Q\).

For \(X(Q)\), take the top and bottom paths
\[
\begin{split}
&a_s,b_s\xrightarrow{T}b_u
  \xrightarrow{X_{\rm top}(B_{u+1},\ldots,B_w)}b_w,\\
&o_s,H_s,I_s,e_s,I_u,e_u
  \xrightarrow{X_{\rm bottom}(B_{u+1},\ldots,B_w)}e_w .
\end{split}                                             \tag{8b}
\]
The joins into the suffix are the old-cycle edge
\(b_ua_{u+1}\) and retained link \(e_uo_{u+1}\).
These \(X\) rails use only face chords, old-cycle
edges, and ordinary links; they need no matching
closure of the suffix. The first path covers \(B_s\)'s
\(a_s,b_s\), all of the port region except \(I_u,e_u\),
and the suffix top rail. The second covers the other
four vertices of \(B_s\), \(I_u,e_u\), and the suffix
bottom rail. They are disjoint and span \(Q\).

Note 275's vacancy-only prime recursion now accepts
\(Q\) in any proper surrounding block gap; serial
parts join across retained ordinary links. Note 273's
group splice and Notes 001 and 178 give the marked
cycle, legal child, and original lobe lengths.
\(\square\)

For every \(m\ge1,h\ge2\) this configuration has a
Barnette realization. Use Note 281(8)'s site blocks and
residual square with
\[
 u=m+2,\qquad t=m+3,\qquad r=m+h+1.
\]
Make \(B_1\) and \(B_3,\ldots,B_r\) vacant and \(B_2\)
short. Retain all standard free links except
\(P_1=e_1o_2\), and add
\[
 H_1I_r,\quad I_1H_t,\quad
 I_jH_{j+1}\ (t\le j<r),\quad
 e_1I_u,\quad o_2H_3,\quad
 I_jH_{j+1}\ (3\le j<u).                            \tag{9}
\]
The first three terms form the surrounding component
\(V_1,V_t,\ldots,V_r\); the other terms form
\(P_1,V_3,\ldots,V_u\). This is a perfect matching
of the free slots. Its edges join opposite old-cycle
colours and draw as nested or disjoint chords in the
opposite-side disk: \(H_1I_r\) encloses \(I_1H_t\),
which encloses \(e_1I_u\) and its inner port chords.
The remaining outer chords lie to the right of \(I_1H_t\).
The site edges remain cofacial.

The matching-chord interlacement graph is connected.
Retained standard links connect the face chords of
\(B_2,\ldots,B_r\); \(e_1I_u\) interlaces those
of \(B_1,B_u\), attaching the first face chord.
Every remaining edge of (9) interlaces an endpoint face
chord. The remaining site and residual-square chords
attach through retained \(e_0o_1,e_ro_{r+1}\) and their
closing chain. Note 217's cut argument and Note 182's cubic
lemma give three-vertex-connectivity. The parent has
\(6(m+h)+16\) vertices and the legal Hamiltonian child
\(6(m+h)+20\). At \(m=1,h=2\), (9) is Note 277's
34-vertex nested example.

The theorem treats a port immediately after the first
vacancy atom of its surrounding component. Note 288
handles the other positions and combines the cases.
