> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An unbounded outer-pair alternating chain has the square signature

[Note 347](347-a-nested-four-double-swap-has-the-square-hamilton-signature.md)
gives a four-double square-equivalent swap.
[Note 362](362-the-six-double-outer-pair-has-the-square-hamilton-signature.md)
extends one outer-pair branch to six double blocks.
The same outer pair supports an explicit square-equivalent
chain at every even length, with a two-block middle route
as its repeating unit. This family differs from
[Note 345](345-an-unbounded-alternating-double-block-chain-has-a-marked-hamilton-route.md):
its second long chord is \(k_1i_N\), whereas Note 345
uses \(k_1i_2\) for \(N>2\).

Let \(m\ge2\), \(N=2m\), and place \(N\) consecutive
eight-vertex blocks on an old Hamilton cycle,
\[
 D_s=(a_s,o_s,h_s,i_s,k_s,j_s,e_s,b_s),
                         \qquad 1\le s\le N.             \tag{1}
\]
The common-face matching chords are the block closings
\(a_sb_s\), the \(J_3\) chords \(i_se_s\) for odd \(s\),
and the \(J_1\) chords \(o_sk_s\) for even \(s\).
In the ordinary free group, with endports \(L,R\), prescribe
the opposite-page matching
\[
\begin{split}
&Lo_1,\quad h_1j_N,\quad k_1i_N,\quad e_NR,\\
&j_sh_{s+1}\quad(1\le s<N),\\
&i_{2t}k_{2t+1},\quad e_{2t}o_{2t+1}
                       \quad(1\le t<m).
\end{split}                                                \tag{2}
\]

**Unbounded outer-pair theorem.** For every \(m\ge2\),
(1)--(2) occur in an \(8N+12\)-vertex three-connected
cubic bipartite plane parent with a compressed, gapless,
tight-target all-square opening and a Hamilton cycle through
both site edges. The legal site-expanded child is Hamiltonian.
The induced \(8N\)-vertex four-terminal patch with terminals
\((a_1,o_1,e_N,b_N)\) has exactly the square's Hamilton
single-path and two-path signature. Replacing this patch by
the square, or inserting it in place of a square, preserves
Barnette membership and all exterior and attachment-edge
Hamilton decisions. Consequently a vertex-minimal
non-Hamiltonian Barnette graph contains no induced disk
copy of this patch.

**Outer-pair transfer lemma.** More generally, keep the
alternating blocks (1) and their prescribed common-face
chords, but allow any actual opposite-page matching
containing \(h_1j_N,k_1i_N,j_1h_2\) and the ordinary
endport edges. Suppose \(h_N\) is matched to a slot
\(s\) of the middle blocks and those blocks have a
spanning \(h_2\)--\(s\) path \(M\) using the present
edges. Then the entire induced \(8N\)-vertex patch
has the exact square Hamilton signature and can be
replaced by a square in either direction while
preserving Barnette membership and every exterior
Hamilton decision. The proof below uses only these
hypotheses in its signature formulas and deletion
comparison. For the explicit family (2),
\(s=j_{N-1}\) and (4) constructs \(M\).

**Matching and middle route.** Each free slot of (1)
appears exactly once in (2). The opposite-page chords
are nested or disjoint: \(h_1j_N\) surrounds \(k_1i_N\);
for each even-to-odd transition,
\[
 i_{2t}k_{2t+1}\ \supset\
 j_{2t}h_{2t+1}\ \supset\
 e_{2t}o_{2t+1},                                           \tag{3}
\]
and the odd-to-even \(j_{2t+1}h_{2t+2}\) chords lie
between those nested intervals. Each prescribed chord
joins opposite old-cycle colours and is not an old edge.

For \(1\le t<m\), define the 16-vertex route
\[
\begin{split}
 C_t={}&(h_{2t},o_{2t},a_{2t},b_{2t},e_{2t},
 o_{2t+1},a_{2t+1},b_{2t+1},e_{2t+1},\\
 &i_{2t+1},h_{2t+1},j_{2t},k_{2t},i_{2t},
 k_{2t+1},j_{2t+1}).
\end{split}                                                \tag{4}
\]
Its non-old joins are the two block closings,
\(e_{2t}o_{2t+1}\), \(i_{2t+1}e_{2t+1}\),
\(j_{2t}h_{2t+1}\), and \(i_{2t}k_{2t+1}\).
It visits both blocks once, from \(h_{2t}\) to
\(j_{2t+1}\). Concatenate \(C_1,\ldots,C_{m-1}\)
using \(j_{2t+1}h_{2t+2}\), and call the resulting
spanning \(h_2\)--\(j_{N-1}\) path through
\(D_2,\ldots,D_{N-1}\) by \(M\). The two end joins
\(j_1h_2,j_{N-1}h_N\) are also in (2).
Thus the group has the spanning route
\[
 P=(o_1,a_1,b_1,e_1,i_1,h_1,j_N,k_N,i_N,k_1,j_1,
        M,h_N,o_N,a_N,b_N,e_N).                           \tag{5}
\]
All 8 vertices of each outer block and all middle
vertices appear once; every consecutive pair is an
old edge or a chord in (1)--(2).

**Exact four-terminal signature.** Let \(O\) be the
full old-cycle path through \(D_2,\ldots,D_{N-1}\),
from \(a_2\) to \(b_{N-1}\). The full old-cycle
path through (1) spans \(a_1b_N\); (5) spans
\(o_1e_N\). The path
\[
 E=(e_N,j_N,k_N,o_N,h_N,i_N,k_1,j_1,e_1,i_1,
       h_1,o_1,a_1,b_1,O,a_N,b_N)                        \tag{6}
\]
spans \(e_Nb_N\). Its only non-old joins are
\(k_No_N,k_1i_N,e_1i_1,a_1b_1,a_Nb_N\).
The old-cycle reflection of Note 346 (4) for even
\(N\), followed by reversal, gives an \(a_1o_1\)
path: it fixes \(k_1i_N\), the sole opposite-page
chord in (6).

The two permitted spanning two-path pairings are
\[
\begin{split}
\{a_1b_N,o_1e_N\}:\
 &(a_1,b_1,e_1,j_1,M,h_N,o_N,a_N,b_N),\\
 &(o_1,h_1,i_1,k_1,i_N,k_N,j_N,e_N);                    \tag{7}\\[2pt]
\{a_1o_1,e_Nb_N\}:\
 &(a_1,b_1,e_1,j_1,M,h_N,i_N,k_1,i_1,h_1,o_1),\\
 &(e_N,j_N,k_N,o_N,a_N,b_N).                             \tag{8}
\end{split}
\]
In each row the two paths are disjoint and cover all
\(8N\) vertices. The only new joins not already
explained by (4)--(6) are \(h_Ni_N\), an old edge,
and \(k_No_N\), the final \(J_1\) chord. The
formulas (5)--(8) require only the middle path,
the two outer chords and the joins at its ends, so
they prove its exact-signature assertion as well.
The single-path pairs \(a_1e_N,o_1b_N\) join equal
old-cycle colours and are impossible because a
spanning path has odd length. The remaining two-path
pairing \(\{a_1e_N,o_1b_N\}\) crosses the cyclic
terminal order and is impossible in the disk.
Thus (5)--(8) give precisely the square's complete
four-terminal Hamilton signature.

**Barnette realization.** Use the old Hamilton order
\[
 x,R_1,w,y,D_1,\ldots,D_N,u,z,L_1,v,
             \alpha,\gamma,\delta,\beta,x.               \tag{9}
\]
Give it common-face matching chords
\(xy,uv,\alpha\beta\), all \(a_sb_s\), and the
alternating internal chords of (1). Give it
opposite-face chords
\[
 \delta R_1,\quad wo_1,\quad e_Nz,\quad\gamma L_1,
 \quad\text{and all the internal-group edges of (2)
 except }Lo_1,e_NR,                                     \tag{10}
\]
with \(L=w,R=z\). Equivalently (10) includes
\(wo_1,e_Nz\) as the two endport edges.
The noncrossing description (3) and the separate
outer intervals show planarity. Every vertex is
matched once, each chord joins opposite colours,
and no chord is an old edge; hence the graph is
simple, cubic and bipartite. The same common-face
embedding as in Note 345 makes \(xy,uv\) a legal
facial \(C_4\)-expansion site: the \(y\)--\(u\)
face arc has length \(2N+1\) through the \(a_sb_s\)
chords, the \(v\)--\(x\) arc has length three through
\(\alpha\beta\), and \(x,u\) have the same colour.
The residual cycle
\(\alpha\gamma\delta\beta\alpha\) is a square
with tight escape targets \(R_1,L_1\);
there is no interblock gap. This is the stated
tight, gapless all-square opening.

For three-connectivity, interlace two matching
chords when their endpoints alternate along (9).
A connected spanning set of interlacement edges is
\[
 xy-wo_1-a_1b_1-h_1j_N-a_Nb_N-e_Nz-uv
       -\gamma L_1-\alpha\beta-\delta R_1,             \tag{11}
\]
together with
\[
\begin{gathered}
 a_sb_s-j_sh_{s+1}-a_{s+1}b_{s+1}
                                      \quad(1\le s<N),\\
 a_1b_1-k_1i_N-i_1e_1,\\
 a_{2t}b_{2t}-i_{2t}k_{2t+1}-i_{2t+1}e_{2t+1},
 \qquad a_{2t}b_{2t}-e_{2t}o_{2t+1}
                                      \quad(1\le t<m),\\
 j_{2t-1}h_{2t}-o_{2t}k_{2t}
                                      \quad(1\le t\le m).
\end{gathered}                                           \tag{12}
\]
Every dash in (11)--(12) is endpoint alternation
in (9), and every matching chord appears in the
connected system. A two-edge cut in a cubic graph
with a spanning old Hamilton cycle would cut exactly
two old-cycle edges and bound a proper old-cycle
interval closed under the complementary matching.
Chords inside and outside that interval do not
interlace, contradicting (11)--(12). There is no
bridge because the old cycle spans. Hence the graph
is three-edge-connected and, being cubic,
three-vertex-connected.

The two internally disjoint \(x\)--\(v\) paths
\[
 x,R_1,\delta,\beta,\alpha,\gamma,L_1,v
 \qquad\text{and}\qquad
 x,y,w,P,z,u,v                                             \tag{13}
\]
cover the parent and give a Hamilton cycle containing
\(xy,uv\). Note 001 gives a Hamilton cycle in the
legal child.

**Class-preserving replacement.** The patch in
(1)--(2) is a plane disk four-pole, realized in
the three-connected graph (9)--(10). Deleting one
patch vertex leaves it connected: each block cycle
remains connected, the old interblock links lose at
most one edge, and at least one of \(h_1j_N,k_1i_N\)
still joins the first and last blocks. After
deleting two patch vertices, every surviving
component touches a surviving terminal; otherwise
that component would disconnect from the nonempty
exterior of the realization (9)--(10), contrary to
three-connectivity. For the transfer lemma, use its
assumed actual Barnette host in place of (9)--(10)
for this two-deletion argument. The exterior of any
four-attachment patch in a three-connected cubic host
is connected,
since two exterior components would each need at least
three of the four attachment edges. The deletion
comparison in Note 362 now applies verbatim to the
patch and the square: removal of any two vertices
leaves either substituted host connected if it leaves
the other connected. The colours, disk order,
simplicity, cubicity and planarity agree. Hence
replacement preserves Barnette membership in both
directions. Its exact linkage signature proved
above preserves every exterior Hamilton decision.
\(\square\)

For \(N=4\) this is Note 347's swap; for \(N=6\)
it is type \(A_0\) in Note 361. The theorem gives
a second unbounded nonlocal, square-equivalent
alternating-chain family alongside Note 346.
It does not classify all matching words at any
larger even length, prove that all six-block
branches are square-equivalent, or resolve
Barnette's conjecture. This is a project-internal
analytic proof without an external priority claim
or independent review.
