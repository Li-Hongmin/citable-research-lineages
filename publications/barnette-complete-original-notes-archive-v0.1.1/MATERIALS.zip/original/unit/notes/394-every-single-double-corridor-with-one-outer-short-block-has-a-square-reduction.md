> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every single–double corridor with one outer short block has a square reduction

[Note 390](390-every-isolated-single-double-corridor-contains-an-exact-square-reduction.md)
handles a single–double free group with no outer short blocks.
[Note 392](392-every-one-left-flank-tj-single-double-corridor-has-an-exact-square-reduction.md)
handles its `tJ` branch with exactly one left short block.
The remaining left-end choices reduce either to the no-flank
classification or to a smaller known square pole.

Use the compressed, gapless, tight-target all-square selected
opening of a Barnette parent. Fix one ordinary target-free free
group whose complete blocks, in old-cycle order, are exactly
\[
 S_0=(c,p,q,d),\quad V=(a,o,h,i,e,b),\quad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\quad
 D=(A,O,H,I,K,J,E,B),\qquad m\ge1.                 \tag{1}
\]
Thus \(S_0\) is the sole outer short block, while a positive
short-block corridor separates the singly vacant \(V\) from the
doubly vacant \(D\). There is no short block after \(D\).
Let \(t,z\) be the group's even left and odd right free endports,
and \(M\) the complementary matching of the chosen old
Hamilton cycle. Other groups and vacancies are unrestricted.

**One-outer-block theorem.** Every complementary matching that
actually occurs under (1) contains an induced disk patch with
exactly the square's four spanning one-path and two spanning
two-path Hamilton states. Its labeled square replacement is
strictly smaller, preserves Barnette membership in both
directions, and preserves every exterior- and attachment-marked
Hamilton decision. Consequently no vertex-minimal
non-Hamiltonian Barnette graph contains any of these induced
patches. Old-cycle reflection gives the same conclusion when
the sole outer short block follows the singly vacant block in
the reflected block order.

**Left-end classification.** The free-slot order is
\[
 t,p,q,o,h,i,e,p_1,q_1,\ldots,p_m,q_m,
 O,H,I,K,J,E,z.                                     \tag{2}
\]
All cross-block free chords lie opposite the common face by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
so they do not interlace. A proper consecutive interval of
complete blocks whose matching is internal would have only its
two boundary old-cycle edges leaving it, violating
three-connectivity.

The even slot \(t\) can meet only \(p,o,i,p_j,O,I,J,z\).
The edge \(to\) traps \(p,q\), which cannot match each other
because \(pq\) is an old-cycle edge. A chord \(tp_j\),
\(j\ge1\), traps the complete interval
\(S_0,V,S_1,\ldots,S_{j-1}\); \(tO\) traps
\(S_0,V,S_1,\ldots,S_m\); and \(tz\) traps the entire
group. In each case its trapped complete blocks would be
matching-closed, contrary to the cut rule. Therefore
\[
                            M(t)\in\{p,i,I,J\}.       \tag{3}
\]

If \(ti\in M\), the four free slots \(p,q,o,h\) before \(i\)
must pair among themselves. The only possible face-side
chord \(oe\) would give these four slots a single exit,
contradicting parity. Without it, \(ph,qo\) are forced:
\(pq,oh\) are old-cycle edges and \(po,qh\) join equal
colours. The induced \(S_0\cup V\) is precisely the
ten-vertex square-equivalent cube-fold patch of
[Note 315](315-port-owned-vacancy-folds-by-a-cube-reduction.md).

If \(tI\in M\), inspect the four slots \(K,J,E,z\) to its
right. An opposite-side chord from one of these slots to
the interior of \(tI\) would cross \(tI\). The slot \(J\)
has no legal mate among \(K,E,z\): \(KJ,JE\) are old-cycle
edges and \(Jz\) joins equal colours. Hence its only
possible mate is the face-side internal chord \(HJ=J_2\).
The chord-isolation lemma of
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
then excludes \(OK,IE\). The slot \(K\) can now meet only
\(z\), since its other outside pairs are forbidden or
wrong-coloured. With \(z\) used, \(E\) can meet only
\(O\) through the internal chord \(OE=J_0\). Thus both
rainbow chords \(J_0,J_2\) occur, and \(D\) itself is the
exact eight-vertex square pole of
[Note 325](325-even-rainbow-multivacancy-blocks-are-exact-square-reductions.md).

If \(tJ\in M\), Note 392 proves the assertion for every
actual matching, including all possible internal returns.

Finally suppose \(tp\in M\). The remaining slot \(q\) is
an even **virtual left endport** immediately before \(V\) in
the free-slot order. Treat \(V,S_1,\ldots,S_m,D\) as the
active core, with endports \(q,z\). Every parity and
noninterlacement step in the no-flank matching classification
of Notes 382–387 applies to this core. Every two-edge-cut
exclusion used there also applies in the original parent:
the supposedly closed intervals consist of unchanged
complete blocks among \(V,S_1,\ldots,S_m,D\), and their
two boundary old-cycle edges are still the only exits.
In particular, a virtual \(qz\) edge would close the entire
proper core interval and is excluded. The extra edge \(tp\)
and face chord \(cd\) both lie outside the active core and
cannot change any of these tests. Therefore the core
matching belongs to the exhaustive no-flank list of
Notes 382–387. By Note 390 it contains an exact induced
square reduction, which remains induced in the original
parent: its four attachment edges may meet \(S_0\), but no
other edge enters the patch. This finishes all four cases
of (3). \(\square\)

The conclusion needs exactly one outer short block and a
positive internal short corridor. It does not classify a
longer or two-sided nonstandard outer flank, groups with
other vacancy-bearing blocks, defective openings or
nonsquare residual cycles. It does not decide the general
Barnette conjecture. The proof is project-internal and
has not had independent external review or a complete
literature priority comparison.
