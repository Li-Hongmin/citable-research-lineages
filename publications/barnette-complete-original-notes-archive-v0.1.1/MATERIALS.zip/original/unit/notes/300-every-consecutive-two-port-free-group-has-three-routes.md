> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every consecutive two-port free group has three spanning routes

[Note 291](291-every-consecutive-two-port-short-shared-block-group-has-three-routes.md)
settles a short block shared by two consecutive missing ordinary
links. If that block is vacant, [Note 292](292-a-vacant-shared-block-forces-a-third-component-and-can-be-absorbed-one-sidedly.md)
separates its vacancy from both port components and settles one
end-port placement. [Note 299](299-an-arbitrary-surrounding-vacancy-component-across-two-end-ports-has-three-routes.md)
settles the placement in which this third component has atoms on
both sides of the shared vacancy. The remaining one-sided placement
allows the other port component to contain vacancies *before* its
port. Its last such vacancy exposes a complete one-defect gap.

Work in a compressed, gapless, tight-target all-square opening of a
Barnette parent, with every vacancy in a distinct target-free
internal face-chord block. Fix one free group whose only missing
ordinary links are
\[
 P_s=e_so_{s+1},\qquad P_m=e_mo_{m+1},\qquad m=s+1,
                                                               \tag{1}
\]
and whose ordinary end links are retained. Let
\(D=B_a,\ldots,B_b\) be the group's full target-free internal
block interval. As in Notes 275 and 288, write \(S(D)\) for a
spanning \(o_a\)--\(e_b\) path, \(K(D)\) for disjoint spanning
\(a_a\)--\(o_a\) and \(e_b\)--\(b_b\) paths, and \(X(D)\) for
disjoint spanning \(a_a\)--\(b_b\) and \(o_a\)--\(e_b\) paths.

**Consecutive two-port theorem.** Every free group satisfying (1)
has all three states \(S(D),K(D),X(D)\), regardless of whether
\(B_m\) is short or vacant. The numbers, positions, and nesting
depths of its target-free vacancies are unrestricted. If every
other free group of the opening has a spanning ordinary-endport
route, the parent has a Hamilton cycle through both site edges,
and its legal site-expanded child is Hamiltonian. The conclusion
holds at every surplus and for arbitrary positive original
square-trap lobe lengths.

The new step is the following one-sided statement. Suppose \(B_m\)
is vacant, and write \(V_m=(H_m,I_m)\). By Note 292, \(V_m\) lies
in a vacancy-only component \(\mathcal C\), distinct from the two
port components. Assume that \(V_m\) is the *last* atom of
\(\mathcal C\). Then the whole group has \(S,K,X\), with no
restriction on the position of \(P_m\) within its own component.
Reflection covers the case where \(V_m\) is first.

**Proof of the one-sided statement.** List the atoms of the
vacancy-only component as
\[
 \mathcal C:\quad V_{c_1}<\cdots<V_{c_h}=V_m,
 \qquad h\ge2.                                           \tag{2}
\]
The reduced boundary order has \(P_s<V_m<P_m\), with no atom
between either adjacent pair. The component of \(P_s\) lies
inside the proper gap between \(V_{c_{h-1}}\) and \(V_m\): a
component containing \(P_s\) cannot interlace \(\mathcal C\),
and it cannot be a singleton. In particular, all its other atoms
are vacancies to the left of \(P_s\). If \(P_m\) is the first
atom of its component, Note 292 gives the three states already.

Suppose instead that the component \(\mathcal R\) of \(P_m\)
has at least one vacancy to its left. Let \(V_t\) be its last
atom before \(P_m\). Noncrossing and the adjacency of
\(V_m,P_m\) imply
\[
                         t<c_1.                          \tag{3}
\]
Indeed, if \(V_t\) occurred between two consecutive atoms of
\(\mathcal C\), an atom of \(\mathcal C\) would lie before it
and another after it, while \(P_m\) lies after all of
\(\mathcal C\). The two components would interlace. There is
no atom between \(V_m\) and \(P_m\). Hence \(\mathcal C\),
the component of \(P_s\), and every other component between
\(V_t\) and \(P_m\) are wholly inside that one proper gap of
\(\mathcal R\). The component \(\mathcal R\) may also have
arbitrarily many vacancies to the right of \(P_m\).

Set
\[
                    F=B_{t+1},\ldots,B_m.                 \tag{4}
\]
Its only *internal* missing ordinary link is \(P_s\). The
other missing link \(P_m\) leaves its right boundary, and
\(e_to_{t+1}\) is retained at its left boundary. The rainbow
edge of \(\mathcal R\) incident with \(V_t\) is \(I_te_m\),
so \(e_m\) is an external boundary slot of \(F\). The other
external ordinary boundary slot is \(o_{t+1}\), matched to
\(e_t\). Every nonboundary matching slot of \(F\) is matched
inside \(F\): an edge from an interior atom to an atom
outside \(F\) would interlace \(\mathcal R\). This includes
all vacancy slots of \(\mathcal C\) and both ends of \(P_s\).
Consequently [Note 288's boundary-locality theorem](288-every-single-missing-link-vacancy-group-has-three-spanning-routes.md)
applies to \(F\) and gives vertex-spanning
\[
                         S(F),K(F),X(F).                   \tag{5}
\]
These paths use neither the retained left attachment
\(e_to_{t+1}\) nor the missing right link \(P_m\).

It remains to insert (5) into the outer one-port routing for
\(\mathcal R\). This is a precise instance of the
gap-substitution fact proved in Note 291. Here are the boundary
checks for each possible outer shape. If \(\mathcal R\) has
vacancies on both sides of \(P_m\), \(F\) is its final left
proper gap. [Note 285](285-every-interior-single-port-component-has-three-spanning-routes.md)
uses \(S(F)\) in the ordinary continuation after (4), \(X(F)\) in the
left path (5)--(6) for its cap and crossed routes, or reads
the whole gap once on the old cycle. Its outer matching edge
\(I_te_m\) and the retained link \(e_to_{t+1}\) are exactly
the edges used at the two ends of that gap.

If \(P_m\) is the last atom of \(\mathcal R\), reflect the
one-port constructions. Then \(F\) becomes their *first*
proper port gap. When \(B_{m+1}\) is short,
[Note 282](282-end-ports-with-arbitrarily-many-vacancies-have-three-spanning-routes.md)
uses \(S(F)\), \(X(F)\), or one uninterrupted old-cycle arc
there. When \(B_{m+1}\) is vacant in a different component,
the reflected boundary-sharing, surrounding, and later-atom
cases of [Notes 286](286-a-boundary-sharing-vacancy-interval-absorbs-an-unbounded-end-port-component.md),
[287](287-a-surrounding-vacancy-component-and-end-port-have-three-spanning-routes.md),
and [288](288-every-single-missing-link-vacancy-group-has-three-spanning-routes.md)
use that same first gap only through \(S(F)\), \(X(F)\),
or the uninterrupted old-cycle arc. In particular, their
proofs do not require its internal matching to be vacancy-only.
All attachments outside \(F\) remain the original retained
ordinary links, old-cycle edges, and matching edges of
\(\mathcal R\). Thus each of the outer \(S,K,X\) routes
covers \(F\) exactly once, through one of (5) or through its
old-cycle arc, and is vertex-disjoint from its other pieces.
Other vacancy-only components compose in proper gaps or serial
flanks by Note 275. This gives \(S(D),K(D),X(D)\). Reflection
proves the first-atom case. \(\square\)

**Proof of the consecutive two-port theorem.** If \(B_m\)
is short, apply Note 291. Otherwise Note 292 puts \(V_m\)
in a third vacancy-only component with at least two atoms.
It is either first, last, or has atoms on both sides.
The first two cases are the one-sided statement above and its
reflection; the last is the complete two-sided corollary of
Note 299. These cases exhaust the noncrossing atom partition,
so \(D\) has all three states. Apply \(S(D)\) in the ordinary
free path, splice the other groups as in Note 273, and use
Notes 001 and 178 for the marked parent cycle, legal child,
and original lobe lengths. \(\square\)

**A four-vacancy instance of the new nesting.** In the old-cycle
layout of Note 281(8), take \(\ell=1,r=6\), make
\(B_1,B_2,B_3,B_5\) vacant and \(B_4,B_6\) short. Retain
all ordinary free links except \(P_4=e_4o_5\) and
\(P_5=e_5o_6\). Along with Note 281's unchanged site,
face, escape, and residual-square matching edges, add
\[
\begin{array}{ll}
H_1o_6,\quad I_1e_5;&\mathcal R=\{V_1,P_5\},\\
H_2I_5,\quad I_2H_5;&\mathcal C=\{V_2,V_5\},\\
H_3o_5,\quad I_3e_4;&\{V_3,P_4\}.
\end{array}                                               \tag{6}
\]
The six edges in (6) pair exactly the eight vacancy slots
and four missing-link slots. Their endpoint intervals are
nested or disjoint, and each edge joins opposite old-cycle
colours. Retained links connect the face chords through
\(B_4\); \(H_2I_5\) attaches \(B_5\) to that chain, and
\(H_1o_6\) attaches \(B_6\). The remaining edges meet an
endpoint face chord. The unchanged site and residual-square
chain completes the matching-chord interlacement graph, so
Notes 217 and 182 give three-connectivity. This is a
44-vertex Barnette parent with a legal 48-vertex Hamiltonian
child. In it \(P_5\) has a vacancy to its left, outside the
scope of Note 292's one-sided theorem.

This completes the *consecutive two-defect free-group* branch
only under the stated opening hypotheses. Nonconsecutive or
three-or-more missing ordinary links, vacancies in repeated or
target-bearing blocks, positive gaps, defective target order,
nonsquare residual cycles, and general Barnette graphs remain
outside the theorem. No claim of priority over external work
is made here.
