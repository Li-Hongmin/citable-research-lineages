> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A seed-signature transfer theorem for the CEN/UV grammar

This note isolates the part of the cube argument that is portable.  The
finite-state calculation is universal for the two successor sites; the
initial witness and joint-incidence conditions are properties of the chosen
root site and are not automatic for an arbitrary legal expansion.

## Six roles and signed data

Let (G) be a Barnette graph and let (p=uv), (q=xy) be a legal,
vertex-disjoint (C_4)-expansion site in the ordered facial orientation
((u,v,ldots,x,y,ldots,u)).  Put (R=G-{p,q}).  Select concrete
spanning witnesses in the following six boundary roles:

\[
\begin{array}{c|l}
 A&C_{11}\text{ cycle with pairing }(uy)(vx),\\
 B&C_{10}\text{ cycle},\\
 C&C_{01}\text{ cycle},\\
 D&X_{vx}\text{ spanning path},\\
 E&X_{uy}\text{ spanning path},\\
 L&\text{two-path linkage with pairing }(uv)(xy).
\end{array}
\]

The supports are retained as concrete edge sets.  For every retained edge
(r), define

\[
 P(r)=\{\tau:\text{some role-}\tau\text{ witness contains }r\},
 \qquad
 N(r)=\{\tau:\text{some role-}\tau\text{ witness avoids }r\}.
\]

For an ordered pair of distinct retained edges define the joint set

\[
 J(r,s)=\{\tau:\text{some single role-}\tau\text{ witness contains }r
                         \text{ and avoids }s\}.
\]

The joint set is stronger than the two marginal sets: witnesses realizing
the two marginals need not be the same witness.

## The finite signed state domain

Write a state as (X/Y) for ((P,N)=(X,Y)), with role alphabet
({A,B,C,D,E,L}).  The following 22-state set is closed under both
CEN and UV transfer maps:

\[
\begin{aligned}
\Sigma=\{&ABC/ADEL, ABCD/AEL, ABCE/ADL, ACDEL/AB, ABDEL/AC,\\
&ABCDEL/ABCDEL, ABCDEL/ABCEL, ABCDEL/ABDEL, ABCDEL/ABEL,\\
&ABCDEL/ADEL, ABCDEL/AEL,\\
&ABCEL/ABCDEL, ABCEL/ABDEL, ABCEL/ADEL,\\
&ABDEL/ABCDEL, ABDEL/ABCEL, ABDEL/ACDEL, ABDEL/ACEL,\\
&ACDEL/ABDEL, ACDEL/ABEL, ADEL/ABCDEL, ADEL/ABCEL\}.
\end{aligned}
\]

The six retained positions in a CEN layer are
((ua,ab,bv,xc,cd,dy)); in a UV layer they are
((ab,xc,cd,dy,ad,bc)).  Exact enumeration of the (2^8) local gadget
subsets gives three facts used below:

1. every nonempty source role has a target role, and applying either
   memberwise transfer map to either coordinate of a state in (Sigma)
   stays in (Sigma);
2. for every state (P/NinSigma) and every retained position, some
   (P)-source transition uses local bit (0), while some (N)-source
   transition uses local bit (1);
3. the six final-gadget closure rows separate every ordered pair of distinct
   gadget edges (one row has bit (1) in the first column and (0) in the
   second).

The explicit transfer and closure rows are the tables in
[Note 014](014-cube-cen-uv-words-have-global-h-plus-minus.md).  The
independent finite-state certificate has 55 decorated states, 422 nonfinal
transition checks and 243 final checks.

## Transfer theorem

Assume the following seed conditions.

* **Role availability.** Each of the six concrete role families above is
  nonempty.
* **Signed marginals.** Every retained root edge (r) has
  ((P(r),N(r))\in\Sigma).
* **Joint separation.** For every ordered pair of distinct retained root
  edges (r,s), (J(r,s)\ne\varnothing).
* **Structural convention.** The site and every selected CEN/UV successor
  are legal Barnette sites.  If the empty word is included, assume the root
  itself has global (H^{+-}).

Then every positive-depth descendant obtained by the first expansion and an
arbitrary finite word in ({\mathrm{CEN},\mathrm{UV}}) has the global
(H^{+-})-property: for every ordered pair of distinct edges ((e,f)),
there is a Hamilton cycle containing (e) and avoiding (f).  With the last
clause above, the root also has the property.

### Proof

Carry concrete witnesses through each annulus using the memberwise transfer
rows.  An ordered pair of final edges belongs to one of four blocks.

* **Retained--retained.**  At the root, joint separation supplies one
  witness containing the first edge and avoiding the second.  Every source
  role has a nonempty target, and old edge incidences are unchanged, so the
  same witness relation survives every later annulus.  If both edges were
  born in the same nonfinal layer, the local (1/0) rows for the six
  retained positions give the required separation at birth; any later
  source-to-target transition then preserves it.
* **Retained--new.**  The first edge has a current (P)-coordinate in
  (Sigma).  Item 2 supplies a transition whose local bit at the new
  edge is (0), while retaining a witness containing the old edge.
* **New--retained.**  Use the current (N)-coordinate and the transition
  with local bit (1).  The resulting witness contains the new edge and
  avoids the old one.
* **New--new.**  At the final layer, item 3 supplies a closure row with
  bits (10).  Role availability turns that row into a concrete spanning
  Hamilton cycle.

The signed state of an edge born in a nonfinal layer is one of the explicit
birth states in the transfer tables, so induction applies to later layers.
Every ordered edge pair is covered by exactly one block.

## Why the joint condition is essential

The marginal condition alone does not imply the theorem.  For two abstract
retained edges (r,s), assign available local supports

\[
 A:\{00,11\},\qquad C:\{00\},
 \qquad B,D,E,L:\{11\}.
\]

Then for both edges (P=ABDEL) and (N=AC), so the marginal state is
(ABDEL/AC\inSigma), and all six roles are nonempty.  Nevertheless no
witness has bits (10) or (01); hence (J(r,s)=J(s,r)=\varnothing).
Thus the correct portable signature is

\[
\Sigma^{\sharp}=
\bigl(\text{all edge marginals in }\Sigma\bigr)
 +\bigl(\text{all ordered }J(r,s)\ne\varnothing\bigr),
\]

not (Sigma) by itself.

The 22-state domain is a compact sufficient domain reachable in the cube
proof.  It is not claimed to be the maximal or literally weakest invariant
domain; enlarging it is a separate finite-state optimization problem.

## Cube corollary and scope

For the cube site ((u,v,x,y)=(0,1,2,3)), the eight explicit witnesses in
[Note 014](014-cube-cen-uv-words-have-global-h-plus-minus.md) realize all
six roles.  Their retained-edge incidence columns form an antichain, which
gives the joint condition for all 90 ordered retained-edge pairs.  Hence the
cube satisfies the seed signature and the transfer theorem recovers the
all-depth cube CEN/UV (H^{+-}) theorem.

The result is conditional on the seed signature and legal successor sites.
It does not assert that arbitrary legal (C_4)-expansions preserve
(H^{+-}), nor that the six selected roles exhaust every possible witness.
