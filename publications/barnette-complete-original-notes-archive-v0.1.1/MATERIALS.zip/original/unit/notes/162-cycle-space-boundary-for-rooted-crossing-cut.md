> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cycle-space boundary for the rooted crossing cut

[Notes 152--154](152-root-square-crossing-edges-can-be-bridges.md) show that
sector-changing exchanges in a legal-wide rooted family can be bridges.  The
following identity gives the exact consequence of the exchange-cycle
algebra, and no more.

## 1. The unique-crossing bridge lemma

Let \(\mathcal T_e\) be the complete rooted target family and let
\(\Gamma_{g_1}(\mathcal T_e)\) have an edge \(MN\) whenever
\(M\triangle N\) is one alternating cycle.  For a perfect matching \(M\),
write \(\mu(M)\in\mathbb F_2^{E(G)}\) for its incidence vector and put

\[
\lambda(MN)=\mu(M)+\mu(N).
\tag{1}
\]

For every closed walk \(M_0M_1\cdots M_r=M_0\) in the exchange graph,

\[
\sum_{i=0}^{r-1}\lambda(M_iM_{i+1})=0
\quad\text{in }\mathbb F_2^{E(G)}.
\tag{2}
\]

Let \(s(M)=\mu(M)_{g_1}\).  Taking the \(g_1\)-coordinate in (1) gives

\[
\lambda(MN)_{g_1}=s(M)+s(N).
\tag{3}
\]

Thus every exchange-graph cycle contains an even number of edges crossing
the \(g_1\)-sector cut.  In particular,

\[
\boxed{
|E\Gamma_{g_1}(\mathcal T_e)|=1
\ \Longrightarrow\ \text{the unique crossing is a bridge of }\Gamma_{g_1}(\mathcal T_e).
}
\tag{4}
\]

Indeed, a non-bridge belongs to a graph cycle, and (3) would force that
cycle to contain a second crossing.

## 2. Sharpness of the algebraic reduction

Equation (2) is a telescoping identity.  It says that the crossing set is
the support of the coboundary \(ds\), so it annihilates the cycle space; it
does not prohibit a singleton cut, which is exactly a bridge.  The rooted
filter is an induced subfamily of the full perfect-matching exchange graph,
so no additional mod-\(2\) relation follows automatically from (2).

The existing legal-wide examples realize the remaining possibilities:

* [Note 152](152-root-square-crossing-edges-can-be-bridges.md) has a rooted
  exchange path whose two sector-changing edges are bridges;
* [Note 154](154-a-crossing-bridge-can-be-an-isolated-mixed-component.md)
  has an isolated mixed \(K_2\) component, so a crossing bridge can have
  cross-degree one at both endpoints;
* [Note 151](151-a-common-b-face-can-have-exactly-one-rooted-crossing.md)
  has 69 crossings in an unconditioned rooted fibre, including an odd total,
  so a universal even-cardinality law is false.

Consequently planarity, cubicity, bipartiteness, brace structure, legal-wide
geometry, complete perfect-matching closure, and Hamilton-cycle parity do not
by themselves imply that every crossing is non-bridging.

## 3. What would finish the cardinality statement

The target implication

\[
\Gamma_{g_1}(\mathcal T_e)\ne\varnothing
\Longrightarrow
|E\Gamma_{g_1}(\mathcal T_e)|\ge2
\tag{5}
\]

therefore needs a genuinely global rooted-incidence input.  Any one of the
following would suffice, but none is known to follow from the current
hypotheses:

1. every sector-changing edge is non-bridging (or the exchange graph is
   2-edge-connected);
2. a dimension-\(\ge2\) perfect-matching face is wholly rooted and
   \(g_1\)-nonconstant, so Balinski connectivity supplies two crossings;
3. every crossing has a rooted triangle or commuting-square completion.

Notes 152--154 refute the automatic local forms of (1) and (3), while
Note 151 shows that a common gate-face occupancy does not give (2).  The
remaining problem is therefore to couple different exchange components or
to use the full common perfect-matching incidence across rooted pairings.
No further parity, ordinary alternating-cycle, or fixed-face argument can
decide (5).

## 4. Literature boundary

Giannopoulou--Wiederrecht, *Two Disjoint Alternating Paths in Bipartite
Graphs* (arXiv:2110.02013, Theorem 1.9), characterizes matching crosses over
conformal cycles in braces.  A matching cross is not a rooted
single-alternating-cycle exchange edge, and that theorem does not preserve
the root pairing, the \(g_1\) sector, or rooted admission.  The root square
here is already a facial conformal cycle, so the theorem supplies no bridge
restriction for (5).

## Decision

The cycle-space route is closed at the exact bridge reduction (4).  The
legal-wide cardinality statement remains open; its next proof or
counterexample must retain global rooted perfect-matching incidence rather
than only cut parity.
