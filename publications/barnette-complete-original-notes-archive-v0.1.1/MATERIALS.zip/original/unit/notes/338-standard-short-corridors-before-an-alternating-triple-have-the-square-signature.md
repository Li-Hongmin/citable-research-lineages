> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Standard short corridors before an alternating triple have the square signature

[Note 337](337-every-consecutive-j1-j3-three-double-group-reduces-to-a-square.md)
forces a square-equivalent core when three \(J_1/J_3\) double
blocks are consecutive. A standard corridor of any positive
length before the \(J_3\) block retains that square signature.
For corridor length one, the matching itself is forced,
even with arbitrary outer short flanks.

Work in the compressed, gapless, tight-target all-square
opening of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix an ordinary target-free free group with even left and
odd right endports \(L,R\). Its only nonshort complete blocks,
in old-cycle order, are
\[
\begin{split}
D_1&=(a,o,h,i,k,j,e,b),\\
D_2&=(A,O,H,I,K,J,E,B),\\
D_3&=(\hat a,\hat o,\hat h,\hat i,\hat k,\hat j,\hat e,\hat b),
\end{split}                                                 \tag{1}
\]
carrying respectively \(J_1=ok,J_3=IE,J_1=\hat o\hat k\).
Between \(D_1,D_2\) lies exactly one short block
\(S=(c,s,t,d)\); \(D_2,D_3\) are adjacent. All other
complete blocks, if any, are short and occur outside this
four-block interval. Write \(P^+\) for the 28-vertex patch
\(D_1,S,D_2,D_3\), with old-cycle joins \(bc,dA,B\hat a\),
the face-side chords
\[
ab,\ ok,\ cd,\ AB,\ IE,\ \hat a\hat b,\ \hat o\hat k,     \tag{2}
\]
and the opposite-side chords
\[
h\hat i,\ iK,\ jH,\ es,\ tO,\ J\hat h.                  \tag{3}
\]
Its degree-two terminals are \((a,\hat j,\hat e,\hat b)\)
in disk-boundary order.

**One-corridor theorem.** Under the stated hypotheses, all
six chords in (3) are forced. The complete vertex-spanning
one-path and two-path Hamilton signature of \(P^+\) at its
four terminals equals that of the labeled square
\((a',\hat j',\hat e',\hat b')\). Replacing \(P^+\) by
the square, or conversely, preserves Barnette membership
and every Hamilton decision on exterior and attachment
edges. After this reduction, the free group has only short
blocks and hence a vertex-spanning \(L\)--\(R\) path.
If every other vacancy occupies a distinct internal block,
the parent has a Hamilton cycle through both site edges and
its legal site-expanded child is Hamiltonian. Old-cycle
reflection gives the corresponding theorem for the order
\(J_3,J_1,S,J_3\), with the one short corridor between
the final two double blocks.

**The matching is forced.** [Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)'s
chord-isolation lemma excludes all other free same-block
chords, and [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md)
places every cross-block free chord in the opposite-side
disk. The ordered free slots of the four-block core are
\[
h,i,j,e,s,t,O,H,K,J,\hat h,\hat i,\hat j,\hat e.        \tag{4}
\]
They are paired noncrossingly, together with the ordinary
endports and any outer short flanks.

The even slot \(h\) can meet only \(J\) or \(\hat i\).
Its old-cycle neighbour \(i\) and forbidden same-block
slot \(j\) are unavailable. Chords to \(s,O,\hat j\)
enclose respectively 3, 5, 11 free slots. A chord to a
left short-block odd slot encloses that block's second
slot plus pairs of later left short slots; a chord to a
right short-block odd slot or \(R\) encloses the thirteen
other core free slots after \(h\) plus an even number of
short slots. Every such count is odd.

Suppose \(hJ\) occurred. The even slot \(\hat h\) could
not reach any free slot inside \(hJ\) without crossing it.
Its same-block odd choices \(\hat i,\hat j\) are an
old-cycle edge and a chord forbidden by isolation.
A left short-block odd slot would enclose its second
slot, pairs of later left short slots, and all ten
free slots of \(D_1,S,D_2\), an odd total. A right
short-block odd slot or \(R\) would enclose
\(\hat i,\hat j,\hat e\) plus an even number of
short slots. Thus \(\hat h\) would have no mate, and
\(h\hat i\) is forced.

Inside \(h\hat i\), the odd slot \(i\) can meet only
\(K\) or \(\hat h\). The same-block \(ie\) chord is
forbidden; \(it\) and \(iH\) enclose respectively 3
and 5 slots. A mate outside \(h\hat i\) would cross it.
If \(i\hat h\) occurred, its eight interior slots would
be \(j,e,s,t,O,H,K,J\). The first odd slot \(j\)
could meet only \(t,H,K\). The choice \(jt\) forces
\(es\) and leaves \(O,H,K,J\), which cannot pair:
\(OH,KJ\) are old-cycle edges and the other
noncrossing choices leave a singleton. The choice
\(jH\) forces \(es,tO\) and leaves the old-cycle
pair \(KJ\). The choice \(jK\) encloses five slots.
Thus \(i\hat h\) is impossible and \(iK\) is forced.

The six slots inside \(iK\) are \(j,e,s,t,O,H\).
The slot \(j\) cannot use its old-cycle neighbour \(e\).
If \(jt\) occurred, its interior would force \(es\)
and leave the forbidden old-cycle pair \(OH\).
Therefore \(jH\) is forced; its interior
\(e,s,t,O\) has the unique allowed noncrossing
matching \(es,tO\). The remaining two slots inside
\(h\hat i\) force \(J\hat h\), proving (3).
The four-pole \(P^+\) is induced because every
nonterminal vertex now has its full degree three.

**Complete Hamilton signature.** The face-side chords (2)
are nested or disjoint, as are the opposite-side chords
(3). In particular, \(h\hat i\) surrounds \(iK,jH,es,tO,J\hat h\);
\(iK\) surrounds \(jH,es,tO\), and \(jH\)
surrounds \(es,tO\). This gives a plane disk drawing
with terminals \((a,\hat j,\hat e,\hat b)\).
Their colours permit exactly four single-path endpoint pairs.

For \(a\hat b\), use the full old-cycle path through
\(D_1,S,D_2,D_3\). For each of the other three
single-path rows of Note 337(6), replace its edge
\(eO\) by
\[
e,s,c,d,t,O,                                              \tag{5}
\]
or replace \(Oe\) by the reverse sequence. All three
rows of Note 337(6) use exactly that matching edge,
and each replacement visits the four vertices of \(S\)
once. Each successive pair in (5) is a chord in (3),
an old-cycle edge, or the face chord \(cd\).
These are the four required spanning paths.

For the two-path pairing
\(\{a\hat j,\hat e\hat b\}\), take the old-cycle
path from \(a\) through \(\hat j\) and the edge
\(\hat e\hat b\). For
\(\{a\hat b,\hat j\hat e\}\), take the modified
\(a\hat j\) single path and delete its edge
\(\hat b\hat e\). The two resulting paths cover all
28 vertices. The third pairing interlaces the
terminals and is impossible in a disk. Thus \(P^+\)
has exactly the square's complete Hamilton signature.

**Realization and connectivity.** Start with the
36-vertex old-cycle realization in Note 337(7), insert
\(S\) between \(D_1,D_2\), and replace the matching
edge \(eO\) by \(es,tO\); add \(cd\).
Equivalently, the old Hamilton order is
\[
x,R_1,w,y,D_1,S,D_2,D_3,u,z,L_1,v,
\alpha,\gamma,\delta,\beta,x.                           \tag{6}
\]
The face-side matching consists of Note 337(8) together
with \(cd\). Its opposite-side matching is Note 337(9)
with \(eO\) replaced by \(es,tO\). Both pages are
noncrossing, every vertex is matched once to the
opposite old-cycle colour, and no old-cycle edge is
repeated. The site chords \(xy,uv\) remain cofacial.

The interlacement graph of these 20 matching chords is
connected. Every alternation in Note 337(10) not
involving \(eO\) survives insertion of \(S\).
Replace its branch \(AB-eO\) by
\[
AB-tO-cd-es-ab.                                         \tag{7}
\]
The four new dashes follow from
\(t<A<O<B\), \(c<t<d<O\), \(e<c<s<d\),
and \(a<e<b<s\), respectively. This connected
system contains all 20 chords. As in Note 337, a
two-edge cut would disconnect the interlacement
graph; the old Hamilton cycle excludes bridges.
The 40-vertex plane cubic bipartite graph is therefore
three-connected.

Replace \(O,e\) in the \(\hat j\hat e\) row of
Note 337(6) by \(O,t,d,c,s,e\). Joining this
spanning patch path to the two exterior \(x\)--\(v\)
paths of Note 337(11) gives a Hamilton cycle through
both site chords. Reflecting the construction realizes
the stated reversed orientation.

**Barnette preservation.** The labeled square is a
planar minor of \(P^+\): contract the interiors of
the two internally disjoint paths
\[
a,b,c,d,A,B,\hat a,\hat b
\quad\text{and}\quad
a,o,h,\hat i,\hat k,\hat j
\]
to its \(a'\hat b'\) and \(a'\hat j'\) edges,
respectively; keep the old edges
\(\hat j\hat e,\hat e\hat b\) and delete surplus
edges. The two-page drawing inserts \(P^+\) into
the empty side of a labeled square in the reverse
direction. Terminal colours and cyclic order agree.

Deleting any one vertex leaves \(P^+\) connected:
each of \(D_1,S,D_2,D_3\) remains connected through
its face-closed block cycle, and every consecutive
pair has two joins with disjoint endpoints:
\(bc,es\); \(dA,tO\); and \(B\hat a,J\hat h\).
After two patch vertices are deleted, each surviving
patch component contains a surviving terminal;
otherwise that component would disconnect the
three-connected realization (6) from its nonempty
exterior. The exterior of any four-pole in a
three-connected cubic host is connected, since
two exterior components would each require at least
three of the four attachment edges. The
four-attachment deletion comparison of
[Note 330](330-staggered-vacancy-chains-have-the-square-hamilton-signature.md)
therefore preserves three-connectivity in both
replacement directions. Simplicity, cubicity,
bipartiteness and planarity are preserved as well.

Compressing \(P^+\) in the selected opening produces
one short target-free square. All other blocks in
the group are short; the ordinary-link argument of
[Note 275](275-every-vacancy-only-noncrossing-matching-is-marked-hamiltonian.md)
gives its spanning \(L\)--\(R\) route. Lift that
route through the complete signature above.
When all other vacancies occupy distinct internal
blocks, Note 324 gives a Hamilton parent cycle through
both site edges, and [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives the legal child's Hamilton cycle. \(\square\)

**Unbounded standard corridors.** There is a square-equivalent
patch of this type for every corridor length \(k\ge1\),
although the specified matching is proved forced above
only for \(k=1\). Replace \(S\) by
\(S_t=(c_t,o_t,e_t,d_t)\), \(1\le t\le k\),
between \(D_1,D_2\). Add all face chords \(c_td_t\).
Put \(e_0=e\). Retain the four opposite-side chords
\(h\hat i,iK,jH,J\hat h\), and replace \(eO\) by
\[
e o_1,\quad e_t o_{t+1}\ (1\le t<k),\quad e_kO.         \tag{8}
\]
Call the resulting \(24+4k\)-vertex four-pole \(P_k\).
Its only degree-two vertices are again
\((a,\hat j,\hat e,\hat b)\).

The full old-cycle path gives the \(a\hat b\) route.
In each other spanning one-path row of Note 337(6),
replace \(eO\) by the vertex sequence
\[
e,\ (o_t,c_t,d_t,e_t)_{t=1}^{k},\ O,                   \tag{9}
\]
or use the reverse sequence for \(Oe\).
Its joins are exactly (8), its three edges inside
each tuple are two old-cycle edges and \(c_td_t\),
and it visits every corridor vertex once. The two
spanning two-path pairings are again the old path
from \(a\) to \(\hat j\) plus \(\hat e\hat b\),
and the modified \(a\hat j\) route split at
\(\hat b\hat e\). Colour and planarity exclude
all other endpoint states. Thus \(P_k\) has exactly
the labeled square's complete Hamilton signature.

For each \(k\), insert \(S_1,\ldots,S_k\) into
Note 337's 36-vertex old-cycle realization, add
the face chords \(c_td_t\), and replace \(eO\)
by (8). This is a two-page cubic bipartite plane
graph on \(36+4k\) vertices. Its matching-chord
interlacement graph remains connected: keep all
alternations of Note 337(10) except the branch
\(AB-eO\), and replace that branch by
\[
AB,\ e_kO,\ c_kd_k,\
(e_{t-1}o_t,c_{t-1}d_{t-1})_{t=k,k-1,\ldots,2},\
e o_1,\ ab.                                             \tag{10}
\]
Consecutive entries in (10) denote endpoint alternations;
the parenthesized range is empty when \(k=1\).
For each \(t\), \(e_tO\) or \(e_to_{t+1}\)
interlaces \(c_td_t\) by
\(c_t<e_t<d_t<O,o_{t+1}\);
\(e_{t-1}o_t\) interlaces \(c_td_t\) by
\(e_{t-1}<c_t<o_t<d_t\). The two end
alternations follow from \(e_k<A<O<B\) and
\(a<e<b<o_1\). Hence (10) joins every new
matching chord to the old connected system.
The graph is three-connected by the same
two-edge-cut argument. Substituting (9) into
Note 337's marked Hamilton cycle gives one
through both site chords for every \(k\).

The square is a planar minor of \(P_k\):
contract the face-chord path
\(a,b,c_1,d_1,\ldots,c_k,d_k,A,B,\hat a,\hat b\)
and the internally disjoint path
\(a,o,h,\hat i,\hat k,\hat j\)
to its \(a'\hat b'\) and \(a'\hat j'\) edges,
retaining \(\hat j\hat e,\hat e\hat b\).
After one patch vertex is deleted, the block cycles
remain joined in a chain by two independent edges
per consecutive pair. After two are deleted, every
component has a surviving terminal by the
three-connected realization just constructed.
The four-attachment deletion comparison therefore
proves that replacing \(P_k\) by its square, or
conversely, preserves Barnette membership and
exterior-marked Hamilton decisions.

**The length-one forcing boundary is sharp.** With two
short blocks \(S_t=(c_t,o_t,e_t,d_t)\), \(t=1,2\),
between \(D_1,D_2\), the following is another
noncrossing opposite-side matching on the core:
\[
h\hat i,\quad iK,\quad J\hat h,\quad
je_1,\quad eo_1,\quad o_2H,\quad e_2O.                \tag{11}
\]
It differs from the standard matching (8), which
uses \(jH,e_1o_2\) in place of \(je_1,o_2H\).
The chords \(je_1,eo_1\) are nested, as are
\(o_2H,e_2O\); these pairs are disjoint and lie
inside \(iK\), which lies inside \(h\hat i\).
All short-block and double-block face chords
remain on the other page.

This matching has a vertex-spanning route between the
same two free ports. One explicit \(\hat j\)--\(\hat e\)
path through all 32 patch vertices is
\[
\begin{split}
&\hat j,\hat k,\hat o,\hat h,\hat i,h,i,k,o,a,b,\\
&c_1,o_1,e,j,e_1,d_1,c_2,d_2,A,O,e_2,o_2,\\
&H,I,K,J,E,B,\hat a,\hat b,\hat e .
\end{split}                                               \tag{12}
\]
Every successive pair is an old-cycle edge, a
face-side chord, or a chord of (11).

It occurs in a 44-vertex Barnette parent: use
Note 337(7)'s old Hamilton order with \(S_1,S_2\)
inserted between \(D_1,D_2\), add their two face
chords, and replace \(jH,eO\) by
\(je_1,eo_1,o_2H,e_2O\). Retain all other chords
of Note 337(8)--(9), including \(w\hat j,\hat e z\).
Every vertex is matched once to the opposite
old-cycle colour, and each page is noncrossing.
The interlacement graph remains connected: remove
the two leaf branches \(AB-jH,AB-eO\) from
Note 337(10) and attach the new chords by
\[
ab-je_1-c_1d_1-eo_1,\qquad
AB-o_2H-c_2d_2-e_2O.                                \tag{13}
\]
The six dashes are endpoint alternations, respectively
from \(a<j<b<e_1\), \(j<c_1<e_1<d_1\),
\(e<c_1<o_1<d_1\), \(o_2<A<H<B\),
\(c_2<o_2<d_2<H\), and
\(c_2<e_2<d_2<O\). Thus the same two-edge-cut
argument proves three-connectivity. Joining (12)
to Note 337(11)'s exterior paths gives a Hamilton
cycle containing both site chords. The two-slot
corridor therefore has a genuine nonstandard
matching; uniqueness does not extend from \(k=1\)
to \(k=2\).

The forced-matching theorem covers exactly one short
block between the first \(J_1\) and the \(J_3\)
block, with arbitrary outer short flanks, and its
reflected orientation. For \(k>1\), (8) is a
specified realizable matching; (11) shows it is
not always unique. The exact \(k\)-type classification
and complete square signature for each type are proved in
[Note 340](340-a-k-block-corridor-before-an-alternating-triple-has-exactly-k-matching-types.md).
Differently placed corridors, other internal-chord types,
singly vacant blocks in the same group, non-tight or
non-square openings, and the general Barnette conjecture
remain outside this note.
The proof is project-internal; no external priority
or independent review is claimed.
