> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(C_4+C_8\) XOR incidence lifts exactly by losing cofaciality

[Note 094](094-a-minimum-planar-multiport-tangle-realizes-the-xor-pairing-table.md)
gives the smallest ordered planar reduced tangle whose two toggles realize

\[
00:I,\qquad10:E,\qquad01:E,\qquad11:I
\tag{1}
\]

without closed components.  Its reduced graph is not bipartite and does not
yet carry four perfect matchings of one cubic-incidence graph.  This note
determines the next interface for that fixed \(C_4+C_8\) incidence.

There is a 20-vertex simple connected plane bipartite four-terminal graph
whose four genuine perfect matchings realize (1), with diagonal symmetric
difference exactly \(C_4\dot\cup C_8\).  The four terminals, however, are
not cofacial in any plane embedding.  Conversely, if the original
concentric annulus and ordered outer terminal boundary are retained, an
integer bipartite colour imbalance of two makes every such common-matching
lift impossible, even with arbitrary path lengths and arbitrary common
matching edges between the radial corridors.

Thus planarity, bipartiteness, cubic incidence and a common perfect-matching
cube still do not exclude XOR.  What excludes this literal construction is
their coupling to the cofacial boundary geometry required by a labelled
inverse-square interface.

## 1. A 20-vertex matching-incidence lift

Let

\[
A=a_0a_1a_2a_3a_0,
\qquad
B=b_0b_1\cdots b_7b_0.
\tag{2}
\]

Join the cycles and four terminals by the eight paths

\[
\begin{array}{llll}
a_0b_0,&a_1r_1b_2,&a_2b_4,&a_3r_3b_6,\\
b_1t_0,&b_3s_1t_1,&b_5t_2,&b_7s_3t_3,
\end{array}
\tag{3}
\]

and add the common matching

\[
K=\{t_0r_1,t_1s_3,t_2r_3,t_3s_1\}.
\tag{4}
\]

Call the resulting graph \(R\).  It has 20 vertices and 28 edges.  It is
simple, connected, plane and bipartite; the four \(t_i\) have degree two
and every other vertex has degree three.  One bipartition class is

\[
\{a_1,a_3,b_0,b_2,b_4,b_6,t_0,t_2,s_1,s_3\},
\tag{5}
\]

and the other is its complement.

For either even cycle \(C\), let \(S_C^0,S_C^1\) be its two alternating
edge matchings in the convention of Note 094, and define

\[
P_{ij}=K\cup S_A^{1-i}\cup S_B^{1-j}
\qquad(i,j\in\{0,1\}).
\tag{6}
\]

Each \(P_{ij}\) is a perfect matching of the same graph \(R\).  Each
complement \(R-P_{ij}\) consists of exactly two spanning terminal paths,
with no closed component, and its terminal pairing is precisely (1), where

\[
I=(t_0t_1)(t_2t_3),\qquad E=(t_0t_3)(t_1t_2).
\tag{7}
\]

Moreover

\[
P_{00}\triangle P_{10}=E(A),\qquad
P_{00}\triangle P_{01}=E(B),
\tag{8}
\]

so

\[
P_{00}\triangle P_{11}=E(A)\mathbin{\dot\cup}E(B).
\tag{9}
\]

This proves that common perfect-matching incidence, rather than merely a
complement transition table, does not by itself rule out double-\(E\).

## 2. The terminals are intrinsically noncofacial

The loss of the original outer boundary is not an artefact of one chosen
rotation.  Add a new vertex \(z\) adjacent to all four terminals.  The
augmented graph contains a \(K_{3,3}\)-subdivision with branch classes

\[
\{s_3,z,s_1\}\mid\{a_3,t_1,t_3\}.
\tag{10}
\]

Its nine branch paths are

\[
\begin{array}{lll}
s_3-b_7-b_0-a_0-a_3,&s_3-t_1,&s_3-t_3,\\
z-t_2-r_3-a_3,&z-t_1,&z-t_3,\\
s_1-b_3-b_2-r_1-a_1-a_2-a_3,&s_1-t_1,&s_1-t_3.
\end{array}
\tag{11}
\]

Their interiors are pairwise disjoint.  Hence the apex-augmented graph is
nonplanar.  If the four terminals were cofacial in any plane embedding of
\(R\), the apex and its four incident edges could be drawn inside that
face, a contradiction.  Therefore

\[
\boxed{t_0,t_1,t_2,t_3\text{ are not cofacial in any plane embedding of }R.}
\tag{12}
\]

In the direct completion model that retains the twelve toggle ports,
replaces each of the eight external edges by an internally disjoint path,
and perfect-matches all path interiors together with the four terminals,
order 20 is sharp.  Bipartiteness forces two radial paths to have even
length, hence at least two radial subdivision vertices.  Colour balance on
the vertices to be covered by the common matching then forces at least two
terminal-path subdivisions.  The construction (3) attains these four
subdivisions.  This is a local model minimum, not a census over arbitrary
gadgets.

## 3. Why the concentric cofacial lift is impossible

Now retain the literal concentric geometry of Note 094.  The two cycles
bound an open annulus, and its complement skeleton consists of four
pairwise disjoint paths

\[
R_i:a_i\longrightarrow b_{2i}
\qquad(i\in\mathbb Z/4\mathbb Z).
\tag{13}
\]

Allow arbitrary positive path lengths.  Also allow common matching edges
between interiors of different \(R_i\); the paths need not be completed as
independent wires.

Fix a bipartition.  The colours of the \(a_i\) alternate, whereas
\(b_0,b_2,b_4,b_6\) all have one colour \(\beta\).  Exactly two paths in
(13) therefore have both endpoints coloured \(\beta\); the other two have
oppositely coloured endpoints.  For a bipartite path, opposite-coloured
endpoints leave equal numbers of its two colours internally, while two
\(\beta\)-coloured endpoints leave one extra internal vertex of colour
\(1-\beta\).  If \(U\) is the set of all annular path interiors, then

\[
|U\cap V_{1-\beta}|-|U\cap V_\beta|=2.
\tag{14}
\]

On the other hand, if

\[
P_{00}\triangle P_{11}=E(A)\mathbin{\dot\cup}E(B),
\tag{15}
\]

every off-cycle vertex is covered by an edge common to \(P_{00}\) and
\(P_{11}\), while every vertex on \(A\cup B\) is already covered by a
toggle-cycle edge.  Jordan separation prevents an edge incident with an
annular interior vertex from leaving the annulus without crossing \(A\) or
\(B\).  Consequently the common edges must perfectly match \(U\) inside
the annulus.  A bipartite perfect matching requires its two colour classes
to have equal size, contradicting (14).

The mod-two path-parity equations themselves are consistent: the four
radial paths always have two even and two odd lengths.  The obstruction is
the signed integer residue in (14), not an unsatisfied GF(2) cycle equation.

## 4. Exact boundary

**Positive realization.**  A simple connected plane bipartite
four-terminal graph, cubic away from its terminals, can contain four actual
perfect matchings with the cycle-free XOR table (1) and diagonal
\(C_4\dot\cup C_8\).

**Cofacial obstruction.**  The literal concentric \(C_4+C_8\) incidence
cannot have such a lift while retaining its annular ordered-boundary
geometry.  This remains true for arbitrary radial path lengths and
arbitrary cross-corridor common matching edges.

**Consequence.**  Neither pure topology nor plane bipartite cubic matching
incidence alone proves the cofacial-pairing lemma.  The first still viable
interface is their joint ordered-cofacial realization.  A counterexample
must change the twelve-port annular incidence so that every bounded region
has zero signed colour residue; a proof must show that all such balanced
multi-port patterns conflict with the labelled root--gate interface or the
complete fibre.

**Scope.**  The 20-vertex graph is not a legal inverse-square interface,
and neither result asserts brace structure, global cross-sector minimality,
or a complete-fibre counterexample.

The explicit graph, four matchings, rotation, noncofacial
\(K_{3,3}\)-subdivision and annular colour calculation are frozen in the
[verification bundle](../computations/bundles/cofacial-boundary-of-the-c4-c8-xor-lift/README.md).
