> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Canonical--cross supplementation is exactly wrong-interval-island exclusion

[Note 108](108-kill-cover-supplementation-is-exactly-a-rooted-split-bond-lemma.md)
reduces the remaining one-step preservation problem to a rooted bond flip
after splitting one vertex of an Eulerian triangulation.  [Note 111](111-parent-bond-split-lift-calculus-and-nondirect-canonical-x-supplementation.md)
shows that every child in the frozen through-order-
\(26\) kill-cover stratum has a canonical--cross bond, but that such a bond
need not descend from any prescribed parent bond.  This note gives an
arbitrary-order criterion for the complete child family itself.

The criterion is purely a component-hitting condition.  A canonical--cross
bond fails exactly when every opposite-gate pair has a component which
misses the split interval to which its shore must attach.  Thus the
canonical--cross conjecture is equivalent to excluding one explicit
wrong-interval-island obstruction in an actual triangulation split.

## 1. Split intervals and rooted colourings

Let \(T^+\) be the child Eulerian plane triangulation in the notation of
Note 108.  Its split patch has vertices \(A,B,C,P,Q\) and local edges

\[
 AP,BP,CP,AQ,BQ,CQ,AC,BC.
\tag{1}
\]

Delete the three new vertices and put

\[
 H=T^+-\{A,B,C\},\qquad
 J_A=N_{T^+}(A)\cap V(H),\quad
 J_B=N_{T^+}(B)\cap V(H).
\tag{2}
\]

The sets \(J_A,J_B\) are the two closed rotation intervals inherited from
the split vertex; both contain \(P,Q\).  Let \({\cal A}_K^b\) be the
root-admissible NAE colourings in local cell \(K\), modulo global reversal,
whose surviving-gate bit is \(b\in\{0,1\}\).  Write

\[
 {\cal C}=\{C_{00},C_{10},C_{01}\},\qquad
 U=X_{uy},\quad V=X_{vx}.
\tag{3}
\]

For a canonical colouring \(\kappa\) and a cross colouring \(\xi\), choose
the representatives specified by the five-bit rows of Note 108 and define

\[
 D=D(\kappa,\xi)
   =\{v\in V(H):\kappa(v)\ne\xi(v)\}.
\tag{4}
\]

For \(S\subseteq V(H)\), define

\[
 \begin{aligned}
 h_A(S)&\Longleftrightarrow
   \text{every component of }H[S]\text{ meets }J_A,\\
 h_B(S)&\Longleftrightarrow
   \text{every component of }H[S]\text{ meets }J_B.
 \end{aligned}
\tag{5}
\]

Empty induced subgraphs satisfy these conditions vacuously.

## 2. The exact component criterion

**Lemma 1.**  Let \(\kappa\) and \(\xi\) be root-admissible.

1. If \(\xi\in U\), their XOR cut is a bond if and only if
   \[
   h_A(D)\quad\text{and}\quad h_B(\bar D).
   \tag{6}
   \]
2. If \(\xi\in V\), their XOR cut is a bond if and only if
   \[
   h_B(D)\quad\text{and}\quad h_A(\bar D).
   \tag{7}
   \]

Here complements are taken in \(V(H)\).

*Proof.*  The five local bits give the complete XOR table

\[
\begin{array}{c|cc}
 &U&V\\ \hline
C_{00}&ACPQ&BCPQ\\
C_{10}&AQ&BQ\\
C_{01}&AP&BP.
\end{array}
\tag{8}
\]

For a \(U\)-pair, the \(D\)-shore has one connected local core containing
\(A\).  It attaches to \(H[D]\) exactly at \(J_A\cap D\); hence that
shore is connected exactly when every component of \(H[D]\) meets
\(J_A\).  The complementary shore has one connected local core containing
\(B\), and it attaches to \(H[\bar D]\) exactly at
\(J_B\cap\bar D\).  Its connectivity is therefore equivalent to
\(h_B(\bar D)\).  A cut is a bond exactly when both shores are connected.
This proves (6), and exchanging \(A,B\) proves (7). \(\square\)

The surviving gate is outside the split interface.  Thus two colourings
have different gate bits exactly when their XOR cut contains the gate dual
edge.  Since membership in \({\cal A}\) already includes NAE and the full
labelled root-admissibility condition, Lemma 1 immediately yields the
complete-family statement.

**Theorem 2.**

\[
\begin{split}
 \Gamma({\cal C},{\cal X})\ne\varnothing
 \quad\Longleftrightarrow\quad
 &\exists b,\ \kappa\in{\cal A}_{\cal C}^{b},\
      \xi\in{\cal A}_{U}^{1-b}:
      h_A(D)\wedge h_B(\bar D),\\
 &\text{or }\exists b,\ \kappa\in{\cal A}_{\cal C}^{b},\
      \xi\in{\cal A}_{V}^{1-b}:
      h_B(D)\wedge h_A(\bar D).
\end{split}
\tag{9}
\]

## 3. The unique wrong-interval-island obstruction

Say that the complete child family has the **wrong-interval-island
obstruction** \(\mathsf{WII}\) if

\[
\begin{aligned}
&\forall b,\ \forall\kappa\in{\cal A}_{\cal C}^{b},\
 \forall\xi\in{\cal A}_{U}^{1-b},\\[-2mm]
&\qquad
 \bigl[\exists K\in\pi_0(H[D]):K\cap J_A=\varnothing\bigr]
 \ \vee\
 \bigl[\exists L\in\pi_0(H[\bar D]):L\cap J_B=\varnothing\bigr],
\\[1mm]
&\forall b,\ \forall\kappa\in{\cal A}_{\cal C}^{b},\
 \forall\xi\in{\cal A}_{V}^{1-b},\\[-2mm]
&\qquad
 \bigl[\exists K\in\pi_0(H[D]):K\cap J_B=\varnothing\bigr]
 \ \vee\
 \bigl[\exists L\in\pi_0(H[\bar D]):L\cap J_A=\varnothing\bigr].
\end{aligned}
\tag{10}
\]

Missing opposite-gate occupancy is included vacuously in (10); it is not a
second obstruction.

**Corollary 3.**

\[
\boxed{
\Gamma({\cal C},{\cal X})=\varnothing
\quad\Longleftrightarrow\quad \mathsf{WII}.}
\tag{11}
\]

Thus the candidate implication isolated in Note 111,

\[
\text{parent kill cover}
\Longrightarrow \Gamma({\cal C},{\cal X})\ne\varnothing,
\tag{12}
\]

is exactly the assertion that an actual legal split pair satisfying the
parent antecedent cannot realize \(\mathsf{WII}\).

## 4. Minimal region-tree forms

Fix an opposite-gate canonical--cross pair.  The primal dual of its XOR
cut is the symmetric difference of two perfect matchings, hence a disjoint
union of simple alternating cycles.  All local cut edges in (8) form one
path through the four split triangles and therefore lie on one
distinguished cycle \(Z_0\).  Every other cycle has a shore containing none
of \(A,B,C,P,Q\): its cut contains no local edge, so the connected local
patch lies wholly on the other shore.

Flipping such a patch-free shore at either endpoint preserves NAE and the
local cell and removes precisely that symmetric-difference cycle.  Let
\(Z_g\) be the unique cycle containing the surviving gate.  Choose an
opposite-gate canonical--cross pair with the minimum number of difference
cycles.  Every exterior cycle

\[
Z\notin\{Z_0,Z_g\}
\tag{13}
\]

must fail root-admissibility when flipped at either endpoint; otherwise a
smaller opposite-gate pair with the same two local cells would result.  By
Note 109, each failure is exactly a violation of

\[
\rho_{00}+\rho_{11}=\rho_{10}+\rho_{01}
\tag{14}
\]

or a fusion of the two labelled opposite-colour root fragments.

If \(Z_g\ne Z_0\), flipping its patch-free shore at the canonical endpoint
cannot remain root-admissible: it would be a canonical--canonical rooted
bond, forbidden by the parent kill-cover hypothesis and the canonical
induced-graph identity of Note 108.  A corresponding flip at the cross
endpoint gives only a cross--cross bond.

Consequently a minimum nonvacuous realization of \(\mathsf{WII}\) has one
of two region-tree forms:

1. a local/gate two-cycle diagonal with \(Z_0\ne Z_g\); or
2. an exterior nongate cycle whose flip is rank- or label-blocked at both
   endpoints.

These are two manifestations of the single quantified obstruction (10),
not additional hypotheses.

## 5. Boundary of the parent hypothesis

The parent kill cover excludes a patch-free flip only when its starting
endpoint is canonical, its cycle contains the surviving gate, and the
flipped endpoint remains root-admissible.  It does not constrain gate-free
exterior flips, flips from a cross endpoint, or NAE flips whose result is
not root-admissible.  It therefore does not by itself exclude either
minimal form above.

The scalar region-tree count also supplies no hidden convexity.  Two
disjoint transitions between the same two complement cycles can have
circuit-count table

\[
\begin{array}{c|cc}
 &0&1\\ \hline
0&2&1\\
1&1&2,
\end{array}
\tag{15}
\]

so both diagonal states are targets while each single-switch intermediate
state fails even the scalar part of root-admissibility.  This transition
system is not an actual plane-brace counterexample; it only shows why a
minimality proof cannot assume endpoint convexity.

The arbitrary-order canonical--cross statement is therefore reduced, but
not proved, by (11).  A counterexample must realize \(\mathsf{WII}\) in an
actual split pair of \(4\)-connected Eulerian plane triangulations.  A
proof must exclude (10) using common triangulation incidence beyond the
rank calculus of Note 109; parent ancestry, a fixed rank profile and the
kill-cover statement alone do not do so.
