> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A nonplanar brace has marked cross openings but no cross Hamilton path

The 16-vertex graph below was the finite nonplanar interface model in
[Note 013](013-h-plus-minus-parent-forces-a-p2-hamiltonian-c4-child.md).
Here it receives an analytic brace certificate, a non-Pfaffian
classification, and a Hamilton cycle avoiding both site edges.
Together with [Note 174](174-brace-cross-openings-avoid-a-forbidden-matching-edge.md),
it separates marked alternating reachability from tree-quotient selection
even under 2-extendability. There is no planar cofacial site in this
example, so it says nothing negative about Barnette's conjecture.

Let \(G\) have bipartition \(L=\{0,\ldots,7\}\),
\(R=\{8,\ldots,15\}\), with the following complete adjacency table:
\[
\begin{array}{c|cccccccc}
i&0&1&2&3&4&5&6&7\\ \hline
N(i)&8,9,15&8,10,13&8,12,15&9,11,13&9,12,14&
10,11,14&10,12,15&11,13,14.
\end{array}
\tag{1}
\]
Set \(p=2\,15\), \(q=7\,11\) and use the abstract ordered site
\((u,v,x,y)=(15,2,11,7)\). The endpoints \(u,x\) have the same
bipartition colour, so the usual bipartite square expansion is defined
combinatorially.

**Theorem.** The graph \(G\) is simple, cubic, bipartite,
3-connected, 2-extendable, nonplanar, and non-Pfaffian. It has a
Hamilton cycle \(C\)
avoiding \(p,q\), but \(G-\{p,q\}\) has neither a Hamilton
\(2\)-to-\(11\) path nor a Hamilton \(15\)-to-\(7\) path.
Consequently neither direction of a single alternating cross opening
from \(C\) can have a tree quotient. Put \(M=E(G)\setminus E(C)\).
In fact, for every
\(e\in E(C)\) and every \(f\in M\setminus\{p,q\}\), at least one cross
opening preserves \(e\) and avoids \(f\), yet none has a tree
quotient.

## Brace and nonplanarity certificates

The adjacency table makes simplicity, cubicity and bipartiteness
immediate. To prove 2-extendability and 3-connectivity, first let
\(U\) be a subset of either colour class with \(1\leq|U|\leq6\).
The pairs of left vertices having at least two
common neighbors are exactly
\[
02,\quad26,\quad37,\quad57;
\tag{2}
\]
the corresponding pairs on the right are exactly
\[
(8,15),\quad(12,15),\quad(11,13),\quad(11,14).
\tag{3}
\]
Each pair-overlap graph is a forest, and no two vertices in the same
bipartition class have identical neighborhoods. The argument below
applies with the two colour classes exchanged. Hence
\[
|N(U)|\geq|U|+2\qquad(1\leq|U|\leq6).
\tag{4}
\]
For \(|U|=1\), this is cubicity; for \(|U|=2\), it follows from the
absence of twins. If a three-set had at most four neighbors, its three
vertices would be pairwise adjacent in the left overlap graph, contrary
to (2). If a four-set had at most five neighbors, three right vertices
would have all their neighbors in its four-vertex complement and would
form a triangle in the right overlap graph, contrary to (3). If a
five-set had at most six neighbors, two right vertices would have the
same three neighbors in its complement. If a six-set missed a right
vertex, that degree-three vertex would have all its neighbors in a
two-vertex complement. This proves (4) in every case.

After deleting any two vertices from each colour class, (4) implies
Hall's inequalities for the remaining bipartite graph. Thus any two
disjoint edges extend to a perfect matching by first deleting their
endpoints. So \(G\) is 2-extendable. The Hamilton cycle (5) below
also shows that \(G\) is connected. To see 3-connectivity directly,
suppose deleting a set \(W\) of one or two vertices disconnects \(G\).
Every remaining vertex has a neighbor, so every component meets both
colour classes. Choose a component of at most seven vertices, and let
\(A,B\) be its left and right vertices. Then \(1\leq|A|,|B|\leq6\),
while (4) and the absence of edges to other components give
\[
|A|+2\leq |B|+|W\cap R|,
\qquad |B|+2\leq |A|+|W\cap L|.
\]
Adding yields \(4\leq|W|\leq2\), a contradiction.

There are exactly four graph-theoretic 4-cycles: each pair in (2)
shares exactly two right neighbors, and every 4-cycle arises this
way. If \(G\) were planar, 3-connectivity would make all facial
walks cycles. Euler's formula gives \(f=24-16+2=10\) faces and total
face length \(48\). Since the graph is bipartite, each face has even
length at least four. The identity
\[
\sum_F(6-|F|)=6\cdot10-48=12
\]
would force at least six facial squares, contradicting the count of
four 4-cycles. Hence \(G\) is nonplanar.

It is also non-Pfaffian. Gorsky--Steiner--Wiederrecht
(*Matching Theory and Barnette's Conjecture*,
doi:10.1016/j.disc.2022.113249, Corollary 4.9)
show that a cubic Pfaffian brace is the Heawood graph or is obtained
from cubic planar braces by repeated cubic trisums. The Heawood graph
has 14 vertices. Every cubic planar brace has at least eight vertices:
the only smaller simple cubic bipartite candidate is \(K_{3,3}\).
At eight vertices each colour class has size four, so cubicity makes
the graph \(K_{4,4}\) minus a perfect matching, namely the cube.
In a cubic trisum, the three factors share four vertices, so its
order is the sum of their
orders minus eight. If this nonplanar 16-vertex \(G\) were Pfaffian,
its last trisum would therefore use exactly three cubes. Their common
square edges are removed. Each cube contributes only its opposite
square as a 4-cycle; no 4-cycle can use a common-square vertex, since
these four vertices are independent and each exterior cube vertex
has just one neighbor among them. That trisum has exactly three
4-cycles, whereas \(G\) has four. This contradiction proves the
claim.

The cyclic list
\[
6,15,0,8,2,12,4,9,3,11,5,14,7,13,1,10,6
\tag{5}
\]
uses every vertex once, follows edges of (1), and avoids \(p,q\).
It is the required Hamilton cycle \(C\). Its complementary matching is
\[
M=\{0\,9,1\,8,2\,15,3\,13,4\,14,5\,10,6\,12,7\,11\}.
\tag{6}
\]

## A crossed-rung description

The obstruction can be located in one edge switch. Replace
\(1\,10,4\,9\) in \(G\) with \(1\,9,4\,10\), and call the result
\(G^\flat\). It is the octagonal prism \(C_8\square K_2\). Its two
rims, in corresponding cyclic orders, are
\[
\begin{aligned}
&8,2,12,4,14,7,13,1,8,\\
&0,15,6,10,5,11,3,9,0,
\end{aligned}
\]
and the eight edges joining corresponding positions are
\[
8\,0,\ 2\,15,\ 12\,6,\ 4\,10,\ 14\,5,\ 7\,11,\
13\,3,\ 1\,9.
\]
In \(G^\flat-\{p,q\}\), the list
\[
2,12,4,10,6,15,0,8,1,9,3,13,7,14,5,11
\]
is a spanning \(2\)-to-\(11\) path. Thus the switch of the two
opposite prism rungs \(4\,10\) and \(1\,9\) to \(4\,9\) and
\(1\,10\) destroys this cross path; the proof below shows that it
destroys every cross path in both directions. The site edges are
opposite prism rungs in \(G^\flat\), so this comparison does not
give a legal cofacial planar site.

## Why both cross Hamilton paths fail

Put \(R_0=G-\{p,q\}\). Partition its vertices into
\[
\begin{aligned}
A&=\{0,2,6,8,12,15\},\\
B&=\{3,5,7,11,13,14\},\\
K&=\{1,4,9,10\}.
\end{aligned}
\tag{7}
\]
The induced subgraphs on \(A,B\) are precisely the six-cycles
\[
0,8,2,12,6,15,0
\quad\text{and}\quad
3,11,5,14,7,13,3.
\tag{8}
\]
The only edges inside \(K\) are \(1\,10\) and \(4\,9\). There are
no \(A\)-to-\(B\) edges. The boundary edges to \(K\) are
\[
\begin{array}{c|cccc}
A\text{ port}&0&6&8&12\\ \hline
K\text{ port}&9&10&1&4
\end{array}
\qquad
\begin{array}{c|cccc}
B\text{ port}&3&5&13&14\\ \hline
K\text{ port}&9&10&1&4.
\end{array}
\tag{9}
\]

Suppose a Hamilton path of \(R_0\) ran from \(2\in A\) to
\(11\in B\). Let \(a,b\) be its numbers of boundary edges at
\(A,B\), and let \(t\) be its number of edges inside \(K\).
The degree sums on the two six-vertex regions make \(a,b\) odd;
there are only four boundary edges at each, so \(a,b\in\{1,3\}\).
All four vertices of \(K\) have path degree two, giving
\[
a+b+2t=8,
\qquad t\in\{0,1,2\}.
\tag{10}
\]
Hence either \(t=2\) and \(\{a,b\}=\{1,3\}\), or \(t=1\)
and \(a=b=3\).

When a region has three boundary edges in the path, its six-cycle
loses exactly two internal edges. One lost edge meets its specified
endpoint, and the other has two boundary ports as endpoints. The four
possibilities, read directly from (8)--(9), are
\[
\begin{array}{c|c|c}
\text{region and deleted cycle edges}&
\text{endpoint path reaches }K&
\text{other path pairs these }K\text{ ports}\\ \hline
A:\ 2\,8,\ 6\,12&4&1,10\\
A:\ 2\,12,\ 0\,8&1&4,9\\
B:\ 11\,3,\ 5\,14&10&4,9\\
B:\ 11\,5,\ 3\,13&9&1,10
\end{array}
\tag{11}
\]
There are no further cases because the second deleted edge must join
two of the remaining boundary ports of that six-cycle.

If \(t=2\), both internal core edges \(1\,10\) and \(4\,9\) are
used. The region with three boundary edges pairs either \(1,10\) or
\(4,9\) in (11), so that paired path closes with the corresponding
core edge into a separate cycle. If \(t=1\) and the used core edge is
\(1\,10\), the vertices \(4,9\) must use both their boundary
edges. This forces the second row for \(A\) and the third row for
\(B\), whose paired paths through \(4,9\) form a separate cycle.
If the used edge is \(4\,9\), the first and fourth rows are forced,
and their paired paths through \(1,10\) form a separate cycle.
All possibilities contradict a spanning path.

Finally, the involution
\[
(0\ 12)(8\ 6)(2\ 15)(3\ 14)(11\ 7)(5\ 13)(9\ 4)(1\ 10)
\tag{12}
\]
preserves the adjacency table and the set \(\{p,q\}\). It maps a
\(2\)-to-\(11\) Hamilton path in \(R_0\) to a
\(15\)-to-\(7\) one. Therefore neither cross path exists.

## A concrete marked opening still exists

Take \(e=1\,13\in C\) and \(f=0\,9\in M\). The old path
\[
P=15,6,12,4,14,7
\tag{13}
\]
alternates \(C,M,C,M,C\), avoids \(e,f,p,q\), and runs from
\(u\) to \(y\). Closing it through the abstract new square gives a
simple alternating cross opening containing \(e\) and avoiding
\(f\) in its complementary 2-factor. That 2-factor has the residual
six-cycle
\[
4,9,3,11,5,14,4.
\tag{14}
\]
Indeed, the old main component is the path
\(7,13,1,10,6,12,2,8,0,15\); the square joins its endpoints.

Since neither cross Hamilton path exists, every cross opening from
the state-\(00\) cycle (5), marked or otherwise, has a disconnected
complement and a non-tree quotient. Moreover, the matching proof of
the marked-opening theorem in Note 174 does not use planarity. Applied
to this brace and its fixed \(C,M,p,q\), it supplies at least one
opening for every \(e\in E(C)\) and
\(f\in M\setminus\{p,q\}\). Thus the failure of tree selection holds
uniformly over all these marks. The planar brace case remains open.
