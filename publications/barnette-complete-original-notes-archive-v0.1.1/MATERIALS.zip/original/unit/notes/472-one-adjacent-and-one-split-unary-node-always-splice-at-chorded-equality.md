> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One adjacent and one split unary node always splice at chorded equality

[Note 471](471-two-adjacent-unary-pairs-always-splice-at-chorded-equality.md) closes the chorded \(c=5f-7\) equality profile when both marked unary nodes have adjacent directly assigned pairs. Here one node is split across its child and the other is adjacent. An ordinary wrapper square replaces the adjacent node's deleted direct-pair edge in every nesting arrangement.

Retain the one-root chorded order, four terminals \(T=\{r_L,u,v,r_R\}\) with \(r_L<u<v<r_R\), and two exterior pairings of [Note 460](460-two-exterior-pairings-close-the-chorded-single-unary-defect.md). Assume the remaining equality profile of [Note 470](470-one-four-special-leaf-always-supplies-the-chorded-four-port-cover.md): two marked unary nodes each directly assigned two special positions, every other assigned position in a two-special leaf, and equality \(c=5f-7\) in the charge. Let the split node \(N_s\) have order
\[
                               H_s,s,A,t,J_s ,
\tag{1}
\]
where \(A\) is its sole child word with first and last vertices \(L,R\). Let the other node \(N_a\) have an adjacent direct pair \(d=xy\). Ordinary intervals are laminar, so \(N_a\) is either disjoint from \(N_s\), contained in its child \(A\), or an ancestor of \(N_s\).

**Mixed-node theorem.** The parent has a Hamilton cycle through both site edges and its legal expanded child is Hamiltonian, whether the two nodes are disjoint or nested. Consequently, a non-Hamiltonian chorded child at this equality boundary must have both marked unary nodes split across their respective child words.

**Wrapper substitution.** At equality, [Notes 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md) and [469](469-the-end-root-chorded-splice-and-unified-12f-plus-2-kernel.md) give every marked nonleaf node two consecutive plain-unary ancestors.

If \(N_a\) is disjoint from \(N_s\) or lies inside \(A\), write the core chord of \(N_a\) as \(hj\) and its immediate plain-unary parent chord as \(H_aJ_a\), where \(H_a,h\) and \(j,J_a\) are consecutive ordinary vertices. This parent chord is not the root chord. Neither opening at \(N_s\) cuts the local old arc inside \(N_a\), so after restoring the leaf edges the rail edges \(H_ah,jJ_a\) lie in the components containing the two respective endpoints of \(d\). Both chords \(H_aJ_a,hj\) are unused: the chord inserted at \(N_s\) is either \(LR\) or \(H_sJ_s\), and the two plain ancestors of \(N_a\) keep \(H_aJ_a\) distinct from \(LR\) even when \(N_a\subset A\). Thus the square switch
\[
                           H_ah,\ jJ_a
                    \quad\longmapsto\quad H_aJ_a,\ hj
\tag{2}
\]
joins the two component classes that restoring \(d\) would join, whenever they differ.

If \(N_a\) is an ancestor of \(N_s\), let the two consecutive plain-unary ancestors of \(N_s\) have chords \(h_1j_1\) and \(h_2j_2\), with \(h_2<h_1<H_s<J_s<j_1<j_2\). They lie inside the child of \(N_a\), so neither chord is the root chord or either inserted chord \(LR,H_sJ_s\). Their old rail edges \(h_2h_1,j_1j_2\) are untouched by leaf switches. In each of the two openings below, the old complementary arc outside the split core of \(N_s\) contains \(d\). Its two rail edges lie on opposite sides of \(d\): the adjacent direct pair of the ancestor \(N_a\) is wholly before or wholly after its child containing \(N_s\). After leaf edges are restored, one rail edge is connected by an intact old subarc to each endpoint of \(d\). Hence the square switch
\[
                           h_2h_1,\ j_1j_2
                      \quad\longmapsto\quad h_2j_2,\ h_1j_1
\tag{2a}
\]
again joins the two component classes that restoring \(d\) would join.

All selected square supports are disjoint from leaf-square supports. In a component quotient, the leaf-square switches together with (2) or (2a) therefore have the same connectivity effect as restoring all deleted leaf edges and \(d\). Switches along a forest rooted at the two terminal paths absorb every cycle whenever this restored graph is connected. The same argument works separately inside two disconnected restored pieces, one containing each terminal path.

**Proof of the theorem.** Let \(C_W\) be the old root cycle, \(E\) the square-supported old edge in each two-special leaf, and \(M\) the face matching of all root special positions other than \(T\). Open the split node at its inner boundaries:
\[
              F_{\rm in}
                  =(C_W-E-\{d,sL,Rt\})\cup M\cup\{LR\}.
\tag{3}
\]
It has degree one precisely at \(T\). Restoring \(E,d\) leaves the two old arcs \(A\) and \(W\setminus A\), with \(LR\) internal to \(A\). If some \(M\)-edge crosses between these arcs, the restored graph is connected, and wrapper substitution gives a spanning two-path cover.

Suppose no \(M\)-edge crosses. The even ordinary child interval \(A\) has cut size \(2+k\) in the cubic parent, where \(k=|T\cap A|\): its only other possible external edges are the \(k\) terminal attachments, since its ordinary matching edges and all nonterminal face matching edges are internal. Three-connectivity and cut parity give \(k=2\) or \(4\). For \(k=2\), each restored arc has one terminal path and perhaps cycles. The leaf switches and wrapper substitution, applied within the arc containing \(N_a\), absorb its cycles into that path; the other arc uses its leaf switches. This gives a spanning two-path cover.

For \(k=4\), the directly assigned positions \(s,t\) are nonterminals outside \(A\). They cannot be matched to each other, because \(s<r_L<t\) makes \(st\) cross the exterior face chord \(z_Lr_L\), exactly as in Note 460. Their matching mates cannot lie in \(A\) by assumption and cannot lie elsewhere in \(N_s\setminus A\), which contains no other directly assigned special positions. Thus an \(M\)-edge from \(s\) or \(t\) leaves the whole \(N_s\) interval. In particular \(N_s\) is not the root, and its chord \(H_sJ_s\) is unused by \(C_W\). Use the outer opening
\[
              F_{\rm out}
                 =(C_W-E-\{d,H_ss,tJ_s\})\cup M\cup\{H_sJ_s\}.
\tag{4}
\]
Restoring \(E,d\) now leaves two old arcs joined by the identified \(M\)-edge, so the restored graph is connected. Wrapper substitution again yields a spanning internal two-path cover. One of the two exterior pairings of Note 460 closes any such cover to a parent Hamilton cycle containing both site edges; [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the child. \(\square\)

The theorem leaves only the two-split-node profile at chorded equality. It is a structural closure for the selected single-hexagon opening, not a general Barnette proof.
