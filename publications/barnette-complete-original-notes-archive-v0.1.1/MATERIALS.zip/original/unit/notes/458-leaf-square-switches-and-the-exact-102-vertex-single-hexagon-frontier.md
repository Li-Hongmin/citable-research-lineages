> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Leaf-square switches and the exact 102-vertex single-hexagon frontier

[Note 454](454-one-missing-leaf-switch-gives-two-four-port-pairings.md) uses the two ordinary chords of a full leaf to switch components without restoring its deleted old-cycle edge. For Hamilton paths and cycles, that restriction is unnecessary: the innermost ordinary chord and the deleted edge are the opposite edges of a square. This gives a switch at every two-special leaf, regardless of how many ordinary wrappers surround it.

## Square-switch splicing

Let \(D\) be a spanning disjoint union of cycles in a graph \(H\). Choose pairwise vertex-disjoint edges
\[
                         E=\{e_i=x_i y_i:i\in I\}\subseteq E(D).
\]
For each \(i\), suppose four distinct vertices occur consecutively on its \(D\)-cycle in the order \(h_i,x_i,y_i,j_i\), the four-vertex sets are pairwise disjoint, and \(h_i j_i\in E(H)\). Choose \(T\subseteq\{x_i,y_i:i\in I\}\) with \(|T|\in\{0,2,4\}\), and let \(M\) be a matching of all remaining \(e_i\)-endpoints, with \(M\cap E(D)=\varnothing\). Assume \(D\cup M\) is connected.

**Square-switch splicing theorem.** The graph \(D\cup M\cup\{h_i j_i:i\in I\}\) has:

1. a Hamilton cycle containing \(M\), when \(|T|=0\);
2. a spanning path with endpoints \(T\) and containing \(M\), when \(|T|=2\);
3. spanning two-path covers containing \(M\), with endpoints \(T\), in at least two distinct terminal pairings, when \(|T|=4\).

No planarity, bipartiteness, or bound on \(|I|\) is needed.

**Proof.** Put \(F_0=(D-E)\cup M\). Its nonterminal vertices have degree two and its terminals have degree one. Thus it consists of cycles and, respectively, zero, one, or two paths. Contract its components and draw one edge for each \(e_i\), allowing loops; call the resulting multigraph \(Q\). Since \(F_0\cup E=D\cup M\), \(Q\) is connected. Moreover each \(Q\)-vertex has even degree: in the corresponding component of \(F_0\), the number of endpoints of \(E\) is twice the number of its \(M\)-edges plus its number of terminals, and the latter is zero or two.

If \(e_i\) is a nonloop of \(Q\), its endpoints \(x_i,y_i\) are in different \(F_0\)-components. The edges \(h_i x_i\) and \(y_i j_i\) are then in those two components. Replace them by
\[
                   h_i x_i,\ y_i j_i
                   \quad\longmapsto\quad
                   h_i j_i,\ x_i y_i.                  \tag{1}
\]
The replacement preserves every degree. It joins two cycles into one cycle, or one path and one cycle into a path with the same terminals. If it joins two paths, it leaves two paths and changes their terminal pairing. Switches at different \(i\) have disjoint four-vertex supports. If \(h_i j_i\) is already an edge of \(D\), the consecutiveness assumption makes \(h_i x_i y_i j_i h_i\) an entire \(D\)-cycle; then \(x_i,y_i\) are connected in \(F_0\), so \(e_i\) is a loop and (1) is not needed.

For zero terminals, switch along a spanning tree of \(Q\), absorbing each new cycle into the growing cycle. For two terminals, root such a tree at the unique path component and absorb every cycle into that path. For four terminals, choose a spanning tree and an edge \(e_*\) on its path between the two path components. Delete \(e_*\) from the tree and absorb all cycle components separately into the two rooted paths. This gives one spanning two-path cover. The unused nonloop edge \(e_*\) admits (1), producing another spanning two-path cover with a different pairing. Every switch leaves \(M\) untouched. \(\square\)

**Open-arc variant.** Let \(P\) be a spanning path with endpoints \(L,R\), with the same disjoint square-supported edges \(e_i\) in its interior. Match all but two of their endpoints by \(M\), leaving \(u,v\). Then \((P-E)\cup M\) consists of two paths with terminals \(L,R,u,v\) and some cycles. Its component quotient by the \(e_i\) is connected because \(P\cup M\) is connected. The spanning-tree argument above, including the final switch between the two paths, gives spanning two-path covers in at least two pairings of \(L,R,u,v\). The inner chord \(h_i j_i\) is never used by \(P\), so every nonloop tree edge is switchable. This variant needs no parity assertion for the quotient.

## Two consequences for hexagon openings

First, the two-pairing and two-terminal assertions of Note 454 hold when **every** marked leaf has only its innermost ordinary chord; no full-leaf or one-short-leaf assumption is needed. In an ordinary leaf, \(h_i,x_i,y_i,j_i\) are consecutive and \(h_i j_i\) is exactly that innermost chord. A singleton root whose closing cycle uses this chord has \(e_i\) as a loop of \(Q\), as covered by the theorem.

Second, the uniform three-root statement of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md) remains true with **arbitrarily many short ordinary wrappers**. Its cycles \(C_1,C_2,C_3\) and the face matching \(M\) satisfy the two-terminal square-switch theorem whenever the root face graph \(K\) is connected. If \(K\) is disconnected, Note 456's cubic-cut and planarity argument puts both inner site ports in one isolated end root. Apply the two-terminal theorem to that root's old arc plus its root chord; the unchanged exterior path (4) or (5) of Note 456 closes the resulting path through both site edges. Hence any chord-free single-hexagon parent in the three-root order of Note 456, with all assignable special positions occurring two per leaf, has a Hamilton cycle containing both site edges, independently of its ordinary wrapper lengths.

There is a parallel chorded consequence. In a chorded single-hexagon opening with \(m=f\), one ordinary root, and two assignable positions outside it, the parity and adjacent-escape argument in [Note 457](457-single-hexagon-failures-have-at-most-six-plus-twelve-f-vertices.md) forces its nontrivial exterior order to be \(w_0,z_L,t_c,W,t_b,z_R,w_*\). If all \(2f\) assigned positions in \(W\) occur two per leaf, the two fixed exterior paths (4) of Note 457 end at four distinct leaf specials. The four-terminal square-switch theorem supplies two internal pairings; one closes those exterior paths to a Hamilton cycle containing both site edges. This conclusion does not require a lower bound on the ordinary-chord count.

## The two-root escape splice

There is a second all-leaf closure at every \(f\). Consider a chord-free single-hexagon opening with \(m=f\), two ordinary roots \(W_1,W_2\), and every assigned special position occurring two per leaf. Exactly two assignable positions \(z_1,z_2\) lie outside the roots. **Its legal child is Hamiltonian.**

It suffices to rule out a non-Hamiltonian child. Adjacent escape targets would merge the selected two-cycle opening, so no two can be adjacent. Four ordered targets \(t_d,t_c,t_b,t_a\) occupy the three gaps around \(W_1,W_2\). Two targets in one gap need at least two outside special positions between them: zero gives the adjacent merger, while one gives equal old-cycle colours to targets whose adjacent hexagon neighbours have opposite colours. Hence exactly one gap contains two targets, with \(z_1,z_2\) consecutive between them; the other gaps contain one target each. Up to the location of the doubled gap, the old-cycle order is
\[
\begin{array}{ll}
\mathrm A:& w_0,t_d,z_1,z_2,t_c,W_1,t_b,W_2,t_a,w_*,\\
\mathrm B:& w_0,t_d,W_1,t_c,z_1,z_2,t_b,W_2,t_a,w_*,\\
\mathrm C:& w_0,t_d,W_1,t_c,W_2,t_b,z_1,z_2,t_a,w_* .
\end{array}                                                   \tag{2}
\]
The remaining old-cycle arc is always \(w_*,\alpha,a,b,c,d,\beta,w_0\).

The inner site port \(u\) has odd old-cycle index from \(w_0\), while \(v\) has even index. In A, only \(z_2\) could be a site port, necessarily \(u\), but then the face chord from \(z_1\) to either root crosses \(q=w_0z_2\). In C, only \(z_1\) could be a site port, necessarily \(v\), but the face chord from \(z_2\) to either root crosses \(p=z_1w_*\). Thus both \(z_i\) are face-chord endpoints in A and C.

In B, the only possible outside site assignments are \(z_1=u\), \(z_2=v\), or both. If both occur, \(u,v\) are adjacent and the one-edge facial-gap switch of [Note 174](174-brace-cross-openings-avoid-a-forbidden-matching-edge.md) gives a Hamiltonian child. If \(z_1=u\) alone, the face chord at \(z_2\) must end at some \(r\in W_2\), since an endpoint in \(W_1\) would cross \(q\); also \(v\in W_2\). Three-connectivity then forces a face chord between the roots, because \(W_1\) otherwise has only its two old-cycle boundary edges. Define the two disjoint cycles
\[
\begin{aligned}
D_1&=(W_{1,\ell}\xrightarrow{\rm old}W_{1,r},t_c,c,d,t_d,W_{1,\ell}),\\
D_2&=(W_{2,\ell}\xrightarrow{\rm old}W_{2,r},t_a,a,b,t_b,W_{2,\ell}).
\end{aligned}                                                    \tag{3}
\]
The root face matching connects them, so the two-terminal square-switch theorem gives a spanning \(v\)--\(r\) path on \(D_1\cup D_2\). Close it with
\[
                    (v,w_*,\alpha,\beta,w_0,z_1,z_2,r),
\]
which contains both site edges. If \(z_2=v\) alone, the face chord at \(z_1\) ends at \(r\in W_1\), the site port \(u\) is in \(W_1\), and the same cut argument connects the roots. The spanning \(u\)--\(r\) path on (3) closes with
\[
                    (u,w_0,\beta,\alpha,w_*,z_2,z_1,r).
\]

Now suppose both \(z_i\) are face-chord endpoints, with mates \(r_i\) in the roots. Let \(K\) be the graph on \(W_1,W_2\) defined by face chords between them. If \(K\) is connected, use the cycles (3) for B. For A or C, give the root lying between \(t_c,t_b\) the cycle
\[
        (W_\ell\xrightarrow{\rm old}W_r,t_b,b,c,t_c,W_\ell)
\]
and close the other root's old arc with its root chord. These two cycles together with the internal face matching are connected. The four-terminal square-switch theorem provides two spanning internal pairings on \(u,v,r_1,r_2\). The two fixed exterior paths are
\[
\begin{array}{ll}
\mathrm A,\mathrm C:&(u,w_0,t_d,d,\beta,\alpha,a,t_a,w_*,v),
                    \quad(r_1,z_1,z_2,r_2),\\
\mathrm B:&(u,w_0,\beta,\alpha,w_*,v),
                    \quad(r_1,z_1,z_2,r_2).
\end{array}                                                     \tag{4}
\]
They cover every vertex outside the two cycles. One of the two internal pairings differs from the exterior pairing and therefore closes to a Hamilton cycle through \(p,q\).

Finally suppose \(K\) is disconnected. The cut of each even root word consists of its two old-cycle boundary edges and its site or exterior face-chord attachments. Cubicity makes its size even, while three-connectivity makes it at least four. Since there are four such special attachments in total, each root has exactly two. Its old arc and internal face matching therefore satisfy the open-arc variant, giving at least two spanning pairings of its left and right boundary ends and its two special attachments.

The following four mutually disjoint exterior paths cover every vertex outside the roots. In each row, the first three paths join \(u\) to \(W_{1,\ell}\), \(v\) to \(W_{2,r}\), and \(W_{1,r}\) to \(W_{2,\ell}\), respectively; the fourth is always \((r_1,z_1,z_2,r_2)\):
\[
\begin{array}{ll}
\mathrm A:&(u,w_0,t_d,d,\beta,\alpha,a,b,c,t_c,W_{1,\ell}),\
           (v,w_*,t_a,W_{2,r}),\
           (W_{1,r},t_b,W_{2,\ell}),\\
\mathrm B:&(u,w_0,\beta,d,t_d,W_{1,\ell}),\
           (v,w_*,\alpha,a,t_a,W_{2,r}),\
           (W_{1,r},t_c,c,b,t_b,W_{2,\ell}),\\
\mathrm C:&(u,w_0,t_d,W_{1,\ell}),\
           (v,w_*,t_a,a,\alpha,\beta,d,c,b,t_b,W_{2,r}),\
           (W_{1,r},t_c,W_{2,\ell}).
\end{array}                                                     \tag{5}
\]
Their endpoint pairing has at least one edge between roots, namely \(W_{1,r}W_{2,\ell}\) after contracting that exterior path. Since each root has four endpoints, the number of between-root paths is two or four. If it is two, each root has one exterior pairing of its other two terminals; choose an available internal pairing different from that one at each root. The two between-root paths then close one cycle. If it is four, the exterior paths identify the four terminals of one root with the four of the other. Choose internal pairings that differ under this identification; two available pairings at each root guarantee such a choice, and their union is an eight-port cycle. In either case (5) and the two root covers yield a parent Hamilton cycle containing \(p,q\), proving the two-root claim. \(\square\)

Consequently, a non-Hamiltonian doubly reduced chord-free opening with \(m=f,R=2\) has at least one assigned special position outside a two-special leaf. Then \(M_0+L\le2f-1\), and the refined charge of [Note 415](415-escape-confinement-shaves-six-vertices-from-the-single-hexagon-kernel.md) gives \(c\le2(2f-1)+f-6=5f-8\). At \(f=8\), this branch has at most 98 reduced child vertices.

## Necessary shape at the 102-vertex boundary

At \(f=8\), [Note 457](457-single-hexagon-failures-have-at-most-six-plus-twelve-f-vertices.md) bounds a doubly reduced non-Hamiltonian child by 102 vertices. If equality holds, the following are the only remaining charging profiles.

* **Chorded hexagon, \(e=2\):** \(c=35,m=8,R=1\). Its root has seven leaves, each assigned exactly two special positions, and one further marked unary node assigned the remaining two. The ordinary forest is full binary apart from unary wrappers, and every permitted wrapper chain attains its charge bound.
* **Chord-free hexagon, \(e=4\), three roots:** \(c=34,m=9,R=3\). The forest has eight two-special leaves and one further marked unary node assigned the remaining two special positions. Its branching and wrapper charges are saturated.

**Proof.** In the chorded case, \(c=35\) and the charge \(c\le5m-3R\) force \(m=8,R=1\). The all-leaf case is Hamiltonian by the preceding chorded consequence. Otherwise \(M_0+L\le15\), while
\[
                 35=c\le2(M_0+L)+8-3
\]
forces \(M_0+L=15\), hence \(M_0=8,L=7\). Each marked node receives exactly two special positions. Equality in the finer charge \(c\le3A-Q\), with \(Q=L=7\), forces \(A=14=M_0+L-R\). Thus there are \(L-R=6\) binary branches and the one nonleaf marked node is unary, not a branch; every plain-unary chain reaches its allowed length.

In the chord-free case, \(c=34\). The escape restrictions of Note 457 exclude \(m=9,R\le2\) and \(m=8,R=1\). The charge excludes \(m\le7\), \(m=9,R\ge4\), and \(m=8,R\ge3\). If \(m=8,R=2\), equality in \(c\le5m-3R=34\) forces \(M_0=L=8\), so all assigned positions occur two per leaf; the two-root escape splice above makes the child Hamiltonian. Thus \(m=9,R=3\). Its all-leaf case is Hamiltonian by the strengthened three-root theorem. Otherwise \(M_0+L\le17\); equality at \(c=34\) forces \(M_0=9,L=8,Q=8,A=14\), yielding exactly one marked unary node and five binary branches, with saturated wrapper chains. \(\square\)

Thus **every 102-vertex hypothetical failure kernel has one marked unary node outside its two-special leaves**. This is a structural necessary condition, not a 102-vertex counterexample or a proof of Barnette's conjecture. The square-switch theorem does not by itself route the two special positions assigned to that unary node.
