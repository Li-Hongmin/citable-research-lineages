> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Multiple opposite-face chords need six extra free vertices

The free-vertex cost theorem of
[Note 187](187-opposite-face-chords-require-two-free-main-vertices-each.md)
gives \(f\ge2r+4\) when an all-square facial opening has
\(r\ge1\) matching edges on its other site-face arc.
For \(r\ge2\), equality would separate the main segment
across a target gap or force an invalid first face chord.

Use the one-square-per-lobe notation of Notes 176--179.
The old main Hamilton-cycle segment \(S_0\) runs from
\(x\) to \(v\), the site ports satisfy \(x<y<u<v\), and
the \(\ell\ge1\) escape-target pairs appear as
\(R_\ell,L_\ell,\ldots,R_1,L_1\), with odd-index \(R_i\)
and even-index \(L_i\). The parent and the chosen site
expansion are Barnette graphs, the parent Hamilton cycle
avoids both site edges, and every trapped component of the
chosen facial opening is a square. Put
\[
f=|V(S_0)|-2\ell-4.
\tag{1}
\]

**Improved chord-cost theorem.** If the other site-face arc
from \(y\) to \(u\) contains \(r\ge2\) edges of the
complementary perfect matching, then
\[
f\ge2r+6,
\qquad\text{equivalently}\qquad
|V(S_0)|\ge2\ell+2r+10.
\tag{2}
\]
In particular, an opening with exactly eight free main
vertices has at most one matching edge on that arc. This
holds for arbitrary original lobe lengths and does not
assume that the opposite arc alternates.

**Proof.** By Note 187, \(f\ge2r+4\). Since \(f\) is even,
it suffices to exclude equality. Suppose \(f=2r+4\).
Note 187 shows that the site ports lie in *distinct*
escape-pair gaps \(Y=(R_i,L_i)\) and \(U=(R_j,L_j)\),
with \(Y\) preceding \(U\). The \(r\) selected face-arc
matching edges use \(2r\) free vertices strictly between
\(y,u\). Parity gives a free vertex \(s\in Y\) before
\(y\) and \(t\in U\) after \(u\). Exactly two other free
vertices remain; hence precisely two internal matching
chords are outside the selected face arc.

The vertices \(s,t\) cannot be matched to each other:
the chord would interlace \(q=xy\), so lie opposite the
common face, and would cross an escape chord from a target
between the distinct gaps \(Y,U\). Write their matching
edges as \(sh,tk\). We claim \(h\in Y\) and \(k\in U\).
If \(h\) lies in a different gap to the right of \(Y\),
then \(sh\) interlaces \(q\) and encloses an escape target
on the opposite side of \(C\), so it crosses the target's
escape chord. If \(h\) lies in a gap to the left of \(Y\),
even gap parity requires another free vertex there. The
only candidate is \(k\), but \(tk\) would interlace
\(p=uv\) and cross an intervening escape chord. Hence
\(h\in Y\); reversing the argument gives \(k\in U\).
Both non-face-arc matching chords are therefore confined
to the two port gaps.

The \(r\) face-arc matching chords have disjoint,
successive endpoint intervals along \(C\). Indeed, the
facial boundary-order lemma of Note 176 puts their
endpoints in their traversal order within \((y,u)\):
for successive chords \(a_ib_i,a_{i+1}b_{i+1}\),
\(a_i<b_i<a_{i+1}<b_{i+1}\).
Thus at most one face chord crosses any given main
\(C\)-edge. Suppose a nonpair target gap strictly
between \(Y,U\) contained a free vertex. It contains
an even positive number, so the edge between its first
two free vertices starts at an odd \(S_0\)-index and
is not straddled by an escape pair. No non-face-arc
chord crosses that edge and at most one face chord does.
This contradicts Note 179's even-cut bridge lemma.
Consequently every intervening nonpair gap is empty.

All \(2r\) face-chord endpoints lie in \(Y,U\) or
intermediate *pair* gaps. Let \(k_Y,k_U\) be their counts
in \(Y,U\). Each is odd and positive: each gap has one
site port and the two endpoints of one non-face-arc chord,
while its total number of non-target vertices is even.
Suppose \(k_Y\ge3\). Only \(s,h\) among the free vertices
of \(Y\) are not face-chord endpoints, and every face
endpoint in \(Y\) follows \(y\). The number of free
vertices between \(R_i\) and \(y\) is odd and positive,
so it is exactly one, namely \(s\); \(h\) follows \(y\).
The \(k_Y+1\) free vertices after \(y\) are consecutive
on \(C\), starting at an even index. Since \(s\) also
has even index, its mate \(h\) has odd index. If \(h\)
is the second vertex after \(y\), the first two face
endpoints are the first and third, both even-indexed.
Otherwise they are the first and second, adjacent on
\(C\). In either case they cannot form the first matching
chord of the face arc. Thus \(k_Y=1\). Reversing the main
segment and exchanging the two site edges gives
\(k_U=1\).

Because \(r\ge2\), at least two face-chord endpoints
remain in intermediate pair gaps. Let the first such gap
contain any endpoints. It has no site port or non-face
free vertex, so it contains an even positive number of
consecutive face endpoints. Its first vertex follows an
odd-index \(R_i\) and has even index. The unique face
endpoint in \(Y\) is likewise the first free vertex
after \(y\), hence has even index. These are the first
two face endpoints of the whole \(y\)-to-\(u\) arc;
the first matching chord would join same-colour vertices.
This final contradiction excludes equality and proves
(2). Note 178's lobe compression leaves \(S_0\) and
the opposite face arc unchanged. \(\square\)

The \(r=1\) lower bound remains \(f\ge6\) and is sharp
by Notes 182--184. For \(r\ge2\), (2) is a necessary
condition only; it does not establish Hamiltonicity at
the next main-segment size or resolve Barnette's conjecture.
