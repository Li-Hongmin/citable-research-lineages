> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A legal-wide plane interface has nonnormalized minimum two-switches

[Note 091](091-defect-normalization-fails-before-the-labelled-inverse-square-interface.md)
constructs a complete residual fibre in which every globally minimum
cross-sector pair has two proper defects of type \((\pi_0,1)\), but none of
its labelled inverse-square attachments is simultaneously planar and
bipartite.  This leaves open the possibility that legal square realizability
itself forces the asymmetric normalization proposed in
[Note 089](089-two-extendability-reaches-the-square-fixed-slice-but-not-the-linkage-fibre.md).

It does not.  Two directed terminal repairs turn the residual countermodel
into a genuine legal-wide plane cubic bipartite interface.  Its complete
fixed-pairing fibre has global cross-sector minimum two.  Among the 48
minimum pairs, 32 have the proposed defect multiset
\(\{(\pi_1,0),(\pi_0,1)\}\), while 16 have
\(\{(\pi_0,1),(\pi_0,1)\}\).

Thus normalization is false for an arbitrary chosen minimum pair even after
the full labelled plane interface is imposed.  The example is not a brace:
its vertex-connectivity is two.  It therefore shifts the remaining positive
question to a genuine 3-connectivity or brace-level selection theorem.

## 1. Two terminal repairs

Let \(R_{91}\) be the 20-vertex residual graph of Note 091, with terminals
\(p_0,p_3,q_0,q_7\).  First add the three-edge ear

\[
q_0q_{0z},\qquad q_{0z}q_{7z},\qquad q_{7z}q_7,
\tag{1}
\]

so that \(q_{0z},q_{7z}\) replace \(q_0,q_7\) as terminals.  Second take a
new copy \(W\) of the plane two-pole \(Q_3-WA_0WB_0\), attach it by
\(p_0WA_0\), and leave \(WB_0\) as the new terminal.  Denote the resulting
graph by \(R^*\).

The pole edges are

\[
\begin{aligned}
&WA_0WB_1,WA_0WB_2,\\
&WA_1WB_0,WA_1WB_1,WA_1WB_3,\\
&WA_2WB_0,WA_2WB_2,WA_2WB_3,\\
&WA_3WB_1,WA_3WB_2,WA_3WB_3.
\end{aligned}
\tag{2}
\]

Then \(R^*\) is simple, connected, planar and bipartite, has 30 vertices
and 43 edges, and its only degree-two vertices are

\[
T=\{WB_0,p_3,q_{0z},q_{7z}\}.
\tag{3}
\]

Every other vertex has degree three.  Fix

\[
\pi_0=\{WB_0p_3,q_{0z}q_{7z}\},
\qquad g_1=p_0p_1.
\tag{4}
\]

## 2. The complete fibre

The graph \(R^*\) has 450 perfect matchings.  Let \(\mathcal L\) be the
complete family of matchings whose complements are exactly two spanning
paths with endpoint pairing \(\pi_0\), and split it by membership of
\(g_1\).  Direct enumeration gives

\[
|\mathcal L|=64,
\qquad |\mathcal L^1|=16,
\qquad |\mathcal L^0|=48.
\tag{5}
\]

Across all \(16\cdot48=768\) cross-sector pairs, the number of alternating
components in the symmetric difference has distribution

\[
2^{48},\qquad3^{240},\qquad4^{348},\qquad5^{120},\qquad6^{12}.
\tag{6}
\]

Hence the global minimum is exactly two.  Classifying the two proper toggles
for all 48 minimum pairs gives

\[
\begin{array}{c|r}
\text{defect multiset}&\text{minimum pairs}\\ \hline
\{(\pi_1,0),(\pi_0,1)\}&32\\
\{(\pi_0,1),(\pi_0,1)\}&16.
\end{array}
\tag{7}
\]

In particular, normalized and nonnormalized global minima coexist inside
one complete fibre.

For a literal exceptional pair, put

\[
\begin{aligned}
K={}&\{LA_0LB_1,LA_1LB_0,LA_2LB_2,LA_3LB_3,\\
&\phantom{\{}WA_0WB_1,WA_1WB_0,WA_2WB_2,WA_3WB_3,q_{0z}q_{7z}\},
\end{aligned}
\tag{8}
\]

and define

\[
\begin{aligned}
M={}&K\cup\{p_0p_1,p_2p_3,q_0q_1,q_2q_3,q_4q_5,q_6q_7\},\\
N={}&K\cup\{p_0p_3,p_1q_0,p_2q_5,q_1q_4,q_2q_7,q_3q_6\}.
\end{aligned}
\tag{9}
\]

Then \(M\in\mathcal L^1\), \(N\in\mathcal L^0\), and

\[
M\triangle N=C_8\mathbin{\dot\cup}C_4,
\tag{10}
\]

where

\[
\begin{aligned}
C_8={}&(p_0,p_1,q_0,q_1,q_4,q_5,p_2,p_3,p_0),\\
C_4={}&(q_2,q_3,q_6,q_7,q_2).
\end{aligned}
\tag{11}
\]

Both proper toggles preserve \(\pi_0\) and create one closed complement
cycle:

\[
(\pi(M\triangle C_8),c(M\triangle C_8))
=(\pi_0,1)
=(\pi(M\triangle C_4),c(M\triangle C_4)).
\tag{12}
\]

## 3. A genuine legal-wide square extension

Attach a square \(Q=u-v-x-y-u\) in the terminal order

\[
(u,v,x,y)=(WB_0,q_{0z},q_{7z},p_3).
\tag{13}
\]

Thus the attachment edges are

\[
WB_0u,\qquad q_{0z}v,\qquad q_{7z}x,\qquad p_3y.
\tag{14}
\]

Take

\[
e=xy,qquad g_0=uv,qquad g_1=p_0p_1.
\tag{15}
\]

The resulting graph \(G\) is simple, connected, planar, cubic and
bipartite, with 34 vertices and 51 edges.  The square \(Q\) is facial.  The
forced gate \(g_0\) and surviving gate \(g_1\) share the face

\[
WA_0,WB_2,WA_2,WB_0,u,v,q_{0z},q_0,p_1,p_0.
\tag{16}
\]

The two residual gate-to-gate paths have odd lengths three and five;
equivalently the two closed gate arcs have sizes five and seven.  The root
edge \(e\) is not on this face.  Hence this is a legal-wide labelled
interface in the project convention.

All eight assignments of the two target pairs to the ordered square
channels, with both orientations, split as

\[
4\text{ plane and bipartite},
\qquad4\text{ nonplanar and nonbipartite}.
\tag{17}
\]

Each of the four plane bipartite assignments supplies a legal-wide
labelling.  The displayed choice is fixed only to make the certificate
literal.

The graph has

\[
\kappa(G)=2,
\tag{18}
\]

so it is not a brace.  No order-minimality is asserted.

## 4. Exact boundary

**Counterexample.**  A simple connected plane cubic bipartite legal-wide
interface can have a globally minimum cross-sector pair with defect multiset

\[
\{(\pi_0,1),(\pi_0,1)\}.
\tag{19}
\]

Thus labelled inverse-square planarity, bipartiteness, cubic incidence,
wide facial placement and complete-fibre global minimality do not normalize
an arbitrary chosen pair.

**Surviving selection problem.**  This example still has 32 normalized
minimum pairs.  It therefore does not refute the weaker statement

\[
\min d(\mathcal L^1,\mathcal L^0)=2
\Longrightarrow
\exists\text{ a normalized minimum pair}.
\tag{20}
\]

That existential selection statement is the sharp form needed before a
separator argument can begin.

**Remaining class boundary.**  The first missing named Barnette hypothesis
is the brace condition, while the example itself isolates the thinner
failure \(\kappa=2\).  It remains unknown whether 3-connectivity alone
forces (20), whether full bipartite 2-extendability is required, or whether
even a plane brace can have a nonnormalized minimum pair.  Any positive
argument must use global class structure to select a favourable minimum,
not infer its profile from one atomic overlay.

The complete fibre, all eight labelled attachments and the explicit
minimum witness are frozen in the
[verification bundle](../computations/bundles/legal-wide-defect-counterexample/README.md).

