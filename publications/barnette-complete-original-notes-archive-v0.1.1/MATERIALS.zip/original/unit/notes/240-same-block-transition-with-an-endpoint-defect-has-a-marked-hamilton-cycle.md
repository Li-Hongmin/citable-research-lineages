> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A same-block transition with an endpoint defect has a marked Hamilton cycle

[Note 239](239-endpoint-and-transition-target-defects-compose-at-second-surplus.md)
handles an endpoint defect and a transition defect
whose two targets lie in different blocks. The
same-block transition has a different matching
profile. It can coexist with the endpoint defect
only in the endpoint site block, where its two
internal free chords are forced. A modified
same-square sweep absorbs them.

Use a compressed all-square Barnette opening
with \(\ell,r\ge1\), empty interblock gaps,
and \(s=2\), so \(f=4r+6\).

**Same-block endpoint--transition theorem.**
Suppose
\[
d_L+b+d_R=2,\qquad b=1,\qquad d_L+d_R=1,
\tag{1}
\]
and the two targets \(L_j,R_{j-1}\) of the
defective transition lie in the same block.
Then the parent has a Hamilton cycle containing
both site edges \(xy,uv\), and its legal
site-expanded child is Hamiltonian. In the
orientation \(d_L=1\), the defective transition
necessarily lies in \(B_0=[x,y]_C\), and its
free matching has the exact form (5) below.
The conclusion holds for arbitrary positive
original lobe lengths.

**Location.** Reflect if necessary so
\(d_L=b=1,d_R=0\). Let \(R_\ell\in B_h\) and
\(L_j,R_{j-1}\in B_i\). Target order gives
\(h\le i\). Both defects exhaust the eligible
vacancies by Note 197.

If \(h<i\), the first endpoint defect has
finished before the defective transition.
The one vacancy between \(L_j,R_{j-1}\)
would have the same-block order \(L_j,c,d,
R_{j-1}\). The earlier endpoint defect
changes the free prefix at both targets
by two. Note 212's parity-barrier proof
then isolates the adjacent pair \(c,d\),
which cannot be matched. Hence \(h=i\).

In the shared block, \(R_\ell\) is the
third interior slot: the first eligible
position is the vacancy assigned to
the endpoint defect, and a later
\(R_\ell\) would require another vacancy.
There is no vacancy between \(R_\ell\)
and \(L_j\), so all targets there are
consecutive. The second vacancy lies
between \(L_j,R_{j-1}\), which therefore
have the local order \(L_j,c,d,R_{j-1}\).
All later eligible positions are occupied
by nonfinal \(L\)-targets. Write the five
free slots of \(B_i\) as
\[
o_i,w,\quad c,d,\quad e_i,
\tag{2}
\]
in that old-cycle order, with \(o_i,w\)
before \(R_\ell\), \(c,d\) between
\(L_j,R_{j-1}\), and \(e_i\) after the
last target of the block. All blocks
before \(B_i\) are short.

The free-slot prefix before \(R_\ell\)
is even. A cross-block free chord cannot
straddle it by Note 203. If two same-block
chords cross it, both \(o_i,w\) are used.
For \(i\ge1\), no free matching edge can
then leave the complete prefix
\(B_0,\ldots,B_{i-1}\). It contains no
escape target, all its fixed site and
face chords are internal, and only two
old-cycle edges leave. This violates
three-connectivity. Thus no chord crosses
\(R_\ell\) when \(i\ge1\).

With that barrier, the free slots before
\(R_\ell\) match only among themselves.
No free slot lies between \(R_\ell,L_j\).
The prefix before \(R_{j-1}\) is still
even, because \(c,d\) add two. Of the
same-block chords from \(c,d\) to slots
after \(R_{j-1}\), only \(ce_i\) has
opposite colours; cross-block chords
over that target are forbidden. Parity
excludes \(ce_i\). The adjacent pair
\(c,d\) has no matching mate. Hence
\(i=0\): the shared block is the left
site block. The reflected assertion
places it in \(B_{r+1}\) when \(d_R=1\).

**Forced matching.** In \(B_0\), a
zero-crossing matching at \(R_\ell\)
would strand the adjacent pair \(o_0,w\).
Exactly two same-block chords must cross.
The even slot \(w\) can match only the
odd slot \(c\): \(o_0w\) is an old-cycle
edge, and there is no other free odd
slot after \(R_\ell\) inside \(B_0\).
The odd slot \(o_0\) can then match
\(d\) or \(e_0\). If it matched \(e_0\),
the even slot \(d\) would have no mate:
\(c\) and \(o_0\) are used, \(cd\) is
an old-cycle edge, and any mate after
\(R_{j-1}\) in a different block would
straddle its escape target. Therefore
\[
o_0d,\qquad wc\in M.                         \tag{3}
\]
All other free slots are the ordinary
sequence \(e_0,o_1,e_1,\ldots,e_r,o_{r+1}\).
At every later occupied target run its
free-slot prefix is even; there is at
most one possible same-block crossing
chord, so Note 203 and parity exclude
it. The noncrossing skipping rule of
Note 196 forces
\[
e_t o_{t+1}\in M\quad(0\le t\le r).
\tag{4}
\]
Thus the complete free matching is
\[
M_{\rm free}=\{o_0d,wc\}
\cup\{e_t o_{t+1}:0\le t\le r\}.
\tag{5}
\]

**Hamilton route.** For each lobe \(t\),
let \(T_t\) be Note 231's path from
\(R_t\) to \(L_t\) through the ordinary
free slots strictly between these
targets. Within a block it follows
old-cycle edges; between blocks it
uses the standard links (4). Every
ordinary free slot lies in exactly
one such interval: \(R_\ell\) has only
\(o_0,w\) before it, \(L_1\) is final
in the right site block, and the
only free slots between consecutive
lobes are \(c,d\), already used in (3).
The paths \(T_t\) are internally
disjoint and cover all ordinary slots.

One \(x\)-to-\(v\) path is the exposed
face route
\[
P_{\rm face}=x,y,a_1,b_1,\ldots,a_r,b_r,u,v.
\tag{6}
\]
The other starts
\[
x,o_0,d,c,w,R_\ell
\xrightarrow{T_\ell}L_\ell,
\gamma_\ell,\delta_\ell,\beta_\ell,\alpha_\ell.
\tag{7}
\]
For \(t=\ell-1,\ldots,1\), continue
from \(\alpha_{t+1}\) through
\[
\beta_t,\delta_t,R_t
\xrightarrow{T_t}L_t,\gamma_t,\alpha_t,
\tag{8}
\]
and finally take \(\alpha_1v\).
The edges in the initial segment
are \(xo_0,dc,wR_\ell\in E(C)\)
and \(o_0d,cw\in M\).
The first square route in (7) uses
\(L_\ell\gamma_\ell\in M\),
\(\gamma_\ell\delta_\ell,
\delta_\ell\beta_\ell\in E(C)\),
and \(\beta_\ell\alpha_\ell\in M\).
Each continuation in (8) uses
Note 231's square edges. Thus the
two displayed paths are internally
disjoint, cover all vertices, and
form a Hamilton cycle through
\(xy,uv\). Notes 001 and 178 give
the legal child and original
lobe lengths. \(\square\)

**A realized site-block profile.**
Set \(\ell=2,r=1,j=2\). The old
26-cycle consists of
\[
\begin{array}{ll}
B_0:&x,o_0,w,R_2,L_2,c,d,R_1,e_0,y,\\
B_1:&a_1,o_1,e_1,b_1,\\
B_2:&u,o_2,L_1,v,\\
S_t:&\alpha_t,\gamma_t,\delta_t,\beta_t
\quad(t=1,2),\text{ returning to }x.
\end{array}                                     \tag{9}
\]
Its complementary matching is
\[
\begin{split}
M={}&\{xy,uv,a_1b_1\}\\
&\cup\{\alpha_t\beta_t,R_t\delta_t,
L_t\gamma_t:t=1,2\}\\
&\cup\{o_0d,wc,e_0o_1,e_1o_2\}.
\end{split}                                     \tag{10}
\]
All pairs have opposite old-cycle
parity. Draw the site, face, and
\(\alpha_t\beta_t\) chords on one
side, with \(o_0d\supset wc\)
inside \(xy\). On the other side,
\[
R_2\delta_2\supset L_2\gamma_2
\supset R_1\delta_1\supset
\{e_0o_1,e_1o_2,L_1\gamma_1\},
\tag{11}
\]
where the three inner chords are
disjoint. The graph is simple,
cubic, bipartite, plane, with
cofacial sites. Its matching-chord
interlacement graph is connected:
\[
o_0d-R_2\delta_2-xy-e_0o_1-a_1b_1
-e_1o_2-uv-L_1\gamma_1-\alpha_1\beta_1
-R_1\delta_1,
\tag{12}
\]
while \(wc\) attaches to \(R_2\delta_2\),
\(L_2\gamma_2\) to \(xy\),
and \(\alpha_2\beta_2\) to
\(R_2\delta_2\). Note 217's interval
criterion proves three-connectivity;
its cut map makes the 30-vertex
site expansion Barnette.

The two paths of a marked Hamilton
cycle are
\[
\begin{split}
&x,y,a_1,b_1,u,v,\\
&x,o_0,d,c,w,R_2,L_2,\gamma_2,
\delta_2,\beta_2,\alpha_2,\beta_1,
\delta_1,R_1,e_0,o_1,e_1,o_2,
L_1,\gamma_1,\alpha_1,v.
\end{split}                                     \tag{13}
\]
They share only \(x,v\) and cover
all 26 vertices. \(\square\)

Notes 239--240 now cover every
\(s=2\) opening with exactly one
endpoint defect and one transition
defect. Two overlapping transition
defects, a spare vacancy in a
defect group, gap slots, and
nonsquare residual cycles remain
outside this result. Barnette's
conjecture is still unresolved.
