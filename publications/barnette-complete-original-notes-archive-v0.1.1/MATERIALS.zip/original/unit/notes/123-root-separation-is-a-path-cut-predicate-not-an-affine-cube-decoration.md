> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Root separation is a path--cut predicate, not an affine cube decoration

[Note 109](109-root-admissible-nae-colourings-have-an-exact-shore-rank-calculus.md)
separates root-admissibility into a four-rank equality and separation of two
ordered root fragments. [Note 119](119-actual-exterior-nae-strata-have-noncrossing-boolean-exchange-cubes.md)
then places exterior NAE colourings in Boolean exchange cubes. This note
determines the exact Boolean form of the second condition.

Root separation is a two-terminal path--cut predicate in a graph whose edge
states are signed coordinate literals. It need not be affine, a parity
character, a subcube, or order-convex. Actual squares in the fixed Note 116
triangulated disk also exclude canonical meet- and join-closure. Thus the
root labels supply no affine cubical intersection theorem with the
independent rank and closure conditions.

## 1. The path--cut formula

Let \(H\) be a triangulated disk, let \(\sigma,\tau\) be NAE colourings,
and let \(C_1,\ldots,C_m\) be the components of their split weak-dual
difference. Toggling \(C_i\) alone integrates to an NAE colouring. After
aligning global representatives, there is therefore a \(0\)-cochain

\[
 s_i:V(H)\longrightarrow\mathbb F_2
\tag{1}
\]

such that

\[
 \delta s_i=\mathbf 1_{E(C_i)}.
\tag{2}
\]

The corner indexed by \(J\subseteq[m]\) is

\[
 \sigma_J(v)=\sigma(v)+\sum_{i\in J}s_i(v).
\tag{3}
\]

Assume that every corner retains a common root matching edge \(uv\), and
let \(x_r,x_s\) be the third vertices in its two root triangles. Since the
root edge is the common monochromatic edge of each root triangle, no
exchange component meets the other two edges of those triangles. Each
\(s_i\) may consequently be oriented to vanish on
\(u,v,x_r,x_s\).

For an edge \(e=pq\), put

\[
 a_e=(s_1(p)+s_1(q),\ldots,s_m(p)+s_m(q)),
 \qquad
 b_e=\sigma(p)+\sigma(q).
\tag{4}
\]

The edge is monochromatic at corner \(J\) exactly when

\[
 \langle a_e,\mathbf1_J\rangle=b_e.
\tag{5}
\]

Hence the connection and separation predicates have the exact forms

\[
\begin{aligned}
 \operatorname{Conn}(J)
 &\iff
 \bigvee_{P:x_r\leadsto x_s}
 \ \bigwedge_{e\in P}
 [\langle a_e,\mathbf1_J\rangle=b_e],\\
 \operatorname{Sep}(J)
 &\iff
 \bigvee_{X:\,x_r\in X,\ x_s\notin X}
 \ \bigwedge_{e\in\delta(X)}
 [\langle a_e,\mathbf1_J\rangle\ne b_e].
\end{aligned}
\tag{6}
\]

For the bare exterior disk, the edge sets \(E(C_i)\) are disjoint. Each
test in (5) is therefore constant or one signed coordinate literal. More
explicitly, if

\[
 K=\mu_\sigma\cap\mu_\tau,
 \qquad
 A_i=E(C_i)\cap\mu_\sigma,
 \qquad
 B_i=E(C_i)\cap\mu_\tau,
\tag{7}
\]

then

\[
 \mu_{\sigma_J}
 =K\mathbin{\dot\cup}
 \mathop{\dot\bigcup}_{i\notin J}A_i
 \mathbin{\dot\cup}
 \mathop{\dot\bigcup}_{i\in J}B_i,
\tag{8}
\]

and \(\operatorname{Sep}(J)\) says precisely that \(x_r,x_s\) lie in
different components of this monochromatic graph.

If a fixed parent or child closure is attached to \(H\), the same formula
holds after extending the cochains to its local vertices. The four parent
and new-cell rows need not induce the same extensions; this is where the
closure predicates carry information not present in the bare cube.

## 2. An actual non-affine square

Use the crossed-double-split triangulation of Note 116, with root \(AC\)
and ordered opposite root fragments \(r_0,r_4\). In the parent vertex
order \((w,r_0,\ldots,r_7,A,B,C)\), take

\[
 \sigma=100010001111,
 \qquad
 \tau=100010100111.
\tag{9}
\]

Their exterior difference has the two weak-dual components

\[
\begin{aligned}
 C_5&=\{Br_5,r_4r_5,r_5r_6\}=\delta_H(\{r_5\}),\\
 C_7&=\{Br_7,r_0r_7,r_6r_7\}=\delta_H(\{r_7\}).
\end{aligned}
\tag{10}
\]

All four corners extend with the same valid parent local row, retain the
root edge, and give

\[
\begin{array}{c|c|c|c}
J&\text{parent row}&c_0+c_1&\operatorname{Sep}(J)\\ \hline
\varnothing&100010001111&3&1\\
\{C_5\}&100010101111&4&1\\
\{C_7\}&100010000111&2&0\\
\{C_5,C_7\}&100010100111&3&1.
\end{array}
\tag{11}
\]

The only monochromatic root-fragment connection which can appear in this
square is

\[
 r_0-r_7-r_6-r_5-r_4.
\tag{12}
\]

It is present exactly when \(C_7\) has been toggled and \(C_5\) has not.
Thus, in mask order \((00,10,01,11)\), the separation table is

\[
 1101,
 \qquad
 \operatorname{Sep}(j_5,j_7)=j_5\vee\neg j_7.
\tag{13}
\]

The three good corners in (13) are not a subcube or an affine coset. They
are not the zero set of an additive equality, and both diagonal corners are
good while one intermediate corner is bad, so they are not order-convex.
In particular, separation is not a single path parity or component weight.

## 3. The semilattice boundary

Bare meet- and join-closure are not canonical either. In the same fixed
actual disk, take

\[
 \alpha=100000001111,
 \qquad
 \beta=101010001111.
\tag{14}
\]

The two exchange components are the one-vertex cuts at \(r_1,r_3\), and
the four valid parent closures have separation table

\[
 0111.
\tag{15}
\]

The singleton corners are separated while their meet is not. Reversing
both coordinate orientations gives the same geometric square the table
\(1110\), in which the singleton corners are separated while their join is
not. Therefore neither a distinguished meet nor a distinguished join is
preserved by the actual cube system.

This does not exclude an orientation-dependent unate statement under the
full mixed-rooted-bond hypotheses. The rooted-endpoint table (13) is itself
unate. In the \(C_6\)-suspension square of Note 121, with root fragments
the two apices, the separation table is \(1000\), also unate. No general
unate theorem is asserted here.

## 4. Consequence for root-labelled selection

The universally valid decoration supplied by Notes 109 and 119 is exactly
the path--cut predicate (6). It is not an affine or convex Boolean-cube
decoration. Even a hypothetical orientation-dependent unate theorem would
not by itself select a corner where the independent rank equality and one
of

\[
 P_{\neg11},\quad X_R,\quad X_U,\quad X_V
\tag{16}
\]

also holds. The remaining interface is therefore a coupling theorem
between the path--cut predicate, rank balance, and the four actual closure
rows; root separation alone supplies no cubical intersection principle.

The fixed square tables are reproduced by

```text
python3 units/barnette/scratch/worker-root-separation-cube/audit_fixed_disk_root_separation_tables.py
```

and terminate with

```text
FIXED_DISK_ROOT_SEPARATION_TABLES_OK
```
