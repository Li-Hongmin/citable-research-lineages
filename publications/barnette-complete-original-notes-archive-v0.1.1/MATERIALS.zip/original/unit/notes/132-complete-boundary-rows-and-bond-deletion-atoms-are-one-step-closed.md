> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Complete boundary rows and bond-deletion atoms are one-step closed

[Note 131](131-three-cube-annular-splits-supplement-but-ordinary-splice-states-are-not-closed.md)
shows that parent perfect-matching rows and their Boolean bond graph do not
form a closed state for a later \(C_4\) split.  The missing objects are the
cross two-defect rows and the way each row pair is cut at the selected site.
This note gives the exact repair for one split.

Fix an ordered site

\[
p=uv,\qquad q=xy
\tag{1}
\]

in a plane cubic bipartite graph, together with the ordered roots and the
forced and surviving gates used by the rooted split-bond problem.  Replace
\(p,q\) by the standard four-vertex \(C_4\) patch.  The next site, when one
is requested, is assumed to be a deterministically named pair of edges in
that new patch.

## 1. Complete exterior rows

Delete \(p,q\).  The restriction of a child perfect matching to the old
exterior is a matching with one of the six defect sets

\[
\varnothing,\quad uv,\quad xy,\quad uvxy,\quad uy,\quad vx.
\tag{2}
\]

The first four classes are restrictions of parent perfect matchings.  The
last two are genuine near-perfect rows and need not have a parent
perfect-matching ancestor.  They are precisely the exterior sources of the
two cross cells.

For every exterior row \(r\), record its connector subset at every annular
interface and its marked deletion signature

\[
\delta_{p,q}(r).
\tag{3}
\]

This signature consists of the complement-component partition after the
four site ends have been exposed, the ordered root and gate marks on those
components, the relevant matching and fibre labels, all marked closed
components, and the number of unmarked closed components.  Counts that can
no longer affect the predicates may be saturated at \(0,1,2,\ge3\).

For every pair of exterior rows \(r,s\), record the bond-deletion atom

\[
\varepsilon_{p,q}(r,s),
\tag{4}
\]

namely the marked component partition of \(r\mathbin\triangle s\) after the
same site cut, including the annular connector differences, the surviving
gate mark, and the residual closed-component count.  The ordinary Boolean
bond relation is a predicate derived from (4); it is not transition data.

## 2. Seven-cell bijection

Let \(K\) denote one of the seven local patch patterns.  Restriction to the
old exterior gives the exact correspondence

\[
\begin{array}{c|c}
K&\text{exterior defect class}\\ \hline
C_{00}&\varnothing\\
C_{10}&uv\\
C_{01}&xy\\
C_{11}&uvxy\\
R_{00}&\varnothing\\
X_{uy}&uy\\
X_{vx}&vx.
\end{array}
\tag{5}
\]

Here the two no-defect cells use different local patch matchings.  For a
compatible exterior row \(r\), let \(J_K^c\) be the fixed marked complement
partition of the patch pattern \(K\).  Then the complete child row atom is

\[
\boxed{\delta^+(r,K)=\delta_{p,q}(r)\vee J_K^c,}
\tag{6}
\]

where the join identifies equally labelled site stubs and then removes the
identified labels.  Component counts and all root and gate marks are
updated under the join.

Formula (6) is exact.  In one direction, remove the patch edges from a
child perfect matching.  The mate of each patch vertex forces exactly one
line of (5).  In the other direction, adjoining the corresponding patch
matching to a compatible exterior row gives degree one at every child
vertex.  Thus (5) is a bijection, not merely a list of sufficient lifts.

The same partition join is valid across an annular interface.  If a factor
has bipartition \(A\mathbin{\dot\cup}B\), local hole set \(H\), and used
connector set \(U\), its balance condition is

\[
|U\cap A|+|H\cap A|=|U\cap B|+|H\cap B|.
\tag{7}
\]

Consequently cross-hole rows may use one or three connectors.  The old
zero/two/four-connector table for perfect-matching rows cannot generate
them.

## 3. Exact transport of the bond graph

For two child rows \((r,K)\) and \((s,L)\), let
\(J_{K,L}^{\triangle}\) be the fixed component partition of the symmetric
difference of the two patch patterns.  Then

\[
\boxed{
\varepsilon^+((r,K),(s,L))
=\varepsilon_{p,q}(r,s)\vee J_{K,L}^{\triangle}.
}
\tag{8}
\]

Both endpoint rows are first admitted by (6).  They are adjacent in the
child single-cycle bond graph exactly when the joined partition in (8) has
one alternating component carrying the required surviving-gate change.
Necessity follows by restricting the child symmetric difference to the
exterior and the patch.  Sufficiency follows because after all stubs are
joined the symmetric difference is 2-regular; one component is one simple
alternating cycle.  No triple-row datum is needed for this predicate.

It follows that the coupled state

\[
S^\sharp=
\bigl(
\text{complete exterior rows with }\delta_{p,q};
\ \varepsilon_{p,q}(r,s)\text{ for every row pair}
\bigr)
\tag{9}
\]

decides both the parent kill-cover predicate and the existence of a child
supplementing bond.  It also reconstructs the complete child row support
and the complete child bond graph.

## 4. Complete CEN/UV next-boundary production

Merely cutting the two next-site edges in all child perfect matchings does
not generate the two next cross-hole classes.  The correct transition uses
generalized patch rows.

Let \(p',q'\) be the named next site and let \(H'\) be one of its six
defect sets.  A generalized patch row is a matching

\[
P\subseteq E_J\setminus\{p',q'\}
\tag{10}
\]

which covers every non-hole patch vertex and avoids every vertex in \(H'\).
Its required old exterior defect is

\[
D(H',P)=
\bigl(V(P)\cap\{u,v,x,y\}\bigr)
\mathbin{\dot\cup}
\bigl(H'\cap\{u,v,x,y\}\bigr).
\tag{11}
\]

For \(\mathrm{CEN}=(bc,da)\), with next boundary
\((U',V',X',Y')=(b,c,d,a)\), the complete production table is

\[
\begin{array}{c|l}
\text{next class}&(D(H',P);P)\\ \hline
0&(0;ab\,cd),(uv;ua\,bv\,cd),(xy;ab\,xc\,dy),
   (uvxy;ua\,bv\,xc\,dy)\\
uv&(uy;ua\,dy)\\
xy&(vx;bv\,xc)\\
uvxy&(0;\varnothing)\\
uy&(0;cd),(xy;xc\,dy)\\
vx&(0;ab),(uv;ua\,bv).
\end{array}
\tag{12}
\]

For \(\mathrm{UV}=(ua,bv)\), with next boundary
\((U',V',X',Y')=(u,a,b,v)\), the complete table is

\[
\begin{array}{c|l}
\text{next class}&(D(H',P);P)\\ \hline
0&(0;ab\,cd),(0;ad\,bc),(xy;ab\,xc\,dy)\\
uv&(uy;dy\,bc)\\
xy&(vx;xc\,ad)\\
uvxy&(uv;cd),(uvxy;xc\,dy)\\
uy&(uv;ab\,cd),(uv;ad\,bc),(uvxy;ab\,xc\,dy)\\
vx&(0;cd),(xy;xc\,dy).
\end{array}
\tag{13}
\]

Thus CEN has \(11\) generalized rows and UV has \(12\).  Every source
defect in (12)--(13) is one of the six classes (2); no seventh class is
needed.

Restriction and extension are inverse.  Restrict a next-boundary row to the
patch.  Since \(p',q'\) are absent, its patch restriction is a unique
\(P\) satisfying (10), and degree one at every non-hole vertex forces
(11).  Conversely, an exterior row of class \(D(H',P)\) and its listed
patch row cover every non-hole child vertex exactly once.

For a table entry \((D,P)\), the next row atom is

\[
\delta_{\mathrm{next}}(r,P)
=\delta_{p,q}(r)\vee J^c_{P,H'}.
\tag{14}
\]

For two next rows, the complete pair atom is

\[
\varepsilon_{\mathrm{next}}((r,P),(s,Q))
=\varepsilon_{p,q}(r,s)
 \vee J^\triangle_{P,Q;H',H''}.
\tag{15}
\]

The next-site stubs remain marked in these joins.  Equations (12)--(15)
therefore generate the complete six-class next-boundary support and every
next pair atom.  Together with Sections 2--3, this proves that
\(S^\sharp\) is one-step closed for either deterministic CEN or UV
successor.

The vocabulary of marked partition atoms is finite: the number of named
stubs, roots and gates is bounded, and irrelevant closed-component counts
are saturated.  This does **not** yet give a finite automaton for arbitrary
words.  The support may contain an unbounded number of row identities and
an unbounded finite relational structure on their pairs.  Proving that a
finite quotient preserves the required universal and existential
predicates is a separate problem.

If the next site may contain an unmarked retained exterior edge, (9) is not
closed: equal current atoms may place that edge in different components.
Its ends and component fragments must already be marked in the current
state.

## 5. Actual collision instance

The first decoration used in Note 131 has order \(24\to28\), root
\(0\!-\!4\), forced gate \(2\!-\!6\), surviving gate \(10\!-\!14\), and
site \(p=5\!-\!7,q=1\!-\!3\).  Complete exterior enumeration gives

\[
97+20+41+68+76+76=378
\tag{16}
\]

rows in the six defect classes of (2).  Equations (6) and (8) reconstruct,
as literal sets,

\[
\begin{array}{c|rrrrrrr}
K&C_{00}&C_{10}&C_{01}&C_{11}&R_{00}&X_{uy}&X_{vx}\\ \hline
\#&97&20&41&68&97&76&76,
\end{array}
\tag{17}
\]

so all \(475\) child perfect matchings are recovered.  The reconstructed
rooted fibre is exactly the direct \(27\)-row fibre, and the reconstructed
cross-sector single-cycle graph is exactly the direct \(26\)-edge graph.
All \(112{,}575\) unordered exterior-row pairs were checked; the
corresponding \(1{,}647\) decorated pair states have no conflicting bond
outcomes in this instance.

The frozen computation is in the
[three-cube rooted split-bond bundle](../computations/bundles/three-cube-rooted-split-bond-classification/README.md).
This instance verifies the concrete realization of the formulas; the
one-step theorem itself is the restriction-and-gluing argument above.

The CEN/UV production tables and pair joins are independently checked by
the [local closure bundle](../computations/bundles/cen-uv-complete-boundary-row-closure/README.md).
It enumerates all \(11+12\) local rows and compares \(55{,}120\) abstract
old-partition joins against direct symmetric-difference recutting, with no
collision.

## 6. Scope

The theorem is local to one standard split with a patch-local named next
site.  It proves an exact sufficient state language and repairs the strict
information loss of Note 131.  It does not prove the general rooted
split-bond lemma, \(H^{+-}\) preservation, realizability of abstract
supports, bounded support size, or all-depth closure under arbitrary
CEN/UV words.
