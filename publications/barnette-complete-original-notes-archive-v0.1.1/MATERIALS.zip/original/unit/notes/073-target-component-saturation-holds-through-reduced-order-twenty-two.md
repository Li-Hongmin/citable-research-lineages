> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Target-component saturation holds through reduced order twenty-two

[Note 071](071-at-most-one-gate-always-lifts-and-component-saturation-holds-through-twenty.md)
proves that every target using at most one gate lifts, and that the stronger
target-component saturation statement need only be tested on components in
which both gate edges are forced.  This note performs that exact restricted
test at the first previously unsupported reduced order.

## Exact finite theorem

Let (F') be a simple plane cubic bipartite brace with

\[
|V(F')|\le22.
\]

Fix any legal two-gate (C_4)-expansion at a face (C), and any unchanged
root edge (e\notin E(C)) for which

\[
\mathcal T_e=\{M:e\in M,\ F'-M\text{ is two cycles separating the ends
of }e\}
\]

is nonempty.  Let (G_e) join two members of (mathcal T_e) when their
symmetric difference is one alternating cycle.  Then every connected
component of (G_e) contains a target matching that lifts through the fixed
expansion.

In particular, every nonempty complete target family contains a liftable
target.  Hence existence-level prescribed-edge (C_4) lifting holds through
reduced brace order (22).

## Complete order-twenty-two coverage

The command

    geng -cqb -d3 -D3 22

generates (4132) connected simple cubic bipartite isomorphism
representatives.  Exactly (14) are planar, (8) are planar and
(3)-connected, and (3) satisfy both the independent-two-edge extension
test and the strict-Hall brace criterion.

For these three braces, the complete embedded-dual calculation gives

\[
\begin{array}{lr}
\text{nonconsecutive gate pairs}&237,\\
\text{admissible odd-arc (4)-connected splits}&168,\\
\text{nonempty surviving-root interfaces}&4548,\\
\text{target/interface instances}&36696,\\
\text{target-state components}&6362,\\
\text{components containing a target with at most one gate}&6096,\\
\text{components forcing both gates}&266,\\
\text{targets in forced-gate components}&668.
\end{array}
\tag{1}
\]

The first (6096) components are liftable by the proof-level neutral-gate
lemma.  Every one of the remaining (266) forced-gate components also
contains a liftable target.  No component failure occurs.

Combining (1) with Note 071, the complete through-(22) range contains

\[
13346\text{ interfaces},\qquad
82060\text{ target instances},\qquad
15658\text{ target-state components},
\tag{2}
\]

and every component meets the liftable set.

The proof bundle is
[target-component-saturation-order22](../computations/bundles/target-component-saturation-order22/README.md).
The census stops at the first failed forced-gate component and would freeze
its complete target and local-row data.  The accepted full run has no such
record, and an independent rerun reproduced its JSON byte for byte.

## Boundary

**Exact conclusion.** The stronger single-alternating-cycle target-component
saturation statement, and therefore ordinary existence-level prescribed-edge
(C_4) lifting, holds for every reduced plane cubic bipartite brace through
order (22).

**Weakest load-bearing step.** The arbitrary-order neutral-gate lemma closes
all non-forced components.  The remaining order-(22) statement rests on
`geng`'s complete isomorph-free generation and exact planarity filtering;
every brace, interface, target family, exchange component, gate condition,
and tested lift row is checked directly.

**Evidence level.** This is an exact computer-assisted finite theorem built
on the proof-level reduction of Note 071.

**Unresolved boundary.** Reduced brace order (24) and all larger orders
remain open.  More importantly, the finite success does not yet prove that a
forced-two-gate component cannot be trapped in bad rooted component
partitions at arbitrary order; a structural selection mechanism is still
required.
