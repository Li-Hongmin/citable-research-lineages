> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All two-slot gaps are excluded at first surplus

[Note 213](213-two-slot-gaps-must-split-and-disrupt-a-transition.md)
excludes two slots in one gap and shows that two singleton gaps
would require a nonadjacent escape-target transition. Even that
remaining shape is impossible. Its first gap slot cannot be
matched on either side of the first subsequent escape target.

Use the compressed all-square Barnette opening of Notes 195--197.
Let its lobe and opposite-face-chord counts be \(\ell,r\ge1\), and
suppose \(f=4r+4\). Let \(G_a,G_b\), \(a<b\), be distinct singleton
gaps, with respective slots \(g=E,h=O\). All other gaps are empty,
and the block capacity is saturated:
\(\sum_{i=0}^{r+1}k_i=\ell-1\). The blocks before \(g\) are forward,
those strictly between \(g,h\) are reversed, and those after \(h\)
are forward again.
These are the only gap possibilities left after Note 213: the
counting identity of Note 195 gives
\[
 2\bigl(\sum_i k_i-(\ell-1)\bigr)+\sum_i t_i=2,
\]
so a positive gap total must be exactly two slots at saturated
block capacity.

**Two-gap exclusion theorem.** No such opening exists. Hence every
all-square opening at \(f=4r+4\) is gapless. Combined with
[Note 212](212-every-gapless-first-surplus-opening-has-a-marked-hamilton-cycle.md),
every legal site-expanded child admitting an all-square opening
with \(\ell,r\ge1\) and \(f=4r+4\) is Hamiltonian.

**Proof.** Note 197 pins \(R_\ell\) to the first slot of \(B_0\)
and \(L_1\) to the final slot of \(B_{r+1}\). It also says that
every nonadjacent transition \(L_j,R_{j-1}\) ends at the second
slot of a reversed block between the two gaps. Consequently no
defective transition can end before \(g\). Since consecutive
target intervals are disjoint, at most one defective transition
can begin before \(g\); if one does, its source \(L_j\) is the
last eligible even slot of a forward block \(B_i\), \(i\le a\),
and its following odd slot \(c_i\) and final even slot \(e_i\)
are free. Every block from \(B_{i+1}\) through \(B_a\) is short:
an occupied eligible position there would insert another target
between \(L_j,R_{j-1}\).

We first exclude a matching mate of \(g\) before \(g\).
With no defective source before \(g\), the free slots there
are the usual final even \(e_0\) of \(B_0\) and first odd/final
even pairs \(o_t,e_t\) of forward face blocks. A target run
cannot be crossed by a free matching edge: the number of free
slots before it is even, cross-atom edges are barred by
[Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md),
and at most one same-block edge could cross, so matching
parity excludes that edge. Thus all free chords among these
slots and \(g\) lie in the opposite-side disk and are
noncrossing. If \(g\) matched any earlier odd slot \(o_t\),
the strictly intervening free slots would be
\(e_t,o_{t+1},e_{t+1},\ldots,e_a\), an odd number.
They could not match internally, a contradiction.

If a defective source \(L_j\) lies before \(g\), a chord from
\(g\) to an odd slot preceding \(L_j\) would straddle that
target and is forbidden by Note 203. The free odd candidates
after \(L_j\) and before \(g\) are \(c_i\) and the first slots
of the subsequent short forward blocks. For each such candidate,
the free slots strictly between it and \(g\) start with the
following even slot and then consist of complete short-block
pairs, so their number is odd. All those slots have their
matching edges in the opposite-side disk: the pairs within
short blocks, and \(c_i e_i\), are old-cycle edges; no
same-block edge can cross the source target because its
preceding free-slot count is even. Noncrossing again rules
out every candidate. Therefore \(g\) has no mate before it.

Let \(T\) be the first escape target after \(g\). Every free
matching edge from \(g\) to a slot after \(T\), including a
possible edge to \(h\), would be a cross-atom chord
straddling \(T\), hence is forbidden by Note 203.
Consider the possible odd mates strictly between \(g,T\).

If the defective transition began before \(g\), then \(T\)
is its destination \(R_{j-1}\), the second slot of a
reversed block. All preceding reversed blocks are short,
and the first slot of the destination block is even and
free. Its second slot is \(T\), not a matching candidate.
The only odd free candidates before \(T\) are the second
slots of those short reversed blocks. For each candidate,
the free slots strictly between \(g\) and it consist of
complete earlier reversed-block pairs and the first even
slot of its own block: an odd number. All are cross-atom
matching slots in the opposite-side disk, since each
short-block pair is an old-cycle edge. Noncrossing
rules out every candidate.

If no defective transition began before \(g\) and \(T\)
lies between the gaps, then \(T\) is the first occupied
\(L\)-target in a reversed block. It is that block's
third interior slot: all earlier reversed blocks are
short, and its first two slots are free \(E,O\).
The number of free slots before \(T\) is even. At most
one same-block free edge could cross \(T\), while every
cross-atom edge across it is forbidden by Note 203;
matching parity therefore forbids all crossings.
Any odd free candidate before \(T\) is the second
slot of an earlier short reversed block or the second
slot of \(T\)'s block. In both cases the chord from
\(g\) encloses complete preceding \(E,O\) pairs and
the first even slot of the candidate's block, an odd
number. The target barrier ensures these interior
slots cannot escape through a same-block chord on the
other disk. Thus no candidate can match \(g\).

It remains possible that no escape target lies between
\(g,h\). Then every reversed block \(B_{a+1},\ldots,B_b\)
is short. For a free odd candidate in one of those
blocks, the same odd-interior argument applies. If
\(g\) matched an odd free slot in a forward block after
\(h\) but before \(T\), its chord would enclose all
reversed-block free pairs, the singleton \(h\), and
complete intervening forward-block pairs: again an odd
number of free endpoints. The only remaining candidate
is \(h\) itself. If \(gh\in M\), noncrossing forces
all free slots of the target-free consecutive block
interval \(B_{a+1},\ldots,B_b\) to match inside that
interval. Its fixed face chords are also internal,
so only its two old-cycle boundary edges leave, a
forbidden two-edge cut. This excludes \(gh\).

Every possible matching mate of \(g\) has been excluded,
contradicting that the complementary matching is perfect.
\(\square\)

Together with [Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md),
the theorem now settles both \(f=4r+2\) and \(f=4r+4\)
for all-square openings with \(\ell,r\ge1\). It does not
address larger free-vertex counts, zero opposite-face chords,
nonsquare residual cycles, or Barnette graphs not obtained
through the specified legal site opening.

**Counterexample-size corollary.** If a non-Hamiltonian legal
site-expanded child admits an all-square facial opening with
\(\ell,r\ge1\), then its selected opening has
\[
 f\ge4r+6,\qquad |V(S_0)|\ge4r+2\ell+10.
\]
Indeed, Note 195 gives \(f\ge4r+2\), while Notes 196,
212 and the theorem above exclude the first two possible
even values of \(f\) for a non-Hamiltonian child. \(\square\)
