> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Maximal chorded seven-face-chord failures reduce to four outer words

Consider a legal cofacial \(C_4\)-expansion with one selected trapped hexagon containing the complementary matching chord \(ad\), and with \(f=7\) additional main chords on the common-face side, as in [Note 416](416-a-chorded-seven-face-chord-failure-has-one-seven-leaf-root.md). Perform both ladder reductions of [Note 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md) and let \(c\) be the ordinary-chord count of the reduced parent.

**Four-word reduction theorem.** If the expanded child is non-Hamiltonian and \(c=32\), then, up to reflection, its odd-depth leaves are \(1,6,7\), its site leaves are \(6,7\), and its four even-depth leaves are \(2,3,4,5\). Its ordinary word and face matching are one of rows 1, 2, 4, 5 in (12) below. The formal row 3 has a forbidden two-edge cut. Thus the two-by-two even-leaf distributions and every other four-on-one-side placement are Hamiltonian or structurally impossible. This necessary reduction does not assert that any of the four remaining graphs is non-Hamiltonian or even realizes a legal expansion; it does not decide the \(c=31\) branch or Barnette's conjecture.

**Reduction to leaf parity words.** Suppose the child is non-Hamiltonian. Note 416 gives one seven-leaf root, no serial sibling-leaf chord of [Note 412](412-two-odd-ladder-poles-compose-to-one-odd-ladder-signature.md), and the old-cycle order
\[
C=(w_0,z_L,t_c,W,t_b,z_R,w_*,\alpha,a,b,c,d,\beta,w_0).
\tag{1}
\]
Equality \(c=32\) makes every leaf \(U_i=((x_i y_i))\) and every binary branch \(F(P,Q)=(((P Q)))\). [Note 419](419-depth-parity-forces-three-odd-leaves-in-the-maximal-seven-face-chord-kernel.md) proves that precisely three of the seven leaves have odd depth. Two are the site leaves \(j<k\); the third lies outside the site interval. The four even-depth leaves occur in group sizes \((4,0,0)\) or \((2,2,0)\), up to permutation of the left, middle and right groups. The four-middle-leaf case is Hamiltonian by [Note 420](420-every-maximal-seven-face-chord-kernel-with-four-middle-even-leaves-is-hamiltonian.md).

We use the exact parity-word recurrence to handle the other distributions. Let \(E,O\) record even and odd depth, and let \(\overline v\) swap the two letters in a word \(v\). For a one-leaf tree the word is \(E\); a binary root with child words \(u,v\) has word \(\overline u\,\overline v\). Conversely, every tree with a prescribed word arises from a split \(w=ab\) for which the left and right child words are \(\overline a,\overline b\). The words for two, three and four leaves are, respectively,
\[
OO;\qquad OEE,EEO;\qquad OEOO,OOOE,EEEE,EOOO,OOEO.
\tag{2}
\]

There are two ways a joining face chord can exclude a sibling-leaf pair in a legal hypothetical failure. If \(U_a,U_{a+1}\) are siblings and *both* their special pairs are matched across the two leaves, the twelve leaf vertices have exactly two edges to the rest of the graph: from \(L_a\) to the preceding branch bracket and from \(R_{a+1}\) to the following branch bracket. This is a two-edge cut, impossible in a three-connected cubic graph. More generally, any proper ordinary subtree whose special terminals are all matched inside it is separated by just its two extreme old-cycle edges, so it too violates three-connectivity. If only \(y_ax_{a+1}\) joins the siblings and their other special terminals attach outside the pair, the twelve-vertex patch is the induced four-pole of Note 412; compressing it reduces \(f\) to six, and Note 414 gives a Hamiltonian child. We call either case a *sibling-leaf exclusion* below, keeping the two reasons distinct.

If one face-side subcompartment contains exactly two even-depth leaves \(a<b\), its noncrossing matching is forced to be \(x_ay_b,y_ax_b\): the self-pairs \(x_ay_a,x_by_b\) are old-cycle edges. If the two leaves are consecutive and siblings, both cross-pairs lie inside the twelve-leaf-vertex set, so the two-edge-cut exclusion applies. The two-by-two distributions are exhausted, up to reflection, by the following table. The middle column lists *all* root splits permitted by the recurrence; applying the same recurrence within each permitted child gives the unavoidable sibling pair or pairs in the last column.

| Depth-parity word | Root splits | At least one sibling pair excluded by the forced face matching |
| --- | --- | --- |
| \(OOEEOEE\) | \(1\mid6,3\mid4,5\mid2\) | \((1,2),(3,4),(6,7)\) |
| \(OEEOOEE\) | \(1\mid6,5\mid2\) | \((2,3),(6,7)\) |
| \(EOEOOEE\) | \(5\mid2\) | \((6,7)\) |
| \(EEOOOEE\) | \(2\mid5,5\mid2\) | \((1,2),(6,7)\) |
| \(OEEOEEO\) | \(1\mid6,6\mid1\) | \((2,3),(5,6)\) |
| \(EOEOEEO\) | \(6\mid1\) | \((5,6)\) |
| \(EEOOEEO\) | \(2\mid5,6\mid1\) | \((1,2),(5,6)\) |

The only six-leaf child words needed to check the nontrivial rows have the following complete root-split lists, obtained directly from (2):
\[
\begin{array}{c|l}
EOOEOO&3|3,5|1\\
OOEEOO&1|5,3|3,5|1\\
OOEOOE&1|5,3|3\\
OEOEOO&1|5.
\end{array}
\]
For a surviving \(5|1\) or \(1|5\) child split, applying the recurrence once to its five-leaf side fixes the indicated sibling pair; no other six-leaf shape remains.

For clarity, the last column says that **at least one** listed pair is sibling in each compatible tree, not that all are. For example, \(EOEOEEO\) has successive surviving splits \(6|1,1|5,1|4,1|3,1|2\), so \((5,6)\) is sibling. The other rows follow from the same recurrence and (2): a surviving three-leaf child is either \(F(U,F(U,U))\) or \(F(F(U,U),U)\), and a four-leaf child has one of the five words in (2). For \(OOEEOEE\), the possible pair \((1,2)\) consists of the third odd leaf and the left site leaf; their chord \(y_1x_2\) is forced by Note 419, while their other special terminals attach outside the pair, so Note 412 applies. Every other listed pair consists of two consecutive even leaves wholly matched to each other, giving the forbidden two-edge cut. Hence no \((2,2,0)\) distribution can occur in a legal non-Hamiltonian child.

**Four even leaves on an outer side.** Reflecting the order if necessary, the site leaves are \(j=6,k=7\), while the third odd leaf \(r\) is one of \(1,2,3,4,5\). The odd-depth face chords are \(z_Lx_r,y_rx_6,y_7z_R\). The first chord encloses every even leaf before \(r\); the second encloses every even leaf strictly between \(r\) and \(6\). Planarity forces each enclosed set to be matched internally. A one-leaf set is impossible, since \(x_i y_i\) is an old-cycle edge. Therefore \(r=2,4\) are impossible. If \(r=3\), each of the two even-leaf pairs \((1,2)\) and \((4,5)\) is wholly matched inside its own subcompartment. The parity word is \(EEOEEOO\); its possible root splits are \(2|5,4|3,6|1\). The recurrence used above shows that every compatible tree has \((1,2)\) or \((4,5)\) as a sibling pair: for \(2|5\) the former is immediate, for \(4|3\) the left child has word \(OOEO\) and forces \((1,2)\), while for \(6|1\) the left child has word \(OOEOOE\) and its only root splits \(1|5,3|3\) force \((4,5)\) or \((1,2)\), respectively. The resulting two-edge cut eliminates \(r=3\).

It remains to analyze \(r=1\) and \(r=5\). For \(r=5\), the parity word is \(EEEEOOO\), the face chords on odd-depth leaves are \(z_Lx_5,y_5x_6,y_7z_R\), and the recurrence has exactly five tree shapes:

| Root and subsequent splits | Consequence |
| --- | --- |
| \(2\mid5\), then \(1\mid4\) on the right | \((5,6)\) sibling; Note 412 applies to \(y_5x_6\) |
| \(2\mid5\), then \(3\mid2\) on the right | word \(W_{\rm I}\) below |
| \(6\mid1\), then \(1\mid5\) and \(2\mid3\) on the left | \((5,6)\) sibling; Note 412 applies to \(y_5x_6\) |
| \(6\mid1\), then \(1\mid5\) and \(4\mid1\) on the left | word \(W_{\rm II}\) below |
| \(6\mid1\), then \(4\mid2\) on the left | \((5,6)\) sibling; Note 412 applies to \(y_5x_6\) |

The four even leaves \(1,2,3,4\) have the three noncrossing matchings (4) of Note 419 with indices shifted to \(1,2,3,4\). In both surviving words \((3,4)\) is sibling. Matching I pairs both leaves wholly to each other and creates a two-edge cut; matching II gives the compressible single joining chord \(y_3x_4\). Matching III is forced:
\[
M_{\rm face}=\{z_Lx_5,y_5x_6,y_7z_R,
x_1y_4,y_1x_4,x_2y_3,y_2x_3\}.
\tag{3}
\]
The remaining matching edges outside \(W\) are \(t_cc,t_bb,\alpha\beta,ad\), as in Note 418. We give Hamilton paths using only these edges, old-cycle edges and ordinary parenthesis chords.

For every leaf write its vertices in old-cycle order as \(L_i,h_i,x_i,y_i,j_i,R_i\), and put
\[
Y_i=(y_i,x_i,h_i,j_i,R_i,L_i),\quad
X_i=(R_i,L_i,h_i,j_i,y_i,x_i),\quad
Z_i=(y_i,j_i,R_i,L_i,h_i,x_i).
\tag{4}
\]
Each is a spanning leaf path. In every occurrence of \(F\), name its left brackets \(\lambda_0,\lambda_1,\lambda_2\), its right brackets in old-cycle order \(\rho_2,\rho_1,\rho_0\), and its first/last vertices \(F_\ell=\lambda_0,F_r=\rho_0\). Superscripts identify occurrences.

For the first survivor set
\[
A=F(U_1,U_2),\quad B=F(U_3,U_4),\quad C=F(B,U_5),\quad
D=F(U_6,U_7),\quad E=F(C,D),\quad W_{\rm I}=F(A,E).
\tag{5}
\]
Split \(A,B\) into four vertex-disjoint paths:
\[
\begin{aligned}
A^-&=(A_\ell,\lambda_1^A,\lambda_2^A,L_1\xrightarrow{Y_1^{-1}}y_1),&
A^+&=(x_2\xrightarrow{X_2^{-1}}R_2,\rho_2^A,\rho_1^A,A_r),\\
B^-&=(B_\ell,\lambda_1^B,\lambda_2^B,L_3\xrightarrow{Y_3^{-1}}y_3),&
B^+&=(x_4\xrightarrow{X_4^{-1}}R_4,\rho_2^B,\rho_1^B,B_r).
\end{aligned}
\tag{6}
\]
They cover every vertex of \(A\cup B\) exactly once. A spanning \(y_6\)--\(x_7\) path of \(W_{\rm I}\) is
\[
\begin{aligned}
y_6&\xrightarrow{Z_6}x_6,
y_5\xrightarrow{Y_5}L_5,
B_r\xrightarrow{(B^+)^{-1}}x_4,
y_1\xrightarrow{(A^-)^{-1}}A_\ell,\\
&\lambda_2^W,\lambda_1^W,W_\ell,W_r,\rho_1^W,\rho_2^W,E_r,
\rho_1^E,\rho_2^E,\lambda_2^E,\lambda_1^E,E_\ell,\\
&A_r\xrightarrow{(A^+)^{-1}}x_2,
y_3\xrightarrow{(B^-)^{-1}}B_\ell,
\lambda_2^C,\rho_2^C,\rho_1^C,\lambda_1^C,\lambda_0^C,C_r,\\
&D_\ell,D_r,\rho_1^D,\lambda_1^D,\lambda_2^D,\rho_2^D,
R_7\xrightarrow{X_7}x_7.
\end{aligned}
\tag{7}
\]
The three face-chord steps in (7) are \(x_6y_5,x_4y_1,x_2y_3\), all in (3). The transitions \(L_5B_r\), \(A_\ell\lambda_2^W\), \(\rho_2^WE_r\), \(E_\ell A_r\), \(B_\ell\lambda_2^C\), \(C_rD_\ell\), and \(\rho_2^DR_7\) are old-cycle edges. Every bracket-to-bracket step in (7) is either consecutive on the old cycle or pairs matching brackets. Thus (7) visits the seven leaves and all six sets of branch brackets once.

For the second survivor set
\[
B=F(U_3,U_4),\quad A=F(B,U_5),\quad C=F(U_2,A),\quad
D=F(C,U_6),\quad E=F(U_1,D),\quad W_{\rm II}=F(E,U_7).
\tag{8}
\]
Let \(R_C\) be the reverse old-cycle path from \(C_r\) to \(C_\ell\), with its step \(y_4x_4\) replaced by
\[
y_4,x_1,h_1,L_1,R_1,j_1,y_1,x_4.
\tag{9}
\]
The first and last steps of (9) are the face chords \(y_4x_1,y_1x_4\); \(L_1R_1\) is an ordinary chord. Hence \(R_C\) visits all of \(C\cup U_1\) exactly once. A spanning \(y_6\)--\(x_7\) path of \(W_{\rm II}\) is
\[
\begin{aligned}
y_6&\xrightarrow{Y_6}L_6,
C_r\xrightarrow{R_C}C_\ell,
\lambda_2^D,\rho_2^D,\rho_1^D,\lambda_1^D,D_\ell,D_r,
\rho_2^E\xrightarrow{T_E^+}E_\ell,\\
&\lambda_2^W,\lambda_1^W,W_\ell,W_r,\rho_1^W,\rho_2^W,
R_7\xrightarrow{X_7}x_7,
\end{aligned}
\tag{10}
\]
where \(T_E^+=(\rho_2^E,\lambda_2^E,\lambda_1^E,\rho_1^E,\rho_0^E,\lambda_0^E)\) is the six-bracket path of Note 418. The connectors \(L_6C_r\), \(C_\ell\lambda_2^D\), \(D_r\rho_2^E\), \(E_\ell\lambda_2^W\), and \(\rho_2^WR_7\) are old-cycle edges. The six \(D\)-brackets in (10) are traversed by successive old-cycle or paired-bracket edges. Equation (10) covers \(U_1,\ldots,U_7\) and all six branch wrappers exactly once.

For either word let \(P\) denote (7) or (10). Its parent graph has the Hamilton cycle
\[
w_0\xrightarrow{q}y_6\xrightarrow{P}x_7\xrightarrow{p}w_*,
z_R,t_b,b,a,\alpha,\beta,d,c,t_c,z_L,w_0.
\tag{11}
\]
The outside steps are old-cycle edges or \(t_bb,\alpha\beta,t_cc\). Both site edges occur, so the direct lift of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) gives a Hamilton cycle of the expanded child. Thus \(r=5\) cannot support a failure.

**The four surviving words.** For \(r=1\), the parity word is \(OEEEEOO\), the site edges remain \(q=w_0y_6,p=x_7w_*\), and the odd-depth face chords are \(z_Lx_1,y_1x_6,y_7z_R\). Let matching I on the four even leaves \(2,3,4,5\) mean
\[
\{x_2y_3,y_2x_3,x_4y_5,y_4x_5\},
\]
and matching III mean
\[
\{x_2y_5,y_2x_5,x_3y_4,y_3x_4\}.
\]
Applying the exact parity-word recurrence and removing every sibling pair excluded by its face matching first leaves these five formal words:
\[
\begin{array}{c|l|c}
\text{row}&\text{ordinary word}&\text{matching}\\\hline
1&F(U_1,F(U_2,F(F(U_3,U_4),F(U_5,F(U_6,U_7)))))&\mathrm I\\
2&F(U_1,F(U_2,F(F(U_3,F(F(U_4,U_5),U_6)),U_7)))&\mathrm {III}\\
3&F(U_1,F(F(F(U_2,U_3),F(U_4,U_5)),F(U_6,U_7)))&\mathrm {III}\\
4&F(F(F(U_1,F(U_2,U_3)),U_4),F(U_5,F(U_6,U_7)))&\mathrm {III}\\
5&F(F(F(U_1,F(U_2,U_3)),F(F(U_4,U_5),U_6)),U_7)&\mathrm {III}.
\end{array}
\tag{12}
\]
Indeed \(OEEEEOO\) permits only the root splits \(1|6,4|3,6|1\). The first has three possible right-subtree shapes, the middle split has one pair of child shapes, and the last has one left-subtree shape, yielding the five formal rows. In row 1 the sibling pair \((3,4)\) leaves only matching I: matching II is compressible and matching III creates a two-edge cut. In rows 2--5 sibling pairs \((2,3)\) or \((4,5)\) leave only matching III: matching I creates a two-edge cut and matching II is compressible. In row 3, the four even leaves \(2,3,4,5\) form the proper subtree \(F(F(U_2,U_3),F(U_4,U_5))\). Matching III pairs all eight of their special terminals within that subtree, so its only two edges to the rest of the graph are the old-cycle edges at its extremes. This contradicts three-connectivity. Rows 1, 2, 4, 5 are the only remaining formal candidates; their Hamiltonicity and legal realizability are not asserted. Notes 410 and 416 imply that any failure in the original graph reduces to one of these four if \(c=32\), completing the necessary reduction. \(\square\)
