> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A cross-return single-double corridor has the square signature at every length

[Note 380](380-every-isolated-single-double-free-group-has-a-square-reduction.md)
classifies the group with one singly vacant and one
doubly vacant target-free block and no intervening
short block. A positive short corridor allows a
different boundary return: the left ordinary endport
can retain its standard link while the single block's
extra slots return to the double block. The resulting
four-pole has an exact square signature at every
positive corridor length.

For \(m\ge1\), let \(Q_m\) have old-cycle path
\[
 a,o,h,i,e,b,\quad
 c_1,p_1,q_1,d_1,\ \ldots,\
 c_m,p_m,q_m,d_m,\quad
 A,O,H,I,K,J,E,B.                                      \tag{1}
\]
Besides consecutive path edges, add the face-closing
edges \(ab,c_jd_j\ (1\le j\le m),AB\) and the
free matching edges
\[
 hJ,\quad iK,\quad eI,\quad p_1H,\quad
 q_jp_{j+1}\ (1\le j<m),\quad q_mO.                    \tag{2}
\]
The three long chords \(hJ\supset iK\supset eI\)
and the corridor chords in (2) are noncrossing
on the page opposite the face-closing chords.
The only degree-two terminals are
\((a,o,E,B)\) in disk-boundary order.
For \(m=1\), write the short block as
\((c,p,q,d)\).

**Unbounded cross-return theorem.** For every
\(m\ge1\), \(Q_m\) has exactly the four
spanning single-path and two spanning
two-path Hamilton states of a square
with labeled corners \((a,o,E,B)\).
Replacing an induced disk copy of \(Q_m\)
by that square, or reversing the
replacement, preserves Barnette membership
and every exterior- and attachment-marked
Hamilton decision. Thus none of these
induced disk patches can occur in a
vertex-minimal non-Hamiltonian Barnette graph.
For every \(m\), the matching profile (2)
occurs in a Barnette parent with a
compressed, gapless, tight-target all-square
selected opening, a Hamilton cycle through
both site edges, and a legal Hamiltonian
site-expanded child.

**The eighteen-vertex core.** For \(m=1\),
the four allowed single-path endpoints
and explicit spanning paths are
\[
\begin{array}{c|l}
aB & a,o,h,i,e,b,c,p,q,d,A,O,H,I,K,J,E,B\\
ao & a,b,e,i,K,I,H,O,q,p,c,d,A,B,E,J,h,o\\
oE & o,a,b,e,i,h,J,K,I,H,p,c,d,q,O,A,B,E\\
EB & E,J,h,o,a,b,e,i,K,I,H,p,c,d,q,O,A,B .
\end{array}                                             \tag{3}
\]
The two noninterlacing four-terminal
pairings have these disjoint spanning paths:
\[
\begin{array}{c|l}
\{ao,EB\}
 &(a,o),\quad(E,J,h,i,K,I,e,b,c,p,H,O,q,d,A,B)\\
\{aB,oE\}
 &(a,b,e,I,H,p,c,d,q,O,A,B),\quad(o,h,i,K,J,E).
\end{array}                                             \tag{4}
\]
Every consecutive pair in (3)--(4) is
an edge of (1)--(2), and each row
covers all eighteen vertices exactly
once. The old-cycle parity gives
\(a,E\) one colour and \(o,B\)
the other, excluding \(aE,oB\)
as single-path pairs. The third
two-path pairing \(\{aE,oB\}\)
interlaces the four disk terminals.
Thus (3)--(4) are the complete
square signature.

To certify the Barnette-class comparison,
cap \((a,o,E,B)\) by a fresh square
\((t_B,t_E,t_o,t_a)\), with attachments
\(Bt_B,Et_E,ot_o,at_a\). The path (1),
followed by \(t_B,t_E,t_o,t_a,a\),
is a Hamilton cycle of the resulting
22-vertex graph. Its complementary
matching is
\[
 ab,\ cd,\ AB,\ hJ,\ iK,\ eI,\ pH,\ qO,\
 ot_o,\ Et_E,\ t_Bt_a.                                \tag{5}
\]
Draw \(ab,cd,AB,t_Bt_a\) on one page
of this cycle. On the other, draw
\(ot_o\supset hJ\supset iK\supset
eI\supset pH\supset qO\), with
\(Et_E\) also inside \(ot_o\)
and disjoint from the other nested
chords. Each page is noncrossing,
and each matching edge joins
opposite cycle parities. The cap
is simple, cubic, bipartite and
plane. Its chord-interlacement graph
has a connected spanning subgraph:
\[
 ab-ot_o-t_Bt_a-Et_E-AB-pH-cd,
\quad
 AB-\{hJ,iK,eI,qO\}.                                  \tag{6}
\]
Each dash is endpoint alternation
in the displayed Hamilton order.
As in [Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md),
a two-edge cut would give a proper
matching-closed Hamilton-cycle interval
and disconnect this interlacement graph.
The Hamilton cycle excludes bridges;
in a cubic graph the absence of
one- and two-edge cuts implies
three-vertex-connectivity. Thus
the cap is a Barnette graph.

Deleting one vertex from \(Q_1\)
leaves it connected. Indeed, its
single, short, and double blocks
are cycles; the first and last
have three joins \(hJ,iK,eI\),
the short and last have three
joins \(dA,pH,qO\), and the
first and short have \(bc\).
These joins use distinct endpoints
within each three-edge family,
so deleting one vertex cannot
separate the surviving block cycles.
After deleting two patch vertices,
every surviving patch component
has a surviving terminal: otherwise
the same deletion would disconnect
the three-connected cap. The square
has the same two deletion properties.
The four-attachment comparison of
[Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md)
therefore preserves three-connectivity
in both replacement directions;
the terminal colours and cyclic order
preserve bipartiteness and planarity.
The six-state signature proves the
Hamilton-decision transfer.

**Arbitrary corridor length.** In \(Q_j\),
the four vertices \((q_j,d_j,A,O)\)
induce the square
\[
 q_jd_j,\quad d_jA,\quad AO,\quad Oq_j,
\]
with one exterior attachment at
each vertex. Replace this square
by the even ladder \(L_4\) of
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
whose two rails are
\[
 (q_j,p_{j+1},q_{j+1},O),
 \qquad(d_j,c_{j+1},d_{j+1},A),
\]
and whose four rungs join corresponding
rail vertices. The old-cycle segment
\(q_j,d_j,A,O\) becomes
\[
 q_j,d_j,c_{j+1},p_{j+1},
 q_{j+1},d_{j+1},A,O.
\]
The new complementary matching edges
are \(q_jp_{j+1},c_{j+1}d_{j+1},
q_{j+1}O\), precisely the next
short block and links of (1)--(2).
This gives \(Q_{j+1}\) from \(Q_j\).

Note 178's exact ladder replacement
preserves each spanning patch routing
and its exterior decisions, so induction
gives the six-state signature of every
\(Q_m\). Starting from the Barnette cap
above, the same replacements give a
Barnette cap for each \(Q_m\).
They preserve connectivity after one
patch-vertex deletion: the ladder
minus one vertex remains connected,
and each exterior component still
has a surviving attachment, as in
the square predecessor. The cap
then supplies the two-deletion
terminal property. The same
four-attachment comparison proves
two-way Barnette-class preservation
for every \(m\).

**Marked realization.** Start with the
26-vertex Barnette parent in the
realization of Note 380. Its 14-vertex
pole has terminal order \((a,J,E,B)\).
Replace that pole by \(Q_1\),
identifying the four attachment
labels as \(a\mapsto a,\ J\mapsto o,\
E\mapsto E,\ B\mapsto B\).
The terminal colours and order agree.
The replacement gives a 30-vertex
Barnette parent by the proved
four-pole theorem. Explicitly,
insert \(c,p,q,d\) between \(b,A\)
in Note 327's old Hamilton cycle
(5) and use the complementary
matching
\[
\begin{split}
\{&xy,ab,cd,AB,uv,\alpha\beta,\delta R_1,
\gamma L_1,\\
  &e_0o,hJ,iK,eI,pH,qO,Eo_3\}.
\end{split}                                             \tag{7}
\]
The face-side chords in (7) are
\(xy,ab,cd,AB,uv,\alpha\beta\);
all others are nested or disjoint
on the opposite page, with
\(\delta R_1\) enclosing
\(e_0o\), the five nested
cross-return chords, \(Eo_3\)
and \(\gamma L_1\).
Thus the site edges remain
cofacial and the selected opening
is still compressed, gapless,
tight-target and all-square.
The exact signature transfers
Note 380's Hamilton cycle through
both site edges. For \(m=1\), an explicit pair of
internally disjoint \(x\)--\(v\) paths is
\[
\begin{split}
&x,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,e_0,o,a,b,e,i,h,J,K,I,H,p,c,d,q,O,A,B,E,o_3,u,v.
\end{split}                                             \tag{8}
\]
The second path uses \(xy,uv\), and the two paths cover
all thirty vertices. Its legal
site-expanded child is Barnette
because the patch replacement
commutes with the site expansion,
and Hamiltonian by
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md).
Now perform the internal \(L_4\)
replacements above \(m-1\) times.
They preserve the same opening,
both site marks, Barnette membership
and the marked Hamilton cycle,
giving a \(26+4m\)-vertex parent
and its legal child for every
\(m\ge1\). \(\square\)

**Standard short flanks.** The adjacent terminal pairs
\(ao\) and \(EB\) of \(Q_m\) are edges. Its six-state
signature and the one- and two-deletion properties proved
above meet every hypothesis of
[Note 367](367-square-signature-four-poles-are-closed-under-standard-short-buffers.md).
Hence adding any \(r,s\ge0\) standard short buffers on
the two sides gives a \(14+4(m+r+s)\)-vertex four-pole
with the exact square signature and the same two-way
Barnette and exterior-marked Hamilton transfer. Applying
these insertions to the marked parent above gives a
\(26+4(m+r+s)\)-vertex Barnette parent with the selected
opening and a Hamilton cycle through both site edges;
its legal site-expanded child is Hamiltonian. Reflection
also gives the reversed double--single block order.

The theorem proves an exact reduction
for the specified cross-return matching
at every positive short-corridor length.
It does not classify all matchings
when a short corridor is present,
nonstandard short flanks outside the two vacant
blocks, other opening types, or
Barnette's conjecture. The proof is
project-internal and has not had
independent review.
