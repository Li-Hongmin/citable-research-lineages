> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Four chord-free profiles remain at the \(12f+2\) boundary

[Note 476](476-a-six-terminal-square-splice-closes-the-chorded-equality-boundary.md) lowers the chorded single-hexagon failure bound to \(12f\) reduced vertices. The chord-free bound of [Note 465](465-two-four-port-pairings-close-the-nested-four-root-end-gap.md) remains \(12f+2\). Its equality profiles follow from the same refined ordinary-forest charge, without a graph census.

Let a doubly ladder-reduced chord-free selected single-hexagon child with \(f\ge7\) have ordinary-chord count \(c=5f-8\). Write \(m\) for half the assignable special positions, \(R\) for the number of ordinary roots, \(M_0\) for marked ordinary nodes, \(L\) for leaves, \(A\) for marked-or-branching nodes, and \(Q\) for two-special leaves, as in [Notes 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md) and [415](415-escape-confinement-shaves-six-vertices-from-the-single-hexagon-kernel.md). The charge is
\[
 c\le3A-Q\le2(M_0+L)+m-3R\le5m-3R,\qquad m\le f+1.
\tag{1}
\]

**Equality classification.** If the expanded child is non-Hamiltonian, exactly one of the following necessary profiles holds:

| \(m,R\) | marked nodes and leaves | direct special positions |
|---|---|---|
| \(f-1,1\) | \(M_0=L=f-1\) | every leaf has two |
| \(f,2\) | \(M_0=f,\ L=f-1\) | one marked unary node has two; every leaf has two |
| \(f+1,3\) | \(M_0=f+1,\ L=f-1\) | two marked unary nodes have two each; every leaf has two |
| \(f+1,3\) | \(M_0=L=f\) | one leaf has four; every other leaf has two |

In every row equality holds throughout the refined bound \(c\le3A-Q\): every permitted ordinary wrapper chain is saturated, and every nonleaf marked node listed in the table is unary rather than branching. The table is a necessary classification, not an assertion that any row has a Barnette realization or a non-Hamiltonian child.

**Proof.** If \(m\le f-2\), (1) gives \(c\le5f-13\). At \(m=f-1\), equality \(c=5f-8=5m-3\) forces \(R=1\) and \(M_0=L=m\), giving the first row.

At \(m=f\), [Note 457](457-single-hexagon-failures-have-at-most-six-plus-twelve-f-vertices.md) excludes \(R=1\) for a non-Hamiltonian chord-free child, while \(R\ge3\) gives \(c\le5f-9\). Thus \(R=2\). The all-leaf profile \(M_0=L=f\) is Hamiltonian by [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md). The charge in (1) therefore requires \(M_0+L=2f-1\), necessarily \(M_0=f,L=f-1\). All \(2f\) assigned special positions occur two per marked node. Here \(Q=f-1\) and \(A\le M_0+L-R=2f-3\); hence
\[
 c\le3(2f-3)-(f-1)=5f-8.
\]
Equality forces the single marked nonleaf node to be unary, giving the second row.

At \(m=f+1\), [Note 457](457-single-hexagon-failures-have-at-most-six-plus-twelve-f-vertices.md) excludes \(R\le2\) for a non-Hamiltonian child. For \(R\ge5\), (1) gives \(c\le5f-10\). At \(R=4\), [Note 465](465-two-four-port-pairings-close-the-nested-four-root-end-gap.md) closes the all-leaf profile \(M_0=L=m\), while every non-all-leaf profile has \(M_0+L\le2m-1\) and then \(c\le5f-9\). Thus \(R=3\). Equation (1) forces \(M_0+L\ge2f\). The sum \(2f+2\) is the Hamiltonian all-leaf profile of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md). The sum \(2f+1\) has \(M_0=f+1,L=f,Q=f\) and one marked nonleaf node. If that node branches, it overlaps the branch count and gives \(A\le2f-3\), hence \(c\le3(2f-3)-f=5f-9\). Otherwise it is unary and is Hamiltonian by [Note 462](462-three-root-split-unary-splice-and-sharper-single-hexagon-kernel.md). Thus the only remaining sum is \(2f\), with \((M_0,L)=(f+1,f-1)\) or \((f,f)\).

In the first case every marked node receives two assigned positions; \(Q=f-1\) and \(A\le M_0+L-R=2f-3\), so equality in \(c\le3A-Q\le5f-8\) makes the two nonleaf marked nodes unary. In the second case all marked nodes are leaves. The \(2(f+1)\) assigned positions give one four-special leaf and \(f-1\) two-special leaves; the same values \(Q=f-1,A\le2f-3\) force equality in the wrapper charge. This gives the last two rows. \(\square\)

At \(f=8\), these are the only possible chord-free 98-vertex reduced failure profiles. The six-terminal splice of Note 476 may apply to a leaf-only subinterval in a row, but it does not by itself settle the four different escape/root placements.
