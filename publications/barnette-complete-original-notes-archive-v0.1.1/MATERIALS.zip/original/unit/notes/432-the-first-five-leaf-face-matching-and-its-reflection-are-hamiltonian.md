> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first five-leaf face matching and its reflection are Hamiltonian

[Note 431](431-the-short-third-leaf-comb-has-a-marked-cycle-and-the-last-comb-has-two-port-signatures.md) reduces the last word in [Note 427](427-the-first-five-leaf-matching-reduces-to-six-short-wrapper-words.md), with depth vector $(1,3,4,6,6,5,2)$ and short leaf 6, to two exact 40-vertex port signatures. Here the second signature has an explicit two-path cover. Consequently every legal child under row I of [Note 426](426-five-leaf-face-matchings-have-three-unresolved-shapes.md), and by reflection row II, is Hamiltonian.

Use the ordinary word
\[
 K=F(U_4,U_5),\qquad S=F(K,U_6^{\rm short}),\qquad
 R=F(U_3,S),\qquad L=F(U_2,R),\qquad
 T=F(L,U_7),\qquad W=F(U_1,T),                      \tag{1}
\]
where $F(P,Q)=(((P Q)))$ and $U_6^{\rm short}=(x_6y_6)$ has old-cycle order $L_6,x_6,y_6,R_6$. A full leaf $U_i$ has the paths $O_i,X_i$ of [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md), equation (1). Branch brackets carry the notation of that note.

**Inner two-path lemma.** The vertices of $K$ have the following disjoint covering paths:
\[
\begin{aligned}
P_K&=(x_5,y_5),\\
Q_K&=(K_\ell,\lambda_1^K,\lambda_2^K,
       L_4\xrightarrow{O_4}R_4,
       L_5,h_5,j_5,R_5,
       \rho_2^K,\rho_1^K,K_r).
\end{aligned}                                                     \tag{2}
\]
Here $K_\ell=\lambda_0^K$ and $K_r=\rho_0^K$. Within $Q_K$, $h_5j_5$ is an ordinary leaf chord; all other steps are consecutive old-cycle edges. Thus $P_K$ uses two vertices and $Q_K$ the remaining sixteen vertices of $K$. The short leaf has the two disjoint covering edges $(x_6,L_6)$ and $(R_6,y_6)$.

These pieces give the two disjoint spanning paths of $R$ required by signature 2 of Note 431:
\[
\begin{aligned}
P_R:\quad x_5,y_5,x_6,L_6,K_r
 &\xrightarrow{Q_K^{-1}}K_\ell,
 \lambda_2^S,\lambda_1^S,S_\ell,
 R_3\xrightarrow{O_3^{-1}}L_3,
 \lambda_2^R,\lambda_1^R,R_\ell;\\
Q_R:\quad R_r,\rho_1^R,\rho_2^R,S_r,
 &\rho_1^S,\rho_2^S,R_6,y_6.
\end{aligned}                                                     \tag{3}
\]
The edge $y_5x_6$ in $P_R$ is a face chord of row I. Every other join in (3) is an old-cycle edge: $L_6K_r$, $K_\ell\lambda_2^S$, $S_\ell R_3$, $L_3\lambda_2^R$, $\rho_2^RS_r$, and $\rho_2^SR_6$. The left and right bracket triples of both $S$ and $R$ appear in (3) exactly once. The leaves $U_3,U_4,U_5$ and the four vertices of $U_6^{\rm short}$ likewise appear exactly once. Therefore $P_R:x_5\to R_\ell$ and $Q_R:R_r\to y_6$ are vertex-disjoint and cover all $40$ vertices of $R$.

**Last-comb theorem.** Substitute the two paths (3) into Note 431's signature-2 route. Explicitly, with the bracket paths $P_W,Q_T,J_L$ from Notes 428 and 431, and $Z_7=(x_7,h_7,L_7,R_7,j_7,y_7)$, the route is
\[
\begin{aligned}
y_1\xrightarrow{Y_1}L_1,
&\lambda_2^W\xrightarrow{P_W}\rho_2^W,
\rho_0^T\xrightarrow{Q_T}\lambda_2^T,
L_\ell\xrightarrow{J_L}R_r,
\xrightarrow{Q_R}y_6,\\
&x_7\xrightarrow{Z_7}y_7,
x_5\xrightarrow{P_R}R_\ell,
R_2\xrightarrow{X_2}x_2.
\end{aligned}                                                     \tag{4}
\]
The three jumps not given by ordinary edges are precisely the available face chords $y_6x_7$, $y_7x_5$, and $y_5x_6$ (the last inside $P_R$). All other joins between displayed pieces in (4) are old-cycle edges: $L_1\lambda_2^W$, $\rho_2^W\rho_0^T$, $\lambda_2^TL_\ell$, $\rho_2^L R_r$, and $R_\ell R_2$. The pieces partition the six full leaves, the short leaf and the six branch wrappers, hence all $76$ vertices of $W$. Formula (4) is therefore a spanning $y_1$--$x_2$ path.

For every legal completion of this word, append its two site edges and the fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), to obtain a parent Hamilton cycle containing both site edges. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it through the legal square expansion. Notes 428--431 already give such a cycle for the other five necessary row-I words of Note 427. Since Note 427's classification covers every hypothetical non-Hamiltonian legal row-I child, no such child exists. Reflection gives the same conclusion for row II of Note 426. \(\square\)

This closes matching rows I and II only in the two-eligible, chorded single-hexagon $f=7,c=31$ kernel. The remaining matching shapes IV/V and VI, the other eligibility counts and opening types, and Barnette's conjecture remain unresolved.
