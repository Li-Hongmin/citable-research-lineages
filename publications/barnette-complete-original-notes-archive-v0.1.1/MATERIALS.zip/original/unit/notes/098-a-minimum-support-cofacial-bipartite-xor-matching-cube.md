> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A minimum-support cofacial bipartite XOR matching cube

[Note 097](097-a-cofacial-bipartite-xor-matching-cube-needs-sixteen-toggle-ports.md)
proves that any ordered-cofacial plane bipartite common-matching XOR cube
needs at least sixteen toggle ports.  That lower bound is attained.

There is a 28-vertex simple connected plane bipartite four-terminal graph,
cubic away from its four degree-two terminals, with four perfect matchings
\(P_{ij}\) such that

\[
P_{00}\mathbin\triangle P_{11}=C_4\mathbin{\dot\cup}C_{12},
\tag{1}
\]

and every matching complement consists of exactly two spanning terminal
paths, with no closed component, in the table

\[
00:I,\qquad 10:E,\qquad 01:E,\qquad 11:I.
\tag{2}
\]

The terminals are cofacial in the prescribed cyclic order.  The common
complement contains two same-cycle return paths on the \(C_{12}\), exactly
as required by Note 096.  Consequently both restrictions obtained in
Notes 096--097 are sharp: a return path is necessary, and sixteen is the
minimum total number of toggle ports.

This graph is not asserted to be a legal-wide inverse-square interface or a
brace.  It refutes the stronger proposed principle that ordered cofaciality,
planarity, bipartiteness and a common perfect-matching cube alone exclude
the double-\(E\) transition.

## 1. The graph

Let

\[
A=a_0a_1a_2a_3a_0,
\qquad
B=b_0b_1\cdots b_{11}b_0,
\tag{3}
\]

and let the ordered terminals be \(t_0,t_1,t_2,t_3\).  Add the ten
common-complement paths

\[
\begin{array}{llll}
t_0x_0b_1,&b_0x_1b_{10},&b_{11}x_2a_0,&a_1x_3b_2,\\
b_3t_1,&t_2x_5b_5,&b_4a_2,&a_3x_7b_6,\\
b_7x_8b_9,&b_8x_9t_3.
\end{array}
\tag{4}
\]

The two same-cycle returns are

\[
b_0x_1b_{10},
\qquad
b_7x_8b_9.
\tag{5}
\]

Finally add the common matching

\[
K=\{x_0x_1,x_2x_3,x_7x_8,x_5x_9,t_0t_1,t_2t_3\}.
\tag{6}
\]

The resulting graph \(R\) has 28 vertices and 40 edges.  One bipartition
is specified by

\[
\operatorname{col}(a_i)=i\pmod2,
\qquad
\operatorname{col}(b_j)=1+j\pmod2,
\tag{7}
\]

\[
(\operatorname{col}(t_0),\ldots,\operatorname{col}(t_3))=(0,1,0,1),
\tag{8}
\]

and

\[
\begin{array}{c|cccccccc}
v&x_0&x_1&x_2&x_3&x_5&x_7&x_8&x_9\\ \hline
\operatorname{col}(v)&1&0&1&0&1&0&1&0.
\end{array}
\tag{9}
\]

Every edge joins opposite colours.  Each terminal has one path edge and
one edge of \(K\); every other vertex has degree three.

## 2. The four matching complements

For either even cycle \(Z=z_0\ldots z_{2m-1}z_0\), write

\[
S_Z^s=\{z_{2r+s}z_{2r+1+s}:0\le r<m\},
\qquad s\in\{0,1\},
\tag{10}
\]

with subscripts taken modulo \(2m\).  Define

\[
P_{ij}=K\cup S_A^{1-i}\cup S_B^{1-j}.
\tag{11}
\]

The three sets in (11) are disjoint and cover every vertex exactly once,
so each \(P_{ij}\) is a perfect matching.  Its complement uses all ten
paths in (4), the smoothing \(S_A^i\), and the smoothing \(S_B^j\).
Direct traversal gives exactly two components in every state.  Their
terminal pairs are

\[
\begin{array}{c|c|c}
(i,j)&\text{terminal pairs}&\text{numbers of vertices on the two paths}
\\ \hline
(0,0)&(t_0t_1)(t_2t_3)&14,14\\
(1,0)&(t_0t_3)(t_1t_2)&18,10\\
(0,1)&(t_0t_3)(t_1t_2)&18,10\\
(1,1)&(t_0t_1)(t_2t_3)&18,10.
\end{array}
\tag{12}
\]

There is no closed component.  Since only the two cycle smoothings vary,

\[
P_{00}\mathbin\triangle P_{11}=E(A)\mathbin{\dot\cup}E(B),
\tag{13}
\]

which proves (1)--(2).

## 3. Ordered cofaciality

Cofaciality is certified directly rather than inferred from planarity after
adding a terminal rim.  Add a new apex \(z\) adjacent to all four
terminals.  The verification bundle contains an explicit rotation system
for this 29-vertex augmented graph.  It has 44 edges and 17 faces, so

\[
29-44+17=2.
\tag{14}
\]

The cyclic order around \(z\) is

\[
t_0,t_1,t_2,t_3
\tag{15}
\]

up to reversal.  Deleting \(z\) and its four incident edges therefore
leaves a plane embedding of \(R\) in which the terminals lie on one face
in the prescribed order.

Cutting this embedding along \(A\cup B\) gives three Jordan regions.  Their
numbers of toggle ports and terminals are

\[
(0,0),\qquad(10,0),\qquad(6,4).
\tag{16}
\]

In each region both the port sign sum and the terminal sign sum are zero,
and every edge of \(K\) stays inside its region.  Thus the regional law of
Note 096 is not only numerically feasible here; the matching \(K\)
actually realizes it.

## 4. Exact boundary

The construction attains equality in the support bound of Note 097.  It
also shows that the regional conservation equations of Note 096 are not
sufficient: the two return paths in (5) permit all regions to balance, and
the common matching (6) realizes that balance without losing cofaciality.

Thus the cofacial-pairing lemma needed by the earlier existential
normalization programme cannot follow from plane bipartite cubic incidence,
ordered cofaciality, or the existence of one common matching cube.  Any
valid positive theorem must use additional labelled inverse-square geometry,
legal-wide gate placement, brace structure, or flexibility of the complete
perfect-matching fibre.

No minimum vertex order is claimed.  The word *minimum* refers only to the
sixteen toggle ports, whose optimality is Note 097.

The graph, four matchings, complement paths, bipartition and augmented
rotation are frozen in the
[verification bundle](../computations/bundles/minimum-support-cofacial-xor-lift/README.md).
