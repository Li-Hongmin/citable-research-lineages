> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Middle-gap split-unary openings with two exposed face chords are Hamiltonian

[Note 481](481-disconnected-two-root-split-unary-openings-are-hamiltonian.md) closes the disconnected root face graph for the two-root equality profile of [Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md). The connected middle-gap order also closes: its only possible leaf-switch separations either give a different terminal pairing, violate three-connectivity or matching parity, or admit a path through the split node's child.

Use order B of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md):
\[
 w_0,t_d,W_1,t_c,z_1,z_2,t_b,W_2,t_a,w_*,
\tag{1}
\]
followed by the old arc \(w_*,\alpha,a,b,c,d,\beta,w_0\). Let \(q=w_0u\), \(p=vw_*\), where the site ports \(u,v\) lie in the roots. Both \(z_i\) are face-chord endpoints, with mates \(r_1,r_2\) in the roots. All other assigned special positions occur in two-special ordinary leaves, except the two directly assigned positions \(s,t\) of one marked unary node \(N\), in the split order \(H,s,A,t,J\). The root face graph \(K\) joins \(W_1,W_2\) when a face matching chord runs between them. Ordinary wrappers are unrestricted.

**Two-exposed-chord middle-gap theorem.** If \(K\) is connected, the parent has a Hamilton cycle containing both \(p,q\), and its legal expanded child is Hamiltonian. By Note 481, the child is Hamiltonian in this order-B, two-exposed-face-chord case for either state of \(K\).

**Proof.** Let \(L,R\) be the first and last vertices of \(A\), with ordinary chord \(LR\). Use the two disjoint cycles from (3) of Note 458:
\[
\begin{aligned}
 D_1&=(W_{1,\ell}\xrightarrow{\rm old}W_{1,r},t_c,c,d,t_d,W_{1,\ell}),\\
 D_2&=(W_{2,\ell}\xrightarrow{\rm old}W_{2,r},t_a,a,b,t_b,W_{2,\ell}).
\end{aligned}
\tag{2}
\]
Write \(D=D_1\cup D_2\). Let \(E\) contain the square-supported old edge at each two-special leaf, and let \(M\) match every assigned special position except the four terminals \(T=\{u,r_1,v,r_2\}\). Form
\[
                 F=(D-E-\{sL,Rt\})\cup M\cup\{LR\}.
\tag{3}
\]
Every nonterminal of \(F\) has degree two and its four terminals have degree one. Thus \(F\) is two paths and some cycles. Each nonloop edge of \(E\) has the disjoint square switch of Note 458. If \(A\) itself is a two-special leaf, its square edge is a loop in the component quotient because \(LR\) is already in \(F\).

If \(F\cup E\) is connected, the four-terminal spanning-tree argument of Note 458 gives two spanning two-path covers with different pairings of \(T\). The fixed exterior paths
\[
              (u,w_0,\beta,\alpha,w_*,v),\qquad
              (r_1,z_1,z_2,r_2)
\tag{4}
\]
cover all vertices outside \(D\), contain \(p,q\), and pair \((u,v)(r_1,r_2)\). One internal pairing differs and hence closes a single Hamilton cycle.

Suppose \(F\cup E\) is disconnected. Cutting \(sL,Rt\) in the cycle containing \(N\) leaves the child arc \(A\), closed by \(LR\), and its complementary arc \(B\); the other whole cycle is \(O\). Restoring \(E\) connects each of these three pieces internally. Since \(K\) is connected, at least one \(M\)-edge joins \(O\) to \(A\) or \(B\). Disconnectedness therefore gives exactly one of the partitions
\[
                        A\mid(B\cup O),\qquad
                        B\mid(A\cup O).
\tag{5}
\]
Each component of \(F\cup E\) contains zero, two, or four terminals, because every path component of \(F\) contains two terminals. The isolated piece \(A\) or \(B\) lies wholly in the root containing \(N\). Call a terminal pair *mixed* if it consists of one site port and one exposed mate; the other two-terminal possibilities are \(\{u,v\}\) and \(\{r_1,r_2\}\).

If both sides of (5) have two terminals and the isolated side has a mixed pair, switch the leaf squares within each side until its cycles join its unique terminal path. Both internal pairs are then mixed, so this pairing differs from \((u,v)(r_1,r_2)\). Together with (4), it is one Hamilton cycle through \(p,q\).

An isolated \(A\) cannot have zero terminals. It then has no site or exposed-face-chord attachment, no \(M\)-edge leaving it, and no ordinary third edge leaving its interval. Only its two old boundary edges \(sL,Rt\) leave \(A\), contrary to three-connectivity of the cubic parent.

If \(B\) has zero terminals and \(A\cup O\) has all four, square switches within \(B\) give one spanning cycle \(Z\); within \(A\cup O\) they give two spanning two-path covers with distinct terminal pairings. All switches lie in ordinary leaf squares, so they preserve the escape edges of (2). If \(N\subseteq W_1\), then \(B\) contains \(t_dd\). Delete this edge from \(Z\), and connect its ends to the terminals using
\[
       (u,w_0,t_d),\qquad(d,\beta,\alpha,w_*,v),\qquad
       (r_1,z_1,z_2,r_2).
\tag{6}
\]
Together with \(Z-t_dd\), these paths pair \((u,v)(r_1,r_2)\). If \(N\subseteq W_2\), then \(B\) contains \(t_aa\). Delete that edge and use
\[
       (u,w_0,\beta,\alpha,a),\qquad(t_a,w_*,v),\qquad
       (r_1,z_1,z_2,r_2).
\tag{7}
\]
Again the exterior plus \(Z\) pairs \((u,v)(r_1,r_2)\). In either case choose the available \(A\cup O\) pairing that differs. The union is one spanning Hamilton cycle containing both site edges.

It remains to handle a two-terminal isolated side with a same-type pair. First suppose \(A\) is isolated and its terminals are \(u,v\). All other special positions in \(A\) are matched inside \(A\), and each belongs to a two-special leaf. Apply the open-arc square-switch theorem of Note 458 to the old \(L\)--\(R\) arc of \(A\): among its two distinct spanning four-port pairings on \(L,R,u,v\), at least one pairs \(L\) with a site port and \(R\) with the other. In the root cycle consisting of the whole old root arc plus its root chord, the complementary arc from \(s\) to \(t\), followed by \(sL\) and \(Rt\), is an \(L\)--\(R\) path through every root vertex outside \(A\). Joining it to that four-port cover gives a spanning \(u\)--\(v\) path in the root. For \(N\subseteq W_2\), the exterior spanning \(w_0\)--\(w_*\) path is (2) of [Note 480](480-adjacent-unary-two-root-chord-free-openings-are-hamiltonian.md). For \(N\subseteq W_1\), use
\[
 w_0,t_d,d,\beta,\alpha,a,b,c,t_c,z_1,z_2,t_b,
 W_{2,\ell}\xrightarrow{\rm old}W_{2,r},t_a,w_*.
\tag{8}
\]
Both paths use only available old, trap, and escape edges and cover every vertex outside the site root. The site edges close the root path to a Hamilton cycle.

Next suppose \(B\) is isolated and carries \(\{u,v\}\) or \(\{r_1,r_2\}\). Since \(K\) is connected, choose a face matching chord between \(A\) and the other root \(O\). If \(N\subseteq W_1\), write it \(xy\) with \(x\in A\), \(y\in W_2\). If \(B\) carries \(u,v\), the site chord \(vw_*\) forces \(v<x\), so both site terminals lie in the prefix of \(W_1\) before \(A\). If \(B\) carries \(r_1,r_2\), noncrossing of \(xy\) with each \(r_i z_i\) forces \(x<r_i\), so both exposed-mate terminals lie in the suffix after \(A\). In either case the side containing the two terminals has one of \(s,t\), complete two-special leaves, and exactly two omitted matching endpoints; it therefore has an odd number of \(M\)-endpoints. No \(M\)-edge joins that prefix to the suffix: such a chord would interlace \(xy\). Isolation of \(B\) forbids an \(M\)-edge from that side to \(A\) or \(O\). Thus its odd set of endpoints would have to match internally, a contradiction. If \(N\subseteq W_2\), write the chosen chord \(yx\) with \(y\in W_1\), \(x\in A\). The site chord \(w_0u\) puts a \(\{u,v\}\) pair after \(A\), while the chords \(z_i r_i\) put a \(\{r_1,r_2\}\) pair before \(A\). The same interlacing and odd-count argument applies.

Finally suppose \(A\) is isolated and carries \(r_1,r_2\). We give the parity argument explicitly, since now the other root joins \(B\). If \(N\subseteq W_1\), choose a face chord \(xy\) from \(x\in B\cap W_1\) to \(y\in W_2\). Noncrossing with \(r_i z_i\), where \(r_i\in A\), forces \(x<r_i\); hence \(x\) lies before \(A\). Any site port in \(W_1\) lies before \(x\), since otherwise its site chord crosses \(xy\). The suffix after \(A\) therefore contains \(t\), complete two-special leaves, and no terminal: it has an odd number of \(M\)-endpoints. It cannot send an \(M\)-edge to \(A\), by isolation; to \(W_2\), because this would cross \(r_i z_i\); or to the prefix before \(A\). Indeed, a prefix endpoint before \(x\) would give a chord crossing \(xy\), while one after \(x\) would give a chord crossing \(r_i z_i\). The suffix cannot be internally matched. If \(N\subseteq W_2\), choose \(yx\) with \(y\in W_1\), \(x\in B\cap W_2\). Noncrossing with \(z_i r_i\) forces \(x>r_i\), so \(x\) lies after \(A\), and every site port in \(W_2\) lies after \(x\). The prefix before \(A\) contains \(s\), complete two-special leaves, and no terminal, hence an odd number of \(M\)-endpoints. Edges from that prefix to \(A\) are excluded by isolation, edges to \(W_1\) cross \(z_i r_i\), and edges to the suffix cross either \(z_i r_i\) or \(yx\). This is the same contradiction.

There is one further terminal distribution: all four terminals may lie in the root containing \(N\). If this is \(W_1\), noncrossing of \(p=vw_*\) with \(r_i z_i\) puts both site ports before both exposed mates. Every chord \(xy\) from \(W_1\) to \(W_2\) has its \(W_1\)-end \(x\) strictly between \(v\) and each \(r_i\): \(x<v\) would cross \(p\), while \(x>r_i\) would cross \(r_i z_i\). If the isolated side is \(A\), all four terminals are in its one interval, but a \(K\)-chord must leave \(B\) to join the other root; its endpoint cannot be between the two terminal groups inside \(A\). If the isolated side is \(B\), a \(K\)-chord leaves \(A\), so the site pair lies before \(A\) and the exposed-mate pair after \(A\). Each side of \(B\) has one of \(s,t\), complete two-special leaves, and exactly two terminals, leaving an odd number of \(M\)-endpoints. Isolation forbids matching outside \(B\), and any chord between its two sides crosses the \(K\)-chord through \(A\). This is impossible. If all four terminals lie in \(W_2\), reverse the argument: noncrossing of \(q=w_0u\) with \(z_i r_i\) puts the exposed mates before the site ports, while every \(K\)-chord ends strictly between each \(r_i\) and \(u\). An isolated \(A\) again cannot contain both terminal groups, and an isolated \(B\) again has two odd, mutually unmatchable sides.

All cases yield a marked Hamilton cycle. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the legal child. \(\square\)

**Boundary.** This closes order B when both \(z_1,z_2\) are exposed face-chord endpoints, for all placements of \(u,v,r_1,r_2\) in the roots. The one-exposed-site case of order B and the connected-\(K\) cases of orders A and C require separate arguments; the other three-root two-unary equality profile of Note 477 is also separate.
