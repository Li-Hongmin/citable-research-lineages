> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Common cubic Hamilton incidence does not force the FEC support bound

[Note 031](031-remote-h-plus-minus-and-faithful-completion-leave-a-common-realization-interface.md)
left open the support-function inequality

\[
 \min_{S\in\mathcal X}w\cdot d(S)
 \le w\cdot\mathbf1
 \qquad\text{for every }w,
 \tag{1}
\]

where

\[
 \mathcal X=
 \mathcal B(\mathcal P_X)\cap\mathcal B(\mathcal G_Q)
\]

and \(d(S)\) is the load on the \(Y\)-partition blocks.  This note gives a
strict common-incidence countermodel to (1).  The two endpoint partitions,
all perfect matchings, all Hamilton complements, and the remote
global-\(H^{+-}\) quantifiers arise from the same cubic bipartite graph.
The countermodel fails only at the remaining plane-dual realization axiom.

## The common cubic Hamilton system

Let

\[
 E=\{e_{xy}:x,y\in\{0,1,2\}\}
\]

be the nine labelled edges of \(K_{3,3}\).  Let \(\mathcal P_X\) and
\(\mathcal P_Y\) be the actual endpoint partition matroids.  Their six
common bases are the six perfect matchings indexed by permutations of
\(\{0,1,2\}\).

The complement of every perfect matching of \(K_{3,3}\) is a Hamilton
6-cycle.  Each edge occurs in exactly two of the six perfect matchings, and
distinct edges have distinct two-element supports.  If

\[
 I(e)=\{M:e\in M\},
\]

then, for every ordered pair of distinct edges,

\[
 I(f)\setminus I(e)\ne\varnothing.
 \tag{2}
\]

Thus this one common cubic matching system satisfies the complete
global-\(H^{+-}\) ordered-edge condition of Note 031, rather than an
independently attached abstract Sperner family.

## A graphic matroid on the same ground

Assign a third colour to each edge by the matrix

\[
 \begin{array}{c|ccc}
       &y_0&y_1&y_2\\ \hline
 x_0&0&0&0\\
 x_1&0&0&1\\
 x_2&0&1&2.
 \end{array}
 \tag{3}
\]

Let \(Q_0\) be a four-vertex path with one parallel class on each of its
three links, placing every colour-\(i\) edge on link \(i\).  A base of
\(\mathcal G_{Q_0}\) selects one edge of each third colour.

There are exactly three
\(\mathcal P_X\)-\(\mathcal G_{Q_0}\) common bases.  Their
\(Y\)-load vectors are

\[
 (1,0,2),\qquad (0,1,2),\qquad (0,0,3).
 \tag{4}
\]

There are also three
\(\mathcal P_Y\)-\(\mathcal G_{Q_0}\) common bases, and the two endpoint
partition matroids have their six perfect matchings as common bases.
Hence all three pairwise base intersections are nonempty.  No perfect
matching, however, is rainbow in the third colour, so the triple
intersection is empty.

The support-function failure is stronger than triple emptiness.  For the
single layer-set weight

\[
 w=(0,0,1)=\mathbf1_{\{y_2\}},
 \tag{5}
\]

equation (4) gives

\[
 \min_{S\in\mathcal X}w\cdot d(S)=2
 >1=w\cdot\mathbf1.
 \tag{6}
\]

Consequently, decomposing a general weight into nested \(0/1\) layer sets
cannot prove (1): the obstruction already occurs on one layer.

## Exact boundary

The construction proves

\[
 \boxed{
 \begin{gathered}
 \text{common cubic perfect-matching incidence}
 +\text{ actual Hamilton complements}\\
 +\text{ global }H^{+-}
 +\text{ all pairwise common bases}
 \end{gathered}
 \not\Longrightarrow (1).}
 \tag{7}
\]

It is not a counterexample to the direct \(P\)-regime target.  The graph
\(K_{3,3}\) is nonplanar, has no deleted-vertex cofacial site of the
required kind, and \(Q_0\) is not obtained by contracting the dual of the
same graph.  In particular, its parallel-link blocks do not obey the
triangle, path, and parallel-pair rotations inherited from one simple
4-connected Eulerian triangulation.

Thus the only remaining axiom capable of forcing the support bound is the
literal ambient identity

\[
 \boxed{
 Q=(F^*/\{p^*,h^*\})[E(K)^*]}
 \tag{8}
\]

together with the two face-colour rotations inherited from the same plane
brace.  A positive weighted proof must convert a layer defect into a
forbidden cut using this actual planar rotation.  Global \(H^{+-}\), even
when realized by the same cubic matching system as both endpoint
partitions, does not provide that conversion.

This note does not decide the separate integrality question from Note 031:
if the all-one load belongs to the load convex hull, the existence of an
integral all-one base remains open under the full ambient hypotheses.

The countermodel is reproduced by

```bash
uv run --python 3.12 --with networkx \
  units/barnette/scratch/worker-barnette/support-function-common-incidence-countermodel.py
```

with terminal marker
`SUPPORT_FUNCTION_COMMON_INCIDENCE_COUNTERMODEL_VERIFIED`.
