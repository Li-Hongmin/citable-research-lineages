> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(A/Z\) interpolation fixes boundary state but not connectivity

Use the setting and decorated traversal notation of Note 015.  Thus
\(p=uv,q=xy\) is a legal cofacial \(C_4\)-expansion site, \(r\) is a
retained edge, \(A\) denotes a Hamilton cycle containing \(p,q\), and \(Z\)
denotes a nonliftable Hamilton cycle avoiding both \(p,q\).

This note gives a canonical interpolation forced by a positive decorated
failure.  Planarity determines the correct boundary pairing, but a real
Barnette graph shows that the interpolation does not preserve complement
connectivity.

## A positive failure forces an \(A/Z\) pair

Assume

\[
A\in T_r^+.
\tag{1}
\]

If \(B\notin T_r^+\), apply parent global \(H^{+-}\) to the ordered pair
\((r,q)\).  The resulting Hamilton cycle contains \(r\) and avoids \(q\).
If it contained \(p\), it would be a \(B\)-witness in \(T_r^+\); hence it
must also avoid \(p\), and is a \(Z\)-cycle containing \(r\).  The same
argument with \(p,q\) interchanged applies when \(C\notin T_r^+\).

Therefore every positive failure of either \(B\)- or \(C\)-decoration
supplies Hamilton cycles \(K_A,K_Z\), both containing \(r\), whose
complementary perfect matchings satisfy

\[
p,q,r\notin M_A,
\qquad
p,q\in M_Z,\quad r\notin M_Z.
\tag{2}
\]

In particular,

\[
r\notin M_A\mathbin\triangle M_Z,
\tag{3}
\]

so every component or subpath flip inside this symmetric difference
preserves the required \(r\)-incidence.

## Exact boundary interpolation

The symmetric difference \(M_A\triangle M_Z\) is a disjoint union of
alternating cycles containing \(p,q\).

If \(p,q\) lie on distinct components, flipping either component in \(M_A\)
gives a perfect matching with the boundary membership of a \(B\)- or
\(C\)-matching, respectively, while preserving (3).  This conclusion is
only boundary-correct: the new complementary 2-factor need not remain a
Hamilton cycle.

Suppose instead that \(p,q\) lie on the same alternating Jordan cycle.
Deleting \(p,q\) splits that cycle into two alternating paths.  The common
face lies on the same side at the two distinguished edges.  With facial
order \(u,v,\ldots,x,y,\ldots\), planarity rules out the crossing pairing,
so the two paths have endpoint pairing

\[
(uy)(vx).
\tag{4}
\]

Each path begins and ends with an \(M_A\)-edge.  Flipping the two paths
separately therefore gives degree-correct near-perfect matchings exposing
\(u,y\) and \(v,x\), respectively.  They are precisely boundary-correct
candidates for \(D=X_{vx}\) and \(E=X_{uy}\), and (3) again preserves the
\(r\)-coordinate.

Thus a positive decorated failure has no remaining degree or endpoint
pairing ambiguity.  The only missing assertion is that one of the
boundary-correct flips can be chosen with connected complement, and that
the same \(r\)-slice also supplies the required \(L\)-witness when needed.

## Connectivity fails for the canonical partial flip

The 12-vertex hexagonal prism has edge set

\[
\begin{split}
\{&01,03,0\,11,12,18,23,27,34,45,4\,11,56,5\,10,\\
  &67,69,78,89,9\,10,10\,11\}.
\end{split}
\tag{5}
\]

It is a Barnette graph with global \(H^{+-}\).  Use the legal square site

\[
(u,v,x,y)=(10,9,6,5),
\qquad p=9\,10,\quad q=5\,6,
\tag{6}
\]

and the matchings

\[
\begin{aligned}
M_A&=\{03,18,27,4\,11,5\,10,6\,9\},\\
M_Z&=\{03,12,4\,11,56,78,9\,10\}.
\end{aligned}
\tag{7}
\]

Their complements are Hamilton cycles, with \(M_A\) avoiding \(p,q\) and
\(M_Z\) containing both.  The component of \(M_A\triangle M_Z\) containing
\(p,q\) is the square

\[
\{56,5\,10,6\,9,9\,10\}.
\tag{8}
\]

After deleting \(p,q\), its two alternating paths are the single edges
\(5\,10\) and \(6\,9\).  The corresponding near-perfect matchings are

\[
M_A\setminus\{5\,10\},
\qquad
M_A\setminus\{6\,9\}.
\tag{9}
\]

Both have the correct exposed vertices, but in \(R=G-\{p,q\}\) each
complement has two components, on

\[
\{0,1,2,3,4,5,10,11\}
\quad\text{and}\quad
\{6,7,8,9\}.
\tag{10}
\]

Hence neither partial flip produces a spanning cross path.  Taking
\(r=01\) makes both source Hamilton cycles contain \(r\), while taking
\(r=03\) makes both avoid \(r\).  The same graph therefore exhibits the
connectivity failure on both incidence slices.  Its complete traversal
family nevertheless satisfies the decorated normal forms of Note 015, so
this is a counterexample to the canonical interpolation route, not to the
preservation theorem.

## Remaining asymmetry

The positive failure has the useful forced \(A/Z\) pair above.  A maximal
negative failure

\[
T_r^-\subseteq\{A,D\}
\qquad\text{or}\qquad
T_r^-\subseteq\{A,E\}
\tag{11}
\]

is more rigid: global \(H^{+-}\) applied to \((p,r)\) and \((q,r)\) may
return only \(A\)-cycles.  A fixed \(A\)-cycle and its matching chord \(r\)
do not automatically supply a same-\(r\)-incidence \(Z\)-, \(B\)- or
\(C\)-cycle, so alternating interpolation need not even start.

Consequently the mixed blocks still require a genuine incidence-preserving
cycle-coalescence or quotient-tree selection theorem.  Circular order and
ordinary component/path flips determine the boundary state, but do not
control the number of complementary components.

The fixed graph calculation is included in

```text
python3 units/barnette/scratch/worker-c4-hpm/verify_planar_bc_component_flip_boundary.py
```

with terminal marker

```text
PLANAR_BC_COMPONENT_FLIP_BOUNDARY_VERIFIED
```
