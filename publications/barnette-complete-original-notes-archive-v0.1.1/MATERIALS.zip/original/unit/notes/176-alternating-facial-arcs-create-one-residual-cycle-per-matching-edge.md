> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Alternating facial arcs create one residual cycle per matching edge

[Note 174](174-brace-cross-openings-avoid-a-forbidden-matching-edge.md)
guarantees a jointly marked cross opening in a plane brace, but its
quotient need not be a tree. The following topological rule completely
counts the components for an opening that literally follows one
facial arc. It requires neither 2-extendability nor bipartiteness.

Let \(G\) be a simple cubic plane graph with a Hamilton cycle \(C\),
and let \(M=E(G)\setminus E(C)\) be its complementary perfect matching.
Choose disjoint \(p=uv,q=xy\in M\) on a common facial cycle, with
the two facial arcs between them running from \(v\) to \(x\) and from
\(y\) to \(u\). Form the usual square expansion, and start with the
child 2-factor \(C\dot\cup Q\).

**Facial-arc theorem.** Suppose one of the two residual facial arcs
is a simple path \(P\) of length \(2k+1\) whose edges alternate
\(C,M,C,\ldots,M,C\). Close \(P\) through the corresponding three-edge
route around the new square and flip the resulting alternating
cycle. The opened child 2-factor has exactly \(k+1\) components:
one contains the new square and the other \(k\) are old cycles.
Equivalently, the quotient \(K(P)\) of Note 174 has \(k+1\)
components: all \(k\) quotient edges are loops on distinct
vertices, and the last vertex is isolated. This literal facial
opening is Hamiltonian exactly when \(k=0\).

**Proof.** Label the vertices of \(P\), in facial order, as
\(z_0,z_1,\ldots,z_{2k+1}\). Its \(C\)-edges and matching edges are
\[
h_i=z_{2i}z_{2i+1}\quad(0\le i\le k),
\qquad
m_i=z_{2i-1}z_{2i}\quad(1\le i\le k).
\tag{1}
\]
View the sphere on the side of the Jordan curve \(C\) containing
the common face as a disk. The matching edges on this side are
noncrossing chords of the disk. The vertices on the boundary of
any face in this chord diagram occur in the same cyclic order as
on \(C\), up to simultaneous reversal. Indeed, draw the boundary
vertices in convex position and straighten the noncrossing chords;
a simple polygon using convex-position vertices in a different
order would have two crossing sides. Orient \(C\) to agree with
the facial order of \(P\).
Its selected edges then occur in the order \(h_0,h_1,\ldots,h_k\).

For each \(i\ge1\), the two endpoints of \(m_i\) are consecutive
vertices of the facial boundary. Hence the directed \(C\)-arc from
\(z_{2i-1}\) to \(z_{2i}\) contains no other selected \(h_j\).
After deleting all \(h_0,\ldots,h_k\), this arc is one path
component, and adding \(m_i\) closes it into a cycle.
The resulting residual cycle is precisely
\[
\bigl(z_{2i-1}Cz_{2i}\bigr)\cup\{m_i\},
\qquad 1\le i\le k,
\tag{2}
\]
where the \(C\)-arc follows the chosen orientation.
These \(k\) arcs are disjoint by their cyclic order on \(C\).
The only remaining component is the \(C\)-path from
\(z_{2k+1}\) to \(z_0\), which the new square path
closes into a cycle. Flipping changes exactly these old edges and
the square attachment, so there are exactly \(k+1\) components.
\(\square\)

**Opposite-side escape corollary.** If \(G\) is also bipartite and
3-edge-connected, each of the \(k\) trapped \(C\)-segments in (2)
has at least two matching edges to vertices outside that segment.
Every such edge lies on the side of \(C\) opposite the common face.

Indeed, let \(S_i\) be the vertices of the directed \(C\)-arc in
(2). The only \(C\)-edges in \(\delta_G(S_i)\) are
\(h_{i-1}\) and \(h_i\), while \(m_i\) stays inside \(S_i\).
Because \(m_i\) joins opposite colour classes, this \(C\)-arc has
an even number of vertices. Hence its cubic edge cut has even
size. Three-edge-connectivity makes that size at least four, so
at least two crossing edges belong to \(M\). A matching chord
crossing from the interior of \(S_i\) to outside on the face side
would interlace and cross \(m_i\), which is impossible in the
plane. The two or more crossing matching edges therefore lie
on the opposite side of \(C\). These escape edges exist, but the
corollary makes no claim that they can be combined into a
marked tree connector.

**Escape-network theorem.** Assume \(k\ge1\) and that \(G\) is
3-edge-connected. Contract each of the \(k+1\) \(C\)-segments
left by deleting \(h_0,\ldots,h_k\) to a vertex, and retain
every matching edge joining distinct segments. Call the resulting
multigraph \(J(P)\). Then \(J(P)\) is connected and has a
noncrossing drawing in the disk on the side of \(C\) opposite
the common face. If \(G\) is also bipartite, every vertex of
\(J(P)\) has positive even degree. Thus \(J(P)\) is Eulerian.
In particular, every escape edge lies on a cycle of \(J(P)\).
Deleting any one escape edge therefore leaves \(J(P)\) connected.
This includes the edge of any prescribed forbidden old matching
edge \(f\), when \(f\) joins two distinct segments; the remaining
network has a spanning tree avoiding \(f\). It is a statement
about the escape network, not about a Hamilton opening.

Every edge of \(J(P)\) meets at least one of the \(k\) trapped
segments, because only one segment contains the new-square path.
Such a matching edge must lie opposite the face by the chord
argument above. This gives the noncrossing drawing. Suppose
\(J(P)\) were disconnected. In a noncrossing graph whose vertices
lie cyclically on a disk boundary, some connected component
occupies a consecutive block of boundary vertices. To see this,
choose a component whose smallest containing boundary interval
is shortest. If it skips a boundary vertex between two
consecutive vertices of its own,
a path within the component and that boundary interval enclose
another whole component, giving a shorter span. Let \(W\) be
the consecutive block thus obtained. The union of its original
\(C\)-segments has exactly two \(C\)-edges in its edge cut,
and no matching edge crosses that cut, since \(W\) is a whole
component of \(J(P)\). This is a 2-edge cut of \(G\), contrary
to 3-edge-connectivity. Hence \(J(P)\) is connected.

When \(G\) is bipartite, each trapped segment has even order,
as above; the remaining segment does too because \(|V(G)|\)
is even. A perfect matching crosses the boundary of an
even-order vertex set an even number of times, so every degree
in \(J(P)\) is even. A single segment has exactly two
departing \(C\)-edges; 3-edge-connectivity and even degree
give degree at least two in \(J(P)\). \(\square\)

**Two-sided overlay lemma.** Let \(F_P\) be the opened child
2-factor, and contract its \(k+1\) components. Every child edge
joining distinct contracted components belongs either to \(J(P)\)
or to one of the old \(C\)-edges \(h_0,\ldots,h_k\). The latter
form a cycle
\[
S_0S_1S_2\cdots S_kS_0
\tag{3}
\]
on the contracted components, allowing two parallel edges when
\(k=1\). Here \(S_0\) is the component containing the new square.
For any child 2-factor \(D\), the overlay edges used by \(D\)
have even degree at every \(S_i\). If \(D\) is Hamiltonian, those
used edges form a connected spanning even subgraph of the
two-sided overlay.

To see the edge classification, the facial cyclic order puts the
other site ports \(u,y\) on the remaining \(C\)-segment \(S_0\).
Thus every unused patch edge has both ends in \(S_0\). The
\(m_i\) close the trapped segments inside their own components.
Every other old edge outside \(F_P\) is either one of the cut
\(h_i\), joining consecutive segments, or a matching edge
recorded by \(J(P)\) when it joins distinct segments. A cycle
crosses every vertex cut an even number of times, proving the
parity assertion. A single Hamilton cycle must also connect all
contracted components. In particular, choosing only a spanning
tree of \(J(P)\) cannot lift directly to a child 2-factor:
its leaves would have odd overlay degree. The cut-edge cycle
(3), and the local attachment order inside each \(S_i\), remain
part of the tree-selection problem. \(\square\)

**Prism forcing corollary.** In the even-prism family \(G_r\to H_r\)
of Note 172, take the literal top-face alternating arc from
\(T_2\) to \(T_{2r+1}\). It cuts exactly
\[
h_j=T_{2j}T_{2j+1}\qquad(1\le j\le r).
\tag{4}
\]
Its escape network is a cycle on \(r\) vertices, with edges
\[
f_j=B_{2j}B_{2j+1}\qquad(1\le j\le r);
\tag{5}
\]
for \(r=2\) the cycle consists of two parallel edges. For every
\(j\), any Hamilton cycle of \(H_r\) avoiding \(f_j\) contains
at least one edge of (4). Such an \(f_j\)-avoiding Hamilton cycle
exists by Note 172's global \(H^{+-}\) theorem for \(G_r\) and
the one-step \(H^-\) theorem of
[Note 013](013-h-plus-minus-parent-forces-a-p2-hamiltonian-c4-child.md).

Indeed, the \(r-1\) trapped segments are the four-vertex paths
\[
T_{2j+1},B_{2j+1},B_{2j+2},T_{2j+2}
\qquad(1\le j\le r-1).
\]
The edges (5) join the remaining main segment to the first
trapped segment, then consecutive trapped segments, then the
last one back to the main segment; every other matching edge
stays within a segment. If a Hamilton cycle avoided \(f_j\)
and every edge of (4), its intercomponent projection would be
a connected spanning even subgraph of the cycle \(J(P)-f_j\).
That graph is a path, which has no such subgraph. \(\square\)

For \(k=0\), deleting the single facial edge from \(C\) gives a
spanning cross path directly. For \(k=1\), a three-edge alternating
facial arc necessarily traps one old cycle. For general \(k\), every
matching edge on the literal facial return traps its own old cycle.
This does not rule out a nonfacial tree connector; the prism paths
in [Note 172](172-unbounded-nonlocality-of-joint-hamilton-witness-transfer.md)
give explicit nonfacial repairs. In that family the literal top-face
arc has length \(2r-1\) and therefore leaves \(r-1\) old cycles,
whereas the first marked detour leaves \(r-2\). The unresolved
planar problem is to select such a connector, with any required
marks, at arbitrary long-gap sites.
