> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact single-lobe chord packing and Hamiltonicity

[Note 190](190-fixed-lobe-chord-amplification-preserves-two-hamilton-witnesses.md)
constructs all opposite-face chord counts at a fixed
square-trap lobe count. In the single-lobe case, a simple
facial spacing argument matches its free-vertex count.
At equality, planarity and three-edge-connectivity also
force the entire reduced matching, so every such
site-expanded child is Hamiltonian.

Use the legal Barnette expansion and all-square facial
opening of Notes 176--179. Compress its sole lobe by
Note 178, leaving one residual square. Let the parent
Hamilton cycle \(C\) avoid the cofacial matching site
edges \(q=xy,p=uv\), with old main segment \(S_0\)
ordered \(x<y<u<v\). Let \(r\ge1\) be the number of
edges of \(M=E(G)\setminus E(C)\) on the other
\(y\)-to-\(u\) site-face arc.

**Facial spacing lemma.** In fact, with any number of
lobes, or without assuming square residual components,
\[
|V(S_0)|\ge4r+8.
\tag{1}
\]
If equality holds, the \(x\)-to-\(y\) and \(u\)-to-\(v\)
cycle subpaths both have length three, the \(r\) face
matching chords each span a cycle subpath of length
three, and these \(r\) four-vertex subpaths partition
the open \(C\)-interval \((y,u)\). Consequently the
other site-face arc is alternating and has length
\(2r+1\).

**Proof.** By the facial boundary-order lemma of
Note 176, the face matching chords have endpoints in
successive, disjoint \(C\)-intervals
\[
y<a_1<b_1<a_2<b_2<\cdots<a_r<b_r<u.
\tag{2}
\]
Each \(a_ib_i\) joins opposite bipartite colours and
is distinct from a \(C\)-edge. Its \(C\)-distance is
therefore odd and at least three, so \([a_i,b_i]_C\)
contains at least four vertices. The intervals in (2)
are disjoint, hence \((y,u)\) contains at least \(4r\)
vertices. Likewise \(xy,uv\in M\) are not \(C\)-edges,
so each of \((x,y)\) and \((u,v)\) contains at least two
vertices. Together with the four site ports this gives
(1).

At equality every one of these lower bounds is an
equality. Thus \(y\) is followed immediately by \(a_1\),
each \(b_i\) immediately precedes \(a_{i+1}\), and
\(b_r\) immediately precedes \(u\). These intervening
edges are on \(C\), so the face arc alternates them
with \(a_ib_i\). \(\square\)

For \(\ell\) square-trap lobes, (1) is the additional
free-vertex bound
\[
f=|V(S_0)|-2\ell-4\ge4r+4-2\ell.
\tag{3}
\]
For one lobe this reads \(f\ge4r+2\), attained by
Note 190 for every \(r\). The following theorem
classifies equality rather than just its count.

**Single-lobe equality theorem.** Suppose the all-square
opening has one lobe and
\[
|V(S_0)|=4r+8
\quad\text{or, equivalently,}\quad f=4r+2.
\tag{4}
\]
After lobe compression the parent graph, its embedding
relative to \(C\), and the two site edges are uniquely
determined up to reversal of \(C\) and reflection of the
plane by \(r\). They are the
single-lobe marked-amplifier family of Note 190. In
particular the parent has a Hamilton cycle containing
both \(p,q\), and the site-expanded child is Hamiltonian.
The conclusion transfers to any positive original
lobe length.

**Proof.** The spacing lemma writes the main segment
in the exact order
\[
x,o_1,o_2,y,\,
a_1,g_1,h_1,b_1,\,
a_2,g_2,h_2,b_2,\,
\ldots,\,
a_r,g_r,h_r,b_r,\,
u,o_3,o_4,v.
\tag{5}
\]
Here \(a_ib_i\), \(xy\), and \(uv\) are the matching
edges on the common-face side of \(C\).
The compressed residual square has two escape edges
to target vertices \(R<L\) on \(S_0\). By Note 179,
\(R\) has odd and \(L\) even \(S_0\)-index. They must
occupy two of the \(2r+4\) *slots*
\[
o_1,o_2,g_1,h_1,\ldots,g_r,h_r,o_3,o_4,
\tag{6}
\]
whose parity alternates odd/even. All other slots are
paired by \(M\).

Every matching edge between two non-target slots lies
opposite the common face. Indeed, \(g_i,h_i\) are
adjacent on \(C\), so they cannot match each other.
A chord from either of them to another slot interlaces
the face chord \(a_ib_i\), forcing it to the opposite
side. Similarly \(o_1,o_2\) and \(o_3,o_4\) are
adjacent pairs, so they cannot match internally;
any chord between the left and right outer pairs
interlaces the site edge \(xy\). On the opposite side,
a chord between slots cannot straddle \(R\) or \(L\):
it would cross that target's escape edge to the
complementary \(C\)-arc.

We first force \(R=o_1\). Otherwise \(o_1\) is free.
It cannot match \(o_2\), and its mate cannot lie after
\(R\). Colour parity makes its mate some \(h_j\)
preceding \(R\). All slot chords lie on the same side
and do not cross, so every slot strictly between
\(o_1\) and \(h_j\) is matched within that interval.
The full cyclic interval \([x,b_j]_C\) is then closed
under \(M\): it also contains both ends of \(xy\)
and of every \(a_ib_i\) for \(i\le j\), and no
escape target. Its only two departing graph edges
are its two \(C\)-edges. This contradicts
three-edge-connectivity. Reversing \(S_0\) and
exchanging \(p,q\) gives \(L=o_4\).

The remaining slots are
\[
o_2,g_1,h_1,g_2,h_2,\ldots,g_r,h_r,o_3.
\tag{7}
\]
The mate of \(o_2\) is either \(g_j\) or \(o_3\).
If \(j>1\), noncrossing forces all slots in the
complete blocks \(1,\ldots,j-1\) to match among
themselves. Then \([a_1,b_{j-1}]_C\) is closed
under \(M\), a forbidden two-edge cut. If the mate
is \(o_3\), the same argument makes
\([a_1,b_r]_C\) a two-edge cut. Thus
\(o_2g_1\in M\). Apply the identical argument to
the first remaining slot \(h_1\), then \(h_2\),
and so on. It forces exactly
\[
o_2g_1,\qquad h_i g_{i+1}\ (1\le i<r),
\qquad h_r o_3
\tag{8}
\]
as the nonface internal matching edges.

The residual square has its closing matching edge
on the common-face side and its two escape edges
to \(o_1,o_4\) on the opposite side, by Notes
176--179. Thus (5) and (8), with the site and
face chords, specify every edge and its side of
\(C\). For \(r=1\) this is Note 184's same-gap
core. Expanding the facial square
\(a_1,g_1,h_1,b_1,a_1\) at the opposite edges
\(a_1b_1,g_1h_1\) changes (5)--(8) for \(r\)
into the same formulas for \(r+1\), after
relabeling the first two four-vertex blocks. Explicitly,
if \(z_1,z_2,z_3,z_4\) are the four new vertices in
the order of Note 190's \(h_1,h_2,h_3,h_4\), the old
first block becomes
\[
(a_1,g_1,z_4,z_1),\qquad
(z_2,z_3,h_1,b_1).
\tag{9}
\]
The new matching edge \(z_4z_3\) joins the two new
filler pairs; every old later block shifts one place.
This square is facial because its three cycle edges
are consecutive, its closing chord is on the face
side, and the matching edges at \(g_1,h_1\) lie on
the opposite side.
Note 190's marked-amplifier proof therefore gives
this uniquely specified graph a Hamilton cycle
through \(p,q\) for every \(r\). Note 001 lifts
that cycle to the site-expanded child. Finally,
Note 178 transfers the Hamilton decision back
through any longer lobe ladder. \(\square\)

This theorem exactly determines the free-vertex minimum
and the Hamilton decision *at that minimum* for a
single square-trap lobe, at every opposite-face chord
count \(r\ge1\). It makes no Hamilton claim above
that minimum or for several lobes.
