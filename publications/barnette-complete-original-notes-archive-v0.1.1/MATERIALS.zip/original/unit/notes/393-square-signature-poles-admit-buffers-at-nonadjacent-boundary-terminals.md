> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Square-signature poles admit buffers at nonadjacent boundary terminals

[Note 367](367-square-signature-four-poles-are-closed-under-standard-short-buffers.md)
adds a short square at a pair of adjacent terminals when those
terminals are also joined by an edge inside the old pole. The edge
condition is unnecessary once the old pole is already known to be
exactly square-equivalent. The replacement can be made before and
after the buffer is attached.

Let \(T\) be a finite bipartite plane disk four-pole with distinct
degree-two terminals \((x,y,z,w)\) in cyclic order, all other vertices
of degree three. Assume it has precisely the square's four spanning
one-path and two spanning two-path Hamilton states, and that its
labeled replacement by the square preserves Barnette membership
in both directions and every exterior- and attachment-marked
Hamilton decision in any Barnette host. No edge \(xy\) is assumed.

Take a fresh square \(S=(A,O,E,B,A)\), join \(Bx,Ey\), and move the
two exterior attachment labels from \(x,y\) to \(A,O\), respectively.
The old \(x,y\) become internal; \(z,w\) keep their attachment
labels. Call the resulting disk pole \(T^+\). The joining square
fits in the boundary interval between the consecutive terminals
\(x,y\). Repeating this construction at any consecutive terminal
pair is allowed, with no internal adjacency requirement.

**Terminal-buffer theorem.** The pole \(T^+\) has exactly the
square's four-terminal Hamilton signature in order \((A,O,z,w)\).
Replacing \(T^+\) by the labeled square, or conversely, preserves
Barnette membership and all exterior- and attachment-marked
Hamilton decisions. The same holds after any finite sequence of
such buffers at consecutive current terminal pairs. Each step
adds four vertices.

**Proof.** Replace the induced subpole \(T\) inside \(T^+\) by its
labeled square \(Q=(x,y,z,w,x)\). The result is two squares joined
by the two disjoint edges \(Bx,Ey\). Since \(x,y\) are adjacent on
\(Q\), this eight-vertex graph is the four-column ladder \(L_4\)
with outer terminals \((A,O,z,w)\). [Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
proves that \(L_4\) has exactly the square's six spanning path
states and that its labeled replacement by a square preserves
the Barnette class and all exterior Hamilton decisions in both
directions.

To verify the first replacement in an arbitrary spanning path
or disjoint path pair of \(T^+\), restrict the linkage to \(T\).
Its restriction covers every vertex of \(T\), has no closed
component, and meets \(T\)'s four attachments in two or four
edges. It is therefore one spanning terminal path or two
disjoint spanning terminal paths. The exact signature of \(T\)
replaces that restriction by a route in \(Q\) with the same used
attachment edges and terminal pairing. The converse replacement
works identically. Thus \(T^+\) and \(L_4\) have identical
outer linkage signatures; composition with Note 178 gives the
asserted exact square signature.

For the class assertion, suppose a Barnette host contains
\(T^+\). The subpole \(T\) has four distinct attachment edges:
\(Bx,Ey\) and the exterior edges at \(z,w\). Its assumed
two-way comparison replaces it by \(Q\) while preserving the
Barnette class. The resulting host contains \(L_4\) as an
induced disk four-pole, so Note 178 replaces \(L_4\) by the
outer square. Conversely, start from a Barnette host with that
outer square, expand it to \(L_4\) by Note 178, and replace its
\(Q\) end square by \(T\). Both intermediate hosts are Barnette.
At each replacement the exterior edges and their attachment
choices are fixed, so their composition preserves every stated
Hamilton decision. The square can be drawn in the boundary
interval, and its alternating terminal colours extend those
of \(T\). Induction proves the finite-sequence statement.
\(\square\)

**Single–double application.** Let \(T\) be any no-flank
`tJ` pole of Notes 383 and 389, with terminals \((a,J,E,B)\).
Add one left short block \(S_0=(c,p,q,d)\) with bridges
\(da,qJ\), while its first free slot has the ordinary end link
\(tp\). The old terminal pair \((a,J)\) is consecutive around
the pole but need not be joined by an edge. The resulting whole
group, with terminals \((c,p,E,B)\), is exactly the buffer
above. Hence every such actual matching has an exact square
reduction, regardless of the other free groups. This includes
the standard first left edge \(tp\) followed by a nonstandard
virtual return \(qJ\), a case outside Note 367's stated
edge-adjacency hypothesis.

The theorem requires an already established exact four-pole
substitution, not merely a spanning route or a one-way
Hamilton lift. It does not classify which flank matching
words occur, other vacancy types or opening types, and it
does not decide Barnette's conjecture. This is a project-
internal analytic proof without external priority or
independent review.
