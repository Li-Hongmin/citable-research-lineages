> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Existence-level C4 lifting survives through reduced order eighteen

[Note 065](065-the-degree-four-reduction-has-a-realizable-locked-nae-boundary.md)
shows that a prescribed-edge facewise-NAE target colouring need not lift
through a degree-four inverse reduction.  The correct induction quantifier
is therefore not to lift an arbitrary witness, but to select a liftable
witness from the complete reduced target family.  This note translates the
locked state into perfect-matching language, determines its exchange
boundary in the smallest realized example, and proves that the
existence-level selection succeeds for every reduced plane brace through
order \(18\).

## The locked state is a facial matching pattern

Let \(T'=F'^*\), let \(z\in V(T')\) correspond to a face \(C\) of the
simple plane cubic bipartite brace \(F'\), and write the boundary edges of
\(C\) cyclically as

\[
f_0,f_1,\ldots,f_{m-1}.
\]

If \(x_i\) is the dual neighbour of \(z\) across \(f_i\), then
\(f_i^*=zx_i\).  Let \(w_i\) be the common endpoint of \(f_i,f_{i+1}\)
and let \(h_i\) be the third edge at \(w_i\).  Choose two nonconsecutive
gate edges \(f_\alpha,f_\beta\); their dual neighbours split the rotation
at \(z\) into the two closed arcs used by Note 065.

A facewise-NAE colouring \(c'\), normalized by \(c'(z)=0\), gives a
perfect matching \(M\) of \(F'\) by taking the primal edges dual to its
monochromatic edges.  On \(C\),

\[
f_i\in M\quad\Longleftrightarrow\quad c'(x_i)=0,
\tag{1}
\]

and

\[
h_i\in M
\quad\Longleftrightarrow\quad
c'(x_i)=c'(x_{i+1})=1.
\tag{2}
\]

Indeed, the triangle \(zx_ix_{i+1}\) has exactly one monochromatic edge.
The three possible nonmonochromatic colour patterns select respectively
\(f_i,f_{i+1}\), or \(h_i\).  In particular, consecutive boundary edges
of \(C\) cannot both belong to \(M\).

An arc whose two gates have colour zero is alternating exactly when its
matching alternates completely along the face boundary and uses no third
edge \(h_i\) at an internal boundary vertex.  Consequently the locked
state (L) of Note 065 has the exact primal form

\[
\boxed{
f_\alpha,f_\beta\in M,\quad
\text{and each of the two open boundary segments contains some }h_i\in M.}
\tag{3}
\]

Thus the obstruction is not merely four local colours.  It records that
both gate edges are matched and that both sectors have genuine
off-face matching activity.

For a prescribed primal edge \(e=a^*\) not on \(C\), define the reduced
target family

\[
\mathcal T_e=
\left\{
M:\begin{array}{l}
M\text{ is a perfect matching of }F',\ e\in M,\\
F'-M\text{ has exactly two cycles, and the ends of }e\\
\text{ lie on different cycles}
\end{array}
\right\}.
\tag{4}
\]

By [Note 063](063-rca-and-the-direct-two-path-target-have-distinct-exact-dual-forms.md),
\(\mathcal T_e\) is exactly the prescribed-edge target-colouring family
modulo global colour complementation.  The existence-level \(C_4\) lift
asks whether some member of \(\mathcal T_e\), not a preselected member,
passes one of the finite colour rows of Note 065(3) together with its
rooted-connectivity test (5).  Formula (3) identifies one entire forbidden
subfamily, but a nonlocked matching still has to pass that global
connectivity test.

## The realized locked witness has four selectable alternatives

Use the reduced triangulation, split site, and root \(a=04\) of Note 065.
Its primal is the \(16\)-vertex brace

    O????B_sDOI_I_DO@W?M?

and the primal root edge is \(e=12\).  The two gate edges are \(03\) and
\(78\).  The complete family \(\mathcal T_e\), modulo global colour
complementation, has five members.  Exactly one is the locked witness of
Note 065; the other four remove gate \(78\) and all four lift to target
colourings of the expanded triangulation.

The symmetric differences from the locked matching exhibit two distinct
escape mechanisms.

1. Two alternatives differ on one alternating component.  In the notation
   of Note 060, that component has

   \[
   p=q=2,
   \]

   retains root separation, and removes one gate.  It directly replaces
   the locked target by another two-cycle target.
2. The other two alternatives require two disjoint alternating components.
   Flipping the first component alone has

   \[
   (p,q)=(1,2);
   \]

   it preserves root separation but changes the complementary factor from
   two cycles to three and leaves both gates matched.  Flipping the second
   alone has

   \[
   (p,q)=(2,1);
   \]

   it removes one gate and merges the two root cycles into a Hamilton
   cycle.  Neither intermediate matching is a target.  Flipping both
   components simultaneously has total \(p=q=2\), restores two separated
   cycles, and yields a liftable target.

Hence a successful family-selection theorem cannot require escape through
one alternating component, strict cycle-count descent, or a sequence whose
intermediate states all retain the rooted target.  The same realized
instance supports both a one-component escape and an irreducibly
synchronized two-component escape.

The exact five-state calculation is independently reproduced by
[the matching-anatomy verifier](../computations/verify_locked_escape_matching_anatomy.py).

## Complete existence-level theorem through order eighteen

Let \(F'\) be any simple plane cubic bipartite brace with
\(|V(F')|\le18\), let \(T'=F'^*\), and choose any vertex split of \(T'\)
along two nonconsecutive gates which produces a simple \(4\)-connected
Eulerian plane triangulation \(T\).  Let \(a\) be any edge of \(T'\) not
incident with the split vertex, so that it survives unchanged in \(T\).
If \(T'\) has a target colouring for \(a\), then it has some target
colouring for \(a\) that extends, with every surviving old vertex colour
fixed, to a target colouring of \(T\).

The source corpus is the complete through-\(18\) corpus of
[Note 064](064-the-planar-two-path-target-holds-through-order-eighteen.md):
209 connected simple cubic bipartite isomorphism classes and exactly five
plane braces, of orders \(8,12,16,16,18\).  Their embedded duals give the
following exhaustive counts:

\[
\begin{array}{lr}
\text{nonconsecutive gate pairs}&203,\\
\text{odd-arc, admissible \(4\)-connected splits}&154,\\
\text{surviving split--root interfaces}&2690,\\
\text{reduced NAE colourings modulo complement}&175,\\
\text{root--target colouring pairs}&370,\\
\text{target-colouring/interface instances}&10256,\\
\text{local three-vertex assignments tested}&82048.
\end{array}
\tag{5}
\]

Every one of the \(2690\) interfaces has a nonempty reduced target family.
Across the complete families, \(12112\) local assignments are target lifts,
and every interface has at least one.  Thus the number of
existence-level failures is zero.  This also shows that the locked witness
of Note 065 is not representative of a locked complete family anywhere in
the complete reduced range.

The accepted computation, exact aggregate certificate, environment, and
reproduction command are frozen in the
[locked-boundary escape bundle](../computations/bundles/locked-boundary-escape-through18/README.md).
The full census was independently rerun from the Note 064 source
certificate and reproduced the stored JSON byte for byte.

## Boundary

The matching translation (1)--(4) and the two exchange mechanisms are
proof-level.  The through-\(18\) assertion is an exact computer-assisted
finite theorem.  Its external coverage interfaces are nauty geng
isomorph-free completeness and the exact planarity decisions used in the
source corpus and split filter; all rotations, splits, colourings, cycle
ranks, roots, and local assignments are enumerated directly.

This does not prove the general existence-level selection lemma.  Reduced
braces of order \(20\) and above remain open.  More importantly, the fixed
example shows that an eventual proof must allow simultaneous alternating
components and temporary loss of either the two-cycle count or root
separation.  The thinnest remaining structural statement is to show that
the complete family \(\mathcal T_e\) always meets the liftable
rooted-connectivity states of Note 065(5); ordinary Kempe connectivity,
one-component escape, and monotone rooted descent are all insufficient.
