> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every consecutive two-port group with a short shared block has three routes

Notes 289 and 290 settle, respectively, the disjoint
opposed and nested same-side end-port arrangements
of two consecutive missing ordinary links. The
noncrossing atom partition leaves one further nested
case: the outer port component has vacancies on both
sides of its port. Its explicit routes in Note 285
accept an arbitrary three-state proper gap, so the
inner port component can be substituted there.

Let a Barnette parent have a compressed, gapless,
tight-target all-square opening with \(\ell,r\ge1\),
and let every vacancy lie in a distinct target-free
internal face-chord block. In one free group suppose
its only missing ordinary links are
\(P_s=e_so_{s+1}\) and \(P_{s+1}=e_{s+1}o_{s+2}\).
Assume their common internal block \(B_{s+1}\)
is short and the group's ordinary end links are
retained. No restriction is imposed on the number
or nesting of vacancy-only components.

**Consecutive two-port theorem.** The group's full
target-free internal interval \(D=B_a,\ldots,B_b\)
has all three vertex-spanning states
\[
\begin{array}{ll}
S(D):&o_a\longleftrightarrow e_b,\\
K(D):&a_a\longleftrightarrow o_a,\quad
       e_b\longleftrightarrow b_b;\\
X(D):&a_a\longleftrightarrow b_b,\quad
       o_a\longleftrightarrow e_b.
\end{array}                                             \tag{1}
\]
Each port component may have arbitrarily many vacancy
atoms on either side allowed by its relative position;
all their spacings and all vacancy-only components are
unrestricted. If every other free group has an
ordinary-endport spanning route, the parent has a
Hamilton cycle through both site edges and its legal
expanded child is Hamiltonian.

**Proof.** By Note 278, the two port atoms belong
to distinct parts of the noncrossing atom partition.
Since \(B_{s+1}\) is short, \(P_s,P_{s+1}\) are
consecutive atoms. Two parts containing consecutive
atoms have only three relative possibilities:
their atom intervals are disjoint, the first
contains the second, or the second contains the
first. Otherwise the two parts would interlace.

In the disjoint case \(P_s\) is the last atom of
its part and \(P_{s+1}\) the first of its part;
all their other atoms are vacancies. Note 289
gives \(S,K,X\) for their combined span, including
all nested vacancy-only parts.

We use the following **gap-substitution fact** from
the displayed routes of Notes 275, 282, and 285--288.
A proper block gap is used only by one of its
\(S,K,X\) states, or is crossed by an old-cycle
arc. In Note 275, prime \(S\) calls for \(K\) in
its first gap and \(S\) in later gaps; prime \(K\)
calls for \(X\) in its first gap. In Note 282,
the straight route calls for \(S\), the cap
for \(X\) in the first port gap, and the crossed
route for \(X\) in the final port gap. Note 285
uses \(S\) in its straight route and \(X\) in
the two folds of its other routes. Note 286
uses \(S\) on the right for its straight state
and \(X\) for its right continuation. Note 287's
first-gap covering paths use \(X\) and its later
ordinary segments use \(S\); Note 288's later-atom
case similarly uses \(S\) in the decorated gap,
an unchanged old-cycle arc for \(K\), and \(X\)
for the crossed continuation. None of these
steps inspects the matching inside a substituted
gap. Therefore a gap containing another port
component is valid whenever it has the required
three states and its attachments outside the gap
are the stated retained links or outer-component
matching edges.

Suppose the part of \(P_s\) contains that of
\(P_{s+1}\). Because no atom lies between the two
ports, \(P_{s+1}\) is the first atom of its part.
Its other atoms are vacancies to the right. Its
source \(B_{s+1}\) is short, so Note 282's local
prime construction gives \(S,K,X\) on its span.
Serial vacancy-only intervals around that span
inside the next outer gap join across retained
ordinary links. Hence the full gap has three
states and lies wholly in
the proper block gap between \(P_s\) and the next
vacancy atom of the outer part. Both boundaries
of that gap are free ports of its three-state
routes; the missing \(P_s\) is exterior to the gap.

If \(P_s\) has vacancies on both sides, substitute
this gap into Note 285's interior-port construction.
If it is the first atom of its part and \(B_s\)
is short, use Note 282. If it is first but
\(B_s\) is vacant in a different component, the
boundary-sharing and surrounding-component cases
of Notes 286--288 give the outer span's states.
The gap-substitution fact applies in each case:
the inner part occupies the first proper gap
after \(P_s\), while the old-cycle arcs and all
outer matching edges remain present. Thus
the outer span has \(S,K,X\), including when
\(B_s\) is vacant.

If the part of \(P_{s+1}\) contains that of
\(P_s\), reflect the preceding argument.
The inner \(P_s\) is its part's last atom and
has a short target \(B_{s+1}\). Its local
three-state span lies in the proper gap before
the outer \(P_{s+1}\). The outer component may
be an end or interior port, and its outward
block \(B_{s+2}\) may be vacant. The reflected
cases of Notes 282 and 285--288, with the same
gap substitution, give its three states. Note
290 is the explicit nested end-port subcase.

Every other vacancy-only part lies in a proper
gap of one of these port parts, is serially
disjoint, or surrounds their combined span.
Note 275's prime recursion and serial composition
give (1) for \(D\). Note 273 composes the free
groups; Notes 001 and 178 give the marked cycle,
legal expanded child, and arbitrary original
lobe lengths. \(\square\)

The interior-outer nested case is nonempty. In
Note 281(8)'s old-cycle layout take \(\ell=1\),
\(r=7\), vacant \(B_1,B_6,B_7\), and short
\(B_2,\ldots,B_5\). Retain all standard free links
except \(P_3,P_4\); use the unchanged site, face,
escape, and residual-square matching edges and add
\[
 H_1I_7,\quad I_1e_3,\quad o_4H_7,\quad
 e_4I_6,\quad o_5H_6.                              \tag{2}
\]
The first three edges are the outer component
\(V_1<P_3<V_7\); the last two are the inner
\(P_4<V_6\). They form a noncrossing perfect
matching of the remaining free slots on the disk
opposite the site face, and all join opposite
old-cycle colours. Retained links connect the
face chords up to \(B_3\) and from \(B_5\)
through \(B_7\); \(o_4H_7\) and \(e_4I_6\)
attach the face chord of \(B_4\) to the latter
chain, while \(H_1I_7\) bridges to the former.
Each other special edge interlaces an endpoint
face chord. The retained end links connect
the site/residual-square closing chain. Thus
the full interlacement graph is connected;
Notes 217 and 182 give three-vertex-connectivity.
The parent is a 46-vertex Barnette graph with
cofacial site edges; the child has 50 vertices
and both have the asserted Hamilton cycles.

The theorem closes the consecutive two-defect
branch when the shared block is short. If
\(B_{s+1}\) is vacant, its atom separates the
two port atoms and may belong to either port
component or a third vacancy-only component;
that branch remains open.
