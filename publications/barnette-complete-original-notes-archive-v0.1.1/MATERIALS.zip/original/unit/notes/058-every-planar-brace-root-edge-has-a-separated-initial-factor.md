> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every planar brace root edge has a separated initial factor

[Note 057](057-planar-two-path-covers-require-root-preserving-cycle-absorption.md)
reduces the planar prescribed two-path statement to a root-preserving
cycle-absorption problem, but leaves open whether the required separated
2-factor exists initially. Diwan's specified-edge construction supplies
exactly this initial factor.

## Separated-root factor theorem

Let \(F\) be a simple plane cubic bipartite brace, let \(rs\in E(F)\), and
let \(r\) and \(s\) belong to opposite colour classes. Then there is a
perfect matching \(M\) such that

\[
rs\in M
\tag{1}
\]

and \(r,s\) lie on distinct cycles of the complementary 2-factor

\[
D=F-M.
\tag{2}
\]

In particular, \(D\) is disconnected.

## Why Diwan's hypotheses hold for a brace

Put \(H=F-\{r,s\}\). A brace is 2-extendable. For every edge
\(f\in E(H)\), the independent two-edge matching \(\{rs,f\}\) therefore
extends to a perfect matching of \(F\). Removing \(rs\) shows that every
edge of \(H\) belongs to a perfect matching of \(H\).

Moreover, a 2-extendable graph is 3-connected, so \(H\) is connected.
Simplicity and cubicity give \(\delta(H)\ge2\). Thus \(H\) is
matching-covered. It has no bridge: if \(g=xy\) were a bridge,
the existence of a perfect matching containing \(g\) would force every
perfect matching to contain \(g\); but \(x\) has another incident edge in
\(H\), and a perfect matching containing that edge cannot contain \(g\).
Consequently

\[
F-\{r,s\}\text{ is 2-edge-connected}.
\tag{3}
\]

The graph \(F\) is 3-connected and hence 2-edge-connected. It is simple,
so \(rs\) has no parallel copy. These are precisely the hypotheses of
Diwan's Theorem 3.

## The construction gives root separation, not only disconnection

The statement of Theorem 3 says that \(rs\) belongs to a separating perfect
matching. Its proof gives the stronger root separation in (2).

Write

\[
N_F(r)\setminus\{s\}=\{a,b\},\qquad
N_F(s)\setminus\{r\}=\{u,v\},
\]

with \(a,r,s,u\) incident with one face and \(b,r,s,v\) incident with the
other face along \(rs\). Starting from \(H\), add vertices \(r',s'\) and
edges

\[
r'a,\ r'u,\ r's',\ s'b,\ s'v.
\tag{4}
\]

Diwan's Theorem 1 gives a 2-factor of this auxiliary planar cubic graph in
which \(r's'\) is a chord of a cycle \(C\). Hence \(C\) uses all four other
edges incident with \(r',s'\). Planarity implies that

\[
C-\{r',s'\}
\]

is the disjoint union of an \(a\)-\(b\) path and a \(u\)-\(v\) path. On
returning to \(F\), the first path closes through \(arb\), while the second
closes through \(usv\). They are distinct cycles containing \(r\) and
\(s\), respectively. All other cycles of the auxiliary factor remain
unchanged. The resulting 2-factor omits \(rs\), so its complement is the
required perfect matching \(M\).

The source is A. A. Diwan, *Chords of 2-Factors in Planar Cubic Bridgeless
Graphs*, **Graphs and Combinatorics** 38 (2022), Theorem 3 and its proof on
PDF page 10, DOI
[10.1007/s00373-022-02583-y](https://doi.org/10.1007/s00373-022-02583-y),
arXiv:[2110.12584](https://arxiv.org/abs/2110.12584). The statement and
proof were checked on 2026-08-26.

## Consequence for the planar two-path problem

Use the notation of Note 057: \(r\in Y\),
\(N_F(r)=\{a,b,s\}\), and the desired port split is
\(\{s\}\mid\{a,b\}\). Apply the theorem to the singleton root edge \(rs\).
It gives a 2-factor whose complementary matching contains \(rs\), whose
root cycle uses \(ra,rb\), and in which \(r,s\) are on distinct cycles.

Therefore the initial-state qualification in Note 057 can be removed:

> If root-preserving cycle absorption (RCA) holds, then repeated absorption
> starts from the factor above and terminates at exactly two cycles. The
> sufficient condition (T) of Note 057 then gives the prescribed spanning
> two-path cover.

Thus (RCA) alone is sufficient for the planar integral statement. This
does not prove (RCA), and it does not show that every separated factor can
be reduced while retaining \(rs\) in the complementary matching and
keeping \(r,s\) on distinct cycles. The direct dual-unicycle construction
of Note 057 remains an independent possible route.

Diwan's Theorem 3 and Theorem 5 play different roles. Theorem 3 constructs
the separated initial factor through an auxiliary specified-chord argument;
Theorem 5 gives only pairwise co-cyclicity and still supplies no
root-preserving decreasing move.
