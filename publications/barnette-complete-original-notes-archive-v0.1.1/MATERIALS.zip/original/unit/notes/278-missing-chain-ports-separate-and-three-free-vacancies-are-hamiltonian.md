> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Missing-chain ports separate; three distinct free vacancies are Hamiltonian

[Note 276](276-distinct-target-free-vacancies-have-only-chain-defects.md)
reduces every target-free group of distinct vacancy blocks to
missing links of the ordinary chain. Add each missing link as a
*virtual* boundary pair. Planarity then gives a noncrossing
partition of the vacancy pairs and these new port pairs.
Three-connectivity forbids two ports in one part.

Use a compressed, gapless, tight-target all-square opening with
\(\ell,r\ge1\), and suppose every vacancy lies in a different
target-free internal face-chord block. Fix one free group with
\(q\ge1\) vacant pairs \((H_i,I_i)\). Let \(c\) of the
complementary-matching edges have both ends in vacancy slots.
By Note 276, exactly
\[
 d=q-c                                                   \tag{1}
\]
ordinary links are missing. List them in increasing block order as
\(P_s=(E_s,O_s)=(e_s,o_{s+1})\), \(s\in J\), \(|J|=d\).

**Port-separation theorem.** For any \(q,d\), no two missing-link
ports belong to the same alternating component of the
noncrossing matching diagram defined below. If every component
contains a port, this free group has a spanning route with the
same ordinary endports as Note 196's standard free path.
The condition holds automatically when \(c\le1\). If every
vacancy group of the opening has such a route, the parent has
a Hamilton cycle containing both site edges \(xy,uv\), and
its legal expanded child is Hamiltonian.
These conclusions hold for unbounded \(q\), arbitrary short-block
flanks, and arbitrary positive original lobe lengths.

**The noncrossing diagram.** Delete from the boundary order the
ordinary slots of every *retained* link \(e_jo_{j+1}\in M\),
together with that link. The remaining free slots consist
precisely of the \(2q\) vacancy slots and the \(2d\) ends of
the missing links. Each pair \(H_i,I_i\) is adjacent on the
boundary; after the deletion, so is each pair \(E_s,O_s\).
Draw \(H_iI_i\) along the boundary as its actual old-cycle
edge, and draw \(E_sO_s\) as a virtual boundary arc through
the intervening face-block endpoints. Neither arc crosses
an opposite-side matching chord. By Note 276, every remaining
edge of \(M\) has both ends among these slots, and no such
edge joins two ordinary slots. The remaining \(M\)-edges
form a noncrossing perfect matching in the opposite-side disk.
No \(M\)-edge joins the two ends of one boundary pair:
\(H_iI_i\) is already an old-cycle edge and \(E_sO_s\)
is a missing link.

The Jordan-curve argument of Note 275 therefore applies to
all \(q+d\) boundary pairs, now called *atoms*. The actual
and virtual boundary arcs together with \(M\) decompose
uniquely into disjoint alternating Jordan cycles. If a
component has atoms \(t_1<\cdots<t_m\), its \(M\)-edges
join the later end of each atom to the earlier end of
the next, plus the outer edge from the earlier end of
\(t_1\) to the later end of \(t_m\). Thus its atoms
form a part of a noncrossing partition, with no singleton
part. An edge between two port atoms is impossible by
Note 276, regardless of whether those ports are adjacent
in the full boundary order.

**Why ports separate.** Suppose one component contains
two ports \(P_s<P_t\). Choose them consecutive among
the ports of that component. Consider the complete
consecutive old-cycle interval
\[
 U=B_{s+1}\cup B_{s+2}\cup\cdots\cup B_t.         \tag{2}
\]
It is nonempty, proper, and contains only target-free
internal blocks of the fixed group. The later end
\(O_s=o_{s+1}\) of \(P_s\) and the earlier end
\(E_t=e_t\) of \(P_t\) lie in \(U\); the other
two port ends lie outside. In the rainbow cycle of
their common component, the matching edges from
\(O_s\) forward to \(E_t\) pair every atom of that
component lying strictly between these ports inside
\(U\). No other component can have one atom between
\(P_s,P_t\) and another outside: that would interlace
the common component and violate noncrossing. Hence
all remaining special slots in \(U\) match internally.
Every retained ordinary link and every face-block
closing chord of \(U\) is internal as well. Thus no
matching edge leaves \(U\). Exactly its two boundary
old-cycle edges leave, contradicting three-edge
connectivity. This proves port separation.

**Spanning routes.** Whenever every component has a port,
port separation says it has exactly one. Remove
its virtual boundary arc \(E_sO_s\); what remains is
one path from \(E_s\) to \(O_s\), visiting all vacancy
slots of that component exactly once and using only
actual \(M\)-edges and old-cycle edges \(H_iI_i\).
Replace the missing ordinary link \(E_sO_s\) by this
path. Components are vertex-disjoint and their ports
are distinct, so all replacements commute. They
give the required spanning free route.
The unchanged target-and-square path of Note 196
closes the marked parent Hamilton cycle. Notes 001
and 178 give the child and the original lobes.

To see why \(c\le1\) guarantees this condition, each of
the \(d\) distinct port components has at least two atoms.
There are \(q+d=2d+c\) atoms altogether. A port-free
component would require at least two more atoms, impossible
for \(c\le1\). Hence all components contain a port.
With \(c=0\), every component consists of one port
and one vacant pair; with \(c=1\), exactly one
component has a port and two vacant pairs, and all
others have one of each.
\(\square\)

**Complete third-surplus consequence.** Suppose the
opening has exactly three vacancies, all in distinct
target-free internal blocks, with any distribution among
free groups and any planar complementary matching.
Then the parent has a Hamilton cycle containing both
site edges, and its legal expanded child is Hamiltonian.

To see this, apply the group results independently.
For a group with \(q\le3\) vacancies, \(c=0,1\) is
settled above. The case \(c=q\) is vacancy-only and
is settled by Note 275. The only remaining possibility
among these group sizes is \(q=3,c=2\), settled by
Note 277; \(q=2,c=2\) is already vacancy-only.
The group routes have the same boundary attachments
and disjoint interiors, so the disjoint-segment
splice used in Note 273 joins them into the global
free path. The fixed target-and-square path completes
the marked cycle.

The port theorem is an all-surplus structural
restriction. It does not by itself absorb port-free
vacancy cycles when \(c\ge2\). The third-surplus
Hamilton conclusion still assumes a selected tight,
gapless, all-square opening with vacancies in distinct
target-free internal blocks; target-bearing or site-block
vacancies, repeated vacancies in one block, positive gaps,
defective target order and nonsquare residual cycles
remain outside its scope.
[Note 279](279-single-mixed-vacancy-has-three-spanning-four-port-routes.md)
supplies the three spanning four-port states of one
internally attached mixed-vacancy interval.
