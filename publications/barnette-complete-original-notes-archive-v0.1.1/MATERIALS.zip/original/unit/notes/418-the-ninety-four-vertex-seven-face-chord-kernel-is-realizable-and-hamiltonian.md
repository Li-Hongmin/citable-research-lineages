> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The 94-vertex chorded seven-face-chord kernel is realizable and Hamiltonian

[Note 416](416-a-chorded-seven-face-chord-failure-has-one-seven-leaf-root.md) leaves \(c=31,32\) as the two possible ordinary-chord counts of a doubly reduced non-Hamiltonian child in the chorded single-hexagon, \(f=7\) branch. [Note 417](417-the-chorded-seven-face-chord-normal-form-has-a-ninety-two-vertex-realization.md) realizes \(c=31\) by a Hamiltonian child. The upper count \(c=32\) is likewise attainable by a genuine Barnette graph with a legal cofacial site, no serial odd-pole reduction, and a Hamiltonian child.

As before, every paired parenthesis denotes a complementary matching edge. Set
\[
U_i=((x_i y_i)),\qquad F(P,Q)=(((P Q))),
\]
\[
\begin{array}{lll}
A=F(U_3,U_4),&B=F(U_5,U_6),&C_0=F(U_2,A),\\
E=F(B,U_7),&S=F(C_0,E),&W=F(U_1,S).
\end{array}                                                     \tag{1}
\]
The word \(W\) has seven leaves, six branches, \(14+18=32\) ordinary chords, and \(42+36=78\) vertices. Its leaf depths are \(1,3,4,4,4,4,3\) in the order \(U_1,\ldots,U_7\).

Let the old cycle be
\[
C=(w_0,z_L,t_c,W,t_b,z_R,w_*,\alpha,a,b,c,d,\beta,w_0).
                                                                    \tag{2}
\]
Together with the 32 parenthesis-pair edges, take the following complementary matching:
\[
\begin{array}{c|l}
\text{site}&q=w_0y_2,\quad p=x_7w_*\\
\text{main face}&z_Lx_1,\quad y_1x_2,\quad x_3y_6,\quad y_3x_6,
                  \quad x_4y_5,\quad y_4x_5,\quad y_7z_R\\
\text{escape}&t_cc,\quad t_bb\\
\text{trapped hexagon}&\alpha\beta,\quad ad.
\end{array}                                                       \tag{3}
\]
Call the resulting graph \(G\), and let \(G^+\) be the standard \(C_4\)-expansion at the disjoint edges \(p,q\).

**Extremal realization theorem.** \(G\) is a 90-vertex Barnette graph, and \(G^+\) is a 94-vertex Barnette graph. The indicated facial opening traps exactly the internally chorded hexagon \((\alpha,a,b,c,d,\beta)\), with \((e,f,c)=(2,7,32)\). Its ordinary forest is doubly reduced and attains the upper count in Note 416. Neither sibling-leaf pair \((3,4),(5,6)\) has the joining face chord required by [Note 412](412-two-odd-ladder-poles-compose-to-one-odd-ladder-signature.md). Nevertheless both graphs are Hamiltonian: a cycle of \(G\) containing \(p,q\) is given below and lifts to \(G^+\).

**Matching, parity and embedding.** All vertices in (2) are distinct, and (3) matches every nonparenthesis vertex exactly once. Every listed matching edge has nonconsecutive endpoints on \(C\), so \(G\) is simple and cubic. Index \(w_0\) by zero. Then \(W\) occupies indices \(3,\ldots,80\), while
\[
(t_b,z_R,w_*,\alpha,a,b,c,d,\beta)=(81,82,83,84,85,86,87,88,89)
\]
as indices. A leaf at depth \(d\) in (1) has \(x_i\) of parity \(3+3d+2\pmod 2\); preceding sibling words have even length. Thus \(x_1,x_2,x_7\) have even indices, \(x_3,x_4,x_5,x_6\) odd indices, and each \(y_i\) has the opposite parity. Each ordinary chord spans an odd index difference. The matching edges (3) also join opposite parities, proving bipartiteness.

Draw the site edges, seven main-face chords, \(\alpha\beta\) and \(ad\) on one side of \(C\). The cap \(q=w_0y_2\) contains the disjoint chords \(z_Lx_1,y_1x_2\). The four middle chords are nested in order
\[
x_3y_6\ \supset\ y_3x_6\ \supset\ x_4y_5\ \supset\ y_4x_5.
\]
The chord \(y_7z_R\) lies inside the cap \(p=x_7w_*\), and the two trapped-hexagon chords nest in their separate interval. Hence this page is noncrossing. On the other side, all ordinary chords are nested or disjoint, while \(t_cc,t_bb\) nest around the word because \(t_c<W<t_b<b<c\). This page is noncrossing too. The two site edges border one face whose boundary uses \(w_*,\alpha,\beta,w_0\) as its selected three-edge arc; the trapped old six-vertex segment is closed by \(\alpha\beta\), has internal chord \(ad\), and has exactly the two escape edges in (3).

**Three-connectivity and legal expansion.** The matching-chord interlacement graph relative to \(C\) is connected. Each ordinary chord in a leaf \(U_i\) interlaces the face or site edge incident with one of its special vertices and ending outside that leaf. Likewise, each of the three wrapper chords of a branch in (1) interlaces any face or site edge with one endpoint inside that branch and one outside. Such an edge exists for every branch: \(y_1x_2\) joins \(U_1\) to \(C_0\); each of \(A,B\) is crossed by the four middle face chords; \(C_0\) is crossed by \(q\) and the middle chords; \(E\) is crossed by \(p\) and the middle chords; and \(S,W\) are crossed by both \(q,p\). These intersections also connect the ordinary chords of the different branches: \(q,p\) meet the root and \(S\) wrappers, \(q\) meets \(C_0\), \(p\) meets \(E\), and the middle face chords meet both \(C_0\) and \(E\). The edge \(z_Lx_1\) meets the \(U_1\) chords, and \(y_7z_R\) meets the \(U_7\) chords. Finally \(t_cc\) interlaces \(q\), \(t_bb\) interlaces \(p\), and \(\alpha\beta,ad\) interlace the escape edges. Thus every matching edge belongs to one interlacement component.

Since \(C\) spans \(G\), a two-edge cut could only consist of two edges of \(C\); its enclosed \(C\)-interval would be closed under the matching and disconnect the interlacement graph. There is no such cut or bridge. In a cubic graph this gives three-vertex-connectivity. The square expansion is plane and bipartite because \(p,q\) are cofacial and have the same colour orientation. It is three-connected by the deletion comparison of Note 417: \(G-\{p,q\}\) is connected; after deleting at most two old vertices an intact square reconnects all old components; after deleting one new and one old vertex the surviving square path meets every old component, or \(G\) would have a two-vertex cut; after deleting two new vertices the surviving square vertices attach to the connected old graph. Hence the expansion is legal in the Barnette class.

**Hamilton certificate.** In each \(U_i\), denote its six vertices in old-cycle order by \(L_i,h_i,x_i,y_i,j_i,R_i\). The following are spanning leaf paths, as in Note 417:
\[
Y_i=(y_i,x_i,h_i,j_i,R_i,L_i),\quad
X_i=(R_i,L_i,h_i,j_i,y_i,x_i),\quad
O_i=(L_i,h_i,x_i,y_i,j_i,R_i).                              \tag{4}
\]
For each \(F(P,Q)\), name the opening brackets \(\lambda_0,\lambda_1,\lambda_2\), the closing brackets in old-cycle order \(\rho_2,\rho_1,\rho_0\), and its first and last vertices \(F_\ell,F_r\). Superscripts below identify the occurrence. Two paths through all six bracket vertices are
\[
T^-=(\rho_0,\lambda_0,\lambda_1,\rho_1,\rho_2,\lambda_2),
\quad
T^+=(\rho_2,\lambda_2,\lambda_1,\rho_1,\rho_0,\lambda_0).
                                                                    \tag{5}
\]
Every consecutive step in (5) is either an old-cycle edge or one of the three bracket chords. Consequently, \(A\) has a spanning path \(P_A:A_r\to y_4\), and \(B\) a spanning path \(P_B:x_5\to B_\ell\), namely
\[
\begin{aligned}
P_A={}&A_r\xrightarrow{T^-_A}\lambda_2^A,
L_3\xrightarrow{O_3}R_3,
L_4\xrightarrow{Y_4^{-1}}y_4,\\
P_B={}&x_5\xrightarrow{X_5^{-1}}R_5,
L_6\xrightarrow{O_6}R_6,
\rho_2^B\xrightarrow{T^+_B}B_\ell.
\end{aligned}                                                       \tag{6}
\]
All junctions between brackets and leaves in (6) are old-cycle edges. The sole face chord used in the following spanning path of \(W\) is \(y_4x_5\):
\[
\begin{aligned}
y_2&\xrightarrow{Y_2}L_2,
\lambda_2^{C_0},\lambda_1^{C_0},C_{0,\ell},
\lambda_2^S,\lambda_1^S,S_\ell,
R_1\xrightarrow{O_1^{-1}}L_1,\\
&\lambda_2^W,\lambda_1^W,W_\ell,
W_r,\rho_1^W,\rho_2^W,S_r,
\rho_1^S,\rho_2^S,E_r,E_\ell,C_{0,r},
\rho_1^{C_0},\rho_2^{C_0},A_r\xrightarrow{P_A}y_4,\\
&x_5\xrightarrow{P_B}B_\ell,
\lambda_2^E,\lambda_1^E,\rho_1^E,\rho_2^E,
R_7\xrightarrow{X_7}x_7.
\end{aligned}                                                       \tag{7}
\]
Here \(W_\ell W_r\) and \(E_rE_\ell\) are their outer ordinary chords; \(\lambda_1^E\rho_1^E\) is another ordinary chord. The steps \(S_\ell R_1\), \(E_\ell C_{0,r}\), and all unlabelled bracket-to-subword junctions follow the old cycle. Equations (4)--(7) use each leaf's six vertices once and each branch's six brackets once, so (7) covers all \(78\) vertices of \(W\) exactly once.

The remaining twelve vertices close this path to a Hamilton cycle of \(G\):
\[
w_0\xrightarrow{q}y_2\xrightarrow{(7)}x_7
\xrightarrow{p}w_*,z_R,t_b,b,a,\alpha,\beta,d,c,t_c,z_L,w_0.
                                                                    \tag{8}
\]
Every outside step in (8) is an edge of (2) or one of \(q,p,t_bb,\alpha\beta,t_cc\). Because (8) uses both site edges, [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) directly lifts it to a Hamilton cycle of \(G^+\).

Every leaf in (1) has one plain-unary chord above its core, and every branch has two. Therefore neither ladder reduction of [Note 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md) applies, and \(c=5f-3=32\) is attained by an actual Barnette parent. Its only sibling-leaf pairs are \((3,4),(5,6)\); neither \(y_3x_4\) nor \(y_5x_6\) appears in (3). The result establishes realizability and Hamiltonicity of this extremal instance; it does not decide every graph in Note 416's necessary class. \(\square\)
