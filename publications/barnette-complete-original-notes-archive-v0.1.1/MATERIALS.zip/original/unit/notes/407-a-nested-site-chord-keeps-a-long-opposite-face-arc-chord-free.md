> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A nested site chord keeps a long opposite facial arc chord-free

[Note 406](406-a-long-gap-single-hexagon-forces-a-main-face-side-chord.md)
forces an extra main-segment matching chord on the common-face
side whenever a single trapped hexagon has a long opposite
site interval. That chord need not belong to the other facial
arc. The following smallest-order Barnette parent separates
these two locations.

Take the twenty-vertex Hamilton cycle
\[
C=(w_0,w_1,\ldots,w_{13},\alpha,a,b,c,d,\beta,w_0)
\]
and add the complementary perfect matching
\[
\begin{split}
M=\{&w_0w_3,w_6w_{13},\alpha\beta,w_7w_{10},\\
    &w_1d,w_2c,w_4w_9,w_5w_8,w_{11}b,w_{12}a\}.
\end{split}                                                   \tag{1}
\]
The site edges are \(q=w_0w_3\), \(p=w_6w_{13}\).
There is no hexagon interior chord \(ad\).

**Nested-chord boundary.** The graph (1) is simple,
three-connected, cubic, bipartite, and plane. The site
edges share a face whose two residual arcs are
\[
 (w_{13},\alpha,\beta,w_0)
 \quad\text{and}\quad
 (w_3,w_4,w_5,w_6),                                  \tag{2}
\]
both of length three. The second arc has no matching
edge: every one of its edges belongs to \(C\). The
sole additional main matching chord on the common-face
side is \(w_7w_{10}\), nested inside \(p\) and absent
from that facial arc. Thus a long opposite facial arc
does not force a matching chord *on that arc*, even in
the Barnette class with a single chord-free trapped
hexagon.

**Certificates.** Draw \(q,p,\alpha\beta,w_7w_{10}\)
on one side of the old Hamilton circle, with
\(w_7w_{10}\) nested in \(p\). Draw the other six
matching chords on the opposite side. There
the four escape chords are nested in the order
\[
 w_1d\supset w_2c\supset w_{11}b\supset w_{12}a.
\]
The two other chords satisfy
\(w_4w_9\supset w_5w_8\); this pair lies inside
\(w_2c\) and is disjoint from \(w_{11}b,w_{12}a\).
Thus no chords on either page cross. All matching edges join
opposite parities of \(C\), and no matching edge is an
old-cycle edge. This proves simplicity, cubicity,
bipartiteness, and planarity. The common face between
\(q,p\) uses \(\alpha\beta\) on one side and the three
old-cycle edges of the second arc in (2) on the other;
\(w_7w_{10}\) cuts only the cap inside \(p\).

The matching-chord interlacement graph is connected:
\(q\) interlaces \(w_1d,w_2c\);
\(p\) interlaces \(w_4w_9,w_5w_8,w_{11}b,w_{12}a\);
\(w_7w_{10}\) interlaces \(w_4w_9,w_5w_8\);
\(\alpha\beta\) interlaces \(w_1d,w_2c,w_{11}b,w_{12}a\).
A two-edge cut in a cubic graph with Hamilton cycle
\(C\) would close a proper interval of \(C\) under
the matching and disconnect this interlacement graph.
There is no such cut and no bridge. Three-edge
connectivity implies three-vertex-connectivity in a
cubic graph, so (1) is a Barnette graph. \(\square\)

The parent has a Hamilton cycle through *both* site edges:
\[
\begin{split}
C'=(w_0,w_3,w_2,w_1,d,c,b,w_{11},w_{10},w_9,\\
\qquad w_4,w_5,w_8,w_7,w_6,w_{13},w_{12},a,\alpha,\beta,w_0).
\end{split}                                                   \tag{3}
\]
Every consecutive pair in (3) is an old-cycle edge or
belongs to (1), and each vertex occurs once. In
particular, the legal square-expanded child is also
Hamiltonian by the direct lift of
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md).

The order twenty is minimal for this location failure
with a single trapped hexagon: Notes 403--405 exclude
long opposite arcs below twelve main vertices, and at
twelve main vertices their only long-gap matching has
its extra face-side chord \(w_4w_7\) directly on the
other facial arc. Here the main segment has fourteen
vertices. The parent itself is Hamiltonian by \(C\);
the stronger marked witness (3) also makes its child
Hamiltonian. The example closes only the proposed
strengthening of Note 406 from “same face side” to
“on the other facial arc,” not Barnette's conjecture.
