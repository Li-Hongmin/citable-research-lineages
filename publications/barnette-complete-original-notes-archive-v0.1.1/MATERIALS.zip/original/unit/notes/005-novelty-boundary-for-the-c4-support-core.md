> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Novelty boundary for the C4 support core

Literature search cutoff: 2026-08-24.

The existence of an infinite edge-Hamiltonian Barnette family, even one with
orders \(240+4k\) produced by repeated standard \(C_4\)-expansion, is not a
novelty claim.  Even prisms already give an elementary family of that form.
Spider-web networks are an infinite Barnette subclass and are Hamiltonian
laceable, which implies every edge lies on a Hamilton cycle.

The established term for the latter property is \(P_2\)-Hamiltonian.  Gorsky,
Steiner and Wiederrecht, *Discrete Mathematics* 346 (2023) 113249, DOI
`10.1016/j.disc.2022.113249`, restate the Holton--Manvel--McKay generation
theorem and prove structural matching properties under \(C_4\)-expansion,
but do not give unconditional Hamiltonicity or \(P_2\)-Hamiltonicity
preservation.  Bej, DOI `10.1080/09720529.2021.1961893`, explicitly notes
that arbitrary repetition of the corresponding alpha operation does not
preserve ordinary Hamiltonicity.

The candidate novelty is therefore the mechanism in Notes 001--003:

1. the exact six-traversal if-and-only-if criterion for one specified
   \(C_4\)-expansion;
2. the seven inclusion-minimal traversal covers of the eight gadget edges;
3. the recurrent three-role support core that propagates old- and new-edge
   Hamilton-cycle support along a selected central chain.

No matching theorem was found in the searched HMM-forward-citation,
\(P_2\)-Hamiltonian, annular-decomposition or prescribed-edge literature.
This supports only the qualified phrase “we are not aware”; an expert check
under alternative names such as square insertion, ladder insertion and
four-terminal Hamiltonian linkage remains necessary.

The 240-vertex chain of Note 004 is a nontrivial certified application of the
mechanism, not the headline novelty.  Manuscript language must not claim the
first infinite edge-Hamiltonian Barnette family, unconditional preservation
under \(C_4\)-expansion, or novelty of the order sequence.

The source-by-source decision record is
`scratch/worker-barnette/novelty-decision-recursive-c4-edge-hamiltonian-family.md`.

