> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Three lobes have the exact chord-packing bound

[Note 192](192-two-lobes-have-the-exact-chord-packing-bound.md)
excludes equality in the universal facial spacing bound
\(|V(S_0)|\ge4r+8\) when an all-square opening has at
least two lobes. The next main-segment size also fails
when there are at least three lobes. The obstruction is
that every nonfinal escape pair needs room after its
even-index target before the next completed face block.

Use the one-square-per-lobe compression of Notes 176--179.
Let \(\ell\ge3\) be the lobe count and \(r\ge1\) the number
of complementary-matching edges on the other
\(y\)-to-\(u\) site-face arc. As before \(S_0\) runs from
\(x\) to \(v\), with \(x<y<u<v\), and
\(f=|V(S_0)|-2\ell-4\).

**Three-lobe spacing theorem.** For every \(\ell\ge3\),
\[
|V(S_0)|\ge4r+12,
\qquad f\ge4r+8-2\ell.
\tag{1}
\]
For exactly three lobes the bound is sharp for every
\(r\ge1\):
\[
f_{\min}(3,r)=4r+2.
\tag{2}
\]
The examples attaining (2) have Hamiltonian parents and
site-expanded children, with arbitrary positive lobe
lengths.

**Blocks and a prefix-cut rule.** List the \(r\) matching
edges on the \(y\)-to-\(u\) site-face arc as
\(a_i b_i\) in increasing \(C\)-order, as in Note 191.
Partition the main segment into the \(r+2\) closed
blocks
\[
B_0=[x,y]_C,\quad B_i=[a_i,b_i]_C\ (1\le i\le r),
\quad B_{r+1}=[u,v]_C,
\tag{3}
\]
and the \(r+1\) open gaps
\[
G_0=(y,a_1)_C,\quad
G_i=(b_i,a_{i+1})_C,\quad
G_r=(b_r,u)_C.
\tag{4}
\]
Each block has at least two interior vertices, with an
even number of extra interior vertices. The gaps have
nonnegative interior sizes. Hence
\[
|V(S_0)|=4r+8+
\sum_{i=0}^{r+1} e_i+
\sum_{i=0}^{r} t_i,
\qquad e_i\in2\mathbb Z_{\ge0},\quad t_i\ge0,
\tag{5}
\]
where \(e_i\) counts block vertices beyond its first
two interior vertices and \(t_i\) counts gap vertices.

Call the interior block and gap vertices *slots*.
Every matching edge joining slots in different blocks
or gaps lies opposite the common face. If one endpoint
is inside a block, such an edge interlaces its closing
site or face matching chord. If both endpoints are in
gaps on the common face boundary, drawing their edge
on that side would split the designated common face;
an edge on its boundary would instead be one of the
already listed \(a_i b_i\). Matching edges within a
single block need not lie opposite the face, but cannot
leave that block.

The escape targets occur in the order
\(R_\ell,L_\ell,\ldots,R_1,L_1\), with each \(R_j\)
at odd and each \(L_j\) at even \(S_0\)-index.
For any nonfinal pair \(j\ge2\), \(L_j\) cannot be
the last slot of its block or gap. To see this, let
\(z\) be the right endpoint of that block, or the
last vertex of that gap. Take the main \(C\)-prefix
from \(x\) through \(z\), together with the residual
square suffix \(S_j,\ldots,S_\ell\). All escape
targets in the prefix are paired with squares in the
suffix. The known site and face matching chords are
complete before \(z\). A slot chord leaving the prefix
would start before \(L_j\), end after its atom, lie
opposite the face by the preceding observation, and
cross the escape edge at \(L_j\). There is no slot after
\(L_j\) inside its atom. Thus the vertex set is closed
under the complementary matching. Exactly two old-cycle
edges leave it, one after \(z\) and one entering \(S_j\)
from \(S_{j-1}\), contrary to three-edge-connectivity.
We call this the **prefix-cut rule**.

**Exclusion at two extra vertices.** Suppose, against
(1), that \(|V(S_0)|=4r+10\). By (5), precisely two
extra vertices are distributed in one of three ways.

First, one block has two extras. With no gap extras,
the interior slots of every ordinary block have index
parities odd, even; the longer block has odd, even,
odd, even. Thus only the second slot of the longer
block can hold an even target \(L_j\) that is not
last in its atom. There are at least two nonfinal
targets \(L_\ell,\ldots,L_2\), contradicting the
prefix-cut rule.

Second, one gap has two extras. All block interiors
have parities odd, even. The two gap slots have
parities even, odd, so only the first of them can
hold a nonfinal \(L_j\) away from its atom's end.
Again there are at least two such targets.

Finally, two distinct gaps each contain one extra
vertex. Mark odd and even \(S_0\)-indices by \(O,E\).
Every block before the first gap has slot colours
\(O,E\). The first added gap slot is \(E\);
the blocks between the two gaps have \(E,O\);
the second added gap slot is \(O\); and every
later block again has \(O,E\). All non-target
slot matching edges lie opposite the face: each
block has only its two consecutive interior
vertices, which cannot be matched to each other,
and each gap has just one slot.

We show that the first escape target must be
\(R_\ell=o_1\), the first slot of \(B_0\).
Otherwise \(o_1\) is free. Its mate must be an
even slot before \(R_\ell\): a chord across that
target would cross its escape edge. The slots
strictly between \(o_1\) and its mate must
match among themselves by noncrossing, so they
have equally many \(O\) and \(E\) colours.
Starting just after \(o_1\), the excess
\(\Delta=\#E-\#O\) is \(1\). Whole blocks
do not change it. The first gap raises it to
\(2\), and the second gap lowers it to \(1\).
Consequently an even slot has \(\Delta=0\)
immediately before it only when it is the
second slot of an \(O,E\) block, either before
the first gap or after the second. The
immediate \(o_2\) is an invalid matching mate
because it is adjacent to \(o_1\) on \(C\).
Any later such mate before \(R_\ell\) closes
the main prefix through that block under the
matching, yielding a forbidden two-edge cut.
The final slot \(o_4\) cannot precede the first
escape target. Thus \(R_\ell=o_1\).

Now all slots strictly between \(R_\ell=o_1\)
and \(L_\ell\) are free and must match among
themselves; no opposite-side chord can cross
either escape edge. Their colours must balance.
The same \(\Delta\) count makes every possible
even \(L_\ell\) with balanced preceding slots
the second slot of an \(O,E\) block. It is
therefore last in its atom. The sole final
such slot \(o_4\) leaves no room for the next
target \(R_{\ell-1}\); every earlier choice
violates the prefix-cut rule. This eliminates
the third distribution.

Thus \(|V(S_0)|\ne4r+10\). Note 192 already excludes
\(4r+8\), and \(|V(S_0)|\) is even, proving (1).
For \(\ell=3\), (1) becomes \(f\ge4r+2\).
Note 190 attains equality for every \(r\), proving
(2), and Note 178 transfers arbitrary lobe lengths.
\(\square\)

The proof does not classify three-lobe equality graphs
or decide whether every child at equality is
Hamiltonian. For four or more lobes it supplies a
lower bound, not an exact minimum.
[Note 194](194-short-facial-chord-blocks-allow-only-one-square-trap-lobe.md)
shows that keeping every site and opposite-face chord
at its minimum cycle length forces a Hamiltonian child,
regardless of gap lengths.
[Note 195](195-exact-lobe-independent-opposite-face-chord-packing.md)
subsequently proves the exact free-vertex minimum for every
lobe count, using the prefix-cut rule above.
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md)
subsequently settles every equality Hamilton decision.
