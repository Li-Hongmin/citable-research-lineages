> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The swapped six-double splice has the square Hamilton signature

[Note 360](360-a-two-path-splice-closes-the-six-double-k1i2-global-return.md)
leaves two nonlocal matchings under \(h_1j_6,k_1i_2\).
Its standard matching is [Note 345](345-an-unbounded-alternating-double-block-chain-has-a-marked-hamilton-route.md)
at six blocks and already has the square signature by
[Note 346](346-the-alternating-rainbow-double-chain-is-square-equivalent-at-every-length.md).
The other matching swaps the two internal chords of the final
four-block portion as in
[Note 347](347-a-nested-four-double-swap-has-the-square-hamilton-signature.md).
Although its four-block outer chord is replaced by a route
through the first two blocks, the complete square signature survives.

Let \(D_s=(a_s,o_s,h_s,i_s,k_s,j_s,e_s,b_s)\),
\(1\le s\le6\), occur consecutively in old-cycle order.
The common-face chords are all \(a_sb_s\), together with
\(i_se_s\) for odd \(s\) and \(o_sk_s\) for even \(s\).
Put on the opposite page exactly the following internal chords:
\[
\begin{split}
&h_1j_6,\ k_1i_2,\ j_1h_2,\ j_2h_3,\ e_2o_3,\\
&k_3i_6,\ j_3h_4,\ i_4k_5,\ j_4h_5,\ e_4o_5,\ j_5h_6.
\end{split}                                                 \tag{1}
\]
Delete the two ordinary exterior matching edges at \(o_1,e_6\).
The resulting induced 48-vertex disk patch \(T\) has four
degree-two terminals in boundary order
\[
                         (a_1,o_1,e_6,b_6).             \tag{2}
\]

**Swapped-splice theorem.** The complete spanning one-path and
two-path terminal signature of \(T\) is exactly that of the
square with terminal order (2). Replacing an induced disk copy
of \(T\) in a Barnette graph by this square, or conversely,
preserves Barnette membership and every Hamilton decision on
the exterior and attachment edges. In particular, a
vertex-minimal non-Hamiltonian Barnette graph has no such
patch. The matching (1) occurs in an explicit 60-vertex
Barnette parent with a Hamilton cycle through both site edges;
its legal site-expanded child is Hamiltonian.

**Four single-path states.** The full old-cycle path spans
\(a_1b_6\). Note 360 (3), using the swapped four-block path
of Note 347, spans \(o_1e_6\) after deleting the ordinary
endports \(L,R\).

The \(a_1o_1\) route \(U_3\) of Note 346 (3) uses only old
edges, the displayed common-face chords, the five
\(j_sh_{s+1}\) chords, and \(h_1j_6\). All are present in (1).
Its reflected route under Note 346 (4) uses the same subset
of edges and spans \(e_6b_6\). This reflection need only
preserve the route's edges; it need not preserve the entire
matching (1).

**First two-path state.** The following two paths are disjoint:
\[
\begin{split}
F={}&(a_1,b_1,e_1,j_1,h_2,o_2,a_2,b_2,e_2,o_3,
 a_3,b_3,a_4,b_4,e_4,j_4,k_4,o_4,h_4,i_4,\\
 &k_5,j_5,e_5,i_5,h_5,o_5,a_5,b_5,a_6,b_6),\\
G={}&(o_1,h_1,i_1,k_1,i_2,k_2,j_2,h_3,i_3,e_3,
 j_3,k_3,i_6,h_6,o_6,k_6,j_6,e_6).
\end{split}                                                 \tag{3}
\]
They span \(T\) with pairing \(\{a_1b_6,o_1e_6\}\).
Their restrictions to \(D_3,\ldots,D_6\) are obtained
from Note 347 (5): prepend \(o_3\) to its \(a_3b_6\)
path and remove \(o_3\) from its \(o_3e_6\) path.
Those paths do not use the absent \(h_3j_6\) chord.
The new joins from the first two blocks are
\(e_2o_3,j_2h_3\); the other cross-block joins are
\(j_1h_2,i_4k_5,k_3i_6\) and old interblock edges.
The two lists contain respectively 30 and 18 distinct
vertices, covering all 48.

**Second two-path state.** Take the edge path \((a_1,o_1)\)
and the following \(e_6\)--\(b_6\) path:
\[
\begin{split}
K={}&(e_6,j_6,h_1,i_1,k_1,i_2,k_2,o_2,h_2,j_1,
 e_1,b_1,a_2,b_2,a_3,o_3,e_2,j_2,h_3,\\
 &i_3,e_3,b_3,a_4,o_4,h_4,j_3,k_3,i_6,k_6,o_6,
 h_6,j_5,e_5,i_5,k_5,i_4,k_4,j_4,\\
 &h_5,o_5,e_4,b_4,a_5,b_5,a_6,b_6).
\end{split}                                                 \tag{4}
\]
The first two blocks of \(K\) use \(k_1i_2,j_1h_2\)
and the common-face \(o_2k_2,a_2b_2\) chords.
The detour \(b_2a_3o_3e_2j_2h_3\) absorbs the two
vertices of \(D_3\) omitted by Note 347 (6).
The remaining suffix is precisely that note's path after
its initial \(e_6,j_6,h_3\), with the missing edge
\(j_6h_3\) replaced by the displayed route through
\(D_1,D_2\). Every join in (4) is an old edge or one
of the prescribed chords; its 46 vertices are exactly
\(V(T)\setminus\{a_1,o_1\}\). This gives pairing
\(\{a_1o_1,e_6b_6\}\).

The 48-vertex bipartition excludes the single-path endpoints
\(a_1e_6,o_1b_6\), whose colours agree. The remaining
two-path pairing \(\{a_1e_6,o_1b_6\}\) crosses the disk
terminal order (2), so is impossible. Equations (3)--(4)
and the four single paths exhaust the square's signature.
A Hamilton cycle uses two or four attachments, proving the
claimed preservation of every exterior Hamilton decision.

**Realization and class preservation.** On the old Hamilton
cycle
\[
x,R_1,w,y,D_1,D_2,D_3,D_4,D_5,D_6,u,z,L_1,v,
  \alpha,\gamma,\delta,\beta,x,                         \tag{5}
\]
put the common-face matching chords \(xy,uv,\alpha\beta\)
and all prescribed block chords. On the opposite page put
\(\delta R_1,wo_1,e_6z,\gamma L_1\) and (1).
The chords of (1) are nested or disjoint: \(h_1j_6\)
surrounds the group; before \(k_3i_6\) lie the disjoint
nested pairs \(k_1i_2\supset j_1h_2\) and
\(j_2h_3\supset e_2o_3\); inside \(k_3i_6\) lie
\(j_3h_4\), \(i_4k_5\supset j_4h_5\supset e_4o_5\),
and \(j_5h_6\). The exterior chords are disjoint from
these or enclose them. All common-face chords are likewise
noncrossing. The matching covers each old-cycle vertex
once, joins opposite colours and contains no old edge.
Thus (5) defines a simple cubic bipartite plane graph.

For three-connectivity, join two matching chords when their
endpoints alternate on (5). The following dashes form a
connected spanning system of such alternations:
\[
\begin{gathered}
xy-wo_1-a_1b_1-h_1j_6-a_6b_6-e_6z-uv
 -\gamma L_1-\alpha\beta-\delta R_1,\\
a_sb_s-j_sh_{s+1}-a_{s+1}b_{s+1}
 \quad(1\le s<6),\\
a_1b_1-k_1i_2-i_1e_1,\qquad j_1h_2-o_2k_2,
 \qquad a_2b_2-e_2o_3,\\
a_3b_3-k_3i_6-i_3e_3,\qquad k_3i_6-o_6k_6,
 \qquad j_3h_4-o_4k_4,\\
a_4b_4-i_4k_5-i_5e_5,\qquad a_4b_4-e_4o_5.
\end{gathered}                                             \tag{6}
\]
Every dash alternates by the old-cycle order (5).
A two-edge cut would bound a proper old-cycle interval
closed under the matching and hence disconnect this
interlacement graph. The old Hamilton cycle excludes
bridges. Therefore the graph is three-edge-connected;
in a cubic graph this implies three-vertex-connectivity.

The site edges \(xy,uv\) are cofacial: their common-face
arc from \(y\) to \(u\) has length 13 through the six
\(a_sb_s\) chords, and the other site arc from \(v\) to
\(x\) has length three through \(\alpha\beta\).
The residual cycle \(\alpha\gamma\delta\beta\alpha\)
is a square with tight escape targets \(R_1,L_1\)
and no interblock gap. Let \(V\) be the \(o_1e_6\)
route from Note 360 (3) for the swapped matching (1).
The two internally disjoint \(x\)--\(v\) paths
\[
x,R_1,\delta,\beta,\alpha,\gamma,L_1,v
 \quad\text{and}\quad
x,y,w,V,z,u,v                                      \tag{7}
\]
cover (5) and form a Hamilton cycle through both site
edges. Note 001 gives the legal child's Hamilton cycle.

Deleting one vertex of \(T\) leaves it connected: each
block's old-cycle path plus \(a_sb_s\) is a cycle,
the five old interblock edges lose at most one edge,
and \(h_1j_6\) survives whenever one of those edges is
lost and joins the two end blocks. After deleting two
patch vertices, every surviving component touches a
surviving terminal; otherwise it would disconnect from
the exterior of the three-connected realization (5).
The exterior of a four-attachment patch in any Barnette
host is connected, since two exterior components would
each require at least three attachment edges. The
four-attachment deletion comparison of Note 362 now
proves three-connectivity under substitution in both
directions. The disk terminal order and colours also
preserve planarity, bipartiteness, cubicity and simplicity.
\(\square\)

**Reflected branch.** The old-cycle reflection \(\rho\)
of Note 346 (4) sends the matching (1) to the unique
\(h_1j_6,k_1i_4\) matching in Note 361 (1)--(3):
it sends \(k_3i_6,i_4k_5\) to \(k_1i_4,i_2k_3\),
and sends \(k_1i_2\) to \(k_5i_6\). All other
chords map to the displayed remaining chords in that
branch. Reflection therefore gives the same exact square
signature, 60-vertex Barnette realization, and
class-preserving replacement for that unique matching.

This theorem treats the swapped nonlocal
\(h_1j_6,k_1i_2\) matching and its \(k_1i_4\)
reflection. Note 346 covers the standard companion;
the local-square branches of Note 360 have proper
square reductions. No statement is made about other
six-block words, short corridors, other opening types
or general Barnette graphs.
The proof is project-internal and has not had an
independent external review.
