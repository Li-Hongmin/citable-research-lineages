> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The square is the unique boundary-neutral occupied face portal

[Note 146](146-an-occupied-domino-portal-forces-short-gap-child-compensation.md)
shows that an occupied square opposite the patch square preserves the
complete four-port complement signature. This note classifies the direct
extension to an arbitrary occupied even face. The square is the unique face
length for which the canonical lift and gate sibling have the same boundary
pairing independently of the exterior.

## 1. Full-face occupied portals

Let the short edge be \(h=st\), and suppose a facial \(2m\)-cycle has
boundary

\[
 F=s-v_1-v_2-\cdots-v_{2m-2}-t-s,
 \qquad m\ge2.
\tag{1}
\]

Assume that for a bad bond \(M_{11}N_{00}\), the gate component after
deleting the two site edges is the entire non-\(h\) boundary path

\[
 P_g=s-v_1-v_2-\cdots-v_{2m-2}-t,
\tag{2}
\]

and that \(N\) occupies its first, third, and subsequent odd-position
edges:

\[
 sv_1,\ v_2v_3,\ldots,\ v_{2m-2}t\in N.
\tag{3}
\]

The surviving gate is one of the complementary even-position edges of
(2), and therefore belongs to \(M\setminus N\). Call (1)--(3) a
**full-face occupied portal**.

As in Note 146, let

\[
 Q_h=s-\alpha-\beta-t-s
\tag{4}
\]

be the child patch square incident with \(h\), with
\(\alpha\beta\in\widehat N\). The gate-path sibling is obtained by flipping

\[
 D=P_g\cup\{t\beta,\beta\alpha,\alpha s\}.
\tag{5}
\]

Let \(K=F\cup Q_h\). Its boundary ports are

\[
 \alpha,\beta,v_1,\ldots,v_{2m-2};
\tag{6}
\]

the third incidence at each \(v_i\) belongs to the common exterior
complement.

## 2. Exact boundary-pairing classification

> **Theorem.** The complements of the canonical lift \(\widehat N\) and
> its gate-path sibling induce the same port pairing on \(K\) if and only if
> \(m=2\), equivalently \(F\) is a square.

### Proof

Inside \(K\), the complement of \(\widehat N\) contains

\[
 \alpha-s-h-t-\beta
\tag{7}
\]

and the even-position edges of \(P_g\). It has no closed component and
induces

\[
\begin{aligned}
\pi_0=\{&
(\alpha,\beta),
(v_1,v_2),(v_3,v_4),\ldots,
(v_{2m-3},v_{2m-2})\}.
\end{aligned}
\tag{8}
\]

After the flip (5), the complement contains \(\alpha\beta\), \(h\), and
the odd-position edges of \(P_g\). It again has no closed component and
induces

\[
\begin{aligned}
\pi_1=\{&
(\alpha,\beta),
(v_1,v_{2m-2}),
(v_2,v_3),(v_4,v_5),\ldots,
(v_{2m-4},v_{2m-3})\}.
\end{aligned}
\tag{9}
\]

For \(m=2\), there are only \(v_1,v_2\), and both pairings are

\[
 \{(\alpha,\beta),(v_1,v_2)\}.
\tag{10}
\]

For \(m\ge3\), the port \(v_1\) is paired with \(v_2\) in \(\pi_0\) but
with the distinct port \(v_{2m-2}\) in \(\pi_1\). Hence
\(\pi_0\ne\pi_1\). \(\square\)

## 3. Consequence for the legal-wide route

The theorem is an exact classification of the exterior-independent gluing
mechanism, not a nonexistence theorem for rooted siblings. When \(m\ge3\),
a particular exterior may still turn both different pairings into rooted
two-factors. What fails is the local signature identity that made Note 146
automatic for every exterior.

Thus the occupied-domino theorem cannot be extended merely by replacing
the square with a longer even face. Any further universal local
neutralizer must use more than one parent face, compensate a pairing change
with an internal closed-component change, or retain additional information
about the actual exterior. The alternative of an unrelated child bond
remains untouched.

[Note 148](148-gate-path-sibling-rootedness-has-an-exact-circuit-partition-criterion.md)
retains that actual exterior and gives the exact test: contract the residual
canonical paths, join them by the flipped matching edges, count the quotient
circuits, and retain the two root markers.  Hence a longer portal can still
succeed, but only through this exterior-dependent circuit partition rather
than the signature identity classified here.
