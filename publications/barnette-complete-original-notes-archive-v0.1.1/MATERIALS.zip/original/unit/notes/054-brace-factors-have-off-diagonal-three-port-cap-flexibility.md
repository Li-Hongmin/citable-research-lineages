> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Brace factors have off-diagonal three-port cap flexibility

[Note 053](053-tight-three-splices-have-an-exact-fourteen-state-cotree-convolution.md)
expresses degree-constrained cotree fragmentation across a tight
three-splice as a min-plus convolution of fourteen cap states. Its
abstract one-unit obstruction has a unique safe three-port state on each
factor, with the two safe states on the forbidden diagonal. This note
proves that the right-hand profile of a brace cannot have that form. The
proof is a same-colour forest pivot forced by the absence of a two-edge
cut.

## The right three-port profile

Let \(F\) be a simple cubic bipartite brace with bipartition
\(X\sqcup Y\). Fix \(r\in Y\), write

\[
N_F(r)=\{t_1,t_2,t_3\}\subseteq X,
\qquad P=F-r,
\]

and choose a nonport hole \(h\in Y\setminus\{r\}\). There are no
site-forced or site-forbidden internal edges on this factor. For

\[
\pi_i=\bigl\{\{i\},[3]\setminus\{i\}\bigr\}
\]

put

\[
\omega_i=\Omega([3],\pi_i;\{h\}).
\tag{1}
\]

A forest representing \(\pi_i\) has two components: one contains only
\(t_i\), the other contains \(t_j,t_k\). Every port has degree one and
every other \(X\)-vertex has degree two. The value \(\omega_i\) is the
minimum degree of \(h\), with value \(+\infty\) when the state is
infeasible.

> **Three-port load and flexibility theorem.** Every finite entry in (1)
> satisfies
> \[
> \omega_i\le2.
> \tag{2}
> \]
> Moreover,
> \[
> \bigl|\{i:\omega_i\le2\}\bigr|\ne1.
> \tag{3}
> \]
> More precisely, from a safe representative in one fibre, minimization
> inside that fibre followed by one same-\(X\) fundamental pivot produces
> a safe representative in an off-diagonal fibre.

Only cubic bipartiteness and the absence of a two-edge cut are used. A
brace has the latter property because it is \(2\)-extendable and hence
\(3\)-connected.

## A finite three-port entry has load at most two

Suppose that \(\pi_i\) is feasible but every representative \(J\) has
\(\deg_J(h)=3\). Among all such representatives choose a smallest
component \(C\) of \(J-h\) containing no selected port. Such a component
exists: \(J\) has two components, the component containing \(h\) contains
at most two of the three selected ports, and deletion of its degree-three
vertex \(h\) creates three branches.

Let \(xh\) be the unique \(J\)-edge from \(C\) to \(h\). Every
\(X\)-vertex of \(C\) has \(J\)-degree two, and \(C\) contains no neighbour
of the deleted root because all three root neighbours are selected ports.
Since \(J[C]\) is a tree,

\[
2|X\cap C|
=|E(J[C])|+1
=|X\cap C|+|Y\cap C|.
\]

Thus \(C\) is colour-balanced. Orienting every edge from \(X\) to \(Y\),
the two directed sides of \(\delta_F(C)\) have equal size. One outward
edge is \(xh\). If it were the only outward edge, the whole boundary
would be a two-edge cut. Hence there is another edge

\[
e=x'y\in E(P)\setminus E(J),
\qquad x'\in X\cap C,\quad y\in Y\setminus C.
\tag{4}
\]

If \(x'=x\), then \(e\ne xh\); simplicity forces \(y\ne h\). Therefore
\(J-xh+e\) represents the same port partition and lowers the degree of
\(h\) to two, a contradiction.

If \(x'\ne x\), let \(f\) be the first edge on the \(J\)-path from \(x'\)
toward \(h\). The pivot

\[
J'=J-f+e
\tag{5}
\]

preserves every prescribed \(X\)-degree because \(e\) and \(f\) meet the
same \(X\)-vertex. It also preserves the port partition: the part cut
from \(C\) contains no selected port and is merely reattached outside
\(C\). Whether or not \(y=h\), one of the resulting port-free branches
at \(h\) is a proper subset of \(C\). The degree of \(h\) remains three,
contradicting the minimal choice of \(C\). This proves (2).

## A safe fibre forces an off-diagonal safe fibre

Fix a safe representative \(J\) of \(\pi_i\), and write
\(\{i,j,k\}=[3]\). Let \(A\) be the component containing \(t_i\), and
let \(B\) contain \(t_j,t_k\). The tree \(J[A]\) contains exactly one
selected \(X\)-port. Consequently

\[
|E(J[A])|=2|X\cap A|-1
=|X\cap A|+|Y\cap A|-1,
\]

so

\[
|X\cap A|=|Y\cap A|.
\tag{6}
\]

Orient \(F\) from \(X\) to \(Y\), and define

\[
\delta^+(A)=E(X\cap A,Y\setminus A),
\qquad
\delta^-(A)=E(X\setminus A,Y\cap A).
\]

Equation (6) and cubicity give equal directed boundary sizes. The root
edge \(t_ir\) lies in \(\delta^+(A)\); equality at one would make
\(\delta_F(A)\) a two-edge cut. Hence

\[
|\delta^-(A)|=|\delta^+(A)|\ge2.
\tag{7}
\]

Every edge of \(\delta^-(A)\) is an unused edge \(xy\), where
\(x\in X\cap B\) and \(y\in Y\cap A\). Call it safe if adding it does
not raise the degree of \(h\) above two. If \(\deg_J(h)\le1\), all these
edges are safe. If \(\deg_J(h)=2\), at most one is unsafe, namely the
unique unused edge ending at \(h\). By (7), a safe cross-edge always
exists.

Among the safe representatives of \(\pi_i\), choose \(J\) minimizing

\[
\sigma(J)=|V(B)\setminus V(P_{jk})|,
\tag{8}
\]

where \(P_{jk}\) is the unique \(t_jt_k\)-path in \(B\). Let
\(e=xy\in\delta^-(A)\) be safe. If \(x\notin V(P_{jk})\), remove the first
edge \(f\) of the path from \(x\) to \(P_{jk}\). The component cut off
contains \(x\) but no selected port. Thus

\[
J'=J-f+e
\]

preserves the port partition and all prescribed \(X\)-degrees, remains
safe, and strictly lowers (8), a contradiction. A safe cross-edge may
therefore be chosen with \(x\in V(P_{jk})\).

Now delete either path edge \(f\in E(P_{jk})\) incident with \(x\), and
add \(e\). Deleting \(f\) separates \(t_j\) from \(t_k\), while adding
\(e\) joins the side containing \(x\) to \(A\). The forest

\[
J''=J-f+e
\tag{9}
\]

has port partition \(\pi_j\) or \(\pi_k\). It has the required
\(X\)-degrees and remains safe. This proves (3).

## The abstract diagonal blocker is not brace-realizable

Consider the specialized splice orientation of Note 053: the left root
lies in global \(X\), the right root lies in global \(Y\), the site lies
wholly on the left, and the hole set consists of the distinguished
nonport hole \(v\) on the left and one nonport hole \(h\) on the right.
No splice port is deleted. Thus \(D=\varnothing\), \(|H|=2\), and
\(\epsilon=1\).

For the three-edge states put

\[
L_i=\Omega_L([3],\pi_i;\{v\}),
\qquad
R_i=\Omega_R([3],\pi_i;\{h\}).
\tag{10}
\]

Assume the two scalar marginal conditions

\[
\min_i L_i\le1,
\qquad
\min_i R_i<+\infty.
\tag{11}
\]

By (2)--(3), at least two right indices satisfy \(R_j\le2\). Choose
\(i\) with \(L_i\le1\), and then choose such a \(j\ne i\). The pair
\((\pi_i,\pi_j)\) is one of the six compatible three-edge signatures of
Note 053. Therefore

\[
\Theta_H\le L_i+R_j\le3=2|H|-\epsilon.
\tag{12}
\]

The splice has binary support by Note 053(14). In particular, the
abstract profile of Note 053(18), whose right normalized values are
\((0,1,1)\), would have

\[
(R_1,R_2,R_3)=(2,3,3).
\]

It violates both (2) and (3), and hence cannot be realized by an actual
brace factor. The positive two-edge entries of that abstract blocker
are not needed for this contradiction.

The theorem is deliberately local. It does not cover a site meeting the
right factor, a right root in \(X\), a port hole, a used splice edge whose
\(Y\)-endpoint is deleted, more than one right hole, or failure of either
marginal condition in (11). It neither proves that every cap state is
feasible nor controls the two-edge entries. Thus it eliminates the
minimal diagonal obstruction in this orientation, but it does not yet
prove tight-splice preservation in full generality.
