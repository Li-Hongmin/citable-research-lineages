> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(zK\) return with two short flanks has the exact square signature

[Note 396](396-two-short-flanks-reduce-outside-one-boundary-branch.md)
classifies the \(Kz\) right return into the \(hI\) words of
[Note 383](383-the-hi-return-single-double-corridor-is-an-exact-square-reduction.md)
and the delayed \(hp_s\) words of
[Note 384](384-delayed-single-double-return-has-two-cutpoints-and-a-marked-route.md),
after replacing \(oK\) by the two-flank edges \(qo,Kz\).
It gives a spanning group route but leaves the complete
four-terminal signature open. The whole two-flank group has
the square signature for every one of these words.

Use the selected compact all-square opening and block order
\[
 S_0=(c,p,q,d),\quad V=(a,o,h,i,e,b),\quad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\quad
 D=(A,O,H,I,K,J,E,B),\quad T=(C,r,s,F),\qquad m\ge1.
\tag{1}
\]
Let \(M\) be the complementary matching and assume
\(tp,qo,Kz,Js,Er\in M\). There is no internal free
chord of \(D\). The complete possible internal words,
as established in Note 396, are the following:

\[
\begin{split}
\mathsf{I}_m={}&\{qo,hI,iH,ep_1,q_mO,Js,Er\}
 \cup\{q_jp_{j+1}:1\le j<m\};\\
\mathsf{II}_{m,u}={}&
 \{qo,hI,iq_u,ep_1,p_{u+1}H,q_mO,Js,Er\}\\
 &\quad\cup\{q_jp_{j+1}:1\le j<m,\ j\ne u\},
 \qquad 1\le u<m;\\
\mathsf{III}_{m;s,u}={}&
 \{qo,hp_s,iq_{s-1},ep_1,q_uI,
               p_{u+1}H,q_mO,Js,Er\}\\
 &\quad\cup\{q_jp_{j+1}:1\le j<m,
                     \ j\notin\{s-1,u\}\},
 \qquad 2\le s\le u\le m-1.
\end{split}                                                   \tag{2}
\]
The unsubscripted \(r\) in \(Er\) is the vertex of \(T\);
the parameters \(u,s\) index corridor blocks.

Let \(Q\) be the induced interval on all blocks in (1),
omitting the exterior vertices \(t,z\). Its four
degree-two terminals, in disk order, are \((c,p,K,F)\).
Their distinct exterior attachments are the old-cycle
edges at \(c,F\) and the matching edges \(pt,Kz\).

**Exact two-flank \(zK\) theorem.** For every actual word
in (2), \(Q\) has precisely the square's four spanning
one-path and two spanning two-path Hamilton states.
Replacing \(Q\) by the labeled square, or reversing the
replacement, preserves Barnette membership and every
exterior- and attachment-marked Hamilton decision.
Since \(|V(Q)|=22+4m>4\), this is a strict reduction.
Thus no vertex-minimal non-Hamiltonian Barnette graph
contains this selected \(Kz\) return.

**Three shortest routing cores.** The ordinary-link
even-column ladders in (2) can be compressed separately
by [Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md),
keeping all four labeled attachments of each ladder.
Type \(\mathsf I\) becomes \(m=1\). Type
\(\mathsf{II}\) becomes \((m,u)=(2,1)\) by compressing
\(S_1,\ldots,S_u\) and \(S_{u+1},\ldots,S_m\).
Type \(\mathsf{III}\) becomes \((m,s,u)=(3,2,2)\)
by compressing \(S_1,\ldots,S_{s-1}\),
\(S_s,\ldots,S_u\), and \(S_{u+1},\ldots,S_m\).
Each resulting core retains terminals \((c,p,K,F)\).

For each core, the full old-cycle path from \(c\) to
\(F\) is the \(cF\) state. The next three displayed
rows give the other one-path states. Consecutive
vertices are joined by an old-cycle edge, a block-closing
face chord, or a matching edge of (2).

For \(\mathsf I_1\), the 26-vertex core has
\[
\begin{array}{c|l}
pK&
 p,c,d,q,o,a,b,c_1,p_1,e,i,h,I,H,O,q_1,d_1,
 A,B,E,r,C,F,s,J,K\\
cp&
 c,d,a,b,c_1,p_1,e,i,H,O,q_1,d_1,A,B,C,F,
 s,r,E,J,K,I,h,o,q,p\\
KF&
 K,I,h,o,q,p,c,d,a,b,c_1,p_1,e,i,H,O,q_1,d_1,
 A,B,E,J,s,r,C,F .
\end{array}                                                   \tag{3}
\]
For \(\mathsf{II}_{2,1}\), the 30-vertex core has
\[
\begin{array}{c|l}
pK&
 p,c,d,q,o,a,b,e,p_1,c_1,d_1,q_1,i,h,I,H,
 p_2,c_2,d_2,q_2,O,A,B,E,r,C,F,s,J,K\\
cp&
 c,d,a,b,c_1,p_1,e,i,q_1,d_1,c_2,p_2,H,O,
 q_2,d_2,A,B,C,F,s,r,E,J,K,I,h,o,q,p\\
KF&
 K,I,h,o,q,p,c,d,a,b,c_1,p_1,e,i,q_1,d_1,
 c_2,p_2,H,O,q_2,d_2,A,B,E,J,s,r,C,F .
\end{array}                                                   \tag{4}
\]
For \(\mathsf{III}_{3;2,2}\), the 34-vertex core has
\[
\begin{array}{c|l}
pK&
 p,c,d,q,o,a,b,e,p_1,c_1,d_1,q_1,i,h,
 p_2,c_2,d_2,q_2,I,H,p_3,c_3,d_3,q_3,
 O,A,B,E,r,C,F,s,J,K\\
cp&
 c,d,a,b,c_1,p_1,e,i,q_1,d_1,c_2,d_2,
 c_3,p_3,H,O,q_3,d_3,A,B,C,F,s,r,E,J,
 K,I,q_2,p_2,h,o,q,p\\
KF&
 K,I,q_2,p_2,h,o,q,p,c,d,a,b,c_1,p_1,e,i,
 q_1,d_1,c_2,d_2,c_3,p_3,H,O,q_3,d_3,
 A,B,E,J,s,r,C,F .
\end{array}                                                   \tag{5}
\]
Every row in (3)--(5) visits its core vertices
exactly once. The terminal colours are \(c,K\)
on one side and \(p,F\) on the other, so the four
rows \(cF,pK,cp,KF\) exhaust the colour-allowed
one-path pairs.

For the two-path pairing \(\{cp,KF\}\), take the
single edge \((c,p)\) and the displayed \(KF\)
path with its consecutive segment \((q,p,c,d)\)
replaced by \((q,d)\). The replacement uses the
old-cycle edge \(qd\), removes exactly \(c,p\),
and leaves a spanning \(K\)--\(F\) path disjoint
from \((c,p)\). For the pairing \(\{cF,pK\}\),
take the following two disjoint spanning paths:
\[
\begin{array}{c|l}
\mathsf I_1: pK&(p,q,o,h,I,K)\\
\mathsf I_1: cF&
 (c,d,a,b,c_1,p_1,e,i,H,O,q_1,d_1,A,B,E,J,s,r,C,F)\\[2pt]
\mathsf{II}_{2,1}: pK&(p,q,o,h,I,K)\\
\mathsf{II}_{2,1}: cF&
 (c,d,a,b,c_1,p_1,e,i,q_1,d_1,c_2,p_2,H,O,
 q_2,d_2,A,B,E,J,s,r,C,F)\\[2pt]
\mathsf{III}_{3;2,2}: pK&(p,q,o,h,p_2,q_2,I,K)\\
\mathsf{III}_{3;2,2}: cF&
 (c,d,a,b,c_1,p_1,e,i,q_1,d_1,c_2,d_2,
 c_3,p_3,H,O,q_3,d_3,A,B,E,J,s,r,C,F).
\end{array}                                                   \tag{6}
\]
Each pair covers every core vertex once, and each
listed join is an edge of that core. The remaining
two-path pairing \(\{cK,pF\}\) interlaces the
terminal disk order \((c,p,K,F)\) and is impossible.
This proves precisely the square's six states for
all three cores. Note 178 lifts each state through
the compressed ladders without changing any
attachment choice, proving the signature for every
word (2).

**Barnette-class comparison.** Cap \(Q\) by a fresh
square \((x_c,x_p,x_K,x_F)\), attaching its corners
respectively to \(c,p,K,F\). The full old-cycle
path through \(Q\), followed by
\(x_F,x_K,x_p,x_c,c\), is a Hamilton cycle of the
cap. On one page its complementary matching has
the disjoint face chords
\[
 cd,ab,c_jd_j\ (1\le j\le m),AB,CF,x_cx_F;
\]
on the other it has the chosen internal word in (2)
together with \(px_p,Kx_K\), which replace the
exterior edges \(pt,Kz\).
These chords are nested or disjoint on each page
and join opposite Hamilton-cycle parities, so the
cap is simple, cubic, bipartite and plane.

Its matching-chord interlacement graph is connected.
Write \(F_0=cd,F_V=ab,F_j=c_jd_j,F_D=AB,F_T=CF\),
and \(F_X=x_cx_F\). Every opposite-page chord
joining slots of two blocks interlaces both blocks'
face chords. The edges \(qo,px_p,Kx_K,Js\)
connect, respectively,
\[
 F_0-F_V,\quad F_0-F_X,\quad F_D-F_X,\quad F_D-F_T.
\tag{7}
\]
In type \(\mathsf I\), the ordinary links connect
the short-block chain from \(F_V\) to \(F_D\).
In type \(\mathsf{II}\), its two ordinary-link
runs attach to \(F_V\) and \(F_D\) through
\(ep_1,iq_u\) and \(p_{u+1}H,q_mO\).
In type \(\mathsf{III}\), its three runs attach
through \(ep_1,iq_{s-1}\) to \(F_V\), through
\(hp_s,q_uI\) to \(F_V,F_D\), and through
\(p_{u+1}H,q_mO\) to \(F_D\). Thus all face
chords and every opposite-page chord lie in one
interlacement component. A two-edge cut in the cap
would bound a proper old-cycle interval closed
under the complementary matching, disconnecting
that interlacement graph. The Hamilton cycle
excludes bridges. In a cubic graph, three-edge
connectivity implies three-vertex-connectivity;
the cap is Barnette.

Deleting one vertex from \(Q\) leaves it connected.
Each complete block is a cycle and remains connected
after one deletion. Its old-cycle bridge edges
connect the blocks as a chain; one vertex deletion
can remove at most one such bridge. At every block
boundary a matching chord crosses the boundary
whose endpoints differ from those of its old-cycle
bridge: \(qo\) at \(S_0,V\), \(ep_1\) at
\(V,S_1\), \(q_mO\) at \(S_m,D\), and \(Js\)
at \(D,T\). At an ordinary short-block boundary
the chord is \(q_jp_{j+1}\). At the exceptional
boundary in type \(\mathsf{II}\) it is \(hI\);
at the two exceptional boundaries in type
\(\mathsf{III}\) they are \(hp_s,q_uI\).
Thus if deletion removes an old bridge, the
listed crossing matching chord survives and
reconnects the two sides of the block chain.

After any two pole vertices are deleted, every
remaining component contains a surviving terminal;
otherwise that component would be disconnected in
the three-connected cap after the same deletions.
The square has the same one- and two-deletion
properties. The four-attachment comparison of
[Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md)
therefore preserves three-connectivity in both
replacement directions. Terminal colours and disk
order preserve bipartiteness and planarity; the
six routing states preserve the exterior and all
used attachment edges. This proves the theorem.
\(\square\)

Combining this theorem with [Note 401](401-every-zh-return-with-two-short-flanks-has-an-exact-square-reduction.md)
and the boundary reduction of Note 396, every actual
matching in the specified two-short-flank,
single--double positive-corridor group contains a
strict exact square reduction. The conclusion
does not cover longer flanks, different free-group
shapes, non-square residual cycles, other selected
openings, or Barnette's conjecture. It is a
project-internal analytic proof; no local graph
recomputation, independent review, or literature
priority claim is asserted.
