> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Parity and alternating-cycle boundaries at a capped brace

Let \(F\) be a plane cubic bipartite brace with global \(H^{+-}\). Use the
capped facial configuration of
[Notes 021--022](022-edge-source-completion-and-common-deletion-at-a-capped-brace.md):

\[
N_F(z)=\{a_1,a_2,a_3\},\qquad h_i=za_i,\qquad p=uv.
\tag{1}
\]

This note determines what Hamilton-cycle parity can prove in the
\(P\)-regime and gives the exact alternating-cycle exchange condition in the
\(K\)-regime. Neither argument proves the capped-brace cardinality
criterion. Together they isolate the additional information that a proof
must supply.

## Four-terminal parity in the \(P\)-regime

Fix one cap edge \(h=za\), with \(p,h\) disjoint and cofacial, and put

\[
J=F-\{p,h\}.
\tag{2}
\]

Assume that \(u,z\) have the same bipartite colour. Thus \(v,a\) have the
other colour. For \(s,t\in\{u,v,z,a\}\), let \(H_{st}\) be the number of
Hamilton \(s\)-\(t\) paths in \(J\). Let

\[
\begin{aligned}
A&=(uv\mid za),\\
B&=(vz\mid ua),\\
C&=(uz\mid va)
\end{aligned}
\tag{3}
\]

be the three terminal pairings, and let \(L_A,L_B,L_C\) count spanning
two-path covers of \(J\) with the indicated pairing and no residual cycle.

Add the two edges of each pairing to \(J\), treating an added edge as a
separately labelled parallel edge if necessary. The three resulting graphs
are loopless cubic multigraphs. Smith--Thomason parity, applied to each
added edge, gives

\[
\begin{aligned}
H_{uv}&\equiv H_{za}\equiv L_B+L_C,\\
H_{vz}&\equiv H_{ua}\equiv L_A+L_C,\\
H_{uz}&\equiv H_{va}\equiv L_A+L_B
\end{aligned}
\pmod 2.
\tag{4}
\]

For example, a Hamilton cycle in \(J+\{uv,za\}\) which contains the
labelled edge \(uv\) either avoids \(za\), in which case deleting \(uv\)
gives a Hamilton \(u\)-\(v\) path, or contains both added edges, in which
case deleting them gives a two-path cover of type \(B\) or \(C\). The
number of cycles containing \(uv\) is even. This proves the first equation;
the other five are identical.

Eliminating the linkage variables shows that the complete path-only linear
information in (4) is

\[
\begin{aligned}
H_{uv}&\equiv H_{za},&
H_{vz}&\equiv H_{ua},&
H_{uz}&\equiv H_{va},\\
H_{uv}+H_{vz}+H_{uz}&\equiv0
\end{aligned}
\pmod2.
\tag{5}
\]

Since \(J\) has even order, a Hamilton path has endpoints in opposite
bipartition classes. Therefore

\[
H_{uz}=H_{va}=0,
\tag{6}
\]

and (5) collapses to

\[
\boxed{
H_{uv}\equiv H_{za}\equiv H_{vz}\equiv H_{ua}\pmod2.}
\tag{7}
\]

Cofacial planarity is not needed for (7). It additionally makes whichever
of the three two-linkage pairings crosses the terminal cyclic order vanish
as an integer.

The facial edge-source completion assertion of Note 022 asks for
\(H_{vz}>0\), while global \(H^{+-}\) supplies \(H_{uv},H_{za}>0\).
Consequently

\[
\boxed{H_{uv}\text{ odd}\Longrightarrow H_{vz}>0.}
\tag{8}
\]

This does not turn source nonemptiness into target nonemptiness. The
smallest formal parity pattern with positive sources and no target is

\[
H_{uv}=H_{za}=2,\qquad
H_{vz}=H_{ua}=H_{uz}=H_{va}=0,\qquad
L_A=L_B=L_C=0.
\tag{9}
\]

All six equations in (4) hold. This is an algebraic parity countermodel,
not a graph.

## A real all-even admissible cap

The obstruction to deriving oddness is already present in the order-\(16\)
global-\(H^{+-}\) brace from Note 022, with graph6 code

    OlCGHD@?g?_@@@A?_?k?P

Take

\[
(u,v,z,a)=(0,15,4,13),\qquad p=0\,15,\quad h=4\,13.
\tag{10}
\]

Exact counting gives

\[
\begin{array}{c|rrrrrr}
st&uv&za&vz&ua&uz&va\\ \hline
H_{st}&4&2&2&4&0&0
\end{array}
\tag{11}
\]

and

\[
(L_A,L_B,L_C)=(4,0,8).
\tag{12}
\]

The common-face order is \(u,v,a,z\), so \(B=(vz\mid ua)\) is the crossing
pairing and \(L_B=0\). Every count is even. The target happens to exist,
but its parity data are indistinguishable from the target-zero pattern
(9). Thus global \(H^{+-}\), planarity, the brace condition and source
nonemptiness do not force the oddness required by (8).

The fixed count is reproduced by

    uv run --python 3.12 --with networkx \
      units/barnette/scratch/worker-c4-hpm/verify_fec_terminal_parity_fixed_instance.py

with terminal marker
\(\texttt{FEC\_TERMINAL\_PARITY\_FIXED\_INSTANCE\_VERIFIED}\).

## Alternating-cycle exchange in the \(K\)-regime

Now assume that \(u,z\) have opposite colours. Retain the notation of
Note 022:

\[
\eta=\mathbf1+e_v-e_z,
\qquad
\mathcal I_\eta=
\{A:A^*\text{ is a spanning two-forest},\ p\in A,
\lambda_A=\eta\}.
\tag{13}
\]

Every member has the form \(A=M\cup\{p\}\), where \(M\) is a perfect
matching of \(F-\{u,z\}\). Let \(\Gamma\) be a vertex-disjoint union of
cycles in \(F-\{u,z\}\), and put

\[
R=A\cap E(\Gamma),\qquad
N=E(\Gamma)\setminus A,\qquad
A'=A\triangle E(\Gamma).
\tag{14}
\]

The load changes by the exact formula

\[
\lambda_{A'}(w)-\lambda_A(w)=\deg_N(w)-\deg_R(w).
\tag{15}
\]

Consequently \(\lambda_{A'}=\eta\) if and only if each constituent cycle is
\(M\)-alternating.

Assume this condition and let \(m=|R|=|N|\). Delete \(R^*\) from the dual
two-forest \(A^*\). The graph

\[
H_0=A^*-R^*
\tag{16}
\]

has exactly \(m+2\) components. Contract these components and use \(N^*\)
as the edges of a quotient multigraph \(Q_N\). It has \(m\) edges on
\(m+2\) vertices, and

\[
\boxed{
(A')^*\text{ is a spanning two-forest}
\Longleftrightarrow Q_N\text{ is a forest}.}
\tag{17}
\]

Thus an alternating matching flip is not enough: a loop or cycle in the
quotient is precisely the dual obstruction to connectedness of the primal
lollipop, equivalently the appearance of a residual cycle component.

Let \(s_i\) be the vertex of the dual cap triangle opposite \(h_i^*\). If
(17) holds, the two components of \(Q_N\) induce the two components of
\((A')^*\), and

\[
A'\in\mathcal F_i
\Longleftrightarrow
Q_N\text{ separates }s_i\text{ from the other two cap vertices}.
\tag{18}
\]

Hence an alternating cycle family carries a member of
\(\mathcal F_1\) to one of \(\mathcal F_2\) if and only if

1. every constituent cycle is alternating;
2. \(Q_N\) is a forest;
3. the new quotient partition isolates \(s_2\), rather than \(s_1\).

Conversely, for any \(A,A'\in\mathcal I_\eta\), their symmetric difference
is a vertex-disjoint union of alternating cycles, and (17)--(18) recover
exactly the required quotient forest and cap partition. This is a
necessary-and-sufficient exchange reduction of cross-fibre flexibility,
not an existence proof. Requiring the cycles to be flipped one at a time
while all intermediate supports remain in \(\mathcal I_\eta\) is stronger
and is not supplied by matching exchange.

## Fibre counts do not supply the missing exchange

Put \(N_i=|\mathcal F_i|\). Planarity gives \(N_3=0\), but pointwise cap
separation yields only

\[
|\mathcal I_\eta|=N_1+N_2.
\tag{19}
\]

There is no universal equality or parity relation between the two facial
fibres. In the same order-\(16\) brace, at

\[
z=13,\quad(u,v)=(14,15),\quad
(h_1,h_2,h_3)=(13\,4,13\,14,13\,12),
\tag{20}
\]

one has

\[
\#\operatorname{PM}(F-\{u,z\})=12,\qquad
|\mathcal I_\eta|=7,\qquad
(N_1,N_2,N_3)=(4,3,0).
\tag{21}
\]

Thus \(N_1=N_2\) and \(N_1\equiv N_2\pmod2\) are both false, and no
fixed-point-free involution can universally exchange the two valid fibres.
The closest witnesses in (21) differ on the alternating square

\[
0-1-2-3-0,
\tag{22}
\]

whose old and new half-cycles both give forests on the four-component
quotient in (17); the flip changes the isolated cap vertex without creating
a residual cycle.

Algebraically, let \(\Phi_i\) denote the spanning-two-forest partition
polynomial whose two components isolate \(s_i\) from the other cap vertices,
and give a primal edge \(e=ab\) dual weight

\[
w_e=y_e x_a x_b.
\tag{23}
\]

Then

\[
N_i=
[y_p\mathbf x^\eta]\,\Phi_i
\big|_{y_e=1\ (e\ne p)}.
\tag{24}
\]

The desired count is therefore a fixed-load coefficient of an all-minors
forest polynomial. A Pfaffian count of the near-perfect matchings does not
retain the quotient-forest filter in (17).

The fixed fibres and the exchange in (22) are checked by

    uv run --python 3.12 --with networkx \
      units/barnette/scratch/worker-c4-hpm/verify_k_common_deletion_exchange_boundary.py

with terminal marker
\(\texttt{K\_COMMON\_DELETION\_EXCHANGE\_BOUNDARY\_VERIFIED}\).

## Consequence for the cardinality criterion

The two regimes now have parallel exact boundaries:

- in the \(P\)-regime, terminal-completion parity proves FEC whenever the
  source count is odd, but a real admissible brace shows that oddness is not
  forced;
- in the \(K\)-regime, a successful move is exactly an alternating cycle
  family whose dual quotient remains a forest and changes the isolated cap
  vertex, while neither ordinary exchange nor fibre parity forces such a
  family.

Thus the remaining capped-brace problem is genuinely a connected-complement
selection theorem. A positive proof must distinguish positive even source
families from a zero target in the \(P\)-regime and must produce a
quotient-acyclic, cap-changing alternating family in the \(K\)-regime.
Neither Smith--Thomason parity, a Pfaffian near-matching count, nor an
unrefined cycle-space exchange contains that information.

Even a proof of these two assertions would settle only the cross traversal
at a tight splice. The mixed and retained--retained blocks of full
global-\(H^{+-}\) preservation would remain.
