> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A wide gate can be a restricted coloop

[Note 082](082-target-feasible-cycle-cubes-are-not-delta-matroids.md)
shows that alternating-cycle selection cannot prove gate escape by treating a
specified gate coordinate as nonloop.  One might still hope to prove the
stronger family statement separately for each of the two gates at a wide
site.  This note gives an infinite family of plane-brace counterexamples.

The obstruction is local: if the root and a gate are opposite edges of a
square, root separation forces that gate into every rooted target.  Even
arbitrarily long facial arcs do not remove this phenomenon.  Consequently the
two gates must remain coupled by a disjunction in any proof of neutral-target
existence.

## 1. Rooted targets and restricted coloops

Let \(G\) be cubic and let \(e=uv\) be an edge.  A perfect matching \(M\) is
an \(e\)-rooted target if \(e\in M\), \(G-M\) is the disjoint union of two
cycles, and \(u,v\) lie on different cycles.  Write

\[
\mathcal T_e=\{M:M\text{ is an }e\text{-rooted target}\}.
\tag{1}
\]

For a fixed edge \(g\), call \(g\) a restricted coloop of
\(\mathcal T_e\) when

\[
g\in\bigcap_{M\in\mathcal T_e}M.
\tag{2}
\]

This is only terminology for the rooted-target family; it is not a coloop of
the graphic or matching matroid.

**Opposite-square lemma.**  Suppose \(e=uv\) and \(g=xy\) are opposite
edges of a square

\[
u-v-y-x-u.
\tag{3}
\]

Then \(g\) belongs to every \(e\)-rooted target.

**Proof.**  If \(M\in\mathcal T_e\), then \(e\in M\), so the two square
edges \(ux,vy\) do not belong to \(M\).  If \(g=xy\notin M\), all three
edges of the path \(u-x-y-v\) lie in \(G-M\).  The endpoints of the root
would then lie in the same component, contrary to (1).  Hence \(g\in M\).
\(\square\)

## 2. An infinite family of wide plane-brace examples

Let \(n\ge8\) be even and let

\[
G_n=C_n\square K_2.
\tag{4}
\]

Write the rim cycles as

\[
(t_0t_1\ldots t_{n-1}t_0),\qquad
(b_0b_1\ldots b_{n-1}b_0),
\tag{5}
\]

and put, with indices modulo \(n\),

\[
T_i=t_it_{i+1},\qquad B_i=b_ib_{i+1},\qquad R_i=t_ib_i.
\tag{6}
\]

Choose the top rim as the distinguished face, take

\[
e=B_0,\qquad g_0=T_0,\qquad g_1=T_s,
\tag{7}
\]

where

\[
s\equiv0\pmod2,\qquad 4\le s\le n-4.
\tag{8}
\]

The four gate endpoints are distinct.  In the orientation
\((u,v,x,y)=(t_0,t_1,t_s,t_{s+1})\), the vertices \(u,x\) lie in the same
bipartition class, while the two residual facial paths have lengths
\(s-1\) and \(n-s-1\).  These lengths are odd and at least three.  Thus (7)
is a legal wide site in the project convention.

Every \(G_n\) is a simple plane cubic bipartite brace.  It is enough to
verify \(2\)-extendability.  Two rungs extend to the all-rung matching.  A
rung and a rim edge extend by adding the parallel rim edge and all available
rungs.  Two independent edges on the same rim extend by adding their two
parallel rim edges and all available rungs.  Finally, for one selected edge
on each rim, choose on each even rim the alternating perfect matching that
contains the selected edge.  These cases cover every independent edge pair.

The root \(B_0\) and the first gate \(T_0\) are opposite edges of the side
square

\[
b_0-b_1-t_1-t_0-b_0.
\tag{9}
\]

The opposite-square lemma already implies that \(T_0\) is a restricted
coloop.  The complete family can in fact be classified exactly.

## 3. Complete rooted-target classification

For every

\[
j\in\mathbb Z/n\mathbb Z\setminus\{-1,0,1\},
\tag{10}
\]

define

\[
M_j=
\{T_0,T_j,B_0,B_j\}
\cup
\{R_i:i\notin\{0,1,j,j+1\}\}.
\tag{11}
\]

Then

\[
\boxed{
\mathcal T_{B_0}
=\{M_j:j\notin\{-1,0,1\}\}.}
\tag{12}
\]

To prove completeness, use the dual octagonal-bipyramid description, with
the same argument for general even \(n\).  Let \(z,z'\) be the dual vertices
of the two rim faces and \(q_i\) the dual vertex of the \(i\)-th side face.
Then

\[
T_i^*=zq_i,\qquad B_i^*=z'q_i,\qquad R_i^*=q_{i-1}q_i.
\tag{13}
\]

Normalize a facewise-NAE colouring by \(c(z)=0\).  A matching edge is a
monochromatic dual edge.  Since \(B_0\in M\), one has

\[
c(z')=c(q_0).
\tag{14}
\]

If this common colour is \(1\), the upper and lower triangles respectively
forbid consecutive zeroes and consecutive ones.  The cyclic \(q_i\)-word is
alternating, and the monochromatic graph is the disjoint union of two stars.
Deleting the dual root edge does not give the rooted two-cycle condition.

Suppose instead that \(c(z')=c(q_0)=0\), and let \(k\) be the number of
zeroes among the \(q_i\).  They form an independent set on the equatorial
cycle.  The monochromatic graph consists of \(K_{2,k}\), on \(z,z'\) and
the zero vertices, together with one equatorial path for each cyclic run of
ones.  For \(k=1\), deleting the root leaves the root marks in the wrong
component relation.  For \(k\ge3\), the \(K_{2,k}\) part has cycle rank
\(k-1\ge2\).  Exactly \(k=2\) gives the rooted target profile: the second
zero is \(q_j\) with (10), and the monochromatic edges are precisely (11).
This proves both inclusions in (12).

It follows immediately that

\[
T_0\in M_j\quad\text{for every }j,
\qquad
T_s\in M_j\iff j=s.
\tag{15}
\]

Thus one gate is forced throughout the complete family, while the other is
omitted by every target except one.

## 4. Sharp width and exact boundary

At \(n=8\), the site has two residual facial paths of length three, the
smallest lengths allowed by the wide condition.  Its complete target family
has five members and gate profile

\[
10^4,\qquad11^1.
\tag{16}
\]

The complete brace census already used in
[Note 077](077-wide-complete-family-gate-escape-holds-through-reduced-order-twenty-six.md)
shows that smaller reduced orders have no legal wide plane-brace site.  The
order-\(16\) octagonal prism is therefore minimum.  The
[verification bundle](../computations/bundles/wide-restricted-gate-coloop/README.md)
independently enumerates its perfect matchings, verifies brace
\(2\)-extendability, reconstructs all five rooted targets and checks (16).

The statement

\[
\forall i\in\{0,1\}\ \exists M\in\mathcal T_e: g_i\notin M
\tag{17}
\]

is false, already at minimum width and throughout the infinite family (4).
What remains open is the strictly weaker, genuinely coupled assertion

\[
\boxed{
\exists M\in\mathcal T_e:
g_0\notin M\ \lor\ g_1\notin M.}
\tag{18}
\]

Equivalently, it remains unknown whether both gates of a legal wide site can
simultaneously be restricted coloops of the complete rooted-target family.
The prism family satisfies (18).  Hence any proof of neutral-target
existence must preserve the disjunction between the two gates rather than
split it into two independent gate-escape assertions.

**Exact conclusion.**  A gate of a legal wide site can be a restricted
coloop even in an infinite family of plane braces with arbitrarily long
residual facial arcs.  The opposite-square lemma is the forcing mechanism.

**Evidence level.**  The lemma, brace proof and classification (12) are
arbitrary-order analytic results.  The minimum order-\(16\) member has an
independent exhaustive certificate; sharpness also uses the complete
lower-order census of Note 077.

**Unresolved boundary.**  The two-gate disjunction (18), equivalently the
nonexistence of a restricted-coloop pair at a legal wide site, remains the
exact ordinary lifting interface.
