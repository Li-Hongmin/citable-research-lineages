> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every all-J1 double-vacancy group reduces to squares

[Note 333](333-three-j1-double-blocks-force-an-unbounded-square-equivalent-chain.md)
gives an exact square reduction for a canonical chain of any
number of \(J_1\) doubly vacant blocks. In a group containing
only these multiply vacant blocks and short blocks, a canonical
chain always occurs: choose the shortest consecutive interval
closed under the matching of the \(H/I\) slots. Noncrossing
forces precisely the chain of Note 333.

Let a Barnette parent have the compressed, gapless,
tight-target all-square opening of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix a target-free free group with ordinary even left and odd
right endports. Each complete block in the group is either
a short target-free block or a doubly vacant target-free
block
\[
D_j=(a_j,O_j,H_j,I_j,K_j,J_j,E_j,b_j)
\]
whose complementary matching contains \(O_jK_j=J_1\).
The number and placement of both kinds of block are
unrestricted; no singly vacant or other multiply vacant
block occurs in this group. Matching choices outside the
group and in other free groups are unrestricted.

**All-J1 reduction theorem.** If the group has at least
one doubly vacant block, it contains an induced canonical
chain \(R_{m,\mathbf k}\) of Note 333 with \(m\ge2\)
and every intervening short-corridor length positive.
The chain is a labeled four-terminal square-equivalent
patch. Replacing it by its square preserves Barnette
membership, every exterior-marked Hamilton decision,
and the selected compressed, gapless, tight-target
all-square opening. Repeating finitely many such strict
reductions removes every doubly vacant block from the
group. In particular, no group satisfying these
hypotheses has exactly one doubly vacant block.

If every vacancy outside the groups reduced this way
lies in a distinct internal block, the parent has a
Hamilton cycle through both site edges and its legal
site-expanded child is Hamiltonian. Old-cycle reflection
gives the same conclusions for groups consisting of
short blocks and \(J_3\) double blocks. This does not
classify groups mixing \(J_1\) and \(J_3\).

**Proof.** List the doubly vacant blocks as
\(D_1,\ldots,D_n\) in old-cycle order. The chord-isolation
lemma of [Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
places each \(O_jK_j\) on the common-face side and
excludes every other internal free chord of \(D_j\).
Every cross-block free chord lies on the opposite side by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
All complete blocks have an even number of free slots.

We first determine the mates of the \(H/I\) slots. An
ordinary short-block odd slot cannot match \(H_j\).
If the ordinary slot precedes \(D_j\), the chord encloses
its block's final even slot, complete blocks, and \(O_j\);
if it follows \(D_j\), the chord encloses
\(I_j,K_j,J_j,E_j\) and complete blocks. Each interior
has even size and the sole face-side exit from
\(O_jK_j\). Other \(J_1\) chords in complete
intermediate blocks have both ends inside or outside.
The right odd endport obeys the second count. A chord
from \(H_j\) to another block's \(J_\ell\) likewise
has even interior and one exit: for \(\ell<j\) it
encloses \(E_\ell\), complete blocks, and \(O_j\);
for \(\ell>j\) it encloses the four-slot tail of
\(D_j\), complete blocks, and
\(O_\ell,H_\ell,I_\ell,K_\ell\). The \(J_1\) chord
of \(D_\ell\) has both ends inside or outside.
Within \(D_j\), the odd alternatives are used,
old-cycle neighbours, or excluded internal chords.
Thus \(H_j\) must match \(I_\ell\) of another
doubly vacant block.

Similarly, an ordinary final even short-block slot or
the left even endport cannot match \(I_j\): on the left
its chord encloses complete blocks and \(O_j,H_j\),
and on the right it encloses \(K_j,J_j,E_j\), complete
blocks, and the endpoint block's first odd slot. Each
even interior has just the \(O_jK_j\) exit. Matching
\(I_j\) to another block's \(E_\ell\) gives the same
obstruction. For \(\ell<j\), its chord encloses
complete blocks and \(O_j,H_j\); for \(\ell>j\),
it encloses \(K_j,J_j,E_j\), complete blocks, and
\(O_\ell,H_\ell,I_\ell,K_\ell,J_\ell\). Again the
interior is even with the sole \(O_jK_j\) exit.
Internal mates in \(D_j\) are unavailable by chord
isolation, colour or old-cycle adjacency. Hence \(I_j\)
must match \(H_\ell\) of another double block.

The complementary matching therefore induces a
noncrossing perfect matching on the ordered special
slots
\[
H_1,I_1,H_2,I_2,\ldots,H_n,I_n,                    \tag{1}
\]
with no same-block \(H_jI_j\) pair, since that edge
belongs to the old cycle. In particular \(n=1\) is
impossible. For \(n\ge2\), the full index interval
\([1,n]\) is closed under this special-slot matching.
Choose a consecutive index interval \([p,q]\) of
minimum size among those whose every special slot
matches another special slot inside the interval.
It has \(m=q-p+1\ge2\).

The mate of \(H_p\) must be \(I_r\) with \(p<r\le q\).
If \(r<q\), the opposite-side chord \(H_pI_r\)
contains all the other special slots of blocks
\(p,\ldots,r\). None can match outside it without
crossing that chord, so \([p,r]\) would be a smaller
closed interval. Therefore \(H_pI_q\) is present.
Now \(I_p\) must match some \(H_s\) with
\(p<s\le q\). If \(s>p+1\), the complete pairs
\((H_t,I_t)\) for \(p<t<s\) lie strictly inside
\(I_pH_s\) and must match among themselves. That
would make \([p+1,s-1]\) a smaller nonempty closed
interval. Hence \(I_pH_{p+1}\) is forced. Repeating
the same argument from \(I_{p+1}\) gives
\[
H_pI_q,\qquad I_jH_{j+1}\quad(p\le j<q).          \tag{2}
\]

For each \(p\le j<q\), the chord \(I_jH_{j+1}\)
encloses \(K_j,J_j,E_j\), the short blocks between
\(D_j,D_{j+1}\), and \(O_{j+1}\). The first and
last enclosed slots match across its boundary through
\(O_jK_j,O_{j+1}K_{j+1}\). All other enclosed free
slots must match inside the chord. If there were no
short block, \(J_j,E_j\) would have only their forbidden
old-cycle edge. Thus the corridor length \(k_j\) is
positive. As proved in Note 332, noncrossing and the
absence of two-edge cuts force its exact matching:
\[
J_je_{j,k_j},\quad E_jo_{j,1},\quad
e_{j,t}o_{j,t+1}\quad(1\le t<k_j).                 \tag{3}
\]
Equations (2)--(3), all \(O_jK_j\) in the interval,
the face-closing chords and the old-cycle path are
exactly Note 333's induced patch \(R_{m,\mathbf k}\).
All its vertices except \(a_p,J_q,E_q,b_q\) have their
third edges internally, so no outside matching can alter
the patch. Note 333 gives its complete square Hamilton
signature and two-way Barnette-preserving replacement.

The replacement square follows the old-cycle order
\(a_p',J_q',E_q',b_q'\) with common-face chord
\(a_p'b_q'\). The contiguous original face-block arc
becomes one short target-free block. No other vacancy,
target, site edge or interblock gap is changed, and the
surviving opposite-side matching endpoints keep their
cyclic order. Hence the reduced parent retains all
hypotheses, with \(m\ge2\) fewer doubly vacant blocks.
Iterate; strict vertex descent makes the process finite.
One double block cannot remain by the mate argument above,
so all disappear.

Apply these reductions to every group of the stated
type. If all other vacancies occupy distinct internal
blocks, the final Barnette opening satisfies Note 324,
which supplies a Hamilton parent cycle through both
site edges. Lift it through the exact four-terminal
reductions; [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
then gives the legal child's Hamilton cycle. Reflect
the old-cycle order for the \(J_3\) statement.
\(\square\)

This theorem closes an unrestricted number of \(J_1\)
double blocks within each specified ordinary target-free
group, including nested and separated special-slot
matchings. It does not handle a group mixing \(J_1\)
and \(J_3\), a singly vacant block alongside multiple
double blocks, other internal matching chords, a
target-bearing terminal vacancy, a positive gap,
defective target order, a nonsquare residual cycle,
or the general Barnette conjecture. The argument is
analytic and project-internal; no external priority
or independent review is claimed.
