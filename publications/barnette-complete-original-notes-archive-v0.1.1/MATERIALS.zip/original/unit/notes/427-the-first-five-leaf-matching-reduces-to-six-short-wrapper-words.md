> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first five-leaf matching reduces to six short-wrapper words

In [Note 426](426-five-leaf-face-matchings-have-three-unresolved-shapes.md), row I has only one boundary where two ineligible leaves may be siblings in a legal non-Hamiltonian child. This forces a short, explicit list of ordinary trees in the chorded single-hexagon $f=7,c=31,s=2$ kernel. Row II is its reflection.

Use the seven-leaf full binary tree of [Note 425](425-short-wrapper-parity-and-terminal-spine-paths.md). Every leaf and branch has the full ordinary word except one short node $v$. In row I, let the five ineligible leaves be $a,b,c,d,e$, with face matching
\[
 x_ay_b,\quad y_ax_b,\quad x_cy_e,\quad y_cx_d,\quad y_dx_e.
 \tag{1}
\]
The sites are, up to reflection of the entire graph, $(j,k)=(1,2)$ or $(1,7)$. By Note 426, a hypothetical non-Hamiltonian child must have the ineligible sibling pair $(b,c)$. In the two site placements this is respectively leaf pair $(4,5)$ or $(3,4)$.

**Six-word necessary theorem.** If a legal row-I child is non-Hamiltonian, its full-tree leaf-depth vector $(d_1,\ldots,d_7)$ and short leaf are one of the following:

| Sites $(j,k)$ | Leaf depths in order | Short leaf | Shape |
| --- | --- | --- | --- |
| $(1,2)$ | $(1,3,4,6,6,5,2)$ | $6$ | comb |
| $(1,2)$ | $(1,3,5,6,6,4,2)$ | $3$ | comb |
| $(1,7)$ | $(1,2,6,6,5,4,3)$ | $5$ | comb |
| $(1,7)$ | $(3,4,6,6,5,2,1)$ | $5$ | comb |
| $(1,7)$ | $(3,5,6,6,4,2,1)$ | $2$ | comb |
| $(1,7)$ | $(1,2,4,4,4,5,5)$ | $6$ | two cherries |

The last row is the explicit ordinary word
\[
\begin{aligned}
 A&=F(U_3,U_4),&D&=F(U_6^{\rm short},U_7),\\
 B&=F(U_5,D),&C&=F(A,B),\\
 E&=F(U_2,C),&W&=F(U_1,E),
\end{aligned}                                                    \tag{2}
\]
where $F(P,Q)=(((P Q)))$, $U_i=((x_i y_i))$, and $U_6^{\rm short}=(x_6y_6)$. Every comb in the table is uniquely specified by its ordered depth vector, with the indicated short leaf. This is a necessary list, not six asserted Barnette realizations or six non-Hamiltonian graphs.

**Proof.** In row I the face matching (1) pairs $a,b$ wholly to each other and has joining chords $y_cx_d,y_dx_e$. Thus any ineligible sibling pair other than $(b,c)$ gives the two-edge cut or the serial-pole Hamilton reduction of Note 426. A sibling pair containing both sites would also make the child Hamiltonian by [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md). Since the two sites are the only even-indexed $x$-leaves, a sibling pair containing one site and one ineligible leaf requires the short node to be that ineligible leaf; the pair has odd depth. There is at most one such pair because the short node is unique.

Suppose first that $(b,c)$ is the tree's only sibling-leaf pair. A full binary tree with one sibling-leaf pair is a comb, and in a seven-leaf comb that pair has depth six. Its five singleton leaves have depths $1,2,3,4,5$ once each. A short branch at odd depth would leave five eligible leaves: its subtree contains two more even-depth than odd-depth leaves. Thus, because $s=2$, the short node is a singleton leaf of odd depth. The other two odd-depth singleton leaves are exactly the sites.

For sites $(1,2)$, the cherry is $(4,5)$. The singleton leaves before it are $1,2,3$, with strictly increasing depths, and those after it are $6,7$, with strictly decreasing depths. Making leaves $1,2$ odd leaves only the left-depth choices $(1,3,4)$ or $(1,3,5)$; the remaining depths on the right are respectively $(5,2)$ or $(4,2)$. These are the first two rows of the table. For sites $(1,7)$ the cherry is $(3,4)$; singleton depths increase at leaves $1,2$ and decrease at leaves $5,6,7$. Requiring leaves $1,7$ odd leaves exactly the choices
\[
 (d_1,d_2;d_5,d_6,d_7)
 =(1,2;5,4,3),\ (3,4;5,2,1),\ (3,5;4,2,1),
\]
giving the next three rows. In each case the remaining odd-depth singleton is the short leaf.

Now suppose the tree has another sibling-leaf pair. It must consist of one site and the short ineligible leaf, because $(b,c)$ is the only permitted ineligible pair. Hence the short node is a leaf at odd depth, and the three odd-depth leaves of the full tree are the two sites and that short leaf by Note 425. The site-short pair can only be $(2,3)$ when $(j,k)=(1,2)$, or $(1,2)$ or $(6,7)$ when $(j,k)=(1,7)$. These give depth-parity words $OOOEEEE$, $OOEEEEO$ and $OEEEEOO$ respectively.

For completeness, use the parity-word recurrence of [Note 419](419-depth-parity-forces-three-odd-leaves-in-the-maximal-seven-face-chord-kernel.md): a root split is possible only when the signed sum of the left block is $-1\pmod3$, with $E=+1,O=-1$; the child words are the letterwise complements of the two blocks. The four-leaf relative word $EEEE$ is the balanced tree with two cherries; $OOOE$ and $EOOO$ each have the middle two leaves as their cherry. The three-leaf words $OEE$ and $EEO$ have respectively the last and first two leaves as their cherry. These facts follow by applying the same recurrence once to words of at most four leaves.

For $OOOEEEE$ the root splits are $1|6,5|2$. The latter makes $(6,7)$ siblings; in the former, the six-leaf side splits $2|4$ or $5|1$. The $2|4$ split again makes $(6,7)$ siblings, and the $5|1$ split, if $(2,3)$ are siblings, makes $(5,6)$ siblings. Both are forbidden by (1).

For $OOEEEEO$ the root splits are $1|6,3|4,6|1$. The first prevents $(1,2)$ from being siblings. The middle split forces $(5,6)$ to be siblings. At $6|1$ the six-leaf side has splits $2|4,5|1$; the first forces $(5,6)$, while the second, if $(1,2)$ are siblings, forces $(4,5)$. All are forbidden. For $OEEEEOO$ the root splits are $1|6,4|3,6|1$. The last prevents $(6,7)$ from being siblings and the middle forces $(2,3)$. At $1|6$ the six-leaf side splits $4|2$ or $1|5$. The former forces forbidden $(2,3)$ and $(4,5)$ pairs. In the latter, the five-leaf side splits $2|3$ or $4|1$; only $2|3$ retains sibling pair $(6,7)$, and it gives exactly (2), with the permitted pair $(3,4)$. This is the last row. No other tree or short-node placement survives. \(\square\)

The six words still require Hamilton analysis. The result is limited to row I and its reflection in the two-eligible, chorded $f=7,c=31$ branch.
