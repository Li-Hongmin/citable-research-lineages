> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every right-short \(Js\) return has an exact square reduction

[Note 396](396-two-short-flanks-reduce-outside-one-boundary-branch.md)
leaves the \(hz,Js\) right return with \(Er\) and no internal free
chord of the doubly vacant block. [Note 397](397-a-right-short-return-core-has-the-exact-square-signature.md)
reduces its ordinary-link word. Here the matching is classified at
every corridor length, and every remaining cutpoint word has the
same exact four-terminal reduction.

Use the selected opening and block order of Note 396:
\[
 S_0=(c,p,q,d),\quad V=(a,o,h,i,e,b),\quad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\quad
 D=(A,O,H,I,K,J,E,B),\quad T=(C,r,s,F),\qquad m\ge1.
\tag{1}
\]
The complementary matching contains \(tp,qo,hz,Js,Er\).
All cross-block free chords lie opposite the selected common face,
are pairwise noninterlacing, and no internal free chord of \(D\)
occurs. A nonempty proper interval of complete consecutive blocks
cannot be matching-closed, because its two old-cycle boundary edges
would form a two-edge cut. These are the only inherited facts used
in the classification below.

For \(1\le r<m\), put
\[
\begin{split}
 N_{m,r}=\{&iK,ep_1,q_rI,p_{r+1}H,q_mO,Js,Er\}\\
 &{}\cup\{q_jp_{j+1}:1\le j<m,\ j\ne r\},
\end{split}                                                   \tag{2}
\]
and write \(N_{m,m}\) for Note 397's ordinary word
\[
 N_{m,m}=\{iK,eI,p_1H,q_mO,Js,Er\}
       \cup\{q_jp_{j+1}:1\le j<m\}.                          \tag{3}
\]
The subscript \(r\) is a corridor cutpoint; the unsubscripted
\(r\) in \(Er\) is the vertex of the right short block.

**Complete right-short-return theorem.** Every actual matching
under (1) and the stated boundary edges is exactly
\(N_{m,r}\) for one unique \(1\le r\le m\), besides the
fixed exterior edges \(tp,qo,hz\). For each word, the induced
disk four-pole on \(V,S_1,\ldots,S_m,D,T\), with boundary
terminals \((a,o,h,F)\), has precisely the square's four
spanning one-path and two spanning two-path Hamilton states.
Replacing it by the labeled square, in either direction,
preserves Barnette membership and every exterior- and
attachment-marked Hamilton decision. Hence every actual
\(hz,Js\) return contains a strict exact square reduction,
at every \(m\ge1\).

**Matching classification.** After \(Js,Er\), the only free
slots in the pole are
\[
                    i,e,(p_j,q_j)_{j=1}^m,O,H,I,K.          \tag{4}
\]
The odd slot \(i\) can meet only a \(q_j\), \(H\), or \(K\).
If \(iq_j\) occurs, its interior forces \(ep_1\) and
\(q_kp_{k+1}\) for \(k<j\): skipping a complete short-block
run would match-close that run. No free chord can cross
\(iq_j\), so the complete suffix
\(S_{j+1},\ldots,S_m,D,T\) is matching-closed when \(j<m\).
Here \(Js,Er\) lie *inside* this suffix. Its two old-cycle
boundary edges would be a two-edge cut. When \(j=m\), the
remaining \(O,H,I,K\) have no available mate, since \(D\)
has no internal free chord. Thus no \(iq_j\) occurs.
If \(iH\) occurs, \(I,K\) lie outside it and cannot reach
an earlier slot on the opposite side; they have no internal
free chord or other available mate. Therefore \(iK\) is
forced.

Inside \(iK\), the slot \(e\) can meet only \(p_j,O,I\).
An edge \(ep_j\) with \(j>1\) match-closes
\(S_1,\ldots,S_{j-1}\), and \(eO\) match-closes
\(S_1,\ldots,S_m\). Hence \(M(e)=p_1\) or \(I\).

If \(eI\) occurs, the even slot \(H\) must meet some
\(p_s\). For \(s>1\), the complete prefix
\(S_1,\ldots,S_{s-1}\) is matching-closed, so \(p_1H\)
is forced. The slot \(O\) must meet \(q_t\); if \(t<m\),
\(q_tO\) match-closes \(S_{t+1},\ldots,S_m\). Thus
\(q_mO\) is forced, and the remaining short slots pair
successively as \(q_jp_{j+1}\). This is (3).

If \(ep_1\) occurs, \(H\) must meet \(p_s\) for \(s\ge2\),
\(I\) must meet \(q_r\), and \(O\) must meet \(q_t\).
Noninterlacement with \(p_sH\) gives \(r<s\le t\).
As above, \(q_tO\) forces \(t=m\). If \(r<s-1\),
the complete run \(S_{r+1},\ldots,S_{s-1}\) is
matching-closed; hence \(s=r+1\). The only possible
noninterlacing matches before \(q_r\) and inside
\(p_{r+1}H\) are the ordinary links
\(q_jp_{j+1}\) for \(j\ne r\): skipping any link
would match-close an intervening complete short-block run.
This gives (2), and the mate of \(e\), then the mate of
\(I\), determines \(r\) uniquely.

**Six states of the cutpoint core.** The case \(r=m\) is
Note 397. For \(r<m\), compress the induced ordinary-link
ladders \(S_1\cup\cdots\cup S_r\) and
\(S_{r+1}\cup\cdots\cup S_m\) separately to one square each
using [Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
Their respective four attachment edges are
\[
 (bc_1,ep_1,q_rI,d_rc_{r+1}),\qquad
 (d_rc_{r+1},p_{r+1}H,q_mO,d_mA).                         \tag{5}
\]
The resulting 26-vertex core has \(m=2,r=1\), with
matching \(iK,ep_1,q_1I,p_2H,q_2O,Js,Er\).
Every consecutive pair in the following rows is an
old-cycle edge, one of the block-closing face chords,
or a listed matching edge:
\[
\begin{array}{c|l}
aF&
 a,o,h,i,e,b,c_1,p_1,q_1,d_1,c_2,p_2,q_2,d_2,
 A,O,H,I,K,J,E,B,C,r,s,F\\
oh&
 o,a,b,e,p_1,c_1,d_1,q_1,I,H,p_2,c_2,d_2,q_2,
 O,A,B,E,r,C,F,s,J,K,i,h\\
ao&
 a,b,e,p_1,c_1,d_1,q_1,I,H,p_2,c_2,d_2,q_2,
 O,A,B,E,r,C,F,s,J,K,i,h,o\\
hF&
 h,o,a,b,c_1,p_1,e,i,K,I,q_1,d_1,c_2,p_2,H,O,
 q_2,d_2,A,B,E,J,s,r,C,F .
\end{array}                                                   \tag{6}
\]
The two disjoint spanning path pairs are
\[
\begin{array}{c|l}
\{ao,hF\}&
 (a,o),\quad
 (h,i,K,I,q_1,p_1,e,b,c_1,d_1,c_2,p_2,H,O,
 q_2,d_2,A,B,E,J,s,r,C,F)\\
\{aF,oh\}&
 (o,h),\quad
 (a,b,c_1,p_1,e,i,K,I,q_1,d_1,c_2,p_2,H,O,
 q_2,d_2,A,B,E,J,s,r,C,F).
\end{array}                                                   \tag{7}
\]
Each row uses every core vertex once. Terminal colours are
\(a,h\) on one side and \(o,F\) on the other, excluding
the other two one-path pairs. The third two-path pairing
\(\{ah,oF\}\) interlaces the terminal order
\((a,o,h,F)\) in the disk and is impossible. Hence (6)--(7)
are the complete square signature. Note 178 lifts each
state through both ladders with its four labeled attachments
unchanged.

**Barnette-class comparison.** Cap the 26-vertex core by a
fresh square \((x_a,x_o,x_h,x_F)\), attaching its vertices
respectively to \(a,o,h,F\). The full old-cycle path through
the core, followed by \(x_F,x_h,x_o,x_a,a\), is a Hamilton
cycle of the 30-vertex cap. On one page of this cycle its
complementary matching has the pairwise disjoint chords
\[
             ab,c_1d_1,c_2d_2,AB,CF,x_ax_F;
\]
on the other it has the nested or disjoint chords
\[
             iK,ep_1,q_1I,p_2H,q_2O,Js,Er,ox_o,hx_h.
\tag{8}
\]
All chords join opposite cycle parities, so the cap is
simple, cubic, bipartite and plane. Its matching-chord
interlacement graph is connected: a spanning tree is
\[
\begin{gathered}
 x_ax_F-ox_o-ab-iK-AB-q_1I-c_1d_1-ep_1,\\
 AB-p_2H-c_2d_2-q_2O,\qquad AB-Js-CF,\\
 AB-Er,\qquad ab-hx_h .
\end{gathered}                                                  \tag{9}
\]
Every dash denotes alternating endpoints in the stated
Hamilton order. A two-edge cut would isolate a proper
Hamilton-cycle interval closed under the complementary
matching and disconnect this interlacement tree. The
Hamilton cycle rules out bridges; cubic three-edge
connectivity implies three-vertex-connectivity. Thus the
cap is Barnette.

The uncapped core remains connected after deletion of any
one vertex. Each of its five blocks remains connected after
one deletion. The \(V\)--\(S_1\) joins \(bc_1,ep_1\)
have disjoint endpoints; the alternate \(V\)--\(D\) and
\(S_1\)--\(D\) joins \(iK,q_1I\) cannot both be lost
by one deletion. The \(S_2\)--\(D\) joins
\(d_2A,p_2H,q_2O\) and the \(D\)--\(T\) joins
\(BC,Js,Er\) also have distinct endpoints within
each set. Hence all surviving block cycles stay connected.
After any two core vertices are deleted, each remaining
component meets a surviving terminal: otherwise it would
be separated by the same deletions in the three-connected
cap. The labeled square has the same one- and two-deletion
properties. The four-attachment comparison proved in
[Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md)
therefore preserves three-connectivity in both directions.
The terminal colours and disk order preserve bipartiteness
and planarity. The connected exterior of a Barnette host
lies on one side of the four-pole boundary, leaving a disk
for the replacement. The six states preserve every exterior
edge and every used attachment. Applying Note 178 in
reverse to both ladders proves the same comparison for all
\(m,r\). The cutpoint pole has \(18+4m\) vertices, so
replacement by a square is strict. \(\square\)

Together with Note 397, this closes the entire \(hz,Js\)
branch of Note 396 for arbitrary positive corridor length.
It does not settle the other \(hz\) returns \(si\) and
\(sp_j\) for \(j<m\), the \(zK\) six-state question,
other selected openings, or Barnette's conjecture.
The result is an internal analytic proof and has not had
independent external review or a literature priority claim.
