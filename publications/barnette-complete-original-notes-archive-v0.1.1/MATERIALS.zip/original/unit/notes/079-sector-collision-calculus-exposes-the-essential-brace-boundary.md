> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Sector defects reduce to long two-hole bonds and expose the brace boundary

[Note 076](076-complete-gate-forcing-reduces-to-three-rooted-sector-incidences.md)
reduces ordinary wide \(C_4\)-lifting to one unresolved implication: a
complete terminal-fixed target family forcing both gates should contain a
target for which one of \(I_L,I_R,I_{LR}\) is a rooted forest.  This note
first corrects the formal sector calculus by using the fact that every
component of the monochromatic forest has one colour.  The three incidences
then reduce exactly to two one-sided tests.  Their only cycle defects are
parallel repetitions, each of which is a primal bond saturated by the target
matching except for two independent holes.

A real order-\(20\) common-perfect-matching countermodel shows that exhaustive
multi-bond closure and extension of the local hole pairs still do not force a
good target.  Its sole missing brace layer is global \(2\)-extendability,
coming from two unrelated nontrivial tight \(3\)-cuts.  Thus the remaining
brace theorem is a genuinely global family-selection problem, not a local
collision calculation.

Throughout, use the notation of Note 076.  For a reduced target colouring
\(c\), normalised by \(c(z)=0\), put

\[
R=H(c)-a,\qquad P=R-z.
\tag{1}
\]

Write \(B(y)\) for the component of \(P\) containing a boundary vertex
\(y\), and let \(\mu,\nu\) be the two root-marked components.  For a multiset
\(X\) of components, write

\[
[X]=\operatorname{supp}X,
\qquad d(X)=|X|-|[X]|.
\tag{2}
\]

## 1. Monochromaticity removes every mixed collision

Every edge of \(H(c)\) has equally coloured ends.  Hence every component of
\(P\) is monochromatic.  With

\[
\begin{aligned}
L_i&=\{B(y):y\in A_L,\ c(y)=i\},\\
R_i&=\{B(y):y\in A_R,\ c(y)=i\},
\end{aligned}
\tag{3}
\]

where \(L_1,R_1\) are multisets and \(L_0,R_0\) are sets, one has

\[
\begin{aligned}
[L_1]\cap R_0&=\varnothing,\\
L_0\cap[R_1]&=\varnothing,\\
\bigl([L_1]\cup[R_1]\bigr)
\cap\{B(x_2),B(x_4)\}&=\varnothing.
\end{aligned}
\tag{4}
\]

The set assertion for zero-coloured neighbours uses the forest property:
two distinct zero neighbours of \(z\) in one \(P\)-component, together with
their two edges to \(z\), would form a cycle in \(R\).

Consequently the one-sided sector ranks in Note 076 simplify to the exact
formulas

\[
\boxed{
\beta(I_L)=d(L_1),\qquad
\beta(I_R)=d(R_1).}
\tag{5}
\]

There is no colour-\(1\)/colour-\(0\) overlap term.  An eligible one-sided
incidence is cyclic exactly when two colour-\(1\) positions on its alternating
arc lie in the same component of \(P\).

If the root blocks are distinct, their path in the forest \(R\) must pass
through \(z\), so both are zero-coloured blocks.  The exact rooted tests are
therefore

\[
\boxed{
\begin{aligned}
I_L\text{ is a rooted forest}
\iff{}&
A_L\text{ alternates},\quad d(L_1)=0,\\
&\mu=\nu\text{ or }\{\mu,\nu\}\subseteq R_0;\\[1mm]
I_R\text{ is a rooted forest}
\iff{}&
A_R\text{ alternates},\quad d(R_1)=0,\\
&\mu=\nu\text{ or }\{\mu,\nu\}\subseteq L_0.
\end{aligned}}
\tag{6}
\]

These are equivalences, not sufficient conditions.

## 2. The third sector is dominated by the first two

When both arcs alternate, the colour-\(1\) stars of \(I_{LR}\) may share
components, but by (4) neither can meet the zero-coloured gate star.  Hence

\[
\boxed{
\beta(I_{LR})=d(L_1)+d(R_1)
+\bigl(|[L_1]\cap[R_1]|-1\bigr)_+.}
\tag{7}
\]

More strongly, \(I_{LR}\) never supplies the unique accepting row.

**Two-sector dominance theorem.**  If \(I_{LR}\) is a rooted forest, then
both \(I_L\) and \(I_R\) are rooted forests.

**Proof.**  A forest \(I_{LR}\) has no repeated edge at either colour-\(1\)
star, so \(d(L_1)=d(R_1)=0\).  By (5), both one-sided incidences are forests.
If \(\mu=\nu\), each already joins the root marks.  Suppose
\(\mu\ne\nu\).  Both root blocks are zero-coloured, and the only
nontrivial component of \(I_{LR}\) containing zero blocks is the gate star
on \(B(x_2),B(x_4)\).  Root connectivity therefore forces

\[
\{\mu,\nu\}=\{B(x_2),B(x_4)\}.
\]

Both gate blocks belong to both closed zero-sectors \(L_0,R_0\), so (6)
makes both one-sided incidences rooted forests. \(\square\)

Thus Note 076(14) is exactly the following two-sector statement:

\[
\boxed{
\begin{gathered}
\text{some target has an alternating side whose colour-\(1\) blocks are}\\
\text{pairwise distinct and whose roots are equal or both lie in the}\\
\text{opposite closed zero-sector.}
\end{gathered}}
\tag{TS}
\]

No \(I_{LR}\)-specific family theorem remains.  If both sides alternate and
both repetition defects vanish, failure of both one-sided tests has the
sharp form

\[
\mu\in L_0\setminus R_0,\qquad
\nu\in R_0\setminus L_0
\tag{8}
\]

after exchanging the roots if necessary: the two roots occupy opposite open
gate sectors.

## 3. A parallel collision is a primal two-hole bond

Assume \(A_L\) alternates and two distinct colour-\(1\) boundary vertices
\(y,y'\in A_L\) lie in the same component of \(P\).  Let \(Q\) be their
unique path in \(P\), and write

\[
q=|E(Q)|\ge1.
\tag{9}
\]

The edges of \(Q\) are monochromatic, whereas \(zy,zy'\) are bichromatic.
Therefore

\[
K=zy\cup Q\cup y'z
\tag{10}
\]

is a simple dual cycle.  In the plane cubic primal graph, \(K^*\) is a bond,
and for the target perfect matching \(M\),

\[
\boxed{
|K^*|=q+2,\qquad |M\cap K^*|=q.}
\tag{11}
\]

The two missing primal edges, dual to \(zy,zy'\), are independent because
the two same-parity positions of an alternating face arc are nonconsecutive.
Thus every sector collision is exactly a bond saturated by \(M\) except for
two independent holes.

If \(q=1\), the dual cycle \(K\) is a nonfacial triangle: a facial triangle
at \(z\) uses consecutive neighbours.  Hence \(K^*\) is a nontrivial
\(3\)-edge cut.  It is tight.  Indeed, for either shore \(S\) and primal
bipartition \(X\sqcup Y\), if \(p\) cut edges leave \(X\cap S\) and \(r\)
leave \(Y\cap S\), then

\[
p+r=3,\qquad
3\bigl(|X\cap S|-|Y\cap S|\bigr)=p-r.
\tag{12}
\]

The difference \(p-r\) is divisible by \(3\) and has odd absolute value at
most \(3\), so all three cut edges have the same orientation.  Every perfect
matching meets the cut exactly once.  A plane cubic bipartite brace has no
such nontrivial tight cut, and therefore

\[
\boxed{\text{every sector-collision path in a plane brace has }q\ge2.}
\tag{13}
\]

For \(q\ge2\), (11) is a bond of size at least four.  Since the two holes are
independent, \(2\)-extendability gives some perfect matching \(N\) containing
both.  This is the exact local content of the brace axiom.  It does not say
that \(N\) contains the fixed root and gates, that its complement has the
target two-cycle shape, or that the resulting boundary arc remains eligible.
It therefore does not produce a target-preserving collision-shortening move.

## 4. Common incidence and exhaustive closure still do not suffice

The failure above is strict inside one actual simple planar cubic bipartite
graph.  Let \(G\) have bipartition classes \(\{0,\ldots,9\}\) and
\(\{10,\ldots,19\}\), with adjacency lists

\[
\begin{array}{c|c@{\qquad}c|c}
0&10,11,12&5&13,15,17\\
1&10,11,13&6&14,15,19\\
2&10,12,13&7&16,17,18\\
3&11,14,15&8&16,18,19\\
4&12,14,16&9&17,18,19.
\end{array}
\tag{14}
\]

It is simple, planar, cubic, bipartite, matching-covered and
three-connected.  Fix the facial octagon

\[
C=(13,5,17,7,16,4,12,2),
\tag{15}
\]

the opposite gates \(5\,13\) and \(4\,16\), and root \(3\,15\).  Put

\[
\begin{aligned}
F&=\{3\,15,4\,16,5\,13,6\,14\},\\
L_0&=\{0\,11,1\,10,2\,12\},&
L_1&=\{0\,12,1\,11,2\,10\},\\
R_0&=\{7\,17,8\,18,9\,19\},&
R_1&=\{7\,18,8\,19,9\,17\}.
\end{aligned}
\tag{16}
\]

Among all \(81\) perfect matchings, the complete rooted target family is
exactly

\[
\mathcal T_e=\{F\cup L_i\cup R_j:i,j\in\{0,1\}\}.
\tag{17}
\]

Every target contains both gates, and the family is the complete \(2\)-cube
generated by the two vertex-disjoint alternating \(6\)-cycles
\(L_0\triangle L_1\) and \(R_0\triangle R_1\).  It therefore contains both
single toggles and the simultaneous terminal-fixed multi-bond toggle.

In the cyclic order (15), the boundary words and eligible incidences are

\[
\begin{array}{c|c|c}
F\cup L_0\cup R_0&01010101&I_L,I_R,I_{LR}\\
F\cup L_0\cup R_1&01110101&I_R\\
F\cup L_1\cup R_0&01010111&I_L\\
F\cup L_1\cup R_1&01110111&\varnothing.
\end{array}
\tag{18}
\]

Every eligible incidence in (18) has a parallel repetition while its root
blocks are joined, and the exact eight-row test finds no lift.  The two
repeated-sector paths are

\[
8-11-10,\qquad 1-0-4,
\tag{19}
\]

so both have \(q=2\) and give \(4\)-edge collision bonds.  Their hole pairs
are

\[
\{5\,17,7\,16\},\qquad
\{4\,12,2\,13\}.
\tag{20}
\]

Both pairs extend to perfect matchings of \(G\).  Thus even local extension
of every displayed collision pair does not imply a target repair.

The graph instead fails global \(2\)-extendability at two different
nontrivial tight \(3\)-edge cuts,

\[
K_L=\{3\,11,4\,12,5\,13\},
\qquad
K_R=\{4\,16,5\,17,6\,19\}.
\tag{21}
\]

The six pairs of distinct edges lying in one of these cuts are exactly all
nonextendible independent pairs; every other independent pair extends.
Dually, the Eulerian plane triangulation is \(3\)-connected rather than
\(4\)-connected.

This proves the strict boundary

\[
\boxed{
\begin{gathered}
\text{common perfect-matching incidence, exhaustive target closure, and}\\
\text{extension of the displayed collision-hole pairs}\\
\not\Longrightarrow\text{a good rooted sector incidence}\\
\text{without the global brace axiom.}
\end{gathered}}
\tag{22}
\]

The explicit object, complete family equality, sector failures, all local
rows and all independent edge pairs are checked by the
[order-20 terminal-fixed sector countermodel bundle](../computations/bundles/order20-terminal-fixed-sector-countermodel/README.md).

## 5. Exact remaining brace-specific boundary

Between any two actual targets \(c,d\) in one complete terminal-fixed family,
write

\[
E(H(d)-a)=E(H(c)-a)\mathbin\triangle\delta(D),
\qquad D\cap\{z,x_2,x_4\}=\varnothing.
\tag{23}
\]

If

\[
X=E(H(c)-a)\cap\delta(D),\qquad
Y=\delta(D)\setminus E(H(c)-a),
\tag{24}
\]

then both endpoint graphs are three-component forests on the same vertex
set, so

\[
|X|=|Y|.
\tag{25}
\]

After the components of \((H(c)-a)-X\) are contracted, \(Y\) is a forest of
\(|X|\) independent joins.  This balanced three-forest exchange is the
complete rank information supplied by an existing family toggle.  A sector
collision, however, is a monochromatic path incidence and does not by itself
produce a shore \(D\) whose toggle preserves NAE, the root, the gates and the
target shape.

By (5)--(13), a hypothetical brace counterexample to (TS) can have only:

1. an ineligible arc;
2. an eligible arc with a repeated component whose two-hole bond has length
   at least four; or
3. an eligible repetition-free arc failing only the root placement in (6),
   with opposite open sectors as in (8) when both sides are eligible.

Thus the brace problem separates into two thinner selection statements.

**Long-collision shortening.**  In a terminal-fixed complete target family
of a plane brace, a shortest eligible repetition can be shortened across
the family, or another target satisfies (TS).

**Eligibility/root escape.**  Such a complete family cannot consist only of
ineligible sides and repetition-free sides with the root failure in (6),
unless another target satisfies (TS).

If the first statement holds, a shortest unrepairable collision reaches
\(q=1\), contradicting (13); the second covers the collision-free residual
stratum.  Neither statement follows from local extension of the two holes,
as (19)--(21) demonstrate.

**Exact conclusion.**  Actual monochromaticity removes the mixed overlap
terms, and the three-sector theorem reduces exactly to (TS).  Every remaining
cycle defect is a long two-hole bond; only the length-one case is directly
excluded by the brace axiom.  Common incidence and local hole-pair extension
do not give target repair.

**Evidence level.**  Equations (5)--(13), two-sector dominance and the
two-hole-bond classification are arbitrary-order proofs.  The order-\(20\)
object is an exact finite common-incidence countermodel, not an abstract
system.

**Unresolved boundary.**  Note 076(14) remains open for plane braces.  Its
new thinnest form is the conjunction of long-collision shortening and
eligibility/root escape across the complete target family.
