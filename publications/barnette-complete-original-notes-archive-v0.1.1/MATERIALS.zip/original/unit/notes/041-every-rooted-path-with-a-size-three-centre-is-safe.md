> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every rooted path with a size-three centre is safe

[Note 040](040-every-rooted-path-with-a-size-two-centre-is-safe.md)
settles every rooted four-vertex path whose centre root class has size
two.  This note treats the unique size-three centre.  Its three root
incidences saturate the adjacent facial positions, leaving only one
nontrivial pair of endpoint classes.

Use the setting of Notes 035--040.  Thus \(F\) is a simple plane cubic
bipartite brace, \(p=uv\) and \(h=z\alpha\) are an ordered legal cofacial
site with \(u,z\) in the same bipartition class, and

\[
 K=F-\{u,\alpha\}.
\]

In the simple \(4\)-connected triangulation \(\Delta=F^*\), write

\[
 p^*=cc_p,\qquad h^*=cc_h,
\]

and let

\[
 W=\{r,s,t,q\},\qquad
 \Delta[\{s,t,q\}]=s-t-q.
\tag{1}
\]

Assume that the centre has the unique size-three root class

\[
 A(t)=T=\{c,c_p,c_h\}.
\tag{2}
\]

> **Size-three-centre path theorem.**  For every legal choice of endpoint
> root classes \(A(s),A(q)\), there is a perfect matching \(M\) of \(K\)
> such that
> \[
> |M\cap E_Q(W)|\le3.
> \tag{3}
> \]

## The two centre states

Let

\[
 w=(ct)^*,\qquad a_p=(c_pt)^*,\qquad a_h=(c_ht)^*
\]

be the three retained primal labels at the centre class.  As in Note 035,
these labels are

\[
 w=vz,\qquad a_p=vx,\qquad a_h=zy,
\tag{4}
\]

where \(v,z\) have degree two in \(K\).  Every perfect matching therefore
has one of the two local states

\[
 (w,a_p,a_h)=(1,0,0)\quad\hbox{or}\quad(0,1,1).
\tag{5}
\]

Put

\[
 \sigma=\mathbf 1_{a_p\in M}=\mathbf 1_{a_h\in M}.
\]

Then

\[
 w=1-\sigma,
 \qquad
 |M\cap\{w,a_p,a_h\}|=1+\sigma.
\tag{6}
\]

Both values of \(\sigma\) occur.  Indeed, \(K\) is \(1\)-extendable:
extending \(w\) gives \(\sigma=0\), while extending \(a_p\) gives
\(\sigma=1\).

## Facial saturation of the centre

The triangles

\[
 cc_pt,\qquad cc_ht
\tag{7}
\]

are facial.  They are the two faces incident with the edge \(ct\).
Consequently no endpoint \(x\in\{s,q\}\) can satisfy \(c\in A(x)\),
because the triangle \(cxt\) would be a third facial triangle incident
with \(ct\).

The face \(cc_pt\) occupies one side of \(c_pt\), so at most one endpoint
can contain \(c_p\) in its root class.  Similarly, at most one endpoint
can contain \(c_h\).  Hence every endpoint class is one of

\[
 \varnothing,\qquad
 S_p=\{c_p\},\qquad
 S_h=\{c_h\},\qquad
 R=\{c_p,c_h\}.
\tag{8}
\]

If one endpoint is of type \(R\), the two facial triangles through that
endpoint occupy the remaining sides of both \(c_pt\) and \(c_ht\), so the
other endpoint has empty root class.  If both endpoints are nonempty,
neither can be \(R\), repetitions of \(S_p\) and \(S_h\) are impossible,
and therefore

\[
 \boxed{\{A(s),A(q)\}=\{S_p,S_h\}.}
\tag{9}
\]

## Facial matching equations

Let \(g_x=(tx)^*\) be the rung label at an endpoint \(x\).
If \(A(x)=S_p\), write \(f_x=(c_px)^*\).  The facial triangle \(c_pxt\)
gives

\[
 a_p+f_x+g_x=1,
\]

and hence

\[
 f_x+g_x=1-\sigma.
\tag{10}
\]

The same equation holds for \(S_h\), with \(a_h\) in place of \(a_p\).

If \(A(x)=R\), write \(f_p,f_h\) for its two root labels.  The two facial
triangles give

\[
 \sigma+f_p+g_x=1,
 \qquad
 \sigma+f_h+g_x=1.
\tag{11}
\]

Thus \(f_p=f_h\), and every \(\sigma=1\) matching avoids both endpoint
labels and the rung.  Conversely, extending \(f_p\) gives a matching with
\(f_p=f_h=1\).  Thus both the zero and two states occur: a remote endpoint
adjacent to a size-three centre is balanced rather than exact-one.

## Completion of the bound

Suppose first that both endpoint classes are nonempty.  By (9), they are
\(S_p,S_h\) in some order.  Extend \(a_p\) to a perfect matching.  Then
\(\sigma=1\), the centre contributes two, and (10) makes both endpoint
labels and both rungs absent.  Thus the total cost is two.

Suppose next that exactly one endpoint class is empty.  If the other is
\(S_p,S_h\), or \(R\), take again a \(\sigma=1\) matching.  Equations
(10)--(11) make the nonempty endpoint and its rung contribute zero.  The
empty endpoint contributes only its rung, so the total cost is at most

\[
 2+0+1=3.
\]

Finally, if both endpoint classes are empty, take a \(\sigma=0\) matching.
The centre contributes one, and the two rungs contribute at most one each.
The total is again at most three.  These cases exhaust (8) and prove (3).

## Consequence and scope

Together with Note 040, the theorem settles every rooted path whose
centre has at least two root incidences.  The argument for the
size-three centre is entirely local: the residual-three-cut zero lemma of
Note 039 is not needed.

The theorem does not treat the case in which the three nonroot vertices
form a triangle, and it does not by itself certify that the no-edge,
one-edge, and path analyses exhaust the complete rooted four-vertex
theorem.
