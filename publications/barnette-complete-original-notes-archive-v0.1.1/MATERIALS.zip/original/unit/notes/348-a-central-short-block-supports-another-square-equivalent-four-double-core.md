> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A central short block supports another square-equivalent four-double core

[Note 347](347-a-nested-four-double-swap-has-the-square-hamilton-signature.md)
classifies a consecutive alternating four-double group with no
short block. A single short block between its middle two double
blocks allows a different nonlocal core. Its complete four-terminal
Hamilton signature is still that of a square.

Work in the compressed, gapless, tight-target all-square opening of
[Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Write four double blocks and one central short block in old-cycle order as
\[
D_t=(a_t,o_t,h_t,i_t,k_t,j_t,e_t,b_t)\quad(1\le t\le4),
\qquad S=(c,r,s,d),                                       \tag{1}
\]
with the order \(D_1,D_2,S,D_3,D_4\). The double-block internal
matching chords have types \(J_3,J_1,J_3,J_1\), namely
\[
                  i_1e_1,\quad o_2k_2,\quad
                  i_3e_3,\quad o_4k_4.                    \tag{2}
\]
Let \(T\) contain the full old-cycle path through these five
blocks, their five common-face closing chords
\(a_tb_t\ (1\le t\le4),cd\), (2), and the opposite-face chords
\[
 o_1h_3,\quad h_1o_3,\quad k_1i_2,\quad j_1h_2,\quad
 j_2s,\quad e_2r,\quad k_3i_4,\quad j_3h_4.                \tag{3}
\]
Its four degree-two terminals, in disk-boundary order, are
\((a_1,j_4,e_4,b_4)\). All other vertices have degree three.

**Central-short-core theorem.** The 36-vertex patch \(T\) has
exactly the square's spanning one-path and two-path signature
at these four terminals. Substitution between \(T\) and the
labeled square preserves three-connected cubic bipartite
planarity and every Hamilton-cycle decision on exterior and
attachment edges. A vertex-minimal non-Hamiltonian Barnette
graph contains no induced disk copy of \(T\).
The patch has a 48-vertex Barnette realization with a
Hamilton cycle through two legal common-face site edges;
its site-expanded child is Hamiltonian.

There is also a conditional classification. If an ordinary
target-free free group consists of precisely the five blocks
(1), with no outer short flank, and its opposite-side matching
contains \(h_1o_3\), then either it contains Note 335's local
square patch on \(D_3,D_4\), or its entire matching is (3)
together with \(Lj_4,e_4R\), where \(L,R\) are the ordinary
endports. In both cases the free group has a spanning
\(L\)--\(R\) path. Consequently, if all vacancies outside this
group lie in distinct internal blocks, the parent has a
Hamilton cycle through both site edges and its legal
site-expanded child is Hamiltonian.

**Complete Hamilton signature.** Put
\[
\begin{split}
P={}&(a_1,b_1,a_2,b_2,e_2,r,c,d,s,j_2,k_2,o_2,h_2,i_2,
 k_1,j_1,e_1,i_1,h_1,o_1,h_3,o_3,a_3,b_3),\\
W={}&(j_4,k_4,i_4,k_3,i_3,h_3,o_1,a_1,b_1,a_2,b_2,
 e_2,r,c,d,s,j_2,k_2,o_2,h_2,i_2,k_1,j_1,e_1,i_1,h_1,\\
 &o_3,a_3,b_3,e_3,j_3,h_4,o_4,a_4,b_4,e_4).
\end{split}                                                \tag{4}
\]
Every successive pair in these sequences is an old edge, a
face chord in (2) or a block-closing chord, or an opposite
chord in (3). In particular, \(e_2r,cd,sj_2\) traverse the
short block. The 24 vertices of \(P\) are exactly all of
\(D_1,D_2,S\) and \(a_3,o_3,h_3,b_3\);
\(W\) visits all 36 patch vertices once and runs from
\(j_4\) to \(e_4\).

Four vertex-spanning one-path states are:
\[
\begin{array}{c|l}
a_1b_4 & \text{the full old-cycle path through }T\\
j_4e_4 & W\\
e_4b_4 & (e_4,\ W\text{ with its final }e_4\text{ deleted})\\
a_1j_4 & (P,e_3,i_3,k_3,j_3,h_4,i_4,k_4,o_4,
             a_4,b_4,e_4,j_4).
\end{array}                                                 \tag{5}
\]
The third row begins with the old edge \(e_4j_4\).
For two disjoint spanning paths with pairing
\(\{a_1b_4,j_4e_4\}\), take
\[
(P,e_3,i_3,k_3,j_3,h_4,i_4,k_4,o_4,a_4,b_4),
\qquad (j_4,e_4).                                         \tag{6}
\]
For pairing \(\{a_1j_4,e_4b_4\}\), take
\[
(P,a_4,o_4,h_4,j_3,e_3,i_3,k_3,i_4,k_4,j_4),
\qquad (e_4,b_4).                                         \tag{7}
\]
The first paths of (6) and (7) each visit all vertices except
the two on their companion edge. The joins after \(P\) in
(7) are \(b_3a_4\) along the old cycle, \(h_4j_3\) and
\(k_3i_4\) from (3), \(e_3i_3\) from (2), and old edges.
The third terminal pairing \(\{a_1e_4,j_4b_4\}\)
joins equal-colour terminals and is impossible. These are
exactly the square's four one-path and two two-path states.
A Hamilton cycle crosses the four-attachment cut in two
or four edges; replacing its spanning path or path pair
therefore preserves the exterior and attachment decisions.

**Planar three-connected realization.** Use the old
Hamilton cycle
\[
x,R_1,w,y,D_1,D_2,S,D_3,D_4,u,z,L_1,v,
\alpha,\gamma,\delta,\beta,x.                             \tag{8}
\]
Place \(xy,uv,\alpha\beta\), all block-closing chords
and (2) on the common-face side. On the opposite side put
\(\delta R_1,wj_4,e_4z,\gamma L_1\) and (3).
Every vertex receives exactly one matching chord, joining
opposite old-cycle colours and distinct from an old edge.
The chords on each side are noncrossing. On the opposite
side, \(wj_4\) surrounds the core chords,
\(o_1h_3\) surrounds \(h_1o_3\), while \(j_2s\)
surrounds \(e_2r\); the disjoint side intervals contain
\(k_1i_2,j_1h_2\) and \(k_3i_4,j_3h_4\).
Thus (8) with these chords is a simple cubic bipartite
plane graph.

The chord-interlacement graph has the following connected
spanning system; a dash means alternating endpoints on (8):
\[
\begin{gathered}
xy-wj_4-a_4b_4-e_4z-uv-\gamma L_1-\alpha\beta-\delta R_1,\\
a_4b_4-j_3h_4-a_3b_3-o_1h_3-a_1b_1-k_1i_2-a_2b_2-j_2s-cd,\\
a_1b_1-h_1o_3-a_3b_3,\qquad
a_1b_1-j_1h_2-o_2k_2,\\
a_2b_2-e_2r-cd,\qquad
a_3b_3-k_3i_4-i_3e_3,\qquad
k_1i_2-i_1e_1,\qquad k_3i_4-o_4k_4.
\end{gathered}                                             \tag{9}
\]
Every matching chord appears. A two-edge cut in a cubic
Hamiltonian graph would enclose an old-cycle interval
closed under the matching and disconnect this interlacement
graph. The old cycle excludes bridges. Hence the graph
is three-edge-connected and therefore three-vertex-connected.

The two site chords \(xy,uv\) bound one face. The
\(y\)--\(u\) arc uses the five block-closing chords and has
length eleven; the \(v\)--\(x\) arc uses
\(\alpha\beta\) and has length three. The vertices
\(x,u\) have the same bipartition colour. Thus this is a
legal facial bipartite \(C_4\)-expansion site. The residual
cycle \(\alpha\gamma\delta\beta\alpha\) is a square
with tight escape targets \(R_1,L_1\), and no interblock
gap occurs. The two \(x\)--\(v\) paths
\[
x,R_1,\delta,\beta,\alpha,\gamma,L_1,v
\quad\text{and}\quad
x,y,w,\ W,\ z,u,v                                          \tag{10}
\]
are internally disjoint and cover all 48 vertices. Their
union is a Hamilton cycle containing both site edges;
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives a Hamilton cycle in the legal 52-vertex child.

For the two-way Barnette reduction, deleting any one
vertex leaves \(T\) connected. Each face-closed block
cycle stays connected, and the links \(b_1a_2,j_1h_2\);
\(b_2c,e_2r,j_2s\); \(o_1h_3,h_1o_3\); and
\(b_3a_4,k_3i_4,j_3h_4\) keep the five blocks
connected after one deletion. After two patch vertices
are deleted, every remaining component has a surviving
terminal; otherwise the explicit three-connected
realization would have the same disconnected component.
In any three-connected cubic host, the exterior of a
four-attachment patch is connected, since each exterior
component would otherwise require at least three of the
four attachments. The same four-attachment deletion
comparison as [Note 330](330-staggered-vacancy-chains-have-the-square-hamilton-signature.md)
now proves three-connectivity in both replacement
directions. Terminal colours and disk order preserve
cubicity, bipartiteness, simplicity and planarity.
Compressing \(T\) replaces \(D_1,D_2,S,D_3,D_4\)
by one short target-free square while preserving the
old-cycle path, face arc, targets, gaps and site edges.
Under the theorem's outside-vacancy hypothesis, Note 324
supplies the marked Hamilton cycle after compression;
(5)--(7) lift it, and Note 001 lifts the legal child.
\(\square\)

**Classification when \(h_1o_3\) occurs.** With ordinary
endports \(L,R\) and no outer short flank, the residual
opposite-side slots are
\[
L,o_1,h_1,k_1,j_1,h_2,i_2,j_2,e_2,r,s,
o_3,h_3,k_3,j_3,h_4,i_4,j_4,e_4,R.                  \tag{11}
\]
Chord isolation from
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
excludes other same-block free chords; [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md)
puts every cross-block chord on the opposite page.
Inside \(h_1o_3\), the slot \(k_1\) can only meet
\(i_2\): \(k_1j_1\) is an old edge and candidates
\(j_2,r\) enclose odd numbers of free slots.
Then \(j_1h_2\) is forced. The four remaining inner
slots \(j_2,e_2,r,s\) must pair as \(j_2s,e_2r\);
the other pairings use \(j_2e_2\) or \(rs\), both old
edges. Thus \(k_1i_2,j_1h_2,j_2s,e_2r\) are
forced in addition to \(h_1o_3\).

Outside \(h_1o_3\), the even slot \(h_3\) can meet
only \(o_1,j_4,R\). Its same-block options are an
old edge or forbidden internal chord, and \(h_3i_4\)
encloses three free slots. If \(h_3R\), the right
tail forces \(k_3i_4,j_3h_4\) and leaves the
forbidden old pair \(j_4e_4\). If \(h_3j_4\),
its four inner slots force \(k_3i_4,j_3h_4\),
giving the local Note 335 patch on \(D_3,D_4\).
The outer slots then pair as \(Lo_1,e_4R\):
the alternative \(LR,o_1e_4\) would close the
whole five-block interval and make a two-edge cut.
Compressing the local patch leaves exactly two
oppositely oriented double blocks and short blocks;
[Note 336](336-every-two-double-mixed-j1-j3-free-group-has-a-spanning-route.md)
gives the spanning group route.

Otherwise \(o_1h_3\). The remaining left endport
\(L\) can meet only \(j_4\) or \(R\) by parity.
The choice \(LR\) leaves \(k_3,j_3,h_4,i_4,j_4,e_4\),
which force \(k_3i_4,j_3h_4\) and the forbidden
old pair \(j_4e_4\). Therefore \(Lj_4,e_4R\);
the remaining four slots force \(k_3i_4,j_3h_4\).
This is exactly (3), and \(L,W,R\) is a spanning
group route. \(\square\)

**First-slot reduction.** In the no-flank group of (11),
the even slot \(h_1\) can meet only
\(j_2,r,o_3,j_4,R\): every other opposite-colour
candidate is a forbidden same-block or old edge, or
encloses an odd number of residual slots. The chord
\(h_1r\) encloses \(k_1,j_1,h_2,i_2,j_2,e_2\).
These six slots force \(k_1i_2,j_1h_2\) and
then the forbidden old pair \(j_2e_2\), so \(h_1r\)
is impossible. If \(h_1j_2\), its four enclosed
slots force \(k_1i_2,j_1h_2\), making \(D_1,D_2\)
the local Note 335 square. Compressing it leaves
two adjacent oppositely oriented double blocks with
short blocks on their left. Note 336 supplies a
spanning group route. Together with the preceding
classification, the only no-flank central-one-short
branches not decided here are \(h_1j_4\) and
\(h_1R\). \(\square\)

This theorem settles the \(h_1j_2\) and \(h_1o_3\)
branches and excludes \(h_1r\) for a central-one-short,
no-flank alternating four-double group, together with
the induced four-pole reduction wherever it occurs.
The \(h_1j_4,h_1R\) branches, outer short flanks, other
internal chord words, target defects, positive
gaps, nonsquare residual cycles and the general
Barnette conjecture remain outside its scope.
The proof is project-internal and analytic;
no independent review or external priority is claimed.
