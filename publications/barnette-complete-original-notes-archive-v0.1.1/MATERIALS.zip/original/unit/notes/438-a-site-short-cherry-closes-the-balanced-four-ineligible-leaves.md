> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A site-short cherry closes the balanced four-ineligible-leaf word

[Note 437](437-the-fourth-matching-short-leaf-has-thirteen-necessary-depth-words.md) lists thirteen necessary short-leaf row-IV words. The word with sites \((1,7)\), short leaf \(2\), and depths \((3,3,4,4,4,4,1)\) has an explicit marked Hamilton path. This eliminates that row for every legal completion.

Write
\[
\begin{aligned}
S_2&=(x_2y_2),& C&=F(U_1,S_2),\\
A&=F(U_3,U_4),& B&=F(U_5,U_6),& R&=F(A,B),\\
L&=F(C,R),& W&=F(L,U_7),
\end{aligned}                                                     \tag{1}
\]
where \(F(P,Q)=(((P Q)))\) and \(U_i=((x_i y_i))\) are full leaves. The available row-IV face chords include \(y_2x_3,x_4y_5,y_4x_5\).

Use the spanning \(x_3\)--\(A_\ell\) path \(T_{AB}\) of [Note 436](436-the-fourth-matching-three-odd-leaf-short-branch-has-a-marked-cycle.md), equation (4). Its only face chords are \(x_4y_5,y_4x_5\), and its construction is internal to \(A\cup B\), so their different ancestors in (1) do not change it. Use \(Y_1,X_7\) and bracket-only paths \(P_T,Q_T,R_T\) from [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md).

**Marked-path theorem.** A spanning \(y_1\)--\(x_7\) path of \(W\) is
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,\quad
\lambda_2^C\xrightarrow{P_C}\rho_2^C,\quad
R_2,L_2,x_2,y_2,\quad
x_3\xrightarrow{T_{AB}}A_\ell,\\
&\lambda_2^R\xrightarrow{Q_R^{-1}}R_r=\rho_0^R,\quad
\rho_2^L\xrightarrow{R_L}L_\ell=\lambda_0^L,\quad
\lambda_2^W\xrightarrow{P_W}\rho_2^W,\quad
R_7\xrightarrow{X_7}x_7.
\end{aligned}                                                     \tag{2}
\]
The transition \(y_2x_3\) is the third used face chord. The pairs \(L_1\lambda_2^C\), \(\rho_2^CR_2\), \(A_\ell\lambda_2^R\), \(R_r\rho_2^L\), \(L_\ell\lambda_2^W\), and \(\rho_2^WR_7\) are consecutive old-cycle vertices. Within \(S_2\), \(R_2L_2\) is its ordinary chord and \(L_2x_2,x_2y_2\) are old-cycle edges. Thus every transition in (2) is an actual edge.

The path \(T_{AB}\) covers \(A,B,U_3,U_4,U_5,U_6\). The other pieces cover \(U_1,S_2,U_7\) and the four remaining branch wrappers \(C,R,L,W\), all without overlap. Their vertex counts are \(36+(6+4+6)+4\cdot6=76\). The fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), closes (2) with both site edges in the parent; [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md), clause 1, gives a Hamilton cycle in every legal expanded child. \(\square\)

Together with Note 437's shared-chord corollary, this leaves eleven structurally necessary row-IV short-leaf words. Row VI, other kernel branches, and Barnette's conjecture remain open.
