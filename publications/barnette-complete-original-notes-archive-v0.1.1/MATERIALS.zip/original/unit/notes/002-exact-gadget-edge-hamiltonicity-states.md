> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact state criterion for gadget-edge Hamiltonicity

For one \(C_4\)-expansion, let \(D_{11},D_{10},D_{01},X_{vx},X_{uy},L\)
denote the six realizable traversal types in Note 001.  A type is available
when its corresponding parent witness exists.

Every Hamilton cycle of the child meets the eight gadget edges in exactly one
of these six traversal patterns.  Direct finite set cover therefore gives an
exact criterion: every new gadget edge lies on some Hamilton cycle if and
only if the available types contain one of

\[
\begin{gathered}
\{D_{11},D_{10}\},\quad \{D_{11},D_{01}\},\quad
\{D_{10},D_{01}\},\quad \{D_{11},L\},\\
\{X_{vx},X_{uy}\},\quad \{X_{vx},L\},\quad
\{X_{uy},L\}.
\end{gathered}
\]

These seven pairs are precisely the inclusion-minimal covers of the gadget.
In particular, the two cross Hamilton paths alone suffice: closing them in
the child gives two Hamilton cycles whose gadget intersections cover all
eight new edges.

The central-transfer package of Note 001 contains both cross paths.  Hence,
after every step of the recursively selected central expansion chain, every
edge of the newly installed gadget lies on a Hamilton cycle of that new
graph.  This does not imply that retained edges from earlier layers remain
Hamiltonian at every later step, or that the whole graph is edge-Hamiltonian;
those require separate old-edge support.

The five-witness package is sufficient but not necessary for this local
edge-Hamiltonicity.  In the general, non-Barnette setup, \(K_4\) with the two
selected edges opposite has neither \(D_{10}\) nor \(D_{01}\), but has both
cross Hamilton paths, so its expanded gadget is fully edge-Hamiltonian.

The exact six-set calculation is independently checked by
`scratch/worker-barnette/gadget_edge_cover_states.py`.

