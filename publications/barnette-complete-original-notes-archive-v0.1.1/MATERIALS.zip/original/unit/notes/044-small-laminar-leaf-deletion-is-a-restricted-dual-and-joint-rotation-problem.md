> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Small laminar-leaf deletion is a restricted-dual and joint-rotation problem

[Note 043](043-four-vertex-safety-does-not-eliminate-small-laminar-dual-leaves.md)
shows that separate low-intersection witnesses do not delete a small leaf
from an optimal laminar dual.  This note gives the exact finite-deletion
criterion, separates three inequivalent deletion quantifiers, and locates
the remaining brace-level information.  Two countermodels show that neither
literal row--column matching incidence nor the separate planar primal and
dual marginals suffice.  An actual plane-cubic two-cut example further shows
that unrestricted deletion and laminar deletion are genuinely different.

## Exact loss along one leaf coordinate

Use the single-layer dual objective of Note 033,

\[
 \Phi(z)=
 \sum_x\min_{e\in D_x}
 \left(c_e+\sum_{U:e\in E_Q(U)}z_U\right)
 -\sum_Uz_U(|U|-1),
 \qquad
 c_e=\mathbf1_{\{y(e)\in A\}}.
\tag{1}
\]

Let \(W\) be a positive inclusion-minimal member of a laminar support,
put \(t=z_W\), and hold all other coordinates fixed.  Write

\[
\begin{aligned}
 i_x&=\min_{e\in D_x\cap E_Q(W)}
 \left(c_e+\sum_{U\ne W:e\in E_Q(U)}z_U\right),\\
 o_x&=\min_{e\in D_x\setminus E_Q(W)}
 \left(c_e+\sum_{U\ne W:e\in E_Q(U)}z_U\right),
\end{aligned}
\tag{2}
\]

where the minimum of an empty set is \(+\infty\).  If \(z^{-W}\) is
obtained by replacing \(z_W\) by zero, then

\[
\boxed{
 \Delta_W(z):=\Phi(z)-\Phi(z^{-W})
 =\sum_x\left[\min(i_x+t,o_x)-\min(i_x,o_x)\right]
 -t(|W|-1).}
\tag{3}
\]

For

\[
 P_{<}(s)=\{x:i_x+s<o_x\},
\]

the same quantity has the integral form

\[
\boxed{
 \Delta_W(z)=
 \int_0^t\bigl(|P_{<}(s)|-(|W|-1)\bigr)\,ds.}
\tag{4}
\]

Indeed, the contribution of one block is zero if \(i_x\ge o_x\), is
\(\min\{t,o_x-i_x\}\) if \(i_x<o_x<+\infty\), and is \(t\) if
\(o_x=+\infty\).  Equation (4) is the finite version of the one-sided
derivative in Note 043.

Let

\[
 \sigma(z)=\Phi(z)-|A|
\]

be the strict slack.  Deleting \(W\) without changing any other coordinate
preserves strictness if and only if

\[
\boxed{\Delta_W(z)<\sigma(z).}
\tag{5}
\]

The pointwise condition

\[
 |P_{\le}(0)|\le |W|-1
\tag{6}
\]

is a slack-free sufficient condition, since
\(P_{<}(s)\subseteq P_{\le}(0)\) for all \(s\ge0\).  In contrast, the
endpoint condition at \(s=t\) controls only an infinitesimal left move.
It does not bound the full integral (4).  The perfect matching supplied by
Note 042 need not choose a baseline-minimizing edge in each block and hence
does not bound (4).

## Three deletion quantifiers

Let \(\mathcal R\) be the nonempty proper vertex sets of \(Q\).  For a
forbidden family \(\mathcal F\subseteq\mathcal R\), define

\[
 \beta_{\neg\mathcal F}(A)=
 \max\{\Phi(\widehat z):
 \widehat z\ge0,\ 
 \widehat z_U=0\text{ for }U\in\mathcal F\}.
\tag{7}
\]

Linear-programming duality gives the exact restricted primal

\[
\boxed{
 \beta_{\neg\mathcal F}(A)=
 \min\left\{
 \sum_ec_ex_e:
 \begin{array}{l}
 x(D_x)=1\quad\text{for every }x,\\
 x(E_Q(U))\le |U|-1
 \quad(U\in\mathcal R\setminus\mathcal F),\\
 x_e\ge0
 \end{array}
 \right\}.}
\tag{8}
\]

Thus the following statements are distinct.

1. **Fixed-coordinate deletion:** equation (5) holds.
2. **Support-monotone deletion:** there is a strict \(\widehat z\) with
   \(\operatorname{supp}(\widehat z)\subseteq\operatorname{supp}(z)\setminus\{W\}\).
3. **Unrestricted deletion:** \(\beta_{\neg\{W\}}(A)>|A|\).

The third statement can introduce crossing regions or restore regions
discarded earlier.  It therefore does not by itself support a leaf-pruning
induction.  An iterative reoptimization must retain a cumulative forbidden
family and prove

\[
 \beta_{\neg\mathcal F}(A)>|A|
 \Longrightarrow
 \beta_{\neg(\mathcal F\cup\{W\})}(A)>|A|.
\tag{9}
\]

## A row--column matching countermodel

Even a \(W\)-safe row--column perfect matching does not force unrestricted
deletion.  Let \(Q_0\) have vertices \(a,b,c,d\) and labelled edges

\[
 e_0,e_1,e_2:ab,qquad e_3:ac,qquad e_4:cd,qquad e_5:bc.
\tag{10}
\]

Take the two partitions

\[
\begin{aligned}
 D_0&=\{e_0,e_1\},&D_1&=\{e_2,e_3\},&D_2&=\{e_4,e_5\},\\
 C_0&=\{e_0,e_2\},&C_1&=\{e_3,e_4\},&C_2&=\{e_1,e_5\}.
\end{aligned}
\tag{11}
\]

Let \(A=\{C_1\}\), so \(e_3,e_4\) have cost one and the other labels
have cost zero.  Put

\[
 W=\{a,b\},\qquad U=\{a,b,c\},\qquad z_W=z_U=1.
\tag{12}
\]

The block minima are \(2,2,1\), and the two rank penalties are \(1,2\).
Hence

\[
 \Phi(z)=2>|A|=1.
\tag{13}
\]

The row--column base

\[
 M_{\mathrm{safe}}=\{e_0,e_3,e_5\}
\]

has cost one and satisfies

\[
 |M_{\mathrm{safe}}\cap E_{Q_0}(W)|=1=|W|-1.
\]

It fails instead on the ancestor \(U\), where its three labels form a
triangle.  Conversely,

\[
 M_{\mathrm{rel}}=\{e_1,e_2,e_4\}
\]

has cost one and satisfies every proper graphic-rank inequality except
that of \(W\).  Equation (8) therefore gives

\[
 \boxed{\beta_{\neg\{W\}}(A)=1.}
\tag{14}
\]

The reverse inequality is witnessed by the \(W\)-free assignment
\(z_U=1\), whose three block minima are \(1,1,1\) and whose rank penalty
is two.

Thus no strict \(W\)-free certificate exists.  This model preserves the
binary row--column cost identity and a literal \(W\)-safe matching, but it
is not the contracted dual incidence of a simple plane brace.

## Actual cubic incidence separates crossing and laminar deletion

Consider the fixed simple plane cubic bipartite graph \(F_2\) on
\(0,\ldots,15\) consisting of the Hamilton cycle in that order and the
chords

\[
 03,16,25,47,8\,11,9\,14,10\,13,12\,15.
\tag{15}
\]

At the ordered cofacial site

\[
 (u,v,z,a)=(14,15,8,9),
\]

the graph has the proper two-edge cut \(\{0\,15,7\,8\}\) and is not a
brace.  In its actual contracted dual, put

\[
 A=\{1,3,5,7,11,13\},qquad W=\{1,5\}.
\]

The certificate

\[
 z_W=1,qquad \alpha_8=2,qquad \alpha_x=1\quad(x\ne8)
\tag{16}
\]

has value \(7>|A|=6\), and all \(112\) partition--graphic bases have
cost seven.

Unrestricted deletion nevertheless succeeds.  The crossing assignment

\[
 z_{\{0,1,5\}}=z_{\{1,5,7\}}=1
\tag{17}
\]

with block potentials

\[
 (\alpha_0,\alpha_2,\alpha_4,\alpha_6,
   \alpha_8,\alpha_{10},\alpha_{12})
 =(2,1,1,1,3,1,2)
\]

is a second value-seven certificate and avoids \(W\).

No strict **laminar** \(W\)-free certificate exists.  Two cost-six block
transversals have respective violation families

\[
 \mathcal V_-=
 \{157,1567\}
\tag{18}
\]

and

\[
 \mathcal V_+=
 \{015,0125,01245,012345\}.
\tag{19}
\]

Every member of \(\mathcal V_-\) crosses every member of
\(\mathcal V_+\).  Summing the dual edge inequalities over either
transversal shows that a certificate of value greater than six must contain
a positive violated region from its corresponding family.  A laminar
support cannot meet both families.  Hence every uncrossing of a strict
\(W\)-free certificate must reintroduce \(W\).

This literal plane-cubic example proves

\[
 \boxed{
 \text{unrestricted leaf deletion can require leaving the laminar class}.}
\tag{20}
\]

## Separate cubic and planar marginals still do not suffice

There is also a stricter countermodel to unrestricted deletion.  Let the
rank graph have vertices \(0,\ldots,6\), with

\[
 L=\{0,1,2\},qquad R=\{3,4,5\}.
\]

Its six partition blocks are

\[
\begin{array}{c|c|c}
\text{block}&\text{zero-cost labels}&\text{unit-cost label}\\ \hline
D_0&01,01&06\\
D_1&12,12&24\\
D_2&02,02&-\\
D_3&34,34&36\\
D_4&45,45&-\\
D_5&35,35&-
\end{array}
\tag{21}
\]

The three unit-cost labels form one literal opposite-colour block, so
\(|A|=1\).  The two partition degree sequences are

\[
 (3,3,2,3,2,2),qquad(3,3,3,2,2,2),
\]

exactly the pattern obtained by deleting two nonadjacent opposite-colour
vertices from a cubic bipartite graph.  There are \(32\)
partition--graphic bases and all have cost two.  Moreover,

\[
 z_L=z_R=1,qquad \alpha_i=1\quad(0\le i<6)
\tag{22}
\]

has value

\[
 6-(|L|-1)-(|R|-1)=2>|A|.
\]

The cost-one block transversal with endpoint multiset

\[
 01,12,02,36,45,35
\tag{23}
\]

violates exactly one proper rank inequality, namely that of \(L\).
Consequently equation (8) gives

\[
 \boxed{\beta_{\neg\{L\}}(A)=1,}
\tag{24}
\]

so \(L\) is indispensable even among arbitrary crossing replacements.
The lower bound is attained by \(z_R=1\): the last three block minima are
one, the first three are zero, and the rank penalty is two.

Both partitions in (21) are realized by deleting the ordered cofacial site
\((6,11,4,13)\) from the simple plane cubic bipartite graph with opposite
colour neighbourhoods

\[
\begin{array}{c|c}
7&0,1,3\\
8&0,2,4\\
9&0,2,5\\
10&1,3,6\\
11&1,4,6\\
12&3,5,6\\
13&2,4,5.
\end{array}
\tag{25}
\]

This graph is \(3\)-connected, but it is not a brace: the independent
edges \(07\) and \(4\,11\) do not extend to a perfect matching.  More
importantly, the labelled rank graph in (21) is not the contracted plane
dual of the displayed embedding, even after relabelling its seven vertices.
The model therefore preserves the literal binary cost, the two cubic
deletion partitions, and a planar rank graph, but not their joint rotation
in one brace.

## Remaining brace-level statement

The following conditional statement remains open.  Suppose an actual legal
site in a simple plane cubic bipartite brace has

\[
 \mu(A)>|A|
\]

and a strict laminar certificate with a positive leaf \(W\),
\(|W|\le4\).  Must

\[
 \beta_{\neg\{W\}}(A)>|A|?
\tag{26}
\]

By (8), a negative answer is exactly a low-cost relaxed point satisfying
every proper graphic-rank inequality except possibly that of \(W\), while
the full common-base optimum is strict.  The countermodels above show that
separate low-intersection matchings, row--column incidence, block degrees,
and planarity of the two marginal graphs do not exclude such a point.  A
positive proof must use the joint primal--dual rotation compatibility and
brace \(2\)-extendability, or must verify the global-slack criterion (5).

Even a positive answer to (26) would settle only unrestricted deletion.
The actual two-cut example shows that a support-monotone or laminar pruning
theorem is strictly stronger.

The fixed finite claims are checked by

```bash
uv run --python 3.12 --with networkx \
  units/barnette/computations/verify_small_laminar_leaf_boundaries.py
```

with terminal marker `SMALL_LAMINAR_LEAF_BOUNDARIES_VERIFIED`.
