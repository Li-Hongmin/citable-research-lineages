> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All double transition defects at second surplus are Hamiltonian

[Note 241](241-two-cross-block-transition-defects-compose-at-second-surplus.md)
settles the two-cross-block case at the second gapless surplus.
When one defective transition stays within a block, the other
cannot cross a block boundary in a three-connected parent. If both
stay in one block, their four intervening free slots have a unique
matching, and two old-cycle detours repair the target path.

Use a compressed all-square Barnette opening with empty interblock
gaps, \(\ell,r\ge1\), and \(s=2\), hence \(f=4r+6\). Assume
\[
d_L=d_R=0,\qquad b=2.                         \tag{1}
\]
Number the defective transitions \(L_j,R_{j-1}\) and
\(L_k,R_{k-1}\), where \(j>k\). Each uses exactly one of the two
vacant eligible positions by [Note 197](197-gapless-square-trap-defect-budget.md).

**Double-transition theorem.** Every parent satisfying (1) has a
Hamilton cycle containing both site edges \(xy,uv\). Hence its legal
site-expanded child is Hamiltonian, for arbitrary positive original
lobe lengths. More precisely, a mixed same-block/cross-block pair of
defects is impossible, and if both transitions stay in single blocks,
those blocks must coincide.

**Proof.** If the closed block intervals of the two defects are
disjoint, Note 237's one-vacancy-per-defect argument excludes a
same-block transition. Explicitly, its two intervening free slots
\(c,d\) are consecutive on the old cycle. At the target before
them, an even free-slot prefix and at most one same-block crossing
chord forbid a crossing. The same holds at the target after them;
cross-block chords cannot straddle either target by
[Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md).
The pair \(c,d\) then has no matching mate, since \(cd\in E(C)\).
Thus the intervals must share a block.

Suppose first that the earlier transition crosses from \(B_i\) to
\(B_h\), while the later transition lies entirely in \(B_h\).
Note 212's first-slot cut and the two-vacancy budget give the
following order of free slots and targets in the shared block:
\[
o_h,w,\quad R_{j-1},\ldots,L_k,\quad c,d,
R_{k-1},\ldots,e_h.                              \tag{2}
\]
Here \(c,d\) are consecutive and belong to the same-block defect;
\(e_h\) is absent if the last target \(L_1\) occupies the final
slot of the right site block. All free slots before
\(R_{j-1}\) number \(2h+2\). At this target, a cross-block
matching chord is forbidden by Note 203. Any same-block chord
crossing it must use \(o_h\) or \(w\), so matching parity allows
zero or two such chords. If there are two, both \(o_h,w\) are used.
The main prefix through the right endpoint of \(B_{h-1}\), together
with the residual-square suffix \(S_j,\ldots,S_\ell\), is then
matching-closed. Its escape targets and fixed chords are internal;
its free slots cannot reach beyond \(R_{j-1}\) by Note 203 and
cannot reach \(o_h,w\), now used. This proper consecutive
\(C\)-interval has exactly two departing cycle edges, contrary
to three-connectivity. Hence no chord crosses \(R_{j-1}\).

The free prefix before \(R_{k-1}\) is also even: the pair \(c,d\)
has added two slots, and no other free slot lies between the two
target runs. With the earlier crossing excluded, the only possible
same-block chord across \(R_{k-1}\) is \(ce_h\), if \(e_h\)
exists. Parity excludes that single chord; Note 203 excludes
cross-block chords. The adjacent pair \(c,d\) cannot be matched.
This rules out the first order.

Suppose instead that the earlier transition is same-block in
\(B_h\), while the later one crosses from \(B_h\) to \(B_q\),
\(q>h\). The shared block has the free-slot order
\[
o_h,\quad L_j,c,d,R_{j-1},\ldots,L_k,c',e_h,
\tag{3}
\]
where \(o_h\) is absent in the left site block. At \(L_j\),
the free prefix is even and at most the one slot \(o_h\) could
start a same-block crossing chord. Hence no free chord crosses
\(L_j\). At \(R_{j-1}\), the only opposite-colour same-block
chords available across its target run are
\[
ce_h,\qquad dc'.                                   \tag{4}
\]
Parity permits zero or both. Zero strands the adjacent pair
\(c,d\), so both edges in (4) must be in the matching. In
particular the two free slots after \(L_k\) in \(B_h\) are used.

Now take the main suffix strictly after \(B_h\), followed by the
residual-square prefix \(S_1,\ldots,S_{k-1}\). This is a proper
consecutive \(C\)-interval. Every escape target in it is matched
to an included square; all site and face chords there are internal.
Its free slots cannot be matched to \(B_h\): \(c',e_h\) are used
by (4), while a chord to any earlier slot of \(B_h\) would straddle
\(L_k\). A chord to an even earlier block also straddles \(L_k\).
Note 203 forbids both. The interval is matching-closed and has only
two departing \(C\)-edges, again contradicting three-connectivity.
This rules out the second order.

If both transitions are same-block but in distinct blocks, their
singleton block intervals are disjoint and the first paragraph
rules them out. Thus every case outside Note 241 has both defective
transitions in the same block \(B_h\). Its local slot order is
\[
\cdots L_j,c,d,R_{j-1},\ldots,L_k,c',d',R_{k-1}\cdots,
\tag{5}
\]
with no free slot in either intervening target run. At \(L_j\),
the free prefix is even and the only possible earlier free slot of
\(B_h\) is its first interior slot \(o_h\), absent when \(h=0\).
Thus parity and Note 203 exclude every free chord across \(L_j\).
At \(R_{k-1}\), the free prefix is also even; the only possible
later free slot in \(B_h\) is its final interior slot \(e_h\),
absent when \(h=r+1\). Again no free chord crosses. Consequently
\(c,d,c',d'\) form a closed matching group. Bipartiteness leaves
only two possible pairings of its odd slots \(c,c'\) with its even
slots \(d,d'\). The pairs \(cd,c'd'\) are old-cycle edges, so the
complementary matching is forced to contain
\[
cd',\qquad dc'.                                  \tag{6}
\]
Every other free group has the standard slots and even-prefix
barriers. Note 196's noncrossing and two-edge-cut skipping argument
therefore forces its ordinary links \(e_t o_{t+1}\),
\(0\le t\le r\). In particular the ordinary free \(x\)-to-\(v\)
path of Note 196 is unchanged.

Take Note 196's target-and-square \(x\)-to-\(v\) path. Replace its
two missing transition edges by the old-cycle subpaths
\[
L_jR_{j-1}\longmapsto L_j,c,d,R_{j-1},\qquad
L_kR_{k-1}\longmapsto L_k,c',d',R_{k-1}.     \tag{7}
\]
The inserted vertices are distinct and occur on neither ordinary
free path nor any residual square. Both substitutions use three
actual consecutive edges of \(C\). The two paths share only \(x,v\),
cover every vertex, and form a Hamilton cycle through \(xy,uv\).
Note 241 handles the two-cross-block case; the mixed case was
excluded above. Notes 001 and 178 lift the marked cycle through the
legal site expansion and restore arbitrary positive lobe lengths.
\(\square\)

**A realized double same-block profile.** Set \(\ell=3,r=1\), with
both defective transitions in \(B_1\). The old 32-cycle consists of
\[
\begin{array}{ll}
B_0:&x,R_3,e_0,y,\\
B_1:&a_1,o_1,L_3,c,d,R_2,L_2,c',d',R_1,e_1,b_1,\\
B_2:&u,o_2,L_1,v,\\
S_t:&\alpha_t,\gamma_t,\delta_t,\beta_t
\quad(t=1,2,3),\text{ returning to }x.
\end{array}                                                \tag{8}
\]
Its complementary matching is
\[
\begin{split}
M={}&\{xy,a_1b_1,uv\}
\cup\{\alpha_t\beta_t,R_t\delta_t,L_t\gamma_t:t=1,2,3\}\\
&\cup\{e_0o_1,cd',dc',e_1o_2\}.
\end{split}                                                \tag{9}
\]
Every pair has opposite old-cycle parity. Draw the site, face, and
\(\alpha_t\beta_t\) chords on one side of \(C\), with the nested
\(cd',dc'\) chords inside \(a_1b_1\). On the other side, the escape
chords nest in target order; \(e_0o_1\) and \(e_1o_2\) lie in
separate gaps. This is a simple cubic bipartite plane graph with
cofacial sites. Its matching-chord interlacement graph is connected:
\[
\begin{split}
xy-e_0o_1-a_1b_1-e_1o_2-uv-L_1\gamma_1-
\alpha_1\beta_1-R_1\delta_1-a_1b_1-
R_2\delta_2-\alpha_2\beta_2-L_2\gamma_2-\\
a_1b_1-L_3\gamma_3-\alpha_3\beta_3-R_3\delta_3-xy,
\end{split}                                                \tag{10}
\]
while both \(cd'\) and \(dc'\) interlace \(R_2\delta_2\).
Note 217's interval criterion proves three-connectivity and its
cut projection makes the 36-vertex site expansion Barnette.

The marked parent Hamilton cycle is the union of the paths
\[
\begin{split}
&x,y,e_0,o_1,a_1,b_1,e_1,o_2,u,v,\\
&x,R_3,\delta_3,\beta_3,\alpha_3,\gamma_3,L_3,c,d,
R_2,\delta_2,\beta_2,\alpha_2,\gamma_2,L_2,c',d',
R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v.
\end{split}                                                \tag{11}
\]
They share only \(x,v\), and their \(10+24-2\) distinct vertices
are exactly the 32 vertices of the parent.

The theorem covers precisely (1). It does not cover fewer than two
target defects with spare vacancies, interblock gaps, nonsquare
residual cycles, or arbitrary Barnette graphs.
