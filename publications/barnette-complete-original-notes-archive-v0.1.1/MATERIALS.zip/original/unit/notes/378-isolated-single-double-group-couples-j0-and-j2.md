> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An isolated single-double group couples J0 and J2

[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
classifies \(J_1\) in the smallest free group with one singly
vacant and one doubly vacant target-free block. Here we
determine when \(J_0\) and \(J_2\) occur in that double
block. [Note 227](227-all-target-free-same-block-double-vacancies-are-hamiltonian.md)
forces \(J_2\) when the double block is the group's only
vacancy, but its missing-link count does not apply with
the additional single vacancy.

Work in a compressed, gapless, tight-target all-square
selected opening of a Barnette graph. Let an ordinary
target-free free group contain exactly two complete blocks:
a singly vacant block \(V=(a,o,h,i,e,b)\) and a doubly
vacant block \(D=(A,O,H,I,K,J,E,B)\), in either order.
There are no short blocks in this group. Let \(t\) and \(z\)
be its even left and odd right free endports, respectively.
Other free groups are unrestricted. Write
\[
                         J_0=OE,\qquad J_2=HJ.
\]

**Isolated \(J_0/J_2\) theorem.** In this group,
\[
                         J_0\in M\quad\Longleftrightarrow\quad J_2\in M.
\]
If either chord occurs, \(D\) is the induced eight-vertex square pole
of [Note 325](325-even-rainbow-multivacancy-blocks-are-exact-square-reductions.md)
(equivalently, [Note 377](377-a-j0-j2-double-vacancy-block-is-an-exact-eight-vertex-square-pole.md)).
It can be replaced by a square in either direction while
preserving Barnette membership and every exterior-marked
Hamilton decision. Thus the induced eight-vertex
disk patch, wherever it occurs in a Barnette host,
is excluded from a vertex-minimal non-Hamiltonian
Barnette graph.

**Proof.** Suppose \(OE\in M\) but \(HJ\notin M\).
The other two possible internal free chords of \(D\)
share \(O\) or \(E\) with \(OE\), so \(OE\) is its only
internal free matching chord. It lies on the common-face
side. If it lay on the opposite side, its interior
\(H,I,K,J\) would have to match internally: every
cross-block matching chord lies on that opposite side
by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md)
and would cross \(OE\). The only possible non-cycle
opposite-colour internal edge is the excluded \(HJ\);
in particular \(HI,IK,KJ\) are old-cycle edges.

The only possible same-block free chord of \(V\) is \(oe\).
If present, it too lies on the common-face side: on the
opposite side it would trap \(h,i\), whose mutual edge
is on the old cycle. All remaining free matching
chords lie on the opposite side. For any such chord,
remove from its open interval the endpoints of
common-face chords whose mates lie outside that
interval. The number of remaining free slots must be
even. We use this interval parity rule below. A
matching-closed proper interval of complete blocks
has only its two boundary old-cycle edges leaving it,
contrary to three-connectivity.

First put \(V\) before \(D\). The free-slot order is
\[
                   t,o,h,i,e,O,H,I,K,J,E,z.       \tag{1}
\]
The even endport \(t\) can match only \(o,i,I,J,z\).
The edge \(ti\) traps \(o,h\); without \(oe\) they
cannot match because \(oh\) is an old-cycle edge,
and with \(oe\) only \(h\) remains inside. The chord
\(tI\) has six interior free slots and the single
common-face exit \(O\) through \(OE\); \(tJ\) has
eight interior free slots and the same single exit.
In both cases \(oe\), if present, lies wholly inside,
so parity excludes the chord. The edge \(tz\) would
enclose the complete blocks \(V,D\), making their
union matching-closed and giving a two-edge cut.
Therefore \(to\in M\), and \(oe\notin M\).

The even slot \(h\) can now match only \(I,J,z\):
\(hi\) is an old-cycle edge, \(o\) is used, and
\(H,K\) have its colour. The chord \(hI\) has
the four interior slots \(i,e,O,H\), of which
only \(O\) exits through \(OE\); \(hJ\) has
the six interior slots \(i,e,O,H,I,K\), again
with only \(O\) exiting. Both violate parity.
If \(hz\) occurs, \(OE\) lies wholly inside it.
The slot \(i\) must then match inside \(hz\)
to \(H\) or \(K\): its other candidates are
used or joined to it by an old-cycle edge.
But \(iH\) encloses \(e,O\), with the single
exit \(O\) through \(OE\), and \(iK\)
encloses \(e,O,H,I\), with the same single
exit. Both violate parity. Hence \(h\)
has no mate, a contradiction.

Now put \(D\) before \(V\). The order is
\[
                   t,O,H,I,K,J,E,o,h,i,e,z.       \tag{2}
\]
The even endport \(t\) can match only \(I,J,o,i,z\).
The chord \(tI\) has interior \(O,H\), with
only \(O\) exiting through \(OE\); \(tJ\)
has interior \(O,H,I,K\), again with only
\(O\) exiting. Parity excludes both.
If \(to\) occurs, all four extra slots
\(H,I,K,J\) of \(D\) must match internally,
since an opposite-side chord leaving \(to\)
would cross it. They have no legal perfect
matching when \(HJ\) is absent, so \(to\)
is impossible. If \(ti\) occurs and \(oe\)
also occurs, its eight interior free slots
have the one exit \(o\) through \(oe\), contrary
to parity. If \(ti\) occurs without \(oe\),
then \(OE\) lies wholly inside it and the
interior slot \(o\) must match \(H\) or \(K\).
The chord \(Ho\) encloses \(I,K,J,E\)
and has the single exit \(E\) through \(OE\);
\(Ko\) encloses \(J,E\) with the same exit.
Both violate parity. Finally \(tz\) would
make the complete two-block interval
matching-closed, again a two-edge cut.
Thus \(t\) has no mate, the last contradiction.

Both block orders exclude \(OE\in M,HJ\notin M\).
This proves \(J_0\Rightarrow J_2\).

For the converse suppose \(HJ\in M\) but \(OE\notin M\).
The chord-isolation lemma of Note 327 excludes
\(OK=J_1\) and \(IE=J_3\). The chord \(HJ\)
lies on the common-face side: otherwise its
interior \(I,K\) could not be matched, since
\(IK\) is an old-cycle edge and cross-block
chords lie opposite the common face. Again
\(oe\), if present in \(V\), lies on the
common-face side. Every other free chord
lies on the opposite side.

If \(V\) precedes \(D\), use order (1). The
possible mates of \(t\) are \(o,i,O,I,z\).
The chord \(ti\) traps \(o,h\), which cannot
match inside it, with or without \(oe\).
The chord \(tO\) traps all four free slots
of \(V\); even if \(oe\) occurs, \(h,i\)
are left joined only by an old-cycle edge.
The chord \(tI\) has six interior free slots
and exactly one common-face exit, \(H\)
through \(HJ\); \(oe\), if present, lies
wholly inside. Parity excludes \(tI\).
The edge \(tz\) closes the complete
two-block interval and is forbidden by
three-connectivity. Thus \(to\in M\)
and \(oe\notin M\).

Now \(h\) can match only \(O,I,z\).
The chord \(hO\) traps \(i,e\), whose
mutual edge is on the old cycle.
The chord \(hI\) has interior \(i,e,O,H\)
with just one face-side exit, \(H\)
through \(HJ\), so parity excludes it.
If \(hz\) occurs, the chord \(HJ\) lies
wholly inside \(hz\). Then \(i\) must
match \(O,K\), or \(E\) inside \(hz\).
The chord \(iO\) traps \(e\);
\(iK\) has interior \(e,O,H,I\)
with the single exit \(H\) through
\(HJ\). If \(iE\) occurs, its interior
has \(e,O,H,I,K,J\). The pair \(H,J\)
is already matched, leaving \(e,O,I,K\).
The slot \(e\) can meet only \(O\) or
\(I\) there. The first choice leaves
the old-cycle edge \(IK\), while
\(eI\) encloses \(O,H\) with the
single exit \(H\) through \(HJ\).
Thus \(hz\) is impossible, and \(h\)
has no mate.

If \(D\) precedes \(V\), use order (2).
The possible mates of \(t\) are
\(O,I,o,i,z\). The chord \(tI\)
has interior \(O,H\), with one exit
\(H\) through \(HJ\).
The chord \(to\) traps the whole
double block; after \(HJ\), the
remaining \(O,I,K,E\) cannot pair,
because \(OE\) and \(OK\) are absent
and \(OI,IK\) are respectively
same-colour and old-cycle pairs.
If \(ti\) occurs with \(oe\),
the chord \(oe\) gives its eight-slot
interior exactly one exit, \(o\).
If \(ti\) occurs without \(oe\), then
\(O\) must match \(h\) inside it:
\(OK\) and \(OE\) are absent.
But the chord \(Oh\) encloses
\(H,I,K,J,E,o\). After the face-side
pair \(H,J\), the slot \(I\) has no
legal mate inside: \(IK\) is on the
old cycle and \(IE\) is excluded by
chord isolation. The edge \(tz\)
again closes the two-block interval.
Thus \(tO\in M\).

The remaining even ordinary slot \(E\)
can match only \(o,i,z\): \(IE=J_3\)
is excluded. If \(Eo\) occurs,
the odd slot \(I\) must meet \(h\)
or \(e\); both chords have an even
number of interior slots with the
single common-face exit \(J\)
through \(HJ\), violating parity.
The chord \(Ei\) traps \(o,h\),
which cannot match inside, whether
or not \(oe\) occurs. Finally \(Ez\)
would close the complete block \(V\)
under the matching and give a
two-edge cut. Hence \(E\) has no
mate. This proves \(J_2\Rightarrow J_0\).

When both chords occur, \(D\) has
precisely the \(q=2\) rainbow matching
of Note 325. Its exact square
reduction and the minimal-counterexample
consequence follow. \(\square\)

If every other vacant position of the selected opening
lies in a distinct internal block, compressing \(D\)
leaves only distinct internal vacancies. [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md)
then supplies a parent Hamilton cycle containing both
site edges; the exact replacement lifts it, and
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives a Hamilton cycle in the legal site-expanded child.
The theorem does not cover a short block in this
free group, another vacancy-bearing block, or
other opening types. It does not resolve Barnette's
conjecture. The proof is project-internal and
has not had independent review.
