> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The planar boundary-chord lemma fails on a sixteen-vertex brace

[Note 061](061-the-actual-boundary-chord-lemma-fails-in-the-nonplanar-heawood-brace.md)
refutes the general actual-fibre boundary-chord lemma but leaves open
whether planarity forbids its fundamental-cut port barrier. It does not:
the same obstruction occurs in a simple plane cubic bipartite brace on
sixteen vertices.

## The plane brace and fixed fibre

Let \(F\) have graph6 string

    O????B_sDOI_I_DO@W?M?

and bipartition

\[
Y=\{0,1,2,3,4,5,6,7\},\qquad
X=\{8,9,10,11,12,13,14,15\}.
\]

A plane embedding is certified by the following eight quadrilateral and
two octagonal facial boundaries:

\[
\begin{gathered}
(0,8,2,10),(0,9,1,8),(1,9,3,11),(2,12,4,10),\\
(3,13,5,11),(4,12,6,14),(5,13,7,15),(6,15,7,14),\\
(0,10,4,14,7,13,3,9),
(1,11,5,15,6,12,2,8).
\end{gathered}
\tag{1}
\]

Every directed edge occurs exactly once in (1), the induced dart
successor at each vertex is one three-cycle, and
\(|V|-|E|+|F|=16-24+10=2\). Thus (1) is a spherical embedding.

The graph is simple, connected, cubic and bipartite. Direct strict-Hall
minimization on both colour sides gives

\[
\min_{\varnothing\ne U,\ |U|\le6}
\bigl(|N_F(U)|-|U|\bigr)=2.
\tag{2}
\]

The bipartite 2-extendability criterion therefore makes \(F\) a brace.

Take root \(r=0\), ports \(N_F(r)=\{8,9,10\}\), and fixed port split

\[
\{8\}\mid\{9,10\}.
\tag{3}
\]

In this fibre, consider the five spanning two-component forests

\[
\begin{aligned}
A=\{&(1,9),(1,11),(2,8),(3,11),(3,13),(4,10),(4,12),
      (4,14),(5,13),(5,15),(6,12),(6,15),(7,14)\},\\
B=\{&(1,8),(2,10),(2,12),(3,9),(3,11),(3,13),(4,14),
      (5,11),(5,15),(6,12),(6,15),(7,13),(7,14)\},\\
C=\{&(1,9),(1,11),(2,8),(3,13),(4,10),(4,12),(5,11),
      (5,13),(5,15),(6,12),(6,14),(7,14),(7,15)\},\\
D=\{&(1,9),(1,11),(2,8),(3,11),(3,13),(4,10),(4,12),
      (4,14),(5,15),(6,12),(7,13),(7,14),(7,15)\},\\
E=\{&(1,9),(1,11),(2,8),(3,11),(3,13),(4,10),(4,12),
      (5,15),(6,12),(6,14),(6,15),(7,13),(7,14)\}.
\end{aligned}
\tag{4}
\]

Each forest has the prescribed \(X\)-degrees, exactly two components, and
the port blocks (3).

## Inclusion-minimal box feasibility

In coordinate order

\[
Y\setminus\{r\}=(1,2,3,4,5,6,7),
\]

the degree and excess vectors are

\[
\begin{array}{c|c|c}
 &d&e=d-2\mathbf1\\ \hline
A&(2,1,2,3,2,2,1)&(0,-1,0,1,0,0,-1)\\
B&(1,2,3,1,2,2,2)&(-1,0,1,-1,0,0,0)\\
C&(2,1,1,2,3,2,2)&(0,-1,-1,0,1,0,0)\\
D&(2,1,2,3,1,1,3)&(0,-1,0,1,-1,-1,1)\\
E&(2,1,2,2,1,3,2)&(0,-1,0,0,-1,1,0).
\end{array}
\tag{5}
\]

The positive weights

\[
(w_A,w_B,w_C,w_D,w_E)=\frac17(1,2,2,1,1)
\tag{6}
\]

satisfy

\[
\sum_J w_J e(J)
=\frac17(-2,-5,0,0,0,0,0)\le0.
\tag{7}
\]

This support is inclusion-minimal. For omission of
\(A,B,C,D,E\), respectively, take the nonnegative separating vectors

\[
\begin{array}{c|c}
\text{omitted state}&\lambda\\ \hline
A&(0,0,1,0,2,3,6)\\
B&(0,0,0,4,1,2,0)\\
C&(0,0,5,3,0,2,1)\\
D&(0,0,2,1,3,4,0)\\
E&(0,0,5,4,6,0,3).
\end{array}
\tag{8}
\]

For each row, \(\lambda\cdot e(J)>0\) for every non-omitted state
\(J\). A convex combination of those states therefore has positive
\(\lambda\)-value, whereas every vector in the nonpositive box has
nonpositive \(\lambda\)-value. Every proper subfamily is contained in one
of these four-state families, proving inclusion-minimality.

The support contains no compatible pair, allowing repetition. The
following symmetric matrix records, for every pair, a coordinate at which
its excess sum is positive:

\[
\begin{array}{c|ccccc}
 &A&B&C&D&E\\ \hline
A&4&3&4&4&4\\
B&3&3&5&3&3\\
C&4&5&5&4&6\\
D&4&3&4&4&4\\
E&4&3&6&4&6.
\end{array}
\tag{9}
\]

## All algebraically possible repair pivots fail

For a same-\(X\) pivot \(J'=J-xz+xy\),

\[
e(J')=e(J)-\mathbf1_z+\mathbf1_y.
\tag{10}
\]

It can repair an ordered pair \((J,K)\) only if
\(e(J)+e(K)\) has exactly one positive coordinate, that value equals one,
and the receiving coordinate has negative slack. Applying these conditions
to all 25 ordered support pairs and then using the incidence of \(F\)
leaves exactly six edge transfers:

\[
\begin{array}{c|c|c}
\text{source, partner}&\text{only possible transfer}&\text{failure}\\ \hline
A,B&A-(3,13)+(7,13)&\text{not a two-component forest}\\
B,A&B-(3,9)+(1,9)&\{10\}\mid\{8,9\}\\
B,A&B-(3,11)+(1,11)&\{9\}\mid\{8,10\}\\
B,C&B-(5,11)+(1,11)&\{10\}\mid\{8,9\}\\
C,E&C-(6,12)+(2,12)&\{9\}\mid\{8,10\}\\
E,C&E-(6,12)+(2,12)&\{9\}\mid\{8,10\}.
\end{array}
\tag{11}
\]

The first candidate leaves the class of two-component forests. The other
five remain two-component forests but cross the fixed port partition (3).
Hence none belongs to the fixed fibre. Equation (10) and the positive
coordinate test prove that (11) exhausts every pivot capable of becoming
compatible with a support state.

This is a genuine plane-brace counterexample to the planar boundary-chord
lemma. The complete fibre contains 86 forests; an independent enumeration
checks all 26 legal pivots incident with the support and finds no compatible
boundary hit. Exact reproduction is provided by
[the permanent verifier](../computations/verify_planar_boundary_chord_counterexample.py),
which ends with
**PLANAR_BOUNDARY_CHORD_COUNTEREXAMPLE_VERIFIED**.

## Boundary

This example does not refute support two. The same fibre contains, for
example, the forest

\[
\begin{split}
\{&(1,8),(1,11),(2,10),(2,12),(3,9),(3,13),(4,12),\\
  &(4,14),(5,11),(5,15),(6,15),(7,13),(7,14)\},
\end{split}
\tag{12}
\]

with degree vector

\[
(2,2,2,2,2,1,2).
\]

Therefore arbitrary support minimality plus a single compatibility chord
is closed even under planarity. Surviving exchange proofs must select a
distribution by a stronger global extremality rule, allow a multistep path
through states not immediately compatible with the original support, or
use a partner outside that support. General planar support one/two and the
fractional degree-box statement remain open.
