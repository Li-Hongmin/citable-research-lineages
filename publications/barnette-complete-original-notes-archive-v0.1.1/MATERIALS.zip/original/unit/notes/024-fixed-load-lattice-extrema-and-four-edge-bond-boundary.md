> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fixed-load lattice extrema and the four-edge-bond boundary

Retain the capped-brace setting of
[Notes 022--023](023-parity-and-alternating-cycle-boundaries-at-a-capped-brace.md).
This note determines what two natural connectivity arguments can extract
from the brace hypothesis. A fixed-load perfect-matching lattice does not
place a connected complement at either extreme, and a residual alternating
region yields only a bond of size at least four. Neither conclusion proves
or refutes the capped-brace cardinality criterion.

## The \(P\)-load family is a matching lattice

Let \(F\) be a plane cubic bipartite brace, let \(p=uv\) and \(h=za\) be
disjoint cofacial edges, and assume that \(u,z\) have the same bipartite
colour. Put

\[
\gamma=\mathbf 1+e_v+e_z.
\tag{1}
\]

Every edge set \(B\subseteq E(F)\) with

\[
p,h\in B,\qquad \lambda_B=\gamma
\tag{2}
\]

has the unique form

\[
B=M\cup\{p,h\},
\tag{3}
\]

where \(M\) is a perfect matching of the plane bipartite graph

\[
K=F-\{u,a\}.
\tag{4}
\]

The complementary support \(F-B\) has degree one at \(v,z\) and degree two
at every other vertex. Consequently

\[
\boxed{
B^*\text{ is a spanning tree}
\iff F-B\text{ is a Hamilton }v\text{-}z\text{ path}.}
\tag{5}
\]

When \(K\) is elementary, its perfect matchings carry the usual
face-flip distributive lattice after an outer face is fixed. This is the
degree-constrained-factor specialization of the planar orientation
lattices of Felsner and Propp. Thus the most direct height-function
strategy for facial edge-source completion is to seek (5) at one of the
two lattice extremes.

That strategy is false in an actual admissible brace.

## Both lattice extremes can have residual cycles

Use the order-\(16\) global-\(H^{+-}\) brace

    OlCGHD@?g?_@@@A?_?k?P

and orient the two cofacial edges by

\[
(u,v,z,a)=(15,0,13,4),
\qquad p=0\,15,\quad h=4\,13.
\tag{6}
\]

The graph \(K=F-\{15,4\}\) is elementary and has eleven perfect matchings.
Take as outer face the natural face created by deleting the two vertices,
with boundary

\[
(0,1,8,9,10,11,12,5,6,7,2,3).
\tag{7}
\]

Orient every alternating finite-face flip by the plane orientation and a
fixed bipartite colouring. The resulting flip digraph is connected and
acyclic and has the unique two extremes

\[
\begin{aligned}
M_-={}&\{03,18,27,56,9\,10,11\,12,13\,14\},\\
M_+={}&\{01,23,5\,12,67,89,10\,11,13\,14\}.
\end{aligned}
\tag{8}
\]

Changing the plane orientation or swapping the two colours interchanges
\(M_-\) and \(M_+\), so their unordered pair is the relevant statement.
Neither is a facial edge-source completion target. More precisely,

\[
\begin{aligned}
F-(M_-\cup\{p,h\})&
  \text{ has component orders }8,4,4,\\
F-(M_+\cup\{p,h\})&
  \text{ has component orders }12,4.
\end{aligned}
\tag{9}
\]

Nevertheless four of the eleven perfect matchings satisfy (5). Hence all
four Hamilton \(0\)-\(13\) path targets are strict interior elements of
the fixed-load distributive lattice:

\[
\boxed{
\text{connected complement is neither forced nor detected by the two
height extrema}.}
\tag{10}
\]

The stronger possibility of a nontrivial lattice functional whose optimum
always satisfies (5) is not addressed by (10).

Even descent by an arbitrarily chosen single alternating cycle is too
weak. Keep \(u=15,z=13,a=4,h=4\,13\), but take

\[
v=14,\qquad p=14\,15.
\tag{10a}
\]

The same graph \(K=F-\{15,4\}\) still has eleven perfect matchings, but now
exactly one of them has connected complement. Two non-target matchings have
two complementary components and are strict local minima for the component
count under **every** single alternating-cycle flip. Each differs from the
unique target on precisely two disjoint alternating cycles, of orders four
and six. Flipping either cycle alone does not decrease the component count;
they must be flipped simultaneously. Hence

\[
\boxed{
\text{one-cycle coalescence fails even when the FEC target is unique;
a synchronized cycle family is genuinely necessary}.}
\tag{10b}
\]

## Full source families need not start a Kuo switch

The preceding synchronous flip cannot in general be generated from a pair
of Hamilton source witnesses.  This is a terminal-pairing obstruction, not
another failure of a particular descent rule.

Put \(J=F-\{p,h\}\), and write

\[
\begin{aligned}
\mathcal X={}&\{M\in\operatorname{PM}(F-\{z,a\}):
J-M\text{ is a Hamilton }u\text{-}v\text{ path}\},\\
\mathcal Y={}&\{N\in\operatorname{PM}(F-\{u,v\}):
J-N\text{ is a Hamilton }z\text{-}a\text{ path}\}.
\end{aligned}
\tag{10c}
\]

For \(M\in\mathcal X\) and \(N\in\mathcal Y\), the terminal components of
\(M\mathbin\triangle N\) have one of the two noncrossing pairings

\[
A=(uv\mid za),\qquad C=(uz\mid va).
\tag{10d}
\]

The third pairing \(B=(vz\mid ua)\) crosses in the facial order
\(u,v,a,z\) and is excluded by planarity.  Crucially, planarity does not
exclude \(A\).  Only a pair in sector \(C\) has an alternating \(u\)-\(z\)
path whose switch produces a perfect matching \(T\) of \(F-\{u,a\}\).

For such a \(C\)-pair the usual quotient statement is exact.  If \(X=J-M\),
delete from \(X\) the edges on the switched path which belong to \(N\),
contract the resulting path pieces, and add the alternate \(M\)-edges.
For the resulting quotient multigraph \(\Theta(M,N)\),

\[
\boxed{
\#\{\text{residual cycles of }J-T\}
=\mu(\Theta(M,N)).}
\tag{10e}
\]

Thus a tree quotient is a sufficient FEC certificate, but it is conditional
on the \(C\)-sector being nonempty.

Orientation \((6)\) shows that the conditional mechanism can be exact.  Its
two source families have sizes four and two.  Of the eight pairs, five lie
in sector \(C\); their distinct Kuo images have quotient cyclomatic-number
distribution

\[
0:4,\qquad 1:1.
\tag{10e1}
\]

The four tree images are precisely all four Hamilton targets.  Moreover,
componentwise alternating closure of the five images gives all eleven
perfect matchings of \(F-\{u,a\}\), and each of the seven positive-residual
states has a strict synchronous descent.  Thus the quotient and synchronous
identities lose no information once the correct sector is populated.

The condition is not forced by complete source-family nonemptiness.  In the
fixed brace with orientation \((10a)\), both source families have size three,
yet all nine pairs lie in sector \(A\).  The corrected \(C\)-sector seed is
empty, while the FEC target is unique and exists.  Switching any collection
of alternating cycles and either or both terminal paths of an \(A\)-pair
can only return deletion sets

\[
\{z,a\},\quad\varnothing,\quad\{u,v,z,a\},\quad\{u,v\};
\tag{10f}
\]

it never produces either target deletion set.  Consequently

\[
\boxed{
\mathcal X,\mathcal Y\ne\varnothing
\not\Longrightarrow
\text{a nonempty source-generated Kuo or synchronous-descent seed}.}
\tag{10g}
\]

The general component-count identity for synchronously flipping an
arbitrary vertex-disjoint alternating-cycle family remains valid, but this
example proves that it cannot be initiated from the two source families
alone.  Any successful use of the simultaneous \(C_4+C_6\) move in \((10b)\)
must first obtain the target-load sector from additional global structure.

Even a Hamiltonian third witness does not by itself supply that structure.
In orientation \((10a)\) there are exactly four two-step bridges

\[
M_{01}\;--\;W_{00}\;--\;N_{10}
\tag{10h}
\]

in which all three matching complements are Hamilton cycles and both steps
are single alternating-cycle flips.  Three bridges have cycle orders
\((6,6)\), and one has orders \((10,10)\).  For every bridge, however, the
union \(M_{01}\cup W_{00}\cup N_{10}\) supports exactly one target-load
near matching, whose complementary component orders are \((12,4)\).  The
unique Hamilton target uses three or four edges outside that union.
Consequently even adjoining one arbitrary distinguished nonmatching edge
cannot make any bridge support the target.

The full common complement does expose a sharp positive mechanism in the
same instance.  For one short bridge, put

\[
I=M_{01}\cap W_{00}\cap N_{10},\qquad
K=E(F)\setminus(M_{01}\cup W_{00}\cup N_{10}).
\tag{10i}
\]

The consensus graph \(I\cup K\) has a unique relevant internal alternating
path \(5-6-9-10\).  With the two transition-selected terminal edges this
becomes the \(a\)-\(u\) path \(4-5-6-9-10-15\).  Toggling it alone still
leaves two components; toggling simultaneously the consensus square
\(0-1-2-3-0\) makes the cut-and-add quotient a tree and gives the unique
Hamilton target.  Hence the actual three-witness sufficient condition is

\[
\boxed{
\text{ordered bridge}+
\text{consensus defect connector}+
\text{tree quotient}
\Longrightarrow \mathrm{FEC}.}
\tag{10j}
\]

The existence of a \(00\) Hamilton matching itself is automatic.  More
generally, in any cubic graph with global \(H^{+-}\), every two distinct
edges \(p,h\) lie on a common Hamilton cycle.  If they are disjoint, choose
at one endpoint of \(p\) an edge \(f\ne p\), which is automatically not
\(h\).  If they meet, choose their common endpoint and let \(f\) be its
third incident edge.  In either case a Hamilton cycle containing \(h\) and
avoiding \(f\) is forced at that cubic vertex to use \(p\).  What is not forced
by the current argument is a **compatible** \(00\) witness adjacent by one
alternating cycle to suitable members of both source families, nor the
restricted consensus connector or final tree quotient.  Thus \((10j)\) is an
exact fixed-instance mechanism, not yet a general consequence of global
\(H^{+-}\).

The first missing selection can be stated without geometry.  Let
\(\mathfrak T(F)\) be the graph whose vertices are Hamilton-complement
perfect matchings, two vertices being adjacent when their symmetric
difference is one alternating cycle.  Partition its vertices into
\(V_{st}\) by membership \(s=1_{p\in M}\), \(t=1_{h\in M}\).  Cubic
forcing and global \(H^{+-}\) give

\[
V_{01},V_{10},V_{00}\ne\varnothing,
\tag{10k}
\]

but the compatible bridge prerequisite is the strictly joint condition

\[
\boxed{
V_{00}\cap N_{\mathfrak T}(V_{01})
       \cap N_{\mathfrak T}(V_{10})\ne\varnothing.}
\tag{10l}
\]

None of Notes 022--024 supplies exchange connectivity, convexity, or a
Helly property implying \((10l)\).  Thus nonemptiness of the three state
classes must not be substituted for a common-neighbour theorem.  Even
\((10l)\), when it holds, is only the first prerequisite for \((10j)\); the fixed
bridge obstruction above shows that the consensus connector and tree
quotient remain independently load-bearing.

## A residual region need only have four attachments

Let \(J=F-\{p,h\}\), and let \(X,Y\) be the two Hamilton source paths with
endpoint pairs \(uv\) and \(za\). Degree parity in the subcubic graph \(J\)
gives

\[
X\mathbin\triangle Y
=\text{two vertex-disjoint terminal paths and a family of cycles}.
\tag{11}
\]

Toggling a terminal-path component can change the endpoints to \(v,z\),
but it proves facial edge-source completion only if no residual cycle is
created. If \(S\) is a nontrivial shore bounded by such a residual region,
then

\[
\boxed{|\delta_F(S)|\ge4.}
\tag{12}
\]

Indeed, a 2-edge cut contradicts 3-connectivity. In a cubic bipartite
graph every 3-edge cut is tight: cubic degree counting forces all three
cut edges to have the same bipartite orientation, and every perfect
matching uses exactly one of them. A brace has no nontrivial tight cut.

Bound (12) is sharp for the overlay argument. In the same fixed brace,
with

\[
(u,v,z,a)=(15,14,13,4),
\qquad p=14\,15,\quad h=4\,13,
\tag{13}
\]

one source pair opens the two alternating squares

\[
4-5-12-13-4,
\qquad
10-11-14-15-10.
\tag{14}
\]

Each square has exactly four external attachments. The graph remains a
brace and has the desired target path. Thus a single source overlay is
compatible with the smallest residual boundary allowed by (12); it cannot
force a 2-cut, a tight 3-cut, or a dual separating triangle.

The first square also shows that the smallest bond cannot simply be
replaced by a gadget to manufacture an FEC counterexample. Remove the shore

\[
S=\{1,2,7,8\},
\qquad
\delta_F(S)=\{01,23,67,89\},
\tag{14a}
\]

and retain the labelled outside ports \(0,3,6,9\). For an arbitrary
replacement four-pole, a spanning path meets it in one of six one-path
states \(P_{ij}\) or one of three two-path pairing states
\(L_{ij|k\ell}\). Exact completion in the fixed outside satisfies, for
every one of the nine states \(\sigma\),

\[
E_{uv}(\sigma)=E_{vz}(\sigma),
\qquad
E_{za}(\sigma)=E_{ua}(\sigma).
\tag{14b}
\]

If \(g_W(\sigma)\) counts local witnesses of state \(\sigma\) in any
replacement \(W\), gluing gives

\[
H_{st}(W)=\sum_\sigma E_{st}(\sigma)g_W(\sigma),
\]

and therefore

\[
\boxed{
H_{uv}(W)=H_{vz}(W),
\qquad
H_{za}(W)=H_{ua}(W).}
\tag{14c}
\]

No planarity or brace hypothesis on \(W\) is needed for these identities.
Thus a brace-preserving replacement through this single square bond cannot
retain the \(uv\) source while killing the \(vz\) target. A genuine
counterexample must alter the outside interface, use another bond, or
couple several replacements.

## A \(K\)-quotient cycle yields a bond, not a tight cut

Use the alternating-family notation of Note 023. Delete the old half
\(R^*\) from the dual two-forest and contract the resulting tree
components. If the new-edge quotient \(Q_N\) contains a cycle, lifting a
first quotient cycle through the unique paths in those tree components
produces a dual simple cycle \(D\). Therefore

\[
\boxed{
Q_N\text{ cyclic}
\Longrightarrow
E(D)^*=\delta_F(S_D)\text{ is a primal bond}.}
\tag{15}
\]

No stronger cut conclusion follows from the quotient data. The length of
\(D\) includes the internal tree paths and need not be three. Tightness
would require every perfect matching of \(F\) to meet the bond once, while
\(Q_N\) records only one near-perfect matching.

The fixed brace realizes this distinction. An unsuccessful alternating
square flip gives the dual four-cycle

\[
D=(0,4,7,2)
\tag{16}
\]

and the primal bond

\[
\delta_F(S_D)=\{01,23,67,89\}.
\tag{17}
\]

Across the 41 perfect matchings of \(F\), the numbers meeting (17) in
\(0,2,4\) edges are respectively

\[
18,18,5.
\tag{18}
\]

Thus the bond is nontrivial and emphatically non-tight. A four-component
quotient model also realizes a cap-changing, inclusion-minimal failure
with a single quotient cycle, so cap placement and alternating-family
minimality do not repair the implication.

## Consequence for the preservation problem

The capped-brace criterion remains the active interface, but three broad
connectivity mechanisms are now separated from it:

\[
\boxed{
\begin{array}{c}
\text{fixed-load face-flip lattice extrema},\\
\text{one alternating-cycle descent},\\
\text{full two-source Kuo/SSC descent},\\
\text{one source-overlay Jordan region},\\
\text{one failed quotient cycle plus brace minimality},\\
\text{one square-bond replacement}
\end{array}
\quad\not\Longrightarrow\quad
\text{connected complement}.}
\tag{19}
\]

Any proof must couple several members of the positive-even source family,
or impose a genuinely new global condition that selects an interior
matching and makes its complement connected. More low-order state
nonemptiness, ordinary height extremization, and a small-cut contradiction
do not supply that condition.

There is no hidden general dual-tree theorem at this point. Since \(F\) is
a plane cubic bipartite brace, \(F^*\) is a simple 4-connected Eulerian
triangulation. The classical dual formulation says that Barnette's
conjecture is equivalent to the existence of an A-trail in every such
triangulation. Bagheri Gh., Feder, Fleischner and Subi prove spanning- and
quasi-spanning-tree-of-faces theorems only under additional facial
2-factor hypotheses, and explicitly distinguish the always-available
quasi-spanning tree in their restricted setting from the still open
A-trail problem. Their results contain no prescribed two-defect or
prescribed-transition theorem implying (5). Thus the capped-brace
condition is a genuine refinement of the known open dual interface, not
an instance of an existing prescribed-tree theorem.

The lattice assertion is reproduced by

    uv run --python 3.12 --with networkx \
      units/barnette/scratch/worker-c4-hpm/verify_fec_fixed_load_lattice_extremes.py

with terminal marker

    FEC_FIXED_LOAD_LATTICE_EXTREMES_VERIFIED

The fixed quotient-bond calculation is reproduced by

    uv run --python 3.12 --with networkx \
      units/barnette/scratch/worker-c4-hpm/verify_k_common_deletion_exchange_boundary.py

with terminal marker

    K_COMMON_DELETION_EXCHANGE_BOUNDARY_VERIFIED

The exact square-replacement interface is reproduced by

    uv run --python 3.12 --with networkx \
      units/barnette/scratch/worker-c4-hpm/verify_fec_square_bond_interface.py

with terminal marker

    FEC_SQUARE_BOND_INTERFACE_VERIFIED

The empty cross-sector assertion for the full source families is reproduced
by the same fixed-instance certificate which also verifies (10e1):

    uv run --python 3.12 --with networkx \
      units/barnette/scratch/worker-c4-hpm/verify_fec_source_image_fixed_instance.py

with terminal marker

    FEC_SOURCE_IMAGE_FIXED_INSTANCE_VERIFIED

The underlying full-family separation of the two special alternating
components is independently reproduced by

    uv run --python 3.12 --with networkx \
      units/barnette/scratch/worker-c4-hpm/verify_capped_brace_full_family_mconvex_boundary.py

with terminal marker

    FEC_PAIRWISE_SOURCE_REROUTING_BOUNDARY_VERIFIED

The two-step Hamilton-bridge obstruction and the successful full
common-complement mechanism are reproduced respectively by

    uv run --python 3.12 --with networkx \
      units/barnette/scratch/worker-c4-hpm/verify_fec_hamilton_bridge_transition_boundary.py

and

    uv run --python 3.12 --with networkx \
      units/barnette/scratch/worker-c4-hpm/verify_fec_decorated_common_complement.py

with terminal markers

    FEC_HAMILTON_BRIDGE_TRANSITION_BOUNDARY_VERIFIED
    FEC_DECORATED_COMMON_COMPLEMENT_VERIFIED

The lattice references used to identify the available general framework
are Stefan Felsner, *Lattice Structures from Planar Graphs*, Electron. J.
Combin. 11 (2004), DOI `10.37236/1768`, and Jim Propp, *Lattice Structure
for Orientations of Graphs*, Electron. J. Combin. 32 (2025), DOI
`10.37236/9474`. The closest dual-tree comparison is Behrooz Bagheri Gh.,
Tomás Feder, Herbert Fleischner and Carlos Subi, *Hamiltonian cycles in
planar cubic graphs with facial 2-factors, and a new partial solution of
Barnette's Conjecture*, J. Graph Theory 96 (2021), DOI
10.1002/jgt.22612.
