> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All same-block sharp positive gaps are Hamiltonian

[Note 264](264-same-block-third-surplus-gaps-are-hamiltonian-unless-the-block-separates-them.md)
settles a two-vacancy block on either side of both gap slots.
[Note 265](265-separating-sharp-vacancy-blocks-have-six-or-seven-free-slots.md)
reduces a block between singleton gaps to six or seven free
interior slots, and [Note 266](266-six-free-separating-gaps-compress-to-first-surplus.md)
settles six. The seven-free case has the same four-column ladder
and therefore the same marked compression.

Let \(G\) be a Barnette parent with a Hamilton cycle \(C\) avoiding
vertex-disjoint cofacial matching site edges \(q=xy,p=uv\).
Select a legal all-square facial opening, compress its residual
lobes as in [Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md),
and assume
\[
 \ell,r\ge1,\qquad f=4r+8,\qquad \sigma=T=2.
 \tag{1}
\]
Suppose the two vacant eligible positions lie in one block.

**Same-block sharp-gap Hamilton theorem.** The parent \(G\) has a
Hamilton cycle containing both \(p,q\). Consequently its legal
site-expanded child is Hamiltonian. This holds for every placement
of the two gap slots and for arbitrary positive original lobe lengths.

**Seven-free normal form.** In the only case not covered by
Notes 264 and 266, the block \(B=[a,b]_C\) lies between singleton
gaps \(g<h\) and has seven free interior slots. Write its reversed
interior as \(z_1,\ldots,z_{2K+2}\), with colours
\(E,O,E,O,\ldots,E,O\). Then \(K\ge3\), the targets occupy
exactly \(z_5,\ldots,z_{2K-1}\), and the two vacancies are
\(z_3,z_{2K+1}\). The matching incidences at the gaps and on
the designated-face side are forced:
\[
 gz_2,\quad z_{2K+1}h;\qquad
 z_1z_{2K+2},\quad z_3z_{2K}.
 \tag{2}
\]
The seventh free block slot \(z_4\) is matched to a slot
outside \(B\), strictly before \(g\). Both gaps immediately
adjoin \(B\).

**Proof.** Note 264 handles a block before or after both gap
slots. If it lies strictly between them, Note 265 gives six or
seven free slots; Note 266 handles six. Assume seven.
Note 265 says that \(L_1\notin B\) and the target subsequence
starts and ends with an \(L\)-target. It contains \(K-2\)
\(L\)-targets and \(K-3\) \(R\)-targets. Write \(s,t\in B\)
for the mates of \(g,h\). By Note 264, \(s\) precedes every
target of \(B\) and \(t\) follows every such target. Since
\(g=E,h=O\), we have \(s=O,t=E\).

The first target is an \(L\)-target in an eligible odd-numbered
slot. It cannot be \(z_1\) by Note 195. The right mate \(t\)
is an eligible \(E\)-slot after the last target, hence a
vacancy. Only two eligible positions are vacant, so the first
target can be only \(z_3\) or \(z_5\). If it were \(z_3\),
colour would force \(s=z_2\). The gap-edge localization lemma
of Note 258 requires a face-side free chord straddling \(z_2\).
Its earlier endpoint must be \(z_1\), and its later endpoint
is beyond the first target \(z_3\). Thus it also straddles
\(z_3\). The even free-prefix parity of Note 255 requires a
second free chord straddling that target: cross-block chords
cannot do so by Note 203. But before \(z_3\) the only free
slot other than the already matched \(z_2\) is \(z_1\).
This is impossible.

Hence the first target is \(z_5\), making \(z_3\) the first
vacancy. The right mate \(t\) requires a vacant eligible
position after the last target. It must be the sole remaining
vacancy \(z_{2K+1}\): ending before \(z_{2K-1}\) would leave
two eligible vacancies on the right, and ending at
\(z_{2K+1}\) would leave no \(E\)-slot for \(t\).
Therefore the last target is \(z_{2K-1}\) and
\(t=z_{2K+1}\). The interval \(z_5,\ldots,z_{2K-1}\)
has \(2K-5\) vertices, exactly the number of targets in
\(B\), so every one is a target. The free slots are
\[
 z_1,z_2,z_3,z_4,\quad z_{2K},z_{2K+1},z_{2K+2}.
 \tag{3}
\]

There are exactly two face-side free chords and exactly one
additional free block slot matched outside \(B\) by Note 265.
The two suffix slots other than \(t\), namely \(z_{2K}\) and
\(z_{2K+2}\), both have colour \(O\), so they cannot be
matched to each other. At least one is therefore a face-chord
endpoint. Its chord reaches the free prefix and straddles
all targets. Even free-prefix parity at any target forces the
second face chord to straddle the targets too. Thus both
suffix \(O\)-slots are face-chord endpoints. Their prefix
endpoints must be the two free \(E\)-slots \(z_1,z_3\).
Noncrossing on the designated-face side forces the nested
pairing in (2). The left mate \(s\) is \(z_2\) or \(z_4\).
Both face chords straddle \(z_4\), whereas only one straddles
\(z_2\). Note 258 requires an odd number to straddle \(s\),
so \(s=z_2\) and \(z_4\) is the external matching endpoint.

The mate of \(z_4\) cannot occur after the first target by
Note 203. If it lay between \(g\) and \(z_2\), its
opposite-side chord to \(z_4\) would interlace \(gz_2\).
It therefore lies before \(g\). If a complete block lay
between \(g\) and \(B\), Note 203 would make it target-free;
it is also saturated, hence short. Its adjacent free slots
cannot match each other. Opposite-side chords leaving the
intervening blocks would interlace \(gz_2\), and face-side
free chords cannot join different blocks. Thus their union
would be closed under the complementary matching, leaving
only two old-cycle edges to the rest of \(G\), contrary to
three-connectivity. The reflected argument using
\(z_{2K+1}h\) and the already matched \(z_{2K+2}\) shows
that \(h\) also immediately adjoins \(B\). This proves the
normal form.

Now put \(w=z_{2K+2}\) and \(t=z_{2K+1}\). Exactly as in
Note 266, the eight vertices
\[
 P=\{g,z_2,a,z_1,b,w,h,t\}
\]
induce \(P_4\square K_2\), with columns
\((g,z_2),(a,z_1),(b,w),(h,t)\). Its four attachments
are at \(g,z_2,h,t\), and it is disjoint from the site
edges and residual squares. The external edge at \(z_4\)
does not touch \(P\). Replace \(P\) by the square with
edges \(gz_2,z_2t,th,hg\). Note 178 preserves the
Barnette class and the simultaneous marked Hamilton
decision for \(p,q\). The old cycle replaces
\(g,a,z_1,z_2\) and \(t,w,b,h\) by \(g,z_2\) and
\(t,h\); the selected common face replaces its chord
\(ab\) by \(gh\). Thus \(\ell,r\) are unchanged,
all gaps disappear, and
\[
 (\sigma',T',f')=(1,0,4r+4).
\]
The legal site expansion commutes with this disjoint
replacement. Note 212 supplies a Hamilton cycle through
\(p,q\) in the compressed parent. Note 178 lifts it to
\(G\), and Note 001 lifts it through the original legal
site expansion. Restoring the original lobe ladders
preserves the marks. \(\square\)

**Shared middle support corollary.** In any opening satisfying
(1) with two singleton gaps, suppose both gap slots have their
matching mates in the same block strictly between the gaps.
Then the parent has a Hamilton cycle through \(p,q\), and its
legal site-expanded child is Hamiltonian.

Indeed, if the support block contains both vacancies, the
theorem applies. Otherwise each of the two vacancy blocks has
one vacancy. Notes 255 and 258 exclude a saturated block
as gap support, so the support block is one of these two.
A target-bearing support block has at most five
free interior slots, by the target count in Note 258. Its two
gap mates enclose every target; the odd gap-mate parity and
even target-prefix parity require at least two face-side
free chords, as in Note 264. Six distinct free slots would
be required, a contradiction. If the support block is
target-free, its four interior slots consist of the two gap
mates and the endpoints of its unique outer face-side chord.
The other vacancy block must be target-bearing by Note 259,
and it cannot lie between the gaps: one of the gap chords
would straddle its target, contrary to Note 203. Every other
intervening block is saturated, target-free and short. The
two gap chords trap all its free slots against matching
outside the interval from \(g\) through \(h\); face-side
chords stay within blocks. That interval is therefore
matching-closed, a forbidden two-edge cut. \(\square\)

The theorem covers only the all-square opening class in
(1) with both eligible vacancies in the same block.
The remaining sharp positive-gap shapes put the vacancies
in different blocks, at least one of them target-bearing,
and their two gap slots cannot share one support block
between them;
gapless third-surplus openings and nonsquare residual
cycles are separate cases. No conclusion about arbitrary
Barnette graphs follows.
