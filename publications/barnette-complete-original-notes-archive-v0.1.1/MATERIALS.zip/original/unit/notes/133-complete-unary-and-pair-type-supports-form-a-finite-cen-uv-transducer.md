> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Complete unary and pair-type supports form a finite CEN/UV transducer

[Note 132](132-complete-boundary-rows-and-bond-deletion-atoms-are-one-step-closed.md)
gives an exact one-step language for complete boundary rows and their
pairwise bond-deletion atoms.  Its row identities and pair relation can
grow with graph order.  This note proves that the identities themselves are
unnecessary: the supports of complete unary and ordered-pair **types** form
an exact finite quotient at every CEN/UV depth.

The parent kill-cover predicate, the current child supplementation
predicate, and the next-boundary transition are three different local maps.
All three factor through the same quotient, while only the third is
iterated.

## 1. The complete type quotient

Let \(A\) be the finite alphabet of complete unary boundary-row types.  A
type records its defect class, marked deletion atom \(\delta_{p,q}\), and
all finite root, gate, sector and fibre labels used by the predicates.  Let
\(B\) be the finite alphabet of complete **ordered** pair types.  A type in
\(B\) records its two endpoint types, the full pair-deletion atom
\(\varepsilon_{p,q}\), and an equality bit.  Write

\[
\partial_1,\partial_2:B\to A,
\qquad
\operatorname{eq}:B\to\{0,1\}.
\tag{1}
\]

An actual complete state \(S\) has a finite row set \(R(S)\), a unary type
map

\[
\alpha_S:R(S)\to A,
\tag{2}
\]

and a complete ordered-pair map

\[
\beta_S:R(S)^2\to B,
\tag{3}
\]

with

\[
\partial_i\beta_S(r,s)=
\begin{cases}
\alpha_S(r),&i=1,\\
\alpha_S(s),&i=2,
\end{cases}
\qquad
\operatorname{eq}(\beta_S(r,s))=1\iff r=s.
\tag{4}
\]

Define the realized type-support quotient

\[
q(S)=(U(S),P(S)),
\quad
U(S)=\alpha_S(R(S)),
\quad
P(S)=\beta_S(R(S)^2).
\tag{5}
\]

Thus \(P(S)\) contains all realized ordered pair types, including diagonal
and off-diagonal pairs of the same unary type.  It is not an independent
Boolean edge marginal.

## 2. Exact next-boundary transition

Let \(\ell\in\{\mathrm{CEN},\mathrm{UV}\}\).  For a unary type \(a\), let
\(\mathcal K_\ell(a)\) be the finite set of compatible generalized
production rows from Note 132: \(11\) total local patterns for CEN and
\(12\) for UV.  The marked partition joins define finite maps

\[
f_\ell(a,\kappa)\in A,
\qquad
g_\ell(b,\kappa,\lambda)\in B.
\tag{6}
\]

The equality bit in the second map is

\[
\operatorname{eq}
\bigl(g_\ell(b,\kappa,\lambda)\bigr)
=
\operatorname{eq}(b)\wedge[\kappa=\lambda].
\tag{7}
\]

For an abstract support pair \((U,P)\), set

\[
\Phi_\ell(U,P)=\bigl(U_\ell',P_\ell'\bigr),
\tag{8}
\]

where

\[
U_\ell'
=
\{f_\ell(a,\kappa):
a\in U,\ \kappa\in\mathcal K_\ell(a)\},
\tag{9}
\]

and

\[
P_\ell'
=
\{g_\ell(b,\kappa,\lambda):
b\in P,\
\kappa\in\mathcal K_\ell(\partial_1b),\
\lambda\in\mathcal K_\ell(\partial_2b)\}.
\tag{10}
\]

If \(T_\ell S\) is the actual complete boundary state at the named next
site, then

\[
\boxed{q(T_\ell S)=\Phi_\ell(q(S)).}
\tag{11}
\]

Indeed, Note 132 gives every next row a unique restriction
\((r,\kappa)\), and every ordered next pair a unique restriction

\[
\bigl((r,\kappa),(s,\lambda)\bigr).
\tag{12}
\]

This proves inclusion in (9)--(10).  Conversely, every \(a\in U(S)\) and
\(b\in P(S)\) has an actual witness row or ordered witness pair.  Extending
that same witness by every compatible local pattern realizes every type on
the right-hand sides of (9)--(10).  No multiplicity or ternary incidence is
used.  When two distinct old rows have the same unary type, their existence
is already recorded by an off-diagonal type in \(P(S)\); equation (7)
handles all diagonal cases after production.

## 3. The two perfect-matching outputs

The generalized next-boundary rows in (11) are not the current parent or
child perfect-matching fibre.  These are reconstructed by two separate
finite maps.

First adjoin the four canonical local \(p/q\) patterns to the compatible
current defect rows.  Applying the same unary and pairwise partition joins
gives the exact parent-PM unary and pair supports
\(U_{\rm par}(q(S))\) and \(P_{\rm par}(q(S))\).  The full kill-cover
antecedent includes the nonempty crossing graph and the nonempty
\(C_{11}\) slice.  Hence it is the finite support predicate

\[
\operatorname{ParentKill}(q(S))
\iff
\bigl(\exists a\in U_{\rm par}(q(S)):
\operatorname{11}(a)\bigr)
\land
\bigl(\exists b\in P_{\rm par}(q(S)):
\operatorname{Bond}_{\rm par}(b)\bigr)
\land
\forall b\in P_{\rm par}(q(S)),\quad
\operatorname{Bond}_{\rm par}(b)
\Longrightarrow
\operatorname{11}(\partial_1b)
\lor
\operatorname{11}(\partial_2b).
\tag{13}
\]

Separately adjoin the seven child-PM patterns

\[
C_{00},C_{10},C_{01},C_{11},R_{00},X_{uy},X_{vx}.
\tag{14}
\]

The resulting exact ordered pair support \(P_{\rm ch}(q(S))\) gives

\[
\operatorname{ChildSupplement}(q(S))
\iff
\exists b\in P_{\rm ch}(q(S)):
\operatorname{Bond}_{\rm ch}(b)
\land
\bigl(
\operatorname{NewCell}(\partial_1b)
\lor
\operatorname{NewCell}(\partial_2b)
\bigr),
\tag{15}
\]

where \(\operatorname{NewCell}\) denotes
\(R_{00},X_{uy},X_{vx}\).  The seven-cell production and its pair join are
again restriction--extension bijections, so (13)--(15) are exact, not
relaxations.  The child truth value is independent of which next site is
subsequently named.

## 4. All-depth consequence

For a word \(w=\ell_1\cdots\ell_k\) in CEN and UV,

\[
q(T_wS)=
\Phi_{\ell_k}\circ\cdots\circ\Phi_{\ell_1}(q(S)).
\tag{16}
\]

Thus complete type supports form a deterministic finite transducer with
raw state space

\[
\mathcal Q=2^A\times2^B,
\qquad
|\mathcal Q|\le 2^{|A|+|B|}.
\tag{17}
\]

At every depth, (13) and (15) are finite output functions, while only
\(\Phi_\ell\) is iterated.  One may restrict \(\mathcal Q\) to coherent
supports or to those reachable from a chosen actual initial state.  Every
actual CEN/UV history is represented exactly.

## 5. Why all retained fields are necessary

Three strict weakenings fail.

1. If the equality bit is deleted, one row and two equal-type rows have the
   same abstract unary and pair-core supports, but their outputs differ by
   the existence of an off-diagonal pair.  This is a finite relational
   countermodel; graph realizability is not asserted.
2. If off-diagonal same-unary-type support is deleted, keep one visible
   \(C_{11}\)--\(A\) bond and then add a second non-\(C_{11}\) row of type
   \(A\), whose difference from the first \(A\)-row is one closed
   alternating cycle.  The crossing graph and \(C_{11}\) slice are
   nonempty in both realizations, but the hidden \(A\)--\(A\) bond changes
   parent kill-cover from true to false.
3. If \(\varepsilon_{p,q}\) is replaced by its Boolean bond value, take
   endpoint classes \(\varnothing\) and \(uy\).  The parent Boolean bond is
   false both when the four stubs lie in one component and when the same
   component is accompanied by one closed component.  After the
   \(C_{00}\)--\(X_{uy}\) child production, the two differences have one
   and two components respectively, so supplementation differs.  A CEN
   next-boundary production also sends them to different pair types.

The local symbolic verification and the frozen weakening collisions are in
the [complete boundary type-support bundle](../computations/bundles/complete-boundary-type-support-automaton/README.md).

## 6. Scope

This theorem removes the apparent unbounded-row obstruction to exact
CEN/UV word encoding.  It does not say that every element of
\(2^A\times2^B\) is coherent or graph-realizable, and it does not prove the
rooted split-bond lemma or \(H^{+-}\) preservation.  The remaining
mathematical interface is no longer all-depth bookkeeping: it is to
characterize which finite type supports are forced by the common
perfect-matching family of an actual plane cubic brace, or to find a
reachable unsafe support.
