> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An internal near-equality vacancy must touch a short face-chord block

[Note 197](197-gapless-square-trap-defect-budget.md) counts the unique
eligible vacancy when a gapless all-square opening first exceeds exact
packing. [Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md)
shows that a free matching chord between different blocks cannot
straddle an escape target. Combining that planar restriction with
the parity of free slots yields a restriction independent of the
number of opposite-face chords. The first alternative below is
realized by [Note 204](204-two-chord-detours-realize-gapless-near-equality-for-all-lobe-counts.md)
for every \(\ell,r\ge2\).

Let \(G,C,M,S_0\) be a compressed one-square-per-lobe Barnette
opening in the notation of Notes 195--197. There are \(\ell\ge1\)
lobes, \(r\ge1\) opposite-face matching chords, and main blocks
\(B_0,\ldots,B_{r+1}\). Assume:

* every interblock gap is empty and \(f=4r+4\);
* \(R_\ell\) is the first interior slot of \(B_0\), and
  \(L_1\) is the final interior slot of \(B_{r+1}\);
* \(L_jR_{j-1}\in E(C)\) for \(2\le j\le\ell\);
* the unique eligible even position not occupied by a
  nonfinal \(L_j\) lies in a face-chord block \(B_k\),
  \(1\le k\le r\).

Write \(2+2k_k\) for the number of interior slots of \(B_k\),
and let its vacant position be \(2t\), where
\(1\le t\le k_k\). Put
\[
 a=t-1,\qquad b=k_k-t.                         \tag{1}
\]
Thus \(a\) and \(b\) count the occupied eligible positions,
and their following odd escape targets, respectively before
and after the vacancy within \(B_k\).

**Peripheral-vacancy theorem.** One has \(ab=0\). More
precisely:

1. If \(a=0<b\), then \(k\ge2\) and the immediately
   preceding face-chord block \(B_{k-1}\) has exactly two
   interior slots.
2. If \(b=0<a\), then \(k\le r-1\) and the immediately
   following face-chord block \(B_{k+1}\) has exactly two
   interior slots.
3. If \(a=b=0\), then \(B_k\) has four interior slots;
   this theorem places no further condition on its matching.

In particular, a tight gapless first-surplus opening cannot
put its sole vacant eligible position between two nonempty
runs of escape-target pairs in one face-chord block.

**Proof.** Since the vacancy is unique, every other eligible
even slot of every block holds a nonfinal \(L_j\). Its following
odd interior slot is \(R_{j-1}\) by the assumed adjacency.
The first slot of \(B_0\) is \(R_\ell\), and its last slot is
free. Every ordinary face-chord block other than \(B_k\)
has precisely its first odd and last even interior slots
free. The final block has only its first odd slot free,
because its last slot is \(L_1\). In \(B_k\) the four free
interior slots, in order, are
\[
 o,\ h,\ i,\ e,                                    \tag{2}
\]
where \(o\) is its first odd slot, \(h\) the vacant even
slot, \(i\) the immediately following odd slot, and
\(e\) its final even slot. There are \(a\) target pairs
between \(o,h\) and \(b\) target pairs between \(i,e\).
In particular \(hi\) is an old-cycle edge and cannot
belong to \(M\).

Suppose \(a,b>0\). The matching mate of \(h\) cannot lie
in an earlier block: that cross-block chord would straddle
one of the targets between \(o,h\), contrary to Note 203.
It cannot lie in a later block for the same reason, using
a target between \(i,e\). Inside \(B_k\), its only free
odd candidates are \(o,i\), and \(hi\notin M\). Therefore
\(ho\in M\).

The free interior slots in \(B_0,\ldots,B_{k-1}\) number
\(1+2(k-1)=2k-1\). Every matching mate of one of these
slots lies in the same set: all block endpoints and square
vertices already have fixed matching partners; \(o,h\)
are paired to each other; and a chord reaching \(i,e\)
or any later block would straddle a target between \(o,h\).
This would give a perfect matching of an odd set, a
contradiction. Hence \(ab=0\).

Now suppose \(a=0<b\). The vertices \(o,h\) are adjacent
on \(C\), as are \(h,i\), so neither \(oh\) nor \(hi\)
lies in \(M\). A cross-block mate of \(h\) in a later
block would straddle a target between \(i,e\); there is
no other free odd slot of \(B_k\). Thus \(h\) must match
the first free odd slot of some earlier face-chord block
\(B_j\), \(1\le j<k\); \(B_0\) has only a free even slot.
The chord from \(B_j\) to \(h\) cannot straddle any target.
Every eligible position outside \(B_k\) is occupied, so
all blocks \(B_j,\ldots,B_{k-1}\) must be short, with
two interior slots each. In particular \(B_{k-1}\) is
short and \(k\ge2\).

Finally suppose \(b=0<a\). The vertices \(h,i\) and
\(i,e\) are both adjacent on \(C\). A mate of \(i\)
in an earlier block would straddle a target between
\(o,h\), and its only other same-block free even
slots are \(h,e\). It must therefore match the final
free even slot of some later face-chord block \(B_j\),
\(k<j\le r\); \(B_{r+1}\) has only a free odd slot.
The chord from \(i\) to \(B_j\) cannot straddle any
target, so \(B_{k+1},\ldots,B_j\) are all short.
In particular \(B_{k+1}\) is short and \(k\le r-1\).
If \(a=b=0\), (1) gives \(k_k=1\), hence four interior
slots. \(\square\)

The theorem is a necessary shape condition for the stated
tight, gapless near-equality branch. It does not decide
Hamiltonicity for all openings at \(f=4r+4\).

Both one-sided alternatives are attained for every
\(\ell,r\ge2\). Note 204 places the vacancy at the first
eligible position of \(B_r\), with \(\ell-1\) target
pairs to its right and a short \(B_{r-1}\) to its left.
For the other alternative, reverse the orientation of its
main segment, exchange the site labels, and reverse the
lobe order while interchanging the \(L\)- and \(R\)-target
names. The old block \(B_r\) becomes the new \(B_1\).
Its old third interior slot \(i\), which is free, becomes
the new vacant eligible slot at position \(2\ell\) of
that block; the old second slot \(h\) becomes its following
free odd slot. The new \(B_2\) is the old short
\(B_{r-1}\). This is a relabeling of the same Barnette
graph and the same marked Hamilton cycle, so it realizes
\(b=0<a=\ell-1\) without another construction.

[Note 206](206-target-free-near-equality-vacancies-exist-at-every-lobe-and-chord-count.md)
subsequently realizes item 3 for every \(\ell\ge1,r\ge2\).
Thus all three shapes in this necessary classification
occur in Hamiltonian Barnette parents.
[Note 207](207-a-single-long-chord-block-at-first-surplus-always-has-a-marked-hamilton-cycle.md)
subsequently proves universal Hamiltonicity when all
block-extra slots lie in the one face-chord block
containing the vacancy and \(\ell\ge2\).
[Note 208](208-one-sided-internal-vacancies-have-marked-hamilton-cycles-at-first-surplus.md)
then removes that concentration assumption whenever
the vacancy's own block contains a target pair.
