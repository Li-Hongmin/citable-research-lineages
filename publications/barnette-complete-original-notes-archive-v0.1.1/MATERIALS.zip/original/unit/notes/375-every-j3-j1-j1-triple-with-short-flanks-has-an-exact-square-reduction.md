> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every J3,J1,J1 triple with short flanks has an exact square reduction

[Note 344](344-every-three-double-j1-j3-free-group-has-a-spanning-route.md)
proves a spanning route for every actual matching
of a realizable \(J_3,J_1,J_1\) three-double
free group. The central-return core and all four
one-sided return atoms have since been shown to
have complete square signatures in
[Notes 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md),
[371](371-the-first-left-return-of-a-j3-j1-j1-triple-has-the-exact-square-signature.md),
[372](372-every-one-sided-left-return-of-the-j3-j1-j1-triple-has-a-square-signature.md),
[373](373-the-first-right-return-of-a-j3-j1-j1-triple-has-the-exact-square-signature.md),
and [374](374-every-one-sided-right-return-of-the-j3-j1-j1-triple-has-a-square-signature.md).
The boundary-link argument of Note 344 now composes
them across arbitrary short flanks.

Use the compressed, gapless, tight-target all-square
opening of Note 324. Fix an ordinary target-free
free group whose exactly three doubly vacant
complete blocks, in old-cycle order, carry
\(J_3,J_1,J_1\) internal free chords; every other
complete block in the group is short, and there
is no singly vacant block in it. Note 343 forces
the first two double blocks to be adjacent and
\(q\ge1\) short blocks between the second and
third. Let \(p,r\ge0\) be the numbers of short
blocks before and after the triple. Let
\(L,R\) be the ordinary even left and odd right
endports. The whole group contains
\[
                         24+4(p+q+r)                 \tag{1}
\]
vertices.

**Three-double exact-reduction theorem.** Every
complementary matching that actually occurs in
such a Barnette opening makes the entire group
an induced disk four-pole with the exact spanning
one-path and two-path Hamilton signature of a
square. Replacing the group by the labeled square,
or reversing the replacement, preserves the
Barnette class and every Hamilton decision on
edges outside the group and on its four labeled
attachments. In the specified opening, the square
is one short target-free block and retains the
selected old cycle, common-face arc, two site
edges, and legal site expansion. The statement
does not require any condition on vacancies
outside the group. Old-cycle reflection gives
the same conclusion for \(J_3,J_3,J_1\), with
the required corridor on the other side.

**The central chord branch.** If \(h_1j_3\)
belongs to the matching, Note 344 forces all
ordinary links through both outer short flanks.
The triple-and-corridor interval is Note 370's
square-equivalent \(Q_q\), with adjacent terminal
pairs \(a_1o_1\) and \(e_3b_3\). Each left
short block is precisely a left standard buffer,
and each right short block a right standard
buffer in the sense of
[Note 367](367-square-signature-four-poles-are-closed-under-standard-short-buffers.md).
That theorem preserves the exact signature,
the two patch deletion properties, and the
Barnette class through all \(p+r\) additions.
The resulting entire group is the asserted
four-pole.

**At most one nonstandard flank without the
central chord.** Suppose \(h_1j_3\) is absent.
When both current flanks are nonempty, Note 344's
four-slot transfer proves that at least one
current outer boundary matching link is standard:
the first left endport matches the first left
short block's odd free slot, or the final right
short block's even free slot matches the right
endport. Its proof rules out a skipped complete
block by a two-edge cut and rules out simultaneous
nonstandard outer links by planar crossing.
Removing a standard first-left block changes
only the virtual left endport to that block's
other free slot; removing a standard final-right
block changes only the virtual right endport.
The original no-two-edge-cut condition continues
to apply to every remaining complete-block
interval.

Peel the maximal standard left prefix and
maximal standard right suffix. The two sets of
matching edges are disjoint and lie on opposite
sides of the fixed core, so the peels commute.
If both remaining flanks were nonempty, neither
current boundary edge could be standard by
maximality, contradicting the preceding
boundary-link lemma. Thus at least one *entire*
outer flank is standard. Both cannot be entirely
standard: after peeling them, the no-flank
four-slot group forces \(h_1j_3\) by Note 344,
contrary to this branch. Hence precisely one
flank contains the nonstandard return.

If the right flank is entirely standard, remove
it while leaving the whole original left flank
intact, including any of its standard prefix.
The induced remaining left-only matching is
exactly Note 344 (7) for one
\(0\le\mu<p\). For \(\mu=0\), Note 371 gives
the exact square four-pole; for \(\mu>0\),
Note 372 does. Its right terminal pair is the
old-cycle edge \(e_3b_3\). Reinsert the right
blocks in reverse peel order. Each is a right
standard buffer at that adjacent pair, so
Note 367 gives the whole group the exact
signature and both deletion properties.

If the left flank is entirely standard, remove
it and retain the whole original right flank.
Reversing Note 344 (7)'s abstract four-slot
word classifies its right-only matching.
Note 373 covers its first return; Note 374
covers every deeper return. The left terminal
pair of either four-pole is the old-cycle
edge \(a_1o_1\). Reinsert the left standard
blocks in reverse peel order using Note 367's
left buffer. This again yields the complete
square signature and two-way Barnette
preservation. No symmetry of the
\(J_3,J_1,J_1\) core is used in this case.
These branches exhaust every actual matching.

The entire group has only four exterior
attachments: the two old-cycle edges at the
first and last block, and the matching edges
at its left and right ordinary endports.
Every other vertex has all three incident
edges inside the group. Each one-sided atom
is an induced disk patch, and the standard
buffers preserve terminal disk order and
opposite-colour pattern. Its first and last
old-cycle vertices are the face endpoints;
the two matching terminals are their
respective internal neighbours after
compression. Thus the replacement square
has the old-cycle four-vertex segment and
face-closing chord of an ordinary short block.
All other opening pieces lie outside.
This proves every assertion. \(\square\)

In particular, a vertex-minimal non-Hamiltonian
Barnette graph cannot contain any one of these
induced \(J_3,J_1,J_1\) or reflected
\(J_3,J_3,J_1\) four-poles: replacing it by the
smaller square would preserve both the class
and its Hamilton status. This is a statement
about these specified patches, not a
classification of arbitrary Barnette graphs.
Other internal-chord types, a singly vacant
block in the same group, defective targets,
positive gaps, nonsquare residual cycles,
and Barnette's conjecture remain unresolved.
The proof is project-internal and has not
had independent review or an exhaustive
external novelty comparison.
