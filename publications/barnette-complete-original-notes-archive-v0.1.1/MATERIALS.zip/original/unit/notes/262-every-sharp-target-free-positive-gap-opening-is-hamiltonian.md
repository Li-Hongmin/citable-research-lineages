> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every sharp target-free positive-gap opening is Hamiltonian

[Note 261](261-the-sharp-target-free-gap-has-one-adjacent-two-slot-gap.md)
forces an exact six-vertex patch when the two third-surplus
vacancies share one target-free block. It is precisely the
incident-edge insertion of [Note 185](185-two-squares-sharing-an-edge-have-a-four-terminal-hamilton-signature.md).
Peeling it reduces the opening to the equality class of
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md),
while preserving both specified site edges.

Let \(G\) be a Barnette parent with a Hamilton cycle \(C\)
avoiding disjoint cofacial matching site edges \(q=xy,p=uv\).
Select an all-square facial opening with \(\ell,r\ge1\),
and suppose
\[
f=4r+8,\qquad \sigma=2,\qquad T=2,
\tag{1}
\]
with both vacant eligible positions in one target-free block.
Suppose the square expansion at \(p,q\) is legal in the
Barnette class.

**Sharp target-free gap Hamilton theorem.** The parent \(G\)
has a Hamilton cycle containing both \(p,q\); consequently
its legal site-expanded child is Hamiltonian. This holds for
all \(\ell,r\ge1\) and arbitrary positive original lobe
lengths.

**Proof.** Compress the lobes by Note 178. Note 261 allows
reflection so that the target-free block \(B=[a,b]_C\)
immediately precedes the sole two-slot gap \(g,h\). Name its
six interior slots \(w_1,\ldots,w_6\), and let \(c\) be the
first vertex of the next block. The relevant old-cycle path
and matching edges are exactly
\[
\begin{split}
&a,w_1,w_2,w_3,w_4,w_5,w_6,b,g,h,c,\\
&ab,\quad w_3w_6,\quad w_5g,\quad w_4h.
\end{split}                                                   \tag{2}
\]
The vertices \(w_3,w_4,w_5,w_6,g,h\) induce two squares
\[
w_3w_4w_5w_6w_3,\qquad w_4w_5ghw_4,                  \tag{3}
\]
sharing \(w_4w_5\). Their only edges to the rest of \(G\)
are \(w_3w_2,w_6b,gb,hc\). In Note 185's notation, put
\[
(\alpha,\gamma,\delta,\beta,L,R)
 =(w_3,w_4,w_5,w_6,h,g).
\]
The two attachments at \(b\) are those of \(\beta,R\),
so (3) is Note 185's insertion into the two incident edges
\(bw_2\) and \(bc\) of a smaller cubic graph \(X\).

Delete these six patch vertices and restore \(bw_2,bc\).
The inverse is simple: in \(G\), the three neighbours of
\(b\) are \(a,w_6,g\), its matching edge is \(ab\), and
\(w_2,c\) are distinct exterior vertices not already
adjacent to \(b\). Under the displayed labeling, \(G\)
is exactly Note 185's insertion into the two incident edges
of \(X\); its reverse class-preservation theorem makes
\(X\) a Barnette graph. The old Hamilton
cycle compresses the path in (2) to \(a,w_1,w_2,b,c\),
so it becomes a Hamilton cycle of \(X\) still avoiding
\(p,q\). The six deleted vertices are interior or gap
slots, so neither site edge is deleted, even if \(ab\) is
itself a site edge and \(b\) a site endpoint.
On the designated common-face boundary, the subpath
\(a,b,g,h,c\) becomes \(a,b,c\). Deleting the patch does
not add a face chord or split this face, so \(p,q\) remain
cofacial and the number \(r\) of other face chords is unchanged.
The selected alternating
arc from \(v\) to \(x\) and every residual square remain
unchanged. The block \([a,b]_C\) now has only \(w_1,w_2\)
as interior slots, and all other blocks are saturated.
Thus the inverse opening has \(\sigma'=T'=0\) and
\[
f'=f-6=4r+2.                                          \tag{4}
\]

More explicitly than the general routing theorem, the
Hamilton cycle \(M_X\cup A_X\) constructed in Note 196
contains \(bw_2\): the even-starting old-cycle matching
\(A_X\) pairs the final interior slot \(w_2\) of this
block with \(b\). Replace that edge in the cycle by
\[
w_2,w_3,w_4,h,g,w_5,w_6,b.                           \tag{5}
\]
Each consecutive pair is an edge of \(G\), and (5) visits
each of the six inserted vertices once. Every other edge
of the Note 196 cycle, including \(p,q\), is retained.
This gives the claimed marked Hamilton cycle of \(G\).
Note 001 lifts it
through the legal expansion at \(p,q\), and Note 178
restores the original lobe lengths. \(\square\)

In particular, Note 260's minimum-order positive-gap example
is a six-vertex cube insertion over an equality opening.
Together with Note 259, this settles every positive-gap
third-surplus opening whose two vacancies lie in target-free
blocks: the distinct-block case is impossible, and the
same-block case has the marked Hamilton cycle above.
It does not cover target-bearing vacancy
blocks, gapless third-surplus openings, nonsquare residual
cycles, or arbitrary Barnette graphs.
