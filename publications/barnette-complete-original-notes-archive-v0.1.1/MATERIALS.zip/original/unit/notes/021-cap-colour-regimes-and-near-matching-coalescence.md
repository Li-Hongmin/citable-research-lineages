> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cap colour regimes and the near-matching coalescence boundary

Let \(F\) be a cubic bipartite brace, let \(z\in V(F)\), and write

\[
N_F(z)=\{a_1,a_2,a_3\}.
\]

Deleting (z) gives one shore of a tight three-edge splice.  Let
(p=uv) be an edge of that shore and distinguish the endpoint (v).
For ({i,j,k}={1,2,3}), use the cap signatures from
[Note 020](020-minimum-c4-h-plus-minus-counterexamples-are-chain-to-brace.md):

- (P_i) is a spanning (v)-(a_i) path in (F-z-p);
- (K_i) is a spanning two-path cover in (F-z-p) with pairing
  ((v,a_i)(a_j,a_k)).

This note determines the exact bipartite regimes of these signatures,
reduces their zero-residual condition to a near-matching/dual-forest
selection, and shows why minimum-parent induction and pairwise edge
incidence do not by themselves settle that selection.

## The colour dichotomy

Fix a bipartition with (z) in one class.  All three ports (a_i) lie in
the other class.

If (P_i) exists and (v\ne a_i), its shore has an odd number of
vertices, so the two endpoints of its spanning path have the same colour.
Thus (v) has the colour of (a_i), and (u) has the colour of (z).
If (v=a_i), a one-port state at (i) would have an isolated
zero-length (v)-component and cannot span a nontrivial shore.  Hence

\[
P_i\Longrightarrow \operatorname{col}(u)=\operatorname{col}(z).
\tag{1}
\]

The complement of a (K_i) two-path cover is a perfect matching of

\[
F-\{u,z\}.
\tag{2}
\]

Such a matching is impossible if (u,z) lie in the same bipartition
class.  Consequently

\[
K_i\Longrightarrow \operatorname{col}(u)\ne\operatorname{col}(z).
\tag{3}
\]

Brace extendability below shows that the corresponding near-matching
families are nonempty in the colour-compatible case.  The exact regime
separation is therefore

\[
\boxed{
\operatorname{col}(u)=\operatorname{col}(z)\Longrightarrow K=\varnothing,
\qquad
\operatorname{col}(u)\ne\operatorname{col}(z)\Longrightarrow P=\varnothing.}
\tag{4}
\]

In particular, if (v=a_h), then (u,z) have the same colour and every
(K_i) is impossible.  Thus the formally allowed zero-length (K_h)
from the raw path-cover definition is never realised in a bipartite
capped shore.

## Both shores have the same regime

For a splice, write the physical cut edges as (a_i b_i), and let
(z_L,z_R) be the cap vertices in the two tight-cut contractions.  Since
(a_i b_i) is an edge,

\[
\operatorname{col}(z_L)=\operatorname{col}(b_i),
\qquad
\operatorname{col}(z_R)=\operatorname{col}(a_i),
\]

so the two cap vertices have opposite colours.  At a legal site

\[
p=uv,\qquad q=xy,
\]

the facial bipartite orientation gives (u,x) the same colour and hence
(u,y) opposite colours.  The right shore compares (y) with (z_R).
Therefore

\[
\boxed{
\operatorname{col}(u)=\operatorname{col}(z_L)
\iff
\operatorname{col}(y)=\operatorname{col}(z_R).}
\tag{5}
\]

The two shores are always both in the (P)-regime or both in the
(K)-regime.  Combining this with the cap-gluing criterion in Note 020
gives a sharp sufficient local target.

> **Cap-cardinality criterion.**  If every capped planar
> global-(H^{+-}) brace at such a facial endpoint satisfies
> \[
> \operatorname{col}(u)=\operatorname{col}(z)\Longrightarrow |P|\ge2,
> \qquad
> \operatorname{col}(u)\ne\operatorname{col}(z)\Longrightarrow |K|\ge2,
> \tag{6}
> \]
> then (D=X_{vx}) survives every tight splice.

Indeed, two subsets of size at least two in a three-element set intersect,
which supplies the one-port gluing in the (P)-regime.  In the
(K)-regime two such subsets contain a pair of unequal indices, which
supplies the three-port gluing.

This is a sufficient criterion for one cross traversal.  It does not by
itself settle the mixed or retained--retained ordered-edge blocks required
for full preservation of global (H^{+-}).

## A minimum parent gives only one same-endpoint child constraint

Suppose (F) is a brace factor strictly smaller than a minimum
counterexample parent, and label the relevant facial boundary as

\[
z,a_1,\ldots,u,v,\ldots,a_2,z,
\tag{7}
\]

where (a_1,a_2) are the face ports and (a_3) is off the face.  For a
fixed directed (p=(u,v)), only one of the two face-cap edges is a legal
site with the same special endpoint (v).  Reversing the other site also
reverses (p) and constrains the signatures distinguished at (u), not
the same (P(v),K(v)) family.

In the (P)-regime the correctly oriented site is

\[
(p,q_1)=((u,v),(z,a_1)).
\]

Its smaller child has global (H^{+-}), so the private gadget pair for
row (D) forces a spanning (v)-(z) path in (F-\{p,za_1\}).  Its
last cap edge is (za_2) or (za_3); deleting (z) gives the exact
constraint

\[
\boxed{P\cap\{2,3\}\ne\varnothing.}
\tag{8}
\]

In the (K)-regime the correctly oriented site is

\[
(p,q_2)=((u,v),(a_2,z)).
\]

The corresponding (D)-path gives (K_1) or (K_3).  Planar boundary
rotation excludes the off-face crossing state (K_3), so

\[
\boxed{1\in K.}
\tag{9}
\]

Thus minimum-parent induction does not prove (6).  It still permits
disjoint (P)-sets such as ({2}) and ({3}), while it reduces an
equal-singleton (K)-failure to the sole physical form

\[
K_L=K_R=\{1\}.
\tag{10}
\]

The one-brace parent allowed by Note 020 has no smaller-factor constraint
at all.

## Near matchings and zero residual

A cubic brace is 2-extendable.  Equivalently, for every nonempty proper
set (X) in one bipartition class with (|X|) below the terminal range,

\[
|N(X)|\ge |X|+2.
\tag{11}
\]

It follows by Hall's theorem that deleting any one vertex from each
class, or any two vertices from each class, leaves a perfect matching.
Therefore all near-matching families below are nonempty; connectivity is
the only missing condition.

### The (P)-regime

For ({i,j,k}={1,2,3}), put

\[
\mathcal M_i=\operatorname{PM}(F-\{u,z,a_j,a_k\}).
\tag{12}
\]

For (M\in\mathcal M_i), the graph

\[
Q_i(M)=(F-z-p)-M
\tag{13}
\]

has one (v)-(a_i) path component and otherwise only cycles, except
that (v=a_i) gives an isolated distinguished component.  Hence

\[
\boxed{P_i\iff
\exists M\in\mathcal M_i\text{ for which }Q_i(M)
\text{ has no residual component}.}
\tag{14}
\]

### The (K)-regime

Put

\[
\mathcal M_{u,z}=\operatorname{PM}(F-\{u,z\}).
\tag{15}
\]

For (M\in\mathcal M_{u,z}), let

\[
Q(M)=F-M-p.
\tag{16}
\]

Its degrees are one at (v), three at (z), and two elsewhere.  The
component containing the two odd-degree vertices is a lollipop: a unique
(v)-to-(z) tail and a cycle meeting it at (z).  Every other component
is a cycle.  Let (t(M)) be the cap port through which the tail reaches
(z).  Then

\[
\boxed{K_i\iff
\exists M\in\mathcal M_{u,z}\text{ such that }Q(M)
\text{ has no residual cycle and }t(M)=i.}
\tag{17}
\]

Planarity excludes (i=3), so the (K)-part of (6) asks for
zero-residual lollipops with both face labels (1,2).

## The planar-dual formulation

For a connected plane graph (J) and (A\subseteq E(J)), bond--cycle
duality gives

\[
J-A\text{ is connected}
\iff A^*\text{ is acyclic in }J^*.
\tag{18}
\]

In the (P)-regime, every (M\in\mathcal M_i) has exactly one fewer
edge than the number of vertices of ((F-z-p)^*).  Thus

\[
\boxed{P_i\iff
\exists M\in\mathcal M_i: M^*
\text{ is a spanning tree of }(F-z-p)^*.}
\tag{19}
\]

In the (K)-regime, every (M\in\mathcal M_{u,z}) has two fewer edges
than the number of vertices of ((F-p)^*).  Therefore

\[
\boxed{K_i\iff
\exists M\in\mathcal M_{u,z}: M^*
\text{ is a spanning two-component forest of }(F-p)^*
\text{ with tail label }i.}
\tag{20}
\]

The cap-cardinality question is consequently a simultaneous
near-perfect-matching and dual-tree/forest selection problem, not a
matching-existence problem.

There is also an exact formulation inside the full dual (T=F^*).  For
(X\subseteq E(F)=E(T)), define the triangular-face load

\[
\lambda_X(w)=|X\cap\delta_F(w)|.
\tag{21}
\]

Write (h_i=za_i).  Complementing the Hamilton (v)-(z) path obtained
from a (P_i)-state gives

\[
\boxed{
P_i\iff \exists\text{ a dual spanning tree }B_i:
\begin{cases}
\lambda_{B_i}=\mathbf1+e_v+e_z,\\
p^*,h_j^*,h_k^*\in B_i,\\
h_i^*\notin B_i.
\end{cases}}
\tag{22}
\]

For (K_i), let (A_i) be the dual complement of the connected
lollipop.  Then

\[
\lambda_{A_i}=\mathbf1+e_v-e_z,\qquad
p^*\in A_i,\qquad h_1^*,h_2^*,h_3^*\notin A_i,
\tag{23}
\]

and the exact condition is

\[
\boxed{
K_i\iff \exists A_i:
\begin{cases}
A_i\text{ is a spanning two-forest satisfying (23)},\\
A_i+h_j^*,\ A_i+h_k^*\text{ are spanning trees},\\
A_i+h_i^*\text{ is not a spanning tree}.
\end{cases}}
\tag{24}
\]

Thus (K_i) is not a one-tree marginal: two trees must have the same
deleted two-forest.  Global (H^{+-}), by contrast, directly supplies
only trees

\[
B_{e,f}=(M\cup\{e\})^*,\qquad
\lambda_{B_{e,f}}=\mathbf1+e_r+e_s
\tag{25}
\]

for (e=rs\ne f), where (F-M) is a Hamilton cycle containing (e)
and avoiding (f).  A graphic exchange (B-e^*+g^*) changes the load by

\[
-e_{r_1}-e_{r_2}+e_{s_1}+e_{s_2},
\tag{26}
\]

where (e=r_1r_2) and (g=s_1s_2).  The basis-exchange axiom controls
neither these four coordinates nor the common deletion required in
(24).

## Sharp boundaries of simpler arguments

The stronger claim that both face ports always lie in (P) is false.
In the cube take, in binary coordinates,

\[
z=000,\quad(a_1,a_2,a_3)=(001,010,100),\quad
p=(011,001).
\]

The common square is (000,001,011,010,000), and (v=a_1).  Directly,

\[
P=\{2,3\};
\tag{27}
\]

(P_1) is impossible because its distinguished path would have equal
endpoints.  The cube is a genuine planar global-(H^{+-}) brace, so this
is a graph-level counterexample to the literal face-pair strengthening,
not to the cardinality criterion.

Minimum-parent induction also stops at the pairwise incidence layer.  For
the unique legal (P)-regime child at ((p,za_1)), append to the six
gadget rows their incidence on the two retained cap edges
((za_2,za_3)).  The nine concrete formal rows

\[
A_2,A_3,B_{23},C_2,C_3,D_3,E_{23},L_2,L_3
\tag{28}
\]

obey all cap degrees and the legal (L=(uv)(za_1)) pairing.  Their ten
edge columns are pairwise incomparable, so they satisfy every ordered
contain--avoid pair on the eight gadget edges and both retained cap
edges.  Nevertheless (D_3) is the only (D)-row, equivalently the
model has (P=\{3\}).  Taking all product copies over any additional
retained symbols preserves full ordered-edge separation without creating
(D_2).  A compatible parent incidence projection exists as well.

This is a strict abstract state countermodel, not a brace.  It proves that
the parent and smaller-child (H^{+-}) quantifiers, six traversal rows,
and all binary retained-edge decorations cannot exclude the off-face
singleton.  A positive proof must use common perfect-matching incidence,
connected-complement exchange, or a genuinely joint condition which
forces a (D)-witness and its retained cap incidence simultaneously.

Ordinary two-source dual-tree exchange also fails in a real brace.  The
order-(16) graph

```text
OlCGHD@?g?_@@@A?_?k?P
```

is a plane cubic bipartite global-(H^{+-}) brace; its dual is an
Eulerian triangulation with no separating triangle.  At

\[
z=13,\qquad (h_1,h_2,h_3)=(13\,4,13\,12,13\,14),
\qquad p=(15,14),
\]

there are two genuine global-(H^{+-}) source trees, both containing
(p^*,h_1^*), with respective loads

\[
\mathbf1+e_u+e_v,qquad \mathbf1+e_z+e_{a_1}.
\]

The entire Boolean edge cube of their union contains no support with
load \(\mathbf1+e_v+e_z\) and the same fixed pair.  Hence no sequence of
symmetric exchanges confined to those two witnesses can reach a
(P)-target.  The graph itself has (P=\{1,2\}); a successful target
uses six edges outside that union.  This is therefore a genuine
brace-level counterexample to the two-source exchange proof, not to the
cardinality criterion.  Any positive exchange theorem must use the full
compatible tree family, and the (K)-case must additionally retain the
common-deletion data in (24).

For finite orientation, the complete order-(18) and order-(22) planar
brace lists used in the existing first-order splice test, together with
the fixed all-CEN braces of orders (44) and (48), give 3696 directed
cap-face objects.  Every one satisfies (6).  This is bounded evidence only;
it is neither a classification through order (48) nor a proof of the
cardinality criterion.

The incidence countermodel is checked by

```text
uv run --python 3.12 \
  units/barnette/scratch/worker-c4-hpm/verify_single_cap_child_off_face_p_state.py
```

with terminal marker

```text
SINGLE_CAP_CHILD_OFF_FACE_P_STATE_VERIFIED
```

The real two-source dual-tree obstruction is checked by

```text
uv run --python 3.12 --with networkx \
  units/barnette/scratch/worker-c4-hpm/verify_dual_cap_face_load_exchange_boundary.py
```

with terminal marker

```text
DUAL_CAP_FACE_LOAD_EXCHANGE_BOUNDARY_VERIFIED
```

## Remaining boundary

Global (H^{+-}) supplies full perfect matchings whose complements are
Hamilton cycles, while brace extendability supplies all near-matching
families (12) and (15).  The exact missing arrow is to transfer the
connected complement through their common alternating-exchange incidence
so as to obtain

- dual spanning trees in at least two of the three four-defect families
  (12), or
- dual spanning two-forests with both planar tail labels in (15).

Unconditional cycle coalescence would be far stronger than what has been
proved and cannot be assumed.  The cardinality statement (6) remains a
candidate brace-level flexibility theorem; no actual brace counterexample
is known here.  Even if established, it closes only the cross traversal at
a tight splice and does not by itself prove full global-(H^{+-})
preservation under (C_4)-expansion.
