> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Local-star extremality does not force a gate sibling

[Notes 140--142](140-short-gap-extreme-families-reduce-to-complete-family-gate-path-sibling-selection.md)
leave a complete-family selection problem: when every parent bond is an
\(h\)-avoiding \(11\)--\(00\) bond, must some gate-path sibling or another
child matching supply a new-cell bond?  The universal hypothesis cannot be
localized to the incident star of one state-\(11\) endpoint.  A genuine
legal-wide Barnette fibre has a nonempty all-bad local star whose unique
gate-path sibling is nonrooted.

[Note 145](145-legal-wide-is-essential-for-short-gap-complete-family-compensation.md)
later refutes the complete-family implication after legal-wide is removed.
The local-star counterexample here remains inside legal-wide and therefore
continues to rule out localization within the surviving statement.

## 1. The local-star strengthening

Fix a state-\(11\) rooted parent target \(M\).  Its incident star consists
of every parent bond with endpoint \(M\).  Exclude a zero-degree target and
call the star **locally extreme** when every incident bond is an
\(h\)-avoiding \(11\)--\(00\) bond.  The proposed strengthening was

\[
 \text{the star at }M\text{ is locally extreme}
 \Longrightarrow
 \text{some incident bond has a rooted gate-path sibling}.
\tag{1}
\]

If true, (1) would prove the complete-family statement by choosing any
state-\(11\) endpoint in its nonempty extreme bond graph.  The implication
is false.

## 2. A real counterexample

Use the order-26 graph

~~~text
Y?????????????w?B_?F??FAOACCC?Oo?D_?W@??I_?H@??CG_?G`???
~~~

with root \(2\!-21\), forced gate \(1\!-13\), surviving gate
\(3\!-14\), and site

\[
 p=7\!-22,qquad q=6\!-15,qquad h=7\!-15.
\tag{2}
\]

The fixed state-\(11\) centre is

\[
\begin{aligned}
M=\{&0\!-18,1\!-13,2\!-21,3\!-24,4\!-23,5\!-14,6\!-15,\\
    &7\!-22,8\!-20,9\!-16,10\!-19,11\!-25,12\!-17\}.
\end{aligned}
\tag{3}
\]

It has exactly one incident parent bond.  Its state-\(00\) endpoint is

\[
\begin{aligned}
N=\{&0\!-17,1\!-13,2\!-21,3\!-14,4\!-23,5\!-22,6\!-18,\\
    &7\!-20,8\!-15,9\!-16,10\!-19,11\!-25,12\!-24\}.
\end{aligned}
\tag{4}
\]

The matching \(N\) omits \(h\), so the degree-one star is locally
extreme.  Its forced gate-path sibling lies in \(X_{uy}\), but its child
complement has the three components

\[
\begin{gathered}
\{1,10,11,16,21,23\},\\
\{7,15,26,27,28,29\},\\
\{0,2,3,4,5,6,8,9,12,13,14,17,18,19,20,22,24,25\}.
\end{gathered}
\tag{5}
\]

Thus the sibling is not rooted and (1) fails in the intended graph class.

The complete parent family is not extreme.  Its full bond profile is

\[
 (11\text{--}10)^4,qquad (11\text{--}01)^2,qquad
 (11\text{--}00,h\in N)^4,qquad
 (11\text{--}00,h\notin N)^1.
\tag{6}
\]

Its child has eleven new-cell bonds.  Hence the example refutes only the
local-star selection principle, not ChildSupplement or the complete-family
statement of Note 140.

## 3. Frozen classification and exact boundary

Inside the already frozen 262 one-edge-gap ParentKill records through order
26 there are 674 nonempty state-\(11\) incident stars.  Exactly six stars,
in five records, are locally extreme.  All six have order 26 and degree one,
with outcomes

\[
\begin{array}{c|c}
\text{outcome}&\text{number of stars}\\ \hline
\text{at least one rooted gate sibling}&2\\
\text{no rooted gate sibling}&4.
\end{array}
\tag{7}
\]

The two successful stars are exactly the two bond stars of the unique
complete-family-extreme record in Note 140.  The four failures lie in four
non-extreme complete families.  Thus complete-family extremality is
strictly stronger than local-star extremality in this real frozen scope,
and its universal quantifier carries mathematical content.

The finite data do not decide whether a locally extreme star of degree at
least two forces a rooted sibling; none occurs in the frozen universe.
More importantly, they neither prove nor refute the legal-wide
complete-family implication. Any successful argument must couple different
state-\(11\) stars or use unrelated child matchings together with the
legal-wide face geometry; a pointwise bond argument and a single incident
star are both insufficient.

The fixed counterexample and finite counts are verified by the
[short-gap local-star extremality bundle](../computations/bundles/short-gap-local-star-extremality-counterexample/README.md).
