> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The residual forty-vertex core has no internal marked path

[Note 448](448-crossed-face-chords-absorb-an-arbitrary-right-word.md) absorbs the thirty-six vertices outside the final row-IV/V short-leaf core. Its simplest consequence would replace the core's outer ordinary chord by that absorption path. This note proves that the required internal core path does not exist. The obstruction is local and does not decide the Hamiltonicity of the complete parent or child.

Keep the forty-vertex core
\[
E=F(U_2,S_3),\qquad D=F(E,U_4),\qquad
C=F(U_1,D),\qquad S_3=(L_3,x_3,y_3,R_3),
\tag{1}
\]
where \(U_1,U_2,U_4\) and all three branches are full. Inside \(C\), allow every old-cycle edge, every ordinary matching chord, and the row-IV face chord \(y_3x_4\). The face chords \(x_3y_7,y_4x_7\) leave \(C\) and are not edges of this internal graph.

**Internal-path obstruction.** This graph on \(C\) has no spanning \(y_1\)--\(x_2\) path, whether or not the path is required to use the outer chord \(C_\ell C_r\).

**Proof.** Suppose such a path \(P\) exists. The full leaf \(U_1\) contains the endpoint \(y_1\) and has only two available edges to the rest of \(C\), at \(L_1\) and \(R_1\). Hence exactly one is used. A spanning path through the six vertices of \(U_1\) from \(y_1\) to \(R_1\) is impossible: these two vertices have the same bipartite colour, whereas a spanning path of an even-order bipartite graph has opposite-colour endpoints. Thus \(P\) exits \(U_1\) at \(L_1\), and its old edge \(R_1D_\ell\) is absent.

The only edges of \(C\) crossing the boundary of \(D\) are \(R_1D_\ell\) and \(D_r\rho_2^C\); the face edge \(y_3x_4\) lies inside \(D\). Since \(x_2\) is an endpoint of \(P\) inside \(D\), exactly one boundary edge is used, namely \(D_r\rho_2^C\). Restricting \(P\) to \(D\) therefore gives a spanning \(D_r\)--\(x_2\) path \(Q\).

Consider the full leaf \(U_4\) in \(D\). Its only edges to \(D\setminus U_4\) are \(E_rL_4\), \(R_4\rho_2^D\), and \(y_3x_4\). Neither endpoint of \(Q\) lies in \(U_4\), so exactly two of these three edges are used. If \(y_3x_4\) is used, the second crossing cannot be \(E_rL_4\): that would require a spanning \(x_4\)--\(L_4\) path of the six-vertex bipartite leaf, whose endpoints have the same colour. Thus \(R_4\rho_2^D\) is used and \(E_rL_4\) is absent. The word \(E\) contains the endpoint \(x_2\), so its boundary is crossed an odd number of times. Its only remaining possible boundary edges are \(y_3x_4\) and \(E_\ell\lambda_2^D\); hence the latter is absent. It follows that \(Q\) restricts to a spanning \(y_3\)--\(x_2\) path of \(E\). This is impossible: in the old-cycle order
\[
\lambda_0^E,\lambda_1^E,\lambda_2^E,
L_2,h_2,x_2,y_2,j_2,R_2,
L_3,x_3,y_3,R_3,
\rho_2^E,\rho_1^E,\rho_0^E,
\tag{2}
\]
the vertices \(x_2\) and \(y_3\) have the same colour, while \(|E|=16\) is even.

If \(y_3x_4\) is absent, both old boundary edges of \(U_4\) must be used. The word \(E\), again containing one endpoint of \(Q\), must use exactly one of its two old boundary edges. Since \(E_rL_4\) is used, \(E_\ell\lambda_2^D\) is absent. All six \(D\)-bracket vertices must then lie on the initial portion of \(Q\) from \(D_r=\rho_0^D\) to \(\rho_2^D\), before the path enters \(U_4\). But \(\rho_0^D\) and \(\rho_2^D\) have the same colour, so no spanning path on these six bipartite bracket vertices has those endpoints. This excludes the remaining case. \(\square\)

**Necessary outer-chord corollary.** In the residual word \(W=F(F(C,U_5),F(U_6,U_7))\), every spanning \(y_1\)--\(x_2\) path using edges of \(W\) must use at least one of the face chords \(x_3y_7,y_4x_7\). Indeed, without them the only edges crossing the boundary of \(C\) are its two old-cycle boundary edges. A spanning path with both endpoints in \(C\) and vertices outside \(C\) must use both. The outer chord \(C_\ell C_r\) cannot already lie on the path: together with the exterior segment it would form a separate cycle. Replacing that exterior \(C_\ell\)--\(C_r\) segment by \(C_\ell C_r\) would therefore give the prohibited internal core path. In particular, Note 448's replacement of that chord can never by itself produce a marked parent Hamilton cycle. [Note 450](450-the-fourth-and-fifth-face-matchings-are-hamiltonian-in-the-two-eligible-kernel.md) constructs a spanning route using \(x_3y_7\). This local obstruction does not assert that any Barnette graph is non-Hamiltonian.
