> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Opposite-edge expansion of a facial square preserves every fibre crossing

[Note 103](103-one-step-crossing-preservation-is-exactly-new-cell-supplementation.md)
identifies new-cell supplementation as the only obstruction to preserving a
cross-sector single-cycle edge through a \(C_4\)-expansion.  For opposite
edges of a facial square, [Note 104](104-a-facial-square-11-state-has-three-target-lifts-and-one-exceptional-crossing-profile.md)
constructs three target lifts of every state-\(11\) endpoint and leaves one
formal local profile, \(11\)--\(00_{\rm ext}\), outside its direct connector
argument.

That profile cannot occur in the fixed-pairing target fibre.  Its four
external matching edges isolate the facial square in the complement.  It
follows that every parent crossing, not merely the crossing graph as a
whole, survives the expansion.  No brace hypothesis is needed for this
local preservation theorem.

## 1. Setup

Let \(\mathcal L\) be the fixed-pairing spanning-two-path matching fibre of
Note 085.  Let

\[
p=uv,\qquad q=xy
\tag{1}
\]

be opposite edges of a facial square

\[
F=u-v-x-y-u,
\tag{2}
\]

disjoint from the deleted root square and the named gates.  Write

\[
r=vx,\qquad s=yu
\tag{3}
\]

for its other two sides.  Expand \(p,q\) by the patch of Notes 101--104,
and denote the complete child fibre by \(\mathcal L^+\).

For a gate-split fibre \(\mathcal F\), let \(\Gamma(\mathcal F)\) have one
edge \(MN\) whenever \(M,N\) lie in opposite gate sectors and
\(M\triangle N\) is one alternating cycle.

## 2. The four-external state is absent

**Lemma.**  No member of \(\mathcal L\) has local form
\(00_{\rm ext}\) at \(F\).

**Proof.**  Such a perfect matching would use the third edge leaving \(F\)
at each of \(u,v,x,y\), and none of \(p,q,r,s\).  Hence all four sides of
\(F\) lie in its complement.  At every vertex of \(F\), the two complement
edges are precisely the two incident sides of \(F\), so \(F\) is a closed
\(C_4\) component of the complement.  This contradicts the definition of
\(\mathcal L\), whose complement is exactly the two prescribed spanning
terminal paths and has no closed component.

If a vertex of \(F\) is a boundary terminal created by root-square
deletion, its third edge is absent from the residual graph, so the same
local matching form is unavailable even before the complement condition is
tested.  \(\square\)

This is the parent analogue of the empty canonical child cell \(C_{11}\)
in Note 103: in both cases four unused square edges become an isolated
complement cycle.

## 3. Crossing preservation

**Theorem.**  Every edge of \(\Gamma(\mathcal L)\) gives an edge of
\(\Gamma(\mathcal L^+)\).  In particular,

\[
\boxed{
\Gamma(\mathcal L)\ne\varnothing
\Longrightarrow
\Gamma(\mathcal L^+)\ne\varnothing.}
\tag{4}
\]

**Proof.**  Let \(MN\) be an edge of \(\Gamma(\mathcal L)\).  If neither
endpoint has state \(11\) at \(p,q\), their canonical child lifts exist.
By Note 103, equation (8), these lifts preserve the gate bits and every
symmetric-difference component.  They therefore form a child crossing
edge.

Suppose that one endpoint, say \(M\), has state \(11\).  Note 104 constructs
three child targets \(M^R,M^U,M^V\), one in each of
\(R_{00},X_{uy},X_{vx}\), with the same gate bit as \(M\).  The other
endpoint \(N\) has one of the local forms in the connector table of Note
104.  The form \(00_{rs}\) cannot occur on a cross-sector single-cycle
edge: then \(M\triangle N\) is exactly the facial square, which avoids the
surviving gate.  The form \(00_{\rm ext}\) is excluded by the lemma.

For every remaining possibility

\[
11,\qquad10,\qquad01,\qquad00_r,\qquad00_s,
\tag{5}
\]

the connector table contains an entry equal to one.  The corresponding
face-assisted lift of \(M\) and indicated lift of \(N\) remain in opposite
gate sectors and differ by one alternating cycle.  They form the required
edge of \(\Gamma(\mathcal L^+)\).  \(\square\)

## 4. Scope

The theorem applies to an interface-disjoint expansion whose selected
edges are opposite sides of a facial square.  Planarity is used only to
name that square; the proof does not invoke \(2\)-extendability or assume
that the child is a brace.  Those hypotheses remain relevant when the
local statement is inserted into a legal-wide Barnette construction.

The conclusion does not settle a general facial expansion in which the two
selected edges do not bound the same \(4\)-face.  In that case the three
new cells of Note 103 need not contain target lifts, and the general
new-cell supplementation problem remains open.
[Note 106](106-cofacial-words-determine-direct-matchings-but-not-target-admission.md)
gives the exact direct-lift criterion for a longer common face and proves
that its face-edge word must be augmented by the exterior two-path
connection signature.
