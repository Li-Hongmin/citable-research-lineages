> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two balanced remote classes joined through a rootless path are safe

[Note 036](036-three-balanced-remote-root-classes-have-a-low-weight-perfect-matching-state.md)
uses nested shores to couple balanced remote root classes, and
[Note 037](037-three-annular-root-classes-do-not-obstruct-single-layer-fec-support.md)
adds every retained rung whose endpoints remain on the common-neighbour
annulus.  This note treats a different incidence: two balanced remote
classes are joined by a two-edge path whose middle vertex has no root
incidence.  The path is forced into the deletion-free strip between the
two remote classes.  The resulting two four-cuts have even shores, which
supplies the required low-cost perfect matching.

Use the setting of Notes 035--037.  Thus \(F\) is a plane cubic bipartite
brace, \(p=uv\) and \(h=za\) are an ordered legal cofacial site,

\[
 K=F-\{u,a\},
 \qquad
 P_c=c_p-c-c_h
\]

in the plane dual \(F^*\), and \(K\) is 1-extendable.  Let \(s,t,q\) be
three nonroot dual vertices with

\[
 A(s)=A(q)=\{c_p,c_h\},qquad A(t)=\varnothing,qquad
 E(F^*[\{s,t,q\}])=\{st,tq\}.                 \tag{1}
\]

Write

\[
 D_s=\{e_s^p,e_s^h\},qquad
 D_q=\{e_q^p,e_q^h\}
\]

for the retained primal labels of the two remote classes, and let
\(g_1,g_2\) be the labels dual to \(st,tq\).  Assume that both remote
classes are balanced: every perfect matching uses either zero or both
members of each pair, and both states occur.  For a perfect matching
\(M\), put

\[
 \sigma_s(M)=\frac{|M\cap D_s|}{2},qquad
 \sigma_q(M)=\frac{|M\cap D_q|}{2}.
\]

> **Rootless-path transfer theorem.**  There is a perfect matching
> \(M\) of \(K\) such that
> \[
>  2\sigma_s(M)+\mathbf 1_{g_1\in M}+\mathbf 1_{g_2\in M}
>  +2\sigma_q(M)\le 3.                         \tag{2}
> \]

## The strip between the remote classes contains no deleted vertex

Put

\[
 P_s=c_p-s-c_h,qquad P_q=c_p-q-c_h.
\]

For \(i\in\{s,q\}\), the simple dual four-cycle \(P_c\cup P_i\)
corresponds to the primal four-bond

\[
 \{p,h\}\mathbin{\dot\cup}D_i.
\]

Balanced parity forces \(u,a\) onto the same shore of each bond.  Choose
in each case the shore containing both deleted vertices.  The annular
ordering argument of Note 036 makes these two shores nested.  Their
set-theoretic difference is the primal region dual to one of the two
closed discs bounded by

\[
 C_{sq}=c_p-s-c_h-q-c_p.                       \tag{3}
\]

Call this disc \(R\).  It is precisely the strip between \(P_s\) and
\(P_q\) which contains neither \(u\) nor \(a\); the complementary disc
contains \(P_c\) and both deleted vertices.  This statement also covers
the case in which \(P_s,P_q\) occur on opposite sides of \(P_c\): the
nested-shore difference selects the deletion-free one of the two strips.

## Alternating endpoints force the joining path into that strip

The path

\[
 P_t=s-t-q
\]

is internally disjoint from \(P_c\) and from the boundary of (3).  If
its interior lay in the complementary disc, then that disc would contain
two proper arcs

\[
 P_c:c_p\longrightarrow c_h,qquad
 P_t:s\longrightarrow q.
\]

Their four endpoints occur on (3) in the alternating cyclic order

\[
 c_p, s, c_h, q.
\]

Two proper arcs with alternating boundary endpoints in a disc must
intersect.  Here their vertex sets are disjoint and plane edges cannot
cross, a contradiction.  Hence \(P_t\subset R\).

The path \(P_t\) divides \(R\) into the two discs bounded by

\[
 C_p=c_p-s-t-q-c_p,qquad
 C_h=c_h-s-t-q-c_h.                            \tag{4}
\]

Neither disc contains \(u\) or \(a\).

## The two residual cuts are even

The cycles in (4) correspond in \(F\) to the four-edge cuts

\[
 S_p=\{e_s^p,g_1,g_2,e_q^p\},qquad
 S_h=\{e_s^h,g_1,g_2,e_q^h\}.                 \tag{5}
\]

Every shore of a four-edge cut in a cubic graph has even order.  For
each cut in (5), the shore inside \(R\) loses no vertex on passing from
\(F\) to \(K\), while its complementary shore loses both \(u,a\).
Thus both shores remain even in \(K\).  Perfect-matching cut parity gives

\[
 \sigma_s(M)+\mathbf 1_{g_1\in M}+\mathbf 1_{g_2\in M}
 +\sigma_q(M)\equiv0\pmod2                    \tag{6}
\]

for every perfect matching \(M\).  Either cut in (5) gives (6), because
the indicator of either member of a balanced pair equals its pair state.

Take a zero-state witness for \(D_s\), whose existence is part of the
balanced hypothesis.  If \(\sigma_q=0\), equation (6) makes the number
of selected path labels \(g_1,g_2\) equal to zero or two, so the cost in
(2) is at most two.  If \(\sigma_q=1\), exactly one of \(g_1,g_2\) is
selected, and the cost is three.  This proves the theorem.

## Consequence and scope

The common-odd projected state obstruction for (1) is not plane
realizable: it places the joining path in the disc containing \(P_c\),
where alternating endpoints force an intersection.  No
alternating-cycle exchange or additional extendability is required once
the deletion-free strip is identified.

The theorem is confined to the two balanced remote endpoint classes in
(1).  It closes the balanced--rootless--balanced profile left at the end
of the present four-vertex reduction chain, but it does not by itself
assert that every other rooted four-vertex profile has been exhausted.
