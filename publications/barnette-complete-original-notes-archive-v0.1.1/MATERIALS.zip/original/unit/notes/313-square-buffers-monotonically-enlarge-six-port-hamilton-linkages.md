> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Square buffers monotonically enlarge six-port Hamilton linkages

[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
shows that even four-terminal ladders have exactly the square's
spanning one- and two-path signature. A target-free vacant block
has six external terminals, and a neighboring short block behaves
differently: adding it preserves every existing spanning path
pairing but can create new ones.

Let \(V\) be the six-cycle with cyclic order
\[
                         a,o,H,I,e,b,a,                 \tag{1}
\]
all six vertices being labeled terminals. A *spanning linkage* is a
collection of vertex-disjoint paths, each with at least one edge,
whose union covers all gadget vertices and whose endpoints are
terminals. Its signature records the endpoint pairs; a terminal
not used as an endpoint has degree two inside the linkage.

To add one *left square buffer*, take a fresh square
\(A,O,E,B,A\), add the two edges \(Ba,Eo\), and move the left
terminal labels \(a,o\) to \(A,O\), respectively. All other
terminal labels stay in place. The old vertices \(a,o\) become
internal. Repeat this operation any number of times; right buffers
are defined by reflecting the order (1).

**Six-port buffer theorem.** Every spanning-linkage signature of
\(V\) is realized after adding any finite number of left and right
square buffers, with the same six labeled terminal pairs. The same
holds for any gadget obtained after earlier buffers. Consequently,
in any exterior graph attached by one labeled edge at each of the
six terminals, every Hamilton cycle before buffering lifts to a
Hamilton cycle after buffering with exactly the same exterior edges.
The converse signature inclusion fails already for one left buffer.

**Proof of the lifting direction.** Consider one left addition to a
gadget whose left boundary terminals are \(a,o\). They are adjacent,
and each has exactly two internal incident edges before addition.
Let \(L\) be a spanning linkage.

If both \(a,o\) are endpoints of \(L\), use the disjoint square
paths \(A,B\) and \(O,E\), followed by the new edges \(Ba,Eo\).
They extend the two old paths to the new terminals \(A,O\).
If only \(a\) is an endpoint, prepend the square Hamilton path
\(A,O,E,B,a\), where the last edge is \(Ba\); the unused edge
\(Eo\) is omitted. If only \(o\) is an endpoint, prepend
\(O,A,B,E,o\), omitting \(Ba\). These substitutions cover the
new square once and leave every old interior edge and every
endpoint pairing unchanged.

If neither \(a\) nor \(o\) is an endpoint, each has degree two
in \(L\), so their common edge \(ao\) is forced. Replace that edge
by the path
\[
                    a,B,A,O,E,o.                         \tag{2}
\]
It covers the new square once, and the same old path remains
connected. These four cases exhaust the uses of the two left
terminals. Reflection proves the right-buffer step, and induction
proves the theorem for any sequence of buffers.

For the Hamilton-cycle assertion, restrict a cycle to the old
gadget. Since the exterior is nonempty and the six gadget vertices
are covered, the restriction is a spanning linkage with two, four,
or six of the labeled attachment edges used. Lifting its local
linkage preserves each exterior attachment and the pairing of its
ends, so the unchanged exterior portions still form one cycle.

**Strictness.** With one left square \(A,O,E,B\), the three paths
\[
               A-O,\qquad I-e,\qquad H-o-E-B-a-b             \tag{3}
\]
are disjoint and cover all ten vertices. Their endpoint pairs are
\((A,O),(I,e),(H,b)\). The corresponding signature in \(V\)
would pair \((a,o),(I,e),(H,b)\). Three paths covering its six
vertices would each have to be one edge, but \(H\) and \(b\)
are nonadjacent in (1). Hence the buffered six-pole has a strictly
larger spanning-linkage signature. \(\square\)

**Barnette-preserving buffering.** Suppose the six-cycle (1) is an
induced subgraph of a simple cubic bipartite plane three-connected
graph, with one exterior edge at each vertex. Assume the exterior
edges at \(a,o\) are incident with the same face on one side of
\(ao\). Replacing them by the left buffer and its six labeled
attachments gives another simple cubic bipartite plane
three-connected graph. The reflected statement holds on the right.

To verify planarity, draw the square in a narrow part of that face
along \(ao\), and reroute the two exterior edges to \(A,O\).
The bridge edges \(Ba,Eo\) fit in the same strip. The square's
bipartition assigns \(A,E\) the old colour of \(a\) and \(O,B\)
the old colour of \(o\), so every new edge is bichromatic.
Cubicity and simplicity are immediate from the four distinct
attachment incidences.

For connectivity, suppose the new graph has an edge cut of size at
most two. If all four square vertices lie on one shore, keep the
shores of all old vertices. Each original attachment edge
\(aa^*\) or \(oo^*\) that crosses the induced old cut is
witnessed by one of its two replacement edges; all other old edges
are unchanged. A cut separating only the square from all old vertices
would have four attachment edges, so the induced old cut is
nontrivial and has no more cut edges, contrary to
three-edge-connectivity. If the square is split, its
four-cycle contributes at least two cut edges. Therefore it
contributes exactly two and every other edge is uncut. The retained
edge \(ao\) puts old \(a,o\) on the same shore; the bridge edges
put \(B,E\) on that shore. Since the square is split, at least one
of \(A,O\) lies on the other shore. Its exterior neighbor lies
there too. In the old graph, at least one and at most two of
\(aa^*,oo^*\) cross, while every other edge is uncut, again a
forbidden cut. Thus the buffered graph is three-edge-connected;
the cubic lemma of Note 182 makes it three-vertex-connected.

**Reverse-cut criterion and elimination.** Suppose a Barnette graph \(G_1\) is obtained
by left buffering, and removing that buffer with the prescribed
reattachment gives a simple cubic bipartite plane graph \(G_0\)
whose old Hamilton cycle is the shortened one. Then \(G_0\) is
Barnette if and only if it has no matching-closed proper consecutive
old-cycle interval whose two boundary cycle edges include \(ao\).

Indeed, a Hamiltonian graph has no bridge. If \(G_0\) has a
two-edge cut that does not separate \(a,o\), put all four square
vertices of \(G_1\) on their common shore. Each of the two
reattached edges crosses exactly when its corresponding exterior
edge in \(G_1\) crosses; no square edge crosses. This lifts the
two-edge cut unchanged, contradicting three-edge-connectivity of
\(G_1\). Hence every two-edge cut of \(G_0\) separates \(a,o\)
and contains their edge \(ao\). A Hamilton cycle crosses any
nontrivial cut evenly; in a two-edge cut both edges must therefore
belong to that cycle. Its shore is a proper consecutive cycle
interval, and the absence of a matching edge across the cut says
precisely that the interval is matching-closed. Conversely such an
interval supplies a two-edge cut. The cubic lemma of Note 182
then gives the claimed three-vertex-connectivity criterion.

For the induced six-cycle (1), this possible cut is in fact
excluded. The shore of a hypothetical two-edge cut containing
\(o\) but not \(a\) is a consecutive arc of the old Hamilton
cycle beginning at \(o\) and ending before it reaches \(a\)
again. If it extends through \(b\), the
cycle's face chord \(ab\) crosses the cut, a third edge.
Otherwise the shore is a nonempty subset of
\(\{o,H,I,e\}\). Every one of those vertices has its third
edge outside the six-cycle, hence outside that short arc, again
adding a third cut edge. Reflection gives the same conclusion
for the right edge \(eb\). Thus any alias-free unbuffering
that yields the stated simple plane cubic bipartite graph is
automatically Barnette; no separate cut test is needed.

**Buffered consecutive-port corollary.** Let a Barnette parent satisfy
Note 300's compact, gapless, tight-target all-square opening and have
exactly two consecutive missing links \(P_s,P_{s+1}\) in one free
group, with their shared block \(B_{s+1}\) vacant and the group's
ordinary end links retained. Insert \(d_L,d_R\ge0\) left and right
buffers at this block. In the two-page embedding, the moved ordinary
matching endpoints are on the side opposite the site face. The new
face chords occupy separate blocks on the common-face side, while
each new retained link is nested within or disjoint from the old
opposite-side chords. Hence the buffered graph retains the stated
opening and cofacial site edges. The preceding connectivity theorem
keeps it Barnette, and the six-port lifting theorem transfers all
three \(S,K,X\) routes from Note 300. Its missing links are now
\(P_s,P_{s+1+d_L+d_R}\), with the central vacancy in
\(B_{s+1+d_L}\). If the other free groups have their ordinary
routes, the parent has the marked Hamilton cycle and its legal
site-expanded child is Hamiltonian. This applies for arbitrary
vacancy components and matching allowed by Note 300, provided the
buffered graph is constructed as stated.

**A two-parameter one-vacancy, separated-port family.** Start with
the 44-vertex Barnette parent of Note 300(6), whose only missing
links in the relevant free group are \(P_4,P_5\) and whose shared
block \(B_5\) is vacant. In its two-page drawing, both the left
attachment pair at \(a_5,o_5\) and the reflected right pair at
\(e_5,b_5\) border faces opposite the site face. Insert
\(d_L\ge0\) left buffers and \(d_R\ge0\) right buffers, with
\(d_L+d_R\ge1\).
Each new attachment pair has the same facial placement, so the
Barnette-preserving construction iterates.

Draw every new short block's face chord on Note 281's common-face
side of the old Hamilton cycle. On the opposite side, a left
buffer moves \(H_3o_5\) to the new outermost \(H_3O\), still
enclosing \(I_3e_4\) and lying inside \(I_2H_5\); a right buffer
moves \(I_1e_5\) to the new outermost \(I_1E\), still inside
\(H_1o_6\). Each bridge from a buffer to the vacant block becomes
a retained consecutive ordinary link inside the corresponding
outer chord. Thus the opposite-side matching remains noncrossing,
and the site edges stay cofacial.

The two missing links become \(P_4,P_{5+d_L+d_R}\), while the sole
corridor vacancy is \(B_{5+d_L}\). There are \(d_L\) short blocks
before it and \(d_R\) after it. The parent and legal child have
respectively \(44+4(d_L+d_R)\) and \(48+4(d_L+d_R)\) vertices. Note
300's three group routes and its marked Hamilton cycle lift through
all buffers; Note 001 lifts the parent cycle through the unchanged
legal site expansion. This realizes the vacancy at either end or at
any interior position of an arbitrarily long two-port corridor.

In the block language of Note 312, one left square is one short
block immediately before a vacant block, with the retained ordinary
link \(Eo\). Thus short-block buffering can safely lift a known
route, while deleting that short block is not an exact six-port
reduction. The planar insertion above uses the stated facial
attachment condition.
