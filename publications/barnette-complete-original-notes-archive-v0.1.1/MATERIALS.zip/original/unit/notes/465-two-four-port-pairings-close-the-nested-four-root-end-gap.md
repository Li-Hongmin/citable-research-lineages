> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two four-port pairings close the nested four-root end gap

[Note 464](464-end-gap-four-root-failures-must-have-the-nested-middle-pair.md) reduces the four-root all-leaf chord-free profile to one allocation: with the left end gap empty, \(W_2,W_3\) form the unmarked face-matching component and \(W_1,W_4\) the marked component. The middle component has two spanning four-port pairings. Any spanning two-path cover of the marked component plus the four exterior vertices closes with one of them.

Use the order
\[
 w_0,W_1,t_d,W_2,t_c,W_3,t_b,W_4,t_a,w_*,
       \alpha,a,b,c,d,\beta,w_0
\tag{1}
\]
and the chord-free hexagon edges of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md). Every assigned special position lies in a two-special leaf. The root face graph has exactly the two connected components \(U=\{W_2,W_3\}\) and \(V=\{W_1,W_4\}\), with both site ports \(u,v\) in \(V\). The right end-gap case is the reflection.

**Nested-pair theorem.** The parent has a Hamilton cycle containing both site edges \(q=w_0u,p=vw_*\). Therefore its legal \(C_4\)-expanded child is Hamiltonian.

**Proof.** Regard the vertices of \(W_2,W_3,t_d,t_c,c,d\) as an internal four-pole \(X\). Its four edges to the rest of the parent are
\[
 t_dW_{1,r},\qquad W_{3,r}t_b,\qquad d\beta,\qquad cb.
\tag{2}
\]
Label their endpoints inside \(X\) by \(A=t_d,B=W_{3,r},C=d,D=c\), respectively. We give two vertex-disjoint spanning two-path covers of \(X\):

* The old-edge paths
  \[
  A,W_{2,\ell}\xrightarrow{\rm old}W_{2,r},t_c,
       W_{3,\ell}\xrightarrow{\rm old}B,
       \qquad C,D
  \tag{3}
  \]
  have pairing \((A,B)(C,D)\). Here \(C,D\) are joined by the old hexagon edge \(dc\).
* The escape edge \(A C=t_dd\) is one path. For the other, start with
  \(D,t_c,W_{3,\ell}\xrightarrow{\rm old}B\) and the disjoint root cycle on \(W_2\), formed by its old arc and outer ordinary chord. Match all leaf special positions in \(W_2,W_3\) by their internal face chords \(M_U\), and delete the leaf old edges \(E_U\). The resulting graph has degree one only at \(D,B\), and its component quotient by \(E_U\) is connected: \(W_2,W_3\) are linked by \(M_U\). Square switches along a spanning tree absorb every cycle into a spanning \(D\)--\(B\) path. Thus this second cover has pairing \((A,C)(D,B)\). A leaf whose square chord already closes a singleton \(W_2\) root contributes only a quotient loop and is not switched, as in [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md).

Now let \(Y\) contain every remaining vertex: \(W_1,W_4,t_b,t_a,a,b,w_0,w_*,\alpha,\beta\). Its four boundary vertices corresponding to (2) are \(W_{1,r},t_b,\beta,b\). Let \(C_1\) be the old \(W_1\)-arc closed by its root chord \(W_{1,\ell}W_{1,r}\), and \(C_4\) the cycle
\[
       (t_b,W_{4,\ell}\xrightarrow{\rm old}W_{4,r},t_a,a,b,t_b).
\]
Let \(E_V\) be their square-supported leaf old edges and \(M_V\) the face matching of their non-site leaf positions. Form
\[
\begin{split}
 F_Y={}&(C_1\cup C_4-E_V-
             \{W_{1,\ell}W_{1,r},t_bb\})\cup M_V\\
     &\cup\{uw_0,w_0W_{1,\ell},vw_*,w_*\alpha,\alpha\beta\}.
\end{split}
\tag{4}
\]
Every vertex of \(Y\) has degree two in \(F_Y\), except \(W_{1,r},t_b,\beta,b\), which have degree one. Both site edges occur in (4). After adding the deleted leaf edges \(E_V\), (4) is connected: the opened \(W_1\) and \(W_4\) arcs are joined by \(M_V\), since the marked root component \(V\) is connected, and the exterior vertices attach through \(u,v\). Therefore the component quotient of \(F_Y\) by \(E_V\) is connected. All its nonloop edges have leaf-square switches; the deleted \(W_1\) root chord is available as a square chord if \(W_1\) is a singleton leaf. A spanning tree, cut at one edge between the two path components, lets those switches absorb every cycle into a spanning two-path cover of \(Y\) with these four boundary terminals. Its pairing \(\pi_Y\) is one of the three pairings of four points.

Connect the two covers of \(X\) and \(Y\) across all four edges (2). Choose the cover of \(X\) whose pairing differs from \(\pi_Y\); (3) and the second construction provide two distinct choices. The union of two different pairings on four boundary ports is one four-cycle, so the resulting degree-two spanning subgraph is a single Hamilton cycle. It contains \(q,p\), which lie in \(F_Y\) and are untouched by the switches. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the child. \(\square\)

## Improved chord-free kernel

Combining this theorem with the other four-root placements in [Notes 463–464](464-end-gap-four-root-failures-must-have-the-nested-middle-pair.md) closes the entire four-root all-leaf profile, with no bound on the number of leaves or their ordinary wrappers. The refined charge cases of [Note 462](462-three-root-split-unary-splice-and-sharper-single-hexagon-kernel.md) then give, for every \(f\ge7\),
\[
 \boxed{\ G^+\text{ non-Hamiltonian and }e=4
       \Longrightarrow c\le5f-8,\qquad
       |V(\bar G^+)|=18+2f+2c\le12f+2\ }.
\tag{5}
\]
At \(f=8\), a chord-free reduced failure kernel has at most 98 vertices. The chorded branch retains [Note 460](460-two-exterior-pairings-close-the-chorded-single-unary-defect.md)'s 100-vertex bound, so the unified selected single-hexagon bound is still 100. Neither branch's remaining kernels nor Barnette's conjecture are decided by (5).
