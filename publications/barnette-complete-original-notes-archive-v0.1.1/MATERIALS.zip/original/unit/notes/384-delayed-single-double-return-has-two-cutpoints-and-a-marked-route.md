> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The delayed h-to-short return has two cutpoints and a marked Hamilton route

[Note 382](382-isolated-single-double-corridors-couple-j0-and-j2-at-every-length.md)
forces \(tJ,oK,Ez\), excludes \(oe\), and leaves
\(hI\) or \(hp_s\) (\(s\ge2\)) when the double
block has no internal free matching chord.
[Note 383](383-the-hi-return-single-double-corridor-is-an-exact-square-reduction.md)
closes the \(hI\) branch by an exact square reduction.
Here the delayed \(hp_s\) branch has a two-cutpoint
matching word and a spanning marked Hamilton route.

Use the compressed, gapless, tight-target all-square
selected opening and the old-cycle block order
\[
 V=(a,o,h,i,e,b),\quad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\quad
 D=(A,O,H,I,K,J,E,B).                                      \tag{1}
\]
The ordinary target-free free group contains exactly
these blocks, has no short flanks, and has even left
and odd right endports \(t,z\). Other groups may occur.
Let \(M\) complement the old Hamilton cycle and
assume \(D\) has no internal free matching chord,
\(tJ,hp_s\in M\).

For integers
\[
                    2\le s\le r\le m-1,                   \tag{2}
\]
define
\[
\begin{split}
 M_{m;s,r}^{\circ}
 =\{&oK,hp_s,iq_{s-1},ep_1,q_rI,p_{r+1}H,q_mO\}\\
 &{}\cup\{q_jp_{j+1}:1\le j<m,\ j\notin\{s-1,r\}\}.
\end{split}                                                 \tag{3}
\]

**Two-cutpoint return theorem.** Every actual matching
under the hypotheses above is precisely
\[
                    \{tJ,Ez\}\cup M_{m;s,r}^{\circ}
\tag{4}
\]
for a unique pair (2). Thus the branch is empty for
\(m=1,2\) and has exactly
\((m-1)(m-2)/2\) matching words for \(m\ge3\).
Every word (4) occurs in a genuine Barnette parent
of order \(26+4m\). That parent has a Hamilton
cycle through both site edges and a legal
Hamiltonian site-expanded child.

More generally, the induced interval on the blocks
(1) has a spanning \(J\)--\(E\) path for every
word (4). Together with \(tJ,Ez\), it gives a
spanning \(t\)--\(z\) route. Consequently any
selected opening with this group and standard
composable routes in all other groups has a
Hamilton parent cycle through both site edges
by the group template of
[Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
The theorem asserts this route and its genuine
realizations; it does not claim a complete
four-terminal square signature for the pole.

**Forced matching.** Note 382 gives
\(tJ,oK,Ez\in M\) and \(oe\notin M\).
All remaining free matching chords join
different blocks and lie opposite the common
face by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
They cannot interlace. A nonempty proper run
of complete short blocks matched entirely
within itself would have exactly two boundary
old-cycle edges, violating three-connectivity.

The chord \(hp_s\) encloses
\(i,e,p_1,q_1,\ldots,p_{s-1},q_{s-1}\).
The slot \(i\) can meet only \(q_k\) for
\(k<s\). If \(k<s-1\), the intervening
complete short-block run is matching-closed;
hence \(iq_{s-1}\) is forced. Inside this
chord the leftmost slot \(e\) must meet
\(p_1\), for skipping a short block would
again close a proper run. Repeating forces
\[
 ep_1,\qquad q_jp_{j+1}\ (1\le j<s-1).                     \tag{5}
\]

On the other side of \(hp_s\) inside \(oK\),
the odd slot \(I\) must meet \(q_r\) with
\(r\ge s\): \(HI\) is an old-cycle edge,
while an edge to a slot inside \(hp_s\)
would interlace that chord. If \(r=m\),
the enclosed \(O,H\) would have to use
their old-cycle edge. Therefore \(r\le m-1\).
When \(r>s\), the interval between \(hp_s\)
and \(q_rI\) contains
\(q_s,p_{s+1},q_{s+1},\ldots,p_r\).
Its leftmost available slot \(q_s\) must meet
\(p_{s+1}\); otherwise a skipped proper
short-block run closes under the matching.
The same argument forces
\[
              q_jp_{j+1}\quad(s\le j<r).                  \tag{6}
\]
For \(r=s\), this interval and (6) are empty.
Inside \(q_rI\), the slot \(H\) must meet a
\(p_k\) with \(k>r\); \(OH\) is an old-cycle
edge. Skipping \(p_{r+1}\) would close
\(S_{r+1},\ldots,S_{k-1}\), so
\(p_{r+1}H\) is forced. The remaining
short slots between this chord and \(O\)
then force
\[
 q_jp_{j+1}\quad(r<j<m),\qquad q_mO.                       \tag{7}
\]
Equations (5)--(7) give (3), and \(hp_s,q_rI\)
recover the two parameters uniquely.
There are \(\sum_{s=2}^{m-1}(m-s)
=(m-1)(m-2)/2\) pairs (2).

**A spanning route.** For \(u\le v\), put
\[
 W_{u:v}=
 (p_u,c_u,d_u,q_u,\ p_{u+1},c_{u+1},d_{u+1},q_{u+1},
                 \ldots,p_v,c_v,d_v,q_v).
\tag{8}
\]
Every short-block segment follows two old-cycle
edges and its face chord; successive segments
join through \(q_jp_{j+1}\). The three paths
\(W_{1:s-1},W_{s:r},W_{r+1:m}\) all exist
under (3). Their vertex sets partition the
entire corridor. The sequence
\[
\begin{split}
 J,K,o,a,b,e,\ W_{1:s-1},\
 i,h,\ W_{s:r},\ I,H,\
 W_{r+1:m},\ O,A,B,E
\end{split}                                                 \tag{9}
\]
is a spanning \(J\)--\(E\) path of the
induced block interval. Its non-obvious
joins are exactly \(oK,ep_1,iq_{s-1},
hp_s,q_rI,p_{r+1}H,q_mO\). Every other join
is an old-cycle edge, a face chord, or one
of the surviving \(q_jp_{j+1}\).
Adding \(tJ,Ez\) yields the asserted
spanning \(t\)--\(z\) route.

**Genuine Barnette realizations.** For each
pair (2), give a graph its old Hamilton
cycle in the order
\[
 x,R_1,e_0,y,\ V,S_1,\ldots,S_m,D,\
 u,o_3,L_1,v,\alpha,\gamma,\delta,\beta,x.
\tag{10}
\]
Add the complementary perfect matching
\[
\begin{split}
 \{&xy,ab,c_jd_j\ (1\le j\le m),AB,uv,
 \alpha\beta,\\
 &\delta R_1,\gamma L_1,e_0J,Eo_3\}
 \ \cup M_{m;s,r}^{\circ}. 
\end{split}                                                 \tag{11}
\]
Every vertex occurs exactly once in (11),
and each matching edge joins opposite
old-cycle parities. The face-side chords
\(xy,ab,c_jd_j,AB,uv,\alpha\beta\) are
disjoint. On the other page,
\(\delta R_1\) encloses all other chords;
\(e_0J\) encloses the nested and disjoint
chords of (3), while \(Eo_3,\gamma L_1\)
lie to its right. Thus the graph is
simple, cubic, bipartite and plane, with
cofacial site edges \(xy,uv\).

Its matching-chord interlacement graph
is connected. Let \(F_0=ab\),
\(F_j=c_jd_j\) and \(F_D=AB\).
An internal matching chord joining
slots in two blocks interlaces the two
corresponding face chords. The incidence
connections are
\[
\begin{array}{c|c}
\text{bridge chord}&\text{face chords it interlaces}\\
oK&F_0,F_D\\
hp_s,\ iq_{s-1},\ ep_1&
 (F_0,F_s),\ (F_0,F_{s-1}),\ (F_0,F_1)\\
q_rI,\ p_{r+1}H,\ q_mO&
 (F_r,F_D),\ (F_{r+1},F_D),\ (F_m,F_D)\\
q_jp_{j+1}&F_j,F_{j+1}\quad(j\notin\{s-1,r\}).
\end{array}                                                 \tag{12}
\]
These connections join every \(F_j\) to
\(F_0,F_D\) and join all internal chords.
The exterior alternation chain
\[
 xy-e_0J-F_D-Eo_3-uv-\gamma L_1
       -\alpha\beta-\delta R_1
\tag{13}
\]
joins all remaining matching chords.
Every incidence in (12) and dash in (13)
is endpoint alternation in (10). A two-edge cut in
a cubic Hamiltonian graph would
isolate a proper old-cycle interval
closed under its complementary matching,
disconnecting that interlacement graph.
The Hamilton cycle also excludes bridges.
Hence the graph is three-edge-connected
and therefore three-vertex-connected.

An explicit Hamilton cycle through
both site edges is the union of these
two internally disjoint \(x\)--\(v\) paths:
\[
\begin{split}
 &x,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
 &x,y,e_0,\
 J,K,o,a,b,e,\ W_{1:s-1},\
 i,h,\ W_{s:r},\ I,H,\
 W_{r+1:m},\ O,A,B,E,\
 o_3,u,v.
\end{split}                                                 \tag{14}
\]
They cover every vertex; the second
uses \(xy,uv\). The cofacial site
expansion has the legal bipartition
order: \(u\) is \(18+4m\) old-cycle steps
after \(x\), so they have the same colour.
The cut projection of
[Note 217](217-vacancy-squares-absorb-across-arbitrarily-long-short-block-ladders.md)
preserves three-connectivity. It is
therefore a Barnette child, Hamiltonian
by [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md).
The face-side chord order and the
unchanged residual square give the
specified selected opening. \(\square\)

**Remaining-branch corollary.** Suppose all vacancies
outside the isolated group (1) lie in distinct internal
blocks. If \(D\) has \(J_0,J_2\), Note 382 compresses it
to a short block and Note 324 gives a marked Hamilton
parent cycle. If \(D\) has no internal free chord and
\(tJ\in M\), Note 382 forces \(hI\) or \(hp_s\).
The first has the spanning route of Note 383; the
second has (9). Substitute this group's \(t\)--\(z\)
route into Note 324's two-path template and use its
standard routes in the other groups. The parent has
a Hamilton cycle through both site edges, and its
legal site-expanded child is Hamiltonian by Note 001.
Thus, under these opening and outside-vacancy
hypotheses, failure of the child to be Hamiltonian
would require the double block to have no internal
free chord and the left endport to use \(to\).
Old-cycle reflection gives the corresponding
restriction in the reversed block order.

The two-cutpoint theorem settles the
matching list and the marked spanning
route in the \(tJ,hp_s\) branch.
It leaves open the pole's other five
Hamilton routing states and therefore
does not assert a square reduction.
The \(to\) first-mate branch, outer
short flanks and other opening types
also remain outside the theorem.
Nothing here resolves Barnette's
conjecture. This is a project-internal
analytic proof with no local graph
recomputation, independent review
or external priority claim.
