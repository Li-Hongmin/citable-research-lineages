> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A vacant shared block forces a third component and can be absorbed one-sidedly

Note 291 settles consecutive missing links when their
shared block is short. A vacant shared block inserts
a vacancy atom between the two port atoms. Old-cycle
adjacency prevents that atom from joining either port
component. In the one-sided configuration where its
vacancy-only component ends at the shared block, the
single-port three-state route to the left joins an
arbitrarily long right end-port component.

Use the compressed, gapless, tight-target all-square
opening of a Barnette parent. All vacancies lie in
distinct target-free internal face-chord blocks.
In one free group suppose exactly \(P_s=e_so_{s+1}\)
and \(P_{s+1}=e_{s+1}o_{s+2}\) are missing ordinary
links and their shared block \(B_{s+1}\) is vacant.
Let \(V=V_{s+1}=(H_{s+1},I_{s+1})\).

**Forced-third-component lemma.** The atom \(V\)
belongs to a vacancy-only component distinct from
the components of both \(P_s\) and \(P_{s+1}\).
Consequently the group has at least four vacancy
atoms: one for each port component and at least two
in the vacancy-only component.

Indeed, the reduced boundary order has
\(P_s<V<P_{s+1}\) with no atom between either
adjacent pair. If \(P_s,V\) were in the same
rainbow component, their connecting matching edge
would be \(o_{s+1}H_{s+1}\), an old-cycle edge.
If \(V,P_{s+1}\) were in the same component, it
would require \(I_{s+1}e_{s+1}\), also an old-cycle
edge. Both are impossible in the complementary
matching. Note 278 says the port components are
distinct; every component has at least two atoms.
This proves the bound.

**One-sided vacant-block theorem.** Suppose the
vacancy-only component containing \(V\) has \(V\)
as its last atom. Suppose \(P_{s+1}\) is the first
atom of its component, whose other atoms are
vacancies to its right. All remaining components
are vacancy-only, and the group's ordinary end
links are retained. Then its full target-free
internal interval has all three spanning \(S,K,X\)
states. If all other free groups have ordinary
spanning routes, the parent has a Hamilton cycle
through both site edges and its legal expanded
child is Hamiltonian. Reflection gives the
orientation with \(V\) first and \(P_s\) last
in its port component.

**Proof.** Let \(\mathcal C\) be the component
of \(V\), with first atom in \(B_a\). Its first
atom lies before \(P_s\), since \(P_s,V\) are
consecutive and \(\mathcal C\) has another atom.
The part containing \(P_s\) lies wholly between
two consecutive atoms of \(\mathcal C\) before
its last atom \(V\): an atom outside that gap
would interlace \(\mathcal C\). In particular,
every atom of the \(P_s\) component lies in
\(B_a,\ldots,B_{s+1}\). Every other component
nested in \(\mathcal C\) is vacancy-only.

Let \(L=B_a,\ldots,B_{s+1}\). Its only internal
missing ordinary link is \(P_s\), and all its
nonboundary matching slots are matched inside
\(L\). The slot \(e_{s+1}\) is a right boundary
port matched externally by the \(P_{s+1}\)
component. Note 288's boundary-locality statement
therefore gives \(S(L),K(L),X(L)\). The proof of
that statement uses no right exterior ordinary
link.

Write the right port component as
\[
 P_{s+1}<V_{k_1}<\cdots<V_{k_m},\qquad m\ge1.
                                                            \tag{1}
\]
Its first vacancy satisfies \(k_1\ge s+3\)
by old-cycle adjacency. All proper gaps of (1)
are vacancy-only and closed by noncrossing.
Apply Note 286's signature-only attachment to
\(L\), with \(s+1\) in place of its \(s\).
Equations (5), (9), and (10) of that note
construct \(S,K,X\) across the right port
component without revisiting \(B_{s+1}\).
Vacancy-only parts outside the combined span
are serial or surrounding and compose by
Note 275. Note 273 joins groups; Notes 001
and 178 give the legal child and lobe lengths.
\(\square\)

The four-vacancy lower bound is attained in a
Barnette parent. In Note 281(8)'s layout take
\(\ell=1,r=6,s=3\), vacant
\(B_1,B_2,B_4,B_6\), and short \(B_3,B_5\).
Retain every standard free link except
\(P_3,P_4\), and add
\[
\begin{gathered}
H_1I_4,\quad I_1H_4,\\
H_2o_4,\quad I_2e_3,\\
e_4I_6,\quad o_5H_6 .
\end{gathered}                                          \tag{2}
\]
The three rows form the vacancy-only component
\(\{V_1,V_4\}\), the \(P_3\) component
\(\{V_2,P_3\}\), and the \(P_4\) component
\(\{P_4,V_6\}\), respectively. They match
every free slot exactly once, join opposite
old-cycle colours, and draw as nested or
disjoint chords in the disk opposite the site
face. The first row surrounds the second;
the third lies to their right. The site edges
remain cofacial.

The retained standard links connect the face
chords through \(B_3\) and from \(B_5\) to
\(B_6\). The chords incident with \(B_4\)
interlace face chords on the left, while
\(e_4I_6\) interlaces those of \(B_4,B_6\)
and bridges the right segment. Every other
special chord interlaces an endpoint face
chord, and the retained end links attach
Note 281's site/residual-square closing chain.
The full interlacement graph is connected,
so Notes 217 and 182 give three-vertex
connectivity. The parent has 44 vertices;
its legal Hamiltonian child has 48.

The forced-third-component lemma applies to
every vacant shared block under these opening
hypotheses. The three-state theorem covers
the stated one-sided placement. A component
containing \(V\) with atoms on both sides,
or a right port component with vacancies
also to its left, requires a further joint
boundary route.
