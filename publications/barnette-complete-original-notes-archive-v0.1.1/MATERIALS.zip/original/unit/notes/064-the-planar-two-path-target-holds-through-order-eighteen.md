> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The planar two-path target holds through order eighteen

[Note 057](057-planar-two-path-covers-require-root-preserving-cycle-absorption.md)
asks whether every rooted simple plane cubic bipartite brace has a spanning
two-path cover realizing each prescribed singleton--paired split of the
three root ports. [Note 063](063-rca-and-the-direct-two-path-target-have-distinct-exact-dual-forms.md)
identifies this with a rooted two-forest and a four-common-base condition.
The following complete finite theorem gives the first exact order boundary
for that direct target.

## Finite theorem

Let \(F\) be a simple plane cubic bipartite brace with
\(|V(F)|\le18\). For every root \(r\), every singleton neighbour
\(s\in N_F(r)\), and

\[
\{a,b\}=N_F(r)\setminus\{s\},
\]

there is a vertex \(y\) in the colour class of \(r\), with \(y\ne r\),
such that \(F-r\) has vertex-disjoint paths \(Q_{ab},Q_{sy}\) whose union
spans \(F-r\).

Consequently, every counterexample to the universal direct target of
Note 057 has at least \(20\) vertices.

## Complete graph range

For every even \(n=6,8,\ldots,18\), geng -cqb -d3 -D3 n generates one
representative of each connected simple cubic bipartite graph. The exact
filtration was

| \(n\) | generated | planar | planar 3-connected | plane braces |
|---:|---:|---:|---:|---:|
| 6  | 1   | 0 | 0 | 0 |
| 8  | 1   | 1 | 1 | 1 |
| 10 | 2   | 0 | 0 | 0 |
| 12 | 5   | 1 | 1 | 1 |
| 14 | 13  | 1 | 1 | 0 |
| 16 | 38  | 3 | 2 | 2 |
| 18 | 149 | 3 | 2 | 1 |

Thus the complete corpus contains \(209\) isomorphism classes and exactly
five plane braces:

    8   G?zTb_
    12  K??FEagT@WB_
    16  O????B_sDOI_I_DO@W?M?
    16  O????B_sCWKOI_BOAW?i?
    18  Q??????wE_P_W_IO@g?h?Cg?B_?

Every vertex was used as root and all three singleton choices were tested.
The number of rooted fibres is therefore

\[
3(8+12+16+16+18)=210.
\tag{1}
\]

All \(210\) fibres contain a witness. The minimum and maximum witness
counts within each graph are

| graph order | minimum | maximum |
|---:|---:|---:|
| 8  | 4  | 4  |
| 12 | 6  | 12 |
| 16, first brace | 8  | 24 |
| 16, second brace | 16 | 34 |
| 18 | 24 | 46 |

In particular, the minimum over the entire complete range is four; the
conclusion is not produced by a single exceptional witness.

## Exact verification

For each retained graph, brace status was checked by extending every
independent two-edge matching. The bipartite strict-Hall inequalities were
checked independently. Each spherical embedding was stored as facial
rotations and verified by directed-edge incidence, one cyclic rotation at
every vertex, and Euler's equation.

For a fixed root and split, the search exhausts the edge sets of \(F-r\)
having degree one at the three ports and at one free same-colour vertex,
and degree two elsewhere. A rollback disjoint-set structure retains only
acyclic choices. The required object is exactly a two-component forest
whose components have endpoint sets \(\{a,b\}\) and \(\{s,y\}\). The
search records both the exact fibre size and one explicit ordered pair of
paths. A separate program checks all \(210\) stored witnesses without
using the census search.

The complete proof bundle is
[planar-two-path-through18](../computations/bundles/planar-two-path-through18/README.md).
It records nauty 2.9.3, NetworkX 3.6.1, the generation parameters, the
accepted output, and the independent reproduction command.

## Boundary

This is an exact computer-assisted finite theorem, not an extrapolation.
The external coverage interfaces are geng completeness and the exact
planarity filter; all brace and path properties are checked independently
from explicit graph data. Order \(20\) and all larger orders remain
unresolved.

The theorem concerns the direct two-path target. It does not prove RCA:
the endpoint-separated two-cycle condition is sufficient for a two-path
witness, but a general direct witness need not admit the perfect-matching
completion required by RCA.
