> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Four-vertex safety does not eliminate small laminar-dual leaves

[Note 042](042-four-vertex-regions-do-not-obstruct-single-layer-fec-support.md)
proves that every four-vertex region admits a perfect matching of internal
cost at most three.  A natural next step would be to delete every
four-vertex leaf from an optimal laminar dual of Note 033.  This note shows
that the inference is invalid even for a planar partition--graphic
common-base system.  The missing datum is compatibility with the
blockwise minimizers created by all other dual weights.

## The exact leaf derivative

Use the dual objective of Note 033,

\[
 \Phi(z)=
 \sum_x\min_{e\in D_x}
 \left(c_e+\sum_{U:e\in E_Q(U)}z_U\right)
 -\sum_U z_U(|U|-1).
\tag{1}
\]

Fix a positive leaf \(W\) of the laminar support and write

\[
 t=z_W,
 \qquad
 b_e=c_e+\sum_{U\ne W:e\in E_Q(U)}z_U.
\]

For each block \(D_x\), put

\[
 i_x=\min_{e\in D_x\cap E_Q(W)}b_e,
 \qquad
 o_x=\min_{e\in D_x\setminus E_Q(W)}b_e,
\tag{2}
\]

with the minimum of an empty set equal to \(+\infty\).  The part of
\(\Phi\) depending on \(t\) is

\[
 \phi_W(t)=
 \sum_x\min(i_x+t,o_x)-t(|W|-1).
\tag{3}
\]

Define

\[
 P_{\le}(t)=\{x:i_x+t\le o_x\},
 \qquad
 P_{<}(t)=\{x:i_x+t<o_x\}.
\tag{4}
\]

For sufficiently small \(\varepsilon>0\),

\[
 \phi_W(t-\varepsilon)-\phi_W(t)
 =\varepsilon\bigl(|W|-1-|P_{\le}(t)|\bigr).
\tag{5}
\]

Indeed, decreasing \(t\) lowers a block minimum by \(\varepsilon\)
exactly when its internal minimum is selected or tied at \(t\).  The rank
penalty simultaneously rises by \(\varepsilon(|W|-1)\).

Consequently a positive leaf is locally deletable without loss only if

\[
 |P_{\le}(t)|\le |W|-1.
\tag{6}
\]

At an interior maximum, concavity gives the sharper necessary condition

\[
 |P_{<}(t)|\le |W|-1\le |P_{\le}(t)|.
\tag{7}
\]

The four-vertex theorem supplies a perfect matching using at most
\(|W|-1\) internal edges.  It does not bound the number of blocks in
\(P_{\le}(t)\), because that matching need not choose a blockwise
minimum for the baseline costs \(b_e\).

## A five-vertex common-base countermodel

Let \(Q\) be the wheel with rim

\[
 W=\{0,1,2,3\}
\]

and centre \(o\).  Write

\[
 e_i=i(i+1)\quad(\bmod 4),
 \qquad
 f_i=oi,
\]

and take the four partition blocks

\[
 D_i=\{e_i,f_i\}.
\tag{8}
\]

Give every rim edge cost zero and every spoke cost one:

\[
 c_{e_i}=0,
 \qquad
 c_{f_i}=1.
\tag{9}
\]

The four spokes form both a partition base and a spanning tree.  In
particular, one common base simultaneously satisfies

\[
 |B\cap E_Q(U)|\le |U|-1
\]

for every proper vertex set \(U\), a property stronger than choosing a
separate low-intersection witness for each four-vertex region.

Nevertheless, for the single dual variable \(z_W=t\), equation (3) is

\[
 \phi_W(t)=4\min(t,1)-3t.
\tag{10}
\]

Its unique maximum occurs at \(t=1\), with value one.  At that point all
four blocks are tied:

\[
 |P_{\le}(1)|=4>|W|-1=3.
\]

Removing the leaf lowers the dual value from one to zero.  Equivalently,
the dual assignment

\[
 z_W=1,
 \qquad
 \alpha_i=1\quad(0\le i<4)
\]

is feasible and has value \(4-3=1\).  The common bases are all partition
selections except the four-edge rim cycle; their minimum \(c\)-cost is
one, so this dual value is optimal.

More generally, every optimal dual for this five-vertex system has a
positive proper-set variable: with all set variables zero, the four block
minima are zero.  Every proper set has size at most four, so some positive
leaf of every optimal support is small.

## Consequence and exact remaining boundary

The countermodel is planar and preserves the partition--graphic
common-base structure, but it is not asserted to arise from the literal
perfect-matching incidence of a plane cubic brace.  It proves the strict
methodological boundary

\[
 \boxed{
 \text{four-vertex low-intersection witnesses}
 \not\Longrightarrow
 \text{small-leaf elimination in an optimal laminar dual}.}
\tag{11}
\]

For an actual strict FEC certificate, a weaker transformation might still
remove a small leaf while losing some dual value but preserving the strict
inequality over \(|A|\).  That statement is not decided here.  Any such
proof must use additional plane-cubic incidence to relate a
low-intersection perfect matching to the active block set
\(P_{\le}(t)\), or must exploit the global slack above \(|A|\).
