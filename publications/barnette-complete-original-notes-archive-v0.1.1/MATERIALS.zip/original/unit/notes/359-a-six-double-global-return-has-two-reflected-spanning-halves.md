> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A six-double global return has two reflected spanning halves

[Note 358](358-six-alternating-double-blocks-reduce-to-one-global-first-return-branch.md)
reduces the consecutive forward six-double group to the first
return \(h_1j_6\). Its branch \(k_1j_3\) has a unique
complementary matching: the two three-block halves are reflections,
and each has the terminal-spanning path needed to cross
\(h_1j_6\) exactly once.

Use Note 358's compressed, gapless, tight-target all-square
opening, its six blocks \(D_1,\ldots,D_6\), ordinary endports
\(L,R\), and the common-face internal matching chords
\[
              i_1e_1,\ o_2k_2,\ i_3e_3,\
              o_4k_4,\ i_5e_5,\ o_6k_6.                  \tag{1}
\]
There is no short block in this group.

**Reflected-halves theorem.** If an actual complementary
matching contains \(h_1j_6,k_1j_3\), then all its
opposite-page chords in the group are
\[
\begin{split}
&Lo_1,\quad h_1j_6,\quad e_6R,\\
&k_1j_3,\quad j_1h_2,\quad i_2k_3,\quad
  j_2h_3,\quad e_2o_3,\\
&h_4i_6,\quad i_4k_5,\quad j_4h_5,\quad
  e_4o_5,\quad j_5h_6.                                  \tag{2}
\end{split}
\]
It gives a vertex-spanning \(L\)--\(R\) path.
If all vacancies outside the group occupy distinct internal
blocks, the parent has a Hamilton cycle through both site
edges and its legal child is Hamiltonian.

**Matching exhaustion.** By Notes 193 and 327, the
remaining cross-block free chords are noncrossing on the
opposite page, and no other same-block free chord is present.
Outside \(h_1j_6\), only \(L,o_1,e_6,R\) are free.
The alternative \(LR,o_1e_6\) would close all six complete
blocks under the matching and produce a forbidden
two-edge cut. Hence \(Lo_1,e_6R\).

Inside \(k_1j_3\), the free slots are
\[
                 j_1,h_2,i_2,j_2,e_2,o_3,h_3,k_3.       \tag{3}
\]
The first slot \(j_1\) can meet \(h_2\) or \(k_3\).
If \(j_1k_3\), the slot \(h_2\) has no interior
mate: \(h_2i_2\) is old, \(h_2j_2\) is excluded
by chord isolation, and \(h_2o_3\) encloses three
free slots. Thus \(j_1h_2\).
Next \(i_2\) must meet \(k_3\): its candidates
\(e_2,h_3\) enclose respectively one and three
free slots. Noncrossing then forces
\(j_2h_3,e_2o_3\).

The free interval after \(j_3\) and before \(j_6\)
starts with \(h_4\) and ends with \(i_6\).
The first slot \(h_4\) can meet only \(j_5\) or
\(i_6\). A chord \(h_4j_5\) would leave the
last two slots \(h_6,i_6\) paired by their
old-cycle edge, so \(h_4i_6\).
Inside it, \(i_4\) can meet only \(k_5\)
or \(h_6\). If \(i_4h_6\), then
\(j_4h_5,e_4o_5\) are forced and leave
the old pair \(k_5j_5\). Therefore
\(i_4k_5\), whose interior forces
\(j_4h_5,e_4o_5\); the remaining two
slots give \(j_5h_6\). This proves (2).
\(\square\)

**Spanning route.** The left half \(D_1,D_2,D_3\)
has the following path from \(o_1\) to \(h_1\):
\[
\begin{split}
P={}&(o_1,a_1,b_1,e_1,j_1,h_2,o_2,a_2,b_2,e_2,
o_3,a_3,b_3,e_3,i_3,h_3,\\
&j_2,k_2,i_2,k_3,j_3,k_1,i_1,h_1).                    \tag{4}
\end{split}
\]
Each of the three blocks contributes all eight vertices once.
The non-old joins are its block-closing chords, the
common-face chord \(i_3e_3\), and
\(j_1h_2,e_2o_3,j_2h_3,i_2k_3,j_3k_1\).
The remaining consecutive pairs are old-cycle edges.

Apply the old-cycle reflection of Note 346 (4) with
\(N=6\), then reverse the resulting vertex order.
The right-half \(j_6\)--\(e_6\) path is
\[
\begin{split}
Q={}&(j_6,k_6,i_6,h_4,i_4,k_5,i_5,h_5,j_4,k_4,o_4,
a_4,b_4,e_4,\\
&o_5,a_5,b_5,e_5,j_5,h_6,o_6,a_6,b_6,e_6).           \tag{5}
\end{split}
\]
It uses each vertex of \(D_4,D_5,D_6\) exactly once.
Its non-old joins are the reflected chords of the
ones just listed for \(P\). Thus
\[
                       (L,P,h_1j_6,Q,R)                \tag{6}
\]
means the simple concatenation of \(L\), the vertex
list \(P\), the edge \(h_1j_6\), the vertex list
\(Q\), and \(R\). The first and last joins are
\(Lo_1,e_6R\). Equation (6) spans every group
vertex once. As in Note 357, this route composes with
Note 324's other groups under the stated
outside-vacancy condition, and Note 001 supplies
the legal child's Hamilton cycle. \(\square\)

The theorem closes only the \(h_1j_6,k_1j_3\)
matching branch. Other mates of \(k_1\) under
\(h_1j_6\), other six-block words and openings,
and the general Barnette conjecture remain outside
its scope. This is a project-internal analytic proof
without an external priority claim.
