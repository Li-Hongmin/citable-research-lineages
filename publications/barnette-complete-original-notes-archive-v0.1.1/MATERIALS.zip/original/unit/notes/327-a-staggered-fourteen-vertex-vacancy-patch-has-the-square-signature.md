> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A staggered fourteen-vertex vacancy patch has the square signature

[Note 227](227-all-target-free-same-block-double-vacancies-are-hamiltonian.md)
excludes the internal chord \(oh_2\) when the doubly vacant block is the
only vacant block in its free group. Its count of missing ordinary links
does not apply when another block is vacant. The following patch shows
that the chord can then occur, and gives an exact Hamilton reduction for
one such configuration. We use the four-terminal routing convention of
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).

**Local chord-isolation lemma.** In any selected all-square
opening with a target-free doubly vacant face block
\(D=(A,O,H,I,K,J,E,B)\), if its complementary matching
contains \(J_1=OK\), then \(OK\) lies on the common-face
side and none of the other internal free chords
\(J_0=OE,J_2=HJ,J_3=IE\) occurs. This conclusion does not
bound the number or placement of vacancies in other blocks.
By old-cycle reflection, an internal \(J_3\) likewise occurs
alone and lies on the common-face side.

**Proof.** A chord joining free slots of different blocks lies
on the opposite side by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
Suppose first that \(OK\) lay on that side. The two slots
\(H,I\) strictly between its ends cannot match each other,
because \(HI\) is an old-cycle edge. They cannot match outside
the chord on the opposite side without crossing it. Their only
possible same-block exits on the common-face side are
\(HJ\) and \(IE\), respectively. Both would therefore be
needed, but they interlace in the order \(H,I,J,E\), which
is impossible on one side. Thus \(OK\) lies on the
common-face side.

The chord \(HJ\) interlaces \(OK\), so if present it must
lie on the opposite side. Inside \(HJ\), the slot \(K\)
is already matched to \(O\) on the common-face side. The
other inside slot \(I\) cannot match \(K\), cannot match
outside by an opposite-side cross-block chord without crossing
\(HJ\), and cannot use \(IE\): that chord crosses \(OK\)
on the common-face side and \(HJ\) on the opposite side.
Hence \(HJ\) is absent. If \(IE\) were present, it would
similarly lie opposite the common face and enclose \(K,J\).
The used slot \(K\) leaves \(J\) without an inside mate;
every outside opposite-side chord crosses \(IE\), while
its only other same-block candidate \(HJ\) crosses both
\(OK\) and \(IE\) on their respective sides. Thus
\(IE\) is absent. The chord \(OE\) shares \(O\) with
\(OK\) and is unavailable. Reflection proves the last
assertion. \(\square\)

Let \(P\) be the graph on the fourteen vertices in the path order
\[
 a,o,h,i,e,b,A,O,H,I,K,J,E,B,                         \tag{1}
\]
with all thirteen consecutive path edges and the six additional edges
\[
 ab,\quad oe,\quad hI,\quad iH,\quad AB,\quad OK.       \tag{2}
\]
Here \((a,o,h,i,e,b)\) is a singly vacant face block and
\((A,O,H,I,K,J,E,B)\) is the immediately following doubly vacant
face block. Its two vacant pairs are \((H,I),(K,J)\), and its
internal chord \(OK\) is precisely \(J_1=oh_2\) in Note 227's
notation. The four degree-two terminals of \(P\) are
\(a,J,E,B\), in that cyclic order. Every other vertex has degree
three. The chords \(ab,oe,AB,OK\) are disjoint or nested on one
side of (1); \(hI,iH\) are nested on the other. This gives a
plane disk drawing with the four terminals on its boundary.

**Staggered-patch theorem.** The complete spanning one-path and
two-path Hamilton linkage signatures of \(P\), at the labeled
terminals \((a,J,E,B)\), equal those of a square in the cyclic
order \(a',J',E',B'\). Consequently, replacing an induced copy
of \(P\) in a cubic graph by this labeled square transfers every
Hamilton cycle in both directions with exactly the same exterior
edges and used attachment edges. If the original graph is Barnette
and its exterior is nonempty, the reduced graph is Barnette.
Conversely, replacing the square by \(P\) in a Barnette graph
is Barnette. Thus this is a two-way class-preserving Hamilton
reduction at the four labeled attachments. In particular, a
vertex-minimal non-Hamiltonian Barnette graph cannot contain
such a patch: its square replacement is ten vertices smaller
and has the same Hamilton decision.

**Proof of the signature.** The even-order path (1) gives the
bipartition colours \(a,E\) on one side and \(J,B\) on the other.
Thus a spanning path may join only one of the four pairs listed
below. Each row is an explicit path through every vertex of \(P\):
\[
\begin{array}{c|l}
aB & a,o,h,i,e,b,A,O,H,I,K,J,E,B\\
aJ & a,b,e,o,h,i,H,I,K,O,A,B,E,J\\
JE & J,K,I,h,o,a,b,e,i,H,O,A,B,E\\
EB & E,J,K,I,h,o,a,b,e,i,H,O,A,B.
\end{array}                                             \tag{3}
\]
Two disjoint paths with all four terminals as endpoints have only
two possible noncrossing pairings in the disk. Both occur:
\[
\begin{array}{c|l}
\{aJ,EB\}&(a,o,h,i,e,b,A,O,H,I,K,J),\quad(E,B)\\
\{aB,JE\}&(a,o,h,I,K,O,H,i,e,b,A,B),\quad(J,E).
\end{array}                                             \tag{4}
\]
The remaining pairing \(\{aE,JB\}\) interlaces the four boundary
terminals, so it cannot be drawn with disjoint paths. Equations
(3)--(4) are exactly the square's signature.

A global Hamilton cycle meets the four-edge patch cut in two or
four edges. Its patch intersection is respectively one spanning
path or two spanning paths. Replace that intersection by the
corresponding row of the square signature, or conversely by (3)
or (4). The exterior edges, attachments, and connections of the
exterior paths remain the same. This proves the exact transfer.

**Proof of Barnette equivalence.** The four terminal colours agree
with the square's, so bipartiteness is preserved. Contract the
connected path from \(a\) through \(K\) in (1) to \(a'\), leaving
\(J,E,B\) as the other three labeled vertices, and delete
surplus edges. The edges \(KJ,JE,EB,AB\) give the square
\(a'J'E'B'a'\); every exterior attachment stays at its label.
Thus the square replacement is a planar minor. Conversely,
the disk drawing preceding the theorem inserts \(P\) in place of
the square with the same cyclic attachment order. In a plane
Barnette graph the exterior of a square with four attachments is
connected, so it lies on one side of that square and leaves the
other side available for this insertion. Cubicity and simplicity
follow from the four distinct terminals and their single external
edges.

Let \(H_{\rm ext}=G-V(P)\). It is connected: if it had two
components, each would require at least three of the four
attachment edges by the three-edge-connectivity of \(G\).
After deleting up to two vertices of the reduced graph, it
remains connected. If both deleted vertices lie in the square,
the surviving square vertices attach to connected \(H_{\rm ext}\).
If neither lies in the square, every component of the surviving
exterior attaches to the intact square, since the corresponding
deletion in \(G\) leaves a connected graph. If one deleted vertex
lies in the square and the other in the exterior, delete the
corresponding terminal of \(P\) and the same exterior vertex in
\(G\). Every surviving exterior component then has an attachment
at one of the other three terminals, which are connected in the
surviving square. Thus the reduced graph is three-connected.

For the reverse direction, observe that the six vertices
\(a,o,h,i,e,b\) form a cycle, the eight vertices
\(A,O,H,I,K,J,E,B\) form another cycle, and the three edges
\(bA,hI,iH\) join them at pairwise distinct endpoints. Deleting
at most one vertex leaves \(P\) connected. After deleting two
vertices, every surviving component of \(P\) contains a
surviving terminal. If one vertex is deleted from each cycle,
both residual cycles are connected and at least one of the
three joins survives, so \(P\) itself is connected. If both
deletions are in the first cycle, a component without terminal
\(a\) or a surviving join endpoint \(b,h,i\) could contain only
\(o,e\). Isolating \(o\), \(e\), or \(\{o,e\}\) would require,
respectively, deletion of three, three, or four of their
neighbors, which is impossible. If both deletions are in the
second cycle, a component without terminal \(J,E,B\) or join
endpoint \(A,H,I\) could contain only \(O,K\); isolating
\(O\), \(K\), or \(\{O,K\}\) likewise requires at least three
deletions. In each same-cycle case, a surviving join endpoint
connects to the intact opposite cycle, which contains a surviving
terminal. This proves the component assertion.

Now suppose the square host is three-connected. Its exterior
is connected by the same four-edge-cut argument. With two
patch vertices deleted, each surviving component of \(P\)
attaches at a terminal to that connected exterior. With no
patch vertex deleted, every component of the exterior after
up to two deletions attaches to the connected \(P\), since
the square host survives those same deletions. With one patch
vertex and one exterior vertex deleted, \(P\) remains connected;
the square host after deletion of the corresponding square
terminal and the same exterior vertex shows that every
surviving exterior component attaches at another terminal.
Thus the expanded graph is three-connected as well.
\(\square\)

**Marked-opening consequence.** Suppose a compressed, gapless,
tight-target all-square opening of a Barnette parent has two
adjacent target-free internal blocks in the order (1), with the
matching edges (2). All other vacancies may be in arbitrary
distinct internal blocks, including target-bearing blocks, with
at most one vacancy per such block. Replace \(P\) by its square.
The old Hamilton cycle uses the segment (1); in the reduced graph
it uses \(a',J',E',B'\), with the face chord \(a'B'\).
The two face chords \(ab,AB\) and the intervening edge \(bA\)
are one consecutive portion of the designated common-face
boundary. The two external matching edges at \(J,E\) retain
their cyclic order on the opposite side. Hence the selected
opening remains all-square, gapless and tight, now with one
fewer face block and with neither of these two blocks vacant.
No escape target or site edge is touched. The reduced parent is
Barnette by the theorem, and its remaining vacancies are in
distinct internal blocks. [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md)
gives it a Hamilton cycle through both site edges. Exact transfer
lifts that cycle to the original parent with the same site edges;
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
then gives a Hamilton cycle in its legal site-expanded child.
The conclusion also holds before residual-lobe compression by
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
Reversing the old-cycle order gives the same reduction and marked
Hamilton conclusion for a doubly vacant block with \(J_3=i_1e\)
immediately followed by its singly vacant partner.

**A realizable \(J_1\) instance.** The qualification that \(J_1\)
can occur is witnessed by the following 26-vertex graph. Give its
old Hamilton cycle \(C\) the order
\[
\begin{split}
 x,R_1,e_0,y,&\ a,o,h,i,e,b,
 A,O,H,I,K,J,E,B,\\
 &u,o_3,L_1,v,\alpha,\gamma,\delta,\beta,x.
\end{split}                                             \tag{5}
\]
Add the complementary perfect matching
\[
\begin{split}
M=\{&xy,ab,AB,uv,\alpha\beta,
       oe,OK,\\
     &\delta R_1,\gamma L_1,e_0J,hI,iH,Eo_3\}.
\end{split}                                             \tag{6}
\]
The first seven chords in (6) are noncrossing on the common-face
side: the site, face-block and residual-square chords occupy
disjoint intervals, and \(oe,OK\) are nested within their
respective face-block chords. The other six are noncrossing on
the opposite side: in (5), \(\delta R_1\) encloses all other
opposite-side chords, \(e_0J\) contains the nested pair
\(hI,iH\), while \(Eo_3\) and \(\gamma L_1\) lie to its
right. Every edge in (6) joins opposite cycle parities.
Thus the graph is simple, cubic, bipartite and plane, with
\(xy,uv\) cofacial. Its residual square is
\(\alpha\gamma\delta\beta\alpha\), and \(R_1,L_1\)
are the tight escape targets.

For three-connectivity, the chord-interlacement graph of
\(M\) has the connected spanning subgraph
\[
 xy-e_0J-AB-hI-ab-iH-oe,\qquad
 hI-OK,\qquad
 AB-Eo_3-uv-\gamma L_1-\alpha\beta-\delta R_1.
                                                               \tag{7}
\]
Every displayed adjacency is alternation of its two pairs
of endpoints in (5). A two-edge cut in a cubic Hamiltonian
graph would bound a proper interval of \(C\) closed under
\(M\), separating the interlacement graph, contrary to (7).
The Hamiltonian graph has no bridge, so it is three-edge-
connected and therefore three-vertex-connected in the cubic
case, as in [Note 217](217-vacancy-squares-absorb-across-arbitrarily-long-short-block-ladders.md).

For an explicit marked Hamilton cycle, join the two internally
disjoint \(x\)--\(v\) paths
\[
 x,R_1,\delta,\beta,\alpha,\gamma,L_1,v
 \quad\text{and}\quad
 x,y,e_0,J,K,I,h,o,a,b,e,i,H,O,A,B,E,o_3,u,v.
                                                               \tag{8}
\]
They cover all 26 vertices, and the second uses both site
edges. The legal site expansion is Barnette by the cut
projection in Note 217 and is Hamiltonian by Note 001.

**Isolated three-vacancy classification.** Suppose a complete
target-free free group has exactly two vacant face blocks, one
singly vacant block \(V=(a,o,h,i,e,b)\) and one doubly vacant
block \(D=(A,O,H,I,K,J,E,B)\), with no short block before,
between or after them in the group. Write \(t\) and \(z\) for
the group's left even and right odd ordinary endports. If
\(OK=J_1\) belongs to the complementary matching, then
\(V\) precedes \(D\), and the entire free matching is uniquely
\[
             \{tJ,\ oe,\ hI,\ iH,\ OK,\ Ez\}.          \tag{9}
\]
In particular, the induced two-block subgraph is exactly \(P\).
The reflected statement holds for \(J_3\), with the single
block following the double block.

**Proof.** By the chord-isolation lemma, \(OK\) is the only
internal free chord of \(D\), and it lies on the common-face
side. The sole possible internal free chord of \(V\) is \(oe\).
If present, it also lies on that side: on the opposite side it
would trap \(h,i\), whose mutual edge is already on the old
cycle and whose cross-block mates would cross \(oe\). Every
other free matching chord lies on the opposite side. For any
such chord, the number of free slots strictly between its
endpoints, minus the number of endpoints there of face-side
matching chords that exit the interval, must be even. We use
this interval parity rule and the prohibition on matching an
old-cycle edge.

First put \(V\) before \(D\). The free-slot order is
\[
                t,o,h,i,e,O,H,I,K,J,E,z.               \tag{10}
\]
The even slot \(E\) can match only \(o,i,z\): \(O,K\)
are used, \(IE\) is excluded by chord isolation, and \(JE\)
is an old-cycle edge. The backward ordinary chord \(Eo\)
would enclose both complete blocks; no opposite-side matching
edge could leave their full interval, while their face chords
and possible same-block chords stay inside. This is a forbidden
two-edge cut. If \(Ei\) occurs and \(oe\) also occurs, exactly
one end of \(oe\) lies inside \(Ei\), while both ends of
\(OK\) lie inside; the six interior free slots fail the parity
rule. If \(oe\) is absent, the first even slot \(e\) inside
\(Ei\) must match \(I\) or \(J\). The edge \(eI\) traps
\(O,H\) with the single face-side exit \(OK\), contrary to
parity; \(eJ\) traps \(H,I\) after the internally paired
\(O,K\), and \(HI\) is an old-cycle edge. Hence \(Ez\)
is forced.

The left endport \(t\) now has possible mates \(o,i,I,J\).
The edge \(ti\) traps \(o,h\), which cannot use their
old-cycle edge; if \(oe\) is present, its single face-side
exit instead violates parity. The edge \(tI\) has six
interior free slots and the single face-side exit from
\(O\) to \(K\); an optional \(oe\) is wholly inside, so
parity again fails. If \(to\) occurs, \(oe\) is absent.
The slot \(h\) must then match \(I\) or \(J\). The edge
\(hI\) has the single face-side exit \(OK\) from its
four-slot interior and violates parity. The edge \(hJ\)
leaves \(i,e,H,I\); their only possible pairs are
\(iH,eI\), which interlace on the opposite side.
Thus \(tJ\) is forced. Inside this chord, \(H\) can match
only \(o\) or \(i\). If \(Ho\), the slot \(I\) must match
\(h\) or \(e\), and either resulting chord interlaces
\(Ho\). Hence \(Hi\), after which \(oe\) and \(hI\)
are forced. This gives exactly (9); its opposite-side
chords \(tJ\supset hI\supset iH\) are nested.

Now put \(D\) before \(V\), so the order is
\[
                t,O,H,I,K,J,E,o,h,i,e,z.               \tag{11}
\]
The endport \(t\) can match only \(I,J,o,i,z\).
The edge \(tI\) traps \(O,H\) with the single exit
\(OK\), contrary to parity. The edge \(tJ\) traps
\(O,H,I,K\); after \(OK\), the remaining \(HI\) is
an old-cycle edge. The edge \(to\) encloses the complete
block \(D\), and \(tz\) encloses both complete blocks;
each would make a forbidden two-edge cut. Finally, suppose
\(ti\) occurs. If \(oe\) occurs, its \(o\)-end is the
only face-side exit from the eight interior free slots,
contradicting parity. If \(oe\) is absent, \(H\) must
match \(o\): its other available odd mates are the
old-cycle neighbor \(I\) and the excluded internal
chord \(HJ\), while the opposite-side chord \(ti\)
forbids a mate outside it. But \(Ho\) traps four slots
with one face-side exit from \(K\) to \(O\), again
contradicting parity. No mate for \(t\) remains, so this
order is impossible. Reflection gives the \(J_3\) clause.
\(\square\)

The patch theorem concerns a specified induced four-pole; it
does not classify matchings containing \(J_1\) with additional
blocks or vacancies in its free group, nor
openings with site-block vacancies, positive gaps, defective
target order or nonsquare residual cycles. It gives no
resolution of Barnette's conjecture. The reduction and example
are analytic project-internal results; no external priority
claim is made. Gorsky--Steiner--Wiederrecht (2023, Section 5)
restates the Holton--Manvel--McKay (1985, Theorem 4) generation
theorem and distinguishes cube and \(C_4\) expansions, but neither
the generation statement nor that discussion supplies the
four-terminal signature (3)--(4).
