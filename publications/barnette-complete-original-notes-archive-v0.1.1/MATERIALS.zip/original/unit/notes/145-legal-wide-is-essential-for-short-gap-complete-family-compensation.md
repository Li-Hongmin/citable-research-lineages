> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Legal-wide is essential for short-gap complete-family compensation

[Notes 139--144](139-a-one-edge-facial-gap-leaves-only-h-avoiding-11-00-bonds.md)
isolate a complete-family compensation statement for a one-edge facial gap.
This note shows that the statement is false for arbitrary interface-disjoint
decorations, even when the parent and child are plane cubic bipartite braces
and both complete perfect-matching families are used. The surviving
historical question must retain the legal-wide gate-face hypothesis.

## 1. The decorated site

Let \(G\) be the order-\(26\) graph with graph6 string

~~~text
Y?????????????w?Y?CW??w??[?EC?T??_W?D@??AK?@_O?GK??SA???
~~~

and facial hexagon

\[
 (3,21,11,17,10,25).
\tag{1}
\]

Choose the opposite site edges and short residual edge

\[
 p=11\!-21,\qquad q=3\!-25,\qquad h=3\!-21,
\tag{2}
\]

and decorate the rooted fibre by

\[
 e=6\!-16,\qquad g_0=1\!-13,\qquad g_1=5\!-15.
\tag{3}
\]

The six vertices incident with \(e,g_0,g_1\) are disjoint from the four
site vertices. The parent \(G\) and the expanded child \(G^+\) are both
simple, connected, cubic, bipartite, planar, 3-connected, and 2-extendable.

For either graph, call a perfect matching a rooted target when it contains
\(e,g_0\), its complementary two-factor has exactly two cycles, and the two
endpoints of \(e\) lie on different cycles. Divide rooted targets into the
two sectors according to membership of \(g_1\). Two opposite-sector targets
form a bond when their symmetric difference is one alternating cycle.

## 2. The complete parent family is extreme

The complete parent perfect-matching family has \(254\) members. Exactly
four are rooted targets. Their site states and sectors are

\[
 2\cdot(11,0)+1\cdot(11,1)+1\cdot(00,0).
\tag{4}
\]

The complete cross-sector bond graph has exactly one edge. It joins a
state-\(11\) target to the state-\(00\) target, and the latter omits \(h\).
Consequently

\[
 B_{\rm bad}=\{b\},\qquad B_{\rm auto}=\varnothing.
\tag{5}
\]

Thus the unrestricted complete-family antecedent of Notes 139--144 holds
in its strongest one-bond form.

## 3. The complete child family has no supplement

The complete child perfect-matching family has \(528\) members. Its rooted
fibre has six members, with cell histogram

\[
 C_{00}^{\,1},\qquad R_{00}^{\,1},\qquad
 X_{uy}^{\,1},\qquad X_{vx}^{\,3},
\tag{6}
\]

and sector sizes \(5+1\). None of the five possible opposite-sector pairs
has a one-cycle symmetric difference. Hence the entire child rooted bond
graph is empty and

\[
 |B_{\rm child}^{\rm new}|=0<1=|B_{\rm parent}|.
\tag{7}
\]

This also separates the two pointwise mechanisms used earlier. The
one-edge-gap image \(\Phi(M)\) of the state-\(11\) endpoint is a rooted
\(X_{vx}\) target, but it is isolated in the child bond graph. The forced
gate-path sibling of the state-\(00\) endpoint is an actual \(X_{uy}\)
perfect matching and differs from the canonical \(C_{00}\) lift by one
alternating cycle, but its complement is Hamiltonian. It is therefore not
a rooted target.

## 4. Counterexample theorem and exact boundary

Combining (5)--(7) gives the following.

> **Theorem.** ParentKill does not imply ChildSupplement for arbitrary
> interface-disjoint one-edge-gap decorations, even when the parent and
> child are simple 3-connected plane cubic bipartite 2-extendable graphs and
> the parent and child rooted fibres are taken from their complete
> perfect-matching families.

The decoration (3) is not legal-wide. In the child embedding, \(g_0\) and
\(g_1\) have no common face, and therefore

\[
 \operatorname{legal\_wide\_arcs}(G^+;e,g_0,g_1)=\varnothing.
\tag{8}
\]

Thus the theorem does not refute the historical legal-wide implication. It
proves instead that legal-wide carries indispensable global information:
common plane-cubic incidence, brace structure, complete parent and child
perfect-matching closure, and interface disjointness do not replace it.

The corrected unresolved statement is

\[
\boxed{
\begin{minipage}{0.82\linewidth}
For a legal-wide interface-disjoint one-edge-gap decoration, if the complete
parent rooted bond graph is nonempty and every parent bond is an
\(h\)-avoiding \(11\)--\(00\) bond, must the complete child rooted family
contain a new-cell bond?
\end{minipage}}
\tag{9}
\]

Any next proof must use the extra gate-face geometry in (8), rather than
only the unrestricted common perfect-matching family. No order-minimality
claim is made for the counterexample.

[Note 146](146-an-occupied-domino-portal-forces-short-gap-child-compensation.md)
gives one exact sufficient mechanism inside this boundary: if the short edge
and surviving gate are opposite edges of a facial square whose lateral
edges are occupied by the bad state-\(00\) endpoint, the resulting two-square
domino preserves the complete complement signature and forces a child
supplement. It remains unknown whether legal-wide complete-family
extremality must create this or another neutralizing mechanism.

The complete enumeration and graph-class checks are frozen in the
[interface-disjoint complete-family counterexample bundle](../computations/bundles/interface-disjoint-complete-family-counterexample/README.md).
