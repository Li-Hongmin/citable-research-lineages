> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A backward port before the last vacancy has a rooted cap

[Note 306](306-a-final-gap-cap-is-exactly-a-rooted-crossed-linkage.md)
reduces a final-gap cap to a rooted spanning linkage and proves
it automatically when at most one ordinary link is missing.
The following two-defect pattern has a backward-facing port
strictly before the last vacancy of a two-vacancy end-port
component. Its matching edges point to an interior vacancy,
so the serial side-chain cap of Note 303 does not apply.
Crossed-rail folds nevertheless give the required rooted cap
at every possible position of that second port.

Use the compressed, gapless, tight-target all-square opening
of Notes 275--306. Let \(B_v,B_u\) be vacant blocks with
\(u>t>s>j>h>v\), and assume
\[
 h\ge v+2,\qquad j\ge h+1,\qquad
 j+1\le s\le t-1,\qquad t\le u-1.                   \tag{1}
\]
The complementary matching contains
\[
\begin{array}{ll}
I_vH_u,\quad e_{u-1}o_u;&\text{outer cap anchors},\\
e_vI_t,\quad o_{v+1}H_h,\quad I_hH_t;&
  \mathcal Q=\{P_v,V_h,V_t\},\\
H_jo_{s+1},\quad I_je_s;&
  \mathcal R=\{V_j,P_s\}.
\end{array}                                                   \tag{2}
\]
All ordinary links in \(B_v,\ldots,B_u\) other than
\(P_v\) and \(P_s\) are retained. Set
\[
 G_0=B_{v+1},\ldots,B_{h-1},\quad
 G_1=B_{h+1},\ldots,B_{j-1},\quad
 L=B_{j+1},\ldots,B_s,\quad
 R=B_{s+1},\ldots,B_{t-1},\quad
 J=B_{t+1},\ldots,B_{u-1}.                           \tag{3}
\]
The intervals \(G_0,L\) are nonempty; \(G_1,R,J\)
may be empty. Their elementary crossed rails use only
old-cycle edges, face chords, and the retained ordinary
links, so their vacancy matching may be arbitrary subject
to the actual Barnette parent and the fixed edges (2).

**Backward-port cap theorem.** Under (1)--(3), there is a
path \(D:e_{u-1}\leadsto b_{u-1}\) whose vertex set is
exactly
\[
 \{e_v,b_v\}\cup\bigcup_{r=v+1}^{u-1}V(B_r).
                                                               \tag{4}
\]
Hence this two-defect final gap meets Note 305's cap
interface. If the other hypotheses of its two-chord skeleton
hold, the enclosing free group has spanning \(S,K,X\)
states, a marked Hamilton parent cycle, and a legal
Hamiltonian site-expanded child.

**Proof.** First construct a path \(U:b_v\leadsto b_t\)
spanning \(B_{v+1},\ldots,B_t\) except \(I_t,e_t\).
For a nonempty interval \(G\), let \(X_{\rm top}(G)\)
have endpoints \(a_{\min G},b_{\max G}\), and
\(X_{\rm bottom}(G)\) have endpoints
\(o_{\min G},e_{\max G}\). Let \(W_R\) run from
\(o_t\) to \(o_{s+1}\): if \(R\) is nonempty, it is
\[
 o_t,e_{t-1}\xrightarrow{X_{\rm bottom}(R)^{-1}}o_{s+1};
\]
if \(R\) is empty, it is the single vertex
\(o_t=o_{s+1}\). Traverse
\[
\begin{split}
b_v,a_{v+1}
 &\xrightarrow{X_{\rm top}(G_0)}b_{h-1},e_{h-1}
  \xrightarrow{X_{\rm bottom}(G_0)^{-1}}o_{v+1},
  H_h,o_h,a_h,b_h,\\
a_{h+1}
 &\xrightarrow{X_{\rm top}(G_1)}b_{j-1},a_j,o_j,
  e_{j-1}
  \xrightarrow{X_{\rm bottom}(G_1)^{-1}}o_{h+1},
  e_h,I_h,H_t,o_t
  \xrightarrow{W_R}o_{s+1},H_j,I_j,e_s,\\
 &\xrightarrow{X_{\rm bottom}(L)^{-1}}o_{j+1},
  e_j,b_j,a_{j+1}
  \xrightarrow{X_{\rm top}(L\cup R)}b_{t-1},a_t,b_t.
\end{split}                                                   \tag{5}
\]
When \(G_1\) is empty (\(j=h+1\)), replace its
top-and-bottom passage by \(b_h,a_j,o_j,e_h\).
The displayed \(o_t\xrightarrow{W_R}o_{s+1}\)
means one occurrence of that vertex when \(R\) is empty.

Every join in (5) is an edge. In addition to old-cycle
edges and face chords, the nonordinary joins are
\(o_{v+1}H_h\), \(I_hH_t\),
\(o_{s+1}H_j\), and \(I_je_s\) from (2);
the returns use retained
\(P_{j-1}=e_{j-1}o_j\), \(P_h=e_ho_{h+1}\), and
\(P_j=e_jo_{j+1}\). If \(G_1\) is empty, its
single return is \(P_h=e_ho_j\). The fold at the
right end of \(G_0\) uses \(b_{h-1}e_{h-1}\),
and the other rail joins are consecutive old-cycle edges.
When \(R\ne\varnothing\), \(W_R\) also uses the retained
\(P_{t-1}=e_{t-1}o_t\); when \(R=\varnothing\),
\(P_{t-1}=P_s\) is missing and is not used.

The two rails of \(G_0,G_1\) partition their vertices.
The lower rails of \(L,R\), together with the upper rail
of \(L\cup R\), partition the vertices of that full
interval: the lower rails use every interior slot and the
upper rail uses every \(a,b\) pair. In \(B_h\), the
first line visits
\(H_h,o_h,a_h,b_h\) and the second visits
\(e_h,I_h\). In \(B_j\), the second line visits
\(a_j,o_j,H_j,I_j\) and the third visits
\(e_j,b_j\). In \(B_t\), the second line visits
\(H_t,o_t\) and the third visits \(a_t,b_t\), leaving
precisely \(I_t,e_t\). These sets are disjoint and
exhaust \(B_{v+1},\ldots,B_t\), so (5) is the stated
simple path \(U\).

Now set
\[
 A:\quad e_t,I_t,e_v,b_v\xrightarrow{U}b_t.
                                                               \tag{6}
\]
The edge \(e_vI_t\) is in (2), and the other two
prefix edges belong to the old cycle. Thus \(A\) covers
\(e_v,b_v\) and all blocks through \(B_t\). If
\(J\) is empty, put \(D=A\). Otherwise its retained
ordinary links give crossed rails, and put
\[
 D:\quad e_{u-1}
 \xrightarrow{X_{\rm bottom}(J)^{-1}}o_{t+1},
 e_t\xrightarrow{A}b_t,a_{t+1}
 \xrightarrow{X_{\rm top}(J)}b_{u-1}.
                                                               \tag{7}
\]
The joins \(o_{t+1}e_t\) and \(b_ta_{t+1}\)
are respectively the retained link \(P_t\) and an
old-cycle edge. The two rails span \(J\), disjoint
from \(A\), proving (4). \(\square\)

**A planar Barnette family.** Choose arbitrary integers
\(\alpha,\gamma\ge1\), \(\beta\ge0\), and
\(1\le\kappa\le\gamma\). Put
\[
 v=3,\quad h=\alpha+4,\quad
 j=\alpha+\beta+5,\quad
 t=\alpha+\beta+\gamma+6,\quad
 s=j+\kappa,\quad u=t+1,\quad z=u+1=r.             \tag{8}
\]
Use Note 281(8)'s old Hamilton cycle with \(\ell=1\).
Make exactly \(B_1,B_3,B_h,B_j,B_t,B_u,B_z\)
vacant, and all other internal blocks short. Retain
every ordinary link except \(P_1,P_3,P_s\).
Besides Note 281's unchanged site, face, escape, and
residual-square edges, take the free matching edges
\[
\begin{array}{ll}
H_1I_z,\ I_1H_z;&\mathcal C=\{V_1,V_z\},\\
e_1I_u,\ o_2H_3,\ I_3H_u;&
 \mathcal P=\{P_1,V_3,V_u\},\\
e_3I_t,\ o_4H_h,\ I_hH_t;&
 \mathcal Q=\{P_3,V_h,V_t\},\\
H_jo_{s+1},\ I_je_s;&
 \mathcal R=\{V_j,P_s\}.
\end{array}                                                   \tag{9}
\]
These ten edges pair all fourteen vacancy slots and
six missing-link slots once. Each joins opposite
old-cycle colours. In the opposite-side disk,
\(H_1I_z\) encloses \(I_1H_z\); \(e_1I_u\)
encloses the other displayed port chords;
\(I_3H_u\) encloses the \(\mathcal Q,\mathcal R\)
chords; and \(e_3I_t\) encloses the two disjoint
subregions delimited by \(o_4H_h\) and
\(I_hH_t\). The \(\mathcal R\) chords nest inside
\(I_hH_t\): their endpoints occur in the order
\(H_j,I_j,e_s,o_{s+1},H_t\). Retained ordinary links lie in the
resulting nested or disjoint intervals. The graph is
therefore simple, cubic, bipartite, and plane, with the
two site edges still cofacial.

For three-connectivity, the retained ordinary links
interlace consecutive face chords \(F_i=a_ib_i\)
except at the three missing links. The following
interlacement paths bridge the three breaks:
\[
\begin{array}{ll}
P_1:&F_1-F_u-F_3-F_2
       \quad(e_1I_u,\ I_3H_u,\ o_2H_3),\\
P_3:&F_3-F_t-F_h-F_4
       \quad(e_3I_t,\ I_hH_t,\ o_4H_h),\\
P_s:&F_s-F_j-F_{s+1}
       \quad(I_je_s,\ H_jo_{s+1}).
\end{array}                                                   \tag{10}
\]
Each displayed edge interlaces the two indicated face
chords. These paths and all retained links connect the
entire face-chord chain. Every other displayed matching
chord interlaces a face chord at one endpoint block;
Note 281's retained end links attach the unchanged site
and residual-square closing chain. Thus the full
matching-chord interlacement graph is connected. Notes
217 and 182 give three-vertex connectivity. The site
expansion is legal by Note 182, and its Hamilton lift
follows from Notes 305 and 001.

The outer component \(\mathcal P\) has the two
anchors \(e_1I_u,I_3H_u\) of Note 305. Its final
gap has the cap (6), since \(u=t+1\); its first gap
\(B_2\) is covered on the old cycle. Hence the parent
has a Hamilton cycle through both site edges, and the
legal child has a Hamilton cycle. With
seven vacant blocks and \(r=z=\alpha+\beta+\gamma+8\),
their orders are
\[
 12+4r+14=58+4(\alpha+\beta+\gamma),
 \qquad 62+4(\alpha+\beta+\gamma).              \tag{11}
\]
The smallest member has 66 and 70 vertices. The
genuinely earlier-port cases \(s<t-1\) begin at
70 and 74 vertices.

**One-vacancy inner port.** There is also a shorter
backward-port cap. Let \(v<j<s<t<u\), with
\(j\ge v+1\), and assume the fixed matching edges are
\[
 I_vH_u,\quad e_{u-1}o_u,\quad
 e_vI_t,\quad o_{v+1}H_t,\quad
 H_jo_{s+1},\quad I_je_s.                           \tag{12}
\]
Retain every ordinary link from \(P_v\) through
\(P_{u-1}\) except \(P_v,P_s\). The component
\(\{P_v,V_t\}\) now has only one vacancy; the
backward component is \(\{V_j,P_s\}\).
Put \(G=B_{v+1},\ldots,B_{j-1}\),
\(L=B_{j+1},\ldots,B_s\), and
\(R=B_{s+1},\ldots,B_{t-1}\). The latter two
intervals have the same meanings as in (3);
\(G,R\) may be empty, while \(L\ne\varnothing\).
Define \(W_R\) as before.

If \(G\ne\varnothing\), construct
\[
\begin{split}
U:\quad b_v,a_{v+1}
 &\xrightarrow{X_{\rm top}(G)}b_{j-1},
 a_j,o_j,e_{j-1}
 \xrightarrow{X_{\rm bottom}(G)^{-1}}o_{v+1},
 H_t,o_t\xrightarrow{W_R}o_{s+1},\\
 &H_j,I_j,e_s
 \xrightarrow{X_{\rm bottom}(L)^{-1}}o_{j+1},
 e_j,b_j,a_{j+1}
 \xrightarrow{X_{\rm top}(L\cup R)}b_{t-1},a_t,b_t .
\end{split}                                                   \tag{13}
\]
If \(G=\varnothing\), replace its initial upper
and lower passage by \(b_v,a_j,o_j\), followed
directly by \(H_t\). Every join in (13) is an
old-cycle edge, a face chord, one of (12), or a
retained link: the special links at the folds are
\(P_{j-1}\) when \(G\ne\varnothing\),
\(P_j\), and \(P_{t-1}\) when \(R\ne\varnothing\).
No missing link is used. The two rails of \(G\),
the lower rails of \(L,R\), and the upper rail
of \(L\cup R\) cover their respective blocks
once. In \(B_j\), the four portions use
\(a_j,o_j,H_j,I_j,e_j,b_j\) in that order;
in \(B_t\), they use \(H_t,o_t,a_t,b_t\),
omitting exactly \(I_t,e_t\). Thus \(U\)
spans \(B_{v+1},\ldots,B_t\) except \(I_t,e_t\).
The cap (6)--(7), with this \(U\), has exactly
the vertex set and endpoints (4). This proves
the one-vacancy inner-port theorem, including
the adjacent case \(j=v+1\). \(\square\)

This shorter pattern also occurs in Barnette graphs
at every allowed distance. Choose
\(\alpha,\rho\ge0\), \(\kappa\ge1\), and set
\[
 v=3,\quad j=4+\alpha,\quad s=j+\kappa,\quad
 t=s+\rho+1,\quad u=t+1,\quad z=u+1=r.             \tag{14}
\]
Use the same old cycle and fixed site, face, escape,
and residual-square edges as in (8). Make exactly
\(B_1,B_3,B_j,B_t,B_u,B_z\) vacant, retain all
ordinary links except \(P_1,P_3,P_s\), and use
\[
\begin{array}{ll}
H_1I_z,\ I_1H_z;&\{V_1,V_z\},\\
e_1I_u,\ o_2H_3,\ I_3H_u;&\{P_1,V_3,V_u\},\\
e_3I_t,\ o_4H_t;&\{P_3,V_t\},\\
H_jo_{s+1},\ I_je_s;&\{V_j,P_s\}.
\end{array}                                                   \tag{15}
\]
These nine edges pair the twelve vacancy slots and
six missing-link slots exactly once and join opposite
old-cycle colours. On the opposite side of the old
cycle, \(e_3I_t\) encloses \(o_4H_t\), which
encloses the nested pair
\(H_jo_{s+1},I_je_s\); the unchanged outer
chords nest around them. All retained ordinary
links are disjoint or nested, so the parent is
plane, simple, cubic, and bipartite.

For \(F_i=a_ib_i\), the three missing-link breaks
are bridged in the interlacement graph by
\[
\begin{array}{ll}
P_1:&F_1-F_u-F_3-F_2,\\
P_3:&F_3-F_t-F_4,\\
P_s:&F_s-F_j-F_{s+1}.
\end{array}                                                   \tag{16}
\]
Each step is supplied by the corresponding edge
of (15); every retained link joins consecutive
face chords. All remaining special chords
interlace endpoint face chords, and the unchanged
closing chain of Note 281 attaches the site and
residual square. Notes 217 and 182 therefore
give three-vertex connectivity and a legal site
expansion. The outer component
\(\{P_1,V_3,V_u\}\) has Note 305's anchors
\(e_1I_u,I_3H_u\), and its final gap has the
cap just proved. Hence the parent has a Hamilton
cycle through both site edges and the child has
a Hamilton cycle. Their orders are
\[
 12+4r+12=52+4(\alpha+\kappa+\rho),\qquad
 56+4(\alpha+\kappa+\rho).                           \tag{17}
\]
They begin at 56 and 60 vertices when
\((\alpha,\kappa,\rho)=(0,1,0)\).

This theorem resolves the stated backward-port final-gap
interfaces, with one or two vacancies in the inner
forward component, at every interior port position
and unbounded block distances. It does not show
that every two-defect rooted final gap, every free group,
or every Barnette graph has the same linkage.
