> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Actual planar fibres realize support-three circuits but add compatibility chords

[Note 056](056-integral-two-path-strengthening-fails-while-the-fractional-degree-box-survives.md)
shows abstractly that fractional degree-box feasibility does not force an
equal-weight support-two certificate. The three-state obstruction can occur
inside the complete fixed fibre of an actual planar cubic bipartite brace.
It is repaired only by additional states in the full fibre.

## Compatibility language

For \(J\) in a fixed fibre, put

\[
e(J)=d(J)-2\mathbf 1,\qquad
P(J)=\{y:e(J)_y=1\},\qquad
N(J)=\{y:e(J)_y=-1\}.
\tag{1}
\]

Two forests \(J_1,J_2\) give an equal-weight support-two certificate exactly
when

\[
e(J_1)+e(J_2)\le0,
\tag{2}
\]

or equivalently

\[
P(J_1)\subseteq N(J_2),\qquad
P(J_2)\subseteq N(J_1).
\tag{3}
\]

## A support-three circuit in a complete planar fibre

Take the simple plane cubic bipartite brace

    K??FEagT@WB_

with root \(r=0\), ports \((6,7,8)\), and fixed split
\(\{6\}\mid\{7,8\}\). In the coordinate order
\(Y\setminus\{r\}=(1,2,3,4,5)\), its complete fibre contains forests
\(A,B,C\) with

\[
\begin{aligned}
d(A)&=(1,2,3,1,2),& e(A)&=(-1,0,1,-1,0),\\
d(B)&=(2,1,1,2,3),& e(B)&=(0,-1,-1,0,1),\\
d(C)&=(2,1,2,3,1),& e(C)&=(0,-1,0,1,-1).
\end{aligned}
\tag{4}
\]

Their edge sets are

\[
\begin{aligned}
A=\{&16,28,2\,10,37,39,3\,11,4\,11,59,5\,10\},\\
B=\{&17,19,26,3\,11,48,4\,10,59,5\,10,5\,11\},\\
C=\{&16,19,2\,10,37,3\,11,48,4\,10,4\,11,59\}.
\end{aligned}
\tag{5}
\]

Here \(2\,10\), for example, denotes the edge \(\{2,10\}\). On the last
three coordinates, the excess vectors contain the directed circuit

\[
(1,-1,0),\qquad(-1,0,1),\qquad(0,1,-1).
\tag{6}
\]

Moreover,

\[
\frac13(e(A)+e(B)+e(C))
=\left(-\frac13,-\frac23,0,0,0\right)\le0,
\tag{7}
\]

while none of the six pairs from \(\{A,B,C\}\), allowing repetition,
satisfies (2). Thus this is an inclusion-minimal box-feasible support with
no compatible pair.

The verifier exhausts the fixed fibre: it has 22 forests and 13 distinct
degree vectors. Define its same-\(X\) pivot graph by joining
\(J\) to \(J-f+g\) when \(f,g\) meet the same \(X\)-vertex and the new
forest remains in the same port fibre. This graph has 35 edges and is
connected. Therefore cubicity, bipartiteness, planarity, the brace strict
Hall inequalities, actual forest incidence, and ordinary same-\(X\) pivot
connectivity do not exclude the support-three circuit.

## The complete fibre repairs the circuit by compatibility chords

The circuit is repaired by states outside \(\{A,B,C\}\). Three explicit
one-pivot chords are

\[
\begin{array}{c|c|c}
\text{pivot}&\text{new degree vector}&\text{compatible target}\\ \hline
A-5\,10+4\,10&(1,2,3,2,1)&B\\
A-3\,11+5\,11&(1,2,2,1,3)&C\\
B-5\,11+4\,11&(2,1,1,3,2)&A.
\end{array}
\tag{8}
\]

The complete fibre also contains the three integral box vectors

\[
(1,2,2,2,2),\qquad(2,1,2,2,2),\qquad(2,2,2,2,1).
\tag{9}
\]

Hence this brace is not a counterexample to support two; in fact it already
has support one. Its significance is that the full family must add a
compatible chord rather than forbid the minimal circuit.

## Projected unit-transfer connectivity is insufficient

Even adding a connected degree-unit transfer graph to the abstract axioms
does not force support two. Consider the ten excess vectors

\[
\begin{aligned}
&(-1,-1,-1,1,1),\quad (-1,-1,0,0,1),\quad
(-1,0,-1,1,0),\\
&(-1,0,0,1,-1),\quad (-1,0,1,0,-1),\quad
(-1,1,-1,0,0),\\
&(-1,1,-1,1,-1),\quad (0,0,-1,1,-1),\quad
(0,1,-1,-1,0),\\
&(1,-1,-1,1,-1).
\end{aligned}
\tag{10}
\]

Every vector belongs to \(\{-1,0,1\}^5\) and has total sum \(-1\). Join
two vectors when their difference has \(\ell_1\)-norm two. This
unit-transfer graph is connected, has 13 edges, and has diameter four.
Nevertheless every pair, allowing repetition, has a positive sum
coordinate. The second, ninth and tenth vectors with weights
\((1/4,1/2,1/4)\) average to

\[
(0,0,-3/4,-1/4,0)\le0.
\tag{11}
\]

Thus the fractional box, all universal coordinate and total-sum identities,
and connected projected unit-transfer dynamics still do not imply support
two. Model (10) is abstract and is not asserted to be a forest fibre.

## Remaining full-family interface

Along the local-exchange route, the following statement would suffice.

> **Boundary-chord lemma.** Let \(\mathcal S\) be an inclusion-minimal
> support of a box-feasible distribution in an actual fixed fibre. If
> \(\mathcal S\) has no compatible pair, then some same-\(X\) pivot
> \(J\to J'\), with \(J\in\mathcal S\), produces a forest \(J'\) compatible
> with some \(K\in\mathcal S\).

Indeed, the chord immediately supplies the required pair \(J',K\). The
planar fibre above satisfies the lemma through (8), while (10) proves that
its proof must use the actual graphic--partition incidence rather than only
degree-vector adjacency.

The boundary-chord lemma is not proved here. It may fail in a larger actual
fibre, and support two remains undecided for arbitrary simple cubic
bipartite braces. Exact reproduction is provided by
[the permanent verifier](../computations/verify_actual_support_three_and_connected_exchange_boundary.py),
which ends with
**ACTUAL_SUPPORT_THREE_AND_CONNECTED_EXCHANGE_BOUNDARY_VERIFIED**.
