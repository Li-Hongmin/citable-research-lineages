> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Facing target vacancies reduce to one mixed terminal core

[Note 232](232-facing-target-bearing-vacancies-are-hamiltonian.md)
classifies a group with exactly two facing target-bearing vacancies.
[Notes 319--321](321-standard-link-sweep-settles-one-one-sided-target-vacancy.md)
allow arbitrarily many additional target-free vacancies to be
removed from its port components. The only terminal arrangement
not covered by Note 232's three base routes has one distinguished
component with a port and the other port-free.

Use a compressed, gapless, tight-target all-square opening of a
Barnette parent. Every eligible vacancy lies in a distinct block.
Exactly two vacancy blocks are target-bearing internal blocks
\(B_k<B_m\). Their vacancies are facing: \(L=(h_L,i_L)\) is the
last eligible position after a nonempty target run in \(B_k\),
\(R=(h_R,i_R)\) is the first eligible position before a nonempty
target run in \(B_m\), and no occupied target lies between them.
Every other vacancy is in a target-free internal block. The
free-slot group between the two target runs has order
\[
 h_L,i_L,e_L,\quad B_{k+1},\ldots,B_{m-1},
 \quad o_R,h_R,i_R,                                  \tag{1}
\]
where each complete intervening block is short or singly vacant.
Its possible ordinary links are the consecutive pairs
\(P_j=(E_j,O_j)\) from \(e_L\) to \(o_R\), as in Note 232.

**Two-terminal reduction theorem.** The free matching on (1)
gives a noncrossing partition of its vacancy and missing-link
port atoms, with at most one port per component. There is a
finite sequence of exact Note 317 compressions and Note 315
cube folds, touching only complete target-free blocks, after
which every component without \(L\) or \(R\) has no port, and
every component containing \(L\) or \(R\) has no target-free
vacancy atom if it contains a port.

The reduced group has one of the following outcomes:

1. no port remains;
2. \(L,R\) lie in one component with a port, which is
   exactly \(\{L,P_a,R\}\);
3. they lie in separate port components, exactly
   \(\{L,P_a\}\) and \(\{P_b,R\}\), with \(a<b\);
4. they lie in separate components, exactly one of which
   contains a port; the other is port-free and has at least
   one additional target-free vacancy atom.

In outcomes 1--3 the parent has a Hamilton cycle through both
site edges and its legal site-expanded child is Hamiltonian.
Outcome 4 is a necessary remaining shape, not an assertion
that a Hamilton cycle is absent. The reductions preserve
Barnette membership, the marked opening, and all exterior
Hamilton linkage choices in both directions.

**Proof of atom structure.** Note 215's even-prefix argument
closes the group (1) at its two occupied target runs. The
terminal triples have no internal free matching edge: their
opposite-colour pairs are old-cycle edges, as in Note 232.
The target-free complete blocks have no same-block ordinary chord.
Indeed, if \(o_je_j\) were such a chord, the parity argument
of Note 276 forces the mate of \(h_j\) to be a vacancy slot
\(i_t\), and then forces a second same-block chord \(o_te_t\)
in the endpoint block. If \(t\) is complete, repeat this mate
rule over all complete blocks with \(oe\) chords. They form
finite noncrossing alternating components; the full span of
one component, from its first to last block, is matching-closed
and gives a two-edge cut, by the corrected argument of Note 276.
If \(t=L\) or \(R\), its one-sided terminal fragment has no
second free ordinary endpoint, so parity already fails. The
alternative mate of \(h_j\) at an ordinary slot fails the
same even-interior parity test, as in Note 276. No ordinary
matching edge can skip or run backward around a complete block
interval: noncrossing would close that interval into a two-edge
cut. Thus every ordinary-to-ordinary edge is a standard link
\(P_j\). Cross-block free chords lie in the opposite-side disk
by Note 193 and do not cross. Virtual arcs at missing links
and old-cycle vacancy pairs form the noncrossing atom partition.

No atom component is a singleton, because each boundary pair's
own edge is absent from the free matching. Two ports cannot share
one component: the complete target-free block interval between
consecutive ports of that component has all matching edges
internal and only its two end old-cycle edges leaving, contrary
to three-edge-connectivity. This is Note 278's cut argument,
valid also for the two boundary ordinary slots in (1).

**Proof of reduction.** Let \(\mathcal L,\mathcal R\) be the
components of the leftmost atom \(L\) and rightmost atom \(R\),
possibly the same component. Among all other port components,
choose one of minimum atom span. Its port \(P\) has a neighboring
target-free vacancy \(W\) in that component. Any component with
an atom in the proper gap \((P,W)\) lies wholly inside it by
noncrossing. It cannot contain a port by minimum span; it also
cannot be \(\mathcal L\) or \(\mathcal R\), since those contain
the global leftmost or rightmost atom outside the gap. The
complete block interval between \(P,W\) is nonempty, for an
adjacent owned vacancy would force an old-cycle edge into the
matching. It has retained internal ordinary links and an
internally closed vacancy matching. Compress it by Note 317,
then fold the square and \(W\) by Note 315. The port is repaired
or loses \(W\), while both distinguished components are
untouched. Repeat until no other port component remains.

If \(\mathcal L=\mathcal R\) and it has a port, that port lies
between \(L,R\). If the two distinguished components differ,
their spans are disjoint: one begins at the global leftmost
atom and the other ends at the rightmost, so nesting is
impossible and interlacing is forbidden. Consequently a proper
gap from either distinguished port to an adjacent target-free
vacancy contains no remaining port. Compress and fold these
gaps until each port-bearing distinguished component contains
only its terminal atom and port. At every step a target-free
vacancy disappears; the terminal atoms and target runs remain.
There are at most two port-bearing distinguished components,
which gives outcomes 1--4. In outcome 4 the port-free component
has another atom because singleton components are impossible;
that atom is a target-free vacancy.

**Hamilton routes in outcomes 1--3.** Port reduction in all
other free groups uses the same minimum-span argument of
Note 321, since their vacancies are in distinct complete
target-free blocks. In outcome 1 every ordinary link in the
opening is retained, so Note 321's standard-link sweep applies.
In outcomes 2--3, every vacancy component other than the
displayed terminal components lies in a complete target-free
closed interval. Compress maximal such intervals by Note 317.
The reduced graph has exactly the two facing target-bearing
vacancies and no other vacancy. Outcome 2 gives Note 232's
one-detour matching \(\{h_Li_R,i_LE_a,O_ah_R\}\);
outcome 3 gives its two-detour matching
\(\{i_LE_a,h_LO_a,i_RE_b,h_RO_b\}\). Note 232 supplies
the marked Hamilton parent cycle in both cases. Reverse every
exact replacement and use Notes 001 and 182 for the legal
child and original lobe lengths. \(\square\)

The one-port/port-free mixed terminal core in outcome 4 may
contain arbitrarily many target-free vacancy atoms in its
port-free component. The theorem narrows that group without
assuming a bound on their number or nesting. It does not cover
same-block repeated vacancies, site-block vacancies, positive
gaps, defective target order, nonsquare residual cycles, or
general Barnette graphs. No external priority claim is made.
