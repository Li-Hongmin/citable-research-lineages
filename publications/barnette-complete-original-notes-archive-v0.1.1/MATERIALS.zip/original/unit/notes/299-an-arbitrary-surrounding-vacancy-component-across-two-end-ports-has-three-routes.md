> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An arbitrary surrounding vacancy component across two end ports has three routes

[Note 298](298-both-end-ports-of-a-two-sided-shared-vacancy-component-have-three-routes.md)
lets both port components grow without bound when the vacancy-only
component through their shared block has three atoms. The latter
component can also grow without bound on either side. Its alternating
cycle is opened once for the straight route, while successive
crossed folds absorb its extra blocks in the crossed route. The cap
route always takes one old-cycle arc.

Use the compressed, gapless, tight-target all-square opening of
[Notes 275](275-every-vacancy-only-noncrossing-matching-is-marked-hamiltonian.md)
and [278](278-missing-chain-ports-separate-and-three-free-vacancies-are-hamiltonian.md).
Each vacancy is in a distinct target-free internal face-chord block.
Fix a free group with retained ordinary end links and exactly two
missing ordinary links \(P_s=e_so_m\), \(P_m=e_mo_{m+1}\), where
\(m=s+1\). The block \(B_s\) may be short or vacant.
Let \(a,b,p,q\ge1\) and
\(h=a+b+1\). Choose an outer component's vacant blocks
\[
 z_1<\cdots<z_a=i<m=z_{a+1}<z_{a+2}<\cdots<z_h=w,
                                                               \tag{1}
\]
and port-component vacant blocks
\[
 i<j_1<\cdots<j_p\le s-1,
 \qquad m+2\le u_1<\cdots<u_q<z_{a+2}.            \tag{2}
\]
Put \(Q=B_{z_1},\ldots,B_w\). The three distinguished
alternating atom components are
\[
 \{V_{z_1},\ldots,V_{z_h}\},\qquad
 \{V_{j_1},\ldots,V_{j_p},P_s\},\qquad
 \{P_m,V_{u_1},\ldots,V_{u_q}\}.                 \tag{3}
\]
Their complementary-matching edges are exactly
\[
\begin{array}{ll}
 H_{z_1}I_w,\quad I_{z_t}H_{z_{t+1}}\ (1\le t<h);&\\
 H_{j_1}o_m,\quad I_{j_t}H_{j_{t+1}}\ (1\le t<p),
 \quad I_{j_p}e_s;&\\
 e_mI_{u_q},\quad o_{m+1}H_{u_1},\quad
 I_{u_t}H_{u_{t+1}}\ (1\le t<q).&
\end{array}                                           \tag{4}
\]
Every other ordinary link of the group is retained.
Noncrossing puts all other components meeting \(Q\) inside
proper gaps between successive displayed atoms. They are
vacancy-only. Each nonempty such gap \(G\) has Note 275's
spanning straight route \(S(G)\) and disjoint crossed rails
\[
 T(G):a_{\min G}\longleftrightarrow b_{\max G},\qquad
 D(G):o_{\min G}\longleftrightarrow e_{\max G}.        \tag{5}
\]
In particular, the nonempty terminal left interval
\(E=B_{j_p+1},\ldots,B_s\) is closed under its vacancy
matching: an atom in it paired outside would interlace
the left-port component or the surrounding component.
All its internal ordinary links are retained. Note 275
therefore gives its \(S(E)\) and \(K(E)\) routes, with
\(K(E)\) paths
\[
 K_L(E):a_{j_p+1}\longleftrightarrow o_{j_p+1},
 \qquad K_R(E):e_s\longleftrightarrow b_s.          \tag{5a}
\]

**Three-component unbounded routing theorem.** For all
\(a,b,p,q\ge1\), \(Q\) has vertex-spanning states
\[
\begin{array}{ll}
 S(Q):&o_{z_1}\longleftrightarrow e_w,\\
 K(Q):&a_{z_1}\longleftrightarrow o_{z_1},\quad
       e_w\longleftrightarrow b_w,\\
 X(Q):&a_{z_1}\longleftrightarrow b_w,\quad
       o_{z_1}\longleftrightarrow e_w.
\end{array}                                           \tag{6}
\]
All four component-size parameters, every proper gap length,
and the depth and number of vacancy-only components inside the
closed gaps are unbounded. Surrounding and serially disjoint
vacancy-only parts compose with (6). If every other free group
has an ordinary-endport spanning route, the parent has a Hamilton
cycle through both site edges and its legal expanded child is
Hamiltonian.

**Proof.** We use two folds. The first,
\(F(x,y):b_x\leadsto e_x\), is Note 297(6): it covers
\(G(x,y)=B_{x+1},\ldots,B_{y-1}\) by the two crossed rails,
joining them at \(b_{y-1}e_{y-1}\); for \(y=x+1\) it is
the old-cycle edge \(b_xe_x\). The second fold,
\(\Phi(x,y):o_y\leadsto b_y\), covers the same gap and
the \(o_y,a_y,b_y\) vertices of its right block:
\[
 \Phi(x,y)=\begin{cases}
 o_y,a_y,b_y,&y=x+1,\\
 o_y,e_{y-1}\xrightarrow{D(G(x,y))^{-1}}o_{x+1},
 a_{x+1}\xrightarrow{T(G(x,y))}b_{y-1},a_y,b_y,
 &y\ge x+2.
 \end{cases}                                           \tag{7}
\]
The first and final joins in the second row are retained
ordinary links or old-cycle edges; \(o_{x+1}a_{x+1}\)
is an old-cycle edge. The two rails are disjoint and span
the gap. Thus both folds use their stated vertices once.

Write the surrounding component's reverse alternating walk as
\[
 \Omega:\quad I_{z_1},H_{z_1},
 (I_{z_t},H_{z_t})_{t=h,h-1,\ldots,2},o_{z_2}.
                                                               \tag{8}
\]
The parenthesized pairs are concatenated in decreasing index
order. The first and last joins are old-cycle edges; the
long jump \(H_{z_1}I_w\) and every jump
\(H_{z_t}I_{z_{t-1}}\) for \(t\ge3\) are in (4).
Hence (8) visits all outer vacancy slots, once each, and
ends at the ordinary slot \(o_{z_2}\).

We also need a left-port chain ending at \(b_s\), rather
than at \(e_s\). Follow the first \(p-1\) passages of
Note 297(8). Replace its final passage by
\[
 H_{j_p},o_{j_p},a_{j_p},b_{j_p},a_{j_p+1}
 \xrightarrow{K_L(E)}o_{j_p+1},e_{j_p},I_{j_p},e_s
 \xrightarrow{K_R(E)}b_s.                           \tag{8a}
\]
Call the resulting path \(\Lambda^*:H_{j_1}\leadsto b_s\).
The joins into and out of \(K_L(E)\) are, respectively,
an old-cycle edge and the retained ordinary link
\(e_{j_p}o_{j_p+1}\); \(I_{j_p}e_s\) is in (4).
The two \(K(E)\) paths cover \(E\) once. Thus
\(\Lambda^*\) covers all left-port blocks, their internal
gaps, and \(E\), exactly once. Let \(\Lambda_K^*\) omit
only \(H_{j_1},o_{j_1}\) from its first passage, so it
starts at \(a_{j_1}\) and ends at \(b_s\). This definition
also applies when \(p=1\), in which case the two omitted
vertices come from (8a).

We describe an ordinary continuation used by the straight
routes. Starting at an ordinary \(o\) slot and moving right,
traverse every displayed vacant block's ordinary vertices
as \(o_t,a_t,b_t,e_t\). Traverse each maximal closed proper
gap by \(S(G)\), joined at its retained ordinary links;
an empty gap uses its direct retained link. Replace the two
missing links by their actual alternating paths
\[
 J_L:\ e_s,(I_{j_t},H_{j_t})_{t=p,p-1,\ldots,1},o_m,
 \qquad
 J_R:\ e_m,(I_{u_t},H_{u_t})_{t=q,q-1,\ldots,1},o_{m+1}.
                                                               \tag{9}
\]
Each pair in (9) is joined by the old-cycle vacancy edge;
the jumps are precisely the corresponding edges of (4).
The terminal interval through \(B_s\) is traversed before reaching
\(e_s\): use \(S(E)\) from \(o_{j_p+1}\) to \(e_s\),
joined to \(B_{j_p}\) by the retained link
\(e_{j_p}o_{j_p+1}\). Then \(J_L\) jumps directly to
\(o_m\). The nonempty first right gap starts at \(o_{m+1}\)
after \(J_R\). Thus the ordinary continuation is one path:
it covers all ordinary slots, the two port components' vacancy
slots through (9), and all extra vacancy-only components through
the \(S\) routes. It omits just the outer component's vacancy
slots, which (8) supplies.

For \(a\ge2\), the straight path is
\[
 o_{z_1},a_{z_1},F(z_1,z_2),\Omega,
 \text{ordinary continuation from }o_{z_2}\text{ to }e_w.
                                                               \tag{10}
\]
The face chord \(a_{z_1}b_{z_1}\) enters \(F\), and
the old-cycle edge \(e_{z_1}I_{z_1}\) enters \(\Omega\).
The first gap is closed and contains no port because
\(z_2\le i<j_1\). The fold covers it once; the ordinary
continuation starts only at \(B_{z_2}\). Equation (8)
supplies precisely the outer vacancy slots omitted by the
continuation, so (10) is a spanning path.

For \(a=1\), the first outer gap contains the left port.
Use Note 297's left fold \(F(i,j_1)\), port chain
\(\Lambda^*:H_{j_1}\leadsto b_s\) from (8a).
Replace (10) by
\[
 o_i,a_i,F(i,j_1),\Omega,\Lambda^*,a_m,b_m,
 \text{right ordinary continuation from }e_m\text{ to }e_w.
                                                               \tag{11}
\]
Here (8) ends at \(o_m\), which joins \(\Lambda^*\)
through \(o_mH_{j_1}\); \(\Lambda^*\) ends at \(b_s\),
which joins \(a_m\) by an old-cycle edge. The last
continuation starts across \(b_me_m\) with \(J_R\) of (9).
The disjoint left folds and the modified port chain (8a)
cover all blocks from \(B_i\) through \(B_s\); the right
continuation covers all remaining ordinary and right-port
vertices. All outer vacancy slots occur in (8). This proves
\(S(Q)\) in both cases.

For the cap state, leave \(e_wb_w\) as the second path.
When \(a=1\), use the left path of Note 297(14)--(15),
with its final index \(w\) replaced by the present \(z_h\):
\[
 a_i,b_i,\text{top of }G(i,j_1),a_{j_1},
 \Lambda_K^*,a_m,o_m,H_{j_1},o_{j_1},
 \text{bottom of }G(i,j_1)^{-1},e_i,I_i,H_m
 \xrightarrow{C\text{ forward}}I_w,H_i,o_i.
                                                               \tag{12}
\]
Empty-gap passages in (12) mean the direct retained joins,
and \(\Lambda_K^*\) begins at \(a_{j_1}\). The old-cycle
arc from \(H_m\) to \(I_w\) covers every right block,
including all extra outer atoms, and leaves only \(e_w,b_w\).

When \(a\ge2\), the first outer gap is closed. Take
\[
 a_{z_1},b_{z_1},\text{top of }G(z_1,z_2),a_{z_2},o_{z_2},
 \text{bottom of }G(z_1,z_2)^{-1},e_{z_1},I_{z_1},H_{z_2}
 \xrightarrow{C\text{ forward}}I_w,H_{z_1},o_{z_1}.
                                                               \tag{13}
\]
The two rails cover the first gap once; an empty gap again
uses direct joins. Edges \(I_{z_1}H_{z_2}\) and
\(I_wH_{z_1}\) are in (4). The long old-cycle arc begins
after \(a_{z_2},o_{z_2}\) and ends before \(e_w,b_w\),
so (13) and the cap edge partition every vertex of \(Q\).
This proves \(K(Q)\).

For the crossed state, take the bottom path
\[
 o_{z_1},H_{z_1},I_w,e_w.                         \tag{14}
\]
Construct a top prefix \(L_X:a_{z_1}\leadsto I_i\).
If \(a=1\), let \(L_X=a_i,F(i,j_1),I_i\), with
\(a_ib_i\) entering the fold. If \(a\ge2\), start
\[
 a_{z_1},b_{z_1},e_{z_1},I_{z_1},              \tag{15}
\]
then, for \(t=2,\ldots,a\), take the matching edge
\(I_{z_{t-1}}H_{z_t}\), the old-cycle edge
\(H_{z_t}o_{z_t}\), and \(\Phi(z_{t-1},z_t)\).
For \(t<a\), continue from its end \(b_{z_t}\) through
\(e_{z_t},I_{z_t}\). For \(t=a\), continue instead
through \(F(i,j_1),I_i\). Each \(\Phi\) covers the
gap before its new outer block and its \(o,a,b\) slots;
each later \(e,I\) pair completes that block. The final
\(F\) covers the gap before the first left-port vacancy
and the remaining \(e_i\) slot. Thus \(L_X\) covers
every left outer block except \(o_{z_1},H_{z_1}\),
which are in (14), and covers its required gaps once.

Join \(L_X\) to \(H_m,o_m\) through the matching edge
\(I_iH_m\), then take \(\Lambda^*,a_m,b_m\).
For the right port, take the path \(R_X^{\rm core}:b_m\leadsto I_m\)
obtained from Note 298(12) or (14) by stopping at \(I_m\),
before the matching edge \(I_mH_{z_{a+2}}\). Explicitly,
when \(q=1\), with \(u=u_1\) and \(R=G(m,u)\), it is
\[
 b_m,a_{m+1}\xrightarrow{T(R)}b_{u-1},e_{u-1}
 \xrightarrow{D(R)^{-1}}o_{m+1},H_u,o_u,a_u,b_u,
 e_u,I_u,e_m,I_m.                                   \tag{16}
\]
When \(q\ge2\), with \(v=u_{q-1}\), \(u=u_q\), it is
\[
 b_m\xrightarrow{C\text{ forward}}I_v,H_u,
 Z(v,u),e_u,I_u,e_m,I_m,                            \tag{17}
\]
where \(Z\) is the explicit final-gap fold of
Note 298(13). Equations (16)--(17) cover every right-port
block and every block from \(B_{m+1}\) through
\(B_{u_q}\), plus \(e_m,I_m\), exactly once.

From \(I_m\), traverse all right outer atoms in increasing
order. For \(t=a+2,\ldots,h\), take
\(I_{z_{t-1}}H_{z_t}\), then \(H_{z_t}o_{z_t}\),
then \(\Phi(v_t,z_t)\), where
\[
 v_{a+2}=u_q,
 \qquad v_t=z_{t-1}\quad(t>a+2).                  \tag{18}
\]
If \(t<h\), continue from \(b_{z_t}\) through
\(e_{z_t},I_{z_t}\); for \(t=h\), stop at \(b_w\).
The first fold covers the gap after the right-port component;
each later fold covers the gap between successive outer
atoms. Every right outer block before \(B_w\) is completed
on this path. The last block contributes \(H_w,o_w,a_w,b_w\)
here and \(I_w,e_w\) to (14).

Concatenating \(L_X\), \(H_m,o_m\), \(\Lambda^*,a_m,b_m\),
(16) or (17), and (18) yields one path from \(a_{z_1}\)
to \(b_w\). The left inventory above, the modified port
chain (8a), the right-port inventory in
(16)--(17), and the right folds (18) have disjoint vertex
sets. The final closed interval \(E\) is covered by the
two paths in (8a). Together they cover exactly the vertices
outside (14). This proves \(X(Q)\).

The constructions use each additional closed gap only through
its \(S,K,X\) signature. Note 275's prime and serial rules
therefore absorb surrounding and disjoint vacancy-only
parts. Note 273 joins the free groups; Notes 001 and 178
give the marked parent cycle, legal child cycle, and
arbitrary original lobe lengths. \(\square\)

**Analytic realization in every four-parameter size.** For
\(a,b,p,q\ge1\), use Note 281(8)--(9)'s old cycle and
unchanged site, face, escape, and residual-square edges.
Make exactly the \(h+p+q\) blocks named in (1)--(2)
vacant, retain every ordinary link except \(P_s,P_m\),
and add (4). A shortest placement is
\[
\begin{split}
 z_t&=t\quad(1\le t\le a),&
 j_t&=a+t\quad(1\le t\le p),\\
 s&=a+p+1,&m&=a+p+2=z_{a+1},\\
 u_t&=m+1+t\quad(1\le t\le q),&
 z_{a+1+t}&=m+q+1+t\quad(1\le t\le b),\\
 r&=w=h+p+q+2.&&
\end{split}                                             \tag{19}
\]
The matching (4) is perfect and joins opposite old-cycle
colours. Draw the outer edge \(H_{z_1}I_w\) around all
other free chords on the side opposite the site face.
The consecutive outer edges \(I_{z_t}H_{z_{t+1}}\)
occupy disjoint inner intervals. The left-port edges lie
nested inside \(I_iH_m\); the right-port edges lie nested
inside \(I_mH_{z_{a+2}}\). Within each port component,
the successive vacancy edges are pairwise disjoint and
the edge reaching its port surrounds them. Retained
ordinary links are nested in or disjoint from these intervals.
Hence the two-page embedding is planar and its site edges
are cofacial.

Retained links connect consecutive face chords on the left
through \(B_s\) and on the right from \(B_{m+1}\) through
\(B_w\). The edge \(I_iH_m\) interlaces the face chords
of \(B_i,B_m\) and joins the shared block to the left
chain; \(I_mH_{z_{a+2}}\) joins it to the right chain.
Every other edge of (4) interlaces a face chord at one
of its endpoint blocks. The unchanged site, escape, and
residual-square chords close Note 281's interlacement
chain. Thus the full matching-chord interlacement graph
is connected. Note 217's interval-cut argument excludes
two-edge cuts, and Note 182's cubic lemma gives
three-vertex-connectivity. The site expansion is legal
by Note 217's cut projection.

The parent and legal child in (19) have, respectively,
\[
 6(h+p+q)+20,\qquad 6(h+p+q)+24                \tag{20}
\]
vertices; both have the asserted Hamilton cycles by (6).
Inserting \(d\) short blocks into proper gaps adds \(4d\)
vertices to each order without changing the proof.
For \(h=3\), this is Note 298. For \(h=4,p=q=1\),
the two distributions \((a,b)=(2,1),(1,2)\) extend
Note 295's four-atom pattern.

The case in which \(B_s\) itself is vacant is also realized.
In (19), insert one block immediately after \(B_{j_p}\),
shift \(B_s\) and everything to its right one index to
the right, and make both the inserted block \(B_k\) and
the shifted \(B_s\) vacant. Add the vacancy-only edges
\(H_kI_s,I_kH_s\) while retaining \(P_k=e_ko_s\).
The left-port edge \(I_{j_p}e_s\) surrounds this new
two-atom component, so the two-page drawing stays planar.
The two new edges interlace endpoint face chords and the
retained links keep the chord-interlacement graph connected.
The resulting Barnette parent and child have, respectively,
\(6(h+p+q)+28\) and \(6(h+p+q)+32\) vertices. Their
Hamilton cycles follow from (6).

The theorem covers arbitrary lengths of the three
distinguished components even when the block just before
the first missing link is vacant in a nested vacancy-only
component. Further missing links, repeated or target-bearing vacancies,
positive gaps, nonsquare residual cycles, and general
Barnette graphs remain outside its scope.

**Complete two-sided shared-block two-port corollary.** Suppose a free group
under the opening hypotheses above has exactly the consecutive
missing links \(P_s,P_{s+1}\), their common block
\(B_{s+1}\) is vacant, and the
vacancy-only component containing \(V_{s+1}\) has atoms on
both sides of it. Then the whole group has \(S,K,X\), with
no bound on its number of vacancies or their spacing,
and no restriction on whether either port-adjacent block
is vacant.

Indeed, Note 278 puts the two ports in distinct components,
and Note 292 puts the shared-block vacancy in a third,
port-free component. List the latter's atoms as in (1);
both sides are nonempty by hypothesis. Noncrossing confines
the component of \(P_s\) to the gap between \(V_i\) and
\(V_m\), and the component of \(P_m\) to the gap between
\(V_m\) and \(V_{z_{a+2}}\). No atom lies between
\(P_s,V_m\) or between \(V_m,P_m\), so the first port
is last in its component and the second is first in its
component. Each needs at least one vacancy atom. Old-cycle
adjacency excludes \(V_s\) from the first component and
\(V_{m+1}\) from the second. Thus the three components
have exactly the form (1)--(4); every other component is
vacancy-only and wholly inside a proper gap or outside
the displayed interval. Apply (6), then Note 275's
surrounding and serial composition. \(\square\)
