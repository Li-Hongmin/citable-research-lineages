> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A C4 child can create every neutral target from non-target defects

[Note 077](077-wide-complete-family-gate-escape-holds-through-reduced-order-twenty-six.md)
proves that wide complete-family gate escape holds through reduced order
\(26\).  A natural route to arbitrary order is to contract a remote
\(C_4\), select a neutral target in the parent, and lift it while retaining
neutrality at the queried wide site.  This note gives an exact real
counterexample to that target-only inheritance rule and records the bounded
construction class in which it first appears.

## 1. Three targeted order-\(28\) families

Take three order-\(24\) plane cubic bipartite braces:

1. the mixed wide interface with minimum neutral-target count;
2. the mixed wide interface with minimum neutral fraction;
3. the first order-\(24\) forced-component counterexample of Note 075.

For each parent perform every legal dual-vertex split whose primal dual is
again a simple plane cubic bipartite brace of order \(28\).  In every
resulting labelled child inspect every legal wide site and every nonempty
unchanged-root complete target family.

The exact coverage is

\[
\begin{array}{lr}
\text{legal parent operations}&196,\\
\text{distinct labelled children}&190,\\
\text{legal wide child splits}&2724,\\
\text{nonempty wide target interfaces}&90896,\\
\text{wide target instances}&1573984,\\
\text{wide forced complete families}&0.
\end{array}
\tag{1}
\]

Thus all three one-step construction families retain a neutral gate escape.
This is not a complete order-\(28\) census.

There is a stronger pointwise finite property.  Among the targets in (1),
\(162492\) use both query gates.  For each such target, minimize the number
of alternating-cycle components in its symmetric difference from a neutral
target in the same complete family.  The distribution is

\[
153638\text{ at distance }1,\qquad
8854\text{ at distance }2,\qquad
0\text{ at distance at least }3.
\tag{2}
\]

Hence synchronized one- or two-cycle neutral selection suffices throughout
this construction class, although ordinary single-cycle component saturation
is false in general.

## 2. Exact failure of target descent

The first parent in Section 1 has graph6 string

    W???????????w?s?P_BC?I_?L??d??`_?@g??R??Gg??B_?

Perform the operation at dual vertex

\[
z=1,\qquad
N(z)=(2,7,9,12,11,6,3,0),
\qquad\text{gate indices }(3,7).
\]

Query the resulting child at dual vertex \(8\), with query gate neighbours
\(5,10\), and use root \(11\,13\).

The parent complete family has five targets.  Its operation-neutral targets
are indices

\[
\{3,4\},
\]

whereas its query-neutral targets are

\[
\{0,1\}.
\]

The two sets are disjoint.  Moreover, targets \(0,1\) have no lift row at
the operation site, while the only lifted targets \(3,4\) remain
double-gate at the query site.

The child nevertheless has eleven targets, of which six, with indices

\[
\{1,2,3,5,6,7\},
\tag{3}
\]

are query-neutral.  Contract each target in (3) using each of the two
possible colours at the removed parent vertex.  None of the twelve
contractions is a parent target.  The NAE contractions that remain locally
valid have cycle ranks

\[
0,\ 1,\ 2,\ 3;
\]

the rank-one contraction has the root off its unique monochromatic cycle.
Thus all six neutral child targets arise from parent colourings outside the
parent target family.

This proves:

**Non-descent theorem.** A legal \(C_4\)-expansion can create every neutral
target needed at a second wide site from parent NAE states that are not
rooted targets.  Consequently, a reduction induction cannot in general
parameterize the child neutral family only by lifted members of the parent
target family.

The theorem does not exclude an induction with a richer state space.  It
identifies the missing states: neutral NAE defects must retain at least cycle
rank and whether the root lies on the distinguished monochromatic cycle.

## 3. Correct induction boundary

The complete-family condition in Notes 076--077 is not monotone under
pointwise contraction of target states.  A child target can contract to

- a non-NAE colouring;
- a rank-zero monochromatic forest;
- a rank-one unicycle with the root off its cycle;
- or a higher-rank monochromatic graph.

A viable \(C_4\)-induction must therefore transport a defect spectrum large
enough to admit promotion of one of these states to a rooted target after
the local expansion.  Tracking only target matchings, gate loads, or
simultaneous-neutral marginals discards states that are genuinely required
in the explicit example.

The finite distance statement (2) suggests that one- and two-cycle
symmetric differences may still control the completed state space, but it
does not prove such a bound at arbitrary order.

## 4. Evidence and boundary

The complete construction-family calculation, the distance profile and the
focused non-descent witness are frozen in
[targeted-order28-wide-children](../computations/bundles/targeted-order28-wide-children/README.md).

**Exact conclusion.** The three specified one-step order-\(28\) families
have no wide forced complete family, and one explicit child has six neutral
targets none of which descends to a parent target.

**Weakest load-bearing step.** The non-descent statement tests both possible
colours at the contracted vertex for every neutral child target and evaluates
the exact NAE, component, cycle-rank and root-on-cycle profile.

**Evidence level.** The non-descent theorem is an exact finite structural
counterexample.  Equation (1) is an exact bounded construction-family
theorem, not a full order-\(28\) classification.

**Unresolved boundary.** Arbitrary-order wide gate escape and Note 076(14)
remain open.  A next positive induction must include non-target NAE defect
states; no particular finite defect automaton is asserted sufficient here.

