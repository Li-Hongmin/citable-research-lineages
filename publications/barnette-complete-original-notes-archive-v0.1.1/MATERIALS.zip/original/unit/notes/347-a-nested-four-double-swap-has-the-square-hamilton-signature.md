> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A nested four-double swap has the square Hamilton signature

[Note 346](346-the-alternating-rainbow-double-chain-is-square-equivalent-at-every-length.md)
handles one nonlocal matching on an even alternating chain. Already at
four consecutive double blocks there is another nonlocal matching:
the disjoint chords \(k_1i_2,k_3i_4\) can be replaced by the nested
chords \(k_1i_4,i_2k_3\). The resulting 32-vertex patch is also an
exact square reduction, although neither adjacent \(J_3,J_1\) pair
has the three local chords of
[Note 335](335-two-oppositely-oriented-double-vacancies-have-one-adjacent-mixed-core.md).

Write four consecutive blocks in old-cycle order as
\[
 D_s=(a_s,o_s,h_s,i_s,k_s,j_s,e_s,b_s),\qquad 1\le s\le4. \tag{1}
\]
Let \(T\) contain their full old-cycle path, the four block-closing
chords \(a_sb_s\), the common-face internal chords
\[
                 i_1e_1,\quad o_2k_2,\quad i_3e_3,\quad o_4k_4, \tag{2}
\]
and the opposite-face chords
\[
 h_1j_4,\quad k_1i_4,\quad j_1h_2,\quad i_2k_3,\quad
 j_2h_3,\quad e_2o_3,\quad j_3h_4.                         \tag{3}
\]
Its four degree-two terminals are \((a_1,o_1,e_4,b_4)\), in
disk-boundary order; every other vertex has degree three.

**Four-double swap theorem.** The complete vertex-spanning
one-path and two-path linkage signature of \(T\) at these
terminals equals that of the square in the same order. Replacing
an induced disk copy of \(T\) by this square, or conversely,
preserves membership in the class of three-connected cubic
bipartite plane graphs and preserves every Hamilton-cycle decision
on exterior and attachment edges. In particular, a
vertex-minimal non-Hamiltonian Barnette graph has no such patch.
The patch occurs in a 44-vertex Barnette parent with a
compressed, gapless, tight-target all-square opening and a
Hamilton cycle through both site edges. If it is a target-free
free-group patch in such an opening and all remaining vacancies
are in distinct internal blocks, the parent has a Hamilton cycle
through both site edges and its legal site-expanded child is
Hamiltonian.

**Exact signature.** The old path through (1) spans \(T\) from
\(a_1\) to \(b_4\). A spanning path from \(o_1\) to \(e_4\) is
\[
\begin{split}
W={}&(o_1,a_1,b_1,e_1,i_1,h_1,j_4,k_4,i_4,
 k_1,j_1,h_2,o_2,a_2,b_2,e_2,\\
 &o_3,a_3,b_3,e_3,i_3,h_3,j_2,k_2,i_2,
 k_3,j_3,h_4,o_4,a_4,b_4,e_4).
\end{split}                                                   \tag{4}
\]
Its cross-block joins are precisely \(h_1j_4,k_1i_4,j_1h_2,
e_2o_3,j_2h_3,i_2k_3,j_3h_4\); its other non-old joins
are block-closing chords and the \(J_3\) chords of (2).
The spanning \(a_1\)--\(o_1\) route of Note 346 (2)--(3)
at \(N=4\) uses only \(j_sh_{s+1}\), \(h_1j_4\), old edges
and (2), so the swap leaves it intact. The reflection
\(\rho\) of Note 346 (4) preserves (2)--(3): it fixes
\(h_1j_4,k_1i_4,i_2k_3,e_2o_3\) as unordered edges and
interchanges \(j_1h_2\) with \(j_3h_4\). Thus the reflected
route spans from \(e_4\) to \(b_4\). These are all four
colour-permitted one-path endpoint pairs.

For the two-path pairing \(\{a_1b_4,o_1e_4\}\), use
\[
\begin{split}
A={}&(a_1,b_1,a_2,b_2,e_2,j_2,k_2,o_2,h_2,i_2,
 k_3,j_3,e_3,i_3,h_3,o_3,a_3,b_3,a_4,b_4),\\
B={}&(o_1,h_1,i_1,e_1,j_1,k_1,i_4,h_4,o_4,k_4,j_4,e_4).
\end{split}                                                   \tag{5}
\]
They are disjoint and cover all 32 vertices. Every consecutive
pair is an old edge or a chord in (2)--(3) or \(a_sb_s\).
For \(\{a_1o_1,e_4b_4\}\), take the single-edge path
\((a_1,o_1)\) together with
\[
\begin{split}
Q={}&(e_4,j_4,h_1,i_1,e_1,b_1,a_2,o_2,h_2,j_1,k_1,
 i_4,k_4,o_4,h_4,j_3,e_3,i_3,k_3,\\
 &i_2,k_2,j_2,h_3,o_3,e_2,b_2,a_3,b_3,a_4,b_4).
\end{split}                                                   \tag{6}
\]
Its non-old joins are \(j_4h_1,i_1e_1,j_1h_2,k_1i_4,
o_4k_4,h_4j_3,e_3i_3,k_3i_2,j_2h_3,o_3e_2,a_3b_3,
a_4b_4\). It visits every vertex except \(a_1,o_1\)
once. The third pairing \(\{a_1e_4,o_1b_4\}\) is
impossible: each pair joins equal bipartition colours.
Thus (4)--(6) give precisely the square's complete signature.
A Hamilton cycle meets the four-attachment cut in two or four
edges, so its spanning path or path pair can be replaced in
either direction while retaining every exterior and attachment
decision.

**Realization.** Use the old Hamilton cycle
\[
 x,R_1,w,y,D_1,D_2,D_3,D_4,u,z,L_1,v,
 \alpha,\gamma,\delta,\beta,x.                             \tag{7}
\]
Give it the common-face matching chords \(xy,uv,\alpha\beta\),
all \(a_sb_s\), and the four chords (2). Give it the
opposite-face matching chords
\[
 \delta R_1,\quad wo_1,\quad e_4z,\quad\gamma L_1,
 \quad\text{the seven chords (3)}.                          \tag{8}
\]
Every vertex has exactly one matching chord. The opposite-side
chords are noncrossing: \(h_1j_4\) surrounds the other core
chords; \(k_1i_4\) surrounds \(i_2k_3\), which surrounds
\(j_2h_3\), which surrounds \(e_2o_3\); \(j_1h_2\) and
\(j_3h_4\) lie in disjoint side intervals of \(i_2k_3\).
The common-side chords are also noncrossing. Each chord joins
opposite old-cycle colours and is distinct from an old edge.
The graph is simple, cubic, bipartite and plane.

For three-connectivity, interlace two matching chords if their
endpoints alternate on (7). The following edges of that
interlacement graph connect every chord:
\[
\begin{gathered}
xy-wo_1-a_1b_1-h_1j_4-a_4b_4-e_4z-uv
 -\gamma L_1-\alpha\beta-\delta R_1,\\
a_sb_s-j_sh_{s+1}-a_{s+1}b_{s+1}\quad(1\le s\le3),\\
a_1b_1-k_1i_4-i_1e_1,\qquad
j_1h_2-o_2k_2,\qquad
a_2b_2-i_2k_3-i_3e_3,\\
k_1i_4-o_4k_4,\qquad a_2b_2-e_2o_3.
\end{gathered}                                             \tag{9}
\]
Each dash is endpoint alternation in (7). In a cubic graph
with a spanning old Hamilton cycle, any two-edge cut consists
of its two boundary cycle edges and encloses a matching-closed
old-cycle interval. Such an interval would disconnect the
chord interlacement graph. Hence there is no two-edge cut.
The old cycle excludes bridges, and cubic three-edge
connectivity implies three-vertex connectivity.

The site edges \(xy,uv\) bound one face. Its \(y\)--\(u\)
arc has length nine through the four \(a_sb_s\) chords;
its \(v\)--\(x\) arc has length three through
\(\alpha\beta\). Also \(x,u\) have the same colour.
This is a legal bipartite facial \(C_4\)-expansion site.
The residual cycle \(\alpha\gamma\delta\beta\alpha\)
is a square with tight escape targets \(R_1,L_1\), and
(7) has no interblock gap. The two \(x\)--\(v\) paths
\[
 x,R_1,\delta,\beta,\alpha,\gamma,L_1,v
 \qquad\text{and}\qquad
 x,y,w,\ W,\ z,u,v                                           \tag{10}
\]
are internally disjoint and cover every vertex. They form a
Hamilton cycle containing both site edges. Note 001 gives
a Hamilton cycle in the legal expanded child.

**Class preservation and opening transfer.** The paths in (5)
contract to the two opposite square edges \(a_1b_4,o_1e_4\)
while \(a_1o_1,e_4b_4\) remain, so the square is a plane
minor of \(T\). The embedding above gives the reverse disk
insertion. Deleting one patch vertex leaves \(T\) connected:
each face-closed block cycle stays connected, and adjacent
blocks still have one of the vertex-disjoint joins
\(b_sa_{s+1},j_sh_{s+1}\). After deleting two patch vertices,
every surviving component contains a surviving terminal;
otherwise it would contradict the three-connectivity of
the explicit realization (7)--(8). The exterior of a
four-attachment patch in any three-connected cubic host is
connected: two exterior components would each require at
least three of the four attachments. These facts give the
four-attachment deletion comparison of
[Note 330](330-staggered-vacancy-chains-have-the-square-hamilton-signature.md)
and prove three-connectivity in both replacement directions.

Compressing \(T\) maps its old-cycle path to the square path
\(a',o',e',b'\) and the block-closing face arc to \(a'b'\).
It replaces four consecutive target-free double blocks by
one short target-free block, retaining the two exterior free
matching attachments and every target, gap and site edge.
If all other vacancies are in distinct internal blocks,
[Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md)
gives a marked Hamilton cycle after compression. Lift it
through the exact signature and apply
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
to the legal child. \(\square\)

**Complete no-flank four-block consequence.** Suppose an ordinary
target-free free group in the same compressed, gapless,
tight-target all-square opening consists of exactly four
consecutive double blocks of types \(J_3,J_1,J_3,J_1\), with
no short block in that group. Then every matching that occurs
in a Barnette parent gives a vertex-spanning path between the
ordinary endports \(L,R\). If neither adjacent \(J_3,J_1\)
pair has Note 335's local three-chord patch, its opposite-side
matching is exactly either Note 345 at \(m=2\), or (3) with
\(Lo_1,e_4R\). This assertion concerns the displayed
\(J_3,J_1,J_3,J_1\) orientation. The old-cycle reflection
of four blocks preserves that orientation word: it reverses
the block order and interchanges \(J_1,J_3\), so it gives
no separate conclusion for \(J_1,J_3,J_1,J_3\).

To prove the classification, remove the endpoints of (2).
The residual slots occur in the order
\[
L,o_1,h_1,k_1,j_1,h_2,i_2,j_2,e_2,
o_3,h_3,k_3,j_3,h_4,i_4,j_4,e_4,R.                  \tag{11}
\]
They match noncrossingly on the opposite side of the old
cycle. No remaining same-block pair is available by
the chord-isolation rule of
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md);
in particular, old-cycle edges cannot be matching chords.
A complete-block interval closed under this matching would
be a forbidden two-edge cut.

The even slot \(h_1\) can meet only \(j_2,o_3,j_4,R\).
Every other opposite-colour candidate either is unavailable
in its own block or encloses an odd number of residual slots.
If \(h_1j_2\), its four enclosed slots
\(k_1,j_1,h_2,i_2\) force \(k_1i_2,j_1h_2\), giving
the first local Note 335 patch. If \(h_1o_3\), its six
enclosed slots force \(k_1i_2,j_1h_2\) and leave the
forbidden old-cycle pair \(j_2e_2\); this case is impossible.

Suppose \(h_1R\). Then \(Lo_1\) is forced.
Inside \(h_1R\), the only candidates for \(k_1\) are
\(i_2,j_3,i_4\). The choice \(k_1j_3\) leaves \(h_4\)
with no mate in the right tail, and \(k_1i_4\) leaves
the forbidden pair \(j_4e_4\). Thus \(k_1i_2,j_1h_2\).
The slot \(j_2\) can meet only \(h_3\) or \(e_4\).
The first choice forces \(e_2o_3,k_3i_4,j_3h_4\)
and again leaves \(j_4e_4\). Hence \(j_2e_4\);
noncrossing and forbidden old edges then force
\(e_2o_3,h_3j_4,k_3i_4,j_3h_4\). The last three
edges are precisely the local Note 335 patch on
\(D_3,D_4\).

Finally suppose \(h_1j_4\). Outside this chord,
\(L\) can meet only \(o_1\) or \(R\). The latter
would force \(o_1e_4\) and close the entire four-block
interval under the matching, a two-edge cut. Thus
\(Lo_1,e_4R\). Inside \(h_1j_4\), the possible mates
of \(k_1\) are \(i_2,j_3,i_4\). The choice \(k_1j_3\)
traps the forbidden old pair \(h_4i_4\). If
\(k_1i_2\), then \(j_1h_2,j_2h_3,e_2o_3,
k_3i_4,j_3h_4\) are forced: this is exactly
Note 345 at \(m=2\).

If \(k_1i_4\), then \(j_1\) can meet only
\(h_2,k_3,h_4\). The choice \(j_1k_3\) leaves
\(h_2\) without a mate inside that chord. The
choice \(j_1h_4\) forces
\(h_2j_3,i_2k_3,j_2h_3,e_2o_3\); all free
matching edges of the proper interval \(D_2,D_3\)
then stay inside it, a two-edge cut. Hence
\(j_1h_2\). The slot \(i_2\) can meet only
\(k_3,h_4\) inside \(k_1i_4\).
The latter choice leaves the forbidden old pair
\(k_3j_3\); the former forces
\(j_2h_3,e_2o_3,j_3h_4\), exactly (3).
This exhausts the noncrossing matchings in (11).

In either local-patch case, compress that pair by Note 335.
The remaining free group has exactly one short block and the
two oppositely oriented double blocks; [Note 336](336-every-two-double-mixed-j1-j3-free-group-has-a-spanning-route.md)
supplies its \(L\)--\(R\) spanning path, which lifts
through the exact square signature. In the two nonlocal
cases, Notes 345 and the present path (4) give the route.
Note 324 then supplies a marked Hamilton parent cycle and
a Hamilton legal child whenever all vacancies outside this
group occupy distinct internal blocks. \(\square\)

The matching (3) differs from Note 345 at exactly the two
disjoint \(k_1i_2,k_3i_4\) chords. Neither adjacent
\(J_3,J_1\) pair has Note 335's local three-chord patch,
so this is a separate four-block core. The classification
above requires four consecutive alternating double blocks
and no short blocks in their ordinary free group; it does
not classify other four-block orders, positive short corridors,
other internal chord types, target defects, positive gaps,
nonsquare residual cycles or general Barnette graphs.
This is a project-internal analytic proof; no independent
external review or external priority is claimed.
