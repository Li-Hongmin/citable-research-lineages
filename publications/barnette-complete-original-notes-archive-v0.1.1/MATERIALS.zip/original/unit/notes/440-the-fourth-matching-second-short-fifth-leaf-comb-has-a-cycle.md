> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The fourth matching's second short-fifth-leaf comb has a cycle

The second short-fifth-leaf comb of [Note 429](429-two-short-fifth-leaf-combs-have-marked-hamilton-cycles.md), with sites \((1,7)\) and depths \((3,4,6,6,5,2,1)\), also occurs in row IV of [Note 437](437-the-fourth-matching-short-leaf-has-thirteen-necessary-depth-words.md). Its row-I marked path uses a face edge absent from row IV. A different path through the same ordinary word uses only the row-IV face chords \(y_2x_3,y_3x_6\).

Retain Note 429's second-comb word
\[
\begin{aligned}
K&=F(U_3,U_4),& A&=F(K,S_5),& S_5&=(x_5y_5),\\
R&=F(U_2,A),& S&=F(U_1,R),& T&=F(S,U_6),&
W&=F(T,U_7),
\end{aligned}                                                     \tag{1}
\]
with all other leaves and branches full. The old-cycle path through \(A\), together with its outer ordinary chord \(A_\ell A_r\), is a Hamilton cycle of the 28-vertex interval \(A\). Delete its old edge \(x_3y_3\), and read the resulting spanning path from \(x_3\) to \(y_3\):
\[
Z_A=(x_3\xrightarrow{\mathrm{old\ backward}}A_\ell,\,
     A_r\xrightarrow{\mathrm{old\ backward}}y_3),
\tag{2}
\]
where the transition \(A_\ell A_r\) is the outer chord.

**Marked-path theorem.** With the paths \(Y_i,X_i,P_T,Q_T,R_T\) of [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md), a spanning \(y_1\)--\(x_7\) path of \(W\) is
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,\quad
\lambda_2^S\xrightarrow{P_S}\rho_2^S,\quad
\rho_0^R\xrightarrow{Q_R}\lambda_2^R,\quad
L_2\xrightarrow{Y_2^{-1}}y_2,\quad
x_3\xrightarrow{Z_A}y_3,\\
&x_6\xrightarrow{X_6^{-1}}R_6,\quad
\rho_2^T\xrightarrow{R_T}\lambda_0^T,\quad
\lambda_2^W\xrightarrow{P_W}\rho_2^W,\quad
R_7\xrightarrow{X_7}x_7.
\end{aligned}                                                     \tag{3}
\]
The two jumps \(y_2x_3,y_3x_6\) are row-IV face chords. The other joins \(L_1\lambda_2^S\), \(\rho_2^S\rho_0^R\), \(\lambda_2^RL_2\), \(R_6\rho_2^T\), \(\lambda_0^T\lambda_2^W\), and \(\rho_2^WR_7\) are old-cycle edges. Equation (2) uses every vertex of \(A\) once, and the remaining pieces in (3) use \(U_1,U_2,U_6,U_7\) and the four wrappers \(R,S,T,W\) once. Their counts are \(28+4\cdot6+4\cdot6=76\), so (3) is a spanning path.

Appending the two site edges and the fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), gives a parent Hamilton cycle containing both expansion edges. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md), clause 1, then gives a Hamilton cycle in every legal row-IV expanded child with word (1). Reflection gives the row-V conclusion. \(\square\)

Together with Notes 437--439, this leaves nine structurally necessary row-IV/V short-leaf words. Row VI and Barnette's conjecture remain open.
