> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Target-free double-vacancy groups compose at every gapless surplus

[Note 215](215-separated-vacancies-compose-marked-hamilton-routes.md)
composes arbitrarily many one-vacancy free groups. Notes
[223](223-two-target-free-vacancies-in-one-group-always-have-a-marked-hamilton-cycle.md)
and [227](227-all-target-free-same-block-double-vacancies-are-hamiltonian.md)
give a spanning free path for a two-vacancy group when both
vacancies lie in target-free face-chord blocks. The local
boundary routing from those proofs can be used in several
disjoint groups at once.

Let \(G\) be a Barnette parent with an old Hamilton cycle
\(C\) avoiding disjoint cofacial matching site edges
\(q=xy,p=uv\). Select an all-square facial opening with
\(\ell,r\ge1\), compress its lobes to residual squares,
and assume every interblock gap is empty. The target order
is *tight*: \(R_\ell\) is the first interior slot of
\(B_0\), \(L_1\) is the final interior slot of
\(B_{r+1}\), and \(L_jR_{j-1}\in E(C)\) for every
\(j\ge2\). Let \(s\) be the number of eligible positions
not occupied by nonfinal \(L\)-targets, so
\(f=4r+2+2s\).

Every vacant position is a free even slot \(h\), immediately
followed by a free odd slot \(i\), as in Note 215. Call
\((h,i)\) a *vacant pair*. The free-slot intervals between
successive occupied target runs are called *groups*. An
internal group's endports are the ordinary slots \(e_a,o_b\)
of Note 215; an outer group uses the appropriate site
boundary port.

**Group-composition theorem.** Suppose:

1. every block containing an escape target has at most one
   vacant eligible position;
2. each group contains at most two vacant pairs; and
3. whenever a group contains two vacant pairs, both lie in
   target-free internal face-chord blocks (possibly the
   same block).

Then \(G\) has a Hamilton cycle containing both \(p,q\),
and its legal site-expanded child is Hamiltonian. This holds
for every \(s\) and for arbitrary positive original lobe
lengths.

**Proof.** First we verify that the indicated groups are
closed under the free part of \(M=E(G)\setminus E(C)\).
At every escape target, the number of preceding free slots
is even by Note 255's prefix parity formula. A free chord
joining different blocks cannot straddle the target by
Note 203; a same-block chord on that opposite side would
cross its escape edge as well. In a target-bearing block
with zero or one vacancy, at most one face-side free chord
can cross any occupied target run. Indeed, a saturated
block has only its first and final ordinary free slots;
with one vacancy its free slots have order \(o,h,i,e\)
in an internal block. On either side of any occupied run,
at most one of these slots is available on one side.
The corresponding site-block statement is the boundary
version proved in Note 215. The even free-prefix parity
therefore excludes the single possible crossing chord.
Blocks with two vacancies have no targets by hypothesis.
No free matching edge crosses an occupied target run.

Consequently each group is matched internally. A group
with no vacancy has the standard \(e_t o_{t+1}\) chain by
Note 196's short-block skipping rule. A group with one
vacancy has the same boundary routing as in
Note 215: its internal cases are Notes 208--209 and its
site-block boundary cases are Note 210. Those proofs use
only the group's noncrossing opposite-side chords, the
old-cycle adjacency exclusions and the forbidden two-edge
cut. Other vacancies behind occupied target runs add even
free-slot pairs to every prefix and cannot change these
local arguments. Note 215's simple boundary peels, when
needed, do not meet another group.

Consider a group with two vacancies. By hypothesis its
vacancy blocks are target-free internal face-chord blocks;
every other complete block in the group is short and
target-free. If the vacancies lie in different blocks,
the group has precisely the arbitrary-flank slot order of
Note 223, and that note supplies one spanning path between
its ordinary endports. If they lie in one block, its six
free slots and arbitrary short flanks have precisely the
slot order of Note 227, which supplies the same endport
routing. The proofs of Notes 222--223 and 225--227 are
confined to the group's matching, the two face-block
closures and consecutive-interval two-edge cuts. An
endpoint block may have a vacancy on the other side of
its occupied target run; the barrier just proved leaves
only its ordinary endport on this group's side. Hence the
local two-vacancy routings remain valid.

Take the even-starting old-cycle matching \(A\) used in
Note 196. Tight target order gives its fixed target-and-square
\(x\)-to-\(v\) path. Use that note's ordinary free
\(x\)-to-\(v\) path as a routing template, omitting the
vacant pairs for the moment. Replace its disjoint group segments
by the endport paths just described. Each replacement
uses all and only that group's vertices and preserves its
attachments to the rest of the free path (or its site
boundary endpoint), so the replacements commute and
produce one spanning free path. It meets the fixed
target-and-square path only at \(x,v\). Their union is a
Hamilton cycle containing \(xy,uv\). Reverse any boundary
peels with the marked routes of Notes 185 and 215; then
Notes 001 and 178 give the legal child and original lobe
lengths. \(\square\)

**Third-surplus consequence.** At \(s=3\), suppose every
target-bearing block has at most one vacancy, the tight
gapless opening has at least two vacancy groups, and every
group containing two vacancies places both in target-free
internal face blocks. Then it is marked Hamiltonian. Thus
an unresolved tight third-surplus opening must put all
three vacancies in one group, put a pair in a group
touching a target-bearing or site block, or place at least
two vacancies in one target-bearing block. Defective target
order, positive gaps, nonsquare residual cycles, and the
general Barnette conjecture are outside the theorem.
