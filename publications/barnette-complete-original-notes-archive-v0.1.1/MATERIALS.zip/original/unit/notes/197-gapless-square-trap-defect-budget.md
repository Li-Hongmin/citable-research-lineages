> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A defect budget for gapless square-trap openings

[Note 195](195-exact-lobe-independent-opposite-face-chord-packing.md)
counts the interior slots of the site and opposite-face chord blocks,
and [Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md)
shows that equality forces every consecutive escape-lobe transition
to be adjacent on the old Hamilton cycle. Above equality, the number
of unoccupied eligible block slots bounds how many of these
adjacencies, including the two boundary positions, can fail.

Use the compressed one-square-per-lobe setting and notation of
Notes 193 and 195. The parent is a three-connected cubic bipartite
plane graph with Hamilton cycle \(C\), complementary matching \(M\),
cofacial site edges \(q=xy,p=uv\in M\), \(\ell\ge1\) residual square
lobes, and \(r\ge1\) opposite-face matching chords. The main
\(C\)-segment runs from \(x\) to \(v\), and its escape targets occur
in the order
\[
R_\ell,L_\ell,R_{\ell-1},L_{\ell-1},\ldots,R_1,L_1.
\tag{1}
\]
Let \(B_0,\ldots,B_{r+1}\) and \(G_0,\ldots,G_r\) be the closed
chord blocks and open gaps of Note 195. Block \(B_i\) has
\(2+2k_i\) interior slots.

**Endpoint barrier, with arbitrary gaps.** The first escape target
\(R_\ell\) cannot be the first interior slot of any block
\(B_h\) with \(h>0\). The last escape target \(L_1\) cannot be
the final interior slot of any block \(B_i\) with \(i<r+1\).

**Proof.** Suppose \(R_\ell\) is the first interior slot of
\(B_h\), \(h>0\). Take the consecutive \(C\)-interval from \(x\)
through the vertex immediately before the left endpoint of
\(B_h\). It consists of complete earlier blocks and gaps and
contains no escape target. Every site or face matching chord in
it is internal. A free-slot matching edge leaving it would have
endpoints in different atoms, so it lies opposite the designated
face by Note 193. Its far endpoint follows \(R_\ell\), since the
block's left endpoint is already matched to its right endpoint
and \(R_\ell\) itself is matched to its residual square. Such
an edge would cross the escape edge at \(R_\ell\). Hence the
interval is closed under \(M\), and only its two boundary
\(C\)-edges leave it, contradicting three-edge-connectivity.

For the other end, suppose \(L_1\) is the final interior slot
of \(B_i\), \(i<r+1\). Take the consecutive \(C\)-interval
starting immediately after the right endpoint of \(B_i\) and
ending at \(v\). It consists of complete later gaps and blocks
and has no escape target. Every block-closing matching chord
is internal. A free-slot edge leaving it for an earlier slot
lies opposite the face and straddles \(L_1\): there is no
free slot between \(L_1\) and the right endpoint of its block.
It would cross \(L_1\)'s escape edge. No matching edge can go
to a residual-square vertex, whose matching incidence is fixed.
The suffix is therefore closed under \(M\) and has exactly two
departing \(C\)-edges, again a contradiction. \(\square\)

Now assume **every gap is empty**. Every block starts with an
odd-index interior slot \(O\), followed by alternating \(E,O\)
slots. By the prefix-cut rule of Note 193, each nonfinal target
\(L_j\), \(j\ge2\), occupies one of the \(k_i\) eligible even
positions \(2,4,\ldots,2k_i\) of its block. Define an eligible
position to be *vacant* when it is not occupied by a nonfinal
\(L_j\). It may be free or occupied by \(L_1\). There are exactly
\[
s:=\sum_{i=0}^{r+1}k_i-(\ell-1)\ge0
\tag{2}
\]
vacant positions, and Note 195's count becomes
\[
f=4r+2+2s.
\tag{3}
\]
Set \(d_L=1\) if \(R_\ell\) is not the first interior slot of
\(B_0\), and \(d_L=0\) otherwise. Set \(d_R=1\) if \(L_1\)
is not the final interior slot of \(B_{r+1}\), and \(d_R=0\)
otherwise. Let
\[
b=\#\{j:2\le j\le\ell,\ L_jR_{j-1}\notin E(C)\}.
\tag{4}
\]

**Gapless defect-budget theorem.** Every such opening satisfies
\[
d_L+b+d_R\le s=\frac{f-(4r+2)}2.
\tag{5}
\]
In particular, at the first boundary above equality,
\(f=4r+4\), at most one of the following can occur:
\(R_\ell\) is delayed from \(x\), \(L_1\) is advanced from
\(v\), or some consecutive transition \(L_j,R_{j-1}\) is
nonadjacent on \(C\).

**Proof.** We assign a distinct vacant eligible position to
each event counted on the left of (5). All assigned positions
lie in disjoint portions of the target order (1).

If \(d_L=1\), the endpoint barrier excludes \(R_\ell\) as the
first interior slot of a later block. Thus \(R_\ell\) occurs
at the third or a later odd interior position of some block.
That block's second position is eligible and precedes the first
escape target, so it is vacant. Assign it to \(d_L\).

If \(d_R=1\), the endpoint barrier excludes \(L_1\) as the
final interior slot of an earlier block. Since it is an even
target, it must occupy an eligible even position of a block.
That position is vacant by definition; assign it to \(d_R\).

Fix \(j\ge2\) for which \(L_j\) and \(R_{j-1}\) are not
adjacent. If they are in the same block, \(L_j\) occupies an
eligible even position. The immediately following odd position
is not \(R_{j-1}\). Since a later odd position of the same
block holds \(R_{j-1}\), the intervening even position is
eligible. No escape target can occur between these consecutive
targets in (1), so this even position is vacant.

Suppose instead that \(L_j\in B_i\) and \(R_{j-1}\in B_h\)
with \(i<h\). If an intermediate block has \(k_m>0\), one of
its eligible even positions lies between the two targets and
is vacant. Otherwise all intermediate blocks have only two
interior slots. If \(R_{j-1}\) is not the first interior slot
of \(B_h\), the block's second position is eligible, precedes
\(R_{j-1}\), and is vacant. It remains to exclude the case in
which \(R_{j-1}\) is first. Take the main \(C\)-prefix from
\(x\) through the right endpoint of \(B_{h-1}\), together
with the residual-square suffix \(S_j,\ldots,S_\ell\).
Every escape target in the prefix is matched into this square
suffix; every site or face chord in the prefix is complete.
An \(M\)-edge leaving this set must join free slots in
different atoms, so Note 193 puts it opposite the face. Its
first endpoint precedes \(R_{j-1}\), and its second follows
\(R_{j-1}\), because that target is the first slot of \(B_h\)
and the gaps are empty. It would cross \(R_{j-1}\)'s escape
edge. Thus the set has only two departing \(C\)-edges, again
impossible. Each nonadjacent transition therefore receives a
vacant position strictly between its two targets.

The position assigned to \(d_L\) precedes \(R_\ell\); each
transition position lies strictly between its respective
\(L_j,R_{j-1}\); and the position assigned to \(d_R\) is
\(L_1\). These ranges are disjoint in (1), so all assigned
positions differ. There are exactly \(s\) vacancies, proving
(5). \(\square\)

At \(s=0\), (5) recovers the endpoint and transition
adjacencies used in Note 196. At \(s=1\), it isolates one
possible departure from that target order, but it does not
fix the remaining free-slot matching or prove Hamiltonicity.

There is a complementary statement when the blocks are
capacity-saturated but the gaps may be nonempty. For an arbitrary
gap pattern, call a block *forward* if its first interior slot
is \(O\), and *reversed* if that slot is \(E\). Note 195 gives
exactly \(k_i\) eligible even positions for nonfinal \(L\)
targets in either type: positions \(2,4,\ldots,2k_i\) in a
forward block, and \(3,5,\ldots,2k_i+1\) in a reversed block.

**Saturated-gap location theorem.** Suppose
\(\sum_i k_i=\ell-1\), with no restriction on the gap lengths.
Then \(R_\ell\) is the first interior slot of \(B_0\), and
\(L_1\) is the final interior slot of \(B_{r+1}\). Every
nonadjacent consecutive transition \(L_j,R_{j-1}\), \(j\ge2\),
ends at the **second interior slot of a reversed block**.
Consequently, if every gap has even length, all these
transitions are adjacent. At \(f=4r+4\), the two-gap-slot
branch therefore has pinned endpoints; if the two slots are
in the same gap, all transitions are adjacent. If they are
in distinct gaps, any nonadjacent transition ends in a block
strictly between those two gaps.

**Proof.** At capacity saturation every eligible even
position is occupied by a nonfinal \(L\) target. Note 195
excludes every escape target from the gaps and every \(L\)
target from the first interior slot of a reversed block.

Consider the first target \(R_\ell\). If it is in a forward
block at an odd position later than the first, the second
position is an eligible \(L\) target before \(R_\ell\),
impossible. If it is first in a later block, the endpoint
barrier above applies. Thus the only forward possibility is
the first slot of \(B_0\).

Suppose instead that \(R_\ell\) is in a reversed block
\(B_h\). It is an \(O\) slot. If it occurs later than the
second interior position, the third position is an eligible
\(L\) target before \(R_\ell\), impossible. Hence it must
be second. Every earlier block is complete and has equally
many \(E,O\) slots. The earlier gaps together have one more
\(E\) than \(O\): gap slots alternate \(E,O\) globally, and
a reversed block starts exactly after an odd number of gap
slots. All these earlier slots are free, since no escape
target precedes \(R_\ell\). An edge from any such slot to a
slot after \(R_\ell\) joins different atoms, lies opposite
the face, and would cross its escape edge. The only additional
free slot before \(R_\ell\) in \(B_h\) is its first slot,
also \(E\). Whether that slot is matched earlier or later
within \(B_h\), the earlier slots, which have excess \(E\),
cannot all be matched. This excludes the reversed case and
pins \(R_\ell\) at \(B_0\)'s first slot.

For \(L_1\), every even-colour position of a forward block
except its final one is occupied by a nonfinal \(L\).
Every even-colour position of a reversed block is either
its forbidden first slot or occupied by a nonfinal \(L\).
Thus \(L_1\) is the final slot of a forward block. The
endpoint barrier makes that block \(B_{r+1}\).

Now take a nonadjacent transition \(L_j,R_{j-1}\).
It cannot lie entirely inside one block: a later \(R\)
would leave an eligible even position between the two
targets, contrary to saturation. If they lie in blocks
\(B_i,B_h\) with \(i<h\), every intermediate block is
short, since a longer one would have an eligible \(L\)
target between them. If \(B_h\) is forward, \(R_{j-1}\)
must be its first interior slot; a later odd slot would
have an occupied eligible even position before it. Take
the main prefix through the vertex immediately before
\(B_h\)'s left endpoint, together with the residual-square
suffix \(S_j,\ldots,S_\ell\). The prefix includes all gaps
before \(B_h\). As in the gapless proof, every fixed
matching edge is internal and every free-slot edge leaving
it would straddle and cross \(R_{j-1}\)'s escape edge.
This would be a two-edge cut, so \(B_h\) cannot be forward.
In a reversed block \(R_{j-1}\) is an \(O\) slot. It cannot
occur after the second interior position, because the third
position is an occupied eligible \(L\) target between
\(L_j\) and \(R_{j-1}\). Hence it is second. A reversed
block occurs precisely when the total number of preceding
gap slots is odd, proving the stated consequences. \(\square\)

These conclusions constrain the target positions, not the
remaining free-slot matching. They do not decide the Hamilton
property at \(f=4r+4\) or for arbitrary Barnette graphs.

**Boundary reduction at saturation.** If \(k_0>0\), the
first eligible position of \(B_0\) is \(L_\ell\), so its
first three main vertices are \(x,R_\ell,L_\ell\).
If \(k_{r+1}>0\), its final eligible even position is
some \(L_j\), and the next odd position must be the
adjacent \(R_{j-1}\): a later target cannot lie outside
the final block. Since its final even position is \(L_1\),
we have \(j=2\) and the last three main vertices are
\(R_1,L_1,v\). In either case Note 186 gives a Hamilton
child directly at a site-edge collision, or peels that
boundary lobe while preserving the child Hamilton decision,
\(r\), the gap lengths, and capacity saturation. Consequently
a smallest non-Hamilton child in the saturated-gap class,
if one exists, has \(\ell\ge2\) and
\(k_0=k_{r+1}=0\). For \(\ell=1\), saturation makes every
block short and Note 194 already gives a Hamilton child.
