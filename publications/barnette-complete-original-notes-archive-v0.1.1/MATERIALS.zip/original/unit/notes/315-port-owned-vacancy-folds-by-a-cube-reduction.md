> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A port-owned corridor vacancy folds by a cube reduction

[Note 314](314-port-free-central-vacancy-gives-three-states-between-separated-ports.md)
reduces a one-vacancy corridor when its vacancy belongs to neither port
component. If it belongs to the left component, the left short-block
unbuffering proposed there creates an old-cycle-edge alias. The alias itself
forces a different, exact four-terminal reduction.

Let \(F\) be the following induced ten-vertex patch in a simple cubic graph \(G\).
Its first block is the square \(A,O,E,B,A\); its second block has the
six-cycle \(a,o,h,i,e,b,a\). Add the three edges
\[
                         Ba,\qquad Eo,\qquad Oh.             \tag{1}
\]
The square edge \(AB\) and the six-cycle edge \(ab\) are face chords
relative to the old Hamilton cycle
\[
                     \cdots A,O,E,B,a,o,h,i,e,b\cdots .         \tag{2}
\]
Every vertex of \(F\) now has degree three except \(A,i,e,b\), each of
which has exactly one edge to a nonempty exterior. Give these four
attachments the labels \(A,i,e,b\). Replace \(F\) by a square \(Q\) with
cyclically ordered labeled vertices \(A',i',e',b'\), reattaching each
exterior edge at its primed label, to obtain \(G'\).

The seven vertices \(A,O,E,B,a,o,h\) induce a cube with one
vertex deleted. One binary labeling is
\[
 A=100,\quad h=010,\quad a=001,\quad
 O=110,\quad B=101,\quad o=011,\quad E=111;
\]
the missing vertex is \(000\). Its three degree-two neighbors
\(A,h,a\) attach, respectively, to the old exterior neighbor of
\(A\), to \(i\), and to \(b\). Hence \(G\) is the cube expansion of
\(G'\) at \(A'\), in the sense of Holton--Manvel--McKay
(1985, Theorem 4, DOI 10.1016/0095-8956(85)90072-3), as
restated by Gorsky--Steiner--Wiederrecht (2023, Section 5, DOI
10.1016/j.disc.2022.113249). The following direct proof keeps
the four attachment labels needed for the corridor application.

**Folded-square lemma.** The spanning one-path and two-path Hamilton
linkage signatures of \(F\) and \(Q\), measured at their four labeled
attachments, are identical. If the original graph \(G\) is Barnette,
then the replacement graph \(G'\) is also Barnette. Every Hamilton cycle
of either graph transfers to the other with exactly the same exterior
edges and the same used attachment edges. The same exact transfer holds
for a spanning collection of paths whose endpoints lie outside the patch.

**Proof of the signature.** The terminals \(A,e\) have one bipartite
colour and \(i,b\) the other. A spanning path has ten vertices, so its
endpoints have opposite colours. All four permitted endpoint pairs are
realized by these paths, each listing every patch vertex once:
\[
\begin{array}{c|l}
A,i&A,B,E,O,h,o,a,b,e,i\\
A,b&A,O,E,B,a,o,h,i,e,b\\
i,e&i,h,O,A,B,E,o,a,b,e\\
e,b&e,i,h,O,A,B,E,o,a,b.
\end{array}                                                   \tag{3}
\]
When all four attachments are used, two vertex-disjoint paths can
pair them in either of the following ways:
\[
\begin{array}{c|l}
(A,i),(e,b)&(A,O,E,B,a,o,h,i),\quad(e,b)\\
(A,b),(i,e)&(A,O,h,o,E,B,a,b),\quad(i,e).
\end{array}                                                   \tag{4}
\]
The third pairing \(\{(A,e),(i,b)\}\) is impossible: the only two neighbors
of \(e\) *inside* \(F\) are \(i,b\), which would be endpoints of the
other path. These are exactly the four spanning one-path pairs and
two spanning two-path pairings of the square \(Q\). No other number
of attachment edges can occur in a global Hamilton cycle: the number
is positive and even, hence two or four. Replacing its patch paths by
the corresponding paths in the other patch keeps the exterior paths
and their connections unchanged. The same argument applies to a
spanning path collection with all its endpoints outside \(F\). This
proves the exact transfer.

**Proof of Barnette preservation.** Simplicity and cubicity follow from
the four distinct patch vertices and the retained labeled exterior
edges. The terminal colours in (3) alternate around \(Q\), so the old
bipartition extends. Planarity follows from a terminal-preserving
minor model: contract the connected sets
\[
\{A,B,E,o,a\},\qquad\{i,h,O\},\qquad\{e\},\qquad\{b\}
                                                               \tag{5}
\]
to the vertices \(A',i',e',b'\), respectively, and delete any surplus
parallel edges. The four required square adjacencies are witnessed by
\(AO,ie,eb,ab\), respectively; the four external edges remain at their
specified labels.

Let \(H=G-V(F)\). It is connected. Otherwise every component of \(H\)
would have at least three edges into \(F\), since \(G\) is
three-edge-connected, whereas the total number of such edges is four.
To show \(G'\) is three-vertex-connected, delete at most two vertices.
If both deleted vertices are in \(Q\), the surviving square vertices
each attach to the connected \(H\). If neither is in \(Q\), the
remaining square is connected; every component of \(H\) after the
deletions has an attachment to it, because \(G\) remains connected
after the same exterior deletions and \(F\) is connected. If one
deleted vertex is a square vertex and the other is outside, the
remaining square is connected. Delete instead the corresponding
terminal of \(F\) and the same exterior vertex in \(G\). Every
component of the remaining exterior must have an attachment at one
of the three surviving terminals, by three-vertex-connectivity of
\(G\), and therefore attaches to the remaining square. The cases
with fewer deletions are included. Hence \(G'\) is Barnette.
\(\square\)

**One-vacancy separated-port theorem.** Let a Barnette parent have
the compressed, gapless, tight-target all-square opening of
[Notes 300](300-every-consecutive-two-port-free-group-has-three-routes.md)
and [312](312-a-short-block-corridor-reduces-separated-ports-to-consecutive-ports.md).
In one free group \(D=B_a,\ldots,B_b\) with retained ordinary end links,
suppose exactly two ordinary links \(P_s,P_t\), \(a\le s<t<b\), are
missing, and exactly one block in \(B_{s+1},\ldots,B_t\) is vacant.
All other corridor blocks
are short; the matching and vacancies outside the corridor are
arbitrary subject to the stated opening. Then the entire group has
vertex-spanning \(S,K,X\) states. Under the usual spanning routes in
the other groups, the parent has a Hamilton cycle through both site
edges and its legal site-expanded child is Hamiltonian.

**Proof.** Compress the maximal short runs on each side of the
corridor vacancy \(V\) as in Note 312. Its atom order is now
\(P_s<V<P_t\) with no intervening atom. Note 278 separates the
two port components. If \(V\) belongs to neither, Note 314 gives
the three states.

Suppose \(V\) belongs to the \(P_s\) component. If no short block lay
between them, then \(V=B_{s+1}\) and their rainbow matching would use
\(o_Vh_V\), an old-cycle edge. Thus a left short block exists. The rainbow rule
forces its \(Oh_V\) edge, while its retained right ordinary link is
\(Eo_V\). These are precisely the edges (1). The right short block,
if present, can first be unbuffered: Note 314's right alias would
require \(V\) to belong to the \(P_t\) component, which it does not.
The folded-square lemma then replaces the left short block and
\(V\) by one short block, preserves Barnette membership and the
free group's four external attachments, and reduces its corridor to
one short block. The old Hamilton cycle of the reduced graph follows
\(A',i',e',b'\). On the common-face side the old face walk
\(A-B-a-b\) becomes its face chord \(A'b'\); all other face chords
and target blocks keep their order. The matching edges at \(i',e'\)
are the old external matching edges at \(i_V,e_V\). Around the new
old Hamilton cycle, the surviving opposite-side matching endpoints
keep their previous cyclic order. The two deleted matching edges
have no surviving endpoint, so the remaining chords stay noncrossing.
Thus the reduced graph still has the required opening. Its right
missing link remains missing. Its left missing
link either remains missing or becomes retained, the latter exactly
when \(e_s i_V\) was a matching edge. There is no new missing link.
Consequently the reduced group has at most two missing links; if
there are two, they are consecutive and share a short block.
[Note 288](288-every-single-missing-link-vacancy-group-has-three-spanning-routes.md)
or [Note 291](291-every-consecutive-two-port-short-shared-block-group-has-three-routes.md)
supplies its \(S,K,X\) states. The exact four-terminal signature
lifts each state through \(F\). Note 313 reinserts the right short
block if one was unbuffered, preserving each state, and Note 312
reverses the initial short-run compressions.

If \(V\) belongs to the \(P_t\) component, reflect the argument,
first unbuffering any left short block and then folding the right
short block with \(V\). These cases exhaust the atom partition.
The global marked parent and legal child follow from Notes 273,
001, and 182. \(\square\)

The local cube fold itself needs no two-port hypothesis. Whenever
exactly one short block lies between a missing-link port and the next
vacant block, and the port and vacancy belong to one rainbow
component, the matching forces the patch
(1). Other ports and vacancies may lie outside its four attachments.
The reflected statement holds on the right.

The folded-square lemma is a labeled special case of the known cube
expansion, not a new graph operation. The separated-port theorem
concerns this specified all-square opening and does not settle the
Barnette conjecture. No priority claim for the corridor theorem has
been established against the broader reducible-configuration
literature.
