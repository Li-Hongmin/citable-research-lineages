> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Wrong-interval islands reduce to rooted island-exchange flexibility

[Note 112](112-canonical-cross-supplementation-is-exactly-wrong-interval-island-exclusion.md)
shows that failure of a canonical--cross child bond is equivalent to a
wrong-interval-island obstruction \(\mathsf{WII}\).  This note identifies
the exact flexibility needed to eliminate one island.  A wrong island may
be switched independently without violating any triangular NAE constraint.
It survives in a minimum pair only when it contains the surviving gate or
when both one-island switches destroy labelled root-admissibility.

A four-vertex abstract model realizes the second possibility while retaining
the parent state, gate and bond data, valid child local rows, and formal
labelled region trees.  Hence parent kill cover cannot exclude
\(\mathsf{WII}\) at that incidence level.  The missing actual-graph input is
precisely rooted island-exchange flexibility for the common complete NAE
family of one triangulation split.

## 1. Independent switching of a wrong island

Use the notation of Note 112.  Let \(\kappa\) be a root-admissible
canonical colouring and \(\xi\) a root-admissible \(X_{uy}\) colouring
with the opposite surviving-gate bit.  Put

\[
D=\{v\in V(H):\kappa(v)\ne\xi(v)\}.
\tag{1}
\]

Suppose that \(K\) is a component of \(H[D]\) satisfying

\[
K\cap J_A=\varnothing.
\tag{2}
\]

Define two one-island hybrids by

\[
\kappa_K(v)=
\begin{cases}
\xi(v),&v\in K,\\
\kappa(v),&v\notin K,
\end{cases}
\qquad
\xi_K(v)=
\begin{cases}
\kappa(v),&v\in K,\\
\xi(v),&v\notin K.
\end{cases}
\tag{3}
\]

**Lemma 1 (island switch).**  Both hybrids in (3) are NAE colourings and
retain respectively the canonical and \(X_{uy}\) local cells.

*Proof.*  A triangle of \(H\) meeting \(K\) cannot meet a different
component of \(D\).  Every one of its other vertices therefore either lies
in \(K\) or has the same colour under \(\kappa,\xi\).  Each hybrid restricts
to one of the two original NAE rows on that triangle.

For a canonical--\(X_{uy}\) pair, the local XOR table of Note 112 is

\[
\begin{array}{c|c}
C_{00}&ACPQ\\
C_{10}&AQ\\
C_{01}&AP.
\end{array}
\tag{4}
\]

The only differing split-side vertex which sees the relevant interval is
\(A\).  Condition (2) excludes every neighbour of \(A\) from \(K\), so no
triangle incident with the split patch acquires a new mixed row.  The local
five-bit assignments are unchanged. \(\square\)

The analogous statements hold for a component of \(H[\bar D]\) missing
\(J_B\), and for \(X_{vx}\) after exchanging \(A,B\).

If \(K\) does not contain the \(D\)-side endpoint of the surviving-gate
edge, both new canonical--cross pairs retain opposite gate bits.  If either
hybrid is root-admissible, replacing its endpoint removes \(K\) from the
difference set.  The other components of \(H[D]\) are unchanged, while
\(K\) joins one or more components of \(H[\bar D]\); hence the number of
wrong-interval components strictly decreases.

**Corollary 2.**  In an opposite-gate canonical--cross pair minimizing the
number of wrong-interval components, every wrong component is either

1. **gate-anchored:** it contains the appropriate endpoint of the
   surviving-gate edge; or
2. **bi-root-rigid:** neither hybrid in (3) is root-admissible.

By Note 109, bi-root-rigidity means that both switches either violate the
three-component rank equality or fuse the two labelled root leaves.  No
triangular NAE obstruction remains.

## 2. A minimum strict abstract boundary model

The following model retains parent local states and gate bits, a nonempty
kill-covered parent bond graph, valid canonical and cross split rows, formal
labelled region trees, and the component test of Note 112.  It is not
claimed to be a common NAE system of an actual plane triangulation.

Take

\[
H=Q-r-P-s,\qquad J_A=J_B=\{P,Q\},\qquad g^*=Qr.
\tag{5}
\]

Use two parent targets

\[
\begin{array}{c|ccccc|c|c}
 &z&P&Q&r&s&\text{state}&g\\ \hline
\eta&0&0&0&0&0&11&1\\
\kappa&0&0&1&0&0&10&0.
\end{array}
\tag{6}
\]

Give both targets the labelled region tree \(L_r-K-L_s\).  Their difference
shore is \(\{Q\}\).  In the abstract parent incidence graph obtained by
adjoining \(zP,zQ\) to (5), both shores are connected and \(Qr\) crosses
the cut.  The parent bond graph is therefore the single edge

\[
\eta_{11}^{\,1}-\kappa_{10}^{\,0}.
\tag{7}
\]

It is nonempty and its only edge is covered by state \(11\).

In the child retain the canonical extension of \(\kappa\) and one
\(X_{uy}\) target:

\[
\begin{array}{c|ccccccc|c}
 &A&B&C&P&Q&r&s&g\\ \hline
\kappa^+&0&0&1&0&1&0&0&0\\
\xi&1&0&1&0&0&0&1&1.
\end{array}
\tag{8}
\]

The first five entries are exactly the valid \(C_{10}\) and \(X_{uy}\)
rows.  Give both endpoints a formal labelled region tree
\(L_r-K-L_s\).  Their gate bits are opposite, but

\[
D=\{Q,s\},\qquad
\{s\}\in\pi_0(H[D]),\qquad
\{s\}\cap J_A=\varnothing.
\tag{9}
\]

Thus their only canonical--cross pair has \(\mathsf{WII}\) and is not a
bond.  The island \(\{s\}\) is not gate-anchored.  Both one-island hybrids
retain NAE-compatible local rows, but neither is included in the formal
root-admissible family; the island is bi-root-rigid.

This is minimum in the stated abstraction.  A nonempty parent bond and a
canonical--cross test each require two endpoints.  With only three vertices
\(P,r,Q\) in connected \(H\), the local row forces one of \(P,Q\) into
\(D\); every component on either shore then meets the appropriate interval.
The four-vertex path (5) is the first support for a separate wrong island.

## 3. The remaining actual-incidence statement

The model proves the strict logical boundary

\[
\boxed{
\text{parent kill cover}
\not\Longrightarrow
\text{absence of }\mathsf{WII}}
\tag{10}
\]

at the level of parent state/gate/bond incidence, valid local split rows and
formal labelled region-tree data.  Its omitted datum is exactly that every
admitted colouring belongs to one common complete NAE triangular-face
system.

The positive statement required by this route is therefore the following.

**Rooted island-exchange flexibility.**  In an actual \(4\)-connected
Eulerian plane-triangulation split satisfying parent kill cover, a
minimum-defect opposite-gate canonical--cross pair has no non-gate
bi-root-rigid wrong component, and at least one minimum pair is not blocked
by a gate-anchored wrong component.

This statement would terminate repeated applications of Lemma 1 at a
canonical--cross rooted bond.  Conversely, any actual counterexample must
realize a protected minimum in which every remaining wrong island is
gate-anchored or bi-root-rigid.  Parent-bond calculus, local split rows and
region-tree counts cannot distinguish these alternatives; the next proof
or counterexample must use the shared actual triangulation incidence.

## 4. The canonical--cross strengthening has an extra occupancy premise

The original rooted split-bond lemma of Note 108 permits a child bond
incident with any of

\[
R_{00},\qquad X_{uy},\qquad X_{vx}.
\tag{11}
\]

Requiring specifically a canonical--cross bond is stronger even before
shore connectivity is tested.  Let \({\cal L}_{\neg11}^b\) be the parent
root-admissible colourings of gate bit \(b\) whose split state is not
\(11\), and put

\[
{\cal A}_X^b={\cal A}_{X_{uy}}^b\cup{\cal A}_{X_{vx}}^b.
\tag{12}
\]

The gate-preserving canonical bijection of Note 108 gives

\[
{\cal L}_{\neg11}^b\longleftrightarrow{\cal A}_{\cal C}^b.
\tag{13}
\]

Hence opposite-gate canonical--cross occupancy is exactly

\[
\boxed{
(\mathsf{OX})\qquad
\exists b:\
{\cal L}_{\neg11}^{\,b}\ne\varnothing
\quad\text{and}\quad
{\cal A}_{X}^{\,1-b}\ne\varnothing.}
\tag{14}
\]

Parent kill cover constrains only edges of the parent rooted bond graph.  At
the present axiomatic layer it forces neither factor in (14).  A strict
two-level incidence model makes the distinction explicit.  Let the parent
have

\[
\alpha\in L_{11}^{\,0},\qquad
\beta\in L_{00}^{\,1},
\tag{15}
\]

with the unique rooted bond \(\alpha\beta\).  In the child retain the
canonical image \(c\in C_{00}^{\,1}\), add a nondirect
\(r\in R_{00}^{\,0}\), and let \(cr\) be a rooted bond, while both cross
cells are empty.  This model respects the canonical induced-graph identity,
has a nonempty parent kill cover, and even satisfies the weaker rooted
split-bond conclusion through \(R_{00}\); nevertheless \(\mathsf{OX}\)
fails.

This second model is again only an incidence model, not a common NAE system
of an actual triangulation.  It proves that the canonical--cross statement
cannot replace the original lemma without an additional actual-incidence
proof of (14).  If \(\mathsf{OX}\) is unavailable, the efficient target is
the full three-new-cell rooted split-bond lemma, not the stronger
wrong-interval exclusion problem alone.
