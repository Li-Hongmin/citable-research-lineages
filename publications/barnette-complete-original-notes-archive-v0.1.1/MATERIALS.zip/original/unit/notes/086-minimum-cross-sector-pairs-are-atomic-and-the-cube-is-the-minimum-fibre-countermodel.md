> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Minimum cross-sector pairs are atomic, and the cube is the minimum fibre countermodel

[Note 085](085-a-square-forced-gate-reduces-the-other-gate-to-a-two-linkage-fibre.md)
reduces the local--global paired-gate stratum to a fixed-pairing
spanning-two-path matching fibre.  Its finite data suggest a stronger
crossing-edge statement: if the surviving gate occurs in the fibre, then
some single alternating-cycle exchange should cross to a matching that
omits it.

This note separates the two claims hidden in that statement.  Sector escape
is the original unresolved local--global assertion.  Conditional on both
sectors being nonempty, a minimum cross-sector pair either is a crossing
edge or generates an atomic component cube in which only the empty and full
toggles remain in the fibre.

The atomic alternative is real even when the smoothed graph is itself a
simple plane brace.  A labelled cube has a two-member fibre whose members
differ on two disjoint \(4\)-cycles.  Its inverse square extension is still
an abstract simple cubic bipartite brace, but it contains a certified
\(K_{3,3}\)-subdivision.  Thus the missing hypothesis is not fibre
incidence, planarity of the smoothed brace, or abstract \(2\)-extendability
of the extension.  It is planarity of the specified two-channel square
extension.

## 1. Pairing and cycle defects

Use the square-deletion notation of Note 085.  The graph \(R\) has four
degree-two terminals

\[
u',v',x',y',
\tag{1}
\]

all other vertices have degree three, and

\[
\mathcal L=
\mathcal L_{u'y'\mid v'x'}(R)
\tag{2}
\]

is the set of perfect matchings whose complements are two spanning paths
with fixed terminal pairing

\[
\pi_0=\{\{u',y'\},\{v',x'\}\}.
\tag{3}
\]

Let \(g_1\in E(R)\) be the surviving gate, and put

\[
\mathcal L^1=\{M\in\mathcal L:g_1\in M\},
\qquad
\mathcal L^0=\{M\in\mathcal L:g_1\notin M\}.
\tag{4}
\]

For any perfect matching \(P\) of \(R\), every internal vertex has degree
two in \(R-P\), and every terminal has degree one.  Hence \(R-P\) is the
disjoint union of two terminal-pairing paths and \(c(P)\ge0\) cycles.  Let
\(\pi(P)\) be the induced terminal pairing.  Then

\[
\boxed{
P\in\mathcal L
\iff c(P)=0\text{ and }\pi(P)=\pi_0.}
\tag{5}
\]

The terminals occur in cyclic order on the boundary left by deleting the
root square, so only the two noncrossing pairings can be realized by
vertex-disjoint paths.  Planarity controls this pairing defect, but it does
not prohibit closed cycle components.

The crossing-edge candidate contains two assertions:

\[
\begin{array}{ll}
\text{sector escape:}&\mathcal L^1\ne\varnothing
\Longrightarrow\mathcal L^0\ne\varnothing,\\[2mm]
\text{sector adjacency:}&
\mathcal L^1,\mathcal L^0\ne\varnothing
\Longrightarrow
\exists M\in\mathcal L^1,\ N\in\mathcal L^0
\text{ with }M\triangle N\text{ one cycle}.
\end{array}
\tag{6}
\]

The first line is exactly the still-open local--global gate statement.  A
minimum-pair argument can address only the second line after sector escape
has been supplied.

## 2. Minimum cross-sector pairs form atomic cubes

Assume both sectors in (4) are nonempty.  Choose

\[
M\in\mathcal L^1,\qquad N\in\mathcal L^0
\tag{7}
\]

so that the number of components of \(M\triangle N\) is minimum.  Write

\[
M\triangle N=C_1\mathbin{\dot\cup}\cdots
\mathbin{\dot\cup}C_k,
\tag{8}
\]

where \(C_1\) is the unique component containing \(g_1\).  For
\(S\subseteq[k]\), define

\[
M_S=M\mathbin\triangle
\bigcup_{i\in S}E(C_i).
\tag{9}
\]

Every \(M_S\) is a perfect matching of \(R\).

**Atomic-cube lemma.**  For every nonempty proper subset
\(S\subsetneq[k]\),

\[
M_S\notin\mathcal L.
\tag{10}
\]

Equivalently,

\[
\boxed{
\{S\subseteq[k]:M_S\in\mathcal L\}
=\{\varnothing,[k]\}.}
\tag{11}
\]

**Proof.**  If \(1\in S\) and \(M_S\in\mathcal L\), then
\(M,M_S\) lie in opposite \(g_1\)-sectors and differ on
\(|S|<k\) components, contrary to minimality.  If \(1\notin S\), then
\(M_S,N\) lie in opposite sectors and differ on the
\(k-|S|<k\) components indexed by \([k]\setminus S\), again a
contradiction. \(\square\)

Thus \(k=1\) is exactly the desired crossing edge.  Failure of sector
adjacency is exactly an atomic cube (11) with \(k\ge2\).  Toggling
\(C_1\) alone must change the terminal pairing, create complement cycles,
or do both; the remaining components are jointly necessary to repair the
defect.

## 3. Local brace axioms do not split the atomic cube

Planarity reduces the pairing defect in (5) to two states but does not
control \(c(P)\).  The endpoint-orbit theorem of Note 081 computes the
result of each toggle; it does not force a proper feasible subtoggle.

Nor does ordinary \(2\)-extendability remove a component.  Every \(M_S\)
already lifts through the deleted square to a perfect matching

\[
\widehat M_S=M_S\cup\{e,g_0\}
\tag{12}
\]

of the original brace.  To choose an additional edge from a desired repair
component while retaining both square edges would require extension of a
three-edge matching \(\{e,g_0,h\}\), which the brace axiom does not
provide.  Extending \(\{e,h\}\) or \(\{g_0,h\}\) may lose the other
square edge and leave the fibre.

The precise sufficient statement still missing is

\[
\begin{gathered}
M,N\in\mathcal L,\quad g_1\in M\triangle N,\quad
\#\operatorname{comp}(M\triangle N)\ge2\\
\Longrightarrow
\exists\,\varnothing\ne S\subsetneq[k]\text{ with }M_S\in\mathcal L.
\end{gathered}
\tag{13}
\]

The next section shows that (13) is false without planarity of the labelled
square extension.

## 4. The cube realizes the minimum atomic two-switch

Let \(K=Q_3\) on vertices \(0,\ldots,7\), with binary labels and edges
joining labels that differ in one bit.  Set

\[
p=01,\qquad q=67,\qquad R=K-\{p,q\}.
\tag{14}
\]

The separated two-factor fibre of Note 085 is exactly

\[
\mathcal S_{p\mid q}(K)=\{N_0,N_1\},
\tag{15}
\]

where

\[
N_0=\{02,13,46,57\},\qquad
N_1=\{04,15,26,37\}.
\tag{16}
\]

Their complement cycles are respectively

\[
(0,1,5,4),\ (2,3,7,6)
\tag{17}
\]

and

\[
(0,1,3,2),\ (4,5,7,6).
\tag{18}
\]

Take \(g_1=02\).  The two sectors are the singletons
\(\{N_0\}\) and \(\{N_1\}\), while

\[
N_0\mathbin\triangle N_1
=(0,2,6,4,0)\mathbin{\dot\cup}(1,3,7,5,1).
\tag{19}
\]

Thus both sectors are nonempty, but there is no crossing single-cycle
edge.  This is the atomic feasible family
\(\{\varnothing,\{1,2\}\}\).

The example is order-minimal among simple bipartite realizations.  Two
distinct alternating components each have length at least four and are
vertex-disjoint, so at least eight vertices are required.  The cube attains
this bound.  Moreover \(K=Q_3\) is itself a simple plane brace.

## 5. The inverse extension fails exactly at planarity

Delete \(01,67\), introduce a square

\[
Q=u-v-x-y-u,
\tag{20}
\]

and attach

\[
1u,\qquad6v,\qquad7x,\qquad0y.
\tag{21}
\]

The resulting graph \(G\) is simple, connected, cubic and bipartite.  It has
\(17\) perfect matchings, and every independent edge pair extends to one;
hence it is an abstract brace.  Nevertheless \(G\) is nonplanar.

Indeed, \(G\) contains a \(K_{3,3}\)-subdivision with branch bipartition

\[
\{3,5,x\}\mid\{6,1,7\}
\tag{22}
\]

and nine branch paths

\[
\begin{array}{lll}
3-2-6,&3-1,&3-7,\\
5-4-6,&5-1,&5-7,\\
x-v-6,&x-y-u-1,&x-7.
\end{array}
\tag{23}
\]

The internal vertices of these paths are pairwise disjoint.  Therefore the
specified channel pairing has no plane square extension and cannot define a
facial legal-wide site.

This locates the exact applicability boundary:

\[
\boxed{
\begin{gathered}
\text{fixed-pairing fibre axioms}
+K\text{ a simple plane brace}
+G\text{ an abstract brace}\\
\not\Longrightarrow
\text{a cross-sector single-cycle edge}.
\end{gathered}}
\tag{24}
\]

The hypothesis not represented by the countermodel is planarity of the
labelled inverse square extension \(G\).

## 6. Exact boundary

The local-square crossing-cycle candidate remains open for real plane
braces.  Conditional on sector escape, its failure is equivalent to an
atomic component cube (11).  The cube realizes the smallest such atomic
fibre while satisfying every listed abstract matching condition, but its
specified inverse extension is nonplanar.

**Exact conclusion.**  Minimum cross-sector pairs are atomic linkage cubes.
The cube is the minimum fibre-only countermodel to sector adjacency.

**Evidence level.**  The atomic-cube lemma and the order-\(8\) lower bound
are analytic.  The
[bundle](../computations/bundles/atomic-two-linkage-cube-countermodel/README.md)
exhaustively verifies the cube fibre, abstract brace extension and explicit
\(K_{3,3}\)-subdivision.

**Unresolved boundary.**  A proof for actual Barnette interfaces must use
planarity of the specified two-channel square extension to exclude atomic
cubes.  Sector escape itself remains the first unresolved assertion in
(6).
