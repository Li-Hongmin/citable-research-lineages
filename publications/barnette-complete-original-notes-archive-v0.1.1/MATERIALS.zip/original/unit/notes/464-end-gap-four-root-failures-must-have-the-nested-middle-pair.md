> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# End-gap four-root failures must isolate the nested middle pair

[Note 463](463-four-root-all-leaf-interior-gap-splice-and-end-gap-obstruction.md) reduces a possible 100-vertex chord-free single-hexagon kernel to an empty end gap and two augmented-root components. In two of the three remaining root allocations, the old perimeter itself supplies the missing exterior route; the third is a precise nested four-root interface.

Use the four-root all-leaf hypotheses and notation of Note 463. It suffices by reflection to consider the left end gap \(g_0\) empty, so the main order is
\[
 w_0,W_1,t_d,W_2,t_c,W_3,t_b,W_4,t_a,w_*.
\tag{1}
\]
The two target-pair cycles are the \(W_2\)-cycle through \(t_dd\) and the \(W_4\)-cycle through \(t_aa\); \(W_1,W_3\) have their outer root cycles. The augmented root graph \(J\) of Note 463 equals the root face graph \(K\), since each target-pair cycle contains only one root.

**Theorem.** If the parent has no Hamilton cycle containing both site edges, then \(J\) has exactly two components, with the unmarked component \(\{W_2,W_3\}\) and the marked component \(\{W_1,W_4\}\). In particular, the site ports \(u,v\) lie in \(W_1\cup W_4\), face chords connect \(W_2\) to \(W_3\) and \(W_1\) to \(W_4\), and no face chord joins the two pairs. For an empty right end gap the reflected allocation is necessary. This is a necessary shape, not an assertion that it has a Barnette realization or lacks a Hamilton cycle.

**Proof.** Note 463 settles connected \(J\), and in the disconnected case proves that \(J\) has two components. Its unmarked component must contain the first target-pair cycle through \(t_dd\), while the marked component contains the second through \(t_aa\). Thus \(W_2\) is unmarked and \(W_4\) marked. A site-free singleton root would have a two-edge cut, so the unmarked root set cannot be \(\{W_2\}\). Apart from the asserted allocation, the two possibilities are \(\{W_1,W_2\}\) and \(\{W_1,W_2,W_3\}\).

If the unmarked roots are \(W_1,W_2\), the marked roots are \(W_3,W_4\). Their two root cycles, the face matching internal to them, and the square switches of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) give a spanning \(u\)--\(v\) path \(P\) on the marked vertices: \(K[\{W_3,W_4\}]\) is connected. Independently, the following old-edge and trap-chord path spans every other vertex:
\[
 w_0,\ W_{1,\ell}\xrightarrow{\rm old}W_{1,r},\ t_d,\
 W_{2,\ell}\xrightarrow{\rm old}W_{2,r},\ t_c,c,d,\beta,\alpha,w_*.
\tag{2}
\]
The steps \(t_cc\) and \(\beta\alpha\) are the escape edge and trap chord; all other transitions are old-cycle edges. Adjoin \(u w_0\), (2), \(w_*v\), and \(P\). This is a Hamilton cycle through both site edges.

If the unmarked roots are \(W_1,W_2,W_3\), the marked root is \(W_4\). The target-pair cycle on \(W_4\), its internal face matching, and its leaf-square switches give a spanning \(u\)--\(v\) path \(P\) on all marked vertices. For the unmarked vertices start with the path
\[
 B=(W_{1,\ell}\xrightarrow{\rm old}W_{1,r},t_d,
      W_{2,\ell}\xrightarrow{\rm old}W_{2,r},t_c,c,d)
\tag{3}
\]
and the disjoint outer root cycle \(C_3\) on \(W_3\). Let \(E_U\) be the square-supported old edges at their leaves and \(M_U\) their full face matching. The graph \(B\cup C_3\cup M_U\) is connected: the unmarked component of \(J=K\) connects \(W_3\) to \(W_1,W_2\), already joined in \(B\). In
\[
                 (B\cup C_3-E_U)\cup M_U
\tag{4}
\]
only \(W_{1,\ell}\) and \(d\) have degree one; every other vertex has degree two. Its component quotient by the deleted leaf edges is connected. Each nonloop quotient edge has its leaf-square switch, so switches along a spanning tree absorb every cycle into one spanning \(W_{1,\ell}\)--\(d\) path \(P_U\). The square supports lie inside root words and do not touch the endpoints. Now
\[
        (u,w_0,W_{1,\ell})\;P_U\;(d,\beta,\alpha,w_*,v)
\tag{5}
\]
is a spanning \(u\)--\(v\) path on all vertices outside \(P\). Joining it to \(P\) gives the marked Hamilton cycle. The only allocation not covered by these two constructions is the one in the theorem. \(\square\)

At \(f=8\), any hypothetical non-Hamiltonian 100-vertex chord-free reduced child must satisfy this nested middle-pair allocation or its reflection. This result does not improve the 100-vertex unified kernel bound of Note 462 and does not address the chorded branch or smaller kernels.
