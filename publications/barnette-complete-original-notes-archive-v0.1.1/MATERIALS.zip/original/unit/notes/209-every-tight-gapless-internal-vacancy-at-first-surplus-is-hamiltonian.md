> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every tight gapless internal vacancy at first surplus is Hamiltonian

[Note 205](205-an-internal-near-equality-vacancy-must-touch-a-short-block.md)
excludes an internal vacancy between two occupied target runs.
[Note 208](208-one-sided-internal-vacancies-have-marked-hamilton-cycles-at-first-surplus.md)
then proves Hamiltonicity when the vacancy's own face-chord
block contains a target pair. The only remaining internal
shape is a target-free block with four interior slots.
Its free matching has a second possible detour direction,
but every admissible detour still makes one marked Hamilton
cycle.

Let \(G\) be a Barnette parent with a Hamilton cycle \(C\)
avoiding two disjoint cofacial matching site edges
\(q=xy,p=uv\), and let its selected all-square opening be
compressed to one square per lobe as in Notes 178 and 195.
Suppose there are \(\ell\ge1\) lobes, \(r\ge1\)
opposite-face matching chords, no interblock gaps, and
\(f=4r+4\). Assume the target order is tight:
\(R_\ell\) is the first interior slot of \(B_0\),
\(L_1\) the final interior slot of \(B_{r+1}\), and
\(L_jR_{j-1}\in E(C)\) for every \(j\ge2\).
Suppose the unique vacant eligible even position lies
in an internal face-chord block \(B_k\), \(1\le k\le r\).

**Tight internal-vacancy Hamilton theorem.** The parent
has a Hamilton cycle containing both \(p,q\), and every
legal site-expanded child admitting this opening is
Hamiltonian. This remains true for arbitrary positive
lengths of the original even four-terminal lobes.

More precisely, if the vacancy block has no occupied
eligible position, let \(o_k,h,i,e_k\) be its four
free interior slots in cycle order, with \(h\) the
vacancy. Let \(e_0\) be the free final slot of \(B_0\),
let \(o_j,e_j\) be the free first and final slots of
each face block, and let \(o_{r+1}\) be the free first
slot of \(B_{r+1}\). Then for some
\[
s\in\{1,\ldots,k-1\}\cup\{k+2,\ldots,r+1\},
\tag{1}
\]
the entire free-slot part of the complementary matching is
\[
M_{\rm free}=
\{e_j o_{j+1}:0\le j\le r,\ j\ne s-1\}
\cup\{e_{s-1}i,\ h o_s\}.
\tag{2}
\]
The ranges in (1) are empty when their endpoints are
out of order; hence no such opening exists with \(r=1\).

**Proof.** If the vacancy block contains an occupied
eligible position, Note 208 proves the result, after
using Note 205 to choose the appropriate orientation.
It remains to handle the target-free case. By Note 197,
the vacant block \(B_k\) has exactly four interior
slots \(o_k,h,i,e_k\), all free. Every other face block
has just its first odd and final even interior slots
free; \(B_0\) has only its final even slot free and
\(B_{r+1}\) only its first odd slot free.

First separate target runs in the other blocks. Before
the first occupied \(L\)-target of any normal face block
\(B_j\), the number of free main slots is \(2j\) if
\(j<k\) and \(2j+2\) if \(j>k\). Before such a target
in \(B_0\) it is zero; in \(B_{r+1}\) it is
\(2r+4\). Every count is even. A cross-block free
matching chord cannot straddle that target by Note 203.
The only possible same-block free chord crossing the
target run is its first-to-final slot chord \(o_je_j\),
so at most one free matching edge could cross the run.
An even set in a perfect matching has an even number
of matching edges leaving it. Hence no free edge crosses
any occupied target run. The free slots partition into
consecutive groups between those runs.

Every ordinary group has the form
\[
e_a,o_{a+1},e_{a+1},\ldots,e_{b-1},o_b,
\tag{3}
\]
with all intervening face blocks short. Exactly one group
contains the vacant block and has the form
\[
e_a,o_{a+1},e_{a+1},\ldots,o_k,h,i,e_k,
o_{k+1},e_{k+1},\ldots,e_{b-1},o_b,
\qquad a<k<b.
\tag{4}
\]
All free chords joining different blocks lie on the side
of \(C\) opposite the common site face by Note 193,
and are noncrossing there. As in Note 208, a chord
enclosing one complete short face block would force its
two adjacent free slots to match each other, impossible;
if it encloses two or more complete short blocks with
their free slots matched inside, their union is a proper
consecutive \(C\)-interval closed under \(M\), a
forbidden two-edge cut. We call this the skipping rule.
It forces the chain \(e_j o_{j+1}\) in every ordinary
group (3).

There is one potential free edge inside the vacant block
that is not an old-cycle edge: \(o_ke_k\). It cannot
occur. Suppose it did. The vertex \(h\) cannot match
\(i\), since \(hi\in E(C)\), and \(o_k\) is already
matched. Thus \(h\) must match the first odd free slot
of another block in its group. Such an edge is a
cross-block chord on the opposite side of \(C\). If
its mate is \(o_j\) with \(j<k\), then, after deleting
the paired \(o_k,e_k\), the still-free vertices strictly
between \(o_j,h\) are \(e_j\) and complete short-block
pairs, an odd number. If \(j>k\), the still-free vertices
strictly between \(h,o_j\) are \(i\) and complete
short-block pairs, again an odd number. All their
matching edges are cross-block chords on the same side,
so none may cross \(ho_j\); they would have to match
internally, which is impossible. Therefore \(o_ke_k\notin M\).
Every free matching chord in (4) is now cross-block and
belongs to one noncrossing disk.

Scan (4) from its first slot \(e_a\). As long as an even
slot \(e_t\) precedes \(B_k\), its mate must be the next
\(o_{t+1}\) or \(i\). A later \(o_j\) before the vacant
block would skip complete short blocks; one after the
vacant block would enclose all complete blocks from
\(B_{t+1}\) through the target-free \(B_k\). By
noncrossing, the slots inside would match internally.
If that interval contains only \(B_k\), its four slots
have no legal internal perfect matching: \(o_kh,hi,ie_k\)
are old-cycle edges and \(o_ke_k\notin M\). If it
contains another block, it is a matching-closed proper
consecutive interval and gives a two-edge cut. Thus
the only departure from the next-block chain before
\(B_k\) is an edge \(e_{s-1}i\).

If that departure occurs, \(s\le k-1\): the choice
\(e_{k-1}i\) would leave the adjacent pair \(o_k,h\).
Inside the chord \(e_{s-1}i\), the vertex \(h\) must
match \(o_s\). Matching it to a later \(o_j\) would
close the skipped short blocks \(B_s,\ldots,B_{j-1}\),
contradicting the skipping rule. The remaining enclosed
slots form the chain \(e_s o_{s+1},\ldots,e_{k-1}o_k\).
After \(B_k\) every ordinary group segment also follows
the chain. This is (2) with \(s<k\).

Otherwise the chain reaches \(e_{k-1}o_k\). The next
unmatched even slot is \(h\). It must match an
\(o_s\) after \(B_k\); \(s=k+1\) would leave the
adjacent pair \(i,e_k\), so \(s\ge k+2\). Inside
\(ho_s\), the odd slot \(i\) must match \(e_{s-1}\).
If it matched an earlier \(e_j\), the trailing complete
short blocks \(B_{j+1},\ldots,B_{s-1}\) would be
matching-closed, contradicting the skipping rule.
The remaining enclosed slots form the chain
\(e_k o_{k+1},\ldots,e_{s-2}o_{s-1}\); later slots
continue the ordinary chain. This is (2) with
\(s>k+1\). Thus (1)--(2) classify every target-free
internal-vacancy matching.

Finally let \(A\) be the even-starting old-cycle matching
indexed from \(x\). The tight target order gives the
\(x\)-to-\(v\) square-and-target path (4) of Note 207.
The other vertices form its free path (5), with the one
chain edge \(e_{s-1}o_s\) replaced by
\(e_{s-1},i,h,o_s\). Formula (2) supplies its two
matching edges and \(ih\in A\). The paths cover
\(V(G)\), meet only at \(x,v\), and their union is a
Hamilton cycle containing \(xy,uv\). Note 001 lifts
this cycle to the legal site-expanded child, and
Note 178 restores the original lobe lengths.
\(\square\)

The theorem decides every tight, gapless,
first-surplus opening whose sole eligible vacancy is
in an internal face-chord block. It does not address
an outer-block vacancy, a target-order defect, a
two-slot interblock gap, or nonsquare residual cycles,
and does not resolve Barnette's conjecture.
