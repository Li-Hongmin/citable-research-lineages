> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every isolated single–double short corridor has a marked Hamilton route

[Notes 382–386](386-the-to-short-return-has-three-cutpoints-and-a-marked-route.md)
settle the internal-chord and all but one no-internal-chord
matching branches of an isolated single–double corridor.
The remaining branch has \(to,hz\). A two-edge-cut argument
removes one apparent outer return; the other two word families
have spanning routes. This closes the marked Hamilton decision
for the whole group when all other vacancies are distinct.

Use the compressed, gapless, tight-target all-square selected
opening of a Barnette parent, with one ordinary target-free
free group of complete blocks
\[
 V=(a,o,h,i,e,b),\quad S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),
 \quad D=(A,O,H,I,K,J,E,B),\qquad m\ge1.                 \tag{1}
\]
The group has no short flanks. Its even left and odd right
endports are \(t,z\). Other groups may occur. Let \(M\)
complement the selected old Hamilton cycle.

For \(1\le r<m\) put
\[
\begin{split}
 Z^1_{m;r}=\{iE,eJ,p_1K,q_rI,p_{r+1}H,q_mO\}
 \cup\{q_jp_{j+1}:1\le j<m,\ j\ne r\}.
\end{split}                                               \tag{2}
\]
For \(1\le s<u<m\) put
\[
\begin{split}
 Z^2_{m;s,u}=\{iE,ep_1,q_sJ,p_{s+1}K,q_uI,
                     p_{u+1}H,q_mO\}\\
 \cup\{q_jp_{j+1}:1\le j<m,\ j\notin\{s,u\}\}.
\end{split}                                               \tag{3}
\]

**Outer-return classification.** If \(D\) has no internal
free matching chord and \(to,hz\in M\), then its free-slot
matching is exactly
\[
             \{to,hz\}\cup Z,
 \quad Z=Z^1_{m;r}\text{ or }Z^2_{m;s,u},                 \tag{4}
\]
with unique parameters. There are \(\binom m2\) words in all,
so this branch is empty for \(m=1\). Each word occurs in a
\(26+4m\)-vertex Barnette parent with a Hamilton cycle
through both site edges and a legal Hamiltonian child.
The induced interval (1) has a spanning \(o\)--\(h\)
path in every actual matching (4).

**Whole-group consequence.** Suppose a selected opening has
the isolated group (1), in either block order, and every
vacancy outside it lies in a distinct internal block.
Then the parent has a Hamilton cycle containing both site
edges. Its legal site-expanded child is Hamiltonian.
This holds for every complementary matching of that
opening; no specified return word is assumed. The group
can contain arbitrarily many intervening short blocks.

**Classification proof.** The free slots are ordered
\[
 t,o,h,i,e,p_1,q_1,\ldots,p_m,q_m,O,H,I,K,J,E,z.       \tag{5}
\]
All cross-block free chords lie on the page opposite the
common face, by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
and do not interlace. A nonempty proper run of complete
blocks matched only within itself would give a forbidden
two-edge cut along its two boundary old-cycle edges.

Fix \(to,hz\). The even slot \(E\) can meet only \(i\)
or some \(p_s\): \(OE,IE\) are excluded internal double-block
chords, \(JE\) is an old-cycle edge, and \(z\) is used.
If \(Ep_s\) occurred, the entire complete-block suffix
\(S_s,\ldots,S_m,D\) would be matching-closed. Its boundary
consists of \(d_{s-1}c_s,Bu\), with \(d_0c_1=bc_1\).
Indeed, every free edge from a slot inside that suffix to
an earlier slot would interlace \(p_sE\); the only possible
edge to the later endport is \(hz\), whose endpoints are
both outside the suffix. All its face chords stay inside.
This forbidden two-edge cut forces \(iE\).

Inside \(iE\), the even slot \(e\) can meet \(p_s,O,I,J\).
An edge \(eO\) would trap all complete short blocks, and
\(ep_s\) for \(s>1\) would trap \(S_1,\ldots,S_{s-1}\).
If \(eI\) occurred, \(J\) would lie on its right inside
\(iE\). Its possible earlier partners \(e,q_j\) lie inside
\(eI\) and would cross it; \(HJ\) is excluded, while
\(KJ,JE\) are old-cycle edges. Thus \(eI\) is impossible.
Only \(eJ\) and \(ep_1\) remain.

For \(eJ\), the slot \(K\) must meet \(p_k\). Skipping
\(S_1,\ldots,S_{k-1}\) is forbidden, so \(Kp_1\) occurs.
Inside it, \(I\) must meet some \(q_r\); \(r=m\) would
strand the old-cycle pair \(O,H\), so \(r<m\).
Noninterlacement and the same short-block rule force
\(Hp_{r+1},Oq_m\) and every ordinary link except
\(q_rp_{r+1}\). This is (2).

For \(ep_1\), the slot \(J\) must meet some \(q_s\).
The choice \(s=m\) strands \(O,H,I,K\) inside \(q_mJ\),
whose only candidate matching chord is the excluded \(OK\).
Thus \(s<m\). The remaining slots force, successively,
\(Kp_{s+1},Iq_u,Hp_{u+1},Oq_m\), where
\(s<u<m\), and all ordinary links except at \(s,u\).
This is (3). Conversely, the words (2)–(3) are complete,
noncrossing perfect matchings of (5) after \(to,hz\) are
removed. Their distinguished mates recover all parameters.
The count is \((m-1)+\binom{m-1}{2}=\binom m2\).

**Spanning routes.** For \(v\le w\), use the short-block
path \(W_{v:w}\) of Note 385, equation (5). Then
\[
\begin{array}{c|l}
 Z^1_{m;r} &o,a,b,e,J,K,\ W_{1:r},\ I,H,
                    \ W_{r+1:m},\ O,A,B,E,i,h\\
 Z^2_{m;s,u}&o,a,b,e,\ W_{1:s},\ J,K,
                    \ W_{s+1:u},\ I,H,
                    \ W_{u+1:m},\ O,A,B,E,i,h.
\end{array}                                               \tag{6}
\]
The first row joins by \(eJ,Kp_1,q_rI,Hp_{r+1},q_mO,Ei\).
The second joins by \(ep_1,q_sJ,Kp_{s+1},q_uI,
Hp_{u+1},q_mO,Ei\). All other successive pairs are
old-cycle edges, face chords or retained ordinary links.
Each row covers all \(14+4m\) vertices of (1) once.
The endport edges \(to,hz\) extend it to a spanning
\(t\)--\(z\) group route.

**Realization and marked cycle.** Give the parent the old
Hamilton order
\[
 x,R_1,e_0,y,\ V,S_1,\ldots,S_m,D,\
 u,o_3,L_1,v,\alpha,\gamma,\delta,\beta,x.            \tag{7}
\]
Its complementary perfect matching is
\[
 \{xy,ab,c_jd_j\ (1\le j\le m),AB,uv,\alpha\beta,
   \delta R_1,\gamma L_1,e_0o,ho_3\}\cup Z.           \tag{8}
\]
Each edge joins opposite parities on (7). The chords
\(xy,ab,c_jd_j,AB,uv,\alpha\beta\) occupy disjoint
intervals on the common-face page. The other chords are
noncrossing: \(\delta R_1\) is outermost, \(e_0o\) precedes
\(ho_3\), and \(ho_3\) encloses the nested or disjoint
word \(Z\); \(\gamma L_1\) follows it. Thus (8) defines
a simple cubic bipartite plane graph with cofacial
site edges \(xy,uv\).

The matching-chord interlacement graph is connected.
Put \(F_0=ab,F_j=c_jd_j,F_D=AB\). Its exterior part has
the alternating chain
\[
 xy-e_0o-F_0-ho_3-uv-\gamma L_1
             -\alpha\beta-\delta R_1-xy.                \tag{9}
\]
The chord \(iE\) interlaces both \(F_0,F_D\), joining
\(F_D\) to this chain. For (2), \(eJ\) also joins
\(F_0,F_D\); \(p_1K,q_rI,p_{r+1}H,q_mO\) join
\(F_1,F_r,F_{r+1},F_m\) to \(F_D\), and ordinary links
join the intervening \(F_j\). For (3), \(ep_1\) joins
\(F_0,F_1\); \(q_sJ,p_{s+1}K,q_uI,p_{u+1}H,q_mO\)
join \(F_s,F_{s+1},F_u,F_{u+1},F_m\) to \(F_D\),
with ordinary links between. Every chord lies in this
connected interlacement component. As in Note 217,
connected interlacement excludes a two-edge cut of a
cubic Hamiltonian graph; the Hamilton cycle excludes
bridges. The parent is therefore three-vertex-connected.

Two internally disjoint \(x\)--\(v\) paths cover its
vertices:
\[
\begin{split}
 &x,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
 &x,y,e_0,\ [\text{the applicable }o\text{--}h
                    \text{ row of (6)}],\ o_3,u,v.
\end{split}                                              \tag{10}
\]
The second path uses \(xy,uv\). The site expansion is
legal because \(x,u\) have the same old-cycle parity;
Note 217's cut projection makes its child Barnette,
and [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
lifts (10) to a Hamilton cycle in that child.
This realizes every word (4). \(\square\)

**Proof of the whole-group consequence.** If \(D\) has
\(J_0,J_2\), [Note 382](382-isolated-single-double-corridors-couple-j0-and-j2-at-every-length.md)
compresses it to a short block. The remaining vacancies
are distinct internal blocks, so Note 324 supplies a
marked Hamilton cycle, which lifts back through the exact
square reduction. If \(D\) has no internal free chord,
Note 382 leaves \(tJ\) or \(to\), up to old-cycle
reflection. Notes 383–384 give a spanning \(t\)--\(z\)
route for every \(tJ\) word. In the \(to\) branch, Note 386
excludes \(hO,hI,hp_1\), Note 385 routes \(hJ\), Note 386
routes every \(hp_s\) with \(s\ge2\), and (6) routes
\(hz\). Substitute the relevant group route into
Note 324's two-path template; its other group routes
have unchanged boundary attachments and disjoint interiors.
This produces a Hamilton parent cycle through both site
edges. Note 001 gives the child. \(\square\)

The theorem concerns only the specified isolated group
in a compressed, gapless, tight-target all-square opening.
It does not assert a complete square signature for the new
poles, allow short flanks, handle other vacancy patterns or
other opening types, or settle Barnette's conjecture.
This is a project-internal analytic proof, without local
graph recomputation, independent review or external
priority claim.
