> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A crossing bridge can be an isolated mixed component

[Note 152](152-root-square-crossing-edges-can-be-bridges.md) shows that a
cross-sector exchange edge need not lie on an exchange cycle. A remaining
possible route to the lower bound two was the following bridge-star
statement: every crossing bridge has an endpoint incident with a second
crossing. That statement is also false. A genuine legal-wide root-square
brace can have an entire mixed exchange component consisting of one isolated
edge; the required compensation occurs in another exchange component.

## 1. The fixed brace

Let \(G\) be the graph with graph6 encoding

~~~text
U?????????[?s?b?KO@Q?BO?Co?F??@o?QG?CE??
~~~

It has \(22\) vertices, \(33\) edges and \(119\) perfect matchings. It is
simple, plane, cubic, bipartite and \(3\)-connected, and all \(462\) pairs
of independent edges extend to perfect matchings. Hence \(G\) is a brace.

Take the facial square

\[
Q=(4,16,5,13)
\]

with root and forced gate

\[
e=4\!-\!16,\qquad g_0=5\!-\!13.
\]

Let

\[
g_1=3\!-\!21.
\]

The two gates occur on the facial cycle

\[
F=(0,13,5,17,9,21,3,12),
\]

and the two closed \(g_0\)-to-\(g_1\) arcs both have cardinality \(5\).
The inverse split of the corresponding dual face remains a simple
4-connected Eulerian plane triangulation, so this is a legal-wide
root-square decoration.

Deleting \(Q\) exposes the attachments

\[
4\mapsto15,\quad16\mapsto7,\quad5\mapsto17,\quad13\mapsto0.
\]

Let \(\mathcal T_e\) be the complete family of perfect matchings containing
\(e,g_0\) whose residual complement is the fixed two-path linkage

\[
(15,0)\mid(7,17).
\]

Complete enumeration gives

\[
|\mathcal T_e|=8,
\]

with a \(5+3\) split according to membership of \(g_1\).

## 2. The isolated mixed component

Order the eight matchings lexicographically by their sorted edge lists.
Their complete single-cycle exchange graph has edge set

\[
\{01,02,05,16,27,34,56,57\}.
\]

The \(g_1\)-containing indices are

\[
\{2,4,7\},
\]

so the crossing edges are exactly

\[
02,\qquad34,\qquad57.
\]

The exchange graph has two connected components,

\[
\{3,4\}
\quad\text{and}\quad
\{0,1,2,5,6,7\}.
\]

Thus \(34\) is not merely a bridge: it is an isolated \(K_2\) component,
and both of its endpoints have total exchange degree and cross-degree equal
to one. Explicitly,

\[
\begin{aligned}
M_3=\{&0\!-\!12,1\!-\!11,2\!-\!14,3\!-\!20,4\!-\!16,5\!-\!13,\\
      &6\!-\!18,7\!-\!15,8\!-\!17,9\!-\!19,10\!-\!21\},\\
M_4=\{&0\!-\!12,1\!-\!11,2\!-\!14,3\!-\!21,4\!-\!16,5\!-\!13,\\
      &6\!-\!20,7\!-\!15,8\!-\!18,9\!-\!17,10\!-\!19\}.
\end{aligned}
\]

Their symmetric difference is the alternating ten-cycle

\[
3-20-6-18-8-17-9-19-10-21-3.
\]

This proves:

> **Isolated mixed-component counterexample.** In the complete rooted
> exchange graph of a legal-wide root-square simple plane cubic bipartite
> brace, a cross-sector bridge may form an isolated \(K_2\) component and
> both endpoints may have cross-degree one.

## 3. Consequence for the remaining cardinality problem

The example does not refute

\[
\Gamma_{g_1}(\mathcal T_e)\ne\varnothing
\quad\Longrightarrow\quad
|E\Gamma_{g_1}(\mathcal T_e)|\ne1,
\]

because the other exchange component contributes the two crossings
\(02,57\). It does show that neither an exchange cycle, a triangle, a
commuting square, an endpoint star, nor the entire connected component
containing a given crossing must provide the second crossing.

Consequently any proof of the cardinality statement must couple distinct
connected components of the rooted exchange graph through the common full
perfect-matching incidence, or use an invariant defined on the complete
rooted family at once. Componentwise exchange topology is insufficient.

The fixed
[verification bundle](../computations/bundles/crossing-bridge-star-counterexample/README.md)
reconstructs the complete family and exchange graph. Its terminal marker is
ORDER22_CROSSING_BRIDGE_STAR_COUNTEREXAMPLE_VERIFIED.
