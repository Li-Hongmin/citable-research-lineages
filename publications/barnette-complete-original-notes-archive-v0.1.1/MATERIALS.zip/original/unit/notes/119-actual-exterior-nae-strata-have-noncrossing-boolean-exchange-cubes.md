> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Actual exterior NAE strata have noncrossing Boolean exchange cubes

[Note 118](118-per-stratum-additive-projections-do-not-force-mixed-sector-survival.md)
shows that identities valid separately on each old-exterior stratum
cannot prove mixed-sector survival.  The missing information is which
strata can coexist in the complete NAE family of one actual
triangulation.

This note determines the first such common-realizability constraint
exactly.  For the triangulated disk left after deleting the split vertex,
the symmetric difference of any two NAE strata is a disjoint family of
weak-dual cycles and boundary paths.  Every subfamily can be toggled
independently and integrates to another actual NAE colouring.  Hence
every pair generates a Boolean exchange cube.  The boundary
monochromatic traces form an even delta-matroid with a noncrossing
exchange pairing.

For a mixed rooted bond, its pair-generated cube has one distinguished
gate path.  Avoiding that path gives precisely the original gate sector,
and every such corner retains the root matching edge.  What is not
preserved is the labelled three-region condition: the four-rank balance
and separation of the two ordered root fragments.  Thus the remaining
arrow is a root-labelled choice theorem on the complete exchange-cube
system, not NAE feasibility or ordinary boundary exchange.

## 1. The exterior disk and its split weak dual

Let \(T\) be a simple \(4\)-connected plane triangulation and let
\(z\in V(T)\).  Write the neighbours of \(z\), in cyclic order, as

\[
 L=v_0v_1\cdots v_{m-1}v_0.
\tag{1}
\]

Consecutive neighbours are adjacent because the faces incident with
\(z\) are triangles.  No nonconsecutive pair \(v_i,v_j\) is adjacent:
otherwise \(zv_iv_jz\) would be a nonfacial separating triangle,
contrary to \(4\)-connectivity.  Thus \(L\) is an induced cycle.

Removing the open star of \(z\) from the sphere leaves a triangulated
closed disk.  Its \(1\)-skeleton is

\[
 H=T-z,
\tag{2}
\]

its boundary is \(L\), and

\[
 H\simeq D^2,\qquad H^1(H;\mathbb F_2)=0.
\tag{3}
\]

Here \(H\) denotes the full two-dimensional cell complex, including its
triangular faces.

Define the **split weak dual** \(W(H)\) as follows.  It has one vertex
\(f^\dagger\) for each triangular face \(f\) of the disk.  An interior
edge \(e\in E(H)\), incident with \(f,f'\), gives an edge

\[
 e^\dagger=f^\dagger f'^\dagger.
\tag{4}
\]

For each boundary edge \(e\in E(L)\), incident with the unique triangular
face \(f\), introduce a distinct degree-one terminal \(t_e\) and put

\[
 e^\dagger=f^\dagger t_e.
\tag{5}
\]

Distinct boundary edges therefore remain distinct terminals; they are
not identified at one outer-face dual vertex.

## 2. Integrating monochromatic-edge patterns

For a binary colouring \(\sigma:V(H)\to\mathbb F_2\), put

\[
 \mu_\sigma=\{uv\in E(H):\sigma(u)=\sigma(v)\}.
\tag{6}
\]

The colouring is NAE on every triangular face exactly when every such
face contains one edge of \(\mu_\sigma\).

The converse is the key integrability fact.  Suppose
\(\mu\subseteq E(H)\) contains exactly one edge of each triangular face.
Define

\[
 d_\mu(e)=
 \begin{cases}
 0,&e\in\mu,\\
 1,&e\notin\mu.
 \end{cases}
\tag{7}
\]

Every triangular boundary contains exactly two edges on which \(d_\mu\)
equals \(1\).  Hence \(d_\mu\) is a cellular \(1\)-cocycle.  Equation
(3) makes it exact, so there is a vertex \(0\)-cochain \(\sigma\) with

\[
 d_\mu(uv)=\sigma(u)+\sigma(v).
\tag{8}
\]

Since \(H\) is connected, \(\sigma\) is unique up to addition of the
constant-one cochain.  Equation (8) says that \(\mu=\mu_\sigma\).

**Integration lemma.**  Every edge pattern containing exactly one edge
of each triangular face is the monochromatic-edge pattern of a unique
NAE colouring of \(H\), modulo global reversal.

## 3. The Boolean exchange-cube theorem

Let \(\Omega(H)\) be the complete family of NAE colourings of \(H\)
modulo reversal.  For \(\sigma,\tau\in\Omega(H)\), define

\[
 \Delta(\sigma,\tau)=\mu_\sigma\mathbin\triangle\mu_\tau.
\tag{9}
\]

Let \(\Delta^\dagger(\sigma,\tau)\) be the subgraph of \(W(H)\) formed
by the weak-dual edges \(e^\dagger\) with
\(e\in\Delta(\sigma,\tau)\).

At a triangular face, the two colourings either choose the same
monochromatic edge, giving degree zero in \(\Delta^\dagger\), or choose
different edges, giving degree two.  Every terminal has degree zero or
one.  Therefore every nontrivial component of
\(\Delta^\dagger(\sigma,\tau)\) is either

* a cycle containing no terminal; or
* a path joining two distinct boundary terminals.

Write \(\mathscr C(\sigma,\tau)\) for this component set.  For
\(\mathscr J\subseteq\mathscr C(\sigma,\tau)\), let \(E_H(C)\) be the
triangulation-edge labels on component \(C\), and set

\[
 \mu_{\mathscr J}
 =\mu_\sigma\mathbin\triangle
 \bigcup_{C\in\mathscr J}E_H(C).
\tag{10}
\]

At every face met by a selected component, the toggle removes the unique
\(\mu_\sigma\)-edge and inserts the unique \(\mu_\tau\)-edge.  Every
other face is unchanged.  Thus \(\mu_{\mathscr J}\) again contains
exactly one edge per triangular face, and the integration lemma produces
an NAE colouring \(\sigma_{\mathscr J}\).

Distinct subfamilies give distinct patterns.  We obtain the following
exact closure.

**Exterior exchange-cube theorem.**  Every pair
\(\sigma,\tau\in\Omega(H)\) generates a Boolean cube

\[
 \boxed{
 \{\sigma_{\mathscr J}:
   \mathscr J\subseteq\mathscr C(\sigma,\tau)\}
 \subseteq\Omega(H).}
\tag{11}
\]

These are exactly the globally consistent intermediate edge patterns
which contain one edge per triangular face and, on each face, choose the
monochromatic edge of either \(\sigma\) or \(\tau\).

We call the family of all pair-generated cubes (11) the **exterior
exchange-cube system** \(\mathcal Q(H)\).  No assertion about
intersections of distinct cubes as abstract cells is needed.

## 4. Boundary traces form a noncrossing even delta-matroid

For \(\sigma\in\Omega(H)\), define

\[
 B_\sigma=\mu_\sigma\cap E(L).
\tag{12}
\]

Counting incidences between triangular faces and their selected edges
gives

\[
 |\mathcal F(H)|
 =2|\mu_\sigma\cap(E(H)\setminus E(L))|+|B_\sigma|,
\tag{13}
\]

so every boundary trace has the same parity:

\[
 |B_\sigma|\equiv|\mathcal F(H)|\pmod2.
\tag{14}
\]

Let

\[
 \mathcal B(H)=\{B_\sigma:\sigma\in\Omega(H)\}.
\tag{15}
\]

Take \(B_\sigma,B_\tau\in\mathcal B(H)\) and
\(e\in B_\sigma\triangle B_\tau\).  The terminal edge \(e^\dagger\)
belongs to a unique path component \(C\) of
\(\Delta^\dagger(\sigma,\tau)\).  If \(t_f\) is its other terminal,
toggling \(C\) from either endpoint of the cube gives

\[
 B_{\sigma_C}=B_\sigma\triangle\{e,f\},\qquad
 B_{\tau_C}=B_\tau\triangle\{e,f\}.
\tag{16}
\]

Thus \(\mathcal B(H)\) satisfies the strong symmetric-exchange axiom,
and (14) makes it an even delta-matroid support.

The embedded path components give more than the abstract axiom.  They
pair the elements of \(B_\sigma\triangle B_\tau\) by disjoint arcs in
the disk, hence by a noncrossing pairing in the cyclic boundary order.
Every union of paired paths occurs simultaneously as a corner of (11).

## 5. A mixed rooted bond has one distinguished gate path

Return to an actual labelled split \(T\rightsquigarrow T^+\).  Let
\(G=T^*\) be the cubic plane dual.  A parent NAE colouring \(\xi\)
encodes the perfect matching

\[
 M_\xi=\{a^\vee:a\in\mu_\xi\}\subseteq E(G),
\tag{17}
\]

where \(a^\vee\) is the ordinary plane-dual edge corresponding to the
triangulation edge \(a\).  This notation distinguishes \(a^\vee\) from
the split weak-dual edge \(a^\dagger\).

Suppose

\[
 \chi^b-\eta^{1-b}
\tag{18}
\]

is a mixed parent rooted bond, with \(\chi\) in state \(11\) and
\(\eta\) outside state \(11\).  Align their representatives at \(z\)
and put

\[
 S=\{v\in V(T):\chi(v)\ne\eta(v)\}.
\tag{19}
\]

Both shores are connected, so \(\delta_T(S)\) is a bond.  An edge
changes monochromatic status exactly when it crosses \(S\), whence

\[
 \mu_\chi\triangle\mu_\eta=\delta_T(S).
\tag{20}
\]

The plane dual of a bond is a simple cycle.  Therefore

\[
 M_\chi\triangle M_\eta
 =(\mu_\chi\triangle\mu_\eta)^\vee
\tag{21}
\]

is one simple alternating cycle in \(G\).

Because the local states of \(\chi\) and \(\eta\) differ, the cycle (21)
meets the deleted \(z\)-fan.  Its restriction to the exterior disk is
exactly

\[
 \Delta^\dagger(\chi|_H,\eta|_H),
\tag{22}
\]

and consists only of boundary-to-boundary paths.  A closed exterior
component would be a second cycle component of (21) disjoint from the
fan.  The exterior paths and the complementary fan-side pieces
concatenate to the single cycle (21).

Let \(g_1^*\in E(H)\) be the triangulation edge dual to the surviving
primal gate.  The gate bits of (18) are opposite, so

\[
 g_1^*\in\mu_\chi\triangle\mu_\eta.
\tag{23}
\]

Its split weak-dual edge lies on one unique exterior path \(P_g\).  In
the cube (11), based at \(\chi|_H\), a component toggle changes the gate
bit exactly when the component is \(P_g\).  Hence

\[
 \boxed{\text{the sector-\(b\) corners are precisely those which do not
 toggle \(P_g\).}}
\tag{24}
\]

Let \(e^*\in E(H)\) be the triangulation edge dual to the fixed primal
root edge.  Both endpoints of (18) are rooted targets, so

\[
 e^*\in\mu_\chi\cap\mu_\eta.
\tag{25}
\]

The root edge is absent from the symmetric difference, and every corner
of the pair-generated cube retains it.

Equation (25) preserves only root matching-edge membership.  Full
root-admissibility additionally requires the monochromatic-component
total to equal three and the two ordered root fragments to remain
separated.  In the notation of
[Note 109](109-root-admissible-nae-colourings-have-an-exact-shore-rank-calculus.md),
one needs both

\[
 \rho_{00}+\rho_{11}=\rho_{10}+\rho_{01}
\tag{26}
\]

and ordered root-fragment separation.  Exterior path toggles can merge
or split monochromatic components, so neither condition follows from
(11), (16), noncrossing, or gate-path avoidance.

## 6. The remaining root-labelled selection lemma

For \(\sigma\in\Omega(H)\), use the following closure predicates.

* \(P_{\neg11}^b(\sigma)\) means that \(\sigma\), with a suitable colour
  at \(z\), has a root-admissible non-\(11\) parent closure in sector
  \(b\).
* \(X_N^b(\sigma)\), for \(N\in\{R,U,V\}\), means that \(\sigma\) has a
  root-admissible child closure in cell \(N\) and sector \(b\).

These predicates include the interval NAE conditions, component-rank
condition, and ordered root separation.  They decorate the vertices of
the complete exchange-cube system; they are not consequences of its
undecorated boundary trace.

The exact remaining statement is the following.

**Root-labelled cubical selection lemma (open).**  Suppose an actual
interface-disjoint legal split has a state-\(11\) rooted parent target
\(\chi^b\) and a non-\(11\) rooted parent target \(\eta^{1-b}\) which
form a rooted bond.  Then some sector-\(b\) exterior
\(\sigma\in\Omega(H)\) satisfies

\[
 \boxed{
 P_{\neg11}^b(\sigma)
 \quad\text{or}\quad
 X_R^b(\sigma)\vee X_U^b(\sigma)\vee X_V^b(\sigma).}
\tag{27}
\]

The selected \(\sigma\) is not required to lie in the single cube
generated by \(\chi|_H,\eta|_H\); the complete actual exchange-cube
system may be necessary.

If \({\cal L}_{\neg11}^{\,b}=\varnothing\), the first disjunct in (27)
is impossible, and (27) gives \({\cal N}^b\ne\varnothing\), exactly
\(P_{\rm sector}\) of
[Note 117](117-mixed-sector-survival-is-a-gate-even-parent-child-exchange-alternative.md).

Thus the only unproved arrow in the mixed branch is a **root-labelled
choice theorem**: select a gate-even exterior whose parent or child
gluing satisfies both (26) and ordered root separation.  NAE feasibility,
componentwise exchange, gate parity, and root-edge membership are already
supplied by the theorems above.

The exterior exchange-cube theorem itself uses neither Eulerianity nor
enumeration; it applies to every connected triangulated disk.  Eulerianity
belongs to the actual parent/child setting of the open selection lemma.
No convexity or delta-matroid axiom for the root-component decorations is
asserted.
