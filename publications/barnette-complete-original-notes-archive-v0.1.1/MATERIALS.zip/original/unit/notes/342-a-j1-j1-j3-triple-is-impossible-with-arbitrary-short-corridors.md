> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A J1,J1,J3 triple is impossible with arbitrary short corridors

[Note 337](337-every-consecutive-j1-j3-three-double-group-reduces-to-a-square.md)
excludes the consecutive \(J_1,J_1,J_3\) order.
Here both internal short-block corridors and both outer
short flanks may have arbitrary lengths. The first two
\(J_1\) blocks either enclose a forbidden two-edge cut
or force the square-equivalent patch of
[Note 332](332-two-j1-double-blocks-across-a-short-corridor-have-the-square-signature.md).
The latter reduction leaves one \(J_3\) block, which is
excluded by [Note 334](334-every-all-j1-double-vacancy-group-reduces-to-squares.md).

Use the compressed, gapless, tight-target all-square opening
of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix an ordinary target-free free group with exactly three
doubly vacant complete blocks in old-cycle order
\[
D_s=(a_s,o_s,h_s,i_s,k_s,j_s,e_s,b_s),\qquad s=1,2,3,
                                                               \tag{1}
\]
carrying \(o_1k_1=J_1,\ o_2k_2=J_1,\ i_3e_3=J_3\).
All other complete blocks are short. Let
\(S_t=(c_t,u_t,v_t,d_t)\), \(1\le t\le p\), lie between
\(D_1,D_2\), and let
\(T_t=(c'_t,u'_t,v'_t,d'_t)\), \(1\le t\le q\), lie between
\(D_2,D_3\). Either length may be zero. Outer short
flanks are unrestricted.

**Nonalternating exclusion theorem.** No Barnette graph
has such a selected opening for any \(p,q\ge0\).
Old-cycle reflection also excludes the order
\(J_1,J_3,J_3\) with arbitrary internal corridors and
outer short flanks.

**Proof.** The chord-isolation lemma of
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
fixes the three internal chords and excludes all other
same-block free chords. Cross-block free chords are
noncrossing on the side opposite the common face by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
After the internal chord endpoints are removed, the
ordered free slots of the three-double interval are
\[
h_1,i_1,j_1,e_1,\ (u_t,v_t)_{t=1}^{p},\
h_2,i_2,j_2,e_2,\ (u'_t,v'_t)_{t=1}^{q},\
o_3,h_3,k_3,j_3.                                        \tag{2}
\]
The short-block slots \(u_t,u'_t\) are odd and
\(v_t,v'_t\) are even.

The even slot \(h_1\) can meet only \(i_2\) or \(j_3\).
Its same-block odd choices \(i_1,j_1\) are an
old-cycle edge and a forbidden chord. The odd
candidate \(u_t\) encloses \(3+2(t-1)\) free slots;
\(j_2\) encloses \(5+2p\);
\(u'_t\) encloses \(7+2p+2(t-1)\);
and \(o_3\) encloses \(7+2p+2q\).
All these counts are odd. A left outer short-block
odd slot encloses its second slot plus complete
left-flank pairs; a right outer odd slot or the
right endport encloses \(11+2p+2q\) remaining core
slots plus complete flank pairs. These are odd too.
The chords \(h_1i_2\) and \(h_1j_3\) alone enclose
even numbers of free slots.

If \(h_1j_3\) occurred, every other residual free
slot of \(D_1,S_1,\ldots,S_p,D_2,T_1,\ldots,T_q,D_3\)
would lie strictly inside it. Noncrossing forces
those slots to match within this full block interval.
All three internal chords and every face-closing
chord also have both endpoints inside the full
block interval. Only its two boundary old-cycle
edges would leave, contrary to three-edge-connectivity.
Therefore \(h_1i_2\) is forced.

Inside \(h_1i_2\), the odd slot \(i_1\) can meet only
\(h_2\). Its same-block \(i_1e_1\) is excluded by
chord isolation, while each \(i_1v_t\) encloses
\(2t+1\) free slots. A mate outside \(h_1i_2\)
would cross it. Thus \(i_1h_2\) is forced.
The residual slots inside \(i_1h_2\) are
\[
       j_1,e_1,u_1,v_1,\ldots,u_p,v_p.                 \tag{3}
\]
If \(p=0\), they would have to use the old-cycle edge
\(j_1e_1\), so \(p\ge1\).

The odd slot \(j_1\) must meet some \(v_t\).
If \(t<p\), the nonempty suffix
\(S_{t+1},\ldots,S_p\) is trapped outside \(j_1v_t\)
but inside \(i_1h_2\), and its complete short blocks
would be matching-closed. Their two old-cycle
boundary edges give a forbidden two-edge cut.
Hence \(j_1v_p\) is forced. Inside this chord,
\(e_1\) must meet \(u_1\): choosing a later \(u_t\)
would close \(S_1,\ldots,S_{t-1}\) under the matching.
The same argument successively forces
\(v_tu_{t+1}\) for \(1\le t<p\).

Consequently the block interval \(D_1,S_1,\ldots,S_p,D_2\)
is precisely the induced square-equivalent four-pole
\(Q_p\) of Note 332. Its only degree-two terminals
are \(a_1,j_2,e_2,b_2\); the matching just proved
does not use any property of \(D_3\), the second
corridor or the outer flanks. Replace \(Q_p\) by
its labeled square. Note 332 proves that this
replacement preserves Barnette membership and
the selected compressed, gapless, tight-target
all-square opening. The resulting ordinary free
group contains exactly one \(J_3\) doubly vacant
block, \(D_3\), and otherwise only short blocks.
By the reflection of Note 334's single-double-block
exclusion, no such group exists. This contradiction
proves the theorem. Reflection proves the stated
\(J_1,J_3,J_3\) case. \(\square\)

Together with [Note 341](341-no-short-corridor-after-the-middle-block-of-an-alternating-triple.md),
this removes both the alternating right-corridor
branch and two of the four nonalternating mixed
orders for exactly three \(J_1/J_3\) double blocks.
The orders \(J_3,J_1,J_1\) and \(J_3,J_3,J_1\),
which are reflections of each other, have the
sharp corridor-position restriction and a real
Barnette instance of
[Note 343](343-a-j3-j1-j1-triple-needs-a-right-corridor-and-occurs.md).
Other internal-chord types, singly vacant blocks in
the same group, target defects, positive gaps,
non-square residual cycles and the general Barnette
conjecture are not decided here. The proof is
project-internal; no external priority or independent
review is claimed.
