> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One omitted small rank inequality can create a fractional local-block extreme point

[Note 044](044-small-laminar-leaf-deletion-is-a-restricted-dual-and-joint-rotation-problem.md)
identifies unrestricted deletion of a positive dual leaf \(W\) with a
restricted primal in which the graphic-rank inequality for \(W\) is
removed. This note shows that the fractional quantifier in that primal is
essential. Planarity and \(3\)-connectivity of the rank graph, together
with separate triangle and path partition blocks, do not preserve
integrality after one four-point rank row is deleted.

## A planar local-block extreme point

Let

\[
 Q=K_5-03,
 \qquad
 W=\{1,2,3,4\}.
\]

The graph \(Q\) is the triangular bipyramid with apices \(0,3\) and base
\(1,2,4\). It is planar and \(3\)-connected. Partition its nine edges
into

\[
\begin{aligned}
 D_0&=\{01,02,12\},\\
 D_1&=\{04,14\},\\
 D_2&=\{13,23\},\\
 D_3&=\{24,34\}.
\end{aligned}
\tag{1}
\]

The first block is a triangle and the other three are two-edge paths.
Define \(x\in\mathbb R^{E(Q)}\) by

\[
 x_{12}=x_{13}=1,
 \qquad
 x_{04}=x_{14}=x_{24}=x_{34}=\frac12,
\tag{2}
\]

and put \(x_{01}=x_{02}=x_{23}=0\). Then

\[
 x(D_i)=1\quad(0\le i\le3),
 \qquad
 x(E(Q))=4=|V(Q)|-1.
\tag{3}
\]

For every nonempty proper \(U\subset V(Q)\), direct evaluation gives

\[
 x(E_Q(U))\le |U|-1
\]

except at \(U=W\), where

\[
 x(E_Q(W))=\frac72>3.
\tag{4}
\]

Thus \(x\) is feasible for the common partition--graphic relaxation with
exactly the inequality indexed by \(W\) omitted.

## Extremality

The following nine active equations are linearly independent:

- the four block equations in (3);
- \(x_{01}=x_{02}=x_{23}=0\);
- the tight rank equations on \(\{1,2,4\}\) and \(\{1,3,4\}\).

Indeed, the zero rows and \(D_0,D_2\) first give

\[
 x_{12}=x_{13}=1.
\]

The remaining tight equations reduce to

\[
 x_{14}+x_{24}=1,
 \qquad
 x_{14}+x_{34}=1,
 \qquad
 x_{24}+x_{34}=1.
\tag{5}
\]

Hence \(x_{14}=x_{24}=x_{34}=1/2\), and the equation for \(D_1\)
then gives \(x_{04}=1/2\). The nine rows therefore have rank nine and
determine (2) uniquely. In particular, \(x\) is a fractional extreme
point, not merely a fractional feasible average.

Consequently,

\[
\boxed{
\begin{gathered}
\text{planar \(3\)-connected rank graph}\\
+\ \text{separate triangle/path block shapes}\\
+\ \text{one omitted four-point rank inequality}
\end{gathered}
\not\Longrightarrow
\text{integrality}.}
\tag{6}
\]

## The pure one-hole comparison

The corresponding relaxation without partition equations admits a useful
reduction, but its four-point case is not settled here. For a connected
loopless multigraph \(Q\), put

\[
\mathcal P_{\neg W}(Q)=
\left\{
x\ge0:
\begin{array}{l}
x(E(Q))=|V(Q)|-1,\\
x(E_Q(U))\le |U|-1
\quad(\varnothing\ne U\subsetneq V(Q),\ U\ne W)
\end{array}
\right\}.
\tag{7}
\]

Suppose \(x\in\mathcal P_{\neg W}(Q)\) and

\[
x(E_Q(W))=|W|-1+t,\qquad t>0.
\]

No tight proper rank set \(S\) can partially cross \(W\). Indeed, if all
three sets \(S\cap W,S\setminus W,W\setminus S\) are nonempty, then

\[
\begin{aligned}
x(E_Q(S))+x(E_Q(W))
={}&x(E_Q(S\cap W))+x(E_Q(S\cup W))\\
&-x(E_Q(S\setminus W,W\setminus S)).
\end{aligned}
\tag{8}
\]

The rank bounds on \(S\cap W\) and \(S\cup W\), using the full equation
when \(S\cup W=V(Q)\), turn (8) into

\[
|S|-1+|W|-1+t
\le |S\cap W|-1+|S\cup W|-1,
\]

which forces \(t\le0\), a contradiction. Thus every tight set is
contained in \(W\), contains \(W\), or is disjoint from \(W\).

Fractionality nevertheless occurs with five points. Take

\[
Q=K_6,\qquad W=\{0,1,2,3,4\},
\]

and define

\[
x_{12}=x_{13}=x_{14}=1,\qquad
x_{02}=x_{03}=x_{04}=x_{05}=\frac12,
\tag{9}
\]

with all other coordinates zero. The only violated proper rank inequality
is that of \(W\), since \(x(E_Q(W))=9/2>4\). The point is extreme:
the three tight pair rows fix \(x_{1i}=1\), the three tight rows on
\(\{0,1,i,j\}\) give

\[
x_{0i}+x_{0j}=1
\qquad(ij\in E(K_{\{2,3,4\}})),
\]

and this odd triangle forces \(x_{02}=x_{03}=x_{04}=1/2\); the full
equation then fixes \(x_{05}=1/2\).

The no-partial-crossing reduction does not yet prove integrality when
\(|W|\le4\). The unresolved linear-algebra step is the simultaneous
normal form for tight rows contained in \(W\) and tight rows containing
\(W\), both of which carry the same internal \(E_Q(W)\) columns.
Accordingly, no four-point pure integrality claim is made.

## Realizability boundary

This is not an actual plane-brace or FEC counterexample. In the
contracted dual of a legal site, one distinguished \(X\)-block is a
root-incident parallel pair, and the \(X\)- and \(Y\)-blocks inherit a
common two-colour rotation from the same simple plane cubic bipartite
graph. The partition (1) has three path blocks and no parallel block.
It therefore preserves only the separate local triangle/path shapes, not
the full one-colour signature or the joint primal--dual rotation.

The smallest \(3\)-connected full \(X\)-side signature behaves
differently. On five rank vertices there are four blocks: one triangle,
one designated parallel pair, and two length-two paths. Allow repetitions
between different blocks at the outset. Three-connectivity forces the
underlying simple graph to have minimum degree three and hence at least
eight edges. The nine labels already contain the designated repetition,
so there are exactly eight endpoint pairs and no further repetition.

Up to permutations of the five rank vertices and interchange of the two
path blocks, the resulting \(420\) labelled patterns have four isomorphism
types. For each type and every omitted \(W\) of size two, three, or four,
exact vertex enumeration gives

\[
4\left[\binom52+\binom53+\binom54\right]=100
\]

one-hole block systems and \(1426\) vertices in total. Every vertex is
integral. Thus the half-integral mechanism in (2) cannot be repaired
merely by replacing one path with the required parallel block while
retaining a five-vertex \(3\)-connected rank graph.

This is a finite smallest-order statement. It does not cover rank order
at least six, a contracted rank graph that loses three-connectivity, or
the simultaneous \(X/Y\) rotation of an actual site.

The remaining question from Note 044 is correspondingly unchanged at the
brace level: the actual rotation and \(2\)-extendability may still exclude
every fractional low-cost point whose unique omitted inequality has

\[
 |W|\le4.
\]

The exact certificate is checked by

    python3 units/barnette/computations/verify_fractional_local_block_one_rank_extreme_point.py
    python3 units/barnette/computations/verify_five_vertex_full_x_signature_integrality.py

with terminal markers
FRACTIONAL_LOCAL_BLOCK_ONE_RANK_EXTREME_POINT_VERIFIED and
FIVE_VERTEX_FULL_X_SIGNATURE_INTEGRALITY_VERIFIED.
