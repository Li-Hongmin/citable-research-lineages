> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two-vacancy free groups have only three boundary states

[Notes 218--219](219-one-short-block-between-two-vacancies-has-three-hamilton-matchings.md)
classify isolated double-vacancy groups with zero or one short
face block between the vacancies. The boundary restriction
behind those classifications does not depend on the number
of intermediate short blocks.

Use a compressed all-square opening with empty interblock gaps,
tight target order and exactly two eligible vacancies. Suppose
they lie in distinct target-free four-slot face blocks
\(B_k,B_m\), \(1\le k<m\le r\), with no occupied target
run between them. Suppose the free group containing them
begins at \(e_{k-1}\) and ends at \(o_{m+1}\), so it is
\[
e_{k-1},\ (o_k,h_k,i_k,e_k),\
(o_{k+1},e_{k+1}),\ldots,(o_{m-1},e_{m-1}),\
(o_m,h_m,i_m,e_m),\ o_{m+1}.                    \tag{1}
\]
The intermediate blocks are short. An empty middle sequence
is allowed.

**Three-boundary-state theorem.** The free matching satisfies
\[
M(e_{k-1})\in\{o_k,i_m\},\qquad
M(o_{m+1})\in\{h_k,e_m\}.                       \tag{2}
\]
The two long choices cannot occur together. Thus the only
boundary states are
\[
\begin{array}{c|cc}
&M(e_{k-1})&M(o_{m+1})\\
\text{ordinary--ordinary}&o_k&e_m\\
\text{long left}&i_m&e_m\\
\text{long right}&o_k&h_k .
\end{array}                                   \tag{3}
\]
This is a necessary structural statement for every corridor
length \(m-k-1\); it does not assert Hamiltonicity for all
matchings in the three states.

**Proof.** The occupied-target barriers of Note 215 close
(1) under the free matching. Every cross-block free chord
lies in the opposite-side disk by Note 193, and those chords
are noncrossing. The odd-colour candidates for the even
endpoint \(e_{k-1}\) are \(o_k,i_k\), the first slots
\(o_j\) of the intermediate blocks, \(o_m,i_m\),
and \(o_{m+1}\).

It cannot match \(i_k\). The two free slots \(o_k,h_k\)
inside that chord are adjacent on \(C\). If \(o_k\)
uses its possible same-block chord \(o_ke_k\) on the
other side, \(h_k\) remains without an inside mate;
every cross-block mate outside \(e_{k-1}i_k\) would
cross it. If \(e_{k-1}\) matches any later first slot
\(o_j\), \(k<j\le m+1\), its chord encloses the
nonempty complete block interval \(B_k,\ldots,B_{j-1}\).
Noncrossing makes that interval closed under the
complementary matching, including any same-block
chords. Its only outgoing edges are its two boundary
old-cycle edges, contrary to three-connectivity.
Thus its only possible mates are \(o_k,i_m\).

Reverse the old-cycle order and interchange the site
labels. The same argument gives the second containment
in (2). Finally the chords \(e_{k-1}i_m\) and
\(h_ko_{m+1}\) would alternate in old-cycle order.
Both join different blocks and lie in the opposite-side
disk, so they cannot coexist in a plane graph. This
leaves precisely (3). \(\square\)

**Same-block chord exclusion.** In every opening satisfying
(1), neither \(o_ke_k\) nor \(o_me_m\) belongs to \(M\).
Consequently every free matching edge joins different blocks
and all free matching chords lie in the same noncrossing
opposite-side disk.

**Proof.** Suppose \(o_ke_k\in M\). The left boundary
cannot then use \(e_{k-1}o_k\), so (2) forces
\(e_{k-1}i_m\in M\), while the right boundary is
ordinary. The even slot \(h_k\) cannot match its adjacent
odd slot \(i_k\), the used \(o_k,i_m\), or an odd slot
beyond \(i_m\), because such a cross-block chord would
cross \(e_{k-1}i_m\). Its mate must therefore be
the first odd slot \(o_j\) of an intermediate block
or \(o_m\), for some \(k<j\le m\).

Strictly between \(h_k\) and \(o_j\) are \(i_k,e_k\)
and zero or more complete short-block free pairs.
The vertex \(e_k\) is already matched to \(o_k\)
on the other side of \(h_ko_j\). After removing it,
an odd number of free vertices remain strictly inside
that opposite-side chord. None can match outside
without crossing \(h_ko_j\); no other same-block
free chord has one endpoint in this interval and one
outside it. This contradicts perfect matching.
Thus \(o_ke_k\notin M\). Reflecting the argument
excludes \(o_me_m\). The remaining free edges are
cross-block, so Note 193 places them all in the
opposite-side disk. \(\square\)

**Canonical ordinary-edge theorem.** Call
\(e_{k-1},o_k,e_k,\ldots,o_m,e_m,o_{m+1}\)
the *ordinary* free slots of (1), leaving out
\(h_k,i_k,h_m,i_m\). If an edge of the free matching
has two ordinary endpoints, it is one of
\[
e_jo_{j+1},\qquad k-1\le j\le m.             \tag{4}
\]
Consequently every deviation from the standard free
chain touches at least one of the four vacancy slots.

**Proof.** By the preceding theorem, every free matching
edge joins different blocks and lies in the same
noncrossing disk. An ordinary-to-ordinary edge joins
some \(e_i\) to some \(o_j\). If \(j=i+1\), it is
in (4). If \(j\ge i+2\), its chord encloses the
nonempty complete block interval
\(B_{i+1},\ldots,B_{j-1}\). All matching edges of
that interval stay inside the chord, so this block
interval is closed under \(M\) and has only two
outgoing \(C\)-edges, impossible. The case \(j=i\)
is the excluded same-block chord.

If \(j<i\), the chord runs from the first free slot
of \(B_j\) to the last free slot of \(B_i\).
Every free slot of the complete interval
\(B_j,\ldots,B_i\) lies on or inside this chord.
A free matching edge leaving the interval would
cross it in the opposite-side disk; the block
endpoints are already matched by their internal
face chords. Hence this complete block interval
would again have a two-edge cut. Thus no other
ordinary-to-ordinary edge exists. \(\square\)

In particular, let \(c\) be the number of matching edges
whose two endpoints are among the four vacancy slots.
There are exactly
\[
2-c                                                     \tag{5}
\]
missing edges of the ordinary chain (4), so at most two
chain edges can be altered. Indeed, each missing chain
edge has both ordinary endpoints matched to vacancy
slots, giving \(2(2-c)=4-2c\) such endpoints.
This reduces every corridor length to the placement
and pairing of at most two altered chain links.

For zero or one intermediate short block, Notes 218--219
classify the matching inside each boundary state and prove
a marked Hamilton cycle. With two or more intermediate
blocks, the interior matchings of (3) are not classified
by this theorem. The paired-square profile in Note 217
realizes the ordinary--ordinary state for every length.
[Note 221](221-every-isolated-two-vacancy-corridor-has-a-marked-hamilton-cycle.md)
subsequently uses (4)--(5) to prove marked Hamiltonicity
for every corridor length without classifying each
individual chord placement.
