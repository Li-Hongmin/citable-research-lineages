> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A real retained-edge reattachment collision for the fourteen-slot summary

Let \(\Sigma_+(Z)\) be the complete one-step successor summary of
[Note 169](169-corrected-fourteen-slot-fixed-operation-interface-go.md), and
let \(\nu(Z,q)\) be exactly the fourteen-slot finite datum of
[`scratch/r3_pulse4/DEFS.md`](../scratch/r3_pulse4/DEFS.md), with the four
future gadget colours evaluated correctly. The datum keeps equality, colour,
target status and identity, existence, and the marked-role face word, but not
unmarked vertices or facial-arc lengths. Write \(\Sigma_{\rm next}(Z,q)\) for
the full next summary, including metadata and complete exterior-row support,
after cutting the two edges of the current site and the selected retained
edge \(q\), with the new \(q\) endpoints active.

> **Theorem.** There are two real legal histories \((Z,q_1)\) and \((Z,q_2)\)
> in the two-consecutive-\(o^*\) domain such that
> \[
> (\Sigma_+(Z),\nu(Z,q_1))=(\Sigma_+(Z),\nu(Z,q_2)),
> \qquad
> \Sigma_{\rm next}(Z,q_1)\ne\Sigma_{\rm next}(Z,q_2).
> \]
> Consequently no deterministic reattachment map on this proposed input
> summary computes the complete next summary over its full real domain.

## The two legal histories

Start with the cube and its ordered site \((0,1,2,3)\), with edges as in the
[frozen SPEC](../SPEC-2026-09-12-upgrade.md). The first expansion creates
\(8,9,10,11\). In its resulting graph \(G_1\), take
\[
s_1=(0,8,9,1),\qquad r=(11,3).
\]
The face \((0,8,9,1,5,4)\) contains the two site edges in the required
order. Expanding \(s_1\) creates \(12,13,14,15\) and gives a graph \(Z\)
with the successor site
\[
s_2=(0,12,11,3).
\]
Indeed, the former face \((0,3,11,8)\) becomes
\((0,12,13,8,11,3)\), which contains \(s_2\) in the required order.
Thus the first of the two consecutive operations has precisely the fixed
\(o^*\) form \((u,v,x,y;r_0,r_1)\mapsto(u,a,r_0,r_1)\).

For direct inspection, \(Z\) has edge set
\[
\begin{split}
\{&(0,3),(0,4),(0,12),(1,2),(1,5),(1,15),(2,6),(2,10),
   (3,7),(3,11),(4,5),(4,7),\\
  &(5,6),(6,7),(8,9),(8,11),(8,13),(9,10),(9,14),(10,11),
   (12,13),(12,15),(13,14),(14,15)\}.
\end{split}
\]

Expand \(s_2\), creating \(16,17,18,19\). The face
\((0,12,15,1,5,4)\) becomes
\[
(0,16,17,12,15,1,5,4).
\]
On this face both retained edges
\[
q_1=(15,1),\qquad q_2=(5,4)
\]
give legal ordered successors \((0,16,15,1)\) and \((0,16,5,4)\).
Their residual facial-arc lengths are respectively \((3,3)\) and \((5,1)\).
At each site the two initial endpoints have the same bipartition colour;
the displayed arcs have odd length. The expansions take place inside the
displayed faces, and the legal-expansion preservation theorem of
[Note 006](006-theorem-level-corrections-and-positive-depth-support-theorem.md)
gives simple cubic bipartite planar 3-connected intermediate graphs.
[The complete rotation systems and edge ledger](../scratch/r3_pulse5/CERTIFICATE.md)
specify both real histories, including their distinct terminal caps.
The independent small-graph checker
[`verify_real_collision.py`](../scratch/r3_pulse5/verify_real_collision.py)
also checks cubicity, bipartiteness, and connectivity three directly.

Fix the same ordered targets in both histories:
\[
e=2\!-!6,\qquad f=9\!-!10.
\]
The graph \(Z\), current site, targets, and entire history up to \(Z\) are
identical, so \(\Sigma_+(Z)\) is literally identical. For either choice of
\(q\), the fourteen ordered slots are
\[
(U,V,X,Y,Q_0,Q_1,E_0,E_1,F_0,F_1,A,B,C,D)
=(0,12,11,3,q_0,q_1,2,6,9,10,16,17,18,19).
\]
All fourteen classes are distinct. Their colour word, normalized up to
global reversal, is in both cases
\[
(0,1,0,1,0,1,0,1,0,1,1,0,1,0).
\]
The first ten classes exist and the four future classes do not yet exist in
\(Z\). Both targets are live external edges, distinct from either \(q\),
with the same endpoint, location, and birth-status tags in both histories.
Deleting unmarked vertices from the displayed face gives, in both cases,
the identical marked-role code
\[
(\texttt{UA},(A,B,V,Q_0),\texttt{SEP},(Q_1),\texttt{SEP}).
\]
These are all fields of the frozen \(\nu\), proving equality of the complete
input keys. The different numerical arc lengths are deliberately absent
from that finite datum.

## One separating exterior row

For both next inputs use the ordered active boundary
\((U,V,X,Y,Q_0,Q_1,E_0,E_1,F_0,F_1)\). Consider the row with degree word
\[
(0,0,0,0,0,0,0,2,2,0),
\]
singleton component partition on all ten active classes, zero components
missing the interface, and target-use bits \((0,0)\).

For \(q_1\), this row is realized by the eight-edge subgraph
\[
F=C_4(4,5,6,7)\;\dot\cup\;C_4(8,9,14,13).
\]
None of its edges is among \(0\!-!12,11\!-!3,15\!-!1\). Every vertex
outside the active boundary has degree two. The two cycles meet the boundary
only at \(E_1=6\) and \(F_0=9\), respectively; every other boundary vertex
is isolated. Thus \(F\) has exactly the asserted complete row.

For \(q_2\), the same row would give degree zero to \(Y=3\) and
\(Q_1=4\). Vertex \(7\) lies outside the active boundary and has precisely
the neighbours \(3,4,6\) in \(Z\). Only its edge to \(6\) could then be
selected, so it cannot have the required degree two. Hence the row is absent
from \(\Sigma_{\rm next}(Z,q_2)\), completing the proof without an exhaustive
nonexistence computation.

This is a NO-GO for the specified \((\Sigma_+,\nu)\) reattachment summary.
It leaves Note 169's one-step theorem intact and does not refute any possible
enriched finite summary, the global \(H^{+-}\) property, or statement (T) of
the frozen SPEC. It supplies the real collision required before the SPEC's
Route 3 refinement can be considered; no refinement is claimed here.
