> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Diwan specified chords do not force the ordered Hamilton path

[Note 067](067-the-direct-target-is-an-ordered-hamilton-path-and-fixed-y-helly-fails.md)
identifies the direct four-common-base target with the following statement.
For a rooted simple plane cubic bipartite brace (F), with
(N_F(r)=\{a,b,s\}), there should be a vertex (y) in the opposite root
class and an (a)--(y) Hamilton path passing through (r) in the order
(b-r-s).  This note determines what follows from Diwan's specified-chord
theorems.

The existing theorems force the correct local pairing at the root, but not a
spanning factor component.  Consequently they do not imply the ordered
Hamilton-path target.

## The exact quantifier in the specified-chord theorem

Diwan's Theorem 1 states that every edge of a (2)-edge-connected planar
cubic graph is either contained in a (2)-edge-cut or is a chord of some
cycle contained in a (2)-factor.  The cycle containing the chord need not be
the entire (2)-factor.

Theorem 3 applies this result to an edge (uv) of a planar cubic graph.
Write

\[
N(u)\setminus\{v\}=\{u_1,u_2\},\qquad
N(v)\setminus\{u\}=\{v_1,v_2\},
\]

where (u_1,u,v,v_1) and (u_2,u,v,v_2) occur on the two sides of (uv).
Delete (u,v), add (u',v'), and join

\[
N(u')=\{u_1,v_1,v'\},\qquad
N(v')=\{u_2,v_2,u'\}.
\tag{1}
\]

If (C) is a (2)-factor cycle having (u'v') as a chord, planarity
forces

\[
C-\{u',v'\}=P_{u_1u_2}\sqcup P_{v_1v_2}.
\tag{2}
\]

Thus the construction already supplies the desired local noncrossing
pairing.  The missing condition is global: the proof explicitly retains
“the cycles other than (C) in the (2)-factor ... (if any)”.

To obtain the ordered Hamilton path from this construction, one would have
to strengthen Theorem 1 so that the specified chord lies in a Hamilton cycle
of the auxiliary graph.  Applied to (uv=rs), this would return a perfect
matching (M\ni rs) such that (F-M) consists of exactly two cycles
separating (r) and (s).  In the notation of Notes 058 and 063, this is

\[
\mu_F(rs)=2,
\tag{3}
\]

the RCA target itself.  It is sufficient for the ordered-Hamilton direct
target but is stronger than it, since a direct path witness need not admit
the same perfect-matching completion.  Reading Hamiltonicity into the
specified-chord conclusion would therefore assume a stronger open statement.

Diwan's Theorem 5, which places two prescribed edges on the same (2)-factor
cycle, has the same boundary.  Choosing the two root edges can force the local
subpath (b-r-s), but it neither makes that cycle spanning nor removes the
other factor cycles.

The source checked here is R. Diwan, “Chords of 2-factors in planar cubic
bridgeless graphs”, *Graphs and Combinatorics* **38**, 177 (2022), DOI
`10.1007/s00373-022-02583-y`, arXiv:2110.12584v1.  The statements and proof
quantifiers were checked against the full text on 2026-08-26.

## A real plane-brace nonspanning output

The phrase “if any” is realized already by the (12)-vertex plane brace from
[Note 064](064-the-planar-two-path-target-holds-through-order-eighteen.md),
with graph6 string

    K??FEagT@WB_

Take root edge (rs=07) and the perfect matching

\[
M=\{07,16,2\,10,3\,11,48,59\}.
\tag{4}
\]

Its complementary (2)-factor is

\[
(0,6,2,8),\qquad(1,7,3,9),\qquad(4,10,5,11).
\tag{5}
\]

The root ends lie on different cycles, but a third (C_4) remains.  In the
auxiliary construction (1), take

\[
u_1=6,\quad u_2=8,\quad v_1=1,\quad v_2=3.
\]

The first two cycles in (5) become an (8)-cycle for which (u'v') is a
chord, while the last (C_4) is unchanged.  Hence the auxiliary (2)-factor
has component sizes

\[
(8,4),
\tag{6}
\]

and satisfies the specified-chord theorem without producing a spanning chord
cycle.

This is not an RCA or ordered-Hamilton counterexample.  For the same root,
the complete separated-matching cycle-count distribution is

\[
\#\{c=2\}=3,\qquad \#\{c=3\}=1.
\tag{7}
\]

Thus good outputs coexist with the bad output (4); the existing theorem has
no selection mechanism distinguishing them.

The verifier
[verify_diwan_nonspanning_chord_witness.py](../computations/verify_diwan_nonspanning_chord_witness.py)
checks the embedded brace, matching (4), factors (5)--(6), the chord, and the
complete distribution (7).  Reproduce with

    uv run python \
      units/barnette/computations/verify_diwan_nonspanning_chord_witness.py

## Boundary

**Exact conclusion.** Diwan's current specified-chord and two-specified-edge
theorems force the correct local root pairing but do not force the spanning
component needed by the ordered-Hamilton target.

**Weakest load-bearing step.** This closes the quantifiers of the published
theorems and the route of taking an arbitrary theorem output.  It does not
exclude a future Diwan-style induction with a new global cycle-rank or
spanning invariant.

**Evidence level.** The theorem boundary is a proof-level reading of the
published statements and construction.  Equations (4)--(7) are an exact
finite certificate in a real plane brace.

**Unresolved boundary.** It remains open whether the special-colouring
induction can be strengthened by a global invariant, or whether the weaker
direct-dual free-face defect can be propagated without proving the stronger
RCA condition (3).
