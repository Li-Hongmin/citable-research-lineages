> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Planar two-path covers require root-preserving cycle absorption

The general prescribed two-path strengthening is false by
[Note 056](056-integral-two-path-strengthening-fails-while-the-fractional-degree-box-survives.md).
This note isolates the remaining planar statement and proves that the
pairwise co-cyclicity theorem of Diwan does not supply its missing global
step.

## Spanning-linkage and closure formulations

Let \(F\) be a simple plane cubic bipartite brace with bipartition
\(X\sqcup Y\), where \(|X|=|Y|=n\).  Fix \(r\in Y\), write

\[
N_F(r)=\{a,b,s\},\qquad P=F-r,
\]

and fix the port split \(\{s\}\mid\{a,b\}\).  The planar integral
statement is

\[
\tag{A}
P\text{ has vertex-disjoint paths }Q_{ab},Q_{sy}
\text{ whose union spans }P,
\]

where \(y\in Y\setminus\{r\}\) is free.

Condition (A) is a one-free-end spanning 2-linkage.  It also has two exact
artificial closure formulations.

1. After adding a labelled edge \(bs\), there is a Hamilton path from
   \(a\) to some \(y\in Y\setminus\{r\}\) with the order

   \[
   a\leadsto b-bs-s\leadsto y.                              \tag{1}
   \]

   Deleting \(bs\) recovers the two paths.  Merely asking for a Hamilton
   path containing \(bs\) is insufficient, because the opposite order
   gives the wrong port partition.
2. For some \(y\), the graph \(P+ab+sy\), with labelled artificial copies
   allowed, has a spanning 2-factor with exactly two cycles, in which
   \(ab\) and \(sy\) lie on different cycles.

These closures are exact, but the added graphs are generally neither cubic
nor bipartite, and the artificial edges need not preserve planarity.

## The planar-dual target is a face-constrained unicycle

For \(J=Q_{ab}\cup Q_{sy}\), put

\[
K=E(P)\setminus E(J).
\]

Every \(x\in X\) has \(\deg_K(x)=1\).  Every
\(z\in Y\setminus\{r,y\}\) has \(\deg_K(z)=1\), while
\(\deg_K(y)=2\).

Let \(P^*\) be the plane dual and

\[
K^*=\{e^*:e\in K\}.
\]

Since

\[
|V(P)|=2n-1,\qquad |E(P)|=3n-3,\qquad |V(P^*)|=n,
\]

condition (A) is equivalent to the existence of \(K^*\) satisfying all four
properties below.

1. \(K^*\) is a connected spanning unicyclic subgraph of \(P^*\).
2. On the boundary of every dual face corresponding to an \(X\)-vertex,
   \(K^*\) uses exactly one edge.
3. On the boundary of every dual face corresponding to a
   \(Y\setminus\{r\}\)-vertex, it uses exactly one edge except at one face
   \(f_y\), where it uses exactly two.
4. The unique cycle of \(K^*\) is dual to a bond whose shores induce the
   port split \(\{s\}\mid\{a,b\}\).

To prove the equivalence, plane duality gives

\[
J\text{ is acyclic}\quad\Longleftrightarrow\quad K^*
\text{ is connected}.                                     \tag{2}
\]

The face incidences give \(|K|=n\), and hence

\[
|J|=(3n-3)-n=2n-3=|V(P)|-2.                                \tag{3}
\]

Thus \(J\) is a spanning forest with two components and \(K^*\), with
\(n\) vertices and \(n\) edges, is unicyclic.  The cut between the two
components of \(J\) is a bond contained in \(K\), so its dual is the unique
cycle of \(K^*\).  The face degrees translate back to degree two at every
internal vertex of \(J\), with endpoints \(a,b,s,y\); its two trees are
therefore the required paths.  The same argument reverses.

The planar target is consequently not an arbitrary 2-factor.  It is a
near-perfect primal incidence object that must simultaneously be a
face-constrained connected unicycle in the dual.

## Exact completion inside the original graph

For an (A)-witness with free endpoint \(y\), the forest \(J\) can be
completed to a 2-factor of the original graph \(F\) exactly under one
additional condition:

\[
\tag{4}
J\text{ extends to a 2-factor of }F
\quad\Longleftrightarrow\quad
N_K(y)\cap\{a,b,s\}\ne\varnothing.
\]

Indeed, choose \(x\in N_K(y)\cap\{a,b,s\}\).  Then

\[
M_x=(K\setminus\{xy\})\cup\{rx\}                            \tag{5}
\]

is a perfect matching of \(F\), and its complementary 2-factor is

\[
D_x=J\cup\{xy\}\cup
\{rt:t\in\{a,b,s\}\setminus\{x\}\}.                         \tag{6}
\]

If \(x=s\), then \(D_s\) has exactly two cycles: the root cycle uses
\(ra,rb\), and the other cycle contains \(s\) and \(sy\).  If \(x=a\) or
\(x=b\), then \(D_x\) is Hamiltonian.  Conversely, a 2-factor containing
all of \(J\) must add two root edges; its third new edge must join the
remaining port to \(y\), which proves necessity in (4).

Two sufficient conditions for (A) follow.

> **(T)** There is a 2-factor with exactly two cycles, its root cycle uses
> \(ra,rb\), and \(r,s\) lie on different cycles.

Deleting \(r\) from the root cycle and one cycle edge incident with \(s\)
from the other cycle gives the two paths.  The separation of \(r\) and \(s\)
is essential: the assertion that \(ra,rb\) lie on the root cycle does not
by itself keep \(s\) off that cycle.

A second sufficient condition is

\[
\tag{H}
F\text{ has a Hamilton cycle containing }rs.
\]

Such a cycle uses \(rs\) and one of \(ra,rb\), say \(ra\).  After deleting
\(r\), it is a Hamilton path from \(s\) to \(a\) containing \(b\)
internally.  Deleting the edge at \(b\) on the \(s\)-side leaves the path
from \(a\) to \(b\) and a second path starting at \(s\), which proves (A).

## Why pairwise co-cyclicity does not supply the missing step

Diwan's Theorem 5 states that, in a connected planar cubic bipartite graph,
any two prescribed edges lie on the same cycle of some 2-factor
(A. A. Diwan, *Chords of 2-Factors in Planar Cubic Bridgeless Graphs*,
arXiv:2110.12584, Theorem 5; DOI 10.1007/s00373-022-02583-y).

For the root state in (T), the natural prescribed pair is \(ra,rb\).
These edges are adjacent, so any 2-factor containing both already places
them on the same cycle.  Their simultaneous occurrence does not require
planarity: take a perfect matching containing \(rs\), which exists by a
1-factorization of the regular bipartite graph, and complement it.  The
same observation applies to any adjacent pair of root edges used in an
attempt to obtain (H).  Thus the direct invocation of Theorem 5 supplies
no new root-state information.

The exact missing absorption statement is:

> **(RCA)** If a 2-factor \(D\) has \(rs\) in its complementary matching,
> has \(r,s\) on distinct cycles, and has more than two cycles, then another
> 2-factor \(D'\) has the same two invariants and fewer cycles.

Together with an initial factor having the stated root separation, repeated
(RCA) would yield (T).  Diwan's two prescribed-edge slots are already
consumed by \(ra,rb\) if the root state is retained.  If instead the two
edges are chosen from cycles one wishes to merge, the theorem's new
2-factor need not retain \(ra,rb\), need not keep \(r,s\) separated, and
need not reduce the number of cycles.  Its conclusion therefore provides
no decreasing potential.

This is a limitation of the pairwise co-cyclicity conclusion itself.  For
example, let the admissible set partitions be all partitions of a
12-element set into three 4-element blocks.  Every pair of elements belongs
to a common block in some admissible partition, but every admissible
partition still has three blocks.  Hence the logical schema

\[
\forall e_1,e_2\ \exists D:\quad
e_1,e_2\text{ are co-cyclic in }D
\]

does not imply a factor with at most two cycles, let alone (RCA).  This
set-system is only an interface separator, not a graph-realizability
counterexample.

## Exact boundary

Diwan's Theorem 5, used only through its pairwise co-cyclicity conclusion,
cannot be cycle-merged into planar (A).  The missing positive statement is
the root-preserving absorption (RCA), together with an initial factor that
separates \(r\) from \(s\), or the stronger prescribed-edge Hamilton
condition (H).  The dual formulation gives a distinct route: construct the
face-constrained connected unicycle directly, without passing through a
2-factor of \(F\).

This note does not prove or refute planar (A), (T), or (RCA).  It also does
not rule out a strengthening of Diwan's induction that retains the root
state while decreasing the cycle count.  The literature boundary was
checked against the complete statement and proof of Theorem 5 on printed
pages 13--14; the route closure concerns the theorem as a black-box
pairwise statement.
