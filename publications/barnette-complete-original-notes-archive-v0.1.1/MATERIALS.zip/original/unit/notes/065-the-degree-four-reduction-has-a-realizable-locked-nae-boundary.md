> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The degree-four reduction has a realizable locked NAE boundary

[Note 063](063-rca-and-the-direct-two-path-target-have-distinct-exact-dual-forms.md)
recasts RCA as a prescribed-edge facewise-NAE colouring problem in an
Eulerian plane triangulation.  This note determines the first local
induction interface for that formulation.

Let \(T\) be a simple \(4\)-connected Eulerian plane triangulation, let
\(a\in E(T)\), and let \(v\notin V(a)\) have cyclic neighbours

\[
x_1,x_2,x_3,x_4.
\]

The standard reduction deletes \(v\), identifies \(x_1\) with \(x_3\) to
one vertex \(z\), and suppresses the two resulting digons at \(zx_2\) and
\(zx_4\). In the primal dual this deletes the facial \(C_4\) and restores
the two old cofacial edges. This note proves that the reduction is not a
universal witness-by-witness induction step for the prescribed-edge NAE
unicycle target. The obstruction is not merely an abstract local state:
it occurs in the dual of a plane cubic bipartite brace.

This does **not** give an RCA counterexample. The expanded obstruction
graph has other target colourings for the same root edge.

## 1. Exact inverse reduction

It is useful not to hide the rotation in the word “identify”. In the
reduced triangulation \(T'\), choose a vertex \(z\) and two nonconsecutive
neighbours \(x_2,x_4\). They cut the cyclic neighbour list of \(z\) into
two closed arcs

\[
A_1=(x_2,\ldots,x_4),\qquad A_3=(x_4,\ldots,x_2).
\tag{1}
\]

Split \(z\) into \(x_1,x_3\), join \(x_i\) to every vertex of \(A_i\), and
add a new vertex \(v\) adjacent in order to
\(x_1,x_2,x_3,x_4\). Thus \(x_2,x_4\) are adjacent to both split copies.
The parity condition for an Eulerian expansion is that both arcs in (1)
have odd cardinality. The site is *reducible* when the result is again a
simple \(4\)-connected Eulerian plane triangulation. This construction is
exactly inverse to the preceding reduction.

In what follows the prescribed edge \(a\) survives unchanged. The explicit
obstruction has \(a\) disjoint from \(z\) in \(T'\) and from \(v\) in \(T\),
so no root-edge identification or choice is involved.

## 2. All finite colour-extension states

Let \(c'\) be an NAE colouring of \(T'\), normalize
\(c'(z)=0\), and put

\[
p=c'(x_2),\qquad q=c'(x_4).
\]

For an extension write

\[
\lambda=c(x_1),\qquad \rho=c(x_3),\qquad d=c(v).
\]

The reduced NAE condition says that no consecutive pair on either arc
\(A_i\) is \(00\). Keeping a split copy at colour \(0\) therefore always
preserves all external triangular faces. Giving \(x_i\) colour \(1\)
preserves them if and only if no consecutive pair of \(A_i\) is \(11\).
Combining the two statements gives the exact rule

\[
c(x_i)=1
\quad\Longrightarrow\quad
\text{the whole arc \(A_i\) must alternate.}
\tag{2}
\]

Conversely, an alternating arc makes this flip legal, so (2) is an
if-and-only-if condition on the choice \(c(x_i)=1\).

Subject to (2), the four new faces are NAE exactly in the following table.
Each entry is \((\lambda\rho;d)\).

\[
\begin{array}{c|l}
(p,q)&\text{all internally valid assignments}\\ \hline
(0,0)&(00;1),(01;1),(10;1),(11;0),(11;1)\\
(0,1)\text{ or }(1,0)&(00;1),(11;0)\\
(1,1)&(00;0),(00;1),(01;0),(10;0),(11;0).
\end{array}
\tag{3}
\]

Indeed, for fixed \(d\), an internal face is monochromatic precisely when
one of the four consecutive pairs in
\((\lambda,p,\rho,q)\) is \(dd\). This proves both necessity and
sufficiency of (3). Equations (2)–(3) are the complete colour boundary;
no contraction assumption remains.

For connectivity, let \(H(c)\) be the spanning graph of monochromatic
edges. Every NAE colouring of a plane triangulation selects one edge per
triangular face, and each selected edge is seen from both incident faces.
Consequently

\[
|E(H(c))|=|V(T)|-2,
\qquad
\beta(H(c))=\operatorname{comp}(H(c))-2.
\tag{4}
\]

If \(a\) is unchanged and \(c'\) is a target colouring, put
\(R=H(c')-a\). Then \(R\) is a three-component spanning forest and the
ends of \(a\) lie in the same component. For any row of (3), the exact
rooted connectivity test is therefore

\[
H(c)-a\text{ is a three-component forest and the ends of \(a\) remain
connected in it.}
\tag{5}
\]

When a split copy is flipped, (5) genuinely depends on the connectivity of
the monochromatic attachments along its complete arc, not only on the four
wheel colours. Thus (3) is the full local colour table, while (5) is the
smallest exact global connectivity condition that must accompany a
proposed lift.

## 3. The locked state

There is one particularly strict state:

\[
p=q=0,\qquad A_1\text{ is not alternating},\qquad
A_3\text{ is not alternating}.
\tag{L}
\]

By (2), (L) forces \(\lambda=\rho=0\); then (3) forces \(d=1\).
Hence the NAE extension is unique. Its monochromatic graph contains the
whole rim

\[
x_1x_2x_3x_4x_1
\tag{6}
\]

and \(v\) is isolated. In \(H(c')\), the edges \(zx_2,zx_4\) are
monochromatic. Replacing their connected two-edge star by the connected
rim (6), while distributing the other \(z\)-attachments between
\(x_1,x_3\), does not change the component partition away from \(v\).
The isolated \(v\) adds exactly one component. Therefore

\[
\operatorname{comp}(H(c))=\operatorname{comp}(H(c'))+1=4,
\qquad \beta(H(c))=2.
\tag{7}
\]

Thus no target colouring can extend a reduced target colouring through a
locked boundary. This conclusion is independent of the position of the
old root cycle, provided the prescribed edge survives unchanged.

## 4. A genuine brace-realizable obstruction

Take the reduced triangulation \(T'\) on vertices \(0,\ldots,9\) with
edge set

    01 02 03 04 12 13 15 16 17 18 19 24
    25 34 36 45 46 47 48 49 57 68 79 89

It is the plane dual of the \(16\)-vertex brace from
[Note 062](062-the-planar-boundary-chord-lemma-fails-on-a-sixteen-vertex-brace.md)
(graph6
'O????B_sDOI_I_DO@W?M?'). Use

\[
z=1,\qquad
(A_1,A_3)=((0,2,5,7,9),(9,8,6,3,0)),\qquad
a=04,
\tag{8}
\]

and colour

\[
c'^{-1}(0)=\{0,1,4,9\},\qquad
c'^{-1}(1)=\{2,3,5,6,7,8\}.
\tag{9}
\]

The monochromatic edges are

\[
01,04,19,25,36,49,57,68.
\tag{10}
\]

They consist of the rooted cycle
\(0-1-9-4-0\), containing \(a=04\), and the two paths
\(2-5-7\) and \(3-6-8\). Hence (9) is an exact reduced target colouring.

Both arcs in (8) have colour word \(01110\). They are therefore
nonalternating, while \(c'(z)=c'(0)=c'(9)=0\); this is exactly (L).
Split \(1\) into \(10,11\) along the two displayed arcs and add the
degree-four vertex \(12\). The expanded edge set is

    02 03 04 0-10 0-11 0-12 24 25 2-10 34 36 3-11
    45 46 47 48 49 57 5-10 68 6-11 79 7-10 89 8-11
    9-10 9-11 9-12 10-12 11-12

This \(T\) is again a simple \(4\)-connected Eulerian plane triangulation;
its plane dual is a simple cubic bipartite \(2\)-extendable graph on
\(20\) vertices. Deleting \(12\), identifying \(10,11\), and suppressing
the two digons gives exactly \(T'\). The root \(04\) is unchanged and is
not incident with \(12\).

Among all eight assignments on \(10,11,12\) agreeing with (9) elsewhere,
the only NAE assignment is

\[
(c(10),c(11),c(12))=(0,0,1).
\]

Its monochromatic graph has four components, total cycle rank two, and
still has \(04\) on a cycle. Hence it is not a target colouring. The
standalone verifier checks planarity, triangular faces, even degrees,
\(4\)-connectivity, both dual brace conditions, exact reduction, all eight
extensions, and the rooted cycle ranks:

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/verify_locked_degree_four_boundary_obstruction.py

It ends with 'LOCKED_DEGREE_FOUR_BOUNDARY_VERIFIED'. It also enumerates
seven other target colourings of \(T\) for the same root \(04\), up to
global colour complementation. The example is therefore deliberately a
lift-interface obstruction, not a counterexample to the underlying RCA
existence statement.

## 5. Exact conclusion and unresolved boundary

**Exact conclusion and quantifiers.** There exist a reducible
degree-four expansion \(T\to T'\), an unchanged prescribed edge
\(a\not\ni v\), and a target NAE colouring \(c'\) of \(T'\) such that no
NAE colouring of \(T\) agreeing with \(c'\) off the split vertex is a
target colouring. In fact the only NAE extension has cycle rank two.
Therefore the standard degree-four/primal-\(C_4\) reduction is not a
universal *witness-by-witness local lift* for the prescribed-edge target.

The exact missing boundary state is (L): when both selected neighbours have
the contracted colour, each split sector must supply an alternating arc if
one wishes to escape the forced extra monochromatic rim cycle. A valid
existence-level induction would have to prove that some reduced rooted
target witness avoids (L), or use a nonlocal recolouring that changes the
reduced witness. Existence of an arbitrary reduced witness alone is
insufficient.

**Weakest load-bearing argument.** The key step is the local fact (2):
flipping a split copy is legal exactly when its complete neighbour arc
alternates. In state (L), the finite table (3) then makes the extension
unique, and the component comparison leading to (7) forces cycle rank two.

**Evidence level.** The reduction, boundary table, and locked-state
failure are proof-level. Realizability is supplied by one explicit finite
plane triangulation and an exhaustive eight-assignment verifier; the brace
and \(4\)-connectivity checks are exact finite checks.

**Unresolved boundary.** This does not decide whether every expanded
graph has some target colouring, nor whether one can always choose a
reduced target colouring outside (L). For nonlocked rows of (3), especially
those that flip a split sector, rooted cycle preservation still depends on
the attachment partition in (5). That global witness-selection problem is
the precise remaining interface; no new task is selected here.
