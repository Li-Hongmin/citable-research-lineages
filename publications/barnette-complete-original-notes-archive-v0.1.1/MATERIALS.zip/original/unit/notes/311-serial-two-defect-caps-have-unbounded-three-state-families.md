> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Serial two-defect caps have unbounded three-state families

[Note 305](305-two-chord-port-skeleton-shields-arbitrary-prefix-matchings.md)
routes a serial chain of port regions when each region has a
specified rooted cap. [Note 310](310-a-boundary-port-and-one-more-missing-link-always-have-a-rooted-cap.md)
supplies that cap whenever its left boundary link is missing
and at most one further link is missing before its retained
right anchor. The substitution works independently in every
region; a backward port can occur in each one.

Use the compressed, gapless, tight-target all-square opening
and the notation \(s=u_0<u_1<\cdots<u_k<w\) of Note
305(1), with \(k\ge1\). In its \(i\)-th region write
\(v_i\) for the distinguished penultimate vacancy, and
assume \(u_i\ge v_i+3\). Retain
the two matching edges
\[
 e_{u_{i-1}}I_{u_i},\qquad I_{v_i}H_{u_i},
                                                               \tag{1}
\]
the right anchor \(P_{u_i-1}=e_{u_i-1}o_{u_i}\),
the surrounding vacancy-only component, and all suffix
interfaces required by Note 305. Assume that in each final
gap \(B_{v_i+1},\ldots,B_{u_i-1}\), the boundary link
\(P_{v_i}\) is missing and at most one of
\(P_{v_i+1},\ldots,P_{u_i-2}\) is also missing.
The matching of the earlier prefix of each region may
otherwise be arbitrary, subject to the actual Barnette
parent and the displayed interfaces.

**Serial two-defect theorem.** The full surrounding interval
has vertex-spanning \(S,K,X\) states. If the other free
groups have ordinary spanning routes, the parent has a
Hamilton cycle through both site edges and its legal
site-expanded child is Hamiltonian. There is no bound on
\(k\), on the total number of missing links in the
earlier prefixes, or on the number and nesting of
vacancy-only components.

**Proof.** For each \(i\), take \(v=v_i\) and
\(u=u_i\) in Note 310. The first edge in (1)
is the outer chord needed by Note 305; the
second is exactly Note 310's \(I_vH_u\).
The fixed link \(P_{u_i-1}\) is its right
anchor. Note 310 therefore gives a path
\[
 D_i:e_{u_i-1}\leadsto b_{u_i-1},\qquad
 V(D_i)=\{e_{v_i},b_{v_i}\}\cup
   \bigcup_{j=v_i+1}^{u_i-1}V(B_j).                 \tag{2}
\]
The regions have disjoint internal block intervals;
consecutive ones meet only in the source/last block
\(B_{u_i}=B_{a_{i+1}}\), where Note 305's
recurrence uses the named boundary vertices.
Thus each \(D_i\) meets Note 305(3)--(4)
without changing another cap's inventory.
Its two-chord skeleton theorem gives the three
states and the Hamilton conclusions. \(\square\)

**A realized family with a backward port in every region.**
For every integer \(k\ge1\), put
\[
\begin{array}{lll}
a_i=1+8(i-1),&v_i=a_i+2,&h_i=a_i+4,\\
j_i=a_i+5,&s_i=a_i+6,&t_i=a_i+7,\\
u_i=a_i+8,&z=u_k+1=8k+2,&r=z
\end{array}                                                   \tag{3}
\]
for \(1\le i\le k\). Thus \(a_1=1\) and
\(a_{i+1}=u_i\). Use Note 281(8)'s old
Hamilton cycle with \(\ell=1\). Make exactly
\[
 B_1,B_z,\qquad
 B_{v_i},B_{h_i},B_{j_i},B_{t_i},B_{u_i}
       \quad(1\le i\le k)                          \tag{4}
\]
vacant, and every other internal block short.
Retain every ordinary link except
\[
 P_{a_i},\quad P_{v_i},\quad P_{s_i}
             \qquad(1\le i\le k).                 \tag{5}
\]
Besides the unchanged site, face, escape,
and residual-square edges, take the free
matching edges
\[
\begin{array}{ll}
H_1I_z,\ I_1H_z;&\mathcal C=\{V_1,V_z\},\\
e_{a_i}I_{u_i},\ o_{a_i+1}H_{v_i},\
   I_{v_i}H_{u_i};&\mathcal P_i=\{P_{a_i},V_{v_i},V_{u_i}\},\\
e_{v_i}I_{t_i},\ o_{v_i+1}H_{h_i},\
   I_{h_i}H_{t_i};&\mathcal Q_i=\{P_{v_i},V_{h_i},V_{t_i}\},\\
H_{j_i}o_{t_i},\ I_{j_i}e_{s_i};&
   \mathcal R_i=\{V_{j_i},P_{s_i}\}
   \quad(1\le i\le k).
\end{array}                                                   \tag{6}
\]
The displayed braces name the atom components,
not additional edges. There are \(5k+2\)
vacant blocks and \(3k\) missing ordinary links,
so their free slots number \(10k+4+6k=16k+4\).
The \(2+8k\) edges of (6) pair those slots
exactly once. Every such edge joins opposite
old-cycle colours.

At a shared block \(B_{u_i}=B_{a_{i+1}}\), the
preceding region uses \(H_{u_i},I_{u_i}\); its
retained right anchor uses \(o_{u_i}\); the next
region uses \(e_{u_i}\). The face chord uses
\(a_{u_i},b_{u_i}\). Thus the two regions neither
compete for a matching slot nor share a vertex of
their cap paths. At the last \(B_{u_k}\), the retained
\(P_{u_k}\) uses \(e_{u_k}\) instead. For \(k=1\),
(3)--(6) are Note 307(8)--(9) with
\((\alpha,\beta,\gamma,\kappa)=(1,0,1,1)\).

The two chords of \(\mathcal C\) are nested.
For each \(i\), \(e_{a_i}I_{u_i}\) encloses
the other chords of its region;
\(o_{a_i+1}H_{v_i}\) is disjoint from
the \(\mathcal Q_i,\mathcal R_i\) subregion,
which lies inside \(I_{v_i}H_{u_i}\).
Within that subregion, \(e_{v_i}I_{t_i}\)
encloses \(o_{v_i+1}H_{h_i}\) and
\(I_{h_i}H_{t_i}\), in disjoint intervals;
the two chords of \(\mathcal R_i\) nest
inside \(I_{h_i}H_{t_i}\). The interval
of region \(i+1\) starts at \(e_{u_i}\),
after the endpoint \(I_{u_i}\) of region
\(i\)'s outer chord. Hence different
regions are disjoint in the opposite-side
disk. For a retained \(P_j=e_jo_{j+1}\), no
free matching endpoint lies strictly between
\(e_j\) and \(o_{j+1}\); every chord of (6)
therefore either contains both endpoints of
\(P_j\) or has neither inside its interval.
Thus retained links are nested or disjoint from
the displayed chords. This gives
a simple cubic bipartite plane drawing,
with the two site edges still cofacial.

Write \(F_j=a_jb_j\) for each face chord.
A retained link interlaces both \(F_j\)
and \(F_{j+1}\). For each region, the
displayed matching chords bridge its
three missing-link breaks by the following
paths in the auxiliary adjacency graph
on face chords:
\[
\begin{array}{ll}
P_{a_i}:&F_{a_i}-F_{u_i}-F_{v_i}-F_{a_i+1},\\
P_{v_i}:&F_{v_i}-F_{t_i}-F_{h_i}-F_{v_i+1},\\
P_{s_i}:&F_{s_i}-F_{j_i}-F_{t_i}=F_{s_i+1}.
\end{array}                                                   \tag{7}
\]
Here one auxiliary adjacency means that the
corresponding chord of (6) interlaces both
face chords, giving a two-edge path in
the actual matching-chord interlacement
graph. In the three rows, the chords supplying
successive adjacencies are, respectively,
\[
\begin{array}{ll}
P_{a_i}:&e_{a_i}I_{u_i},\ I_{v_i}H_{u_i},\ o_{a_i+1}H_{v_i};\\
P_{v_i}:&e_{v_i}I_{t_i},\ I_{h_i}H_{t_i},\ o_{v_i+1}H_{h_i};\\
P_{s_i}:&I_{j_i}e_{s_i},\ H_{j_i}o_{t_i}.
\end{array}
\]
Each endpoint lies strictly between the endpoints
of its block's face chord, so these interlacements
follow directly from the old-cycle order. Thus all
\(F_1,\ldots,F_z\)
belong to one interlacement component.
Every other chord in (6) interlaces
an endpoint face chord. The retained end links
\(P_0,P_z\) attach Note 281's unchanged
site and residual-square closing chain.
The full interlacement graph is connected.
Notes 217 and 182 give three-vertex
connectivity; Note 182 also gives a legal
site expansion.

For each \(i\), the main component
\(\mathcal P_i\) has the two chords (1)
with \(u_{i-1}=a_i\). Its final gap has
missing \(P_{v_i},P_{s_i}\) and retained
right anchor \(P_{u_i-1}=P_{t_i}\).
Note 310 gives its cap \(D_i\); the
backward component \(\mathcal R_i\)
lies in that gap. The suffix after
\(u_k\) consists of the single
outer vacancy block \(B_z\), with
its ordinary boundary link retained.
The serial theorem above applies.
Since \(r=8k+2\), the parent and child
orders are respectively
\[
 12+4r+2(5k+2)=42k+24,\qquad 42k+28.            \tag{8}
\]
The first pair has 66 and 70 vertices.
The number of backward ports and the
total number \(3k\) of missing links
are unbounded.

The theorem concerns the specified serial
skeleton and its final-gap interfaces.
It does not classify all two-port free
groups, other opening shapes, or all
Barnette graphs.
