> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A cofacial bipartite XOR matching cube needs sixteen toggle ports

[Note 096](096-regional-balance-forces-a-return-path-in-every-cofacial-xor-lift.md)
gives a regionwise signed-colour conservation law and proves that every
ordered-cofacial XOR lift needs a same-cycle return path.  A complete
reduced-incidence classification now gives an independent sharp lower
bound on the size of any such lift.

Let \(R\) be a simple connected plane bipartite four-terminal graph.  The
terminals have degree two and every other vertex has degree three.  Suppose
that \(R\) has four perfect matchings \(P_{ij}\), \(i,j\in\{0,1\}\), such
that every complement \(R-P_{ij}\) consists of exactly two spanning
terminal paths, with no closed component, and the ordered terminal-pairing
table is

\[
00:I,\qquad 10:E,\qquad 01:E,\qquad 11:I.
\tag{1}
\]

If

\[
P_{00}\mathbin\triangle P_{11}=C\mathbin{\dot\cup}D
\tag{2}
\]

for two disjoint alternating cycles, then

\[
\boxed{|C|+|D|\ge16.}
\tag{3}
\]

This is a necessary condition, not an existence result at sixteen ports.
It covers every ordered-cofacial reduced incidence and arbitrary lengths of
the common-complement paths; it is not a census of graphs of bounded order.

## 1. Complete block representation

Outside \(C\cup D\), all four matchings coincide.  Delete these common
matching edges and contract every maximal common-complement path outside
the cycles.  Since no complement has a closed component, the reduced
object consists of \(C,D\), four ordered terminals, and a perfect matching
\(X\) on all cycle vertices and terminals.  The union of \(X\) with the
zero smoothing on both cycles is exactly the two \(I\)-paired paths in
state \(00\).

Put

\[
q=\frac{|C|+|D|}{2}.
\tag{4}
\]

The zero smoothing consists of \(q\) undirected edges.  Orient and read
these blocks along the \(t_0t_1\) path and then the \(t_2t_3\) path.  This
gives uniquely

1. a permutation of the \(q\) blocks;
2. one of two orientations for each block; and
3. the cut separating the blocks on the two terminal paths.

Conversely, these data determine every edge of \(X\).  Thus the
\(q!2^q(q+1)\) block descriptions exhaust exactly the reduced incidences
with the required \(00\) state.  The verifier tests the other three
states directly for the table (1) and for absence of closed components.

As a necessary ordered-cofacial test, every edge of \(X\) is subdivided and
a subdivided rim is adjoined through the four terminals in their prescribed
cyclic order.  Every genuinely ordered-cofacial tangle extends to such a
plane rim augmentation.  The converse need not hold, because different
parts of the original tangle may lie on opposite sides of the rim.  Thus
the test deliberately retains a **rim-planar superfamily** of the desired
objects.  Proving that no member of this larger family is region-balanced
is sufficient for the lower bound.

## 2. The regional test is complete for arbitrary path lengths

For every surviving rim-planar incidence, cut along \(C\cup D\).  The
verifier assigns both possible relative bipartition phases to the cycles
and all sixteen possible colour assignments to the terminals.  In each
region it evaluates the signed residue from Note 096.

An external path with oppositely coloured endpoints has zero internal
residue.  If its endpoints have the same colour, its interior has one extra
vertex of the opposite colour.  Terminal endpoints are included because
they too must be covered by the common matching.  Adding two vertices to
any path adds one vertex of each colour and leaves the residue unchanged.
Consequently this finite test covers every path length compatible with
bipartiteness, not only the shortest subdivisions used to represent a
candidate.

All common matching edges are confined to one cut region, so every region
must have residue zero.  Failure of this necessary condition proves that
the reduced incidence has no actual plane bipartite common-matching lift.

The embedding used for the regional calculation loses no embedding of the
same rim augmentation.  After suppressing the subdivisions, each of the
1,088 rim-planar survivors together with its terminal rim is a simple cubic
3-connected graph.  Whitney uniqueness makes that augmented embedding
intrinsic up to reflection.  In particular, if the underlying tangle had a
genuine ordered-cofacial embedding, extending it by the rim would give this
same regional decomposition.

## 3. Complete classification below sixteen ports

Note 094 proves that the XOR/no-closed-component table has no ordered-cofacial
realization with fewer than twelve toggle ports.  Up to exchanging the two
toggle coordinates, the remaining even cycle-length pairs below sixteen
are

\[
(4,8),\quad(6,6),\quad(4,10),\quad(6,8).
\tag{5}
\]

The complete block classification gives

\[
\begin{array}{c|r|r|r|r}
(|C|,|D|)&\text{XOR/no-cycle}&\text{rim-planar superfamily}
&\text{non-rigid}&\text{region-balanced}\\ \hline
(4,8)&3264&64&0&0\\
(6,6)&1584&0&0&0\\
(4,10)&40960&640&0&0\\
(6,8)&28608&384&0&0.
\end{array}
\tag{6}
\]

None of the 1,088 rim-planar candidates is balanced in every region.
Together with the smaller-port theorem of Note 094, this proves (3).

## 4. Exact boundary

The theorem excludes every ordered-cofacial XOR construction with at most
fourteen toggle ports, including all same-cycle return incidences and all
arbitrary path subdivisions.  The lower bound is attained by the explicit
sixteen-port common-matching cube in
[Note 098](098-a-minimum-support-cofacial-bipartite-xor-matching-cube.md).
This note itself makes no claim about labelled inverse-square attachments,
legal-wide geometry, braces, complete fibres or global cross-sector
minimality.

The complete generator, regional test, dependency version and exact
reproduction commands are frozen in the
[verification bundle](../computations/bundles/cofacial-xor-needs-sixteen-toggle-ports/README.md).
