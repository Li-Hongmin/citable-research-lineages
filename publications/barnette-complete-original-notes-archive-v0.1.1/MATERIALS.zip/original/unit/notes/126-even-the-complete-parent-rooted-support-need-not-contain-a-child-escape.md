> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Even the complete parent rooted support need not contain a child escape

[Note 125](125-a-prescribed-mixed-hamilton-overlay-need-not-contain-its-escape.md)
shows that one prescribed mixed Hamilton overlay may miss every surviving
new-cell target even when another mixed sibling succeeds.  The sibling
selection suggested there is nevertheless false.  More strongly, the union
of *all* parent rooted-target supports may miss every surviving child target.

Thus the mixed-sector survival problem cannot be reduced to choosing more
rooted parent overlays.  Any support-based continuation must use a parent
perfect matching outside the rooted fibre, or incidence native to the child.

## 1. Rooted-support selection

Use the notation of [Notes 117](117-mixed-sector-survival-is-a-gate-even-parent-child-exchange-alternative.md)
and [124](124-root-smoothing-does-not-turn-mixed-sector-survival-into-parity.md).
For a sterile state-(11) parent endpoint \(\chi^b\), let

\[
 {\cal M}_\chi,qquad {\cal E}_\chi,qquad {\cal X}^b
\tag{1}
\]

denote respectively its opposite-sector mixed neighbours, its same-sector
non-(11) neighbours, and its same-sector new-cell child targets.  Write
\({\cal R}\) for the complete parent rooted-target fibre and

\[
 U_{\cal R}=\bigcup_{M\in{\cal R}}M,
 \qquad E_{\rm ret}=E(G)\setminus\{p,q\}.
\tag{2}
\]

The good-sibling assertion left by Note 125 was

\[
 {\cal E}_\chi=\varnothing,quad {\cal M}_\chi\ne\varnothing
 \quad\Longrightarrow\quad
 \exists\eta\in{\cal M}_\chi,\ N\in{\cal X}^b:
 N\cap E_{\rm ret}\subseteq(\chi\cup\eta)\cap E_{\rm ret}.
\tag{3}
\]

The following example disproves not only (3), but the formally stronger
selection in which \(\chi\cup\eta\) is replaced by the union of every member
of \({\cal R}\).

## 2. A legal-wide counterexample

Take the plane cubic bipartite graph

```text
graph6 = S???????F?Y?b?W_CW?F?AW?KO?`_?g_?
root = 5-17
forced gate = 4-12
surviving gate = 2-14
site = {3-18, 6-13}
```

with the spherical embedding frozen in the accompanying certificate.  The
two site edges lie on the face

\[
 (1,11,3,18,8,15,6,13),
\tag{4}
\]

and the expansion has two root-free gate arcs of lengths \((5,5)\).  The
parent and child are therefore a legal-wide pair.  Both are plane cubic
bipartite braces.

The unique state-(11) rooted target in sector (b=1) is

\[
\begin{split}
\chi=\{&0\!-!11,1\!-!10,2\!-!14,3\!-!18,4\!-!12,5\!-!17,\\
       &6\!-!13,7\!-!15,8\!-!16,9\!-!19\}.
\end{split}
\tag{5}
\]

Its complete one-cycle endpoint profile is

\[
 \bigl(|{\cal M}_\chi|,|{\cal E}_\chi|,|{\cal X}^1|\bigr)
 =(2,0,3).
\tag{6}
\]

The three members of \({\cal X}^1\) have cells

\[
 R_{00},\qquad X_{vx},\qquad X_{uy}.
\tag{7}
\]

The parent rooted fibre has five members.  Nevertheless their complete
retained-support union has the exact deficits

\[
\begin{array}{c|c}
N& (N\cap E_{\rm ret})\setminus U_{\cal R}\\ \hline
R_{00}&\{3\!-!11,8\!-!18\}\\
X_{vx}&\{3\!-!11\}\\
X_{uy}&\{8\!-!18\}.
\end{array}
\tag{8}
\]

In particular,

\[
 \boxed{
 \forall N\in{\cal X}^1,qquad
 N\cap E_{\rm ret}\not\subseteq U_{\cal R}.}
\tag{9}
\]

Since \(\chi\cup\eta\subseteq U_{\cal R}\) for every
\(\eta\in{\cal M}_\chi\), equation (9) immediately disproves (3).  For
completeness, the two mixed neighbours and three child targets give the
pairwise deficit-size matrix

\[
 \begin{pmatrix}
 5&3&2\\
 5&2&3
 \end{pmatrix},
\tag{10}
\]

so every individual sibling fails by at least two retained edges.

## 3. Verification and scope

The fixed certificate starts from the displayed graph6 string and twelve
facial boundary cycles.  It independently enumerates (97) parent and
(164) child perfect matchings, reconstructs rooted fibres of sizes (5)
and (7), and verifies all (375) and (558) independent two-edge
extensions.  It then derives (6)--(10) directly from matching supports.
No endpoint census or generated classification record is read.

The example is minimum only in the frozen family of Note 110: there is no
eligible endpoint below parent order (20) in that family.  No global
minimum claim is made.  The example also does not refute the Boolean
mixed-sector survival implication, because \({\cal X}^1\ne\varnothing\).

What it proves is the strict boundary

\[
\boxed{
\text{complete parent rooted-target support does not determine a surviving
child escape.}}
\tag{11}
\]

Consequently, adding third, fourth, or all rooted parent overlays cannot
repair the selection route.  The next possible support mechanism must use
a non-rooted parent perfect matching containing (3-11) or (8-18), and
must additionally show that its alternating component actually merges the
required child complement components.  Edge supply alone is not such a
connectivity statement.

The frozen proof bundle is
[good-sibling-selection-counterexample](../computations/bundles/good-sibling-selection-counterexample/README.md).

