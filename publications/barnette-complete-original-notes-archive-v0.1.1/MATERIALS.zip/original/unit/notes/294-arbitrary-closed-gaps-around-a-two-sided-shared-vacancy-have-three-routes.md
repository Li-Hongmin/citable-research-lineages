> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Arbitrary closed gaps around a two-sided shared vacancy have three routes

Note 293 gives the first five-vacancy example in which two consecutive
missing links share a vacant block and its vacancy-only component extends
to both sides. The same three routes survive arbitrary closed intervals
in all four gaps between the five distinguished vacant blocks. The gap
argument uses only a straight route and two crossed rails; the cap route
traverses the entire right side on the old Hamilton cycle.

Work in the compressed, gapless, tight-target all-square opening of
Notes 275 and 278. Fix a free group whose ordinary end links are retained.
Every vacancy is in a distinct target-free internal
face-chord block. A short block has old-cycle order
\(a_t,o_t,e_t,b_t\), and a vacant block has order
\(a_t,o_t,H_t,I_t,e_t,b_t\). Each block has the face chord
\(a_tb_t\). Put \(P_t=(e_t,o_{t+1})\) for an ordinary-link atom.

Fix indices
\[
 i<j\le s-1<m=s+1,\qquad m+2\le u<w,                 \tag{1}
\]
and let \(Q=B_i,\ldots,B_w\). The blocks
\(B_i,B_j,B_m,B_u,B_w\) are vacant, \(B_s\) is short,
and \(P_s,P_m\) are missing. Their three alternating atom
components are
\[
 \{V_i,V_m,V_w\},\qquad \{V_j,P_s\},\qquad
 \{P_m,V_u\}.                                           \tag{2}
\]
Equivalently, the seven matching edges incident with their
vacancy or port slots are
\[
\begin{array}{lll}
 H_iI_w,&I_iH_m,&I_mH_w,\\
 H_jo_m,&I_je_s,&\\
 e_mI_u,&o_{m+1}H_u.&
\end{array}                                              \tag{3}
\]
All other ordinary links in \(Q\) are retained. Additional
vacancy-only components may occur in the four proper block gaps
\[
 G_1=B_{i+1},\ldots,B_{j-1},\quad
 G_2=B_{j+1},\ldots,B_{s-1},\quad
 G_3=B_{m+1},\ldots,B_{u-1},\quad
 G_4=B_{u+1},\ldots,B_{w-1}.                             \tag{4}
\]
Here \(G_1,G_2,G_4\) may be empty, whereas \(G_3\) is
nonempty. Assume no other port component meets \(Q\).

**Two-sided closed-gap theorem.** The induced interval \(Q\)
has all three vertex-spanning states
\[
\begin{array}{ll}
 S(Q):&o_i\longleftrightarrow e_w,\\
 K(Q):&a_i\longleftrightarrow o_i,\quad
       e_w\longleftrightarrow b_w,\\
 X(Q):&a_i\longleftrightarrow b_w,\quad
       o_i\longleftrightarrow e_w.
\end{array}                                              \tag{5}
\]
There is no bound on the lengths of the four gaps, the number
of other vacancies in them, or the nesting depth of their
vacancy-only components. In particular, the group with exactly
the two missing links \(P_s,P_m\) has all three states after
serial and surrounding vacancy-only intervals are included.
If every other free group has its usual spanning route, the
parent has a Hamilton cycle through both site edges and its
legal expanded child is Hamiltonian.

**Proof.** The partition (2) is noncrossing. Its first part
surrounds both port parts. No atom lies between \(P_s,V_m\)
or between \(V_m,P_m\), because these are consecutive atoms
at the shared block. Noncrossing therefore puts every other
component meeting \(Q\) wholly inside one of the four gaps
(4). Each gap is closed under its vacancy matching and has
retained internal ordinary links. Note 275 supplies a spanning
straight route \(S(G)\) and crossed routes
\[
 T(G):a_{\min G}\longleftrightarrow b_{\max G},
 \qquad
 D(G):o_{\min G}\longleftrightarrow e_{\max G},       \tag{6}
\]
whose two paths are disjoint and together cover \(G\).
This includes a gap of short blocks only.

Begin with the following formal skeleton routes, obtained by
relabeling Note 293(3)--(6) as
\(1,2,3,4,5,6,7\mapsto i,j,s,m,m+1,u,w\).
When a proper gap is nonempty, its formal adjacent-block
edges are replaced below before the route is used:
\[
\begin{split}
 S_0:\quad& o_i,a_i,b_i,a_j,o_j,e_i,I_i,H_i,I_w,H_w,I_m,H_m,\\
 &o_m,H_j,I_j,e_s,o_s,e_j,b_j,a_s,b_s,a_m,b_m,\\
 &e_m,I_u,H_u,o_{m+1},a_{m+1},b_{m+1},e_{m+1},\\
 &o_u,a_u,b_u,e_u,o_w,a_w,b_w,e_w;                       \tag{7}\\[2pt]
 K_0:\quad& a_i,b_i,a_j,b_j,e_j,I_j,e_s,o_s,a_s,b_s,
 a_m,o_m,H_j,o_j,e_i,I_i,H_m\\
 &\xrightarrow{C\text{ forward}}I_w,H_i,o_i,
 \qquad\text{with the disjoint cap }e_w,b_w;              \tag{8}\\[2pt]
 X_{0,\mathrm{bottom}}:\quad& o_i,H_i,I_w,e_w;            \tag{9}\\[-2pt]
 X_{0,\mathrm{top}}:\quad& a_i,b_i,e_i,I_i,H_m,o_m,H_j,o_j,
 a_j,b_j,e_j,I_j,e_s,o_s,a_s,b_s,\\
 &a_m,b_m,a_{m+1},o_{m+1},H_u,o_u,e_{m+1},b_{m+1},
 a_u,b_u,e_u,I_u,e_m,I_m,H_w,o_w,a_w,b_w.                 \tag{10}
\end{split}
\]
All fixed non-cycle joins in (7)--(10) are edges of (3),
retained ordinary links, or face chords. In (8), the old-cycle arc from
\(H_m\) to \(I_w\) includes all blocks on the right,
regardless of their matching. It leaves exactly \(e_w,b_w\)
for the cap.

For a nonempty gap \(G_k\), write \(T_k=T(G_k)\) and
\(D_k=D(G_k)\). A displayed \(S(G_k)\), \(T_k\), or \(D_k\)
is traversed in the indicated direction. Make these four
independent replacements:

1. **\(G_1\).** In \(S_0,K_0\), replace the two joins
   \(b_i a_j\) and \(o_j e_i\), respectively, by
   \[
   b_i,a_{i+1}\xrightarrow{T_1}b_{j-1},a_j,
   \qquad
   o_j,e_{j-1}\xrightarrow{D_1^{-1}}o_{i+1},e_i.
   \tag{11}
   \]
   In \(X_{0,\mathrm{top}}\), replace \(b_i e_i\) by
   \[
   b_i,a_{i+1}\xrightarrow{T_1}b_{j-1},e_{j-1}
   \xrightarrow{D_1^{-1}}o_{i+1},e_i.                    \tag{12}
   \]

2. **\(G_2\).** In \(S_0\), replace
   \(e_s,o_s,e_j,b_j,a_s\) by
   \[
   e_s,o_s,e_{s-1}\xrightarrow{D_2^{-1}}o_{j+1},
   e_j,b_j,a_{j+1}\xrightarrow{T_2}b_{s-1},a_s.
   \tag{13}
   \]
   In \(K_0,X_{0,\mathrm{top}}\), replace
   \(e_s,o_s,a_s\) by
   \[
   e_s,o_s,e_{s-1}\xrightarrow{D_2^{-1}}o_{j+1},
   a_{j+1}\xrightarrow{T_2}b_{s-1},a_s.                 \tag{14}
   \]

3. **\(G_3\).** In \(S_0\), replace the segment from
   \(o_{m+1}\) through \(o_u\) by
   \[
     o_{m+1}\xrightarrow{S(G_3)}e_{u-1},o_u.           \tag{15}
   \]
   In \(X_{0,\mathrm{top}}\), replace the segment from
   \(a_{m+1}\) through \(a_u\) by
   \[
   a_{m+1}\xrightarrow{T_3}b_{u-1},e_{u-1}
   \xrightarrow{D_3^{-1}}o_{m+1},H_u,o_u,a_u.           \tag{16}
   \]
   The cap route (8) needs no replacement here.

4. **\(G_4\).** If nonempty, replace \(e_u o_w\) in
   \(S_0\) by
   \[
   e_u,o_{u+1}\xrightarrow{S(G_4)}e_{w-1},o_w.         \tag{17}
   \]
   Replace \(o_w a_w\) in \(X_{0,\mathrm{top}}\) by
   \[
   o_w,e_{w-1}\xrightarrow{D_4^{-1}}o_{u+1},
   a_{u+1}\xrightarrow{T_4}b_{w-1},a_w.                \tag{18}
   \]
   Again (8) already covers this gap on the old cycle.

For an empty \(G_1,G_2\), or \(G_4\), keep the corresponding
skeleton joins. Every new boundary join in (11)--(18) is a
retained ordinary link, an old-cycle edge, an edge of (3),
or a face chord. The rails \(T_k,D_k\) are disjoint and
cover their gap once. Equations (12), (14), (16), and (18)
join their rails through, respectively, the old-cycle edges
\(b_{j-1}e_{j-1}\), \(o_{j+1}a_{j+1}\),
\(b_{u-1}e_{u-1}\), and \(o_{u+1}a_{u+1}\). Equation (13)
instead joins them through \(e_jb_j\) in the distinguished
block. The four gaps have disjoint vertex sets. Thus each
modified skeleton remains a path or pair of paths with exactly
the endpoints in (5), and covers every vertex of \(Q\)
exactly once.

All additional vacancy-only components outside \(Q\) are
serial or surround it. Note 275's prime and serial
compositions accept the three states of \(Q\) as a closed
gap signature, giving the full free group's states. Note 273
joins the groups; Notes 001 and 178 give the marked parent
cycle, legal child cycle, and arbitrary original lobe lengths.
\(\square\)

**Signature substitution.** The local argument (7)--(18)
uses no matching classification inside a gap beyond its
spanning \(S\) and \(X\) states. Thus the same conclusion
holds if a closed gap contains further missing links, provided
that gap already has \(S,X\) and every ordinary boundary
link used in (11)--(18) remains present. This is a routing
implication, independent of how those gap states are proved.

**Complete five-vacancy corollary.** Suppose such a free group has
exactly two missing ordinary links \(P_s,P_{s+1}\), the common
block \(B_{s+1}\) is vacant, and its vacancy belongs to a
vacancy-only component having atoms on both sides. If the
group has exactly five vacancies, then it has all three states
\(S,K,X\), with no restriction on the distances between
vacant blocks. The same marked parent and legal-child
Hamilton conclusions hold under the other hypotheses of the
theorem.

Indeed, Note 292 makes the shared-block vacancy component
distinct from both port components, and Note 278 separates
the two ports. The first component needs at least three
vacancies, and each port component needs at least one. With
five in total, it has exactly three atoms
\(V_i,V_m,V_w\), while the other two components each have
one port and one vacancy. The ports \(P_s,P_m\) lie in the
two proper gaps of \(V_i,V_m,V_w\), immediately to the left
and right of \(V_m\). Noncrossing forces each port's
vacancy into its respective gap. The left vacancy must
precede \(P_s\), and the right one must follow \(P_m\),
because neither adjacent port--vacancy pair has an atom
between it and \(V_m\). Call them \(V_j,V_u\). The
old-cycle adjacency exclusions \(I_se_s\) and
\(o_{m+1}H_{m+1}\) give \(j\le s-1\) and \(u\ge m+2\).
No other vacant block remains; in particular \(B_s\) is
short. The rainbow rule of Note 278 now forces exactly
(1)--(3), and every block in (4) is short. Apply the
two-sided closed-gap theorem. \(\square\)

**Every four-tuple of short-gap lengths occurs.** Let
\(d_1,d_2,d_3,d_4\ge0\), and set
\[
 i=1,\quad j=2+d_1,\quad s=j+1+d_2,\quad m=s+1,
 \quad u=m+2+d_3,\quad w=u+1+d_4,\quad r=w.            \tag{19}
\]
Use the old-cycle and unchanged site, face, escape, and
residual-square chords of Note 281(8)--(9). Make precisely
the five blocks in (2) vacant, all other internal blocks
short, retain every ordinary link except \(P_s,P_m\), and
add (3). This is Note 293 when every \(d_k=0\).
The seven edges (3) pair all special slots, have opposite
old-cycle colours at their ends, and are noncrossing on the
side opposite the site face: \(H_iI_w\) is outermost;
\(I_iH_m\) encloses the two left-port edges, while
\(I_mH_w\) encloses the two right-port edges. Each retained
ordinary link is inside or disjoint from those nested chords.

For three-connectivity, use Note 217's interlacement
criterion. Retained ordinary links connect the face chords
in each of the two long standard-chain pieces, including
every inserted short block. The special chords
\(H_iI_w\) and \(I_iH_m\) interlace the endpoint face
chords and join these pieces to the shared-block face chord.
All other special edges interlace an endpoint face chord;
the unchanged site and residual-square links close the
interlacement chain as in Note 281. Hence the full matching
interlacement graph is connected. Note 182's cubic lemma
gives three-vertex-connectivity. The parent and its legal
child have, respectively,
\[
 50+4(d_1+d_2+d_3+d_4),\qquad
 54+4(d_1+d_2+d_3+d_4)                              \tag{20}
\]
vertices and are Hamiltonian by (5).

The theorem resolves this three-component two-sided
shared-vacancy pattern, including arbitrary closed
vacancy-only gaps. The corollary covers the entire sharp
five-vacancy two-sided branch. More vacancies permit longer
port components or a longer component through the shared
block; those profiles and Barnette's conjecture remain open.
