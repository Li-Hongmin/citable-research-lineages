> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A single mixed vacancy has three spanning four-port routes

[Note 209](209-every-tight-gapless-internal-vacancy-at-first-surplus-is-hamiltonian.md)
gives a spanning free path when one target-free vacancy pair
replaces a distant ordinary chain link. Its intervening patch
has two further spanning routes. These are the three routing
states used to absorb vacancy-only cycles in Note 275.

Let \(D=B_a,\ldots,B_b\) be consecutive target-free internal
face-chord blocks in a compressed gapless tight-target
all-square opening. Exactly one block \(B_k\) is vacant:
\[
 B_k=(a_k,o_k,H_k,I_k,e_k,b_k);
\]
all other blocks of \(D\) are short
\((a_j,o_j,e_j,b_j)\). Suppose the free matching within
this interval retains every standard link
\(e_jo_{j+1}\), \(a\le j<b\), except
\[
 P_s=e_so_{s+1},
\]
and instead has
\[
 e_sI_k,\qquad o_{s+1}H_k.                        \tag{1}
\]
Assume both ends of \(P_s\) lie in \(D\):
\(a\le s<b\). The old-cycle adjacencies exclude
\(s=k-1,k\); after reflection, take
\(s\le k-2\). Assume the ordinary links at the
two ends of \(D\) are retained when those links exist.
The four external ports of \(D\) are
\(a_a,o_a,e_b,b_b\).

**Three-state routing theorem.** The induced patch \(D\)
has each of these vertex-spanning routings:
\[
\begin{array}{ll}
X(D):&a_a\longleftrightarrow b_b,\quad
       o_a\longleftrightarrow e_b;\\
K(D):&a_a\longleftrightarrow o_a,\quad
       e_b\longleftrightarrow b_b;\\
S(D):&o_a\longleftrightarrow e_b .
\end{array}                                               \tag{2}
\]
The first two rows are pairs of disjoint paths; the last is
one path. Every route covers all vertices of \(D\).
The statement holds for arbitrary short-block flanks and,
by reflection, for a missing link on either side of \(B_k\).

**Proof.** First take \(b=k\), so the vacant block is the
rightmost block of the patch. For \(S(D)\), start with
Note 196's ordinary free path through \(D\) and replace
its missing link by
\[
 e_s,I_k,H_k,o_{s+1}.                              \tag{3}
\]
The outer joins are (1), and \(I_kH_k\) is an old-cycle
edge. This inserts the two vacancy slots once.

For \(K(D)\), leave \(e_kb_k\) as the right path.
The left path first follows face chords and the
intervening old-cycle edges along the top rail from
\(a_a\) through \(a_k,o_k\). From \(o_k\), run
backwards along the ordinary-slot bottom rail to
\(o_{s+1}\), then take
\[
 o_{s+1},H_k,I_k,e_s,                              \tag{4}
\]
and continue backwards along the bottom rail to \(o_a\).
The bottom rail uses the retained links
\(e_jo_{j+1}\) for \(j\ne s\) and the old-cycle
edges \(o_je_j\) in short blocks. The first backward
portion covers the ordinary slots of
\(B_{s+1},\ldots,B_{k-1}\); the second covers those
of \(B_a,\ldots,B_s\). The top portion covers all
their face-chord endpoints, as well as \(a_k,o_k\).
Together with (4) and \(e_kb_k\), the two paths cover
every vertex once and have the required cap endpoints.

For \(X(D)\), take a bottom path from \(o_a\) through
the ordinary slots of \(B_a,\ldots,B_s\) to \(e_s\),
then continue
\[
 e_s,I_k,e_k.                                      \tag{5}
\]
Its joins are a matching edge from (1) and the old-cycle
edge \(I_ke_k\). The other path starts at \(a_a\)
and follows the top face-chord rail through
\(b_{k-1}\). Take the old-cycle edge
\(b_{k-1}e_{k-1}\), traverse the bottom rail
backwards to \(o_{s+1}\), and finish
\[
 o_{s+1},H_k,o_k,a_k,b_k.                           \tag{6}
\]
The first join is (1); the other two inside \(B_k\)
are old-cycle edges, followed by the face chord
\(a_kb_k\). This path uses every face-chord endpoint,
the ordinary slots of \(B_{s+1},\ldots,B_{k-1}\),
and \(o_k,H_k\). It is disjoint from (5), so the two
paths span \(D\) with the crossed pairing.

If \(b>k\), the suffix \(B_{k+1},\ldots,B_b\)
is a short-block ladder. It has all three states of
Note 275's short-ladder base case. Joining two straight
states across \(e_ko_{k+1}\) extends \(S\); joining
two crossed states across both
\(e_ko_{k+1}\) and \(b_ka_{k+1}\) extends \(X\).
Joining \(K\) on the prefix to \(X\) on the suffix
across both edges extends \(K\), exactly as in
Note 275's serial composition. Reflection exchanges
left and right defects and preserves the three
pairings in (2). This proves the theorem. \(\square\)

The theorem concerns a four-port patch with its one
missing link wholly inside the patch. It does not
classify patches with several mixed vacancies, nor
a missing link whose endpoint lies in an exterior
vacancy block. It supplies the routing states needed
for subsequent nested-cycle absorption.
