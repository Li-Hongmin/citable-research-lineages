> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The actual boundary-chord lemma fails in the nonplanar Heawood brace

[Note 059](059-actual-planar-fibres-realize-support-three-circuits-but-add-compatibility-chords.md)
proposes a boundary-chord lemma for arbitrary actual fixed fibres. That
lemma is false even for a simple cubic bipartite brace. The counterexample
below is nonplanar, so a specifically planar version remains open.

## The brace and its fixed fibre

Let \(F\) be the Heawood graph with graph6 string

    MhEGHC@AI?_PC@_G_

and bipartition

\[
X=\{1,3,5,7,9,11,13\},\qquad
Y=\{0,2,4,6,8,10,12\}.
\]

The labelled incidence is fixed by

\[
\begin{array}{c|c@{\qquad}c|c}
x&N_F(x)&x&N_F(x)\\ \hline
1&\{0,2,10\}&3&\{2,4,12\}\\
5&\{0,4,6\}&7&\{2,6,8\}\\
9&\{4,8,10\}&11&\{6,10,12\}\\
13&\{0,8,12\}&&
\end{array}
\]

Take root \(r=0\), ports

\[
N_F(r)=\{1,5,13\},
\]

and the fixed port split

\[
\{1\}\mid\{5,13\}.
\tag{1}
\]

The Heawood graph is the point-line incidence graph of the Fano plane. For
a set \(U\) of \(k\) points, and dually for a set of \(k\) lines, the Fano
incidence rules give

\[
|N(U)|\ge k+2\qquad(1\le k\le5).
\tag{2}
\]

For \(k=1,2\) the neighbourhood sizes are \(3,5\). For \(k=3\) they are
\(7\) in the collinear case and \(6\) otherwise. A four-point complement
contains at most one line, and a five-point complement contains none.
Thus (2) is the bipartite 2-extendability criterion, so \(F\) is a brace.

The graph is not planar. It has \(14\) vertices, \(21\) edges and girth
six, whereas a planar bipartite graph of girth at least six on \(14\)
vertices has at most \(3(14-2)/2=18\) edges.

In the fixed fibre (1), consider the forests

\[
\begin{aligned}
A=\{&
12,23,27,34,49,56,6\,11,78,9\,10,11\,12,12\,13\},\\
B=\{&
12,23,34,56,67,6\,11,78,89,8\,13,9\,10,11\,12\},\\
C=\{&
1\,10,27,34,3\,12,45,49,6\,11,78,89,11\,12,12\,13\}.
\end{aligned}
\tag{3}
\]

Here \(12\) denotes the edge \(\{1,2\}\), while a thin space separates
endpoints when one endpoint has two digits. Directly, their component
partitions are

\[
\begin{aligned}
A:&\quad
\{1,2,3,4,7,8,9,10\}\mid\{5,6,11,12,13\},\\
B:&\quad
\{1,2,3,4\}\mid\{5,6,7,8,9,10,11,12,13\},\\
C:&\quad
\{1,10\}\mid\{2,3,4,5,6,7,8,9,11,12,13\}.
\end{aligned}
\tag{4}
\]

Thus all three are two-component spanning forests with the prescribed
\(X\)-degrees and port split (1).

## A minimal box-feasible support with no chord

In the coordinate order

\[
Y\setminus\{r\}=(2,4,6,8,10,12),
\]

the degree and excess vectors are

\[
\begin{array}{c|c|c}
&d&e=d-2\mathbf1\\ \hline
A&(3,2,2,1,1,2)&(1,0,0,-1,-1,0)\\
B&(2,1,3,3,1,1)&(0,-1,1,1,-1,-1)\\
C&(1,3,1,2,1,3)&(-1,1,-1,0,-1,1).
\end{array}
\tag{5}
\]

Therefore

\[
\frac13\bigl(e(A)+e(B)+e(C)\bigr)
=(0,0,0,0,-1,0)\le0.
\tag{6}
\]

The support \(\mathcal S=\{A,B,C\}\) is inclusion-minimal
box-feasible. Each singleton has a positive coordinate. In the pair
\(A,B\), the first coordinate forces the weight of \(A\) to zero; in
\(A,C\), the second forces the weight of \(C\) to zero; and in \(B,C\),
the fourth forces the weight of \(B\) to zero. The remaining singleton is
infeasible in each case.

Allowing repetition, the six pair sums of excess vectors are

\[
\begin{array}{c|c}
AA&(2,0,0,-2,-2,0)\\
AB&(1,-1,1,0,-2,-1)\\
AC&(0,1,-1,-1,-2,1)\\
BB&(0,-2,2,2,-2,-2)\\
BC&(-1,0,0,1,-2,0)\\
CC&(-2,2,-2,0,-2,2).
\end{array}
\tag{7}
\]

Every row has a positive coordinate, so \(\mathcal S\) has no compatible
pair.

For a same-\(X\) pivot

\[
J'=J-xz+xy,
\]

the excess changes by

\[
e(J')=e(J)-\mathbf1_z+\mathbf1_y.
\tag{8}
\]

Such a pivot can repair \(J\) against \(K\) only when
\(e(J)+e(K)\) has exactly one positive coordinate, that value is one, and
the receiving coordinate has slack at least one. Table (7) eliminates
every ordered pair except \(B,C\). For that pair,

\[
e(B)+e(C)=(-1,0,0,1,-2,0),
\]

so a repairing pivot must transfer one degree unit from \(Y\)-vertex \(8\)
to \(2\) or \(10\). The Heawood incidence leaves exactly two candidates:

\[
B-78+27,\qquad C-89+9\,10.
\tag{9}
\]

Both remain two-component forests with the required \(X\)-degrees, but
their component port blocks are respectively

\[
\{13\}\mid\{1,5\},
\qquad
\varnothing\mid\{1,5,13\}.
\tag{10}
\]

They therefore leave the fixed fibre. No same-\(X\) pivot from
\(\mathcal S\) produces a forest in the same fibre compatible with a
member of \(\mathcal S\). This refutes the boundary-chord lemma.

## What the example does not refute

The complete Heawood fibre itself satisfies support one. For example,

\[
\{12,23,34,49,56,67,78,8\,13,9\,10,10\,11,11\,12\}
\tag{11}
\]

has degree vector

\[
(2,2,2,2,2,1).
\]

Thus the example does not refute support two. It proves only that choosing
an arbitrary inclusion-minimal box-feasible support does not force an
immediate compatibility chord, even with actual cubic incidence, brace
extendability and a complete fixed fibre.

Any surviving general exchange proof must add a global extremality
criterion, allow a multistep route through states not immediately
compatible with the original support, or use a partner outside that
support. Planarity is another possible missing hypothesis: the two
fundamental-cut port barriers in (10) occur in a nonplanar brace, and this
note neither proves nor refutes their existence in a plane brace.
