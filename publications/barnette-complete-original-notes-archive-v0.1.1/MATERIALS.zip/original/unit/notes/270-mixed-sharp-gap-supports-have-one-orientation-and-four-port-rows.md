> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mixed sharp gap supports have one left-to-right orientation

[Note 269](269-two-target-bearing-vacancy-blocks-cannot-separately-support-sharp-gaps.md)
excludes two target-bearing vacancy blocks when the gap slots
are supported separately. The mixed assignment has a similar
port tree, but its target-free block allows four noncrossing
boundary pairings. Its target-bearing block must be on the left.

Use the compressed all-square opening of Note 269, with
\[
 \ell,r\ge1,\qquad f=4r+8,\qquad \sigma=T=2.       \tag{1}
\]
Suppose the two capacity vacancies lie in distinct blocks
\(P,Q\); exactly \(P\) contains escape targets. Suppose
each of the two gap slots is matched to a different one of
\(P,Q\). Name the gap slots \(g<h\), so \(g=E,h=O\).

**Mixed-support orientation and port theorem.** Necessarily
\(P<Q\) and \(P\) precedes both \(g,h\). The target-bearing
block \(P\) is forward. Its four free suffix slots are
\(c,H,I,e\), with colours \(O,E,O,E\) and face chord \(ce\).
The target-free block \(Q\) has four free slots
\(u_1,u_2,u_3,u_4\), face chord \(u_1u_4\), and no escape
target. Its colour pattern is forward \(O,E,O,E\) when
it lies before both gaps or after both, and reversed
\(E,O,E,O\) when it lies between them.

Write only the three opposite-side matching edges on the
two gap slots and the unmatched inner ports. Up to the
ordinary free matching elsewhere, the following are the
only pairings that pass colour and noncrossing:
\[
\begin{array}{c|l}
\text{old-cycle order}&\text{three special matching edges}\\
\hline
P<Q<g<h     & hH,\quad gu_3,\quad Iu_2\\
P<g<Q<h     & gI,\quad hu_3,\quad Hu_2\\
P<g<Q<h     & hH,\quad gu_2,\quad Iu_3\\
P<g<h<Q     & gI,\quad hu_2,\quad Hu_3 .
\end{array}                                                   \tag{2}
\]
This is a necessary boundary classification; it does
not assert that every row extends to a Barnette graph.

**Proof.** Notes 255 and 258 send each gap slot to one
of the vacancy blocks and require a face-side chord there.
Note 268 gives exactly one chord in each support block.
As in Note 269, its endpoints span four consecutive free
slots, the gap mate lies in one of their two inner slots,
and the other inner slot cannot match a saturated block
or another slot in its own block. Note 259's cross-block
parity therefore pairs the two remaining inner slots of
\(P,Q\). Their chord cannot straddle an escape target by
Note 203.

If the target-free block \(Q\) preceded \(P\), this
cross-block chord would enter \(P\) before all of its
targets. Thus \(P\)'s four-slot run would be a reversed
prefix, and its gap mate would have to lie to the left
of \(P\). The other gap slot, matched to \(Q\), cannot
lie to the right of \(P\): its chord from \(Q\) would
straddle a target of \(P\). Both gap slots would
therefore precede \(P\). But two preceding gap slots
make the first interior slot of \(P\) odd-coloured,
hence \(P\) forward by Note 195, a contradiction.

Consequently \(P<Q\). The port chord from \(P\) to
\(Q\) can avoid \(P\)'s targets only if its four-slot
run is the forward suffix \(c,H,I,e\). Its own gap
slot must be to the right of \(P\). If the other gap
slot were to the left of \(P\), the one preceding gap
would make \(P\) reversed. Hence \(P\) precedes
both gaps.

The unique face chord of \(P\) is \(ce\); that of
the target-free \(Q\) is \(u_1u_4\). Note 258's odd
gap-mate parity places the gap mate at \(H\) or \(I\)
in \(P\), and at \(u_2\) or \(u_3\) in \(Q\). The
unused inner ports join. Their colours and the
positions of \(g=E,h=O\) give two candidate
assignments in each of the three block orders.
For \(P<Q<g<h\), the assignment \(gI,hu_2,Hu_3\)
is forbidden: \(Hu_3\) interlaces \(Ig\) in the
opposite-side disk. For \(P<g<h<Q\), the assignment
\(hH,gu_3,Iu_2\) is forbidden: \(Iu_2\) interlaces
\(Hh\). The two assignments for \(P<g<Q<h\)
are nested or disjoint. The four survivors are
exactly (2). \(\square\)

The port chord also forbids any escape target strictly
between its endpoints. In particular all complete
blocks strictly between \(P\) and \(Q\) are target-free
and saturated.
The remaining proof problem is whether the four boundary
rows force a marked Hamilton route or a further
three-connectivity obstruction. No such conclusion is
claimed here.
