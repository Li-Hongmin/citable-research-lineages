> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# RH/local Weil fifth bounded pulse checkpoint

2026-10-03. **Research stop: no new fixed-power arithmetic estimate.** Only task-7 outputs were written. Original project stays read only, with its original uncommitted/ignored files preserved. The fourth-round packet is frozen and not superseded.

The specific structure tested was the actual Λ=μ*log and μ*1=δ identity inside the *same* pulse-3 Fejér signed pair. It gives

    c(n)=4−2·1_(2|n)+Σ_(d|n,n/d≥3)μ(d)κ(n/d),
    κ(1)=κ(2)=0,
    κ(k)=(−4+2·1_(2|k))log(k/2), k≥3.

This identity is destroyed by round-4 Λ± replacements with actual μ retained. It was already proved in original scratch 924. The old odd-source normal form, zero rows, squarefree compensation and periodic-background payments also existed, so none is counted as new progress.

The complete high-source matrix in this localizer is

    Γ_de=M⟨q*v_d,q*v_e⟩,
    D=floor(M/(16H)), D<d,e<2M/3.

The new calculation verifies the existing elementary payments at this interface:

    E_loc(low-source remainder)=o(H⁴/M),
    Σ_(d>D)μ(d)²Γ_dd
      ≪H²log²(2H)/M+M^−2γlog⁵M=o(H⁴/M),
    1/10<γ<1/5.

The exact remaining obligation is

    |Σ_(d≠e, d,e>D)μ(d)μ(e)Γ_de|
      ≪_ε H⁴M^(−1+ε),

with **all** cofactors and both physical parity arms included. This is an old signed arithmetic gate expressed in the fixed Fejér pair, not a new upper bound. Factoring d=gu,e=gv gives μ(d)μ(e)=μ(uv)μ(g)²·1_((g,uv)=1), so there is no alternating μ(g) sign available within a fixed reduced pair. The cancellation needed across reduced pairs is still unproved.

Finite verification uses actual prime-power Λ and integer-sieved μ: M=256,H=3,K=20 and M=512,H=4,K=40, 165/333 high sources. All identity, source reconstruction, Fejér multiplier, Hermitian matrix and energy decompositions passed. Largest recorded identity residual <8×10^−15. Modifying Λ at one non-prime-power composite while holding μ fixed produces the expected convolution error 1/32 and c-identity error 1/8. These are finite algebra checks; their K is deliberately below the support margin and does not test the large-M approximation rate or the missing power bound.

Deliverables: `rh-round5-true-convolution-stop.md`, `rh_round5_verify.py`, `rh-round5-verifier-result.json`, fresh-context `rh-round5-independent-review.md`, provenance `rh-round5-source-audit.json`, and a local checkpoint manifest. Same-model review is not heterogeneous validation. The report does not independently certify all old private proofs or external preprint proofs.

User's latest instruction: finish review and freeze, then pause without another pulse. The handoff entry `rh-round5-open-obligation.md` states H5, why present methods fall short, and what future literature/heterogeneous review must check. Any future restart requires a proposed quantitative estimate for the **complete** reduced-pair source matrix. Another cofactor identity, a single-frequency envelope, a fixed-cofactor near block, or an absolute-value estimate that simply restates an old stronger gate is insufficient. No claim of RH, local Weil completion or a true arithmetic counterexample is made.

No fifth-round public contribution is proposed. Attribution, rights-holder license and external verification for any explanatory public checkpoint remain unresolved and are owned by the parent-designated Commons task. No original private manuscripts, credentials, keys, upload, signature, DOI or publication were included.