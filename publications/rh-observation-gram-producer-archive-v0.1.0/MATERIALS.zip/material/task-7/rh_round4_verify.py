# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
#!/usr/bin/env python3
"""Bounded finite diagnostics for a pointwise-envelope countermodel, not uniform proof."""
import cmath
import json
import math
import platform
from pathlib import Path

import numpy as np


def bump(t):
    s = (t - 1.5) / 0.4
    out = np.zeros_like(t)
    mask = np.abs(s) < 1
    out[mask] = np.exp(1 - 1 / (1 - s[mask] ** 2))
    return out


def step(t):
    out = np.zeros_like(t)
    out[t >= 1] = 1
    mask = (t > 0) & (t < 1)
    s = t[mask]
    left = np.exp(-1 / s)
    right = np.exp(-1 / (1 - s))
    out[mask] = left / (left + right)
    return out


def geometric(n, alpha):
    alpha = (alpha + 0.5) % 1 - 0.5
    if abs(alpha) < 1e-15:
        return complex(n)
    return cmath.exp(1j * math.pi * alpha * (n + 1)) * (
        math.sin(math.pi * n * alpha) / math.sin(math.pi * alpha))


m = 32768
h = 10
v = (math.log(m) / math.log(math.log(m))) ** (1 / 3)
rho = math.exp(-v)
n = np.arange(m, 2 * m, dtype=np.int64)
t = n.astype(float) / m
psi = bump(t)
chi = psi.copy()
packet = chi * np.cos(2 * math.pi * 1.5 * h * np.log(t))
max_n = 2 * m
prime = np.ones(max_n + 1, dtype=bool)
prime[:2] = False
for p in range(2, math.isqrt(max_n) + 1):
    if prime[p]:
        prime[p*p::p] = False
mu = np.ones(max_n + 1, dtype=np.int8)
mu[0] = 0
for p in np.flatnonzero(prime):
    mu[p::p] *= -1
    if p*p <= max_n:
        mu[p*p::p*p] = 0
assert mu[1] == 1 and mu[30] == -1 and mu[210] == 1 and mu[12] == 0
base_c = -4 * math.log(2) * mu[n]
base_a = base_c * psi / n
d = np.fft.fft(packet * psi / n)
u = np.fft.fft(base_a)
frequency = np.arange(m)
centered = np.where(frequency <= m // 2, frequency, frequency - m)
z = np.abs(centered) / h
f = step((z - 0.5) / 0.5) * (1 - step((z - 2) / 2))
eta = f*f
ed = float(np.sum(eta * np.abs(d) ** 2))
e0 = float(np.sum(eta * np.abs(u) ** 2))
energies = {}
formula_residuals = {}
for sign in (-1, 1):
    lam_full = 1 + sign * rho * packet
    lam_half = np.ones(m)  # n/2 <= M; even-channel packet is exactly absent
    c_formula = 2 * (n % 2 == 0) * (lam_half - 1) - 4 * (
        lam_full - 1 + math.log(2) * mu[n])
    expected = base_c - 4 * sign * rho * packet
    formula_residuals[str(sign)] = float(np.max(np.abs(c_formula - expected)))
    assert formula_residuals[str(sign)] < 1e-13
    assert float(np.min(lam_full)) > 0
    a = expected * psi / n
    ah = np.fft.fft(a)
    assert float(np.max(np.abs(ah - (u - 4 * sign * rho * d)))) < 1e-12
    energies[str(sign)] = float(np.sum(eta * np.abs(ah) ** 2))
parallelogram = energies['-1'] + energies['1'] - 2*e0 - 32*rho*rho*ed
assert abs(parallelogram) < 1e-12
assert max(energies.values()) + 1e-12 >= 16*rho*rho*ed

# Invoke the frozen filter construction once; this tests its transfer on this model.
gamma = 0.15
k = math.ceil((m/h) * m**gamma)
assert k < m/2
q = np.fft.ifft(f) * np.maximum(0, 1 - np.abs(centered)/k)
qh = np.fft.fft(q)
multiplier_error = float(np.max(np.abs(qh - f)))
local = {}
root_checks = {}
for sign in (-1, 1):
    a = (base_c - 4 * sign * rho * packet) * psi / n
    ah = np.fft.fft(a)
    local[str(sign)] = float(np.sum(np.abs(qh*ah) ** 2))
    observed = abs(math.sqrt(local[str(sign)]) - math.sqrt(energies[str(sign)]))
    bound = multiplier_error * math.sqrt(m * float(np.sum(a*a)))
    assert observed <= bound + 1e-12
    root_checks[str(sign)] = dict(observed=observed, spectral_bound=bound,
                                  normalized_c_mass=float(np.sum((base_c - 4*sign*rho*packet)**2)/m))

samples = []
for x in [m//2, m, 5*m//4, 2*m, 4*m]:
    active = n[n <= x]
    packet_active = packet[:len(active)]
    for qden in sorted({1, 2, 3, 5, int(x**(1/3)), math.isqrt(x)}):
        if qden < 1 or qden > math.sqrt(x):
            continue
        numerators = [1] if qden == 1 else [1, qden - 1]
        limit = math.sqrt(x) / qden
        deltas = [-limit, -0.35*limit, 0, 0.35*limit, limit]
        if qden == 1:
            deltas += [-h*x/m, h*x/m, 2*h*x/m]
        for numerator in numerators:
            for delta in deltas:
                if abs(delta) > limit + 1e-10:
                    continue
                alpha = numerator/qden + delta/x
                packet_sum = np.sum(packet_active * np.exp(2j*math.pi*alpha*active))
                baseline_sum = geometric(x, alpha)
                d0 = max(1, abs(delta)/4)
                denominator = x / math.sqrt(d0*qden)
                largest = max(abs(baseline_sum + sign*rho*packet_sum)
                              for sign in (-1, 1))
                samples.append(dict(x=x, q=qden, a=numerator, delta=delta,
                                    ratio_to_common_envelope=float(largest/denominator)))
worst = max(samples, key=lambda r: r['ratio_to_common_envelope'])
# Finite samples are diagnostic. The eventual 1.01 statement is proved analytically.
assert worst['ratio_to_common_envelope'] < 1.01
budgets = []
for theta in [0.2, 0.225, 0.25]:
    margin = 3*theta - 7/12
    assert margin > 0
    budgets.append(dict(H_power=theta, MPR_secondary_budget_power=theta-5/12,
                        target_power=4*theta-1, saving_margin=margin))
growth = []
for log_m in [50, 100, 1000]:
    vm = (log_m / math.log(log_m)) ** (1/3)
    growth.append(dict(log_M=log_m,
                       log_rho_squared_over_target=0.2*log_m+0.8*math.log(2)-2*vm,
                       log_rho_squared_over_target_with_epsilon_005=0.15*log_m+0.8*math.log(2)-2*vm))
result = dict(python=platform.python_version(), numpy=np.__version__, M=m, H=h,
              original_H_interval=[(m/2)**0.2, (m/2)**0.25], rho=rho,
              purpose='Bounded toy checks; neither uniform envelope nor asymptotic lower bound is certified by finite samples',
              mu_unchanged=True, formula_max_residuals=formula_residuals,
              packet_band_energy=ed, base_true_mu_band_energy=e0,
              joint_energies=energies, parallelogram_residual=parallelogram,
              Fejer_K=k, Fejer_local_energies=local, root_transfer=root_checks,
              sampled_parameter_count=len(samples), worst_sample=worst,
              sampled_literal_1_01_envelope_pass=True,
              lowest_H_specialization_tested=False,
              MPR_secondary_budget=budgets, asymptotic_log_gap_examples=growth,
              finite_energies_over_target={s:value/(h**4/m) for s,value in energies.items()},
              overall='PASS')
Path(__file__).with_name('rh-round4-verifier-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
