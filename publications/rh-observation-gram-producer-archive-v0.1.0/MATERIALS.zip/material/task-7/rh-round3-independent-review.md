> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Independent review of the finite short-filter obstruction

2026-10-03. Reviewed only `rh-round3-short-filter-obstruction.md` and its accompanying `rh_round3_verify.py`. No original project files were consulted or changed. This is a same-model, independent-new-context mathematical review; it is not a cross-model assessment or an external primary-source theorem audit.

**Disposition: the finite proposition and its sharpness claim are valid.** I found no substantive mathematical flaw. Its application establishes an exact domination obstruction on the arbitrary-coefficient test class. It establishes no quantitative obstruction for the true arithmetic coefficients or for an estimate with an additive error, and supplies no RH result. The manuscript makes those limits explicit.

## Algebra and quantifiers

For each fixed M, the polynomial P has degree s, nonzero endpoints, and distinct roots at exactly the observed Mth roots of unity. Its s+1 coefficients therefore define a nonzero vector on any permitted consecutive block. The stated DFT convention gives the displayed translated evaluation of P, so the positive-weight observation energy vanishes exactly.

For a filter whose support fits in K consecutive residues, a cyclic shift gives a nonzero polynomial Q of degree at most K−1. If K<M−s+1, then deg(QP)≤K−1+s<M. The ordinary polynomial ring over C has no zero divisors, and a nonzero polynomial of degree below M cannot be a multiple of z^M−1. Hence QP represents a nonzero cyclic convolution. Translation of either input contributes a unit power of z in C[z]/(z^M−1); it cannot turn that nonzero class into zero. This explicitly handles an input interval or a filter interval crossing residue 0.

The same P works for every short nonzero filter. Since V is a sum of nonnegative squared norms, one positive summand contradicts V≤C E_F, whatever the other filters do. The contradiction holds for every finite C, including constants depending arbitrarily on M. No uniform lower bound on the positive energy is needed. Composite M introduces no difficulty: the Mth roots are distinct for every positive integer M.

Positive weights on F are sufficient and give a finite sharpness constant because F is finite. Zero-weight frequencies must be excluded from F, as they are in the observation application. No symmetry of the weights is needed for the real-vector statement. Symmetry of F makes P real by conjugate pairing, including any self-conjugate roots ±1. The constructed real vector works even for complex filters; requiring real filters is harmless but stronger than necessary.

## Sharpness and cyclic span

The complement-root polynomial Q_* has degree M−s and vanishes at every frequency outside F, while remaining nonzero on F. With the stated unnormalized DFT, Parseval contributes precisely 1/M. Thus the displayed constant max_{h∈F}|Q_*(ζ^(−h))|²/(M w_h) proves domination for all vectors.

Q_* has a representative supported in the stated block of M−s+1 residues. For clarity, its nonzero endpoints alone do not prove *minimal* span on a circle: another placement might exploit an internal gap. Here the already-proved necessity rules out any shorter cyclic support interval, so the minimal span is indeed M−s+1. This is an optional exposition clarification, not a gap in the combined proof.

## Application to the weighted observation

Writing x=m−M introduces no residual phase because h is an integer. The weight ψ(1+x/M)/(M+x) is real and nonzero on a fixed interior interval where |ψ| is bounded below. That interval contains a positive constant times M consecutive integer samples for large M, whereas s=O(H)=o(M) in the stated H range. It therefore accommodates the needed block of s+1 samples. Dividing the constructed vector by this weight realizes it as test coefficients c; when F is symmetric, those coefficients may be real.

For active integer h, 8H<M ensures distinct residues because any two supported frequencies differ in absolute value by at most 8H. Defining F using η(h/H)>0 and w_h=η(h/H) therefore identifies the observation energy with E_F exactly. The annular support excludes residue 0, so F is proper; its plateau supplies nonempty F for sufficiently large H. Consequently the necessary filter span is M−s+1=M−O(H), which excludes span o(M) for exact domination on this test class.

This realization does not satisfy the prescribed arithmetic formula for c merely by construction. The proof uses arbitrary coefficients and exact observation-band zeros. It cannot establish a lower bound for the actual arithmetic remainder, rule out an arithmetic-only gate, or exclude V≤C E_F+R when R is separately estimated. Even for the constructed counterexample, V>0 does not specify its size relative to H^4/M.

The scaling sentence is valid for any finite collection of strictly positive homogeneous upper bounds on coefficient amplitudes or interval sums: a sufficiently small nonzero multiple satisfies them. An optional clarification would add “strictly positive upper bounds, without a prescribed normalization.” Scaling does not preserve a nontrivial fixed amplitude, retain a useful lower bound for V, or establish arithmetic identities. The manuscript already acknowledges the last two limitations.

## Verification and audit boundary

I inspected the supplied verifier. It uses floating-point DFT diagnostics on composite groups M=16 and M=24, checks wrapped input support, the real construction, positive Haar-filter energy, Parseval normalization, and complement-filter leakage. Its residual checks are appropriately described as numerical diagnostics rather than exact proofs.

I independently ran exact integer convolution checks through Python standard-library code, without creating another verifier file:

* M=6, F={1,5}: P=1−z+z² and Q_*=−1−z+z³+z⁴ satisfy Q_*P=z⁶−1 exactly. A block starting at residue 5 wraps through 0. The sharp convolution is exactly zero on this vector, while three short nonzero filters give nonzero convolutions.
* M=2,…,11: P=z−1 with Q_*=1+z+⋯+z^(M−1), and the reversed complementary choice, check the endpoint cases s=1 and s=M−1 by exact integer cyclic convolution.

Both independent checks passed. General validity rests on the polynomial proof, not on these finite examples. I did not verify the literature statements, the earlier conditional summable-gcd result, novelty, attribution, or licensing; those lie outside this bounded review. No remaining blocker affects the finite proposition.

## Second audit: approximate local replacement with a paid error

This separate audit covers the subsequently added section “A concrete approximate local replacement with a paid error.” It has the same same-model, independent-new-context limitation as the first audit. I checked the added section directly and ran my own additional small diagnostics. I did not audit external theorems or original project files.

**Disposition: the approximate proposition is valid under its stated smoothness and mass hypotheses.** The transfer is an equivalence of target-scale upper bounds. It does not prove the target arithmetic Gram estimate, an unconditional small difference of the two energies, or RH. There is no conflict with the exact obstruction because the local replacement pays an explicit error.

### Square-root regularity

For a globally nonnegative C_c² function η, set C=||η''||∞. The plateau ensures C>0. Taylor's upper bound at displacement −η'(t)/C is η(t+u)≤η(t)−η'(t)²/(2C). Combining it with η(t+u)≥0 proves |η'(t)|²≤2Cη(t), hence |(√η)'|≤√(C/2) on every positive component. Continuity and the zero values at component boundaries extend this Lipschitz bound across zeros. Thus the periodic rescaling has Lipschitz constant O_η(M/H). Its vanishing near the seam follows from 4H<M/2.

The final manuscript explicitly specifies η∈C_c^∞(R) in its initial declaration, which supplies the needed global C_c² regularity. This resolves the only precision issue raised during the second audit. Square-root Lipschitz regularity would not follow from continuity alone.

### Discrete Fejér kernel and normalization

Substitution of the inverse DFT defining q_n into its forward multiplier gives exactly

    Q(h)=(1/M) Σ_j f_j F_K((j−h)/M).

There is no conjugation or missing factor of M. The signed indices |n|<K are distinct residues when K<M/2. The kernel is nonnegative. Averaging it over M sample points leaves only its n=0 coefficient because |n|<K<M; therefore the average is exactly 1.

Writing d_j=dist(j/M,Z), the bound F_K≤min(K, O(1/(Kd_j²))) gives a first-moment contribution O(1/K) from j≤M/K and O((log(2K))/K) from the remaining harmonic sum, with reflection handling the other half of the circle. This calculation introduces no hidden factor of M. Multiplying by the periodic Lipschitz constant yields

    ||Q−f||∞ ≲_η (M/H)log(2K)/K ≲_η M^(−γ)log M.

For the unnormalized DFT, M||q*a||²=Σ_h |Q(h)â(h)|² and E_F=Σ_h |f_hâ(h)|². The reverse triangle inequality then gives the stated root-energy error, using Σ_h|â(h)|²=MΣ_x|a_x|². Assumption (5) supplies its additional factor √log M.

### Uniform scale, actual coefficients, and target equivalence

The original lower endpoint is H≥(M/2)^(1/5), so

    K/M ≤ 2^(1/5)M^(γ−1/5)+1/M → 0,
    H⁴/M ≥ 2^(−4/5)M^(−1/5).

For fixed 1/10<γ<1/5, these imply K<M/2 eventually and

    [M^(−γ)(log M)^(3/2)]² /(H⁴/M)
      ≲ M^(1/5−2γ)(log M)³ → 0

uniformly over all H in the original range. The threshold for “sufficiently large M” may depend on the fixed γ. No uniformity as γ approaches either endpoint is claimed. The ceiling in K does not change the estimates. At γ=3/20 and H≈M^(1/5), the span O(M^(19/20)) is correct.

For the true coefficients, the displayed three-channel formula and |μ|≤1 reduce the quadratic mass to Λ² sums and O(M) constant terms. Since Λ(n)≤log(2M) on the relevant range, Chebyshev's bound Σ_{n≤2M}Λ(n)=O(M) gives Σ|c(m)|²=O(M log M). The even-index Λ(m/2) term is bounded in the same manner. Multiplication by bounded ψ and division by m≥M give (5). This argument uses no pair-correlation cancellation.

Let r be the root-energy error and T=H⁴/M. The inequalities

    E_loc ≤ 2E_F+2r²,
    E_F ≤ 2E_loc+2r²,
    r²=o(T)

prove the asserted equivalence of O_ε(TM^ε) upper bounds, with potentially different implicit constants. They do not bound |E_loc−E_F| by o(T) without a further energy estimate: the direct difference bound contains r(2√E_F+r). The manuscript correctly distinguishes these conclusions. In particular the required bound on E_loc remains an unproved arithmetic input.

### Ordinary covariance representation

Expanding Σ_y|Σ_n q_n a_{y−n}|² and setting x=y−n produces a_x overline(a_{x+n−m}); the displacement is n−m, matching the manuscript's definition of C_a. Compact support of ψ inside (1,2) leaves a fixed positive multiple of M as a margin from each seam. Since 2K=o(M), every displacement |n−m|≤2K−2 is smaller than that margin eventually. The cyclic correlations then agree exactly with the zero-extended ordinary correlations. The physical expression and its normalization by M are correct. This no-wrap conclusion uses the actual ψ-supported vector; arbitrary vectors obeying only the mass bound still retain the cyclic formulation of the proposition.

### Additional independent diagnostics

I ran a standard-library floating-point test with M=128, H=8, K=30 and an even smooth sampled f, checking direct inverse/forward DFT against the Fejér expression, kernel normalization, first moment, Parseval, and the root-energy perturbation inequality. All checks passed. The first moment was approximately 0.0188434; the root-energy difference was approximately 0.170021, below the computed spectral error bound 0.444747. These toy parameters check finite identities and do not certify the original asymptotic H range or the power-saving limit.

I also ran an exact integer convolution/covariance test on M=20 with support strictly inside the seams and filter displacements −2, 0, 2. It confirmed the sign n−m and equality with zero-extended correlations. The general estimates are established by the analytic argument above, rather than these diagnostics. No remaining mathematical blocker affects this second proposition under the smoothness hypothesis.
