> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# RH / local Weil 第四有界轮检查点

2026-10-03。原库只读，前三轮成果保留。第二、三轮封存packet的SHA256启动核对无变化。本轮没有重做滤波工程，也没有证明真实signed Gram的固定幂节省。

## 从原文落实的差距

Srivastav arXiv2505.07803v2（2026-01-27）Theorem1/Cor1原始陈述已读。真实观察频率q=1、delta≈H且倍素数臂delta≈2H均在原参数区间；Abel后每个真实A_h≤O(H^-1/2)，O(H)频率平方总成本O(1)。最低H≈M^(1/5)的目标M^-1/5仍缺，不能把必要单频界当作整带充分界。

Maynard–Pandey–Radziwill arXiv2608.14777v1（2026-08-14）Theorem1.1原始陈述已读。其N19/24上界项在归一化后平方累计为H M^-5/12+o(1)，相对目标的最坏幂裕量是1/60，已低于目标；N/√B、B≈H的另一上界项仍主导。两项只是上界预算，不是实际算术向量分解，不能“删除已付第二项”后声称得到了真实余项控制。原文严格n<N，端点O(logN)已明确吸收。

这两篇均为所读版本的preprint。主代理和独立审查者核了原始陈述/参数，并未独立审计两篇完整证明。前轮ordinary S_nu条件性输入保持原范围。

## 本轮新完成的严格障碍

自足稿rh-round4-pointwise-envelope-obstruction.md：保留μ为真实μ，在全整数上取非真实但非负的

    L_M^±(n)=1±rho_M χ(n/M)cos(2πt_*H log(n/M)),
    rho_M=exp(−aV_M), H=ceil((M/2)^(1/5))。

对所有x∈[M/2,4M]及完整参数q≤√x、|epsilon|≤1/(q√x)，证明统一的文字常数界

    |Σ_(n≤x)L_M^±(n)e(n alpha)|≤1.01x/√(delta_0q)。

这覆盖2026 MPR完整参数区间、Srivastav Cor1的字面Λ界及Theorem1完整参数的相同单频量纲。q≥2利用有理相位与整数分离，所有前缀成本O(q)；q=1分小delta的二阶导积分和大delta的非驻相积分，Euler误差一致支付。振幅rho→0使1.01常数有足够裕量。

同时ordinary短和逐点≤rho|I|，真实μ所有乘法、二进、平方自由关系和来源单频输入均保持。用**同一全域两尺度观察公式**计算c±，倍臂包在该窗口恰为零，得到

    A_h^±=U_h∓4rho D_h。

驻相使Theta(H)个η平台频率|D_h|≥cH^-1/2，故E_D≥c；Hilbert平行四边形不等式在完全不估计真实μ的U_h时，保证某个±有E≥c rho²≫H⁴M^-1+epsilon。该系数二次质量O(M)，调用第三轮已冻结的Fejer根能量转移可得同一E_loc下界。

**范围十分明确：** 两个L±都不是真实Λ，破坏素数幂支撑及Λ=μ*log。反模型只排除从这些完整单频包络、ordinary短和、非负性、真实μ及两尺度线性公式推导整带幂界的路线；不反驳真实Gram、RH或利用缺失算术结构的新证明。没有把已有scratch873驻相包、952单点调制重新冒充新结果。新增已证接口是完整单频参数区间的保存与真实μ的联合选号。

## 复现和审查

`python3 rh_round4_verify.py`，Python3.14.7、NumPy2.5.1；本地M32768、H10，μ筛到2M，290组完整参数样本。原式与简化式误差<4.5e-16，平行四边形残差0，最大样本包络比率1.000770465<1.01，根能量转移和指数预算PASS。代码只需既有NumPy，无安装或重算。

重要有限边界：该H在允许区间，但不等于命题最低H的7；该尺度E/目标约0.1414和0.1292，并未出现有限目标违反。输出明确记录这些事实。统一所有参数与渐近超目标结论由解析证明，不由有限样本认证。

rh-round4-independent-review.md为独立新上下文**同模型**复核：无阻断数学漏洞，统一文字常数、相位积分、选号、1/60预算、冻结Fejer接口均认证。审查者还读了两篇原始定理陈述，但未核全文证明；没有异源审查或新颖性认证。两项可选措辞建议已修正。

## 接续的单个科学义务

真实Λ的精确素数幂支撑与Λ=μ*log必须在同一个三通道signed pair sum里被量化，而不能仅把其输出单频上界再平方。具体待证仍是第三轮显示的普通位移Fejer Gram E_loc≤H⁴M^-1+epsilon，或一个能改变该缺口的真实算术子和估计。任何对本轮L±替换稳定的新增一阶/单频假设，均须先检查是否仍被该反模型满足；若满足，就不能作为幂界闭合依据。当前未取得实际算术节省，不应把方法边界声称为RH进展。

## 保持与贡献

新packet另存task-7；old封存hash保持。进程归属仍UNKNOWN，既有ps权限拒绝未重试/绕路；没有原库取锁或写入。无重算、HPC/SAT、云VM、付费、账户操作、密钥、上传、DOI、签名或发布。

潜在最小贡献是新稿＋轻量代码＋结果＋审查，带源审计与新manifest。Fejer附结论的证明依赖已冻结第三轮；该依赖的hash在manifest单列，不覆盖旧稿。署名、许可、新颖性及异源验证仍待统一贡献父任务处理，第三方PDF/原私稿历史不入公开候选。

PULSE=FULL_POINTWISE_ENVELOPE_OBSTRUCTION; TRUE_ARITHMETIC_POWER_SAVING=OPEN.
