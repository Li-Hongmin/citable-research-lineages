# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
#!/usr/bin/env python3
"""Exact algebra diagnostics for the summable-gcd remainder; no theorem search."""
from fractions import Fraction as F
import json, math, platform
nu=F(59,100); eps=F(1,1000); lam=F(3,5)
exponents={
 'ordinary_short_sum_power':nu+eps-lam,
 'supported_divisor_count':F(1,2)+eps-lam,
 'rankin_divisor_tail':F(-1,32)+eps,
 'background_prefix':-lam,
 'freeze_smooth_weight':F(-1,5),
 'formal_gcd_tail':-lam,
}
assert all(x<0 for x in exponents.values())
series={
 'ordinary_short_sum_g_weight':1+nu,
 'supported_divisor_count_g_weight':F(3,2),
 'rankin_divisor_tail_g_weight':F(63,32),
}
assert all(p>1 for p in series.values())
# Decreasing-integral envelopes for the nonnegative series.
N=10000
series_checks=[]
for name,p in series.items():
    s=math.fsum(g**(-float(p)) for g in range(1,N+1))
    envelope=1+1/(float(p)-1)
    assert s<=envelope
    series_checks.append({'name':name,'p':str(p),'partial_sum':s,'universal_integral_envelope':envelope})
# g<=2L and H>=c M^(1/5): X=M/g>=c M^(1/5),
# and q<=X^(1/8): x/q>=c M^(7/40).
assert F(1,5)*(1-F(1,8))==F(7,40)
# Exact coefficient identity in basis (1,1/zeta(2)).
background_odd=(F(8),F(0));background_even=(F(1),F(0));prime=(F(-9),F(0))
assert tuple(background_odd[k]+background_even[k]+prime[k] for k in (0,1))==(0,0)
# Route comparison: for L=M^lambda, total bound exponent is lambda-4/5.
# Target at H=M^(1/5) is -1/5. For lambda=3/5+delta, gap=delta.
gaps=[]
for delta in (F(1,100),F(1,20),F(1,10)):
    observed_power=(lam+delta)-F(4,5)
    target=F(-1,5)
    assert observed_power-target==delta
    gaps.append({'delta':str(delta),'power_gap':str(delta)})
print(json.dumps({'python':platform.python_version(),
 'chosen_nu':str(nu),'chosen_epsilon':str(eps),
 'power_exponents':{k:str(v) for k,v in exponents.items()},
 'series_checks':series_checks,'smallest_scaled_start_power':'7/40',
 'constant_conservation':'PASS','fixed_power_gap_checks':gaps,
 'status':'PASS','scope':'Finite exact algebra, exponent margins and decreasing-integral checks; not an asymptotic/RH certificate.'},indent=2))
