> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Complete single-frequency envelopes do not force the joint arithmetic Gram power

2026-10-03. RH/local Weil bounded pulse 4. Original project and previous packets remain read only. This note compares two primary-author exponential-sum estimates at the actual observation frequencies and proves a strict limitation of using their pointwise envelopes alone. It gives no counterexample for the true Λ or μ and no RH result. The old ordinary-short-sum chirp is a precedent, not a new claim here; the additional audited obligation is preservation of the complete rational-approximation parameter ranges and the exact observation formula with μ unchanged.

## Primary inputs and the actual gap

Let M=2Y, Y^(1/5)≤H≤Y^(1/4), η∈C_c^∞(R) even and nonnegative, supported where 1/2≤|t|≤4 and ≥1 where 1≤|t|≤2, and ψ∈C_c^3((1,2)). Write e(t)=exp(2πit). The actual joint observation is

    A_h=Σ_(M<m<2M) [c(m)/m] ψ(m/M)e(−hm/M),
    c(m)=2 1_(2|m)(Λ(m/2)−1)−4(Λ(m)−1+(log2)μ(m)),
    E=Σ_h η(h/H)|A_h|².

The target is E≪_ε H^4 M^(−1+ε). The explicit Fejér-weighted local Gram from pulse 3 has an equivalent target bound, with its approximation already paid. No additional filter approximation is needed in this pulse.

Srivastav, *Log-free bounds on exponential sums over primes*, [arXiv:2505.07803v2](https://arxiv.org/html/2505.07803v2), 27 January 2026, Theorem 1 and Corollary 1, was read in its original statement. Corollary 1, for α=a/q+δ/x, (a,q)=1, q≤x^(1/3), |δ|≤x^(4/15)/q, δ_0=max(1,|δ|/4), gives

    |Σ_(n≤x) Λ(n)e(nα)| ≤51x√q/(φ(q)√δ_0),
    |Σ_(n≤x) μ(n)e(nα)| ≤15x/√(δ_0φ(q)).

In the observation band take q=1, α=1−h/M (or 1−2h/M for the doubled arm), with δ=−hx/M or −2hx/M at each summation endpoint x≍M. Since H≲M^(1/4), |δ|≲H<x^(4/15) eventually. Abel summation gives each weighted channel O(H^(−1/2)); the smooth background is smaller. Thus this application gives |A_h|≲H^(−1/2) but, after O(H) frequency squares, only E≲1. At H≍M^(1/5), an individual plateau mode necessarily has this very size bound if the target holds; it is the accumulation over the whole band that remains unestimated.

Maynard–Pandey–Radziwiłł, *Exponential sums over primes*, [arXiv:2608.14777v1](https://arxiv.org/html/2608.14777v1), 14 August 2026, Theorem 1.1, was also read. For α=a/q+ε, q≤N^(1/2), |ε|≤1/(qN^(1/2)), B_α=max(q,qN|ε|), its Λ bound is

    N^(o(1))(N/√B_α+N^(19/24)).

Here q=1 and B_α≍H. The original MPR sum is n<N; replacing this by n≤N adds an O(log N) endpoint, absorbed in the stated secondary budget. In the normalized weighted channel the second term costs M^(−5/24+o(1)). Its squared frequency budget is H M^(−5/12+o(1)), whose ratio to H^4/M is M^(7/12+o(1))/H³≲M^(−1/60+o(1)) throughout the allowed H range. That budget is below the target. The first term is still H^(−1/2+o(1)) per frequency and does not pay the joint band. These are terms in an upper bound, not a decomposition of the true arithmetic coefficients into two separately removable vectors. Neither primary statement supplies the needed signed correlation.

Earlier all-interval and almost-all-interval uniformity inputs, and the conditional ordinary μ short-sum input, retain exactly the scopes recorded in pulses 2–3. No exceptional-set estimate is turned into an all-M theorem. No claim of current optimality is made from these two comparisons.

## Countermodel proposition with the actual μ retained

Along even integers M→∞, fix a nonnegative, nonzero ψ∈C_c^∞((1,2)), a permitted subclass of the original C_c^3 tests, and the fixed η above. Choose t_*∈(1,2) with ψ(t_*)>0 and a fixed χ∈C_c^∞((1,2)), 0≤χ≤1, χ(t_*)>0. Fix a>0, let

    H=ceil((M/2)^(1/5)),   V_M=(log M/log log M)^(1/3),
    ρ_M=exp(−aV_M),
    u_M(n)=χ(n/M) cos(2πt_*H log(n/M)),
    L_M^σ(n)=1+σρ_M u_M(n),   σ∈{+1,−1}.

The packet is zero outside M<n<2M. These are global nonnegative real functions on the positive integers, not von Mangoldt functions. Keep μ_M^σ=μ, the true Möbius function, unchanged.

**Proposition.** For sufficiently large M the following statements hold.

1. For every x∈[M/2,4M] and every α=a_0/q+ε with (a_0,q)=1, 1≤q≤x^(1/2), |ε|≤1/(q x^(1/2)), put δ=xε and δ_0=max(1,|δ|/4). Uniformly in this whole parameter set and both σ,

       |Σ_(n≤x) L_M^σ(n)e(nα)| ≤1.01 x/√(δ_0q).                (1)

   In particular these functions obey the Λ envelope of the 2026 Maynard–Pandey–Radziwiłł theorem, up to a fixed constant, throughout its parameter set for x≍M. They also obey Srivastav's literal Corollary 1 Λ bound there, because its parameter set is contained in this one and √q/φ(q)≥1/√q. The larger fixed-parameter Theorem 1 domains are contained as well; (1) supplies their pointwise scaling. This is a statement about the numerical envelopes, not about having the arithmetic hypotheses of those theorems.
2. For every ordinary interval I,

       |Σ_(n∈I) (L_M^σ(n)−1)| ≤ρ_M # (I∩Z).                   (2)

   For x≍M this is stronger than an ordinary prefix bound u exp(−cV_x)+x^ν, for any fixed ν>7/12 and some c>0. The unchanged true μ has the previously specified ordinary input S_ν and the literal Srivastav bounds, conditional only on those external inputs being used in their stated ranges. No new assertion about their proofs is made.
3. Define c_M^σ by the **same exact two-scale formula** as c, using L_M^σ and the unchanged μ on every positive integer. Define A_h^σ and E_σ with ψ and η as above. At least one sign σ_M satisfies

       E_(σ_M) ≥c_(ψ,χ,η)ρ_M²,
       E_(σ_M)/(H^4 M^(−1+ε)) →∞ for each fixed 0<ε<1/5.       (3)

4. Both coefficient systems have Σ_(M<m<2M)|c_M^σ(m)|²=O(M). Hence the already proved mass-based Fejér transfer applies. Its E_loc counterpart has the same lower bound up to a smaller positive constant for the sign in (3), for all sufficiently large M.

Thus ordinary short sums, nonnegativity, all the displayed rational single-frequency envelopes, the unchanged true μ, its multiplication/parity relations, and the exact two-scale linear formula together still do not force the fixed-power Gram in this larger test class. The missing true Λ prime-power support and Λ=μ*log relation are explicitly violated. The proposition does not rule out a proof that uses these exact arithmetic facts, a true signed pair estimate, or further joint information.

## Proof of the complete pointwise envelope

All constants below depend only on the fixed packet χ,t_*. Let x∈[M/2,4M]. If the support does not meet [1,x], the packet sum is zero. Otherwise its active interval is a subinterval of (M,2M).

Two elementary estimates for the two exponential branches suffice. If a phase F has monotone derivative staying a distance at least κ from every integer, its integer sum on any subinterval is O(1/κ). One direct proof telescopes e(F(n+1))−e(F(n)) using [e(F(n+1)−F(n))−1]^(−1); the reciprocal has endpoint size and total variation O(1/κ) as the monotone increment traverses an interval separated from the integers. Multiplication by χ(n/M) costs only its fixed supremum and total variation, so the same estimate holds with this weight.

For a real phase with monotone derivative and |F''|≳H/M² on this interval, the continuous integral is O(M/√H). Split where |F'|≤√H/M, whose length is O(M/√H), and integrate by parts on the at most two remaining monotone pieces. A bounded-variation amplitude χ has the same integral estimate. Euler summation then costs O(1+H+|δ|) for the phases below. These statements are elementary oscillatory estimates, not μ or prime bounds.

**q≥2.** Reduce a_0 modulo q so 1≤a_0≤q−1. The branch phases are

    F_±(t)=a_0t/q+εt±t_*H log(t/M).

Their derivatives differ from a_0/q by at most |ε|+t_*H/M. Uniformly for q≤x^(1/2),

    q|ε|≤x^(−1/2),   qH/M≲M^(−1/4)→0,

where the weaker full allowed H≤O(M^(1/4)) already suffices. Eventually both derivatives stay at distance at least 1/(2q) from integers, and are monotone. Thus the packet prefix sums are O(q). The geometric prefix of the baseline 1 is O(q) as well. Consequently the L prefix is O(q). But δ_0 q≤x^(1/2), so x/√(δ_0q)≥x^(3/4), whereas q≤x^(1/2). Their ratio tends to zero uniformly. In particular (1) holds for every such q≥2 when M is sufficiently large.

**q=1.** The integer a_0 has no effect. Here |δ|≤x^(1/2). Fix a sufficiently large constant D depending on t_* and the range x/M. For |δ|≤DH the phases ±t_*H log(t/M)+(δ/x)t have |F''|≍H/M², and Euler summation gives a packet prefix bound

    O(M/√H+H)=O(M/√H)≲x/√δ_0.

For |δ|>DH, the derivative of each phase is bounded away from zero by a fixed multiple of |δ|/M. Its continuous integral is O(M/|δ|). Euler summation costs O(H+|δ|), yielding

    O(M/|δ|+H+|δ|)≲x/√δ_0,

because |δ|≤O(√M), H≲M^(1/4), and |δ|>DH. Thus the packet prefix is always at most C x/√δ_0, uniformly.

If |δ|≤4, use positivity and the pointwise bound L_M^σ≤1+ρ_M to bound the entire prefix by (1+ρ_M)x≤1.01x eventually. In this case δ_0=1. If |δ|>4, the baseline geometric sum is at most x/(2|δ|), since |ε|≤x^(−1/2) and |sin(πε)|≥2|ε| for large x. Its ratio to x/√δ_0 is ≤1/(4√|δ|)≤1/8. The packet ratio is at most Cρ_M→0. This proves (1), with the stated 1.01 factor, for q=1 too.

For Srivastav's fixed parameter 0<κ≤1/10, q≤x^(2/5−κ)≤x^(1/2) and |ε|≤x^(−4/5+κ)/q≤1/(q x^(1/2)), so the whole stated domain is included. Corollary 1 follows by κ=1/15. The μ inputs remain exactly those of the true μ. Statement (2) and nonnegativity follow pointwise from |u_M|≤1.

## Proof of the full-band lower bound and joint sign selection

For M<m<2M, m/2<M, so L_M^σ(m/2)=1. Therefore the two-scale formula gives exactly

    c_M^σ(m)=−4(log2)μ(m)−4σρ_M u_M(m),
    A_h^σ=U_h−4σρ_M D_h,
    D_h=Σ_(M<m<2M) [χ(m/M)ψ(m/M)/m]
                         cos(2πt_*H log(m/M))e(−hm/M),

where U_h is the unchanged true μ channel. No estimate for U_h is needed in the lower bound.

Put φ(t)=χ(t)ψ(t)/t. For h∈[H,(1+τ)H], first fix small τ>0 so t_h=t_*H/h remains in a fixed interval where φ>0. Euler summation and the two cosine branches give

    D_h=(I_h^++I_h^-)/2+O(H/M),
    I_h^±=∫_1^2 φ(t) e(±t_*H log t−ht)dt.

The positive branch has a unique nondegenerate stationary point t_h. Uniform one-term stationary phase gives

    I_h^+=exp(iΘ_h−iπ/4) φ(t_h)t_h/√(t_*H)+O(H^(−3/2)),

where Θ_h is real. The negative branch is O(H^(−1)) by integration by parts. Since H/M=o(H^(−1/2)), it follows that |D_h|≥c H^(−1/2) on Θ(H) integer frequencies inside η's plateau. Hence

    E_D=Σ_h η(h/H)|D_h|²≥c>0.

In the weighted frequency Hilbert space the parallelogram identity is exact:

    E_++E_−=2||U||²+32ρ_M² E_D≥32cρ_M².

Thus one sign has E_σ≥16cρ_M². This selects a possibly scale-dependent nontrue Λ weight; it does not identify a failure of the genuine Λ. Since V_M=o(log M) and H⁴/M≍M^(−1/5), the ratio in (3) tends to infinity for every fixed ε<1/5.

The displayed c_M^σ is uniformly bounded, so its quadratic mass is O(M), even stronger than the real coefficient mass used in pulse 3. In the Fejér transfer choose any fixed 1/10<γ<1/5. Its root-energy error is O(M^(−γ)log^(3/2)M)=o(ρ_M). Accordingly the winning sign also has E_loc≥c'ρ_M². This invokes the frozen transfer theorem rather than redoing its construction or representing its paid error as arithmetic cancellation. □

## What this closes and what it leaves open

Original scratch 873 already proves a subexponential-amplitude log chirp defeats ordinary short-sum and mass bounds; scratch 952 gives prime-supported two-scale modulations. Neither claim is relabeled as new here. The new verified interface is the simultaneous preservation of the **whole** rational pointwise envelope domains, including the August 2026 Λ estimate, while using the actual μ in the joint sign argument. The construction loses genuine Λ support and convolution. Thus it excludes only an envelope-only route; it neither restricts a method exploiting those missing arithmetic structures nor establishes an actual correlation lower bound.

The remaining scientific obligation is the true three-channel signed pair estimate, equivalently the explicit E_loc bound. Improving generic rational-denominator exponents without affecting the small-q, δ≈H envelope or its joint accumulation does not close that obligation. A usable next subclaim must supply real arithmetic coupling or a joint spectral estimate that is not stable under the displayed Λ replacements. No isolated-channel upper bound is declared a necessary condition.

## Reproduction and release boundary

The companion verifier uses bounded local finite checks for the exact two-scale observation, μ unchanged, the stationary packet, parallelogram identity and sampled full-parameter envelope ratios. It also records exponent budgets and the mass-based Fejér transfer check. Finite samples cannot certify the uniform envelope or the asymptotic countermodel; those assertions rest on the proof above.

The self-contained note, own verifier/output and independent review are a potential minimal contribution. Original private notes, third-party PDFs and extracted text are excluded. Human attribution, licensing and novelty are unresolved. No prior packet is overwritten, and no key, DOI, upload or publication is made.
