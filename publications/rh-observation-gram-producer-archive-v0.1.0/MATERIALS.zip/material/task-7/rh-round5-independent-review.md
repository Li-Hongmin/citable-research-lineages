> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Independent review of the true-convolution reduction

2026-10-03. Reviewed `rh-round5-true-convolution-stop.md` in fresh context, together with the frozen analytic localizer in `rh-round3-short-filter-obstruction.md`. This is an independent agent from the same model family, not a heterogeneous mathematical review. The original project was not edited; no external services or paid work were used.

## Verdict

**The analytic reduction is valid within its stated large-M range. No blocking mathematical error was found in (2)–(11), including the leakage payments and equivalence with (H5).** The result is a recovery and transport of a true-convolution gate. It supplies no new signed off-diagonal estimate, no new arithmetic power saving, and no RH conclusion. The stopping decision is justified.

The statements about what private scratch notes already contain were not independently re-audited in this review. The verdict concerns the displayed round-5 mathematics and its frozen pulse-3 localizer dependency. It does not certify exhaustive novelty research or publication readiness.

## Exact convolution and source reconstruction

Substituting the actual identity `Lambda(n)=sum_{d|n} mu(d) log(n/d)` into the two Lambda arms gives cofactor coefficient `-4 log k + 2 1_(2|k) log(k/2)`. For n>1, `-4 log(2) mu(n)=4 log(2) sum_{d|n,d<n} mu(d)`. Adding this contribution for k>=2 gives exactly the displayed kappa, with k=2 equal to zero. The constant terms are `b(n)=4-2 1_(2|n)`. There is no missing parity factor or surviving k=1 source. Formula (2) therefore holds, including n=2.

Since the supported physical integers satisfy M<n<2M and k>=3, all active divisors satisfy d<2M/3. Splitting them at D gives the exact identity `a=a^hi+r`, before convolution. This uses actual mu and Lambda; an altered Lambda with unchanged mu must separately satisfy the inversion identity before this reduction can be applied.

## Low sources and their leakage

For d<=D put X=M/d. Write `F_X(v)=log(Xv/2) phi(v)`. Its Fourier transform is bounded by `C log(M) (1+|xi|)^(-3)` uniformly in this range, because phi and `(log v) phi(v)` are compactly supported C^3 functions. Poisson summation of the integer and even lattices gives, up to the harmless Fourier-sign convention,

    vhat_d(h) = (-4/d) sum_j Fhat_X(h+jX)
                +(1/d) sum_j Fhat_X(h+jX/2).

The second coefficient includes both the factor 2 in kappa and the even-lattice spacing 2. Because X>=16H, the even-lattice spacing is at least 8H. For H/2<=|h|<=4H, both alias families stay at distance at least a constant times `H(1+|j|)` from zero. Thus the stated `log M/(d H^3)` bound follows. The k>=3 cutoff does not disturb this calculation for large M, since the support has k>X>=16H. The background's fixed integer and even lattices have the same alias gap. Summing 1/d yields (3).

The ratio of the first energy term to T is at most `M H^(-9) log^4 M`, which tends to zero uniformly since H is bounded below by a constant times M^(1/5). The elementary pointwise bound for r is `|r_x| <= C M^(-1)(1+tau(M+x) log M)`. Squaring it and using `tau(n)<=C_sigma n^(sigma/4)`, with `log^2 M<=C_sigma M^(sigma/2)`, proves (4). No cancellation was used.

The pulse-3 uniform multiplier estimate and cyclic Parseval give `E_loc(r)<=2E(r)+2 epsilon_M^2 M||r||_2^2`. A choice `0<sigma<2gamma-1/5` makes its second term o(T), uniformly in the H range. The reverse triangle inequality then gives (6). The divisor mass estimate is essential here: the low-source band estimate alone would not control leakage outside the band.

The frozen pulse-3 multiplier proof is also sound for the stated nonnegative smooth eta: its square root is Lipschitz, and the discrete Fejer first moment gives the claimed uniform error. The actual-coefficient mass estimate in that note gives the equivalence of E and E_loc at the target scale. This is an equivalence of upper bounds, not a claim that the two full energies always differ by o(T).

## Total source mass and diagonal payment

There are O(M/d) active cofactors for each d, and each kappa is bounded by a constant times `log(2M/d)`. Hence the frequency-uniform source bound used in (7) is correct. With D comparable to M/H for sufficiently large M, summing `log^2(2M/d)/d^2` for D<d<2M/3 gives `O(log^2(2H)/D)`. This yields the displayed `H^2 log^2(2H)/M`, whose ratio to T is `O(log^2(2H)/H^2)=o(1)`.

For each physical integer n, the source vectors have at most tau(n) nonzero entries at that position, each of squared magnitude at most `C M^(-2) log^2 M`. Interchanging the two finite sums proves (8). The elementary divisor summatory estimate supplies `sum_{n<=2M} tau(n)=O(M log M)`. The total squared mass is therefore `O(log^3 M/M)`, with no unproved average cancellation assumption.

Applying the same multiplier comparison to each source separately and summing its squared error proves (9). Its leakage term divided by T is `O(M^(1/5-2gamma) log^5 M)=o(1)`. This payment is valid for the entire diagonal and does not pay any distinct-source covariance.

## Off-diagonal equivalence and remaining gap

The matrix Gamma is the exact Gram matrix of the filtered source vectors with the stated M normalization. Thus (10) is exact, O_loc is real, and `O_loc>=-D_loc`. Positivity supplies a lower bound of this kind; it does not supply the required small upper bound.

For any fixed epsilon>0, (6) shows that an `O(T M^epsilon)` upper bound for either E_loc(a) or E_loc(a^hi) gives one for the other. Combining `E_loc(a^hi)=D_loc+O_loc` with `D_loc=o(T)` proves the equivalence with `|O_loc|=O_epsilon(T M^epsilon)`. In particular the absolute value in (H5) is justified by the paid diagonal lower bound; it is not an assumption of absolute summability of the matrix entries.

Formula (11) is valid even when a reduced factor is not squarefree: then mu(uv)=0 and both sides vanish. If g shares a prime with uv, one original source is nonsquarefree and the mask again makes both sides zero. Otherwise multiplicativity gives precisely `mu(uv) mu(g)^2`. The common-factor variable carries a nonnegative squarefree mask. The observation about the absence of an alternating mu(g) sign is correct; it leaves all kernel-dependent or cross-reduced-pair cancellation unproved.

No step in this note proves (H5). The exact identity, source diagonal payment, Gram positivity, and gcd factorization together are a reduction, not the missing arithmetic estimate. The note maintains this distinction consistently.

## Minor presentation clarification

The initial draft could specify once that cyclic vectors use representatives `0<=x<M`. The author has added this clarification at line 20. Frequency-dependent eta is naturally evaluated on centered representatives, or equivalently on the integer observation band, whose residues are distinct because `8H<M`. These conventions present no blocking defect.

## Finite diagnostic

Inspected `rh_round5_verify.py` and `rh-round5-verifier-result.json`, then independently reran `python3 rh_round5_verify.py` successfully under Python 3.14.7 and NumPy 2.5.1. Both cases passed: `(M,H,K,D)=(256,3,20,5)` and `(512,4,40,8)`. The largest displayed identity residual was below `8e-15`.

The prime sieve generates Lambda on prime powers and the integer mu sieve correctly zeros squareful entries. The convolution is formed by a separate divisor/cofactor loop. All active sources are included, and the FFT normalization agrees with `M||q*a||_2^2`. The direct Fejer-kernel sum is checked against the Fourier transform of the tapered inverse transform. The code also checks the finite diagonal leakage inequality, exact high/low reconstruction, the Gram/spatial/spectral energy equality, diagonal decomposition, and every common-factor sign identity in the selected source ranges. These comparisons use algebraically different constructions where appropriate.

The altered inputs use n=314 and n=626, both non-prime-power composites within the window. Keeping mu fixed and adding rho=1/32 to Lambda gives a cofactor-identity discrepancy `4rho=1/8` and inversion discrepancy rho, as expected. This shows the true-convolution identity does not extend to those altered Lambda inputs. It supplies no counterexample for actual Lambda or for (H5).

K=20 and K=40 are explicitly finite choices, **not** `ceil((M/H) M^gamma)`. The code and result correctly disclose this; the run therefore audits the fixed functional form of the filter and its exact identities, rather than exercising the asymptotic pulse-3 filter family. The small-case diagonal and signed off-diagonal values must not be interpreted as evidence for their large-M target scales. Finite computations cannot establish the analytic payments or (H5).

**Final disposition: accept the stated reduction and research stop, with no blocking finding. The complete signed arithmetic gate (H5) remains unproved. No new power saving or public contribution follows from this review.**
