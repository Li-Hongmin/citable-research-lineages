> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Exact short-filter obstruction and paid localization of the observation-band gate

2026-10-03. Bounded RH/local Weil pulse 3. Original project read only. This note proves a sharp finite Fourier obstruction to exact short-filter replacement and a constructive approximate replacement whose error is paid by the true coefficient mass bound. It does not improve the true arithmetic remainder, prove RH, or claim a new uncertainty principle. Independent review status is recorded separately.

## The missing rate and what would count as a new input

Keep the fixed weight and notation of the preceding conditional summable-gcd result: M=2Y, Y^(1/5)≤H≤Y^(1/4), B=M/H, V_M=(log M/log log M)^(1/3). That result gives

    Σ_g |T_g−C_g I_ψ J_M(L)| ≪ (L/B) exp(−c V_M),

for M^(3/5)≤L≤B/64, assuming the stated ordinary μ and Λ−1 prefix estimates. The signed constants sum to zero. At H≍M^(1/5) and L=M^(3/5+δ), the target H^4/M is M^(−1/5) up to constants. In this particular absolute-error interface, a replacement rate ρ_M must satisfy ρ_M≪M^(−δ) to pay that target. Relative to the present exp(−c V_M) rate, the required extra gain is M^(−δ)exp(c V_M); equivalently, the present bound divided by the target is M^δ exp(−c V_M). Allowing the usual M^ε target slack replaces δ by δ−ε. This comparison does not give a lower bound for any actual remainder. Nor is a separate improvement for every displacement band necessary: the full signed bands can cancel.

The full observation is

    A_h = Σ_(M<m<2M) [c(m)/m] ψ(m/M) e(−hm/M),
    E = Σ_h η(h/H) |A_h|²,
    c(m)=2 1_(2|m)(Λ(m/2)−1)−4(Λ(m)−1+(log 2)μ(m)).

Here ψ is a fixed, nonzero real C_c^3((1,2)) function; η∈C_c^∞(R) is fixed, even, nonnegative, supported where 1/2≤|t|≤4 and ≥1 where 1≤|t|≤2. For 8H<M, the active integer frequencies have distinct residues modulo M. Define their residue set F and its size s=O(H). The exact new scalar estimate required is the joint signed Gram E≪_ε H^4 M^(−1+ε). A concrete sufficient input is the uniform joint-coefficient bound |A_h|≪_ε H^(3/2)M^(−1/2+ε/2) on the active band; the O(H) frequency count then pays E. A weaker necessary input on each plateau mode is |A_h|≪_ε H²M^(−1/2+ε/2). At the lowest H these thresholds are respectively M^(−1/5+ε/2) and M^(−1/10+ε/2). The necessary single-frequency bound is not sufficient for the sum. An estimate that only bounds μ or Λ separately need not be necessary, because their three channels may cancel.

## Source comparison before choosing this proposition

The following are primary-author results actually read in this pulse, not evidence that the desired fixed-power joint Gram is already known.

* Matomäki–Shao–Tao–Teräväinen, *Higher uniformity of arithmetic functions in short intervals I. All intervals*, Forum Math. Pi 11 (2023), e29, [author manuscript v4](https://arxiv.org/html/2204.03754v4), Theorem 1.1(i),(ii), Corollary 1.3, and (1.23). The μ and Λ−Λ^sharp estimates give arbitrary logarithmic savings on intervals longer than X^(5/8+ε), including phase twists. The Λ approximant is not the constant 1. These statements alone do not supply the fixed-power error here.
* Matomäki–Radziwiłł–Shao–Tao–Teräväinen, *Higher uniformity … II. Almost all intervals*, Invent. Math. 244 (2026), 967–1091, [published open-access original](https://link.springer.com/article/10.1007/s00222-026-01408-6), Theorem 1.1(i),(ii) and Corollary 1.2. The μ and Λ−Λ^sharp estimates reach X^(1/3+ε) for almost all starting points with logarithmic savings and exceptional-set control. The same theorem has power savings for divisor functions; those parts are not μ or Λ estimates. The theorem's exceptional set and its approximant cannot be discarded when making a pointwise-in-M claim.
* Gallagher, *A large sieve density estimate near σ=1*, Invent. Math. 11 (1970), 329–339, [publisher record](https://link.springer.com/article/10.1007/BF01403187). Only the subscription preview/metadata were accessible, so no transfer lemma is attributed to its unseen full text.

The earlier ordinary-prefix input remains explicitly conditional in the frozen pulse-2 manuscript, with the primary-source audit in its separate record. Ramachandra's 1976 original download remains inaccessible; no claim of direct audit is made here.

Local prior work was checked before selecting the lemma below. Original scratch 952 already constructs prime-supported modulations that preserve quantitative short sums and the exact two-scale formula but violate a fixed-power full-band bound. Scratch 904/910/915 provide different constrained prime flips. Scratch 924/926 use true Möbius inversion to obtain a high-source Gram; they do not pay that Gram. Notes 870/882 already explain a Haar sufficient gate and fixed-order low-frequency leakage. The aborted modulation and fixed-order-Haar ideas therefore are not new results in this pulse. Those originals have not been modified or repackaged as public text.

## Finite proposition: a sharp obstruction to exact local replacement

Let M≥2 be any integer, ζ=exp(2πi/M), and F a nonempty proper subset of Z/MZ with |F|=s. Give each h∈F a positive weight w_h. For a vector a=(a_x)_(x mod M), set

    â(h)=Σ_(x mod M) a_x ζ^(−hx),
    E_F(a)=Σ_(h∈F) w_h |â(h)|².

Let I be any interval of at least s+1 consecutive residues. A finite family of convolution filters q_j may depend arbitrarily on M. Each nonzero q_j is supported in some interval of K_j consecutive residues, with K_j≤M. Write

    V(a)=Σ_j ||q_j *_M a||²_(ℓ²(Z/MZ)).

**Proposition.** If a finite constant C can satisfy

    V(a) ≤ C E_F(a)                                            (1)

for every complex vector supported on I, then every nonzero filter has

    K_j ≥ M−s+1.                                               (2)

The threshold is sharp, even if (1) is required on the entire M-dimensional vector space: there is a nonzero filter supported in exactly M−s+1 consecutive residues for which (1) holds for some finite C. If F is symmetric under h↦−h and the filters are real, the obstruction already holds on real vectors. No primality assumption on M is used.

**Proof of necessity, including a constructive counterexample.** Form the polynomial

    P(z)=∏_(h∈F) (z−ζ^(−h)) = Σ_(r=0)^s p_r z^r.               (3)

Place its s+1 coefficients on consecutive residues inside I, starting at x_0, and zero elsewhere. Then

    â(h)=ζ^(−h x_0) P(ζ^(−h)),

so E_F(a)=0 exactly. Both endpoints of the coefficient block are nonzero: P is monic and its constant coefficient is a product of nonzero roots. In particular a≠0.

Consider any nonzero q_j with K_j<M−s+1. A cyclic shift of its support changes the output only by a cyclic shift, so take its polynomial Q(z)=Σ_(r=0)^(K_j−1) q_r z^r, trimming zero endpoints if needed. The cyclic convolution corresponds to the product Q(z)P(z) modulo z^M−1, together with the harmless shift z^(x_0). The nonzero product has degree at most K_j−1+s<M. It cannot be divisible by z^M−1; thus the cyclic convolution is nonzero. Consequently V(a)>0 but E_F(a)=0, contradicting (1). This same a obstructs every short nonzero member of the family; adding positive variances does not help.

When F is symmetric, the roots in (3) occur in conjugate pairs, possibly with real roots ±1. Thus P has real coefficients. The constructed a is real, proving the real assertion.

**Proof of sharpness.** Take

    Q_*(z)=∏_(h∉F) (z−ζ^(−h)).                                 (4)

Its degree is M−s and its first and last coefficients are nonzero, so it has a consecutive support representation of length M−s+1. Its multiplier vanishes off F and is nonzero on F. Cyclic Parseval gives

    ||q_* *_M a||² = M^(−1) Σ_(h∈F) |Q_*(ζ^(−h))|² |â(h)|²
                  ≤ [max_(h∈F) |Q_*(ζ^(−h))|²/(M w_h)] E_F(a).

The maximum is finite. Necessity already rules out a shorter cyclic support representation, so this proves sharpness. Symmetric F also yields a real sharpness filter. □

## Application and its exact limits

Take x=m−M and a_x=c(M+x)ψ(1+x/M)/(M+x). Any nonzero continuous ψ has a closed interval inside (1,2) on which its absolute value is bounded below. For sufficiently large M its integer samples include s+1 consecutive positions. Every vector constructed in (3) supported there can be realized by some real or complex test coefficient c, using division by the nonzero weight. The active η weights give E_F=E. Thus a nonzero convolution filter with span o(M), including a difference filter whose order grows with M but whose total span stays o(M), cannot satisfy an **exact**, observation-only domination (1) on this arbitrary-coefficient class. Its necessary span is at least M−O(H), and the elementary bound is attained by a global filter.

This is stronger in scope than merely testing a fixed-order adjacent-window difference, but narrower in conclusion than a quantitative arithmetic obstruction. The constructed coefficients need not be μ, Λ, multiplicative, prime-supported, or satisfy their inversion identities. Scaling a can meet any prescribed strictly positive pointwise or interval-sum upper bounds on this finite window, provided no fixed normalization or nonzero lower bound is imposed; scaling does not make the coefficients arithmetic. More crucially, the proof does not quantify V(a) relative to H^4/M as M grows. It excludes exact domination with no additive remainder, even with an M-dependent finite C; it does not exclude a short-filter estimate with a separately paid additive error, or a gate proved only for the true c. It therefore must not be cited as ruling out fixed-power estimates, growing-order Haar methods on the true sequence, or RH.

## A concrete approximate local replacement with a paid error

The exact obstruction does not force the usable gate to be global. Here is a second, positive proposition which keeps an explicitly controlled error. It applies to the actual observation under its known quadratic mass bound, without assuming any new cancellation.

Fix the original smooth, even, nonnegative η, with the stated support. Put f_h=√η(h/H) on the centered residue representatives. Fix 1/10<γ<1/5 and set

    K=ceil((M/H) M^γ),
    q_n=(1−|n|/K) M^(−1) Σ_(h mod M) f_h e(hn/M)  (|n|<K),
    q_n=0 otherwise,
    E_loc(a)=M ||q *_M a||².

For sufficiently large M, K<M/2 and the filter has consecutive support at most 2K−1=o(M). Suppose

    Σ_x |a_x|² ≤ C_0 (log M)/M.                                 (5)

Then, uniformly over the original H range,

    |√E_loc(a)−√E_F(a)| ≪_(η,C_0) M^(−γ) (log M)^(3/2),         (6)
    (right-hand side)² = o(H^4/M).                              (7)

Consequently E_loc≪_ε H^4 M^(−1+ε) if and only if E_F has the same bound. This is an equivalence of target-scale upper bounds; it does not claim their unconditional difference is o(H^4/M).

**Proof.** The square root of a nonnegative C_c^2 function is Lipschitz. Indeed Taylor's upper bound with C=||η''||_∞>0 and displacement −η'(t)/C gives 0≤η(t)−η'(t)²/(2C). Wherever η>0, |(√η)'|≤√(C/2); extension across its zeros preserves the Lipschitz bound. The periodic continuous function θ↦√η(Mθ/H), −1/2≤θ≤1/2, is therefore Lipschitz with constant O_η(M/H), and vanishes near the periodic seam.

The filter multiplier Q(h)=Σ_n q_n e(−hn/M) is the discrete Fejér average of f:

    Q(h)=M^(−1) Σ_(j mod M) f_j F_K((j−h)/M),
    F_K(t)=Σ_(|n|<K)(1−|n|/K)e(nt)
          =K^(−1)|Σ_(r=0)^(K−1)e(rt)|².

This kernel is nonnegative, and M^(−1)Σ_j F_K(j/M)=1 since K<M. Its discrete first moment obeys

    M^(−1) Σ_j dist(j/M,Z) F_K(j/M) ≪ log(2K)/K.

For completeness, use F_K(t)≲min(K,1/(K dist(t,Z)²)). The indices 1≤j≤M/K cost O(1/K); the remainder up to M/2 is bounded by K^(−1)Σ_(M/K<j≤M/2)1/j=O(log(2K)/K). Reflect negative indices; j=0 contributes zero. Thus

    max_h |Q(h)−f_h| ≪_η (M/H)log(2K)/K
                         ≪_η M^(−γ)log M =: ε_M.               (8)

Cyclic Parseval and the reverse triangle inequality in frequency ℓ² give

    |√E_loc−√E_F|
      ≤ [Σ_h |Q(h)−f_h|² |â(h)|²]^(1/2)
      ≤ ε_M √(M Σ_x|a_x|²),

which proves (6). Since H^4/M≳M^(−1/5) and 2γ>1/5, (7) follows. Also K/M≲M^(γ−1/5)→0, establishing short relative support. This proves the proposition. □

For the actual a_x=c(M+x)ψ(1+x/M)/(M+x), (5) follows from Σ_(M<m<2M)|c(m)|²≪M log M. To see that mass bound, square the displayed three-channel formula, use |μ|≤1, and use Σ_(n≤2M)Λ(n)²≤log(2M)Σ_(n≤2M)Λ(n)≪M log M (Chebyshev's bound suffices); the doubled Λ channel is bounded the same way. No prime-pair or Möbius-pair cancellation enters this step.

Because ψ is supported away from both window endpoints and K=o(M), for sufficiently large M the correlations in E_loc have no cyclic wraparound. Its exact physical form is

    E_loc = M Σ_(|n|,|m|<K) q_n overline(q_m) C_a(n−m),
    C_a(k)=Σ_(x∈Z) a_x overline(a_(x+k)),

where a is extended by zero. Only ordinary displacements |k|≤2K−2 enter. The weights keep the signs of the complete three-channel correlations. The explicitly specified mean-square bound E_loc≪_ε H^4 M^(−1+ε) is now a concrete necessary and sufficient local gate at the target scale. It remains unproved. At γ=3/20 and H≍M^(1/5), its spatial span is O(M^(19/20)); this is much longer than a single observation length M/H, and still o(M). The short support comes from a paid approximation error, so it does not contradict the exact proposition.

This resolves the finite localization obligation while preserving the scientific gap: a direct joint signed Gram estimate, or the displayed E_loc estimate, must still gain the missing arithmetic power. Source-normal-form manipulations and one-point bounds must be tested at that interface rather than declared sufficient from names or numbering.

## Reproduction and contribution boundary

Run `python3 rh_round3_verify.py`. It uses the Python standard library, small explicit real polynomials on composite cyclic groups, and direct DFT/convolution. It checks the band-annihilating construction, positive short-filter energy, the degree inequality, Parseval normalization, and the sharp global filter; additional finite examples check Fejér averaging, kernel mass, the Lipschitz first-moment error and the root-energy triangle bound. These small examples are not demonstrations of the asymptotic H/K regime. Floating-point residuals are diagnostics; the polynomial and analytic proofs above establish the claims.

Only this self-contained mathematical note, its own verifier/output, and the independent review can be a minimal candidate for the parent contribution task. Attribution and license require the human author's decision; novelty has not been established. Existing frozen packets are unchanged. No original private source, third-party PDF/extracted text, credentials, key, upload, signature, DOI, or publication is included.
