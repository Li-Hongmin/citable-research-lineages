> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 原始观察系数的固定物理 gcd 分层：独立复核

日期：2026-10-03。复核者为主代理同模型的新上下文实例；这是独立上下文复核，不是异源审查。只读了 notes 894、891、851 及 849 的必要定义；未读 892、未改原库、未作 Git 操作、进程探测或数值重计算。

## 判定与条件

在题设正核有向窗口
\[
M<m,n<2M,\qquad L<n-m\le2L,\qquad
M^{3/5}\le L\le M/(64H),\qquad
Y^{1/5}\le H\le Y^{1/4},\quad M=2Y,
\]
以及 note 891 的统一核界、Poisson 别名界和固定紧支撑平滑权条件下，所给固定精确 gcd 候选成立：对每个**固定**整数 \(g\ge1\)，
\[
T_{cc}^{[g]}(L)=C_g Q+O_{g,\psi,\eta}\bigl((L/B)e^{-c_gV_M}\bigr),
\quad Q=I_\psi J_M(L),\quad B=M/H,
\]
其中
\[
C_1=\frac{32}{3\zeta(2)}-12,\qquad C_2=\frac1{\zeta(2)}+3,
\]
\[
C_g=\frac{32}{3\zeta(2)g^2}\ (g\ge3\text{ 奇}),\qquad
C_g=\frac4{\zeta(2)g^2}\ (g\ge4\text{ 偶}).
\]
这里将 note 851 式 (4) 对 \(\mu\)、\(\Lambda-1\) 的全起点、全前缀短和作为**明确外部假设**：任取固定 \(7/12<\nu<3/5\)，相应误差为 \(u e^{-cV_x}+x^\nu+O(1)\)。本复核没有验证 Ramachandra 原文，也不据 note 851 的既有复核标签将该输入升级为本次已核实事实。

固定层推导实际只需要 \(L\ge M^{3/5}\)，无需额外用到 note 891 的 \(L\ge K_\alpha\)。如果沿用 891 原定理的窗口，结论当然也适用。

## 精确分解与背景层

写
\[
c=b+P_o+P_e+z+E,
\quad b(m)=4-2\mathbf1_{2\mid m},\quad z(m)=-4\log2\,\mu(m),
\]
\[
P_o(m)=-4\mathbf1_{m=p}\log p,\qquad
P_e(m)=2\mathbf1_{m=2p}\log p.
\]
\(E\) 是高次素数幂及其二倍所给的残差。其支撑在 \(m\asymp M\) 有 \(O(\sqrt M\log M)\) 个点，点值 \(O(\log M)\)，故在固定层中所有涉及 \(E\) 的配对可绝对支付为 \(O_g((L/B)M^{-1/2}\log^C M)\)，吸入所需次指数误差。所有 \(P_o,P_e\) 以下都指纯素数项，背景仍是原始 \(b\)，没有平方自由替换。

令 \(m=gu,n=gv\)。精确 gcd 条件为 \((u,v)=1\)。在内端任意区间 \(I\) 上，初等除数展开给
\[
\sum_{v\in I,(u,v)=1}b(gv)=r_g(u)|I|+O(\tau(2u)),
\]
\[
r_g(u)=
\begin{cases}
2\varphi(u)/u,&g\text{ 偶},\\
4\varphi(u)/u,&g\text{ 奇},\ u\text{ 偶},\\
3\varphi(u)/u,&g,u\text{ 均奇}.
\end{cases}
\]
这里最后一行的互素偶内端与奇内端各有密度 \(\varphi(u)/(2u)\)；第二行互素内端必奇。

记 \(P_{\rm odd}=\prod_{p\ge3}(1-p^{-2})=4/(3\zeta(2))\)。每整数的 \(\varphi(u)/u\) 奇、偶部分平均分别为 \(P_{\rm odd}/2\)、\(P_{\rm odd}/4\)，全体平均为 \(1/\zeta(2)\)。故外端乘上 \(b(gu)\) 后的平均为
\[
d_g=
\begin{cases}
12(P_{\rm odd}/2)+8(P_{\rm odd}/4)=32/(3\zeta(2)),&g\text{ 奇},\\
4/\zeta(2),&g\text{ 偶}.
\end{cases}
\]
内外两次尺度换元各给一个 \(1/g\)，所以
\[
T_{bb}^{[g]}=\frac{d_g}{g^2}Q+O_g((L/B)e^{-c_gV_M}).
\]
更具体地，内端除数计数误差对固定 \(g\) 相对主尺度为 \(O_g(\log^2M/L)\)，外端平均误差为 \(O_g(\log M/M)\)；冻结 \(f(n/M)\) 与 Poisson 误差分别为 \(O(L/M)\)、\(O(H^{-A})\)。它们均有固定幂节省。

## 素数项：exact gcd 1 与 exact gcd 2

短位移为 \(o(M)\)。奇素数端点 \(p\asymp M\) 与不同的附近端点自动互素。二倍素数端点 \(2p\asymp M\) 与附近不同端点不可能共有 \(p\)，故其 gcd 恰为另一端的奇偶因子：另一端奇数时为 1，偶数时为 2。这是精确分层的决定性几何事实。

短和假设给纯素数项的每物理整数平均密度
\[
\kappa_o=-4,\qquad \kappa_e=1.
\]
背景不限制奇偶时密度为 \(3\)；限制为奇数时密度为 \(4/2=2\)；限制为偶数时密度为 \(2/2=1\)。沿用 891 的前缀 Abel 求和、核积分与外端平滑平均方法，各通道主系数就是下表中的乘积。两种方向各自成立；复权的冻结主项均为 \(|f|^2\)，不会改变常数。

| 有向通道 | exact gcd 1 系数 | exact gcd 2 系数 |
|---|---:|---:|
| \(P_oP_o\) | 16 | 0 |
| \(P_oP_e\) | -4 | 0 |
| \(P_eP_o\) | -4 | 0 |
| \(P_eP_e\) | 0 | 1 |
| \(P_ob\) | -12 | 0 |
| \(bP_o\) | -12 | 0 |
| \(P_eb\) | 2 | 1 |
| \(bP_e\) | 2 | 1 |

因此 gcd 1 的素数–素数项为 \(16-4-4=8\)，素数–背景两方向合计为 \(-12-12+2+2=-20\)，总修正为 \(-12\)。gcd 2 的纯二倍素数项为 \(1\)，二倍素数–偶背景的两个方向各为 \(1\)，总修正为 \(+3\)。所有 \(g>2\) 不含纯素数或纯二倍素数端点。

尤其不能把 gcd 2 的背景密度误用为全背景密度 \(3\)，或用平方自由替换后的偶背景。这里 \(b(2v)=2\) 为正；exact gcd 2 的近位移条件自动排除与外端大素数共有因子，只留下偶端点密度 \(1\)。这直接解释 \(C_2>0\)。本次未读 892，因此不复核其负层公式；若其平方自由替换层确为负，两结果属于不同系数的精确 gcd 子和，没有矛盾。

## Möbius 项为何没有主项

对固定平方自由 \(g\)，
\[
\mu(gv)\mathbf1_{(u,v)=1}
=\mu(g)\mu(v)\mathbf1_{(v,gu)=1};
\]
非平方自由 \(g\) 则端点 \(\mu(gv)\) 恒为零。令 \(X=M/g\)，取与 891 式 (25) 相同的精确卷积
\[
\mu(v)\mathbf1_{(v,q)=1}=(\mu*a_q)(v),\qquad
\sum a_q(d)d^{-s}=\prod_{p\mid q}(1-p^{-s})^{-1},
\]
其中 \(q=gu\le2M\)。以 \(d\le X^{1/8}\) 分开，851(4) 与 Rankin 尾界给各前缀 \(O_g((L/g)e^{-c_gV_M})\)：需吸收的非指数项包括 \(X^\nu E_\nu(q)\)、\(X^{1/2}E_{1/2}(q)\)、\((L/g)X^{-1/32}E_{3/4}(q)\)。因为 \(E_\sigma(q)=M^{o(1)}\)、\(E_1(q)\ll\log^C M\)、\(\nu<3/5\) 且 \(g\) 固定，它们有固定幂节省。

gcd 2 时可直接写 \(n=2v\)，\(\mu(2v)=-\mu(v)\mathbf1_{(v,2)=1}\)，与 \((u,v)=1\) 合并为 \((v,2u)=1\)，故同一卷积适用。需要奇偶限制时将素数 2 并入 conductor 即可。

将含 Möbius 的端点置于内端，核与平滑权总变差为 \(O(H)\)；外端绝对质量为 \(O(M)\)（背景/Möbius 有界，素数项由短和或 Chebyshev 质量界支付）。这给所有相关通道所需误差。反方向使用相同前缀估计的负位移区间。故 Möbius 的点值在素数上虽非零，完整短和在这些精确层上仍无密度主项。

## 常数求和与量词

系数级数绝对收敛，并且
\[
\sum_{g\text{ 奇}}\frac{32}{3\zeta(2)g^2}=8,\qquad
\sum_{g\text{ 偶}}\frac4{\zeta(2)g^2}=1.
\]
加上 gcd 1 修正 \(-12\) 与 gcd 2 修正 \(+3\)，得到 \(\sum_g C_g=0\)。这是常数级数的精确恒等式；不能仅凭各固定层的 \(O_g\) 误差就将其求和并声称全部层有同一次指数误差，也不能把 \(c_g\) 或隐常数视为对增长 \(g\) 一致。

894 的增长截断定理需要其另外写出的统一链。其参数边界与 14 式相容：\(g\le M^\tau\) 时主障碍为
\[
M^{\nu-\lambda+o(1)}g^{1-\nu},
\]
要求 \(\tau<(\lambda-\nu)/(1-\nu)\)。令 \(\nu\downarrow7/12\) 给 \((12\lambda-7)/5\)，因此必须保留严格 \(\beta<\tau<(\lambda-\nu)/(1-\nu)\)。另有 \(\tau<2\lambda-1\)、\(\tau<\lambda\)、\(\tau<1\) 的固定幂支付，这些均由上述更强边界可满足。固定层结论本身不包含这条增长量词；任何外推须重新使用 894 的统一估计。

## 894 (5a)、(5b) 的绝对尾

未发现绝对尾的计数缺口。理由如下。

对 \(g>G\ge2\)，纯素数或纯二倍素数端点均不能出现。剩余 \(b+z\) 有界。非零位移若 gcd 为 \(g\)，则 \(g\mid(n-m)\)，正窗口给 \(g\le2L\)。每层外端数量 \(O(M/g)\)，内端位移数量 \(O(L/g)\)；后者即使 \(g>L\) 仍成立，因为 \(g\le2L\)。于是
\[
\#\{(m,n):L<n-m\le2L,(m,n)=g\}\ll ML/g^2,
\]
按 \(g>G\) 求和并用 \(|K|\ll H\) 与归一化 \(M^{-2}\)，得 \(\ll HL/(MG)=(L/B)/G\)。若 \(G\ge2L\)，左侧直接为零。

对于例外高次素数幂端点 \(m\)，其除数数 \(\tau(m)\ll\log M\)。允许按 \(g\mid m\) 重复计数，每个 \(g>G\) 最多 \(O(L/g)\) 个窗口内端；总计 \(O(L\tau(m)/G)\)。将例外点数与 \(O(\log^2M)\) 系数乘积计入，得到
\[
\ll \frac{HL}{MG}M^{-1/2}\log^C M,
\]
可吸入绝对尾界。双方均例外也已经被这一过计数覆盖。

对整个硬窗口 \(0<|n-m|\le U=CB\log(2M)=o(M)\)，纯素数/二倍素数排除仍成立。此时给定 \(g\mid m\) 的非零位移数恰至多 \(2\lfloor U/g\rfloor\)，无须为零位移添加 \(+1\)，所以同一计数给 \(\ll HU/(MG)\)。设
\[
G_{\rm phys}=\left\lceil M\log^2(2M)/H^4\right\rceil.
\]
在允许 \(H\) 范围内 \(G_{\rm phys}>2\) 对充分大 \(M\) 一致成立，并且
\[
\frac{HU}{MG_{\rm phys}}\ll_C
\frac{H^4}{M\log(2M)}.
\]
这证明 (5b) 的尺度。该绝对计数不需要短和假设；其关键限制是高 gcd 阈值至少 2、位移 \(o(M)\)、排除零位移，以及核有统一 \(O(H)\) 界。均已满足。

## 未审边界

本报告仅判定所给固定层候选及 894 的绝对尾计数；未验证外部短和原文、892 的平方自由层定理、其余 note 的承重链、全距离 signed covariance、完整观察能量固定幂门、局部 Weil 正性或 RH。没有从正尾或 \(\sum C_g=0\) 推出这些结论。
