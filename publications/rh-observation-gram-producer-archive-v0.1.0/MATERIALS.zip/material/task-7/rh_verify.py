# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
#!/usr/bin/env python3
"""Finite exact diagnostics only: no asymptotic/RH certificate."""
from fractions import Fraction as F
from math import gcd, prod
import json, platform, time
start=time.perf_counter()
small_primes=(2,3,5,7)
Q=prod(small_primes)
crt=[]
for g in (1,2,3,4,6,9):
    total=sum((4-2*((g*u)%2==0))*(4-2*((g*v)%2==0))
              for u in range(Q) for v in range(Q) if gcd(gcd(u,v),Q)==1)
    observed=F(total,Q*Q)
    expected=(8*prod(F(p*p-1,p*p) for p in small_primes if p!=2)
              if g%2 else 4*prod(F(p*p-1,p*p) for p in small_primes))
    assert observed==expected,(g,observed,expected)
    crt.append({'g':g,'residue_modulus':Q,'primitive_background_mean':str(observed)})
# Compute mu independently from factorization; verify the restricted-mu convolution.
N=600
mu=[0]*(N+1);mu[1]=1
factors=[[] for _ in range(N+1)]
for n in range(2,N+1):
    t=n; square=False
    p=2
    while p*p<=t:
        if t%p==0:
            exponent=0
            while t%p==0:t//=p;exponent+=1
            factors[n].append(p);square |= exponent>1
        p+=1
    if t>1:factors[n].append(t)
    mu[n]=0 if square else (-1)**len(factors[n])
conv_cases=0
for n in range(1,N+1):
    divisors=[d for d in range(1,n+1) if n%d==0]
    for m in range(1,81):
        rhs=sum(mu[n//d] for d in divisors if all(m%p==0 for p in factors[d]))
        lhs=mu[n] if gcd(n,m)==1 else 0
        assert lhs==rhs,(m,n,lhs,rhs)
        conv_cases+=1
# Finite geometric exclusion for prime and doubled-prime endpoints.
M,U=500,150
prime=lambda n:n>=2 and mu[n]!=0 and len(factors[n])==1
# Extend only this finite factorization when needed.
def is_prime(n):return n>=2 and all(n%d for d in range(2,int(n**.5)+1))
geom_cases=0
for m in range(M+1,2*M):
    if is_prime(m) or (m%2==0 and is_prime(m//2)):
        for n in range(max(M+1,m-U),min(2*M,m+U+1)):
            if n!=m:
                assert gcd(m,n)<=2,(m,n)
                geom_cases+=1
# Formal constant conservation, coefficients in the basis (1,1/zeta(2)).
C1=(F(-12),F(32,3));C2=(F(3),F(1));tail=(F(9),F(-35,3))
assert tuple(C1[j]+C2[j]+tail[j] for j in (0,1))==(0,0)
prime_g1=F(16-4-4)+2*F(-12+2)
prime_g2=F(1)+2*F(1)
assert prime_g1==-12 and prime_g2==3
out={'python':platform.python_version(),'CRT_background_checks':crt,
     'restricted_mu_convolution_cases':conv_cases,'prime_support_exclusion_cases':geom_cases,
     'prime_constant_g1':str(prime_g1),'prime_constant_g2':str(prime_g2),
     'formal_constant_conservation':'PASS','all_checks':'PASS',
     'seconds':round(time.perf_counter()-start,3),
     'scope':'Exact finite algebra and support diagnostics; proves no infinite signed estimate or RH.'}
print(json.dumps(out,indent=2))
