> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# RH / local Weil 第二有界轮检查点

2026-10-03。原库继续只读，所有新结果在task-7。前轮原始c固定层符号保留；本轮完成原始全gcd层可和余项的单个有限命题，已停在检查点。

## 改变的数学判断

不再只有“每个固定g成立，但不能交换无穷求和”。条件于μ与Λ−1普通短和S，现已独立推导并通过同模型新上下文审查：

Σ_(g≥1)|Tg−Cg Iψ J_M(L)| ≪ (L/B)exp(−c V_M)，

对固定η、M^(3/5)≤L≤B/64、允许H和全部物理g一致。包括g>2L真实配对为空的形式主项尾。因此ΣgCg=0可以合法应用到实际全层和，给|ΣgTg|≪(L/B)exp(−c V_M)。

重要机制：不用每层相对误差的最大值；以真实外端计数M/g和核归一化保持g^-2权，剩余三种幂项分别落在g^(-1−ν)、g^(-3/2)、g^(-63/32)的可和级数。最末层X=M/g仍≥32H≳M^(1/5)，最小卷积基点≥M^(7/40)，而导体m≤2M以Eσ(m)≤CεMε统一处理。背景内外取整误差和稀疏素数幂均在全层绝对和中支付，未偷换固定g量词。

## 文献输入状态

已读Matomäki–Teräväinen原始作者论文的arXiv v2与EMS发表PDF，§2.1明确陈述θ>7/12的μ次指数短和，以及素数定理相似误差。短前缀由选θ<ν和平凡xθlogx≪xν补齐，得到所需Sν。严格区分该旧输入和其Theorem1.1的θ>0.55、仅对数节省新结果；卷积生长导体不是作者定理自带，而是本轮证明。

Ramachandra1976原扫描件仍未取得。相关library记录metadata-only；curl返回`(6) Could not resolve host: www.impan.pl`，公开下载端web随后返回`403 Forbidden`，已停止该端访问。没有用其他登录/账户/服务绕过403，未读取凭据。不能声称独立核过其Main Theorem或Remark4全函数类。足够的普通μ和Λ输入现在有实际阅读的原始作者文献支撑，正式命题仍保留S假设以可审计。

具体来源、页码、访问结果见rh-round2-source-audit.json。共享ResearchLibrary未写入，版权PDF不属于贡献候选包。

## 失败与异议边界

- 全层可和余项不是比已有ordinary短和更强的速率；完整正窗口的次指数界此前可用直接短和得到。本轮新增的是合法的全gcd绝对误差/任意子集控制，补足量词接口，不宣称全窗口界首次出现。
- 同模型新上下文审查 conditional ACCEPT；其独立证明确认增长导体、最末层、短于1前缀、bb全层误差和形式尾；它未核外部文献原文，不构成异源审查。
- 若只保留μ输入，不能认证g1、2的素数主项；必须保留S的Λ−1部分。审查的这一量词提醒已纳入定稿。
- 对H≍M^(1/5)、L=M^(3/5+δ)，目标H⁴/M≈M^(-1/5)，现界的比率M^δ exp(−c V_M)不能给固定幂目标。此为所给上界不够强的明确判据，不是实际余项下界或其他方法不可能定理。
- 任意增长G的相对正高尾o((L/B)/G)仍不是全层绝对误差自动给出的；原894的独立β门必须保留。
- 固定η外的可变权族、非正核位移、全频带能量、全尺度Weil正性与RH均未判定。

## 交付与复现

- 自足数学稿：rh-round2-summable-gcd-remainder.md。
- 独立审查：rh-round2-independent-review.md。
- 标准库验证：`python3 rh_round2_verify.py`，Python3.14.7；分数幂次裕量、级数包络、缩放基点、常数守恒与目标差距全部PASS，输出rh-round2-verifier-result.json。它们是有限代数检查，不替代解析证明或外部定理。
- 对统一贡献任务的文件和SHA256清单：rh-round2-contribution-manifest.json。

公开候选是自足稿+轻量代码+结果+审查；保留条件性输入、同模型局限、先例与署名/许可未定项。没有push、PR、签名key、DOI、Zenodo归档或外部发布；统一贡献任务负责后续许可与提交。重要发现已向父报告，不并行发布。

## 接续与停止

本轮有限命题已完成。没有活跃计算、后台程序或待归档操作。最便宜下一义务不是再列gcd常数，而是提出一个明确、可被现有文献或反例检验的Λ/μ联合带限估计，能改善本稿(5)的次指数项。若只重复ordinary短和、固定g极限或Euler常数，固定幂目标仍不改变，不应继续。

原库抽样指纹与git只读状态见rh-round2-start-snapshot.local.json及rh-round2-final-snapshot.local.json。进程归属仍沿第一轮ps拒绝记录保持UNKNOWN；本轮没有重复探测、抢锁或原库写入。

PULSE=SUMMABLE_GCD_REMAINDER VERDICT=CONDITIONAL_ACCEPT SCOPE=FIXED_ETA_POSITIVE_WINDOW
