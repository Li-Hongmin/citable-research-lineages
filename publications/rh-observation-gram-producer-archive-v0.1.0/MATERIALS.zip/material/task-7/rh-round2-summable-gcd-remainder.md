> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# All-gcd summable remainder for the original two-endpoint coefficient

2026-10-03. Local review draft, with explicit short-sum input. No RH claim, novelty claim or publication authorization. Fixed observation weight only. This supersedes the first pulse's warning that fixed-g asymptotics alone were insufficient for infinite summation: the argument below proves a separate uniform ℓ¹ estimate before summing.

## 1. Literature input and exact scope

The publisher record is K. Matomäki and J. Teräväinen, *On the Möbius function in all short intervals*, J. Eur. Math. Soc. 25 (2023), no.4, 1207–1225, DOI 10.4171/JEMS/1205; first online publication 29 January 2022. The publisher's original PDF, §2.1, manuscript p.5, directly states the older subexponential Möbius estimate for intervals of length h≥x^θ, θ>7/12, and the analogous prime-number-theorem error. Its Theorem 1.1 instead gives a logarithmic saving at θ>0.55; the two estimates must not be conflated.

Sources actually read this pulse:

- Published author article and metadata: https://ems.press/journals/jems/articles/4411198
- Published original PDF, §2.1, manuscript p.5: https://ems.press/content/serial-article-files/32825
- Author preprint v2, §2.1, p.4, same statement: https://arxiv.org/html/1911.09076v2

The 1976 Ramachandra original scan was **not** retrieved: cached library record is metadata-only, the publisher download endpoint returned HTTP403, and local curl failed DNS resolution. No access-control workaround was attempted. Therefore the full function class, Main Theorem and Remark4 of the 1976 paper are not independently audited here. The sufficient ordinary μ and Λ−1 input is grounded in the actual author article above, rather than a project note's prior-audit label.

Write V_x=(log x/loglog x)^(1/3). The literature statement used is, for each fixed θ>7/12 and all sufficiently large x, uniformly for x^θ≤h≤x,

|Σ_(x<n≤x+h) μ(n)| + |Σ_(x<n≤x+h)(Λ(n)-1)| ≪_θ h exp(-cθ V_x).

For every fixed ν>7/12, choose θ∈(7/12,ν). If h<x^θ, the elementary coefficient bounds give O(x^θ log x)=O_ν(x^ν). Combining the two regimes proves the **derived full-prefix input Sν**:

|Σ_(x<n≤x+h) μ(n)| + |Σ_(x<n≤x+h)(Λ(n)-1)|
≪_ν h exp(-cν V_x)+x^ν,  0≤h≤x.                       (S)

Real endpoints cause only O(log x) corrections, absorbed in x^ν. Intervals with base comparable to x are covered by changing constants. Negative physical displacements are intervals with an earlier base, also comparable to x. No twisted Möbius theorem, growing-conductor theorem, or RH is assumed. The growing conductor below is dealt with by an exact elementary convolution.

The formal proposition retains S as an explicit hypothesis, so its mathematical dependence remains auditable even if the cited source is later challenged.

## 2. Objects and proposition

Along integers Y→∞, set M=2Y, Y^(1/5)≤H≤Y^(1/4), B=M/H. Fix ψ∈C_c^3((1,2);C), f(v)=ψ(v)/v, Iψ=∫_1^2|f(v)|²dv. Fix nonnegative even η∈C_c^∞ supported where 1/2≤|t|≤4, with η≥1 on 1≤|t|≤2. Put

K(k)=Σ_(h∈Z)η(h/H) exp(-2πihk/M),
J(L)=∫_(L/B)^(2L/B)η̂(t)dt,
c(m)=2·1_(2|m)(Λ(m/2)-1)-4(Λ(m)-1+(log2)μ(m)),
a_m=1_(M<m<2M)c(m)f(m/M)/M.

Take any integer M^(3/5)≤L≤B/64. Let

T_g=Σ_(L<n-m≤2L, gcd(m,n)=g)a_m conjugate(a_n)K(m-n).

Directly from the finite Fourier sum, |K|≪H and |K′|≪H²/M. Thus the supremum plus variation of f(n/M)K(m−n) on a length-L interval is O(H). Poisson summation gives ∫_L^(2L)K(−t)dt=MJ(L)+O_A(LH^(1−A)); the nonzero aliases are uniformly away from zero since 2L=o(M). Also J(L)≍L/B>0: on 0≤t≤1/32, |u|≤4 implies cos(2πut)≥cos(π/4), and η is nonnegative with a fixed positive platform.

Set T_g=0 where no physical pair exists, in particular g>2L. Define

C1=32/(3ζ(2))-12, C2=1/ζ(2)+3,
C_g=32/(3ζ(2)g²) for odd g≥3,
C_g=4/(ζ(2)g²) for even g≥4.

**Proposition (conditional on S).** There is c>0, depending only on the fixed input constants and ψ,η, such that all permitted H,L and all sufficiently large M satisfy

Σ_(g≥1)|T_g-C_g Iψ J(L)| ≪_(ψ,η) (L/B)exp(-c V_M).     (1)

Consequently every subset A of the positive integers, even one depending on M,H,L, satisfies

|Σ_(g∈A)T_g-IψJ(L)Σ_(g∈A)C_g| ≪(L/B)exp(-c V_M).     (2)

Because Σ_gC_g=0, the complete positive displacement window obeys

|Σ_gT_g| ≪(L/B)exp(-c V_M).                            (3)

A different estimate is needed for a relative error o((L/B)/G) when G grows as a fixed power. Equation (1) provides an absolute error independent of the chosen subset; it does not silently replace the stronger relative growth-tail statement in the original note894.

## 3. Uniform coprime Möbius prefix bound

For an active physical gcd g, g≤2L≤C M^(4/5), hence X=M/g≥c M^(1/5). Fix an outer physical integer m=gu≤2M. If g is not squarefree, μ(gv)=0. Otherwise exact gcd implies

μ(gv)1_((u,v)=1)=μ(g)μ(v)1_((v,m)=1).

Define A_m(q)=1 if all prime divisors of q divide m and 0 otherwise. The exact identity

μ(v)1_((v,m)=1)=(μ*A_m)(v)

follows prime by prime. For any fixed 0<σ<1,

Eσ(m)=Σ_q A_m(q)q^(-σ)=∏_(p|m)(1-p^(-σ))^(-1)≤C_(σ,ε)M^ε;
E1(m)≪log^C M,

uniformly for m≤2M, for every fixed ε>0. To justify this without a conductor theorem, split p≤log M and p>log M. The small-prime logarithmic sum is Oσ((log M)^(1−σ)); the number of larger prime divisors is at most log(2M)/loglog M. Thus log Eσ=o(log M). The same argument at σ=1 gives a power of log M. In particular m/X≈g is allowed to grow; it is not absorbed in a fixed-g implicit constant.

For any inner prefix interval I at location ≍X, length at most 2L/g, split the convolution at q=X^(1/8). For q≤X^(1/8), the base of the ordinary μ sum is ≥c X^(7/8)≥c M^(7/40), so its V is bounded below by a fixed positive multiple of V_M. Apply S to get

Σ_(q≤X^(1/8)) A_m(q)|Σ_(v∈I/q)μ(v)|
≪(L/g)exp(-c0V_M)E1(m)+X^ν Eν(m).

A subunit interval has at most one integer; its O(1) contribution is absorbed in the X^ν term or the supported-divisor count below. The remaining q satisfy q≤C X whenever they contribute. Their trivial interval count and Rankin bounds give

Σ_(q>X^(1/8)) A_m(q)(L/(gq)+1)
≪(L/g)X^(-1/32)E_(3/4)(m)+X^(1/2)E_(1/2)(m).

Thus uniformly in all active g and m,

R_g := sup_prefix |Σ_(n∈Iphysical, gcd(m,n)=g)μ(n)|
≪(L/g)exp(-c0V_M)log^C M
  +(M/g)^ν M^ε +(M/g)^(1/2)M^ε
  +(L/g)(M/g)^(-1/32)M^ε.                              (4)

Intervals to the left of the fixed endpoint obey the same estimate. This is a bound, not a pointwise asymptotic claiming that its right side is smaller than L/g for every large g.

## 4. Summing all Möbius-layer errors

Write c=b+P_o+P_e+D+E, where

b(m)=4-2·1_(2|m), D(m)=-4(log2)μ(m),
P_o(m)=-4·1_(m=p)log p, P_e(m)=2·1_(m=2p)log p,
E(m)=2·1_(2|m)P2(m/2)-4P2(m), P2(n)=Λ(n)-1_(n=p)log n.

For g>2 pure-prime and doubled-prime endpoints cannot occur: a different multiple sharing the large prime would be ≍M away, whereas 2L=o(M). All remaining b,D coefficients are bounded. There are O(M/g) outer endpoints, and the inner weight has supremum plus variation Oψ,η(H). Putting a Möbius endpoint inside and using (4), its absolute layer contribution is at most

(H/M²)(M/g)R_g.

Both directions are covered by choosing the opposite endpoint inside; D–D is counted at most twice. For g=1,2 a pure-prime outer endpoint has total absolute mass O(M) by Chebyshev, so these two finite layers satisfy the same estimate with an absolute enlarged constant. Summing all active g, relative to HL/M=L/B, gives

≪ exp(-c0V_M)log^C M
 + (M^(ν+ε)/L)Σ_(g≥1)g^(-1−ν)
 + (M^(1/2+ε)/L)Σ_(g≥1)g^(-3/2)
 + M^(-1/32+ε)Σ_(g≥1)g^(-63/32).                       (5)

All three series converge. Choose ν=59/100 and ε=1/1000, then L≥M^(3/5) makes the three power errors at most M^(-9/1000), M^(-99/1000), M^(-121/4000). Polylogarithms are absorbed by decreasing c0. Hence the sum of the absolute **Möbius-layer errors**, over all g, is O((L/B)exp(-c1V_M)). No fixed-g O_g estimate was summed; the weighted error was first proved uniformly.

## 5. Summing all background-layer errors

Put d_g=32/(3ζ(2)) for odd g and d_g=4/ζ(2) for even g. With m=gu,n=gv, the primitive inner background count is

Σ_(v∈I,(u,v)=1)b(gv)=r_g(u)|I|+O(τ(2u)),

r_g(u)=2φ(u)/u (g even), 4φ(u)/u (g odd,u even), 3φ(u)/u (g,u odd).

The odd/even sums of φ(u)/u have main densities 2/(3ζ(2)), 1/(3ζ(2)) and errors O(log(2x)); therefore the weighted outer average of b(gu)r_g(u) is d_g M Iψ/g+Oψ(log(2M/g)). The error constants are uniform in g, because only its parity enters these formulas.

For each active g, the four background errors after normalization are bounded by

H/(Mg) log(2M/g)                         [inner τ count],
HL/(M²g) log(2M/g)                      [outer rounding],
HL²/(M²g²)                             [freezing f],
(HL/M)H^(-A)/g²                        [Poisson aliases].

Here Σ_(u≤C M/g)τ(2u)≪(M/g)log(2M/g), and |f|² has uniformly bounded variation after scaling, so no growing-g constant is hidden. On summing g≤2L, these errors are at most

(L/B)[log² M/L + log² M/M + L/M + H^(-A)].               (6)

For g>2L there is no physical pair, but the formal background main terms have total size O((L/B)/L), since Σ_(g>2L)g^(-2)≪1/L. Include this tail before claiming an all-g result. All terms in (6) and this tail have fixed power savings in the allowed range, and hence are O((L/B)exp(-c2V_M)).

## 6. Prime terms, sparse errors, and conservation

All prime-related contributions lie in g=1,2. With physical density of P_o equal to−4, of P_e equal to+1, background density 3 overall, 2 at odd locations and 1 at even locations, the ordered prime corrections are:

g=1: (16−4−4)+2(−12+2)=−12;
g=2: 1+1+1=+3.

S for Λ−1, ordinary prime-power removal, Abel summation and the same kernel integral give these fixed two layers with error O((L/B)exp(-c3V_M)). Their derivation uses the Λ part of S, not just its μ part.

The support of E has O(√M log M) points; all coefficients are O(log M). Each exceptional endpoint has O(L) nearby partners. Absolute summation of all exceptional pairs, then partition into physical gcd layers, gives

Σ_g |T_(with E,g)| ≤ Σ_(all exceptional pairs)|summand|
≪(L/B)M^(-1/2)log^C M.

Combining (5), (6), both prime layers and the absent-pair formal tail proves (1).

Finally, the absolutely convergent main coefficients obey

Σ_(g odd) d_g/g²=8, Σ_(g even) d_g/g²=1,
Σ_g C_g=8+1−12+3=0.

The new ℓ¹ bound now justifies summing the actual layers and subtracting these constants, giving (2)–(3). It also permits arbitrary selected gcd subsets; it does not prove a sharper relative high-tail asymptotic at a polynomial cutoff.

## 7. Precise route limitation

At H≍M^(1/5), the target scale is H⁴/M≍M^(-1/5). If L=M^(3/5+δ), 0<δ<1/5, then L/B≍M^(-1/5+δ). Our certified bound (3), divided by the target, is O(M^δ exp(-cV_M)), which is not a bounded function as M→∞. Relative to a target M^(-1/5+ε) it is insufficient whenever ε<δ. This compares **bounds**; it is not a lower bound on the actual signed remainder or a mathematical impossibility theorem for other methods.

At L≍M^(3/5) the positive window is paid with a subexponential surplus. Summing dyadic displacement windows up to B by this estimate only gives O(exp(-cV_M)) because their lengths form a geometric sum ≍B. It therefore does not certify the fixed-power interior H=M^(1/4−θ), θ>0. No claim is made about windows outside the stated positive-kernel collar, about the full observation energy, or about all-scale local Weil positivity.

The decisive remaining interface is cancellation stronger than the ordinary short-sum exponential term in (5), after keeping Λ/μ cross terms. More gcd constants or finite numerical PASS checks cannot remove this bottleneck.

## 8. Reproduction, review and version boundary

Run `python3 rh_round2_verify.py` (Python3.14.7, standard library). The result rh-round2-verifier-result.json checks rational exponent margins, three convergent-series envelopes, the minimum scaled base M^(7/40), constant conservation and the fixed-power gap. These finite checks are not a proof of S or of (1); the proof above is analytic.

Independent fresh-context same-model review is rh-round2-independent-review.md. It independently checks the uniform conductor handling, large-g background errors and all-g absolute summation. Same-model shared errors remain possible; no heterogeneous ACCEPT is claimed.

This is an internal local candidate for the separately authorized unified contribution task. Source PDFs are not part of a proposed public package; citation metadata, this self-contained result, code and review are sufficient. No push, PR, signing key, DOI or external publication was performed here. Novelty, author attribution and licensing remain for the unified contribution task.
