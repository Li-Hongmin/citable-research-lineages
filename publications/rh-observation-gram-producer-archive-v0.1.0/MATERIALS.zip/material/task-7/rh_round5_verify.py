# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
#!/usr/bin/env python3
"""Small true-arithmetic Fejer identities. Not an asymptotic H5 test."""
import json
import math
import platform
from pathlib import Path

import numpy as np


def arithmetic(limit):
    mu = np.ones(limit + 1, dtype=np.int64)
    mu[0] = 0
    prime = np.ones(limit + 1, dtype=bool)
    prime[:2] = False
    lam = np.zeros(limit + 1)
    for p in range(2, limit + 1):
        if not prime[p]:
            continue
        prime[2*p::p] = False
        mu[p::p] *= -1
        if p*p <= limit:
            mu[p*p::p*p] = 0
        power = p
        while power <= limit:
            lam[power] = math.log(p)
            power *= p
    return mu, lam, prime


def smooth_step(s):
    if s <= 0:
        return 0.0
    if s >= 1:
        return 1.0
    a, b = math.exp(-1/s), math.exp(-1/(1-s))
    return a/(a+b)


def case(m, hscale, k):
    # K is deliberately finite and below the support margin; it is not
    # ceil((M/H)M^gamma). These examples audit identities, not the asymptotic rate.
    assert k < 0.2*m
    assert (m/2)**0.2 <= hscale <= (m/2)**0.25
    limit = 2*m - 1
    mu, lam, prime = arithmetic(limit)
    conv = np.zeros(limit + 1)
    for d in range(1, limit + 1):
        for cofactor in range(2, limit//d + 1):
            conv[d*cofactor] += mu[d] * math.log(cofactor)
    convolution_error = float(np.max(np.abs(conv[1:] - lam[1:])))

    ell = math.log(2)
    ns = np.arange(m, 2*m)
    phi = np.zeros(m)
    for x, n in enumerate(ns):
        v = n/m
        y = (v-1.5)/0.28
        phi[x] = math.exp(-1/(1-y*y))/v if abs(y) < 1 else 0
    b = 4 - 2*(ns % 2 == 0)
    c = 2*(ns % 2 == 0)*(lam[ns//2]-1) - 4*(lam[ns]-1+ell*mu[ns])
    dlist = np.arange(1, limit//3+1)
    source_coeff = np.zeros((len(dlist), m))
    for i, d in enumerate(dlist):
        for x, n in enumerate(ns):
            if n % d == 0 and n//d >= 3:
                t = n//d
                source_coeff[i, x] = (-4+2*(t % 2 == 0))*math.log(t/2)
    reconstructed_c = b + mu[dlist] @ source_coeff
    coefficient_error = float(np.max(np.abs(c-reconstructed_c)))
    vectors = source_coeff * phi[None, :] / m
    a = c*phi/m
    b_phi = b*phi/m
    full_source_error = float(np.max(np.abs(a-b_phi-mu[dlist]@vectors)))

    centered = np.arange(m)
    centered = np.where(centered <= m//2, centered, centered-m)
    f = np.array([smooth_step(2*abs(h)/hscale-1)*
                  smooth_step((4-abs(h)/hscale)/2) for h in centered])
    invf = np.fft.ifft(f)
    q = np.zeros(m, dtype=complex)
    for j in range(-k+1, k):
        q[j % m] = (1-abs(j)/k)*invf[j % m]
    qhat = np.fft.fft(q)
    kernel = np.array([abs(sum(np.exp(2j*np.pi*r*j/m)
                               for r in range(k)))**2/k for j in range(m)])
    predicted_qhat = np.array([sum(f[j]*kernel[(j-h)%m]
                                   for j in range(m))/m for h in range(m)])
    fejer_error = float(np.max(np.abs(qhat-predicted_qhat)))

    dcut = m//(16*hscale)
    hi = dlist > dcut
    vhi, muhi = vectors[hi], mu[dlist[hi]]
    ahi = muhi @ vhi
    r = a-ahi
    r_from_low = b_phi + mu[dlist[~hi]] @ vectors[~hi]
    low_source_error = float(np.max(np.abs(r-r_from_low)))
    filtered_sources = np.fft.ifft(np.fft.fft(vhi, axis=1)*qhat[None, :], axis=1)
    gram = m*filtered_sources @ filtered_sources.conj().T
    diag = float(np.sum(muhi**2 * np.diag(gram).real))
    signed = float((muhi @ gram @ muhi).real)
    offdiag = float(np.sum(gram*muhi[:, None]*muhi[None, :]).real - diag)
    filtered_hi = np.fft.ifft(np.fft.fft(ahi)*qhat)
    spatial_energy = float(m*np.sum(np.abs(filtered_hi)**2))
    spectral_energy = float(np.sum(np.abs(np.fft.fft(ahi)*qhat)**2))
    exact_band_energy = float(np.sum(f**2*np.abs(np.fft.fft(ahi))**2))
    # This bound is exact for every finite q/f pair, independent of asymptotics.
    eps = float(np.max(np.abs(qhat-f)))
    diag_band = float(np.sum(f[None, :]**2 *
                            np.abs(np.fft.fft(vhi, axis=1))**2 * muhi[:, None]**2))
    diag_transfer_rhs = 2*diag_band + 2*eps**2*m*float(np.sum(np.abs(vhi)**2))

    # Same-model Lambda perturbation destroys the identity while retaining mu.
    bad_n = next(int(n) for x, n in enumerate(ns) if phi[x] > 0 and lam[n] == 0)
    altered_lam = lam.copy()
    rho = 0.03125
    altered_lam[bad_n] += rho
    altered_c = 2*(ns % 2 == 0)*(altered_lam[ns//2]-1)-4*(altered_lam[ns]-1+ell*mu[ns])
    altered_identity_error = float(np.max(np.abs(altered_c-reconstructed_c)))
    altered_convolution_error = float(np.max(np.abs(altered_lam-conv)))

    # Audit the exact common-factor sign condition over all high source pairs.
    sign_failures = 0
    for d in dlist[hi]:
        for e in dlist[hi]:
            g = math.gcd(int(d), int(e))
            u, v = int(d)//g, int(e)//g
            # mu(uv) can be computed as mu(u)*mu(v), because gcd(u,v)=1.
            expected = int(mu[u]*mu[v]*mu[g]**2)*(math.gcd(g,u*v) == 1)
            if mu[d]*mu[e] != expected:
                sign_failures += 1

    errors = dict(convolution=convolution_error, cofactor_identity=coefficient_error,
                  full_source_reconstruction=full_source_error, low_source_reconstruction=low_source_error,
                  fejer_multiplier=fejer_error, hermitian=float(np.max(np.abs(gram-gram.conj().T))),
                  source_vs_spatial=abs(signed-spatial_energy), spatial_vs_spectral=abs(spatial_energy-spectral_energy),
                  diagonal_decomposition=abs(signed-diag-offdiag))
    assert max(errors.values()) < 1e-10
    assert diag <= diag_transfer_rhs + 1e-10
    assert signed >= -1e-10 and offdiag >= -diag-1e-10
    assert abs(altered_identity_error - 4*rho) < 1e-10
    assert abs(altered_convolution_error - rho) < 1e-10
    assert sign_failures == 0
    return dict(M=m, H=hscale, K=k, D=dcut, high_source_count=int(np.sum(hi)),
                identity_residuals=errors, true_high_source_band_energy=exact_band_energy,
                localized_true_high_source_energy=signed, localized_source_diagonal=diag,
                localized_signed_offdiagonal=offdiag, diagonal_transfer_rhs=diag_transfer_rhs,
                perturbed_nonprimepower_n=bad_n, perturbation=rho,
                perturbed_identity_residual=altered_identity_error,
                perturbed_convolution_residual=altered_convolution_error,
                common_factor_sign_failures=sign_failures, verdict="PASS")


result = dict(python=platform.python_version(), numpy=np.__version__,
              scope="Bounded finite true-arithmetic algebra diagnostics; K below support margin, not asymptotic pulse3 K. No H5 proof or rate test.",
              cases=[case(256, 3, 20), case(512, 4, 40)], overall="PASS")
Path(__file__).with_name('rh-round5-verifier-result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
