> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Historical RH mathematical handover projection

## 审计证据分级

|范围|本轮判断|边界|
|---|---|---|
|849(10)–(11)原始c定义、两尺度换元|直接代数核对成立|不复核整条RH等价链或所有观察误差|
|894(7)、高次素数幂支撑、g>2素数排除|直接核对成立|位移必须o(M)，排除零位移|
|894(9)–(12)奇偶互素背景计数|无条件初等证明核对成立|固定g本文完整推导；不是增长g全部误差晋级|
|894(5a)、(5b)|本轮主推导与独立新上下文审查未发现计数缺口|固定η完整；可变权只用其统一核界，不认证888全部远尾|
|894(5)–(6)高g增长渐近|条件于851短和输入；参数门与证明形状相容|不是本轮异源ACCEPT；统一卷积全部工程/原文未重新认证|
|892平方自由w层|局部Euler因子和奇偶密度代数相容；仍为旧证明草案|未重审885全部计数链；不能将w逐层符号用于c|
|893(2)⇒(3)、Dirichlet级数与非零留数|已沿869路径分摊独立核对其条件性逻辑|893(2)未证；Zaccagnini原文和(4)定量未在本轮核验|
|851外部短和S|原笔记报告已核原扫描件及异源复核|本轮DOI访问失败；此轮只作为明示外部输入|
|完整signed中距离固定幂门、局部Weil全尺度、RH|未解|本轮常数守恒和正尾均不提供目标界|

没有发现需要推翻894核心公式的确定错误。发现并闭合的是旧收尾时尚未落盘的前两gcd候选推导；明确否定的外推是“原始c继承w的gcd=2负主项”和“固定层求和恒等式自动证明完整固定幂能量”。它们不应描述为原笔记已正式声称的错误。

外部原文访问：`https://doi.org/10.4064/aa-31-4-313-324` 与 `https://doi.org/10.4171/JEMS/1205` 的web open均返回URL not accessible via this tool。搜索没有取得可用原文；没有据无关搜索结果作数学或新颖性判断。

## 本轮实质结果

详细对象、假设、证明及复现见 **rh-original-c-fixed-gcd-draft.md**。在固定η、正核窗口 M^(3/5)≤L≤B/64、原始c、每个固定物理gcd g上，条件于851(4)所陈述的全起点/全前缀短和S，

T_g = C_g Iψ J_M(L)+O_g((L/B)exp(-c_g V_M)),

C1=32/(3ζ(2))-12<0；C2=1/ζ(2)+3>0；
C_g=32/(3ζ(2)g²) (奇g≥3)，C_g=4/(ζ(2)g²) (偶g≥4)。

决定常数的薄弱接口已经展开：g1素数–素数为8，素数–背景两方向合计-20；g2二倍素数–二倍素数为1，二倍素数–偶背景两方向各1，合计+3。背景层仅靠初等互素计数。所有μ端点的无主项仍依赖S及互素卷积，不能省略。

主系数级数严格绝对收敛且Σ_g C_g=0。对每个固定G≥2，Σ_(g≤G)C_g=-D(G)<0，D(G)=22/(3ζ(2)G)+O(G^-2)。g≥2的层全为正，负主项只在g1。非平方自由g的原始背景层也非零，例如g4=1/(4ζ(2))。

复现：`python3 rh_verify.py`，Python3.14.7，无第三方依赖，0.079秒；模210的六个CRT密度检查、48000个限制μ卷积、29256个素数几何排除、常数守恒全部PASS，结果rh_verify_result.json。有限PASS只检测代数/支撑，不证明渐近或S。

独立审查：rh-fresh-review.md来自fresh-context review的新上下文代理，确认固定层候选和894绝对尾计数；使用同模型，非异源检查，有共同误差风险。该代理未读892或验证外部原文，报告明确保留此边界。

## 下一步与停止点

本轮有限命题已得到“条件于S成立”的证明，并以g2正符号排除不合法逐层替换。停止在此，不顺手开更多gcd格或新HPC/SAT任务。没有本轮未完成计算或后台命令。

父接续的最便宜两道观察：

1. 若要晋级该短稿：由独立验证者核Ramachandra原版Main Theorem/Remark4对μ和Λ-1、所有前缀的精确量词，再对本稿作异源审查。缺少该输入时保留“条件于S”，不能正式标无条件。
2. 若要继续研究主门：保留已求出的背景项和Λ/μ通道交叉，在一个明确带限余项上判定所拟固定幂估计。不要继续把Euler常数列全当作算术推进；固定g的O_g常数不足以控制g增长至Gphys。

原强增长截断门为β<(12λ-7)/5；在最短λ=3/5窗口仅允许β<1/25，而H≍M^(1/5)的硬窗口绝对阈值Gphys≍M^(1/5)log²M。两者之间仍有真实统一短和范围缺口，不能由固定层守恒填平；绝对高尾支付与signed核心必须区分。

## Research Commons最小候选

见rh-commons-minimal-candidate.md：仅准备无条件奇偶互素背景密度、常数守恒、限定的条件性符号边界和轻量 verifier。待补作者/贡献署名、所有者许可、外部输入核验、异源审查、最接近先例判断及Commons实际收录条件。未找到相关根路径的LICENSE文件，不推定允许公开；未上传私稿、签名key、DOI、外部发布、账户/凭据或付费操作。CRL公开试点仍由父裁定。

PULSE=ORIGINAL_C_FIXED_GCD VERDICT=CONDITIONAL_PROOF CHECKPOINT=LOCAL_DRAFT_ONLY
