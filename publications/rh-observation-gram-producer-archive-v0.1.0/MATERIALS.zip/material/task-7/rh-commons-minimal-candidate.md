> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 待许可、待核验的最小贡献候选：奇偶背景的精确 gcd 密度

本文件是可能公开内容的候选，不是已提交的Research Commons记录。原项目私稿、编号路径、会话信息与全部历史草稿不属于拟公开包。

数学对象：b(n)=4-2·1_(2|n)。对每个固定g，取primitive variables (u,v)=1，对b(gu)b(gv)作两个变量的平滑平均。两物理变量的缩放各付一个1/g；无条件主密度为

D_g=32/(3ζ(2)g²) (g奇)，D_g=4/(ζ(2)g²) (g偶)。

最短证明：对固定u，内端b(gv)的互素平均在g偶时为2φ(u)/u；g奇u偶时为4φ(u)/u；g和u都奇时为3φ(u)/u。φ(u)/u在奇u与偶u上的每整数平均分别为2/(3ζ(2))、1/(3ζ(2))。乘外端b(gu)得到奇g的32/(3ζ(2))与偶g的4/ζ(2)，再乘g^-2。容斥取整误差O(τ(2u))和外端O(log x)给固定g的有效平滑平均证明；不是依赖“局部独立”的启发式。其总密度Σ_gD_g=9。

应用边界（**条件性附注**，发布前须核外部短和）：对原始两端点系数c(n)=2·1_(2|n)(Λ(n/2)-1)-4(Λ(n)-1+(log2)μ(n))，在固定正核短位移窗口中，素数相关修正集中为g1的-12与g2的+3，因而总常数为0而g2层为正。固定层符号不能从平方自由Fourier近似逐层移植。该附注不主张RH、任何无限signed能量固定幂界或新颖性。

拟交付最小包：一份自包含密度证明、标准库Python有限有理CRT/卷积/支撑检查及其结果。已有task-7本地草稿和verifier可作为待整理源，不能将有限PASS当成无限数论证明。最接近先例尚未检索；此背景计数可能只是常见初等结果，收录价值待判断。

发布前缺项：

- 人类作者/数学责任人、署名形式、AI辅助与独立同模型复核的贡献说明均待确认；不得把环境用户名自动作为正式作者身份。
- 所有权与文字/代码许可待确认；相关根路径未见LICENSE，不能推定默许公开。
- 条件性附注的Ramachandra原文量词核验与异源审查未完成；若无法核验，只公开无条件密度部分或保留假设标注。
- 精确误差量词、可复现版本固定及最接近先例比较待独立验收。
- Public AI Research Commons的实际平台、收录格式、验证与许可要求由父查证；本任务没有独立核其当前条件。

本任务未上传、签名、创建key、申请DOI或发布。CRL公开试点由父协调，不能据此文件自动启动发布。
