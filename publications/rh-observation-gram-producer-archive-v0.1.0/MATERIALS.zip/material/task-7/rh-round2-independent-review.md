> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 第二轮独立审查：原始 c 的全物理 gcd 层绝对误差

2026-10-03。独立新上下文、同模型审查；不是异源复核。只读了 `rh-original-c-fixed-gcd-draft.md` 与原项目 note 894；只写本文件。没有 Git 操作、进程检查或管理、外部调用、数值重计算，也没有修改原项目。

## 判定与精确条件

**判定：成立，但必须明确保留草案的双通道短和输入，并写出下面的统一求和证明；不能由固定 g 命题直接外推。** 固定 ψ、η 及固定 ν∈(7/12,3/5)，假设草案 S 的 μ 与 Λ−1 两个全前缀估计。允许前缀长度至 Cx 的版本也足够；原 u≤x 版本在本窗口的实际调用中已经足够。还使用 m≤2M 上一致的 Eσ(m)≤Cσ,ε M^ε（每个固定 σ∈(0,1)、ε>0）及 E1(m)≪log^C(2M)。

这里 Eσ(m)=∏_{p|m}(1−p^(−σ))^(−1)，是完整 m-光滑数级数，而不是只对 m 的平方自由除数求和。若仅假设普通 μ 短和，则下文能证明全部 μ 通道的统一界及高层背景结论；g=1,2 的素数主项仍须草案 S 的 Λ−1 部分，不能省略。

沿 M=2Y→∞，Y^(1/5)≤H≤Y^(1/4)，B=M/H，M^(3/5)≤L≤B/64，在窗口非空时存在固定 c′>0，全部允许 H,L 一致满足

\[
\sum_{g\ge1}\left|T_g(L)-C_g I_\psi J(L)\right|
\ll_{\psi,\eta,\nu}\frac LB e^{-c'V_M},
\qquad V_M=(\log M/\log\log M)^{1/3},
\]

其中 C1=32/(3ζ(2))−12，C2=1/ζ(2)+3；奇 g≥3 时 Cg=32/(3ζ(2)g²)，偶 g≥4 时 Cg=4/(ζ(2)g²)。对 g>2L，真实 Tg 精确为零，仍需支付形式主项尾。

## 1. 实际 gcd 范围及统一基点

非零配对有 g|(n−m)，故 1≤g≤2L。令 X=M/g，则

\[
X\ge M/(2L)\ge32H\gg M^{1/5}.
\]

因此没有 X 有界的隐蔽终端层。m=gu∈(M,2M) 给 u∈(X,2X)，内端 v 的相关区间及反向区间均有起点 ≍X、长度 O(L/g)≪X。模数 m 可以是 gX 级别；本证明从不把 Eσ(m) 偷换成一个只依赖 X 的小量。

设 Q=X^(1/8)。对 q≤Q，普通 μ 的卷积基点为 ≍X/q，至少 ≫X^(7/8)≳M^(7/40)。从 V 的定义，有一个与 g,q,H,L 无关的 a>0，使所有这些基点的 V 值≥a V_M。因此全部普通短和的指数误差可统一为 exp(−c0 V_M)。

长度小于 1 的实前缀含至多一个整数，其 μ 和为 O(1)，由 (X/q)^ν 吸收。若 S 最初只对整数端点陈述，端点取整也只增加 O(1)；Λ 的相应取整增加 O(log M)，同样由其幂误差吸收。这里不要求 L/g 趋于无穷。并且在全部实际层上 L/g≥1/2，所以配对计数中的 L/g+1 可统一换成 O(L/g)。

## 2. 互素 μ 前缀的独立统一证明

若 g 不平方自由，含 μ 端点的层为零。若 g 平方自由，固定 m=gu，精确 gcd 条件给

\[
\sum_{n\in I,(m,n)=g}\mu(n)
=\mu(g)\sum_{v\in I/g}\mu(v)\mathbf1_{(v,m)=1}.
\]

令 A_m(q) 指示 q 的所有素因子均整除 m，包括 q=1。逐素数的卷积恒等式是

\[
\mu(v)\mathbf1_{(v,m)=1}=(\mu*A_m)(v).
\]

对长度 h≤C L/g 的任意相关前缀，用 q≤Q 的部分调用普通 Sν^μ。统一指数比较及 Euler 级数给

\[
\sum_{q\le Q}A_m(q)\left[\frac hq e^{-c_0V_M}+(X/q)^\nu\right]
\ll h e^{-c_0V_M}\log^C(2M)+X^\nu M^\varepsilon.
\]

对 q>Q 用绝对值计数。因为 v≪X，只有 q≤C′X，故

\[
\begin{aligned}
\sum_{Q<q\le C'X}A_m(q)(h/q+1)
&\le h Q^{-1/4}E_{3/4}(m)+(C'X)^{1/2}E_{1/2}(m)\\
&\ll h X^{-1/32}M^\varepsilon+X^{1/2}M^\varepsilon.
\end{aligned}
\]

由此得到对所有实际 g、m 及所有前缀一致的

\[
R_g\ll
\frac Lg e^{-c_0V_M}\log^C(2M)
+(M/g)^\nu M^\varepsilon
+(M/g)^{1/2}M^\varepsilon
+\frac Lg(M/g)^{-1/32}M^\varepsilon. \tag{A}
\]

隐含常数可依赖固定 ε,ν，但不依赖增长 g。导体 m/X≈g 的增长已经全部落在 Eσ(m) 的 M^ε 因子里。用 M^ε 而不是未说明量词的 X^o(1) 是这里的重要修补。

## 3. 所有 μ 通道的绝对层和

在物理位移 t∈[L,2L]，固定 η 给 |K(t)|≪H、|K′(t)|≪H²/M。内端 f 与 K 的乘积，其上确界加总变差为 Oψ,η(H)：变化估计含 LH/M≤1/64，且 L/M=o(1)。改用 v=t/g 后，导数产生 g、积分区间缩短 1/g，常数仍一致。

去掉稀疏高次素数幂后，g>2 的外端 b 或 D=−4(log2)μ 均有常数界；外端数量 O(M/g)。离散 Abel 求和把 (A) 乘以 H/M²，再乘以外端数 M/g。分别处理 bD、Db、DD，至多固定次重复计费。因此归一化于 L/B=HL/M 后，总误差至多

\[
\begin{aligned}
\frac LB\bigg[&e^{-c_0V_M}\log^C(2M)\sum_{g\le2L}g^{-2}\\
&+\frac{M^{\nu+\varepsilon}}L\sum_{g\le2L}g^{-1-\nu}
+\frac{M^{1/2+\varepsilon}}L\sum_{g\le2L}g^{-3/2}\\
&+M^{-1/32+\varepsilon}\sum_{g\le2L}g^{-63/32}\bigg]. \tag{B}
\end{aligned}
\]

所有四个级数绝对收敛。取固定 0<ε<min(3/5−ν,1/32)，利用 L≥M^(3/5)，后三项都有固定幂节省。第一项的固定对数幂可在减小 c0 后吸收。

g=1,2 上，有 μ 与纯素数交叉时仍用 (A)，外端改用全区间 Chebyshev 的素数加权质量 O(M)；或者使用更松的 O(M log M) 并吸收固定对数幂。只有两个层，故不破坏 (B)。其他 μ 通道也可直接由有界外端处理。没有对全体层使用 O(M log M) 外端质量，也没有忽略原本可得的 1/g 权重。

关键结论是 (B) 的加权可和性，而不是 (A) 相对于 L/g 在每个 g 都很小。后者在最末层通常不能获得同样精度，也不需要。

## 4. 背景 b–b 的全层统一误差

note 894 的互素计数、奇偶 φ(u)/u 密度给

\[
\sum_{v\in I,(u,v)=1}b(gv)=r_g(u)|I|+O(\tau(2u)),
\]

且 b(gu)r_g(u) 的前缀平均为 d_g x+O(log(2x))，其中奇 g 的 dg=32/(3ζ(2))、偶 g 的 dg=4/ζ(2)。这些常数只按 g 奇偶分支，误差常数不依赖 g。

内端 Abel 误差由 Σ_{u≍X}τ(2u)≪X log(2X) 给出，逐层为 H/(Mg)·log(2M/g)。冻结后的外端权 |f(gu/M)|² 的总变差 Oψ(1)，故前缀平均的外端取整误差为 J(L)/(Mg)·log(2M/g)≪HL/(M²g)·log(2M/g)。这不是粗糙的 O(X^ε) 逐点 τ 上界。

冻结 f(n/M) 至 f(m/M) 的逐层误差用配对数 O(ML/g²) 给 HL²/(M²g²)。f 在 (1,2) 内固定紧支撑；当 M 充分大时，L/M=o(1) 保证支撑不会产生上端点截断缺口。固定 η 的 Poisson 别名误差逐层为 (HL/M)H^(−A)/g²，A 可任意固定大。

综上，对每个实际 g 都有独立于 g 的

\[
\left|T_{bb,g}-\frac{d_g}{g^2}I_\psi J(L)\right|
\ll \frac H{Mg}\log\frac{2M}g
+\frac{HL}{M^2g}\log\frac{2M}g
+\frac{HL^2}{M^2g^2}
+\frac{HL}M\frac{H^{-A}}{g^2}. \tag{C}
\]

对 g≤2L 求绝对和，得到

\[
\ll \frac LB\left[\frac{\log^2(2M)}L+
\frac{\log^2(2M)}M+\frac LM+H^{-A}\right]. \tag{D}
\]

最末层的 u 仍有 X≫M^(1/5)，没有外端平均只在少量点上调用的问题。即使内端区间长度约 1，(C) 的 τ 平均依旧合法。四项分别由 L≥M^(3/5)、M→∞、L/M≤1/(64H) 和 H≫M^(1/5) 给固定幂节省。

## 5. 素数、稀疏例外与形式主项尾

纯素数端点 p≍M、2p≍M 在 |n−m|≤2L=o(M) 时只能落于 gcd=1 或 2：若共有底层大素数 p，则两个不同倍数的距离至少 p。草案列出的有向配对常数因此仅在两个固定层出现，总和为 g=1 的 −12、g=2 的 +3。原固定层低素数证明使用 Sν^Λ、普通 Abel 求和和外端素数质量；ν<3/5 使 M^ν/L 有幂省。该步骤不需要增长 g 的素数分布命题。

高次素数幂及二倍高次素数幂的集合有 O(M^(1/2)log M) 个点；每个点可配的另一个端点 O(L)，所有系数 O(log M)。由于精确 gcd 层分割全部配对，直接支付全配对绝对和便得到

\[
\sum_g|T_{c,g}-T_{b+P_o+P_e+D,g}|
\ll (L/B)M^{-1/2}\log^C(2M).
\]

不需要把每层的同一个稀疏界再乘以 2L，也不需要高素数幂除数个数的额外一致命题。

g>2L 时 Tg=0，而 Cg=d_g/g²。因此形式尾的绝对误差是

\[
I_\psi |J(L)|\sum_{g>2L}|C_g|
\ll (L/B)/L.
\]

由固定 η 的正核性质 J(L)≍L/B，此形式尾仍有固定幂节省。合并 (B)、(D)、两个低层素数误差、稀疏例外和形式尾，即得判定中的全层绝对误差命题。

## 推论与审查边界

主系数级数绝对收敛，奇偶求和精确给 Σg Cg=0。上述 ℓ1 结论使交换真实有限层和与形式无限主项成为已证明的操作，故

\[
\left|\sum_gT_g(L)\right|
\le\sum_g|T_g(L)-C_g I_\psi J(L)|
\ll (L/B)e^{-c'V_M}.
\]

这个结论只处理固定 η、M^(3/5)≤L≤B/64 的单个正核位移窗口。exp(−c′V_M) 比任何固定负幂慢，因此它不提供完整频带所需的固定幂余量，也不证明 RH。没有复核可变 η_M 的统一导数/Euler 常数，没有晋级原 note 894 的所有量词，没有审查相邻问题。

外部短和定理的真实性与来源仍是输入层：本次审查没有访问 1976 原文或当前文献，也不声称核过 Remark 4 的完整函数类。父任务报告的新文献输入可另行支持 S；本文件只认证条件于所列 Sν 与 Euler 因子界的统一数学推导。没有发现该有限命题的剩余数学阻塞。
