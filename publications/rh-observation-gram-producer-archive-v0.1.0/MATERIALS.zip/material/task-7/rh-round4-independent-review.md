> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Independent review of the pulse-4 pointwise-envelope obstruction

2026-10-03. This is a fresh-context, same-model review of `rh-round4-pointwise-envelope-obstruction.md`. It is not a heterogeneous review. The pulse-4 manuscript was the only initial mathematical input; the frozen pulse-3 manuscript was subsequently read only to check its Fejér-transfer interface. No original project file was edited, no Git mutation was made, and no remote computation, paid service, or publication was used.

**Disposition:** the asymptotic envelope-only countermodel is mathematically sound within the stated larger coefficient class. No blocking proof flaw was found. The assertion about the actual local gate additionally invokes the frozen pulse-3 transfer, whose hypotheses are met. This does not establish a counterexample for the true von Mangoldt function, prove or disprove RH, or certify novelty or release readiness.

## Uniform envelope audit

The literal common bound is stronger than a mere match of exponents, and its proof addresses the full parameter set, rather than just the observation frequencies.

For every permitted approximation, `δ0 q = max(q, q|δ|/4) ≤ √x`. For `q ≥ 2`, reduction of the numerator modulo `q` places its rational part between `1/q` and `1−1/q`. The perturbation of either branch derivative has size at most `|ε| + t_*H/M`, with `q|ε| ≤ x^(−1/2)` and `qH/M = o(1)` uniformly. Thus each derivative remains in one interval separated from the integers by `1/(2q)`. Its monotonicity passes to the consecutive phase increments. The elementary telescoping first-derivative estimate and the fixed total variation of χ give `O(q)` for every packet prefix. The same bound holds for the baseline geometric sum. Dividing by the proposed envelope gives at most `O(x^(−1/4))`, uniformly in all these denominators. Consequently even the literal factor 1.01 is available eventually.

For `q = 1`, a large fixed constant `D` splits the two analytic regimes. When `|δ| ≤ DH`, each branch has second derivative of magnitude comparable to `H/M²`, independently of the linear perturbation. The integral is `O(M/√H)`, and Euler summation costs `O(1+H+|δ|) = O(H)`. Since `H^(3/2) = o(M)`, the error is absorbed. Comparison with `x/√δ0` loses only a fixed constant depending on `D`.

When `|δ| > DH`, choosing `D` sufficiently large makes the linear term dominate both chirp derivatives on the entire active interval. The integral is `O(M/|δ|)` and Euler summation adds `O(H+|δ|)`. Each resulting term is bounded by a fixed multiple of `x/√δ0`: `|δ| ≤ √x = O(√M)` ensures in particular that `|δ|^(3/2)/M = O(M^(−1/4))`. These bounds are uniform over partial packet prefixes as well as the full support.

The packet alone has an unspecified fixed envelope constant, but it is multiplied by `ρM → 0`. This is enough for the literal common constant: for `|δ| ≤ 4`, the pointwise bound `0 ≤ L ≤ 1+ρM` gives `(1+ρM)x`; for `|δ| > 4`, the baseline geometric sum has envelope ratio at most `1/(4√|δ|) ≤ 1/8`. There is therefore ample fixed slack to absorb the packet. There is no unexamined gap at the threshold `|δ| = 4` or in the transition `|δ| ≍ H`.

## Primary-statement scope and exponent budget

The original statements of [Srivastav, Theorem 1 and Corollary 1](https://arxiv.org/html/2505.07803v2) and [Maynard–Pandey–Radziwiłł, Theorem 1.1](https://arxiv.org/html/2608.14777v1) were read through public, read-only primary-source browsing. This was a statement/domain audit, **not an audit of either paper's full proof**.

Srivastav's Corollary 1 has precisely the quoted `q ≤ x^(1/3)`, `|δ| ≤ x^(4/15)/q` domain and constants 51 and 15. Every fixed-parameter Theorem 1 domain also lies in the manuscript's larger approximation domain. The literal Corollary 1 Λ envelope follows immediately from `q/φ(q) ≥ 1`; the manuscript only needs to claim the corresponding pointwise scaling on the larger Theorem 1 domains. The true μ is retained, so its cited bounds are not counterfeited by changing coefficients.

The MPR approximation range and exponent 19/24 are quoted correctly. Its parameter `B = max(q, q|δ|)` satisfies `δ0 q ≤ B ≤ 4δ0 q`, so the proposed common envelope gives at most `2.02x/√B`, which obeys the displayed MPR envelope up to a fixed constant. The manuscript correctly does not claim the substitute weights satisfy the arithmetic hypotheses of that theorem.

The endpoint-convention precision point has been resolved in the manuscript: MPR writes `Σ_(n<N)`, and the possible true-Λ endpoint is explicitly recorded as `O(log N)`, absorbed in the `N^(19/24+o(1))` term. A substitute-weight endpoint is bounded. This does not affect the argument.

The normalized second term is `M^(−5/24+o(1))`. Squaring and summing over `O(H)` modes gives `H M^(−5/12+o(1))`. Its ratio to `H⁴/M` is `M^(7/12+o(1))/H³`, at most `M^(−1/60+o(1))` because `H ≳ M^(1/5)`. The 1/60 margin is correct. The manuscript also correctly treats the two terms as terms of an upper bound, rather than independent arithmetic vectors that may be removed separately.

## Exact joint observation and lower bound

On the observation window `M < m < 2M`, the doubled input lies below the packet support. Hence `L(m/2)−1 = 0` exactly whenever the doubled arm is present. The displayed identity

    cσ(m) = −4(log 2)μ(m) − 4σρM uM(m)

therefore preserves the complete original two-scale formula, including its parity factor. The true μ channel is identical for both signs; all its multiplication and parity facts are consequently preserved.

The product amplitude `φ(t) = χ(t)ψ(t)/t` is positive near `t_*`. A small fixed positive interval of ratios `h/H` keeps the unique positive-branch stationary point `t_*H/h` in that region and inside η's plateau. The stated stationary-phase normalization is correct for `e(t)=exp(2πit)`: the leading magnitude is `φ(t_h)t_h/√(t_*H)`. The negative branch is nonstationary. Its `O(H^(−1))` contribution, the `O(H^(−3/2))` stationary remainder, and the discrete `O(H/M)` error are all smaller than the leading `H^(−1/2)` term. There are a fixed positive multiple of `H` integer modes in this interval, so `E_D ≥ c > 0` follows without relying on phase coherence between modes.

The Hilbert-space parallelogram identity eliminates any need to estimate the true μ contribution: `E_+ + E_− = 2||U||² + 32ρM² E_D`. Thus at least one sign has the required lower bound even if the other cancels strongly against μ. Allowing the sign to depend on the scale is legitimate for disproving a uniform implication over this coefficient class. Since `ρM² = M^(−o(1))`, it dominates the target `M^(−1/5+ε)` for each fixed `0 < ε < 1/5`.

The ordinary-interval bound and nonnegativity follow directly from `|uM| ≤ 1`. For `x ≍ M`, a fixed choice `0<c<a` eventually makes `ρM ≤ exp(−cV_x)`; endpoint counting can be absorbed in the displayed polynomial additive term. No estimate with prime-power support or the identity `Λ = μ*log` survives the replacement, and the manuscript explicitly records both losses.

## Frozen local transfer

The pulse-3 transfer requires `Σ|a_x|² = O(log M/M)` for `a_x = c(M+x)ψ(1+x/M)/(M+x)`. Here `cσ` is uniformly bounded, giving the stronger `Σ|a_x|² = O(1/M)`. The original fixed η and permissible H are used, and any fixed `1/10 < γ < 1/5` gives the required short relative filter support.

Even the weaker recorded pulse-3 root-energy error `O(M^(−γ)log^(3/2)M)` is `o(ρM)`. Reverse triangle inequality therefore transfers the winning sign's lower bound to the existing `E_loc`. This is a valid invocation of the frozen theorem; it is not a new filter construction or an arithmetic cancellation argument.

## Review limits

The accepted conclusion is failure of an implication from the stated envelopes, ordinary bounds, nonnegativity, and the exact observation formula in the enlarged test class. This review supplies no actual-Λ correlation lower bound, no true signed-pair estimate, no RH conclusion, and no independent proof of the conditional ordinary μ input. Prior private scratch results and novelty were not audited. Human attribution and licensing remain outside this mathematical disposition.

## Finite verifier audit

The source `rh_round4_verify.py` and its recorded `rh-round4-verifier-result.json` were inspected. The review did not independently rerun the program. The recorded environment is Python 3.14.7 with NumPy 2.5.1; its calculation is bounded at `M=32768`, `H=10` and 290 sampled approximation parameters.

The FFT uses the correct sign and normalization for the observation, because translating `m=M+x` contributes the integer phase `e(−h)=1`. The finite ψ vanishes at the endpoint included by its array representation. The Möbius sieve uses all relevant primes and removes square factors. The doubled packet arm is exactly absent. The finite Fejér multiplier matches the frozen construction, and the root-energy triangle bound uses the correct factor `√(MΣ|a|²)`.

The recorded exact-formula residual is below `4.5×10^(−16)`, the parallelogram residual is zero to the recorded precision, and the packet energy is about 0.06693. Both root-energy differences are below their computed spectral bounds. The largest sampled common-envelope ratio is 1.000770465, below 1.01.

The optional verifier precision improvement has been resolved. The verifier now asserts the sampled ratio is below 1.01 and records `sampled_literal_1_01_envelope_pass=True` and `lowest_H_specialization_tested=False`. The parent reports a successful rerun with the numerical output otherwise unchanged. This strengthens the finite diagnostic's explicit check without altering the analytical 1.01 proof; this reviewer did not independently rerun the revised program.

These calculations are diagnostics, with two explicit scope limits. First, `H=10` lies in the original allowed H interval but differs from the proposition's chosen lowest-scale value `ceil((M/2)^(1/5))=7`. Second, the finite joint energies divided by `H⁴/M` are approximately 0.1414 and 0.1292, both below 1. They therefore do not exhibit a finite target violation. The displayed logarithmic gap values illustrate the asymptotic growth formula, rather than replace the stationary-phase argument. No finite sample establishes the all-parameter envelope, an eventual 1.01 threshold, or the asymptotic lower bound.
