> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# True convolution inside the fixed Fejér pair: verified reduction and research stop

2026-10-03, bounded RH/local Weil pulse 5. Original project read only. This pulse uses actual Möbius inversion, not a single-frequency envelope or a modified Λ model. **Outcome: no new arithmetic power saving.** The calculation below transports an existing true-convolution reduction to the already fixed Fejér pair and identifies exactly what remains unproved. It is not proposed as a novel theorem or a new Commons contribution.

## Scope and prior-work check

The old private notes were checked before this calculation. Scratch 924 already proves the cofactor ≥3 identity and pays the low sources in the observation band. Scratch 926 puts both parity arms into one odd-source Gram, pays its diagonal and small reduced ratios, and explicitly leaves the distinct-source signed covariance. Scratch 917 restores complete physical rows and identifies exact zero rows. Scratch 919 already upgrades those zero rows to a positive-density family. Notes 889–892 already contain squarefree recentering and signed prime/composite compensation; note 889 even identifies positive and negative constant-size prime–Möbius subblocks. Scratch 912 already pays periodic background and higher prime powers under gcd masks. These claims are not being counted again as progress or inferred from filenames: the relevant formulas and their proofs were read.

No new external theorem is needed for the calculation here. The central algebra is proved below. External pointwise estimates audited in pulse 4 are not used. The frozen pulse-3 Fejér construction and its elementary multiplier error are the sole local analytic dependency.

## Fixed objects

Let M=2Y be an even integer, Y^(1/5)≤H≤Y^(1/4), and let ψ∈C_c^3((1,2)) be real. Put φ(v)=ψ(v)/v. Fix even nonnegative η∈C_c^∞ supported on 1/2≤|t|≤4, as in pulse 3. For large M, 8H<M. Set

    c(n)=2·1_(2|n)(Λ(n/2)−1)−4(Λ(n)−1+(log 2)μ(n)),
    a_x=M^−1 c(M+x) φ(1+x/M),  x∈Z/MZ,
    A_h=Σ_x a_x e(−hx/M),
    E=Σ_h η(h/H)|A_h|²,       T=H⁴/M.

Use representatives 0≤x<M for every cyclic coefficient definition and centered residue representatives for functions of h/H. The ordinary integer frequency sum has distinct active residues since 8H<M. All coefficients are zero outside the compact ψ window. The physical phase e(−h(M+x)/M) equals e(−hx/M).

Keep the pulse-3 filter, unchanged: choose 1/10<γ<1/5,

    K=ceil((M/H)M^γ),
    q_j=(1−|j|/K)M^−1 Σ_h √η(h/H)e(hj/M),  |j|<K,
    q_j=0 otherwise,
    E_loc(a)=M||q*_M a||₂².

For all sufficiently large M, K<M/2 and K=o(M). Its multiplier Q_h obeys

    max_h |Q_h−√η(h/H)| ≤ ε_M ≪ M^−γ log M.       (1)

The corresponding actual-coefficient target bounds for E and E_loc are equivalent by pulse 3. Every new Gram below uses this same q. No new localizer is chosen to obtain a desired answer.

## The structure destroyed by Λ± replacement

Let b(n)=4−2·1_(2|n), and define

    κ(1)=κ(2)=0,
    κ(k)=(−4+2·1_(2|k))log(k/2), k≥3.

For actual μ and Λ, for every n>1,

    c(n)=b(n)+Σ_(d|n, n/d≥3) μ(d)κ(n/d).           (2)

Proof: substitute Λ=μ*log into c. Since (μ*1)(n)=0 for n>1,
μ(n)=−Σ_(d|n,d<n)μ(d). The cofactor k≥2 coefficient then is
−4log k+4log 2+2·1_(2|k)log(k/2), which is κ(k) and vanishes at k=2. The k=1 logarithms vanish. This proves (2) exactly, without a rate assumption.

This is the chosen structural proposition. The pulse-4 Λ± perturbation leaves μ actual, but violates Λ=μ*log. It therefore violates (2); retaining its good scalar envelopes cannot restore this identity. Conversely (2) is already in scratch 924. Re-proving it is a consistency audit, not a new theorem.

For d≥1 define the cyclic source vector

    v_d(x)=M^−1 κ((M+x)/d) φ(1+x/M)
           ·1_(d|(M+x), (M+x)/d≥3).

The support condition in (2) gives d<2M/3 automatically. Put D=floor(M/(16H)),

    a^hi=Σ_(D<d<2M/3) μ(d)v_d,
    r=a−a^hi=b_φ+Σ_(d≤D) μ(d)v_d,
    b_φ(x)=M^−1 b(M+x)φ(1+x/M).

Then a=a^hi+r is an exact vector identity before and after convolution by q.

## Low-source and diagonal payments in the same Fejér pair

The standard C³ Poisson calculation yields, for H/2≤|h|≤4H,

    |r̂(h)| ≪ H^−3 log² M,
    E(r) ≪ H^−5 log⁴ M=o(T).                      (3)

Here are the details needed to check this dependency. For d≤D let X=M/d≥16H. On X<k<2X, κ is the sum of a smooth logarithmic integer-lattice term and a smooth logarithmic even-lattice term. After scaling, φ and (log v)φ(v) have Fourier transforms O((1+|ξ|)^−3). All aliases h+jX and h+jX/2 lie at distance ≫H(1+|j|) from zero. Thus |v̂_d(h)|≪log M/(dH³). Summing 1/d and adding the two fixed background lattices proves (3). This repeats, rather than strengthens, the payment in scratch 924.

For each fixed σ>0, the elementary divisor bound τ(n)≪_σ n^(σ/4), with logarithms absorbed into M^(σ/2), gives

    M||r||₂² ≪_σ M^σ.                             (4)

By (1), Parseval and the triangle inequality,

    E_loc(r) ≤ 2E(r)+2ε_M² M||r||₂²
             ≪ H^−5log⁴M+M^(−2γ+σ)log²M=o(T),   (5)

where choose any 0<σ<2γ−1/5. This uses T≳M^−1/5. Thus the low-source payment survives the fixed localizer, including its leakage outside the observation band. In particular

    |√E_loc(a)−√E_loc(a^hi)| ≤ √E_loc(r)=o(√T).   (6)

Define the exact Hermitian positive-semidefinite source matrix

    Γ_de=M Σ_x (q*v_d)(x) overline((q*v_e)(x)).

Its diagonal contribution is

    D_loc=Σ_(D<d<2M/3) μ(d)² Γ_dd.

First in the exact observation band, |v̂_d(h)|≪log(2M/d)/d by counting its O(M/d) active cofactors. Therefore

    D_band=Σ_h η(h/H)Σ_(d>D) μ(d)²|v̂_d(h)|²
           ≪ HΣ_(d>D) log²(2M/d)/d²
           ≪ H² log²(2H)/M=o(T).                 (7)

For the leakage transfer, the vectors' total squared mass obeys

    Σ_d ||v_d||₂²
    ≪ M^−2 log²M Σ_(M<n<2M) τ(n)
    ≪ log³M/M.                                  (8)

The last inequality follows by summing Σ_(d≤2M) floor(2M/d)≪Mlog M. Applying (1) to all source vectors and summing squares now gives

    D_loc ≤2D_band+2ε_M² MΣ_d||v_d||₂²
          ≪ H²log²(2H)/M+M^−2γlog⁵M=o(T).        (9)

This is an interface check: no source sign cancellation was used in (7)–(9). It does not pay the non-diagonal terms.

## The remaining hypothesis and the stopping point

The exact paired identity is

    E_loc(a^hi)=D_loc+O_loc,
    O_loc=Σ_(D<d,e<2M/3, d≠e) μ(d)μ(e)Γ_de.     (10)

O_loc is real. Positivity gives O_loc≥−D_loc, but provides no useful upper bound. By (6) and (9), for every ε>0 the original target is equivalent to

    |O_loc| ≪_ε H⁴M^(−1+ε).                      (H5)

Indeed, an upper bound on O_loc bounds E_loc(a^hi); conversely its lower bound −D_loc and a bound on E_loc(a^hi) bound |O_loc|. This is an equivalence of bounds, not an unconditional small difference between the complete energies. Γ keeps all physical cofactor collisions, both parity arms, and the signs of the q autocorrelation. Neither a fixed-cofactor cross block nor an absolute sum of Γ_de is substituted for (H5).

The real μ restriction is also exact: if d=gu, e=gv, (u,v)=1, a nonzero product requires gu and gv squarefree, so

    μ(d)μ(e)=μ(uv)μ(g)²·1_((g,uv)=1).            (11)

For a fixed reduced pair u,v the common-factor variable g has no alternating μ(g) sign; μ(g)² is a nonnegative squarefree mask. Thus merely invoking multiplicativity after common-factor grouping supplies no new cancellation. Equation (11), too, is already recognized by the old odd-source/gcd analysis. The unproved signed cancellation must occur across the remaining reduced pairs and their complete cofactor kernels, or through a new arithmetic estimate on the full matrix. The presence of Γ as a positive Gram matrix does not make its μ-weighted off-diagonal sum small.

**Research stop:** this bounded pulse recovered the old true-convolution gate and verified that its elementary payments are valid inside the frozen Fejér pair. It did not find a stronger true-Λ estimate for (H5), a counterexample to the actual arithmetic gate, or a new fixed-power saving. Continuing this algebra or rephrasing more pointwise envelopes would repeat known material. No formal new arithmetic theorem, RH conclusion, or Commons novelty claim is made. A next pulse should begin only with a specific new estimate for the complete reduced-pair matrix, with a quantitatively stated rate; another cofactor identity is insufficient.

## Reproduction, review, and contribution boundary

`python3 rh_round5_verify.py` performs a bounded finite diagnostic using actual prime-power Λ and an integer Möbius sieve. It checks Λ=μ*log, (2), exact source reconstruction, the fixed-form Fejér multiplier identity, matrix/physical energy equality, and diagonal/off-diagonal decomposition. It also changes Λ at a non-prime-power composite while keeping μ actual, and confirms failure of (2). This is a falsification of an overextended identity on altered inputs, not an arithmetic counterexample. Finite filter parameters check algebra only, not the large-M approximation regime or (H5). Analytic proofs above, not numerics, establish the payments.

Independent review is a fresh-context review by the same model family; it cannot replace heterogeneous mathematical review. Its verdict is stored separately. There is no proposed new public contribution from this pulse. If a parent elects to share a minimal explanatory checkpoint, attribution, rights-holder license, novelty assessment, and external validation remain pending. No private original notes, third-party source files, signing keys, upload, DOI, or publication are included or authorized here. Prior frozen packets are unchanged.
