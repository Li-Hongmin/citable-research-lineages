> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# RH/local Weil：暂停时的最小未解命题

2026-10-03。第五轮终审通过所述归约，**未证明以下命题**。本页是未来文献检查或外部数学审阅的入口，不是新的 Commons 投稿候选。用户已要求本轮封存后暂停。

## 精确命题 H5

固定实函数 ψ∈C_c³((1,2))，置 φ(v)=ψ(v)/v。固定偶、非负 η∈C_c^∞，支撑于 1/2≤|t|≤4，并在 1≤|t|≤2 上 ≥1。令 M=2Y 为偶整数，Y^(1/5)≤H≤Y^(1/4)。μ为真实 Möbius 函数，Λ为真实素数幂 von Mangoldt 函数；使用完整恒等式 Λ=μ*log、μ*1=δ₁。

固定 1/10<γ<1/5，K=ceil((M/H)M^γ)，D=floor(M/(16H))。在 Z/MZ 上用代表元 0≤x<M、居中频率代表元定义

    q_j=(1−|j|/K) M⁻¹ Σ_h √η(h/H)e(hj/M), |j|<K；其余为0，
    κ(1)=κ(2)=0，κ(k)=(−4+2·1_(2|k))log(k/2), k≥3，
    v_d(x)=M⁻¹κ((M+x)/d)φ(1+x/M)
           ·1_(d|(M+x),(M+x)/d≥3)，
    Γ_de=M Σ_x(q*v_d)(x) overline((q*v_e)(x))。

需证明：对每个 ε>0，所有充分大 M、全范围 H，一致有

    |Σ_(D<d,e<2M/3, d≠e) μ(d)μ(e)Γ_de|
      ≪_(ε,ψ,η,γ) H⁴M^(−1+ε)。                 (H5)

这里保留两个物理奇偶臂及所有 cofactor；不换成逐项绝对和、不要求单个 cofactor 子块达到此界、不删除远距离负核。固定 ψ、η 后常数可依赖它们，不能随 M 改变以获得所需结论。

已核实：低源误差在同一 q 中为 o(H⁴/M)，且

    Σ_d μ(d)²Γ_dd
      ≪ H²log²(2H)/M+M^−2γlog⁵M=o(H⁴/M)。

因此 H5 是当前完整联合观察目标上界的必要且充分归约。不是声称 H5 已成立，也不是把更强的逐窗口/单通道条件宣布为必要条件。

## 现有方法为何未闭合

- **普通短和及固定 gcd 密度：**当前有次指数或任意对数幂节省，联合主常数能抵消，但这些误差在最低 H 的部分位移带上仍大于固定幂目标。误差上界不足不构成真实余项的下界。
- **素数/μ 单频率上界：**第4轮已审适用域的现成界给各归一化包 O(H⁻¹/²)，O(H) 个频率平方和到 O(1)；最低 H 的目标是 M⁻¹/⁵。新预印本的二级误差预算可支付，并未支付其主项，也未给出实际分解。
- **真实卷积、平方自由支撑及精确零行：**它们排除第4轮 Λ±反模型并删除若干源/物理位置，却尚未控制剩下的完整 Γ。该轮反模型从来不是真实算术反例。
- **Gram 正性：**只给非对角和≥−已付对角，不能给 H5 所需上界。
- **按 gcd 使用乘法性：**写 d=gu、e=gv、(u,v)=1 后，μ(d)μ(e)=μ(uv)μ(g)²·1_((g,uv)=1)。固定约化比例时没有 μ(g) 交替；所缺仍是约化对之间及完整 cofactor 核的联合 signed 抵消。

## 外部审阅入口与停止条件

先读本任务 [完整归约](rh-round5-true-convolution-stop.md) 中 (2)–(11)、[新上下文同模型审查](rh-round5-independent-review.md)，以及冻结第3轮的 Fejér 乘子误差证明。复现入口为 `python3 rh_round5_verify.py`；有限检查只验证恒等式和归一化，不能检验 H5 渐近界。

未来审阅应直接回答：是否有可适用于上述 **完整 Γ** 的实际 μ 双线性/二点估计，能提供最低 H 所需固定幂速率？若调用短区间或指数和文献，应给出原定理、系数限制、频率/区间范围、是否几乎处处及例外集，并重新核算 H⁴/M 量纲。只给已知 cofactor 恒等式或单频率包络不足以重启此路线。

已读公开文献的检索入口保留在第3、4轮 source-audit：Matomäki–Shao–Tao–Teräväinen 的全区间高阶均匀性、Matomäki–Radziwiłł–Shao–Tao–Teräväinen 的几乎所有区间版本、Srivastav 和 Maynard–Pandey–Radziwiłł 的素数指数和预印本。相关原定理已作范围核查；预印本的完整证明没有被本任务独立认证。外部异源审阅仍缺，不以同模型通过替代。

当前停止：不启动第六轮、不生成更多包络/同类恒等式、不将第五轮算作新投稿。前四轮冻结成果保留原有待投稿边界；本轮不给署名、许可、上传或 DOI 授权。
