> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# RH / local Weil 第三有界轮检查点

2026-10-03。原库只读；第二轮已封存packet未改。新稿另存 task-7/rh-round3-short-filter-obstruction.md。本轮不声称改善真实算术余项的速率。

## 精确的新结果

1. **无余项短滤波替换的尖锐障碍。** 观察集合F含s个频率，任意系数测试类的允许位置中含s+1连续位置。如果正滤波方差 Σ_j||q_j*a||² 可由观察带能量E_F精确上界，每个非零连续支撑滤波器都必须有长度至少M−s+1；该阈值由补频率根多项式达到。证明用P(z)=∏_(h∈F)(z−ζ^(−h))：E_F=0，但任何长度更短的q与P之积次数小于M且非零，不能在模z^M−1后变零。允许M合数、环形支撑、实系数和随M增长的阶数。

2. **含已支付误差的可用局部门。** 对实际固定η，以f_h=√η(h/H)作离散Fejér近似，取K=ceil((M/H)M^γ)、1/10<γ<1/5。显式q支撑在|n|<K，因此相对长度o(M)。真实a的二次质量 Σ|a|²≪logM/M 给

       |√E_loc−√E| ≪ M^(−γ) log^(3/2)M，
       E_loc=M||q*a||²。

   该误差平方o(H⁴/M)，对原H范围一致。因此E_loc的H⁴M^(−1+ε)上界与原E目标等价。ψ远离端点，使其普通位移相关表示无需周期回绕。取γ=3/20、H≈M^(1/5)，物理跨度O(M^(19/20))，比单观察长度M/H更长，但仍是o(M)。这是目标的具体局部化，**没有证明E_loc本身的算术上界**。

两命题并不冲突：第一条排除严格无余项精确支配；第二条用真实二次质量支付了近似余项。不能由第二条称RH或局部Weil全尺度门成立。不能无条件称E−E_loc=o(H⁴/M)，这里只认证平方根差及目标上界等价。

## 对固定幂缺口的明确判断

第二轮的Σ_g绝对余项只有(L/B)exp(−cV_M)。在H≈M^(1/5)、L=M^(3/5+δ)，同一接口的新率ρ_M必须≤M^(−δ+ε)才能支付H⁴M^(−1+ε)。相比当前率，必须多出M^(−δ+ε)exp(cV_M)节省。这个必要率只针对该逐带绝对误差接口；真实完整Gram仍可跨带抵消。

一个可直接尝试但未证的充分估计是整组三通道A_h一致≤H^(3/2)M^(−1/2+ε/2)。单个η平台频率的必要界仅H²M^(−1/2+ε/2)，不足以支付全部O(H)频率。把μ、Λ两条臂分开作为必要门也不合法。现已给出完整显式Fejér权的E_loc普通位移相关式，下一轮可以直接检验其真实联合signed Gram，而无需重复固定g常数或有限秩工程。

## 文献与失败保存

已读2023 all-interval作者原稿v4的Theorem1.1(i),(ii)、Corollary1.3、(1.23)，及2026 Inventiones开放原文Theorem1.1(i),(ii),(iii)、Corollary1.2：μ/Λ结论仍为log节省；2026是almost-all，Λ须减Λsharp，不能删例外集。其divisor power saving不是μ/Λ结论。Gallagher1970仅publisher preview，未引用未见lemma。1976下载403障碍沿前轮记录保留，未重试或绕过。

最初考虑的短和振荡反模型及固定阶Haar反模型已在scratch952、904/910和note882存在，因此放弃，不包装为新结果。新有限命题不宣称数学优先权或新不确定性原理。一次猜错的SIAM DOI打开无关文章，已在source audit记录并排除。

## 审查、复现与保持

独立新上下文审查见rh-round3-independent-review.md；两个命题均ACCEPT，无实质数学漏洞。初始η声明的光滑性已按审查显式补入；环形最小跨度和缩放范围亦已精确措辞。审查仍为同模型复核，不是异源审查，外部定理不在审查者范围。标准库`python3 rh_round3_verify.py`检查多项式零带反例、环形支撑、补根尖锐性、离散Fejér恒等式、核质量、Lipschitz首矩误差及Parseval三角界，全部PASS；审查者还做了独立精确整数反例/协方差检查和Fejér诊断。数值残差是诊断；精确/渐近结论依据解析证明。

preservation snapshot显示原抽样指纹不变，git仍仅891–894既有未跟踪笔记，第二轮packet四文件SHA256全部吻合。进程归属仍UNKNOWN，原`ps`权限拒绝未重试、未绕路；本轮未原库写入或取锁。未HPC/SAT、云VM、充值、账户切换、外发、签名key、DOI或归档。

统一贡献父任务可取本轮自足稿＋代码＋结果＋审查及新版本manifest。署名、许可、异源审查和新颖性未定；不自动附原私稿、第三方PDF或提取文本。第二轮版本继续封存。

## 接续位置

本轮具体局部化义务完成。剩余最清楚的单个科学义务是：对已显示的Fejér三通道位移权，在真实c上证明E_loc≪_εH⁴M^(−1+ε)，或给出可核的实际消去子命题；当前ordinary短和只给次指数/对数率。若仅重证滤波截断、固定层守恒或相同反模型，应停，不能当作幂界进展。

PULSE=SHORT_FILTER_OBSTRUCTION_AND_PAID_LOCALIZATION; MAIN_ARITHMETIC_RATE=OPEN.
