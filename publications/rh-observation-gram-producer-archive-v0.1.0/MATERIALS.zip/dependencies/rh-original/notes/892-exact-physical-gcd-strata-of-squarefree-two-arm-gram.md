> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 平方自由双臂 Gram 的逐物理 gcd 主项

日期：2026-10-03。**证明草案；固定 gcd、Euler 尾、次指数与固定幂增长 $G$ 的延伸均已独立只读复核，异源复核未完成。**沿用 [note 891](891-squarefree-parity-arms-cancel-prime-density-on-positive-collar.md) 的五通道系数、正核位移窗口与记号，并使用 [note 885](885-squarefree-gcd-averaging-leaves-weighted-mobius-main.md) 的平方自由互素计数、[note 851](851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 的 Möbius 短和。本文把 note 891 的“互素负项与非互素正项”细化为每个固定物理 gcd 的主项，并求出截断后主系数尾的尖锐 $1/G$ 常数。它是局部有向 Gram 的分层渐近式，不是完整观察频带的固定幂上界。

## 定理

设 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$、$B=M/H$、$V_M=(\log M/\log\log M)^{1/3}$，并取 note 891 式 (1) 的 $K_\alpha\le L\le B/64$。令 $w$ 为该 note 式 (2) 的五通道之和，$f(v)=\psi(v)/v$，$I_\psi=\int_1^2|f(v)|^2\,dv$，$J_M(L)=\int_{L/B}^{2L/B}\widehat\eta_M(t)\,dt$。把式 (3) 中的 $w$–$w$ 有向 Gram 限制在物理 $\gcd(m,n)=g$，记为 $T_{ww}^{[g]}(L)$。

令 $\Theta_o$ 为 note 891 式 (7) 的 Euler 乘积。对每个固定奇平方自由整数 $q>1$，置
\[
 A(q)=\prod_{p\mid q}\frac1{p(p+2)}.
\tag{1}
\]
存在固定 $c>0$，对每个固定 $q$ 一致于上述 $H,L$，有
\[
\begin{aligned}
T_{ww}^{[1]}(L)&=-8(1-\Theta_o)I_\psi J_M(L)
 +O\!\left(\frac LB e^{-cV_M}\right),\\
T_{ww}^{[2]}(L)&=-(1-\Theta_o)I_\psi J_M(L)
 +O\!\left(\frac LB e^{-cV_M}\right),\\
T_{ww}^{[q]}(L)&=8\Theta_o A(q)I_\psi J_M(L)
 +O_q\!\left(\frac LB e^{-cV_M}\right),\\
T_{ww}^{[2q]}(L)&=\Theta_o A(q)I_\psi J_M(L)
 +O_q\!\left(\frac LB e^{-cV_M}\right).
\end{aligned}
\tag{2}
\]
若 $g$ 不是平方自由整数，则 $T_{ww}^{[g]}(L)=0$。任意 $G\ge2$ 的其余层还有一致的绝对尾界
\[
\sum_{g>G}|T_{ww}^{[g]}(L)|\ll_{\psi,\eta}\frac{L/B}{G}.
\tag{3}
\]
因此先令 $M\to\infty$ 再令 $G\to\infty$，各层主项满足精确补偿
\[
\underbrace{-8(1-\Theta_o)-(1-\Theta_o)}_{g=1,2}
+\underbrace{9\Theta_o\sum_{\substack{q>1\\q\text{ 奇平方自由}}}A(q)}_{g\ge3}
=-9(1-\Theta_o)+9(1-\Theta_o)=0.
\tag{4}
\]
特别地，当 $I_\psi>0$ 时，$g=2$ 层的实部也有严格负主项；全部正补偿来自含有奇素数的共同因子层。式 (4) 是主项的 Euler 恒等式，不控制完整 Gram 的固定幂余量。
在非互素部分内部，$g=2$ 的系数为 $-(1-\Theta_o)$，而 $g\ge3$ 的总系数为 $+9(1-\Theta_o)$；合计 $+8(1-\Theta_o)$，也核对了 note 891 式 (9c) 的非互素补偿。

## 平方自由配对的固定 gcd 密度

记 $D_q$ 为两个**奇**平方自由整数具有精确共同因子 $q$ 的双变量局部密度。素数 $2$ 的局部因子为 $1/4$。对每个奇素数 $p\nmid q$，两整数的 $p$ 指数均至多为 $1$ 且不能同时为 $1$，局部因子为
\[
 U_p=(1-p^{-1})^2+2(1-p^{-1})(p^{-1}-p^{-2})
 =1-3p^{-2}+2p^{-3}
 =\frac{(p-1)^2(p+2)}{p^3}.
\tag{5}
\]
若 $p\mid q$，两指数都必须等于 $1$，局部因子为
\[
 V_p=(p^{-1}-p^{-2})^2=\frac{(p-1)^2}{p^4},
\qquad \frac{V_p}{U_p}=\frac1{p(p+2)}.
\tag{6}
\]
因此，以 note 891 式 (21) 的 $C_o=\frac14\prod_{p\ge3}U_p=d_o^2\Theta_o$ 为基准，
\[
 D_q=C_oA(q).
\tag{7}
\]
奇–偶、偶–奇的平方自由配对若精确 gcd 为 $q$，其 $2$ 局部因子为 $(1/2)(1/4)=1/8$，所以密度均为 $D_q/2$。偶–偶配对若精确 gcd 为 $2q$，其 $2$ 局部因子为 $(1/4)^2=1/16$，所以密度为 $D_q/4$。

这些密度也由有误差的计数给出，而不只是假定局部独立。以奇–奇为例，写 $m=qu$、$n=qv$。因 $q$ 固定平方自由，活动配对满足 $u,v$ 为奇平方自由数且 $(u,q)=(v,qu)=1$。固定 $u$ 后，note 891 式 (17) 在 $v$ 的任意前缀区间给
\[
\sum_{\substack{v\in I\\(v,2qu)=1}}\mu^2(v)
=\rho_o(qu)|I|+O_q(M^{1/2+\epsilon}),
\qquad \rho_o(qu)=\rho_o(q)\prod_{p\mid u}\frac p{p+1}.
\tag{8}
\]
对外端 $u$ 置
\[
 h_q(u)=\mathbf1_{(u,2q)=1}\mu^2(u)\prod_{p\mid u}\frac p{p+1}.
\]
其 Dirichlet 级数为 $\zeta(s)B_q(s)$；对 $p\nmid2q$，$B_q$ 的局部因子是 note 891 式 (18) 的
$1-p^{-s}/(p+1)-p^{1-2s}/(p+1)$，而对 $p\mid2q$ 因子为 $1-p^{-s}$。因为 $q$ 固定，$B_q$ 的系数在每个 $\Re s>1/2$ 绝对可和。取整与固定 BV 权分部求和遂给
\[
\sum_{M<qu<2M}h_q(u)|f(qu/M)|^2
=B_q(1)\frac Mq I_\psi+O_{q,\psi,\epsilon}(M^{1/2+\epsilon}).
\tag{9}
\]
内端 $v$ 的物理间距是 $q$，故由 (8)–(9) 得到密度 $\rho_o(q)B_q(1)/q^2$。对 $q=1$ 它正是 $C_o$；每增加一个奇素数 $p\mid q$，比值为
\[
\frac1{p^2}\frac p{p+1}
\frac{1-p^{-1}}{(1-p^{-1})(1+1/(p+1))}
=\frac1{p(p+2)},
\]
再次得到 (7)。奇–偶、偶–奇和偶–偶分别把一个或两个变量写为二倍奇数，证明上述 $1/2$、$1/4$ 因子，计数误差仍为 $O_{q,\epsilon}(M^{1/2+\epsilon})$。

把 note 891 式 (14) 的核分部求和、$f$ 冻结和 Poisson 公式用于这些计数，平方自由 $Q$–$Q$ 子 Gram 的主系数由各密度乘通道系数给出。相对于 $L/B$，余项至多
\[
O_{q,\psi,\eta,\epsilon}\!\left(\frac{M^{1/2+\epsilon}}L+
\frac LM+H^{-A}\right)
=O_{q,\psi,\eta,\epsilon}(M^{-1/10+\epsilon}),
\tag{10}
\]
其中固定选 $A>2$，$L\gg M^{3/5}$。这一固定幂误差可吸收到式 (2) 的次指数误差。

## 素数与 Möbius 通道

在 $0<n-m\le2L=o(M)$ 内，奇素数 $p\asymp M$ 与另一不同位置的物理 gcd 必为 $1$。二倍奇素数 $2p\asymp M$ 与邻近奇位置的 gcd 也为 $1$，与邻近偶位置的 gcd 必为 $2$：若还有共同因子 $p$，两不同位置至少相距 $p\asymp M$。因此素数通道只出现在 $g=1,2$。

对任何固定平方自由 $g$，Möbius 通道在一个端点的精确 gcd 条件可化为短和。固定另一个端点 $m=gu$，写内端 $n=gv$。条件 $(m,n)=g$ 等价于 $(u,v)=1$，而 $\mu(gv)$ 非零时还须 $(v,g)=1$。故
\[
\sum_{\substack{n\in I\\(m,n)=g}}\mu(n)
=\mu(g)\sum_{v\in I/g}\mu(v)\mathbf1_{(v,m)=1}.
\tag{11}
\]
对固定 $g$，note 891 式 (24) 的卷积证明可在位置 $\asymp M/g$、长度 $\asymp L/g$ 重用：其中模数 $m\le2M=2g(M/g)$，比该式原参数的模数范围只多一个固定的 $g$ 倍，$E_\sigma(m)=M^{o(1)}$ 的估计不变；常数及充分大阈值允许依赖 $g$。于是对任意前缀，右侧为 $O_g((L/g)e^{-cV_M})$。在核上作离散分部求和后，凡有 Möbius 端点的有向子 Gram 均为 $O_g((L/B)e^{-cV_M})$。若 Möbius 在左端，固定右端并对左端的反向区间使用同一估计。

对于 $g=1$，奇–奇的素数–素数、两个素数–平方自由交叉和平方自由–平方自由主系数依次为 $16,-16,-16,16\Theta_o$，合为 $-16(1-\Theta_o)$。奇–偶和偶–奇的每个方向对应四个系数为 $-4,+4,+4,-4\Theta_o$，各合为 $+4(1-\Theta_o)$；偶–偶的 gcd 不可能为 $1$。故总系数为 $-8(1-\Theta_o)$，与 note 891 式 (9c) 一致。对于 $g=2$，只有偶–偶配对。素数–素数主系数为 $+1$；两个素数–平方自由交叉分别为 $-1$；由 (7) 的偶–偶密度 $D_1/4$，平方自由–平方自由主系数为
$(-3\zeta(2))^2D_1/4=\Theta_o$。加上 (11) 的 Möbius 误差，得到 $1-1-1+\Theta_o=-(1-\Theta_o)$。

若 $g=q>1$ 为奇数，只有 $Q$–$Q$ 主项。奇–奇主系数为
$(6\zeta(2))^2D_q=16\Theta_oA(q)$；两种混合方向各为
$(6\zeta(2))(-3\zeta(2))D_q/2=-4\Theta_oA(q)$。三项合计 $8\Theta_oA(q)$。若 $g=2q$ 且 $q>1$，只有偶–偶主项，为
$(-3\zeta(2))^2D_q/4=\Theta_oA(q)$。这证明 (2)。

当 $g>2$，素数通道全部消失，其余通道在平方自由位置有绝对常数界。又 $g\mid n-m$ 使 $g\le2L=o(M)$，所以每个 $g$ 的活动配对至多
$O((M/g)(L/g))$ 个。用 $|K_{H,M}|\ll H$、$|a_m^{(w)}|\ll_\psi M^{-1}$，对 $g>G$ 求和即得 (3)。最后
\[
\sum_{\substack{q\ge1\\q\text{ 奇平方自由}}}A(q)
=\prod_{p\ge3}\left(1+\frac1{p(p+2)}\right)
=\Theta_o^{-1},
\tag{12}
\]
因为式 (5)–(6) 给 $U_p+V_p=(1-p^{-2})^2$。将 (2) 的主项求和并用 (3) 控制固定层以外的尾部，得到 (4)。$\square$

## gcd 主系数尾的尖锐渐近

式 (3) 的 $1/G$ 阶数对**主系数的 Euler 尾**不可改进。对实数 $G\ge2$，把式 (2) 中所有 $g\le G$ 的主系数相加，记为 $C_{\le G}$。令
\[
\mathscr S(t)=\sum_{\substack{q>t\\q\text{ 奇平方自由}}}A(q),\qquad
\mathfrak b=\frac12\prod_{p\ge3}
\left(1-\frac1p\right)\left(1+\frac1{p+2}\right)>0.
\tag{13}
\]
则
\[
\boxed{\quad
C_{\le G}=-\Theta_o\{8\mathscr S(G)+\mathscr S(G/2)\}
=-\frac{10\Theta_o\mathfrak b}{G}
+O_\epsilon(G^{-3/2+\epsilon}).
\quad}\tag{14}
\]
尤其每个有限 $G\ge2$ 的截断主系数严格为负。这个渐近只针对**先取固定 $g$ 的极限后所得的主系数序列**；它没有断言 $G=G(M)$ 增长时真实 $T_{ww}^{[g]}(L)$ 仍有一致的渐近。因此它量化了逐层主项法需要支付的尾，却不单独给 note 849 式 (15) 的固定幂余量。

对每个**固定** $G\ge2$，note 891 式 (5) 的不限 gcd 主项为零，而式 (2) 可对有限个 $g\le G$ 求和。于是实际有向 Gram 的余尾满足
\[
\sum_{g>G}T_{ww}^{[g]}(L)
=\Theta_o\{8\mathscr S(G)+\mathscr S(G/2)\}I_\psi J_M(L)
+O_G\!\left(\frac LB e^{-c_GV_M}\right).
\tag{14a}
\]
若 $I_\psi>0$，先令 $M\to\infty$ 再令 $G\to\infty$，(14)–(14a) 还说明式 (3) 的绝对尾界在 $1/G$ 的阶数上是尖锐的；这里仍没有交换 $G\to\infty$ 与 $M\to\infty$。

证明令
\[
b(q)=\mathbf1_{2\nmid q}\mu^2(q)
\prod_{p\mid q}\frac p{p+2},
\qquad A(q)=\frac{b(q)}{q^2}.
\]
在 $\Re s>1$，其 Dirichlet 级数为 $\zeta(s)D(s)$，其中
\[
D(s)=(1-2^{-s})\prod_{p\ge3}
\left(1-\frac{2p^{-s}}{p+2}-\frac{p^{1-2s}}{p+2}\right).
\tag{15}
\]
每个非平凡局部系数的绝对值分别为 $2/(p+2)$ 与 $p/(p+2)$，所以 $D$ 的 Dirichlet 系数在任意 $\Re s>1/2$ 绝对可和。以 $b=1*d$ 取整求和，任意固定 $\epsilon>0$ 给
\[
\sum_{q\le x}b(q)=D(1)x+O_\epsilon(x^{1/2+\epsilon}),
\qquad D(1)=\mathfrak b.
\tag{16}
\]
对 (16) 分部求和得 $\mathscr S(t)=\mathfrak b/t+O_\epsilon(t^{-3/2+\epsilon})$。式 (4) 的全体主系数和为零；在 $g>G$ 的遗漏层中，奇 $q$ 层权为 $8\Theta_o A(q)$，偶 $2q$ 层权为 $\Theta_o A(q)$。故其和为 $\Theta_o[8\mathscr S(G)+\mathscr S(G/2)]$，取负即为 (14)。$\square$

## 次指数增长 gcd 截断的真实余尾

固定 $I_\psi>0$。存在仅依赖观察权族的统一界和短和输入的 $c_*>\alpha_*>0$，使对全部充分大 $M$、全部允许的 $H,L$ 及
\[
2\le G\le e^{\alpha_*V_M}
\tag{17}
\]
一致有
\[
\boxed{\quad
\sum_{g>G}T_{ww}^{[g]}(L)
=\Theta_o\{8\mathscr S(G)+\mathscr S(G/2)\}I_\psi J_M(L)
+O_{\psi,\eta}\!\left(\frac LB e^{-c_*V_M}\right),
\quad}\tag{18}
\]
因此
\[
\boxed{\quad
\Re\sum_{g>G}T_{ww}^{[g]}(L)
\asymp_{\psi,\eta}\sum_{g>G}|T_{ww}^{[g]}(L)|
\asymp_{\psi,\eta}\frac{L/B}{G}.
\quad}\tag{19}
\]
第二个比较中的上界是式 (3)；第一个比较指两者各自与同一正量 $ (L/B)/G$ 可比，并非逐项同号。这把式 (14a) 的固定 $G$ 量词推进到一个真实增长区间，仍远小于支付目标所需的任何固定幂 $G=M^\delta$。

证明先把平方自由–平方自由项的式 (8)–(10) 对 $q\le e^{\alpha_*V_M}$ 一致求和。对奇平方自由 $q$、外端 $m=qu$，内端的前缀计数误差可保持为
\[
O\!\left(\tau(2qu)\sqrt{M/q}\right).
\]
因 $\tau(qu)\le\tau(q)\tau(u)$ 且
$\sum_{u\le x}\tau(u)\ll x\log(2x)$，先对 $u\asymp M/q$ 求和、再用核的 $O(H)$ 变差界并乘归一化因子 $M^{-2}$，全部 $q\le G$ 的内端误差至多
\[
O\!\left(\frac H{\sqrt M}\log(2M)
\sum_{q\ge1}\frac{\tau(q)}{q^{3/2}}\right)
\ll \frac{L}{B}\frac{\sqrt M\log(2M)}L.
\tag{20}
\]
这里 $\sum\tau(q)q^{-3/2}=\zeta(3/2)^2<\infty$。偶端把 $q$ 换成 $2q$，只改变绝对常数。

外端 $h_q(u)$ 的级数仍为 $\zeta(s)B_q(s)$。对任意固定 $\sigma=1/2+\epsilon<1$，其 Euler 因子在 $p\nmid2q$ 的 Dirichlet 系数绝对范数乘积由一个只依赖 $\sigma$ 的常数控制；在 $p\mid2q$ 的因子是 $1-p^{-s}$。因此
\[
\sum_d\frac{|b_q(d)|}{d^\sigma}
\ll_\sigma\prod_{p\mid q}(1+p^{-\sigma})
\le\tau(q),
\]
而式 (9) 可一致加强为
\[
\sum_{M<qu<2M}h_q(u)|f(qu/M)|^2
=B_q(1)\frac Mq I_\psi
+O_{\psi,\epsilon}\!\left(\tau(q)(M/q)^{1/2+\epsilon}\right).
\tag{21}
\]
将 (21) 代入内端主项，按 $q$ 求和后的归一化误差为
$O_{\psi,\epsilon}((L/B)M^{-1/2+\epsilon})$，因为
$\sum_q\tau(q)q^{-3/2-\epsilon}<\infty$。冻结 $f(n/M)$ 的代价由所有活动配对数 $\ll ML\sum_g g^{-2}$ 给
$O((L/B)(L/M))$；Poisson 非零别名给
$O_A((L/B)H^{-A})$。取固定小 $\epsilon$，使用
$L\gg M^{3/5}$、$L/M\ll H^{-1}\ll M^{-1/5}$，可将这些平方自由误差合并为
\[
\sum_{3\le g\le G}
\left|T_{QQ}^{[g]}-\kappa_g I_\psi J_M(L)\right|
\ll_{\psi,\eta}\frac LB M^{-1/20},
\tag{22}
\]
其中 $T_{QQ}^{[g]}$ 是只取两个平方自由通道的对应层，$\kappa_q=8\Theta_oA(q)$、$\kappa_{2q}=\Theta_oA(q)$，并约定非平方自由层为零。式 (20)–(22) 对 (17) 中的 $G$ 一致。

接着统一处理含 Möbius 的项。设 $g\le e^{\alpha_*V_M}$ 为平方自由、$X=M/g$，并在式 (11) 中取 $m\le2M$。把 note 891 式 (25) 的卷积按除数 $d\le X^{1/8}$ 与 $d>X^{1/8}$ 分开；note 851 式 (4) 取 $\nu=59/100$，与 note 891 式 (26) 的 $E_\sigma(m)$ 估计给任意内端前缀
\[
\begin{aligned}
\left|\sum_{v\in I/g}\mu(v)\mathbf1_{(v,m)=1}\right|
\ll{}&(L/g)e^{-c_0V_M}E_1(m)
+X^\nu E_\nu(m)+X^{1/2}E_{1/2}(m)\\
&+(L/g)X^{-1/32}E_{3/4}(m).
\end{aligned}
\tag{23}
\]
这里 $V_{X/d}\gg V_M$ 在 $d\le X^{1/8}$ 上一致；式 (23) 的 $c_0>0$ 已吸收这个固定比例。因 $E_1(m)\ll(\log M)^C$、$E_\sigma(m)=M^{o(1)}$ 对固定 $0<\sigma<1$ 一致成立，而
$L/g\gg M^{3/5}e^{-\alpha_*V_M}$，后三项相对于 $L/g$ 都有固定幂节省。缩小 $c_0$ 得某个与 $g,m,H,L$ 无关的 $c_1>0$，使式 (23) 为 $O((L/g)e^{-c_1V_M})$。核分部求和后，对 $g>2$ 每个外端的其他通道系数有界，外端至多 $O(M/g)$ 个；故全部 $g\le G$ 的含 Möbius 项总和为
\[
O_{\psi,\eta}\!\left(\frac LB e^{-c_1V_M}
\sum_{g\ge1}g^{-2}\right).
\tag{24}
\]
$g=1,2$ 的素数端点由式 (2) 的既有短和证明支付。结合 (22)、(24) 及式 (2) 的 $g=1,2$ 主项，得到
\[
\sum_{g\le G}T_{ww}^{[g]}(L)
=C_{\le G}I_\psi J_M(L)
+O_{\psi,\eta}\!\left(\frac LB e^{-c_2V_M}\right)
\tag{25}
\]
（某个固定 $c_2>0$）。从 note 891 式 (5) 的完整 $w$–$w$ Gram 扣除 (25)，再用 (14)，得到 (18)，可取 $0<\alpha_*<c_*<c_2$。

最后式 (16) 及有限个小 $G$ 的正性给
$8\mathscr S(G)+\mathscr S(G/2)\asymp1/G$，一致于 $G\ge2$；而 $J_M(L)\asymp L/B$。由 (17) 且 $\alpha_*<c_*$，式 (18) 的误差严格小于其正主项，得到 (19)。$\square$

### 直接分析高 gcd 尾的固定幂范围

式 (18) 通过“完整 Gram 减低 gcd 层”得出，因而继承了 $g=1,2$ 的素数短和误差。直接在 $g>G\ge2$ 上工作可把增长范围扩大为固定幂：对每个固定 $0<\beta<1/25$，存在 $c_\beta>0$，使
\[
\boxed{\quad
\sum_{g>G}T_{ww}^{[g]}(L)
=\Theta_o\{8\mathscr S(G)+\mathscr S(G/2)\}I_\psi J_M(L)
+O_{\psi,\eta,\beta}\!\left(\frac{L/B}{G}e^{-c_\beta V_M}\right)
\quad}\tag{26}
\]
对全部允许的 $H,L$ 与 $2\le G\le M^\beta$ 一致成立。若 $I_\psi>0$，这个范围内式 (19) 的两个比较仍成立。特别对任意固定 $0<\beta_0\le\beta<1/25$，式 (14) 给 $M^{\beta_0}\le G\le M^\beta$ 上真实尾的显式主常数
\[
\sum_{g>G}T_{ww}^{[g]}(L)
=\frac{10\Theta_o\mathfrak b}{G}I_\psi J_M(L)
+O_{\psi,\eta,\beta_0,\beta}\!\left(\frac{L/B}{G}e^{-c_\beta'V_M}\right)
\tag{26a}
\]
（某个 $c_\beta'>0$）。这里对**随 $M$ 作固定幂增长的真实截断**给出正尾渐近；$1/25$ 是下述特定短和误差在最短允许 $L$ 上给出的上限，不宣称为实际最优边界。

证明固定 $\beta<\tau<(3/5-\nu)/(1-\nu)$，其中 $7/12<\nu<3/5$ 取得足够接近 $7/12$；这样的 $\nu,\tau$ 正因 $\beta<1/25$ 而存在。置 $T=\lfloor M^\tau\rfloor$。式 (23) 的卷积证明可把短和指数 $59/100$ 改为 note 851 式 (4) 所允许的任意固定 $\nu>7/12$。对 $g\le T$，$X=M/g\ge M^{1-\tau}$，而 $d\le X^{1/8}$ 时 $X/d\ge M^{(1-\tau)7/8}$，故 $V_{X/d}\gg_{\tau} V_M$。由 $L\gg M^{3/5}$、$E_\sigma(m)=M^{o(1)}$，改取 $\nu$ 后式 (23) 中相对于 $L/g$ 的后三项分别至多
\[
M^{\nu-3/5+o(1)}g^{1-\nu},\qquad
M^{-1/10+o(1)}g^{1/2},\qquad
(M/g)^{-1/32}M^{o(1)}.
\tag{27}
\]
在 $g\le T$ 上它们均有固定幂节省；第一项的指数裕量是 $3/5-\nu-\tau(1-\nu)>0$。式 (23) 首项中的 $E_1(m)\ll(\log M)^C$ 可吸入较小的次指数常数。因此每个 $G<g\le T$ 的含 Möbius 子项，按式 (24) 的逐层估计求和，总量为
\[
O_{\psi,\eta,\beta}\!\left(\frac{L/B}{G}e^{-c_4V_M}\right)
\tag{28}
\]
（某个 $c_4=c_4(\beta)>0$）。该区间没有素数或二倍素数端点。

对平方自由–平方自由项，把式 (20)–(22) 的求和限制在 $G<g\le T$。任意固定小 $\epsilon>0$ 下，$\sum_{q>G/2}\tau(q)q^{-3/2}\ll_\epsilon G^{-1/2+\epsilon}$，所以它们与对应密度主项的差至多
\[
O_{\psi,\eta,\epsilon}\!\left(
\frac LB\left[
\frac{\sqrt M\log(2M)}L G^{-1/2+\epsilon}
+M^{-1/2+\epsilon}G^{-1/2+\epsilon}
+\frac{L/M+H^{-A}}G
\right]\right).
\tag{29}
\]
若 $G\le M^\beta$，因 $\beta<1/25<1/5$ 且 $L\gg M^{3/5}$，式 (29) 相对于 $(L/B)/G$ 有固定幂节省。对 $g>T$，式 (3) 将真实尾绝对界为 $O((L/B)/T)$；式 (13)–(16) 对遗漏密度主项也给 $O((L/B)/T)$。由于 $G/T\ll M^{\beta-\tau}$，这两项相对于 $(L/B)/G$ 同样有固定幂节省。把区间 $G<g\le T$ 的主项与 $g>T$ 的形式主项合并，得到式 (26)：所有固定幂误差都可吸入缩小常数后的 $e^{-c_\beta V_M}$。由 (16)、$J_M(L)\asymp L/B$ 与式 (3) 再得绝对尾的比较。$\square$

同一证明还给出随位移长度改善的范围。若固定 $3/5\le\lambda<4/5$，并在原假设外另有 $L\ge M^\lambda$，则对每个固定
\[
0<\beta<\frac{12\lambda-7}{5}
\tag{30}
\]
式 (26)–(26a) 及式 (19) 的结论仍成立，其中次指数常数可依赖 $\lambda,\beta$。事实上只需在 (27) 中把 $3/5$ 换成 $\lambda$，再选
$\beta<\tau<(\lambda-\nu)/(1-\nu)$、$\nu>7/12$ 足够接近 $7/12$；其可选条件恰是 (30)。式 (29) 的首项除以 $(L/B)/G$ 后至多为 $M^{1/2-\lambda+\beta(1/2+\epsilon)+o(1)}$，仍有固定幂节省，因为 $(12\lambda-7)/5<2\lambda-1$ 对 $\lambda<1$ 成立。式 (27) 的第二项也由 $\tau<(\lambda-\nu)/(1-\nu)<2\lambda-1$ 得到固定幂节省，其余估计不变。

特别在 $H=Y^{1/5}$、$L=\lfloor M^{3/5+\delta}\rfloor$、$0<\delta<1/5$、$G=\lfloor M^\delta\rfloor$ 时，取 $\lambda=3/5+\delta/2$，则充分大时 $L\ge M^\lambda$。因
$\delta<(12\lambda-7)/5=1/25+(6/5)\delta$，可在 (30) 中选一个 $\beta>\delta$，再取 $0<\beta_0<\delta$ 以应用 (26a)。于是对 $I_\psi>0$，真实正尾的显式主项为
\[
\sum_{g>G}T_{ww}^{[g]}(L)
=\frac{10\Theta_o\mathfrak b}{G}I_\psi J_M(L)
+O_{\psi,\eta,\delta}\!\left(\frac{L/B}{G}e^{-c_\delta V_M}\right)
\tag{31}
\]
这里 $G\asymp L/H^3$，且 $J_M(L)\asymp L/B$，故 (31) 左侧的实部 $\asymp_{\psi,\eta,\delta}H^4/M$，在这一自然截断处正好落在 note 849 式 (15) 的目标量级；它仍只涉及 $w$ 的高 gcd 有向子 Gram。

## 边界

逐 gcd 层出现的正负主项均为 $L/B$ 量级。若 $H=Y^{1/5}$、$L=M^{3/5+\delta}$，它们各自超过 note 849 式 (15) 的 $H^4M^{-1+\varepsilon}$ 目标（$0<\varepsilon<\delta$）。式 (26) 证明每个固定 $\beta<1/25$、$G=M^\beta$ 的**真实**高 gcd 余尾为 $\asymp M^{-1/5+\delta-\beta}$；若 $\delta-\varepsilon\le\beta$，这部分 $w$–$w$ 余尾落在目标量级内。式 (26) 不支付 $g\le G$ 的固定幂 signed 误差，式 (2) 与 (25) 的次指数误差对此仍不够；实际剩余对象仍是低 gcd 层与三个算术通道的联合 signed Gram。note 889 的 $c\mapsto w$ 误差仅作用于不限 gcd 的硬窗口，不能逐层套用。本 note 不证明 note 849 式 (15) 的完整界、全尺度局部 Weil 正性或 RH。
