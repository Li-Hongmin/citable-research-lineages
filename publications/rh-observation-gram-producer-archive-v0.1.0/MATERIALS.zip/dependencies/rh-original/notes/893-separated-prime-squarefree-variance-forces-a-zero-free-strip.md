> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 单独支付双臂素数–平方自由均方所需的零自由带

日期：2026-10-03。**证明草案，独立只读复核通过，异源复核未完成。**依赖 [note 891](891-squarefree-parity-arms-cancel-prime-density-on-positive-collar.md) 的真实双臂 $F$ 系数、[note 869](869-three-channel-short-interval-variance-forces-a-zeta-derivative-gate.md) 的滑动窗口平方和引理，以及 [note 849](849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的目标量纲。外部比较只使用 Zaccagnini, *Primes in almost all short intervals*, *Acta Arith.* **84** (1998), 225–244, DOI 10.4064/aa-84-3-225-244，原版 PDF 第 225 页定理；它给对数尺度节省。本文区分“由已有均方定理可得的界”和“若更强输入成立将推出的零自由结论”，不假设所需固定幂界成立。

## 命题

对每个 $m\ge1$ 定义 note 891 的双臂系数，有限个小整数也按下式解释：
\[
F_*(m)=-4\mathbf1_{m=p\ge3}\log p
+2\mathbf1_{m=2p,\ p\ge3}\log p
+6\zeta(2)\mathbf1_{2\nmid m}\mu^2(m)
-3\zeta(2)\mathbf1_{2\mid m}\mu^2(m).
\tag{1}
\]
在 $m\asymp M\to\infty$，它正是 note 891 的 $F_{\rm phys}=P_o+Q_o+P_e+Q_e$。令 $C_F(x)=\sum_{m\le x}F_*(m)$，固定 $\kappa>0$，$B_X=\lfloor\kappa X^{4/5}\rfloor$。

若对每个 $\varepsilon>0$、全部充分大整数 $X$ 有
\[
\sum_{X\le x\le2X}
|C_F(x+B_X)-C_F(x)|^2
\ll_{\kappa,\varepsilon}X^{12/5+\varepsilon},
\tag{2}
\]
则对每个 $\varepsilon>0$，
\[
C_F(x)\ll_{\kappa,\varepsilon}x^{9/10+\varepsilon},
\tag{3}
\]
并且 Riemann $\zeta$ 函数在 $\Re s>9/10$ 没有非平凡零点。特别地，试图先用式 (2) 单独支付 $F$–$F$ 的短窗口均方，必须建立一个固定宽度的零自由带。式 (2) 是支付观察频带的一种**充分输入**，不是 note 849 的带限目标所必需的条件。

同一论证具有一般指数形式：若 $0<\theta<1$、$0<\delta\le\min\{1,2(1-\theta)\}$，把 $B_X$ 换成 $\lfloor\kappa X^\theta\rfloor$ 并把 (2) 的右侧换成 $X^{1+2\theta-\delta+\varepsilon}$，则 $C_F(x)\ll_\varepsilon x^{1-\delta/2+\varepsilon}$，从而 $\zeta$ 在 $\Re s>1-\delta/2$ 零自由。固定幂均方节省 $\delta$ 直接对应宽度 $\delta/2$ 的零自由带。

另一方面，Zaccagnini 的已发表 Selberg 积分上界与初等平方自由计数给本系数的无条件估计
\[
\sum_{X\le x\le2X}
|C_F(x+B_X)-C_F(x)|^2
\ll_\kappa
X^{13/5}\left(\frac{\log\log X}{\log X}\right)^2+X^2\log^C X
\tag{4}
\]
（某个固定 $C>0$）。它比式 (2) 的 $X^{12/5+\varepsilon}$ 目标大 $X^{1/5-o(1)}$。通过 note 849 式 (26) 的短窗口 Parseval 传递，式 (4) 单独只给对数尺度频带能量界，不给 $H^4/M\asymp M^{-1/5}$。

## 证明

由 $|F_*(m)|\ll\log(2m)$，note 869 式 (6) 的路径分摊论证可直接用于 $C_F$：在每个 dyadic 区间，任意两端的差至多
\[
O\!\left(B_X\log X+
\sqrt{\frac X{B_X}+1}\sqrt{\frac1{B_X}
\sum_{X\le x\le2X}|C_F(x+B_X)-C_F(x)|^2}\right)
=O_\varepsilon(X^{9/10+\varepsilon}).
\]
跨 dyadic 区间相加证明 (3)。一般指数版本中，上式两项的幂次分别为 $\theta$ 和 $1-\delta/2$；假设 $\delta\le2(1-\theta)$ 保证后者较大，同样的 dyadic 论证给所述一般结论。故 $\sum_mF_*(m)m^{-s}$ 在 $\Re s>9/10$ 局部一致收敛，定义全纯函数；一般版本的全纯半平面为 $\Re s>1-\delta/2$。

为找出它在零点处的极点，在 $\Re s>1$ 记
$P(s)=\sum_p(\log p)p^{-s}$。平方自由整数的 Dirichlet 级数是 $\zeta(s)/\zeta(2s)$；只保留奇数再除以 $1+2^{-s}$，偶平方自由部分再乘 $2^{-s}$。因此式 (1) 的 Dirichlet 级数精确为
\[
\mathcal F(s)=(-4+2^{1-s})\bigl(P(s)-(\log2)2^{-s}\bigr)
+3\zeta(2)(2-2^{-s})
\frac{\zeta(s)}{\zeta(2s)(1+2^{-s})}.
\tag{5}
\]
又
\[
P(s)=-\frac{\zeta'(s)}{\zeta(s)}-R(s),
\qquad R(s)=\sum_p\sum_{j\ge2}(\log p)p^{-js},
\tag{6}
\]
其中 $R$ 在 $\Re s>1/2$ 绝对收敛。式 (5) 在 $s=1$ 的素数极点留数为 $-3$，平方自由极点留数为 $+3$，故该点可去。若 $\rho$ 是 $\Re\rho>9/10$ 的 $\zeta$ 零点，$\zeta(2\rho)\ne0$，式 (5) 的平方自由项在 $\rho$ 全纯；由 (6)，素数项在 $\rho$ 的留数是
\[
\operatorname{ord}_\rho(\zeta)\,(4-2^{1-\rho})\ne0,
\tag{7}
\]
因为 $|2^{1-\rho}|<2^{1/10}<4$。这与 (3) 给出的全纯性矛盾，证明零自由结论。

最后核对 (4)。Zaccagnini 第 225 页定理对 $h\asymp X^{4/5}$ 允许取其 $\epsilon(X)=0$；将其后向窗口 $[t-h,t]$ 平移为前向窗口 $[x,x+h]$，再用相邻两个 dyadic 区间覆盖平移后的积分域，给
\[
\int_X^{2X}\left|\pi(t)-\pi(t-h)-\frac h{\log t}\right|^2dt
\ll \frac{Xh^2}{\log^2X}
\left(\frac{\log\log X}{\log X}\right)^2.
\tag{8}
\]
在 $t\asymp X$、$h\asymp X^{4/5}$ 上，把素数计数乘以 $\log t$，与窗口中的 $\sum_p\log p$ 的差至多 $O(h^2/X)$；其平方积分 $O(h^4/X)$ 被 (4) 的首项吸收。素数幂在任何此类窗口内的总 $\Lambda$ 质量至多 $O(\sqrt X\log^2X)$。对 (8) 使用平方三角不等式，便得两个物理素数臂的中心化滑动和的平方积分 $\ll Xh^2(\log\log X/\log X)^2+X^2\log^C X$，二倍素数臂以 $t=2u$ 换元，窗口长度变为 $h/2$。平方自由奇、偶计数在任何窗口的误差都是 $O(\sqrt X)$，其主密度分别为 $4/\pi^2$、$2/\pi^2$，经 (1) 乘系数得到 $+4$、$-1$；两个素数臂的主密度为 $-4$、$+1$，四者合为零。平方自由误差的滑动平方和为 $O(X^2)$。整数端点与实积分只差 $O(X\log^2X)$，得到 (4)。$\square$

## 适用边界

对 $H\asymp M^{1/5}$，note 849 式 (26) 的窗口长 $L\asymp M^{4/5}$，式 (2) 恰是可经 Parseval 支付 $M^{-1/5+\varepsilon}$ 的量纲。式 (4) 传递后只到 $(\log\log M/\log M)^2$。因此 Zaccagnini 的实际定理不能独立支付 $F$–$F$；这不排除利用整个频带的选择性抵消，也不排除 $F$ 与 Möbius 通道的联合 signed 估计。本文既没有证明式 (2)，也没有证明 RH。
