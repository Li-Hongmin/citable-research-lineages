> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 真实 Haar 门的普通位移式与固定阶窗口差的低频泄漏

日期：2026-10-03。依赖 [note 849](849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实系数与目标频带、[note 851](851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 的全区间短和、[note 870](870-adjacent-window-haar-gate-for-the-three-channel-observation-band.md) 的相邻窗口门。前两节处理真实算术系数，末节给确定性反模型；它们都不证明 note 870 式 (4)，更不证明 RH。

## 真实系数的周期拼接可在目标尺度内删除

沿整数 \(Y\to\infty\)，令 \(M=2Y\)、\(Y^{1/5}\le H\le Y^{1/4}\)、\(L=\lfloor M/(32H)\rfloor\)，并取 note 849 式 (10) 的真实 \(c(m)\)。定义零延拓
\[
b_x=\begin{cases}c(M+x),&0\le x<M,\\0,&x\notin[0,M),\end{cases}
\qquad
V_H^{\rm lin}=
\sum_{x\in\mathbb Z}
\left|\sum_{j=0}^{L-1}b_{x-j}-\sum_{j=L}^{2L-1}b_{x-j}\right|^2.
\tag{1}
\]
令 \(V_H^{\rm cyc}\) 为 note 870 式 (2) 的模 \(M\) Haar 方差。存在固定 \(c_0>0\)，记 \(V_Y=(\log Y/\log\log Y)^{1/3}\)，则一致于上述 \(H\)，
\[
\boxed{\quad
|V_H^{\rm cyc}-V_H^{\rm lin}|
\ll \frac{Y^3}{H^3}e^{-2c_0V_Y}
      +\frac{Y^{7/3}\log^2(2Y)}{H}
=o(H^2Y^2).
\quad}\tag{2}
\]
因此 note 870 式 (4) 的 \(O_\varepsilon(H^2Y^{2+\varepsilon})\) 门可等价地用 \(V_H^{\rm lin}\) 表述。后者有不含模 \(M\) 回绕配对的**精确**相关式。置
\[
\mathcal C_Y(k)=\sum_{m=M}^{2M-1-k}c(m)c(m+k)
\quad(0\le k<M),
\qquad
w_L(k)=\begin{cases}2L-3k,&1\le k<L,\\k-2L,&L\le k<2L,\end{cases}
\]
则
\[
\boxed{\quad
V_H^{\rm lin}=2L\mathcal C_Y(0)
  +2\sum_{k=1}^{2L-1}w_L(k)\mathcal C_Y(k).
\quad}\tag{3}
\]
式 (2) 支付的只是周期拼接；式 (3) 中普通整数位移的联合带符号和仍未得到目标上界。
此处用到真实算术短和：若把 \(c(m)\) 换成恒为一的序列，则周期方差为零，而零延拓的线性方差精确为 \((4L^3+2L)/3\)。

更明确地，取 \(K_0=\lfloor H^3/\log^2(2Y)\rfloor\)。对角及全部 \(1\le k\le K_0\) 的普通位移均可无符号支付，故
\[
\boxed{\quad
V_H^{\rm cyc}
=2\sum_{K_0<k<2L}w_L(k)\mathcal C_Y(k)
+o(H^2Y^2).
\quad}\tag{3a}
\]
式 (3a) 的余项对 \(Y^{1/5}\le H\le Y^{1/4}\) 一致；剩余中距离和仍须联合估计，不能逐项取绝对值。

**证明。** 取 \(Q=\lfloor Y^{2/3}\rfloor\)。note 851 式 (5)、(7) 给每个包含于 \([M,2M)\) 的长 \(Q\) 整数区间 \(I\) 一致界
\(|\sum_{m\in I}c(m)|\ll Qe^{-c_0V_Y}\)。任意长不超过 \(2L\) 的区间分为整 \(Q\) 块和至多两个余块，用 \(|c(m)|\ll\log(2Y)\) 支付余块，故
\[
\sup_{I\subset[M,2M),\ |I|\le2L}
\left|\sum_{m\in I}c(m)\right|
\ll Le^{-c_0V_Y}+Q\log(2Y)=:E_Y.
\tag{4}
\]
在 \(2L-1\le x<M\) 时，线性和周期 Haar 窗口完全相同。两种方差可能不同的 \(x\) 只在 \(0\le x<2L-1\) 以及线性式的 \(M\le x<M+2L-1\)，共不到 \(4L\) 个。每个这样的 Haar 和至多是四个 \([M,2M)\) 内普通区间和的带符号组合，故绝对值 \(\ll E_Y\)。将两组边界窗口的平方和分别上界，得到
\[
|V_H^{\rm cyc}-V_H^{\rm lin}|
\ll L E_Y^2
\ll L^3e^{-2c_0V_Y}+LQ^2\log^2(2Y),
\]
即 (2) 的大 \(O\) 部分。第一项除以 \(H^2Y^2\) 至多为 \(O(e^{-2c_0V_Y})\)，因为 \(Y/H^5\le1\)；第二项的比值 \(\ll Y^{1/3}H^{-3}\log^2(2Y)\le Y^{-4/15}\log^2(2Y)\to0\)。

对 (1) 展开平方并按两指标差 \(k\) 合并。长度 \(2L\) 的系数列前 \(L\) 项为 \(+1\)，后 \(L\) 项为 \(-1\)；其自身相关在 \(k=0\) 为 \(2L\)，在 \(1\le k<L\) 为 \(2L-3k\)，在 \(L\le k<2L\) 为 \(k-2L\)。零延拓使 \(k>0\) 的内层和恰为 \(\mathcal C_Y(k)\)，正负 \(k\) 两侧相同，证明 (3)。此外 note 870 已给 \(\mathcal C_Y(0)\ll Y\log(2Y)\)，而 Cauchy--Schwarz 给 \(|\mathcal C_Y(k)|\le\mathcal C_Y(0)\)。所以对角为 \(O(Y^2H^{-1}\log(2Y))=o(H^2Y^2)\)，且
\[
\sum_{1\le k\le K_0}|w_L(k)\mathcal C_Y(k)|
\ll LK_0Y\log(2Y)
\ll H^2Y^2/\log(2Y)=o(H^2Y^2).
\]
结合 (2) 便得 (3a)。\(\square\)

## 真实系数的低频支付及固定阶阈值

固定正整数 \(r\)，并沿用下面式 (5) 的 \(r\) 阶周期窗口差。令 \(P_{\le U}\) 为模 \(M\) 的 Fourier 投影，保留周期距离 \(\min(h,M-h)\le U\) 的频率，并置
\[
U_r=\left\lfloor Y^{1/5-1/(10r)}\right\rfloor.
\]
对真实 \(b_x=c(M+x)\) 的周期延拓，存在固定 \(c_1>0\)，一致于 \(Y^{1/5}\le H\le Y^{1/4}\) 有
\[
\boxed{\quad
\sum_{x\bmod M}|\mathsf H_{L,r}P_{\le U_r}b(x)|^2
\ll_r H^2Y^2 e^{-2c_1V_Y}
=o(H^2Y^2).
\quad}\tag{4a}
\]
特别地，真实 Haar 方差的 \(|h|\le Y^{1/10}\) 部分已在目标量级内支付。这个结论只删除低频，不能控制 \(Y^{1/10}<|h|\lesssim H\) 的真实带符号相关。

**证明。** note 851 式 (4) 对 \(\mu\)、\(\Lambda-1\) 的所有区间长度一致适用；把偶数指标换元，取其中的固定 \(\varepsilon=1/24\)，可对每个 \(I\subset[M,2M)\)、\(|I|\le Q=\lfloor Y^{2/3}\rfloor\) 写成
\[
\left|\sum_{m\in I}c(m)\right|
\ll |I|e^{-cV_Y}+Y^{5/8}.
\tag{4b}
\]
端点取整的 \(O(\log Y)\) 也被第二项吸收。每个模 \(M\) 的长 \(Q\) 窗口至多在周期拼接处裂为两个这样的区间，所以 (4b) 及 \(Y^{5/8}=o(Qe^{-c_1V_Y})\) 给
\[
\max_{x\bmod M}\left|\sum_{j=0}^{Q-1}b_{x-j}\right|
\ll Qe^{-c_1V_Y}
\]
（适当缩小 \(c_1>0\)）。记 \(B_Q(h)=\sum_{j=0}^{Q-1}e(-hj/M)\)。因为 \(U_rQ/M\ll Y^{-2/15}\to0\)，在 \(|h|\le U_r\) 有 \(|B_Q(h)|\gg Q\)。周期 Parseval 因而给
\[
\sum_{|h|\le U_r}\left|\frac{\widehat b(h)}M\right|^2
\ll \frac1{MQ^2}\sum_{x\bmod M}
\left|\sum_{j=0}^{Q-1}b_{x-j}\right|^2
\ll e^{-2c_1V_Y}.
\tag{4c}
\]
这里 \(|h|\) 取模 \(M\) 的最小绝对代表。对这些频率，(5) 的乘子满足
\[
|B_L(h)\{1-e(-hL/M)\}^r|
\ll_r L(U_r/H)^r.
\]
再次用 Parseval，(4a) 左侧至多为 \(M L^2(U_r/H)^{2r}e^{-2c_1V_Y}\)。最后
\(M L^2(U_r/H)^{2r}/(H^2Y^2)\ll YU_r^{2r}/H^{2r+4}\le1\)，证明 (4a)。\(\square\)

## 任意固定阶相邻窗口差都额外检测较低频率

固定正整数 \(r\)。对模 \(M\) 序列 \(v\) 定义 \(r\) 阶窗口差
\[
\mathsf H_{L,r}v(x)=
\sum_{a=0}^{r}(-1)^a{r\choose a}
\sum_{j=aL}^{(a+1)L-1}v_{x-j}.
\tag{5}
\]
这里 \(r=1\) 正是 note 870 的 Haar 差。取 \(H=\lceil Y^{1/5}\rceil\)、上述 \(L\)，并固定
\[
\frac15-\frac1{10r}<\alpha<\frac15,
\quad h_0=\lfloor Y^\alpha\rfloor,
\quad \delta_Y=e^{-cV_Y},
\quad v_x=\delta_Y\cos(2\pi h_0x/M).
\tag{6}
\]
序列 \(v\) 周期零均值、逐点有界、\(\sum_{x\bmod M}|v_x|^2\le M\)，而且每个整数区间 \(I\) 都满足 \(|\sum_{x\in I}v_x|\le\delta_Y|I|\)。令 \(\psi\in C_c^3((1,2))\)，并仿 note 870 置
\[
a_x=\frac{v_x}{M+x}\psi(1+x/M),\qquad 0\le x<M.
\]
对 note 849、870 的固定频带权 \(\eta\)，有
\[
\sum_{h\in\mathbb Z}\eta(h/H)|\widehat a(h)|^2
\ll_{\psi,\eta}\delta_Y^2H^{-5}
=o(H^4/Y),
\tag{7}
\]
但
\[
\boxed{\quad
\frac{\sum_{x\bmod M}|\mathsf H_{L,r}v(x)|^2}{H^2Y^2}
\asymp_r
\delta_Y^2Y^{1/5+2r(\alpha-1/5)}
\longrightarrow\infty.
\quad}\tag{8}
\]
因而在仅有这些**逐尺度**的一点短和、零均值和二次质量约束时，所需观察频带界不能一致推出任何**固定阶**相邻窗口差的目标量级。这个依赖 \(Y\) 的模型不是实际 \(c(m)\)，故不否定真实 Haar 门，也不排除固定算术序列具有额外的跨尺度关系；它说明把该门当成必要算术条件会额外要求较低频段的消去。

**证明。** 记 \(F(t)=\psi(1+t)/(1+t)\in C_c^3((0,1))\)。离散 Poisson 求和把 \(\widehat a(h)\) 写成 \(\delta_Y/2\) 倍的两个 \(\sum_{j\in\mathbb Z}\widehat F(h\pm h_0+jM)\)。当 \(\eta(h/H)\ne0\) 时，\(|h|\asymp H\)、\(h_0=o(H)\)，且非零别名离原点 \(\gg M\)。三次分部积分给 \(|\widehat a(h)|\ll_\psi\delta_YH^{-3}\)；频带有 \(O_\eta(H)\) 项，证明 (7)。

以 \(B_L(h)=\sum_{j=0}^{L-1}e(-hj/M)\) 表示整窗乘子，(5) 的乘子恰为
\(B_L(h)\{1-e(-hL/M)\}^r\)。由于 \(h_0=o(H)\)、\(L\asymp M/H\)，在 \(h=h_0\) 有
\[
|B_L(h_0)|\asymp L,
\qquad |1-e(-h_0L/M)|\asymp h_0/H.
\]
\(v\) 只有模 \(M\) 的 \(\pm h_0\) 两个 Fourier 模。周期 Parseval 遂给
\[
\sum_{x\bmod M}|\mathsf H_{L,r}v(x)|^2
=\frac{M\delta_Y^2}{2}|B_L(h_0)|^2
 |1-e(-h_0L/M)|^{2r}
\asymp_r M\delta_Y^2L^2(h_0/H)^{2r}.
\]
除以 \(H^2Y^2\)，用 \(M=2Y\)、\(H\asymp Y^{1/5}\) 和 \(h_0\asymp Y^\alpha\) 得 (8)。其指数严格为正，而 \(\delta_Y=Y^{-o(1)}\)，故比值趋于无穷。\(\square\)

## 算术边界

式 (2) 允许将真实 Haar 门改写为不含周期回绕的普通位移相关，供直接处理 \(c(m)c(m+k)\)。式 (4a) 与 (8) 合起来给出固定阶短和方法的尖锐幂阈值：阈值以下的真实低模已支付，阈值以上即有满足相同一点输入的反模型。若下一步只需 note 849 的观察频带，应直接处理其 \(K_H\) 加权真实三通道 Gram。两条完整算术目标仍无所需固定幂上界。
