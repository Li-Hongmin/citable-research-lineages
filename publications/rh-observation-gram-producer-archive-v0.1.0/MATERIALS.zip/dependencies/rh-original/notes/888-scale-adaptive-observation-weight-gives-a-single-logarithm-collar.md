> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 尺度自适应观察权将真实算术门缩到单对数领圈

日期：2026-10-03。依赖 [note 849](849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实观察 Gram、[note 850](850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的源层格距、[note 851](851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 的全频带次指数界、[note 884](884-uniform-kernel-gram-through-one-observation-length.md) 的近位移支付、[note 886](886-centered-three-channel-reduction-for-every-hard-observation-window.md) 的硬窗口中心化，以及 [note 887](887-gevrey-observation-weight-localizes-the-arithmetic-gate-to-a-polylog-collar.md) 的固定权远尾。本文只改变频带权的选择：权可以随物理尺度 $M$ 改变，但其平台、支撑和承重估计中的常数保持一致。所得单对数领圈仍需真实三通道的固定幂 signed 界；它不证明 RH。

## 定理

固定 $\psi\in C_c^3((1,2);\mathbb C)$ 与 $A>0$。沿整数 $Y\to\infty$，令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$、$B=M/H$。存在仅依赖 $A$ 的常数 $C_A>0$ 和一族非负偶函数 $\eta_M\in C_c^\infty(\mathbb R)$，一致满足
\[
0\le\eta_M\le1,\quad
\operatorname{supp}\eta_M\subset\{1/2\le|u|\le4\},\quad
\eta_M(u)=1\quad(1\le|u|\le2),
\tag{1}
\]
使以 $\eta_M$ 定义的 note 849 真实核
\[
K_{H,M}(k)=\sum_{h\in\mathbb Z}\eta_M(h/H)e(-hk/M)
\tag{2}
\]
满足，对 $d=c$ 和 note 886 的 $d=t$ 都有
\[
\boxed{\quad
\sum_{|m-n|>C_AB\log(2M)}
|a_m^{(d)}a_n^{(d)}K_{H,M}(m-n)|
\ll_{\psi,A}M^{-A}.
\quad}\tag{3}
\]
这里 $a_m^{(d)}=\mathbf1_{M<m<2M}d(m)\psi(m/M)/m$。

同一个远尾支付在 note 850 的完整奇数源两臂展开中仍成立。取该 note 的 $D=\lfloor M/(32H)\rfloor$、$\phi(v)=\psi(v)/v$ 和乘子 $W$，则
\[
\boxed{\quad
\sum_{\substack{D<u,v<2M/3,\ u,v\ {\rm odd}\\
k,\ell<64H,\ M<ku,\ell v<2M\\
|ku-\ell v|>C_AB\log(2M)}}
\left|\frac{W(k)W(\ell)}{M^2}
\phi(ku/M)\overline{\phi(\ell v/M)}
K_{H,M}(ku-\ell v)\right|
\ll_{\psi,A}M^{-A}.
\quad}\tag{3a}
\]
这包括不同源项；源层的大共同因子估计也保留统一常数。

取闭区间 $J\Subset(1,2)$ 使 $\operatorname{supp}\psi\subset J^\circ$。存在固定 $c_*>0$，独立于 $M,H$，使 note 884 式 (3)–(5) 对这族 $\eta_M$ 一致成立。特别固定 $0<\alpha<c_*$，若 $H^4e^{\alpha V_Y}\le M$，其中 $V_Y=(\log Y/\log\log Y)^{1/3}$，令
\[
K_\alpha=\lfloor H^3e^{\alpha V_Y}\rfloor,\qquad U=C_2B\log(2M),
\]
则取上面 $A=2$ 的同一权，有
\[
\boxed{\quad
\sum_h\eta_M(h/H)|\mathcal A_h(Y)|^2
=\sum_{K_\alpha<|m-n|\le U}
a_m^{(t)}\overline{a_n^{(t)}}K_{H,M}(m-n)
+o(H^4/M).
\quad}\tag{4}
\]
式 (4) 的误差对所述 $H$ 一致。若 $H^4e^{\alpha V_Y}>M$，适当取小 $\alpha$ 后，note 851 式 (3) 已一致给左侧 $o(H^4/M)$。由于 $\eta_M=1$ 于 $1\le|u|\le2$，式 (4) 中环带的 $O_\varepsilon(H^4M^{-1+\varepsilon})$ 上界足以支付相应的原始 dyadic 频带。因此全部规定的观察频带中，仅这个单对数领圈保留未付的固定幂算术界。

## 权的构造与远尾

取 note 887 式 (4) 的固定非负偶光滑权 $\eta_0$；它支撑于 $[5/8,19/8]\cup[-19/8,-5/8]$，高度不超过一，并在 $[7/8,17/8]\cup[-17/8,-7/8]$ 等于一。另取固定非负偶函数 $g\in C_c^\infty([-1,1])$，$\int g=1$，置 $a=1/16$。对将于下文选择的整数 $N=N(M,A)$，令
\[
g_{N}(x)=\frac Na g(Nx/a),\qquad
r_N=\underbrace{g_N*\cdots*g_N}_{N\text{ 次}},\qquad
\eta_M=\eta_0*r_N.
\tag{5}
\]
$r_N$ 是支撑于 $[-a,a]$ 的光滑概率密度；$\eta_M$ 的正支撑在 $[9/16,39/16]$ 内，且在 $[15/16,33/16]$ 等于一，负支撑由偶性给出。因此 (1) 对全部 $N$ 成立。卷积概率密度还给每个固定整数 $j\ge0$ 的统一导数界
\[
\|\eta_M^{(j)}\|_1\le\|\eta_0^{(j)}\|_1,
\qquad
|\widehat{\eta_M}(\xi)|\ll_j(1+|\xi|)^{-j}.
\tag{5a}
\]
特别地，note 850 式 (4) 所需的二次 Poisson 核界对这族权保持统一常数，其式 (1)–(3) 的大共同因子绝对支付也随之适用。

采用 note 849 的 Fourier 约定。固定 $D_g>0$ 使
\[
|\widehat g(\xi)|\le\min\{1,D_g(1+|\xi|)^{-2}\}.
\]
从 (5) 精确得到
\[
|\widehat{\eta_M}(\xi)|
\le C_0\left|\widehat g\!\left(\frac{a\xi}{N}\right)\right|^N
\le C_0\min\left\{1,\left(\frac{D_gN^2}{a^2\xi^2}\right)^N\right\}
\quad(\xi\ne0).
\tag{6}
\]
这里 $C_0=\|\eta_0\|_1$ 是固定常数。
取 $N=\lceil\lambda_A\log(2M)\rceil$，其中 $\lambda_A\log4>A+3$，再取 $C_A$ 足够大，使 $|\xi|\ge C_A\log(2M)$ 时 (6) 的右侧至多 $C_0\,4^{-N}$。这些选择均不依赖 $H$。

对活动的 $m,n$，note 849 的紧支撑条件给 $|(m-n)/M|\le1-\kappa_\psi$。Poisson 求和仍精确给
\[
K_{H,M}(k)=H\sum_{j\in\mathbb Z}
\widehat{\eta_M}\!\left(H(k/M+j)\right).
\tag{7}
\]
当 $|k|>C_AB\log(2M)$ 时，$j=0$ 项由 (6) 至多为 $C_0H4^{-N}=O(M^{-A-2})$。对 $j\ne0$，$|j+k/M|\ge\kappa_\psi$，且 (6) 的幂次项给
\[
H\sum_{j\ne0}
\left|\widehat{\eta_M}\!\left(H(k/M+j)\right)\right|
\ll_{\psi,A}H\left(\frac{C_{\psi,g}N}{H}\right)^{2N}
=O_{\psi,A}(M^{-A-2}),
\tag{8}
\]
因为 $H\ge Y^{1/5}$ 而 $N\asymp_A\log M$；对 $|j|\ge2$ 的级数由 $|j+k/M|\gg|j|$ 收敛，$j=\pm1$ 由 $\kappa_\psi$ 支付。note 849 式 (16) 和 note 886 式 (8) 分别给 $\sum_m|a_m^{(c)}|,\sum_m|a_m^{(t)}|\ll_\psi1$；对 (7) 求和即证明 (3)。

对 (3a)，活动乘子的总绝对质量满足
\[
\frac1M\sum_{\substack{u>D,\ u\ {\rm odd}\\k<64H,\ M<ku<2M}}
|W(k)\phi(ku/M)|
\ll_\psi\sum_{k<64H}\frac{|W(k)|}{k}
+\frac1M\sum_{k<64H}|W(k)|
\ll_\psi\log^2(2M).
\]
这里仅用每个 $k$ 的活动 $u$ 至多 $O(M/k+1)$ 个，以及 note 850 式 (8)。在 (3a) 每个活动位移上，(7) 已给 $|K_{H,M}|\ll M^{-A-2}$；以总绝对质量的平方求和便得 (3a)。

## 近端常数与拼接

这里不能直接把“$\eta$ 固定”代入旧结论，须核对那些证明实际使用的量。式 (1) 给一致的 $\sum_h\eta_M(h/H)\ll H$、$\sup|K_{H,M}|\ll H$ 和 $\sup|K'_{H,M}|\ll H^2/M$；因支撑固定，
\[
\|\widehat{\eta_M}\|_\infty+
\|\widehat{\eta_M}'\|_\infty\ll1.
\tag{9}
\]
在 $|k|\le B$ 时，(7) 中 $j\ne0$ 的别名与主点相隔至少 $H/2$，由 (8) 的同一计算可按任意负幂一致支付。note 884 证明的其余输入是与权无关的 note 851 短和、式 (9) 控制的核总变差、以及 $\sum\kappa_i=0$ 的精确密度消去。因此 note 884 式 (3) 的误差仍一致为 $O((HK/M)e^{-c_*V_Y})$，其中可取与 $M,H$ 无关的 $c_*>0$；其式 (5) 随之支付 $|m-n|\le K_\alpha$。

note 886 的交错求和只用上述 $K_{H,M}$ 两个界，故在任意硬窗口 $K\le M$ 仍一致给
\[
|\mathcal G_K(c)-\mathcal G_K(t)|
\ll_\psi H/M+H^2K/M^2+H\log(2M)/\sqrt M.
\tag{10}
\]
在 $K=U$，三项均为 $o(H^4/M)$，因为 $U=C_2(M/H)\log(2M)$ 且 $H\ge Y^{1/5}$。用 (3) 的 $A=2$ 支付远端，用 note 884 的近端界，再以 (10) 替换中间硬环带，证明 (4)。

最后，note 851 的频带能量证明在权上只用非负性、有界高度和固定支撑；(1) 使该证明对 $\eta_M$ 一致。若记其中的次指数常数为 $c_R>0$，选 $0<\alpha<\min(c_*,2c_R)$ 和 $\alpha/4<b<c_R/2$。当 $H^4e^{\alpha V_Y}>M$ 时，充分大 $Y$ 有 $H\ge Y^{1/4}e^{-bV_Y}$，故 note 851 式 (3) 给所声称的上端支付。$\square$

## 固定倍数的观察长度不能绝对支付核

以上方法必须留下至少一个随 $M$ 发散的观察长度倍数。更精确地，固定任意 $R>0$，存在只依赖 $R$ 的 $R'>R$、$\delta_R>0$，使**每个**满足 (1) 的权 $\eta$ 都有
\[
\sup_{R\le|\xi|\le R'}|\widehat\eta(\xi)|\ge\delta_R.
\tag{11}
\]
若一族权另满足在 $|k|\le(R'+1)B$ 上的 Poisson 非零别名和为 $o(1)$，则对充分大的 $M$、本定理的每个 $H$，存在整数 $k$ 满足
\[
RB<|k|\le R'B+1,\qquad |K_{H,M}(k)|\ge\tfrac14\delta_R H.
\tag{12}
\]
式 (8) 表明本文构造的权确实满足这个别名条件。因此没有固定常数 $R$ 能使该权的整个 $|k|>RB$ 核按绝对值成为小量。

证明 (11) 只用紧性。若它对某个 $R$ 为假，就能对每个整数 $j>R$ 找到满足 (1) 的 $\eta_j$，使 $\sup_{R\le|\xi|\le j}|\widehat{\eta_j}(\xi)|\le1/j$。这些权在固定紧集 $S=[-4,-1/2]\cup[1/2,4]$ 上的 $L^2$ 范数有界；取弱收敛子列，其极限 $\eta$ 仍满足 $0\le\eta\le1$、支撑于 $S$ 且在 $[1,2]\cup[-2,-1]$ 上等于一。每个固定 $\xi$ 的 Fourier 积分是 $L^2(S)$ 上的连续线性泛函，故 $\widehat\eta(\xi)=0$ 于全部 $|\xi|\ge R$。紧支撑使 $\widehat\eta$ 为整函数；恒等定理迫使 $\eta=0$，与平台矛盾。这证明 (11)。构造 (12) 时把刚证的结论用于 $R+1$，并将其右端仍记作 $R'$；这同时给 (11) 原来较大的区间。由固定支撑和高度有 $\|\widehat{\eta_M}'\|_\infty\ll1$；将此时 $|\xi|\ge R+1$ 的一个点四舍五入到网格 $k/B$，误差至多 $1/(2B)=o(1)$，所以 $|k|>RB$。在 (7) 中扣除假设的别名，便得 (12)。$\square$

## 未付算术量

式 (4) 只将可绝对支付的远端缩至 $C_2(M/H)\log M$，并保留了真实核的符号。$|m-n|\asymp M/H$ 仍在环带内，三个中心化通道的联合协方差仍须达到 $O_\varepsilon(H^4M^{-1+\varepsilon})$；本文没有给出该界，也不推出全尺度局部 Weil 正性或 RH。
