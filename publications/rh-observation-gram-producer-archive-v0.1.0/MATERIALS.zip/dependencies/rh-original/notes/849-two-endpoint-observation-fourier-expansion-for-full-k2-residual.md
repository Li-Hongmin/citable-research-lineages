> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 完整 \(k=2\) 余项的两端点展开与中距离协方差

日期：2026-10-01。依赖 [note 753](753-high-divisor-k2-gate-is-the-k2-residual-up-to-negligible-low-layer.md) 的完整余项恒等式与 [note 847](847-quarter-power-observation-fourier-tail-for-full-k2-residual.md) 的观察频率坐标。端点系数、分片 BV 界、整数求积、环带两侧支付、素数子块下界、全频带 $o(1)$ 界及光滑模型反例均已完成独立只读复核。本结果是两个真实算术指数和的有误差展开及其中距离协方差的无符号边界；它不估计目标完整均方，也不证明 RH。
末尾的三通道替换是后续新增推导，尚待异源复核。

## 定理

固定 $\psi\in C_c^3((1,2))$，$Y\to\infty$ 沿整数。记
$R_N=\mathcal R_{N,2}$、$e(x)=e^{2\pi i x}$，并令
\[
S_h=\sum_{Y<N\le2Y}\psi(N/Y)R_Ne(-hN/Y),\qquad 1\le |h|\le Y/2.
\]
则无条件地有
\[
\begin{aligned}
S_h={}&\frac{Y^2}{2\pi h^2}\sum_{r\ge1}
 \frac{\Lambda(r)-1}{r}\psi(r/Y)e(-hr/Y)\\
&-\frac{2Y^2}{\pi h^2}\sum_{r\ge1}
 \frac{\Lambda(r)-1+(\log2)\mu(r)}{r}
 \psi(r/(2Y))e(-hr/(2Y))
 +O_\psi\!\left(\frac{Y^2}{|h|^3}+h^2\right).
\end{aligned}
\tag{1}
\]
两和分别只含 $Y<r<2Y$ 与 $2Y<r<4Y$。

## 证明

note 753 给
\[
R_N=-\sum_{N<r<2N}[\Lambda(r)+\mu(r)\log(r/N)]\sin(2\pi r/N).
\]
整数 $N$ 上 $\sum_{N<r<2N}\sin(2\pi r/N)=0$，故可精确地将
$\Lambda(r)$ 换成 $a_r=\Lambda(r)-1$。令 $b_r=\mu(r)$，定义
\[
F_r(t)=\psi(t/Y){\bf1}_{r/2<t<r}
 [a_r+b_r\log(r/t)]\sin(2\pi r/t).
\]
于是 $S_h=-\sum_r\sum_{n\in\mathbb Z}F_r(n)e(-hn/Y)$。
记 $J_s=F_r'(s+)-F_r'(s-)$。因为两个端点的正弦为零，
\[
J_{r/2}=-\frac{8\pi}{r}\psi(r/(2Y))[a_r+(\log2)b_r],
\qquad
J_r=\frac{2\pi}{r}\psi(r/Y)a_r.
\tag{2}
\]
活动区间的光滑片上 $r,t\asymp Y$，所以对 $0\le j\le3$，
$|F_r^{(j)}(t)|\ll_\psi(|a_r|+|b_r|)Y^{-j}$。
分布二阶导数为 $F_{r,\mathrm{reg}}''+J_{r/2}\delta_{r/2}+J_r\delta_r$；
其正则部分的变差满足
\[
\operatorname{Var}(F_{r,\mathrm{reg}}'')
\ll_\psi (|a_r|+|b_r|)Y^{-2}.
\tag{3}
\]
这里还计入正则二阶导数在两个端点的值跳跃；每个跳跃为
$O_\psi((|a_r|+|b_r|)Y^{-2})$，内部三阶导数积分同阶。
令 $\omega=2\pi h/Y$。紧支撑及两次分部积分给
\[
\int F_r(t)e^{-i\omega t}\,dt
=\frac{J_{r/2}e^{-i\omega r/2}+J_re^{-i\omega r}}
{(i\omega)^2}
+O_\psi\!\left((|a_r|+|b_r|)\frac{Y}{|h|^3}\right),
\tag{4}
\]
因为正则二阶导数的 Fourier 积分由 (3) 再分部一次后至多
$O_\psi((|a_r|+|b_r|)/(Y|h|))$。

整数采样采用二阶求积：若 $g$ 连续、紧支撑且
$g'$ 为 BV，则
\[
\left|\sum_{n\in\mathbb Z}g(n)-\int g(t)\,dt\right|
\ll\operatorname{Var}(g').
\tag{5}
\]
事实上 Poisson 求和后，对每个非零整数 $k$ 两次分部积分给
$|\widehat g(k)|\le(2\pi k)^{-2}\operatorname{Var}(g')$；
所得 Fourier 级数绝对收敛，求和即得 (5)，也包含端点处
$g'$ 的跳跃。
对 $g(t)=F_r(t)e(-ht/Y)$，端点导数跳跃由 (2) 给
$O_\psi((|a_r|+|b_r|)/Y)$，光滑片的二阶导数积分由
$|g''|\ll_\psi(|a_r|+|b_r|)(1+h^2)/Y^2$ 给
\[
\operatorname{Var}(g')
\ll_\psi(|a_r|+|b_r|)(1+h^2)/Y.
\tag{6}
\]
Chebyshev 界 $\sum_{r\le4Y}\Lambda(r)\ll Y$ 使
$\sum_{r\le4Y}(|a_r|+|b_r|)\ll Y$。合计 (4)、(6)，在
$S_h=-\sum_r\cdots$ 中代入 (2) 的符号，得到 (1)。$\square$

## 对中频带的精度与边界

设 $T_h$ 为 (1) 的两个显式和，$E_h=S_h-T_h$。
当 $Y^{1/5}\le H\le Y^{1/4}$、$H\le|h|<2H$ 时，
\[
\frac1Y\sum_{H\le|h|<2H}|E_h|^2
\ll_\psi \frac{Y^3}{H^5}+\frac{H^5}{Y}
\ll_\psi Y^2.
\tag{7}
\]
因此该频带的归一化 $\ell^2$ 范数中 $S$ 与 $T$ 相差 $O_\psi(Y)$。
式 (7) 不断言二者能量之差为 $O(Y^2)$，也不界定任一原能量。
若把 (1) 两个和按第一项系数合并为
\[
\mathcal A_h(Y)=
\sum_r\frac{\Lambda(r)-1}{r}\psi(r/Y)e(-hr/Y)
-4\sum_r\frac{\Lambda(r)-1+(\log2)\mu(r)}{r}
\psi(r/(2Y))e(-hr/(2Y)),
\tag{8}
\]
则 $T_h=Y^2\mathcal A_h(Y)/(2\pi h^2)$。在上述频带，
\[
\frac1Y\sum_{H\le|h|<2H}|T_h|^2
\asymp\frac{Y^3}{H^4}
\sum_{H\le|h|<2H}|\mathcal A_h(Y)|^2.
\tag{9}
\]
所以支付这段完整余项能量至 $O_\varepsilon(Y^{2+\varepsilon})$
等价于真实算术门
$\sum_{H\le|h|<2H}|\mathcal A_h(Y)|^2
\ll_\varepsilon H^4Y^{-1+\varepsilon}$；式 (7) 只支付替换误差。
例如逐频任意对数幂节省仍不能给出 (9) 所需的固定幂平均节省。

式 (8) 还可化为单一长度 $2Y$ 的 DFT。定义
\[
c(m)=2{\bf1}_{2\mid m}\bigl(\Lambda(m/2)-1\bigr)
-4\bigl(\Lambda(m)-1+(\log2)\mu(m)\bigr).
\tag{10}
\]
第一和中以 $m=2r$ 换元，第二和中以 $m=r$ 换元，得到精确恒等式
\[
\boxed{\quad
\mathcal A_h(Y)=\sum_{2Y<m<4Y}
\frac{c(m)}m\psi(m/(2Y))e(-hm/(2Y)).
\quad}
\tag{11}
\]
例如奇素数 $p$ 满足 $c(p)=-4\log p+4+4\log2$，而
$c(2p)=2\log p+2-4\log2$。这里 $c$ 保留真实算术符号；
式 (11) 把两尺度频带门写成一个明确的联合系数序列，
仍不提供 (9) 的均方界。

这里的 $h$ 是移动观察变量 $N$ 的 Fourier 频率，与 note 801 的原始
Poisson 谐波不同。剩余的两个算术和仍需真正的 signed 平均估计；
只取绝对值不会支付完整的 $Y^{2+\varepsilon}$ 余项门。

## 平滑频带的中距离协方差门

固定非负偶函数 $\eta\in C_c^\infty(\mathbb R)$，支撑包含于
$\{t:1/2\le |t|\le4\}$，且在 $1\le|t|\le2$ 上 $\eta(t)\ge1$。
令 $Y^{1/5}\le H\le Y^{1/4}$，并把 (11) 的系数在全体整数上延拓为零：
\[
a_m=\frac{c(m)}m\psi(m/(2Y)),\qquad
K_H(k)=\sum_{h\in\mathbb Z}\eta(h/H)e(-hk/(2Y)).
\tag{12}
\]
对任意固定 $\delta>0$，写 $K_0=H^3/\log^2(2Y)$、
$K_1=Y^{1+\delta}/H$。则有精确展开
\[
\sum_h\eta(h/H)|\mathcal A_h(Y)|^2
=\sum_{m,n}a_m\overline{a_n}K_H(m-n),
\tag{13}
\]
而其中 $|m-n|\le K_0$ 的总贡献绝对值至多
\[
O_{\psi,\eta}\!\left(\frac{H^4}{Y\log(2Y)}\right),
\tag{14}
\]
$|m-n|>K_1$ 的总贡献对每个固定 $B>0$ 至多
$O_{\psi,\eta,\delta,B}(Y^{-B})$。特别地，对角项本身为
$O_{\psi,\eta}(H\log(2Y)/Y)$。因此若能证明
\[
\boxed{\quad
\sum_{K_0<|m-n|\le K_1}
a_m\overline{a_n}K_H(m-n)
\ll_{\varepsilon,\delta,\psi,\eta} H^4Y^{-1+\varepsilon},
\quad}
\tag{15}
\]
就得到 (9) 的中频带目标；(15) 是尚未证明的真实带符号算术界。
反过来，若 (13) 左侧满足同一上界，则扣除 (14) 与远差项后
(15) 也成立；因此两者在这一幂次量级等价。

证明这些无符号支付如下。由 Chebyshev 界及
$\Lambda(m)^2\le\log(4Y)\Lambda(m)$，
\[
\sum_m|a_m|\ll_\psi1,
\qquad
\sum_m|a_m|^2\ll_\psi\frac{\log(2Y)}Y.
\tag{16}
\]
对每个整数 $k$，Cauchy--Schwarz 给
$\sum_m|a_{m+k}a_m|\le\sum_m|a_m|^2$；又有
$|K_H(k)|\le\sum_h\eta(h/H)\ll_\eta H$。
在 $|k|\le K_0$ 的 $O(K_0+1)$ 个差值上求和即得 (14)，
因为 $K_0\to\infty$。只保留 $k=0$ 即得对角界。

取 $\widehat\eta(\xi)=\int\eta(t)e(-\xi t)\,dt$。Poisson 求和给
\[
K_H(k)=H\sum_{j\in\mathbb Z}
\widehat\eta\!\left(H\left(\frac{k}{2Y}+j\right)\right).
\tag{17}
\]
由于 $\psi$ 紧支撑于 $(1,2)$，存在固定 $\kappa_\psi>0$，
使非零 $a_m,a_n$ 满足
$|m-n|\le(1-\kappa_\psi)2Y$。故 $k/(2Y)$ 不能靠近非零整数别名。
$\widehat\eta$ 的任意阶衰减于是给，对每个 $A>1$，
\[
|K_H(k)|\ll_{\eta,A}H
\left(1+H\min\left\{\frac{|k|}{2Y},\kappa_\psi\right\}\right)^{-A}.
\tag{18}
\]
当 $|k|>K_1$ 且存在这样的 $(m,n)$ 时，(18) 右侧为
$O_{\psi,\eta,A}(H Y^{-A\delta})$；结合 (16) 的
$(\sum|a_m|)^2\ll1$，取充分大的 $A$ 即得任意负幂远差界。
最后 $K_0/K_1=H^4/[Y^{1+\delta}\log^2(2Y)]\to0$，
所以两段支付不会覆盖 (15) 的中距离区间。$\square$

式 (13) 的左侧非负，且 $\eta\ge1$ 覆盖 $H\le|h|\le2H$。
因此 (15) 足以支付该 dyadic 频带；它本身不能由 (14) 或
远差衰减推出。在 $H=Y^{1/5}$ 时，中距离约为
$Y^{3/5}/\log^2Y<|m-n|\le Y^{4/5+\delta}$。

### 环带内真实素数同号块的下界

在同一记号下，进一步取固定非负、非零的实函数 $\psi$。
任选闭区间 $J\subset(1,2)$，使 $\psi\ge c_\psi>0$ 于 $J$，
并令 $\mathcal P_Y=\{p\text{ 为素数}:p/(2Y)\in J\}$。
则对每个固定 $\delta>0$ 和所有 $Y^{1/5}\le H\le Y^{1/4}$，
这个真实算术子块满足
\[
\boxed{\quad
\sum_{\substack{p,q\in\mathcal P_Y\\
K_0<|p-q|\le Y/(16H)}}
a_p a_q K_H(p-q)\gg_{\psi,\eta}1.
\quad}
\tag{19}
\]
这些对已包含于 (15) 的中距离环带，因为
$Y/(16H)<K_1$。若 $H\le Y^{1/4-\theta}$ 且 $\theta>0$ 固定，
则 (19) 比 (15) 的目标 $H^4/Y\le Y^{-4\theta}$ 大一个固定幂。

证明不需素数对猜想。素数定理在固定比例区间给
$P:=|\mathcal P_Y|\asymp_\psi Y/\log Y$。
将 $2YJ$ 分成 $O_\psi(H)$ 个长度至多 $L=Y/(16H)$ 的格，
每格含 $P_j$ 个素数。Cauchy--Schwarz 给同格有序异素数对数
\[
\sum_jP_j(P_j-1)
\ge c_\psi\frac{P^2}{H}-P
\gg_\psi\frac{Y^2}{H\log^2Y}.
\tag{20}
\]
其中 $|p-q|\le L$。而 $|p-q|\le K_0$ 的有序对至多
$P(2K_0+1)$，相对 (20) 的比例至多
$O_\psi(HK_0\log Y/Y)=O(1/\log Y)$，由 $H^4\le Y$ 得到。
对剩下的同格素数对，$|h|\le4H$ 蕴含
$|2\pi h(p-q)/(2Y)|\le\pi/4$；因 $\eta\ge0$ 且在
$H\le|h|\le2H$ 至少为 $1$，
\[
K_H(p-q)=\sum_h\eta(h/H)
\cos\!\left(\frac{\pi h(p-q)}Y\right)\gg_\eta H.
\tag{21}
\]
最后奇素数 $p\in\mathcal P_Y$ 满足
$c(p)=-4\log p+4+4\log2<0$，从而
$a_pa_q\gg_\psi\log^2Y/Y^2$。把 (20)--(21) 相乘即得 (19)。
$\square$

式 (19) 是 (15) 内一个正子块的下界，不是完整环带的下界。
若 (15) 对每个 $\varepsilon>0$ 成立，则在
$H\le Y^{1/4-\theta}$ 取 $\varepsilon<4\theta$，环带其余真实系数
必须与这个素数块产生相应的**核加权负贡献**；素数同号配对本身
已经排除对此环带逐项取绝对值的证明方式。此处不能推断负贡献
来自素数--合数或 Möbius 系数的反号：$K_H$ 本身会变号。
事实上 $H\ll M=2Y$ 且 $\eta(0)=0$，所以有限 Fourier 正交给
$\sum_{k\bmod M}K_H(k)=M\eta(0)=0$，而
$K_H(0)=\sum_h\eta(h/H)>0$。

### 整段频带的无条件消失与幂次缺口

实际上，现有全区间短区间定理已能证明比单个子块更强的整体抵消：
在上述 $H$ 范围内，一致有
\[
\boxed{\quad
\sum_h\eta(h/H)|\mathcal A_h(Y)|^2=o_{\psi,\eta}(1).
\quad}
\tag{22}
\]
这里 $\psi$ 可以是任意固定 $C_c^3((1,2))$ 函数。(22) 只给
无速率的 $o(1)$，当 $H=Y^\gamma$、$1/5\le\gamma<1/4$ 时，
它仍不能给出 (15) 所需的 $Y^{4\gamma-1+\varepsilon}$ 固定幂界。

所需外部输入已在 [note 835](835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md)
核对：Heath--Brown 1982 的全区间短区间素数定理在任意固定
$\theta>7/12$ 给 $\sum_{x<n\le x+x^\theta}\Lambda(n)
=x^\theta(1+o(1))$；Matomäki--Shao--Tao--Teräväinen 2023
Theorem 1.1(i) 在长度 $x^{5/8+\epsilon}\le B\le x^{1-\epsilon}$
的所有区间给 $\sum\mu(n)\ll_A B/\log^A x$，且适用于全部前缀。
取 $B=\lfloor Y^{2/3}\rfloor$。对任何 $u\asymp Y$，长度为 $B$
的区间上有
\[
\sum_{u<m\le u+B}c(m)=o(B)
\tag{23}
\]
一致成立：把 $c$ 按 (10) 分成两项 $\Lambda-1$、一项
$\mu$，偶数项以 $m=2n$ 变换；后者的素数区间长度 $B/2$
仍可分成长度 $Y^{13/20}$ 的小段，因 $13/20>7/12$，
剩余长度 $O(Y^{13/20})$ 的平凡 $\Lambda$ 质量为 $o(B)$。
同样的分段适用于未缩放的 $\Lambda-1$；$\mu$ 项由上述全区间定理支付。

令 $M=2Y$、$L=\lfloor Y/(16H)\rfloor$。则
$Y^{3/4}/17\le L\le Y^{4/5}$ 对充分大 $Y$ 成立，
且 $B\log Y=o(L)$。把任意长度至多 $L$ 的整数区间
分成长度 $B$ 的整块和一个余段，整块用 (23)，余段用
$|c(m)|\ll\log Y$，即得统一的前缀估计
\[
\sup_{\substack{I\subset(2Y,4Y)\\|I|\le L}}
\left|\sum_{m\in I}c(m)\right|=o(L).
\tag{24}
\]
这里 $|I|$ 指区间长度。对光滑权
$w(t)=\psi(t/M)/t$，有 $|w|\ll_\psi Y^{-1}$、
$|w'|\ll_\psi Y^{-2}$；在每个长度至多 $L$ 的区间上
用 (24) 分部求和，得到
\[
\sup_{|I|\le L}\left|\sum_{m\in I}a_m\right|
=o_\psi(L/Y).
\tag{25}
\]

将 $a_m$ 按 $m\pmod M$ 看作 $\mathbb Z/M\mathbb Z$ 上的序列
$b_x=a_{x+M}$。由于 $\psi$ 在 $(1,2)$ 内紧支撑，
长为 $L=o(Y)$ 的周期窗口在拼接处只经过零值区，(25)
对每个周期窗口仍成立。记
$B_h=\sum_{j=0}^{L-1}e(-hj/M)$。在 $\eta(h/H)\ne0$ 时，
$|h|\le4H$ 且 $|h|L/M\le1/8$，故几何和公式给
$|B_h|\gg L$。周期 Parseval 于是推出
\[
\begin{aligned}
\sum_h\eta(h/H)|\mathcal A_h|^2
&\ll_\eta\frac1{L^2}
\sum_{h\bmod M}|B_h\mathcal A_h|^2\\
&=\frac M{L^2}\sum_{x\bmod M}
\left|\sum_{j=0}^{L-1}b_{x-j}\right|^2
=o_{\psi,\eta}(1),
\end{aligned}
\tag{26}
\]
证明 (22)。结合 (14)、远差界与 (13)，整个中距离
signed 和也为 $o(1)$。当 $\psi\ge0$ 且非零时，(19) 因此
无条件地迫使环带其余项产生与素数子块同量级的核加权负贡献。
这没有取得 (15) 的固定幂速率，也没有单独识别算术系数的负协方差。

后一限制有一个纯光滑反例。任取非负、非零
$\varphi\in C_c^\infty((1,2))$，设
$b_m=M^{-1}\varphi(m/M)$、$M=2Y$，并按 (12) 定义其
平滑频带能量 $E_\eta(b)$。Poisson 求和给
\[
\sum_m b_m e(-hm/M)
=\sum_{j\in\mathbb Z}\widehat\varphi(h+jM),
\qquad
E_\eta(b)\ll_{\varphi,\eta,A}H^{1-2A}
\quad(A>1),
\tag{27}
\]
因为 $H\ll M$ 且 $\widehat\varphi$ 任意阶衰减。
另一方面，在 $\varphi\ge c>0$ 的固定比例区间把整数分成
$O(H)$ 个长度至多 $M/(32H)$ 的格。与 (20)--(21) 相同的
格内计数给
\[
\sum_{\substack{m,n\in\mathbb Z\\
K_0<|m-n|\le M/(32H)}}
b_mb_nK_H(m-n)\gg_{\varphi,\eta}1.
\tag{28}
\]
近差对数至多 $O(MK_0)$，仅占格内 $\gg M^2/H$ 对的
$O(HK_0/M)=O(1/\log^2Y)$。因此即使所有系数非负且完全光滑，
也会出现 (28) 的正子块、其余距离的负核贡献及趋零的总频带能量。
式 (19) 的作用严格限于排除逐项绝对值估计；若要识别真正算术
负协方差，必须在消除这种光滑密度与 $K_H$ 的符号效应后再比较。

## 目标量级内只剩三类真实系数

在 $M=2Y$ 及 (12) 的频带内，定义
\[
c_{\rm tri}(m)=2\mathbf1_{m=2p\text{ for a prime }p}\log p
-4\mathbf1_{m=p\text{ for a prime }p}\log p
-4(\log2)\mu(m),
\qquad
\mathcal A_h^{\rm tri}
=\sum_{M<m<2M}\frac{c_{\rm tri}(m)}m
\psi(m/M)e(-hm/M).
\tag{29}
\]
这里的 $2p$ 项只含 $Y<p<2Y$，而 $p$ 项只含
$2Y<p<4Y$。有无条件误差界
\[
\boxed{\quad
\sum_h\eta(h/H)
|\mathcal A_h-\mathcal A_h^{\rm tri}|^2
\ll_{\psi,\eta}
\frac{H\log^2(2Y)}Y+H^{-5}
=o\!\left(\frac{H^4}Y\right)
\quad}
\tag{30}
\]
其中最后一个 $o$ 在
$Y^{1/5}\le H\le Y^{1/4}$ 上一致。因此 (15) 的目标
频带界成立当且仅当对 $\mathcal A_h^{\rm tri}$ 成立；
这支付了常数背景与所有高次素数幂，保留三个通道之间的
真实带符号交叉项。

证明令 $\varphi(u)=\psi(u)/u\in C_c^3((1,2))$，并记
$P_2(n)=\Lambda(n)-\mathbf1_{n\text{ prime}}\log n$。
由 (10)、(29)，差序列精确为
\[
c(m)-c_{\rm tri}(m)
=4-2\mathbf1_{2\mid m}
+2\mathbf1_{2\mid m}P_2(m/2)-4P_2(m).
\tag{31}
\]
先处理前两项。对 $w(m)=\psi(m/M)/m=M^{-1}\varphi(m/M)$，
分别在整数格与偶数格使用 Poisson 求和，得到其 Fourier 和的
**精确**公式
\[
\sum_m(4-2\mathbf1_{2\mid m})w(m)e(-hm/M)
=4\sum_{j\in\mathbb Z}\widehat\varphi(h+jM)
-\sum_{j\in\mathbb Z}\widehat\varphi(h+jY).
\tag{32}
\]
在 $\eta(h/H)\ne0$ 时，$H/2\le|h|\le4H\ll Y$，
而 $\varphi\in C_c^3$ 的三次分部积分给
$(32)=O_\psi(H^{-3})$。

高次素数幂满足初等质量界
\[
\sum_{n\le4Y}P_2(n)
=\sum_{p\le2\sqrt Y}
\left(\#\{k\ge2:p^k\le4Y\}\right)\log p
\ll\sqrt Y\log(2Y).
\tag{33}
\]
因为对每个 $p$，$\#\{k\ge2:p^k\le4Y\}\log p\le\log(4Y)$，
且这样的素数个数至多 $2\sqrt Y$。在 $M<m<2M$ 上
$|w(m)|\ll_\psi Y^{-1}$，
故 (31) 中的两项高次素数幂对每个 $h$ 的贡献
为 $O_\psi(Y^{-1/2}\log(2Y))$。频带含 $O_\eta(H)$ 个整数 $h$；
平方求和即得 (30) 的不等式。最后
$H\log^2(2Y)/Y=o(H^4/Y)$，且
$H^{-5}=o(H^4/Y)$，均由 $H\ge Y^{1/5}$ 保证。
两序列的加权 $\ell^2$ 范数之差因此为
$o(H^2/\sqrt Y)$，证明目标上界的双向蕴含。$\square$
