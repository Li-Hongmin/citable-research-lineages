> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 三通道短区间均方输入强迫的 ζ 导数门

日期：2026-10-03。依赖 [note 849](849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)、(26) 的真实三通道系数与观察频带。本结论分析一种足以支付其中 \(H=Y^{1/5}\) 频带的短区间均方输入；它不证明该输入，也不估计 note 849 式 (15)。

## 定理

对全部整数 \(m\ge1\) 定义
\[
c(m)=2\mathbf1_{2\mid m}\bigl(\Lambda(m/2)-1\bigr)
-4\bigl(\Lambda(m)-1+(\log2)\mu(m)\bigr),
\qquad C(x)=\sum_{m\le x}c(m).
\tag{1}
\]
固定 \(\kappa>0\)，令 \(B_X=\lfloor\kappa X^{4/5}\rfloor\)。假设对每个 \(\varepsilon>0\)，在全部充分大整数 \(X\) 上有
\[
\boxed{\quad
\sum_{X\le x\le2X}
|C(x+B_X)-C(x)|^2\ll_{\kappa,\varepsilon}X^{12/5+\varepsilon}.
\quad}\tag{2}
\]
则对每个 \(\varepsilon>0\)，
\[
C(x)\ll_{\kappa,\varepsilon}x^{9/10+\varepsilon}.
\tag{3}
\]
此外 \(\sum_{m\ge1}c(m)m^{-s}\) 在 \(\Re s>9/10\) 全纯，并在 \(\Re s>1\) 精确等于
\[
\boxed{\quad
\mathcal C(s)=
(4-2^{1-s})\left(\frac{\zeta'(s)}{\zeta(s)}+\zeta(s)\right)
-\frac{4\log2}{\zeta(s)}.
\quad}\tag{4}
\]
式 (4) 的右侧在 \(s=1\) 可去奇，并取值 \(6\gamma\)。因此，如果 \(\rho\) 是 \(\Re\rho>9/10\) 的 ζ 零点，(2) 强迫 \(\rho\) 为单零点且满足
\[
\boxed{\quad (4-2^{1-\rho})\zeta'(\rho)=4\log2.\quad}\tag{5}
\]
特别地，任一该半平面的重零点或不满足 (5) 的单零点，都严格否定输入 (2)。这不是无条件零自由结果；目前并未排除式 (5) 在单零点成立。

## 证明

由 \(|\mu(m)|\le1\)、\(0\le\Lambda(m)\le\log m\)，有 \(|c(m)|\ll\log(2m)\)。固定整数 \(X\) 与 \(X\le a<b\le2X\)，暂记 \(B=B_X\)、\(\Delta(t)=C(t+B)-C(t)\)。若 \(b-a<B\)，则直接有 \(|C(b)-C(a)|\ll B\log(2X)\)。否则，对每个 \(0\le u<B\)，从 \(a+u\) 起以步长 \(B\) 向右走到不超过 \(b\) 的最后一点。所有这些路径上的完整边所用起点互不重复，且属于 \([X,2X]\)。所以在 \(B\) 条路径中至少有一条满足
\[
\sum_{\text{该路径的完整边}}|\Delta(t)|^2
\le \frac1B\sum_{X\le t\le2X}|\Delta(t)|^2.
\]
每条路径的完整边数至多 \(X/B+1\)，其起点与终点到 \(a,b\) 的距离各小于 \(B\)。Cauchy–Schwarz 和两端的平凡估计给
\[
|C(b)-C(a)|
\ll B\log(2X)
+\sqrt{\frac XB+1}\,
\sqrt{\frac1B\sum_{X\le t\le2X}|\Delta(t)|^2}
\ll_{\kappa,\varepsilon}X^{9/10+\varepsilon}.
\tag{6}
\]
这里用 \(B\asymp_\kappa X^{4/5}\)；式 (2) 指数中的 \(\varepsilon\) 可预先取得更小。对 \([1,x]\) 作 dyadic 分段，并在每段应用 (6)，得到 (3)。

由 (3) 及 Abel 分部求和，Dirichlet 级数在 \(\Re s>9/10\) 的任意紧集上一致收敛，因此全纯。对 \(\Re s>1\)，标准恒等式
\(\sum\Lambda(m)m^{-s}=-\zeta'/\zeta\)、\(\sum\mu(m)m^{-s}=1/\zeta\) 以及偶数指标代换，逐项给
\[
\begin{aligned}
\sum_{m\ge1}\frac{c(m)}{m^s}
&=2^{1-s}\left(-\frac{\zeta'}\zeta-\zeta\right)
-4\left(-\frac{\zeta'}\zeta-\zeta+\frac{\log2}{\zeta}\right),
\end{aligned}
\]
即 (4)。在 \(s=1\)，\(\zeta(s)=1/(s-1)+\gamma+O(s-1)\)、\(\zeta'/\zeta=-1/(s-1)+\gamma+O(s-1)\)，故两极点抵消、\(1/\zeta\to0\)，极限为 \((4-2^0)2\gamma=6\gamma\)。

设 \(\rho\) 是 \(\Re\rho>9/10\) 的零点。将 (4) 改写为
\[
\mathcal C(s)=(4-2^{1-s})\zeta(s)
+\frac{(4-2^{1-s})\zeta'(s)-4\log2}{\zeta(s)}.
\tag{7}
\]
左侧已全纯。若零点重数至少为二，则 (7) 分子的第二项在 \(\rho\) 等于 \(-4\log2\ne0\)，矛盾。若为单零点，商的极点可去必须且只需分子在 \(\rho\) 为零，即 (5)。\(\square\)

## 与观察频带的精确关系

在 note 849 式 (26) 的 \(H=Y^{1/5}\) 处，观察窗口长 \(L_Y=\lfloor Y/(16H)\rfloor\asymp Y^{4/5}\)。取 \(X=2Y\) 与 \(\kappa=2^{-4/5}/16\)，则式 (2) 中的 \(B_X=L_Y\)。若该式成立，则对 \(a_m=c(m)\psi(m/(2Y))/m\) 的长度 \(L_Y\) 窗口，\(w(m)=\psi(m/(2Y))/m\) 满足 \(|w|\ll Y^{-1}\)、\(|w'|\ll Y^{-2}\)。把窗口中的 \(w(m)\) 冻结在起点时，余项逐窗口至多
\[
O_\psi\!\left(\frac{L_Y^2\log Y}{Y^2}\right)
=O_\psi(Y^{-2/5}\log Y).
\]
式 (2) 给主项在 \(O(Y)\) 个窗口上的平方和 \(O_\varepsilon(Y^{2/5+\varepsilon})\)，上述余项的平方和为 \(O(Y^{1/5}\log^2Y)\)。代入 note 849 式 (26) 中的 \(Y/L_Y^2\asymp Y^{-3/5}\) 因子，得到该频带所需的 \(O_\varepsilon(Y^{-1/5+\varepsilon})=O_\varepsilon(H^4Y^{-1+\varepsilon})\) 上界。边界窗口由 \(\psi\) 的紧支撑零延拓处理。

因此 (2) 是一种足够强的短区间路线输入，同时由 (3)–(5) 已承载明确的零点信息。它是**充分条件**，不是 note 849 式 (15) 的必要条件；频带估计仍可能通过只作用于非零观察频率的抵消成立。
