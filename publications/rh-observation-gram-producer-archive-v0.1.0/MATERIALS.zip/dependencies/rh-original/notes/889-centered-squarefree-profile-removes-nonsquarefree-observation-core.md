> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 中心化平方自由轮廓在目标精度内移除观察核的非平方自由位置

日期：2026-10-03。依赖 [note 849](849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的完整系数与观察 Gram、[note 886](886-centered-three-channel-reduction-for-every-hard-observation-window.md) 的三个中心化通道，以及 [note 888](888-scale-adaptive-observation-weight-gives-a-single-logarithm-collar.md) 的单对数领圈；末节另用 [note 885](885-squarefree-gcd-averaging-leaves-weighted-mobius-main.md) 的平方自由计数和 [note 851](851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 的全区间短和。这里用初等平方自由计数支付一个真实硬位移窗口中的非平方自由背景和它与全部三个算术通道的交叉。留下的系数逐点支撑于平方自由整数；在正核环带内还可识别一项真实 Möbius 符号造成的负交叉。完整带符号协方差仍未得到固定幂上界。

## 定理

沿用 note 886 的 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$、$\psi\in C_c^3((1,2);\mathbb C)$、完整系数 $c(m)$、中心化系数 $t(m)$ 与硬窗口 Gram $\mathcal G_K$。频带权可取 note 849 的任意固定合格权，或 note 888 中随 $M$ 改变的权；两种情形都满足 $|K_H|\ll H$、$|K_H'|\ll H^2/M$，常数在后一情形对 $M,H$ 一致。令
\[
d_2=\frac1{\zeta(2)},\qquad
s(m)=3\bigl(1-\zeta(2)\mu^2(m)\bigr),\qquad
z(m)=t(m)-s(m).
\tag{1}
\]
则在 $M<m<2M$ 有精确恒等式
\[
\boxed{\quad
z(m)=3\zeta(2)\mu^2(m)
-4\mathbf1_{m\ {\rm prime}}\log m
+2\mathbf1_{m=2p,\ p\ {\rm prime}}\log p
-4(\log2)\mu(m),
\quad}\tag{2}
\]
特别地，$\mu^2(m)=0$ 蕴含 $z(m)=0$。对每个整数 $0\le K\le M$，一致有
\[
\boxed{\quad
|\mathcal G_K(t)-\mathcal G_K(z)|
\ll_{\psi,\eta} \frac H{\sqrt M}+\frac{H^2K}{M^{3/2}}.
\quad}\tag{3}
\]
因此对任意固定 $C>0$ 和 $K\le C(M/H)\log(2M)$，
\[
|\mathcal G_K(c)-\mathcal G_K(z)|=o(H^4/M)
\tag{4}
\]
一致于所述 $H$。特别对 note 888 的 $A=2$ 可变权及其 $K_\alpha,U=C_2(M/H)\log(2M)$，在 $H^4e^{\alpha V_Y}\le M$ 内有
\[
\boxed{\quad
\sum_h\eta_M(h/H)|\mathcal A_h(Y)|^2
=\sum_{K_\alpha<|m-n|\le U}
a_m^{(z)}\overline{a_n^{(z)}}K_{H,M}(m-n)
+o(H^4/M).
\quad}\tag{5}
\]
右侧真正未付的中距离 Gram 现在只含平方自由的 $m,n$。在上端 $H^4e^{\alpha V_Y}>M$，note 888 已给频带目标。

还可绝对支付这些平方自由位置的大**物理**共同因子。对式 (5) 的 $U$，置
\[
G_{\rm phys}=\left\lceil\frac{M\log^2(2M)}{H^4}\right\rceil.
\]
则对充分大的 $M$ 一致有
\[
\boxed{\quad
\sum_{\substack{0<|m-n|\le U\\(m,n)>G_{\rm phys}}}
|a_m^{(z)}a_n^{(z)}K_{H,M}(m-n)|
\ll_\psi\frac{H^4}{M\log(2M)}
=o(H^4/M).
\quad}\tag{5a}
\]
因此式 (5) 的环带可再限制为 $(m,n)\le G_{\rm phys}$。这里是物理指标 $m,n$ 的 gcd，与 note 850、885 的奇数源 gcd 不同。

## 证明

平方自由恒等式 $\mu^2(n)=\sum_{d^2\mid n}\mu(d)$ 直接给
\[
\sum_{n\le x}\mu^2(n)
=\sum_{d\le\sqrt x}\mu(d)\lfloor x/d^2\rfloor
=\frac{x}{\zeta(2)}+O(\sqrt x).
\tag{6}
\]
最后一个等号使用 $\sum_{d>\sqrt x}d^{-2}=O(x^{-1/2})$，无需 Möbius 的任何符号估计。对 $I\subset[M,2M]$ 的任意整数区间，式 (1)、(6) 遂给
\[
\left|\sum_{n\in I}s(n)\right|\ll\sqrt M.
\tag{7}
\]
注意 (7) 对长度很短的区间仍成立；它是下述分部求和所需的统一前缀界。

note 886 式 (1) 展开 $t$ 后，减去 $s=3-3\zeta(2)\mu^2$ 即为 (2)。素数、二倍素数和 $\mu$ 都支撑于平方自由整数；在 $M<m<2M$ 内，$m=2p$ 时 $p$ 为奇素数，故这一项也不例外。

固定外层 $m$ 和硬窗口 $K$，按 note 886 式 (5) 记
\[
F_m(n)=\mathbf1_{M<n<2M}\mathbf1_{0<|n-m|\le K}
\frac{\psi(n/M)}{n/M}K_H(m-n).
\]
定义域至多是两个整数区间。式 (7) 与离散 Abel 求和给
\[
\left|\sum_n s(n)F_m(n)\right|
\ll\sqrt M\bigl(\|F_m\|_\infty+\operatorname{Var}_nF_m\bigr)
\ll_{\psi,\eta}\sqrt M\left(H+\frac{H^2K}{M}\right).
\tag{8}
\]
这里最后一步只用 $\|K_H\|_\infty\ll H$、$\|K_H'\|_\infty\ll H^2/M$、$\psi(v)/v$ 的固定总变差及硬窗口两端的有界个跳跃；note 888 的可变权同样满足这两个核界。

Chebyshev 界、$|\mu|\le1$、$\mu^2\le1$ 及 (2) 给
$\sum_{M<m<2M}(|z(m)|+|s(m)|)\ll M$。在
$t=z+s$ 的 Gram 展开中，对 $z$--$s$、$s$--$z$ 和 $s$--$s$ 分别以内层 $s$ 使用 (8)，外层取这个绝对质量界，并计入两个 $M^{-1}$ 系数，即得 (3)。

note 886 式 (4) 已给 $\mathcal G_K(c)-\mathcal G_K(t)$ 的误差。若 $K\le C(M/H)\log(2M)$，把它与 (3) 相加；相对于 $H^4/M$，新增两项的比值分别是
\[
\frac{\sqrt M}{H^3},
\qquad
\frac{K}{H^2\sqrt M}
\le\frac{C\sqrt M\log(2M)}{H^3},
\]
在 $H\ge Y^{1/5}$ 上均趋零。note 886 的原有三项也一致趋零，证明 (4)。最后用 (4) 分别替换 note 888 式 (4) 环带的两个硬窗口端点，得到 (5)。$\square$

为证明 (5a)，先注意 $U=o(M)$ 且 $G_{\rm phys}>2$。若 $M<m,n<2M$、$m\ne n$、$(m,n)>2$、$|m-n|\le U$，则两端都不是素数；否则另一端至少是该素数的二倍，已超出窗口。两端也不是 $2p$（$p$ 为奇素数）：若 $(2p,n)>2$，共同因子必含 $p$，而窗口内与 $2p$ 不同的 $p$ 倍数只能是 $3p$，两者相距 $p>M/2>U$。故在 (5a) 的每个非零配对上，两端均平方自由，式 (2) 简化为
\[
z(m)=3\zeta(2)-4(\log2)\mu(m),\qquad
z(n)=3\zeta(2)-4(\log2)\mu(n),
\]
两系数均有绝对常数界。对每个公因子 $g>G_{\rm phys}$，因 $g\mid(m-n)$ 有 $g\le U$；满足 $g\mid m,n$、$M<m,n<2M$、$0<|m-n|\le U$ 的有序对至多
\[
O\!\left(\frac Mg\frac Ug\right)
=O(MU/g^2)
\]
个，其中 $g\le U=o(M)$ 保证取整项可吸收。允许一个配对被多个公因子重复计数，只会增大上界，所以总对数至多 $O(MU/G_{\rm phys})$。在这些非零配对上用 $|a_m^{(z)}|,|a_n^{(z)}|\ll_\psi M^{-1}$、$|K_{H,M}|\ll H$，得到
\[
\text{(5a) 左侧}\ll_\psi\frac{H}{M^2}
\frac{MU}{G_{\rm phys}}
\ll_\psi\frac{\log(2M)}{G_{\rm phys}}
\ll_\psi\frac{H^4}{M\log(2M)},
\]
证明 (5a)。$\square$

## 平方自由支撑内的奇偶密度再中心化

置 $P(u)=\mathbf1_{u\ {\rm prime}}\log u$，并定义
\[
\begin{aligned}
q_2(m)&=3\zeta(2)\mu^2(m)
 \bigl(2\mathbf1_{2\mid m}-\mathbf1_{2\nmid m}\bigr),\\
w(m)&=z(m)-q_2(m),\\
F(u)&=P(u)-\tfrac32\zeta(2)\mu^2(u)
\qquad(u\ {\rm odd}).
\end{aligned}
\tag{9}
\]
对奇数 $u$，分别在 $M<u<2M$ 与 $M<2u<2M$ 的相应行上，有**精确**的两臂公式
\[
\boxed{\quad
w(u)=-4F(u)-4(\log2)\mu(u),\qquad
w(2u)=2F(u)+4(\log2)\mu(u).
\quad}\tag{10}
\]
$w$ 仍逐点支撑于平方自由整数。两臂的密度分别为零：奇数 $u$ 上，$P(u)$ 的每整数密度为 $1$，而 $\tfrac32\zeta(2)\mu^2(u)$ 的每整数密度也为
$(3/2)\zeta(2)\cdot4/\pi^2=1$。奇数 Möbius 部分的密度为零：若 $M_{\rm odd}(x)=\sum_{n\le x,\ n\ {\rm odd}}\mu(n)$，则 $\mu(2u)=-\mu(u)$ 对奇数 $u$ 给 $M_{\rm odd}(x)=M_\mu(x)+M_{\rm odd}(x/2)$；由素数定理等价的 $M_\mu(x)=o(x)$ 迭代可得 $M_{\rm odd}(x)=o(x)$。偶臂由 (10) 得出同样结论。

两臂在相邻的物理尺度上满足精确反演
\[
F(u)=-\frac{w(u)+w(2u)}2,\qquad
\mu(u)=\frac{w(u)+2w(2u)}{4\log2}
\qquad(u\ge3\text{ 为奇数}).
\tag{10a}
\]
固定的 $(M,2M)$ 只包含 $u$、$2u$ 中至多一个，因此 (10a) 不在同一观察窗口内提供额外抵消；它说明再中心化没有删除 Möbius 符号信息。

这个再中心化在目标尺度内无代价。对所有整数 $0\le K\le M$，
\[
\boxed{\quad
|\mathcal G_K(z)-\mathcal G_K(w)|
\ll_{\psi,\eta}\frac H{\sqrt M}
+\frac{H^2K}{M^{3/2}}.
\quad}\tag{11}
\]
因此式 (5) 可以把 $z$ 换成 $w$，仍只有 $o(H^4/M)$ 的总误差；式 (5a) 的大物理 gcd 支付对 $w$ 也成立。真正未付的核心于是可取为 $(m,n)\le G_{\rm phys}$ 的两臂 $F$--$\mu$ signed Gram。

为证 (11)，note 743 式 (8) 的奇数平方自由计数和式 (6) 相减，给
\[
\sum_{\substack{n\le x\\n\ {\rm odd}}}\mu^2(n)
=\frac4{\pi^2}x+O(\sqrt x),
\qquad
\sum_{\substack{n\le x\\n\ {\rm even}}}\mu^2(n)
=\frac2{\pi^2}x+O(\sqrt x).
\]
式 (9) 中奇位系数为 $-3\zeta(2)$，偶位系数为 $+6\zeta(2)$；两者的主密度分别为 $-2$ 与 $+2$，正好相消。因此每个整数区间 $I\subset[M,2M]$ 都有
\[
\left|\sum_{n\in I}q_2(n)\right|\ll\sqrt M.
\]
把证明 (3) 中的 $s$ 换成 $q_2$。由式 (2)、(9)、Chebyshev 界与 $|\mu|\le1$，有 $\sum_{M<m<2M}(|w(m)|+|q_2(m)|)\ll M$；其余离散 Abel 与核变差估计逐项相同，得到 (11)。式 (10) 则由 $\mu(2u)=-\mu(u)$、$\mu^2(2u)=\mu^2(u)$（$u$ 奇）和式 (2)、(9) 直接代入。大 gcd 配对中不出现素数位或二倍素数位，故 $w$ 的两端仍有绝对常数界，证明式 (5a) 对 $w$ 的版本。$\square$

## 留存的素数–Möbius 交叉不能绝对支付

取 $H=Y^{1/5}$、$B=M/H$，并令 $\psi$ 为任意固定非负、非零的实函数，$f(v)=\psi(v)/v$。在奇数物理位置，式 (10) 的两个通道系数分别为
\[
a_m^{F,\mathrm o}=-\frac{4F(m)}M f(m/M),\qquad
a_m^{\mu,\mathrm o}=-\frac{4\log2}{M}\mu(m)f(m/M).
\tag{12}
\]
下述结论对 note 888 的可变观察权成立，也对支撑于 $|t|\le4$、在 $1\le|t|\le2$ 至少为一的固定非负偶权成立。存在只依赖 $\psi$ 与权的常数 $c>0$，使充分大 $M$ 时，在式 (5) 留存的环带内已有
\[
\boxed{\quad
\sum_{\substack{p\text{ 为奇素数},\ n\text{ 为奇平方自由合数}\\
K_\alpha< n-p\le U,\ (p,n)=1}}
\left|a_p^{F,\mathrm o}\overline{a_n^{\mu,\mathrm o}}
K_{H,M}(p-n)\right|\ge c.
\quad}\tag{13}
\]
因此即使已作两次平方自由密度再中心化、删去近端与远端，并只保留最小物理 gcd，$F$–$\mu$ 交叉仍比目标 $H^4/M\asymp M^{-1/5}$ 有固定幂大的绝对质量。式 (13) 不下界实际带符号交叉。

证明时取闭区间 $J_1\Subset J_0\Subset(1,2)$，使 $f\ge c_0>0$ 于 $J_0$，并只取 $p/M\in J_1$。素数定理给这样的素数 $\gg_\psi M/\log M$ 个。对每个 $p$，取
\[
\frac B{64}<n-p\le\frac B{32},\qquad
n=3r,\quad r\text{ 为奇平方自由数},\quad (r,3)=1.
\tag{14}
\]
由 note 885 式 (6) 在固定模数 $3$ 的平方自由计数，
\[
\#\{n\le x:n\text{ 满足 (14) 的后三条件}\}
=\frac{x}{\pi^2}+O(\sqrt x).
\]
故每个 $p$ 对应 $B/(64\pi^2)+O(\sqrt M)\gg B$ 个 $n$，因为 $B\asymp M^{4/5}$。这些 $n$ 处于 $MJ_0$，为奇平方自由合数；又因 $0<n-p=o(M)<p$，有 $(p,n)=1$。在当前端点 $K_\alpha/B=H^4e^{\alpha V_Y}/M\to0$，所以 (14) 确实处于式 (13) 的硬环带。

对 $0<n-p\le B/32$，观察权的支撑 $|h|\le4H$ 使 $|2\pi h(p-n)/M|\le\pi/4$。权非负且在 $H\le|h|\le2H$ 至少为一，故 $K_{H,M}(p-n)\gg H$。此外 $F(p)=\log p-\tfrac32\zeta(2)\gg\log M$，$|\mu(n)|=1$，因而 (12) 每对给 $\gg_\psi H\log M/M^2$ 的绝对贡献。乘以 $\gg M/\log M$ 个 $p$ 和每个 $p$ 的 $\gg B$ 个 $n$，得到 $\gg HB/M=1$，即 (13)。$\square$

式 (13) 中还有一个实际同号子块。仍取上述 $p/M\in J_1$，但把 (14) 的合数限制为 $n=3q$，其中 $q$ 是素数且 $B/64<3q-p\le B/32$。则 $\mu(3q)=+1$，所以 (12) 的两端均为负，核为正，并有
\[
\boxed{\quad
\sum_{\substack{p/M\in J_1,\ p\ \text{prime}\\
q\ \text{prime},\ B/64<3q-p\le B/32}}
a_p^{F,\mathrm o}\overline{a_{3q}^{\mu,\mathrm o}}
K_{H,M}(p-3q)
\gg_{\psi,\eta}\frac1{\log M}.
\quad}\tag{15}
\]
确实，对每个 $p$，$q$ 落在长度 $B/192\asymp M^{4/5}$、位置 $\asymp M$ 的区间。note 851 式 (4) 的全区间短素数和与高次素数幂的 $O(\sqrt M\log M)$ 绝对质量给其中 $\gg B/\log M$ 个素数，一致于 $p$。每对仍贡献 $\gg H\log M/M^2$，而 $p$ 有 $\gg M/\log M$ 个，故总量为 $\gg HB/(M\log M)=\gg1/\log M$。所有这些配对的物理 gcd 都是 $1$。式 (15) 只下界此指定子块；完整交叉的其余项仍可能抵消它。

在这个指定的**正核**环带内，真实 Möbius 符号确实提供了相反项。令
\[
S_3=\sum_{\substack{p/M\in J_1,\ p\ \text{prime}\\
r\ \text{odd},\ (r,3)=1,\ B/64<3r-p\le B/32}}
a_p^{F,\mathrm o}\overline{a_{3r}^{\mu,\mathrm o}}K_{H,M}(p-3r).
\]
则存在固定 $c_1>0$ 使
\[
|S_3|\ll_{\psi,\eta}e^{-c_1V_M},
\qquad V_M=\left(\frac{\log M}{\log\log M}\right)^{1/3}.
\tag{16}
\]
记 $S_3^+$ 与 $S_3^-$ 分别为 $\mu(3r)=+1$ 与 $-1$ 的子和；核和其余权在该窗口非负，故 $S_3^+\ge c/\log M$ 由 (15) 给出，$S_3^-\le0$。由于 $e^{-c_1V_M}=o(1/\log M)$，式 (16) 强迫
\[
\boxed{\quad S_3^-\le-\frac{c'}{\log M}\quad}\tag{17}
\]
对某个 $c'>0$ 和充分大的 $M$ 成立。式 (17) 中的 $n$ 有至少三个不同素因子；这是正核区域内由真实 Möbius 符号产生的负交叉，而非 Fourier 核变号造成的负项。事实上两种符号各自都有常数级主项。对固定观察权令 $\eta_*=\eta$；对 note 888 式 (5) 的可变权令 $\eta_*=\eta_0$。按 note 849 的 Fourier 约定置
\[
C_{\psi,\eta_*}(J_1)=\frac{8\log2}{\pi^2}
\left(\int_{J_1}f(v)^2\,dv\right)
\left(\int_{1/64}^{1/32}\widehat{\eta_*}(t)\,dt\right)>0.
\]
则对 $\sigma\in\{+1,-1\}$，若 $S_3^\sigma$ 是 $\mu(3r)=\sigma$ 的子和，有
\[
\boxed{\quad S_3^\sigma=\sigma C_{\psi,\eta_*}(J_1)+o(1),
\qquad S_3=O_{\psi,\eta}(e^{-c_1V_M}).\quad}\tag{17a}
\]
式 (15) 的半素数子块是正号主项的一部分；式 (17a) 同时给出负号子块的常数级规模。

为证 (16)，置 $b(r)=\mu(r)\mathbf1_{(r,6)=1}$。对 $q=2^a3^d$（$a,d\ge0$）求和的卷积恒等式为
\[
b(r)=\sum_{q\mid r,\ q=2^a3^d}\mu(r/q).
\tag{18}
\]
取 $\nu=5/8$。对任何位置 $\asymp M$、长度 $\ell\le B$ 的整数区间 $I$，将 (18) 代入；在 $q\le M^{1/4}$ 上，note 851 式 (4) 对 $I/q$ 中的 Möbius 和给
\[
\ll \frac\ell q e^{-cV_M}+(M/q)^\nu+1,
\]
因为 $M/q\ge M^{3/4}$；缩小固定 $c>0$ 后常数对所有这些 $q$ 一致。对 $q>M^{1/4}$ 用平凡界 $O(\ell/q+1)$。由 $q=2^a3^b$ 的几何级数，$\sum q^{-1},\sum q^{-\nu}\ll1$、$\sum_{q>M^{1/4}}q^{-1}\ll M^{-1/8}$，且活动 $q$ 只有 $O(\log^2M)$ 个。因此每个这样的 $I$ 都满足
\[
\left|\sum_{r\in I}b(r)\right|
\ll\ell e^{-cV_M}+M^{5/8}+\ell M^{-1/8}+\log^2M.
\tag{19}
\]
在 $\ell\le B\asymp M^{4/5}$ 时，右侧一致为 $O(B e^{-c_1V_M})$（再缩小 $c_1$）。

固定 $p$ 后，$r$ 的活动区间长 $B/192$、位置 $\asymp M$；将受限求和延到全部整数 $r$ 时，$\mu(3r)\mathbf1_{(r,6)=1}=-b(r)$。令 $W_p(r)=f(3r/M)K_{H,M}(p-3r)$。由 $\|K_{H,M}\|_\infty\ll H$ 与 $\|K'_{H,M}\|_\infty\ll H^2/M$，此区间上 $\|W_p\|_\infty+\operatorname{Var}W_p\ll_\psi H$。式 (19) 的统一前缀界经离散 Abel 给
\[
\left|\sum_r b(r)W_p(r)\right|\ll_\psi HB e^{-c_1V_M}.
\]
再用 Chebyshev 界 $\sum_{p/M\in J_1}F(p)\ll M$、式 (12) 的两个 $M^{-1}$ 和 $HB=M$，得到 (16)。$\square$

为证 (17a) 的主项，note 885 式 (6) 取 $q=3$ 给
\[
\sum_{\substack{r\le x\\(r,6)=1}}\mu^2(r)
=\frac3{\pi^2}x+O(\sqrt x).
\tag{20}
\]
式 (19) 对位置 $\asymp M$、长度不超过 $B$ 的区间及其前缀一致成立；$\mu(3r)=-b(r)$ 于 $(r,6)=1$。因此对每个 $p$ 和 $\sigma=\pm1$，在
$I_p=((p+B/64)/3,(p+B/32)/3]$ 上有
\[
\#\{r\in I_p:(r,6)=1,\ \mu(3r)=\sigma\}
=\frac{B}{128\pi^2}
+O\!\left(\sqrt M+B e^{-c_1V_M}\right).
\tag{21}
\]
两种符号都给 $\gg B$ 个整数。对上面的 $W_p(r)$，其上确界和总变差均为 $O_\psi(H)$。将 (20) 和 (19) 的统一前缀界分别离散分部求和，得到更精确的带权式
\[
\sum_{\substack{r\in I_p\\(r,6)=1,\ \mu(3r)=\sigma}}W_p(r)
=\frac3{2\pi^2}\int_{I_p}W_p(x)\,dx
+O_\psi\!\left(H\sqrt M+HB e^{-c_1V_M}\right).
\tag{22}
\]
对固定 $\eta$，Poisson 求和给 $K_{H,M}(-Bt)/H=\widehat\eta(t)+o(1)$；对 note 888 的可变权，其式 (5)、(7) 给
$\widehat{\eta_M}(t)=\widehat{\eta_0}(t)\widehat g(at/N)^N\to\widehat{\eta_0}(t)$，且非零别名为 $o(H)$。两种收敛在 $1/64\le t\le1/32$ 上一致。又因 $B/M=1/H$，故在 (22) 中换元 $t=(3x-p)/B$ 后，一致于 $p/M\in J_1$ 有
\[
\frac3{2\pi^2}\int_{I_p}W_p(x)\,dx
=\frac{HB}{2\pi^2}f(p/M)
\int_{1/64}^{1/32}\widehat{\eta_*}(t)\,dt+o(HB).
\tag{23}
\]
式 (12) 与素数定理的加权形式给
\[
\frac1M\sum_{p/M\in J_1}F(p)f(p/M)^2
\longrightarrow\int_{J_1}f(v)^2\,dv.
\tag{24}
\]
将 (22)–(24) 代入 $S_3^\sigma$，使用 $HB=M$；(22) 的总误差至多 $O_\psi(H/\sqrt M+e^{-c_1V_M})=o(1)$，即得 (17a) 的主项。最后 $\eta_*$ 非负、偶、支撑于 $|u|\le4$，而 $0\le t\le1/32$ 时 $\cos(2\pi ut)\ge\cos(\pi/4)>0$；$f$ 在 $J_1$ 上正，故 $C_{\psi,\eta_*}(J_1)>0$。$\square$

## 剩余边界

式 (3)、(11) 使用的都是平方自由**计数**的平方根误差。式 (10) 虽将未付算术对象压成奇数平方自由支撑上的 $F$ 与 $\mu$ 两个波动通道，式 (17a) 也识别了正核区域内大小相同、符号相反的两个真实交叉主项，但这些结论没有对完整中距离 signed 二点相关给出固定幂上界。式 (5) 及其 $w$ 版本不是 RH 或全尺度局部 Weil 正性的证明。

单纯把式 (19) 的**逐窗口**短和升级到这个子块所需的固定幂，也已经承载新的零自由信息。确切地说，若对某个固定 $\kappa>0$、每个 $\varepsilon>0$ 及所有大 $X$，在全部 $X\le x\le2X$ 上一致有
\[
\sum_{x<r\le x+\lfloor\kappa X^{4/5}\rfloor}
\mu(r)\mathbf1_{(r,6)=1}
\ll_{\kappa,\varepsilon}X^{3/5+\varepsilon},
\tag{25}
\]
则把每个 dyadic 区间拆成 $O(X^{1/5})$ 个完整窗口和一个长度 $O(X^{4/5})$ 的余段，得 $\sum_{r\le x}b(r)\ll_\varepsilon x^{4/5+\varepsilon}$。Abel 求和于是使
$\sum_{r\ge1}b(r)r^{-s}
=1/[\zeta(s)(1-2^{-s})(1-3^{-s})]$
在 $\Re s>4/5$ 全纯，故 $\zeta(s)$ 在该半平面没有零点。式 (25) 是一个**未证明的充分输入**；完整环带也可能通过平均二点抵消达到目标，而不满足这样的逐窗口界。
