> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 相邻窗口差给三通道观察频带的零频消失门

日期：2026-10-03。依赖 [note 849](849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)–(15)、(26)，并细化 [note 869](869-three-channel-short-interval-variance-forces-a-zeta-derivative-gate.md) 的短区间充分条件。本结果是精确 Fourier 恒等式与充分性归约；下面的算术均方输入尚未证明，故不支付真实 signed covariance，也不证明 RH。

## 定理

沿整数 \(Y\to\infty\)，令 \(M=2Y\)、\(Y^{1/5}\le H\le Y^{1/4}\)、
\[
L_H=\left\lfloor\frac{M}{32H}\right\rfloor,
\quad a_x=\frac{c(M+x)}{M+x}\psi\!\left(1+\frac xM\right),
\quad b_x=c(M+x),\qquad 0\le x<M,
\tag{1}
\]
并把 \(a,b\) 延拓成模 \(M\) 的周期序列。这里 \(c\) 是 note 849 式 (10) 的真实三通道系数，固定 \(\psi\in C_c^3((1,2))\)。对任意周期序列 \(v\) 定义相邻窗口差
\[
\mathsf H_Lv(x)=
\sum_{j=0}^{L-1}v_{x-j}
-\sum_{j=L}^{2L-1}v_{x-j},
\quad V_H(Y)=\sum_{x\bmod M}|\mathsf H_{L_H}b(x)|^2.
\tag{2}
\]
固定非负偶 \(\eta\in C_c^\infty(\mathbb R)\)，支撑于 \(1/2\le|t|\le4\)，且在 \(1\le|t|\le2\) 上至少为一。令 \(\mathcal A_h(Y)\) 如 note 849 式 (11)，则
\[
\boxed{\quad
\sum_{h\in\mathbb Z}\eta(h/H)|\mathcal A_h(Y)|^2
\ll_{\psi,\eta}
\frac{H^2}{Y^3}V_H(Y)+\frac{\log^2(2Y)}{H^2}.
\quad}\tag{3}
\]
因此，若对每个 \(\varepsilon>0\) 有真实带符号算术界
\[
\boxed{\quad V_H(Y)\ll_{\varepsilon}H^2Y^{2+\varepsilon}
\quad(Y^{1/5}\le H\le Y^{1/4}),\quad}\tag{4}
\]
则 note 849 式 (15) 在这段频带上成立。此处 (4) 仍未证明。

作为量纲基线，Young 不等式及 \(\sum_{M<m<2M}|c(m)|^2\ll Y\log(2Y)\) 只给
\(V_H(Y)\ll Y^3H^{-2}\log(2Y)\)。在 \(H=Y^{1/5}\) 时，这比 (4) 差 \(Y^{1/5}\)（另有对数）；相邻窗口相减本身没有支付算术门。

令 \(C_b(k)=\sum_{x\bmod M}b_xb_{x+k}\)。由于 \(4L_H<M\)，(2) 还给出精确的紧支撑相关式
\[
V_H=2L_HC_b(0)
+2\sum_{1\le k<L_H}(2L_H-3k)C_b(k)
+2\sum_{L_H\le k<2L_H}(k-2L_H)C_b(k).
\tag{4a}
\]
两个非对角权的总和与对角权合为零。对角项本身只有
\(2L_HC_b(0)\ll Y^2H^{-1}\log(2Y)=o(H^2Y^2)\)；(4) 未付的部分确实是带符号的**不同指标相关**，且物理位移严格限于 \(|k|<2L_H\)。

这个窗口差还保留了三通道的原始算术内容。令 \(\Psi(t)=\sum_{n\le t}\Lambda(n)\)、\(M_\mu(t)=\sum_{n\le t}\mu(n)\)、\(E(t)=\Psi(t)-t\)。对每个整数 \(x\ge1\)，直接对 (1) 的系数求和得
\[
C(x)=2E(x/2)-4E(x)-4(\log2)M_\mu(x)
+\{x-2\lfloor x/2\rfloor\}.
\tag{4b}
\]
于是对不触及周期拼接点的 \(x\)，\(\mathsf H_{L_H}b(x)\) 恰为 (4b) 右侧在 \(M+x,M+x-L_H,M+x-2L_H\) 三点的二阶差。最后的 parity 项逐点至多为四，平方总量 \(O(Y)\)；真正的 (4) 是这两种素数误差与 Möbius 部分和的**联合二阶差分均方**，不能分别用现有零自由区误差取绝对值支付。

还可在 (4) 的目标量级内只保留 note 849 式 (29) 的三个真实通道。记其系数为 \(c_{\rm tri}(m)\)，并令 \(b^{\rm tri}_x=c_{\rm tri}(M+x)\)。note 849 式 (31) 把 \(c-c_{\rm tri}\) 分成 \(4-2\mathbf1_{2\mid m}\) 和两个高次素数幂项。常数的两窗差为零，偶数指标的两窗差为 \(O(1)\)；高次素数幂在整个物理段的绝对质量为 \(O(\sqrt Y\log(2Y))\)，故每个窗口差至多同阶。于是
\[
\sum_{x\bmod M}|\mathsf H_{L_H}(b-b^{\rm tri})(x)|^2
\ll Y^2\log^2(2Y)=o(H^2Y^2).
\tag{4c}
\]
平方范数的三角不等式表明 (4) 对 \(b\) 成立当且仅当同量级估计对 \(b^{\rm tri}\) 成立。这里的三通道是两个素数臂和 Möbius 臂；它们的联合交叉仍是未付项。

## 证明

采用离散 Fourier 约定 \(\widehat v(h)=\sum_{x\bmod M}v_xe(-hx/M)\)。令
\(B_L(h)=\sum_{j=0}^{L-1}e(-hj/M)\)。由 (2) 逐项换元得精确恒等式
\[
\widehat{\mathsf H_Lv}(h)
=B_L(h)\{1-e(-hL/M)\}\widehat v(h)
=\frac{\{1-e(-hL/M)\}^2}{1-e(-h/M)}\widehat v(h),
\tag{5}
\]
分母为零时取连续值；特别 \(\widehat{\mathsf H_Lv}(0)=0\)。

在 \(\eta(h/H)\ne0\) 时，\(H/2\le|h|\le4H\)。由 \(L=L_H\) 得对充分大 \(Y\)
\[
\frac1{70}\le\frac{|h|L}{M}\le\frac18,
\qquad \frac{|h|}{M}=o(1).
\]
几何和公式于是给 \(|B_L(h)|\gg L\)、\(|1-e(-hL/M)|\gg1\)，且这些 \(h\) 模 \(M\) 互异。式 (5)、周期 Parseval 及 \(\widehat a(h)=\mathcal A_h(Y)\) 证明
\[
\sum_h\eta(h/H)|\mathcal A_h(Y)|^2
\ll_\eta\frac M{L^2}\sum_{x\bmod M}|\mathsf H_La(x)|^2.
\tag{6}
\]

写 \(w_x=\psi(1+x/M)/(M+x)\)，则 \(a_x=w_xb_x\)。由于 \(\psi\) 在 \((1,2)\) 内紧支撑，\(w_x\) 在周期拼接点附近的固定比例区间为零；而 \(2L=o(M)\)。因而对窗口触及拼接点的 \(x\)，\(\mathsf H_La(x)=w_x=0\)。其余窗口可按普通整数顺序比较，且
\(|w_x|\ll_\psi Y^{-1}\)、\(|w_{x-j}-w_x|\ll_\psi jY^{-2}\)。再用 \(|c(m)|\ll\log(2Y)\)，逐窗口得到
\[
|\mathsf H_La(x)-w_x\mathsf H_Lb(x)|
\ll_\psi\frac{L^2\log(2Y)}{Y^2}.
\tag{7}
\]
将 (7) 平方求和，得到
\[
\sum_x|\mathsf H_La(x)|^2
\ll_\psi \frac{V_H(Y)}{Y^2}
+\frac{ML^4\log^2(2Y)}{Y^4}.
\tag{8}
\]
由 \(M\asymp Y\)、\(L\asymp Y/H\)，(6)–(8) 即给 (3)。在给定的 \(H\) 范围内，\(\log^2(2Y)/H^2=o(H^4/Y)\)，因为 \(H^6/Y\ge Y^{1/5}\)。若 (4) 成立，(3) 便给 \(\sum_h\eta(h/H)|\mathcal A_h|^2\ll_\varepsilon H^4Y^{-1+\varepsilon}\)。note 849 式 (13)–(15) 已无条件支付极近和极远差值，并证明该频带界蕴含其式 (15)。\(\square\)

## 为何它比整窗均方弱

零频严格消失是 (5) 的结构事实。作为不涉及算术系数 \(c\) 的确定性比较，若 \(v_m\equiv1\)，则任意相邻两窗差恒为零，而整窗和为 \(L\)，部分和为 \(\asymp X\)。更一般地，固定 \(9/10<\beta\le1\)，取 \(v_m=m^{\beta-1}\) 于 \(m\asymp X\)、\(L\asymp X^{4/5}\)。均值定理给
\[
|\mathsf H_Lv(x)|\ll_\beta L^2X^{\beta-2},
\qquad
\sum_{x\asymp X}|\mathsf H_Lv(x)|^2
\ll_\beta X^{2\beta+1/5}\le X^{11/5},
\tag{9}
\]
同时 \(\sum_{m\le X}v_m\asymp X^\beta\)。所以仅凭相邻窗口差的抽象均方界，不能推出 note 869 式 (3) 的全局部分和界。式 (9) 只比较两类输入的逻辑强弱，不证明真实 \(c(m)\) 满足 (4)；增长高度的零点和真实素数、Möbius 交叉仍可能支配 (4)。

## 一点短和不能直接支付 Haar 固定幂

note 851 的全区间短和强于普通零自由区估计，但单靠这种一点输入仍不能推出 (4)。对此有显式的有界周期反模型。取 \(H=Y^{1/5}\)、\(L=L_H\)、\(h_0=\lceil H\rceil\)，令 \(V_Y=(\log Y/\log\log Y)^{1/3}\)、\(\delta_Y=e^{-cV_Y}\)，并在 \(\mathbb Z/M\mathbb Z\) 上置
\[
v_x=\delta_Y\cos(2\pi h_0x/M).
\tag{10}
\]
它逐点有界、全周期和为零，并对**每个**整数区间 \(I\) 满足 \(|\sum_{x\in I}v_x|\le\delta_Y|I|\)。特别地，长度 \(Q=\lfloor Y^{2/3}\rfloor\) 的全部短和都满足 note 851 式 (5) 型的 \(O(Qe^{-cV_Y})\) 上界，且 \(\sum_x|v_x|^2\le M\)。

但 \(h_0L/M\to1/32\)，故 (5) 的 Haar 乘子在 \(h_0\) 处满足
\(\left|B_L(h_0)\{1-e(-h_0L/M)\}\right|\asymp L\)。\(v\) 只有 \(\pm h_0\) 两个 Fourier 模，周期 Parseval 精确给
\[
\sum_{x\bmod M}|\mathsf H_Lv(x)|^2
=\frac{M\delta_Y^2}{2}
\left|B_L(h_0)\{1-e(-h_0L/M)\}\right|^2
\asymp\delta_Y^2\frac{M^3}{H^2}.
\tag{11}
\]
式 (11) 与 (4) 的 \(H^2Y^2\asymp H^2M^2\) 之比为
\(\asymp\delta_Y^2M/H^4=M^{1/5-o(1)}\to\infty\)。这只关闭“由一致一点短和、逐点界及零均值直接推出 (4)”的推法；\(v\) 不是实际 \(c(m)\)。真实系数仍须在 (4a) 中取得二点 signed 消去。
