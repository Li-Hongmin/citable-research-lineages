> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 正核领圈内平方自由奇偶臂的密度抵消与物理互素负 Gram

日期：2026-10-03。**证明草案，异源复核未完成。**依赖 [note 849](849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实观察核、[note 851](851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 式 (4) 的全区间短和、[note 888](888-scale-adaptive-observation-weight-gives-a-single-logarithm-collar.md) 的可变权以及 [note 889](889-centered-squarefree-profile-removes-nonsquarefree-observation-core.md) 式 (9)–(11) 的平方自由两臂。本文在留存的**正核**位移窗口求出五个真实通道的有向 Gram 主项，并给出双臂 $F$–$F$ 物理互素子 Gram 的显式负主项。素数与平方自由背景在每个奇偶臂内各自抵消；Möbius 通道在此精度下只有误差。完整固定幂算术门仍未证明。

## 定理

沿整数 $Y\to\infty$，置
\[
M=2Y,\quad Y^{1/5}\le H\le Y^{1/4},\quad B=M/H,\quad
V_M=(\log M/\log\log M)^{1/3}.
\]
固定 $\psi\in C_c^3((1,2);\mathbb C)$，令 $f(v)=\psi(v)/v$、$I_\psi=\int_1^2|f(v)|^2\,dv$。观察权 $\eta_{M}$ 可以是 note 849 的一个固定合格非负偶光滑权，也可以是 note 888 式 (5) 取 $A=2$ 的可变权；记
\[
K_{H,M}(k)=\sum_{h\in\mathbb Z}\eta_M(h/H)e(-hk/M),
\qquad \widehat\eta_M(t)=\int\eta_M(u)e(-ut)\,du.
\]
固定 note 888 所容许的 $\alpha>0$，取任意整数
\[
K_\alpha=\lfloor H^3e^{\alpha V_Y}\rfloor\le L\le B/64.
\tag{1}
\]
对所有正整数 $m$ 定义五个系数，并在观察窗口 $M<m<2M$ 使用：
\[
\begin{array}{lll}
d_{P_o}(m)=-4\mathbf1_{m=p\ {m prime}}\log p,
&d_{Q_o}(m)=6\zeta(2)\mathbf1_{2\nmid m}\mu^2(m),\\
d_{P_e}(m)=2\mathbf1_{m=2p,\ p\ {m prime}}\log p,
&d_{Q_e}(m)=-3\zeta(2)\mathbf1_{2\mid m}\mu^2(m),\\
d_\mu(m)=-4(\log2)\mu(m).
\end{array}
\tag{2}
\]
下标 $o,e$ 分别表示物理位置的奇、偶臂。令
\[
a_m^{(i)}=\mathbf1_{M<m<2M}\frac{d_i(m)}M f(m/M),\qquad
T_{ij}(L)=\sum_{L<n-m\le2L}a_m^{(i)}\overline{a_n^{(j)}}K_{H,M}(m-n).
\tag{3}
\]
则 $\sum_i d_i(m)$ 精确等于 note 889 的平方自由系数 $w(m)$。写
\[
(\kappa_{P_o},\kappa_{Q_o},\kappa_{P_e},\kappa_{Q_e},\kappa_\mu)=(-4,4,1,-1,0),
\qquad J_M(L)=\int_{L/B}^{2L/B}\widehat\eta_M(t)\,dt.
\tag{4}
\]
存在固定 $c>0$，使 (1) 中全部 $H,L$ 及五个指标对一致满足
\[
\boxed{\quad T_{ij}(L)=\kappa_i\kappa_j I_\psi J_M(L)
+O_{\psi,\eta}\!\left(\frac LB e^{-cV_M}\right).\quad}
\tag{5}
\]
而且 $J_M(L)\asymp_\eta L/B>0$。特别地，
\[
T_{P_oP_o}=16I_\psi J_M+O((L/B)e^{-cV_M}),\quad
T_{P_oQ_o}=-16I_\psi J_M+O((L/B)e^{-cV_M}),\quad
T_{Q_oQ_o}=16I_\psi J_M+O((L/B)e^{-cV_M}),
\tag{6}
\]
偶臂的相应三个主系数为 $1,-1,1$。将 $P_o+Q_o$、$P_e+Q_e$、$\mu$ 视为三个合并通道，则它们之间的每个有向 Gram 都为 $O((L/B)e^{-cV_M})$。这项抵消在观察核为正的区域内发生；若 $\psi\ge0$ 为实函数，式 (6) 的 $P_o$–$Q_o$ 每个非零配对都是非正的。

在 $T_{P_oQ_o}$ 中再要求右端 $n$ 为奇平方自由**合数**，所得子和仍满足
\[
\boxed{\quad
T_{P_oQ_o}^{\rm comp}(L)
=-16I_\psi J_M(L)+O_{\psi,\eta}\!\left(\frac{L}{B\log M}\right).
\quad}\tag{6a}
\]
因此 $I_\psi>0$ 时，正核窗口里已有一个固定符号的真实素数–合数负交叉，大小为 $\asymp L/B$。

上述结论在每对指标中再限制物理 $\gcd(m,n)\le G_{\rm phys}:=\lceil M\log^2(2M)/H^4\rceil$ 后仍成立，允许缩小 $c$。尤其主阶负交叉留在 note 889 式 (5a) 尚未支付的物理 gcd 核心里。

还可精确分离物理 $\gcd(m,n)=1$。置 $F_o=P_o+Q_o$，并在 (3) 的两个端点上施加 $(m,n)=1$，记所得有向 Gram 为 $T_{F_oF_o}^{(1)}(L)$。定义收敛 Euler 乘积
\[
\Theta_o=
\prod_{p\ge3\ {m prime}}
\frac{1-3p^{-2}+2p^{-3}}{(1-p^{-2})^2},
\qquad 0<\Theta_o<1.
\tag{7}
\]
则对任意固定 $0<\epsilon<1/20$，
\[
\boxed{\quad
T_{Q_oQ_o}^{(1)}(L)
=16\Theta_o I_\psi J_M(L)
+O_{\psi,\eta,\epsilon}\!\left(\frac LB M^{-1/10+\epsilon}\right),
\quad}\tag{8}
\]
\[
\boxed{\quad
T_{F_oF_o}^{(1)}(L)
=-16(1-\Theta_o)I_\psi J_M(L)
+O_{\psi,\eta}\!\left(\frac LB e^{-cV_M}\right).
\quad}\tag{9}
\]
若 $I_\psi>0$，式 (9) 的实部对充分大 $M$ 严格为负。相反，不限 gcd 的 $F_o$–$F_o$ 主项由 (5) 为零。因此物理共同因子大于 $1$ 的奇平方自由–平方自由配对，恰有 $+16(1-\Theta_o)I_\psi J_M(L)$ 的正主项；由上面的高 gcd 支付，这个正主项全部位于 $1<(m,n)\le G_{\rm phys}$。这里的负主项是**截取真实算术配对后的有向 Gram**，不与完整频带能量的非负性冲突。

同一常数还控制混合奇偶互素配对。令 $F_{\rm phys}=P_o+Q_o+P_e+Q_e$，即从 $w$ 中仅取两个 $F$ 臂而暂不取 $\mu$ 臂。对 $(i,j)=(Q_o,Q_e)$ 或 $(Q_e,Q_o)$ 均有
\[
T_{ij}^{(1)}(L)
=-4\Theta_o I_\psi J_M(L)
+O_{\psi,\eta,\epsilon}\!\left(\frac LB M^{-1/10+\epsilon}\right),
\tag{9a}
\]
并且
\[
\boxed{\quad
T_{F_{\rm phys}F_{\rm phys}}^{(1)}(L)
=-8(1-\Theta_o)I_\psi J_M(L)
+O_{\psi,\eta}\!\left(\frac LB e^{-cV_M}\right).
\quad}\tag{9b}
\]
因此只取互素物理配对的**完整双臂 $F$–$F$** 子 Gram 仍有严格负主项。不限 gcd 的同一 $F$–$F$ 主项为零，所以 $1<(m,n)\le G_{\rm phys}$ 的双臂配对必须给出 $+8(1-\Theta_o)I_\psi J_M(L)$ 的补偿主项。

这一结论也保留**全部 Möbius 通道**。令 $T_{ww}^{(1)}$ 在 (3) 中取五项之和 $w$ 并要求 $(m,n)=1$。则
\[
\boxed{\quad
T_{ww}^{(1)}(L)
=-8(1-\Theta_o)I_\psi J_M(L)
+O_{\psi,\eta}\!\left(\frac LB e^{-cV_M}\right).
\quad}\tag{9c}
\]
不限 gcd 的同一完整 $w$–$w$ 有向 Gram 是 $O((L/B)e^{-cV_M})$，故 $1<(m,n)\le G_{\rm phys}$ 的**完整三通道**配对必须产生 $+8(1-\Theta_o)I_\psi J_M(L)$ 的补偿主项。当 $H=Y^{1/5}$、$L=\lfloor M^{3/5+\delta}\rfloor$ 且 $0<\delta<1/5$ 时，两部分各为 $\asymp M^{-1/5+\delta}$；因此对 $\varepsilon<\delta$，不能分别以 note 849 式 (15) 的 $M^{-1/5+\varepsilon}$ 尺度支付它们。式 (9c) 不控制所有位移的 Gram，也不提供该固定幂上界。

## 证明

先核对精确分解。note 889 式 (2)、(9) 给
\[
w(m)=3\zeta(2)\mu^2(m)-q_2(m)-4\mathbf1_{m=p}\log p
+2\mathbf1_{m=2p}\log p-4(\log2)\mu(m).
\]
当 $m$ 奇时，$3\zeta(2)\mu^2-q_2=6\zeta(2)\mu^2$；当 $m$ 偶时它等于 $-3\zeta(2)\mu^2$。这正是 (2) 的五项之和。

平方自由计数及其奇数版本给每个 $x\asymp M$，
\[
\sum_{n\le x,\;2\nmid n}\mu^2(n)=\frac4{\pi^2}x+O(\sqrt x),
\qquad
\sum_{n\le x,\;2\mid n}\mu^2(n)=\frac2{\pi^2}x+O(\sqrt x).
\tag{10}
\]
故 $Q_o,Q_e$ 的每整数密度分别是
$6\zeta(2)\cdot4/\pi^2=4$ 与 $-3\zeta(2)\cdot2/\pi^2=-1$。
note 851 式 (4) 对 $\mu$ 和 $\Lambda-1$ 可取固定 $\nu=59/100$。对 $P_o$ 使用 $\Lambda$ 的短和并扣除高次素数幂；对 $P_e$ 先作 $m=2p$ 换元。高次素数幂在 $m\asymp M$ 的总 $\Lambda$ 质量为 $O(\sqrt M\log^2 M)$。于是对每个长度至多 $2L$、位置 $\asymp M$ 的整数区间 $I$，以及 $I$ 的每个前缀，统一有
\[
\sum_{n\in I}d_i(n)
=\kappa_i|I|+O\!\left(|I|e^{-c_0V_M}+M^\nu+\sqrt M\log^2 M\right)
=\kappa_i|I|+O(Le^{-c_1V_M}).
\tag{11}
\]
最后一个等式使用 $L\ge K_\alpha\gg M^{3/5}$；缩小 $c_1>0$ 即可吸收固定幂余项。相同输入给
\[
\sum_{n\in I}|d_i(n)|\ll L\quad(|I|\asymp L),
\qquad
\sum_{M<m<2M}|d_i(m)|\ll M,
\tag{12}
\]
以及对固定 BV 权 $|f|^2$ 的全段分部求和式
\[
\sum_{M<m<2M}d_i(m)|f(m/M)|^2
=\kappa_i M I_\psi+O_\psi(Me^{-c_1V_M}).
\tag{13}
\]

固定活动的外端 $m$。函数 $n\mapsto\overline{f(n/M)}K_{H,M}(m-n)$ 在 $m+L<n\le m+2L$ 上的上确界及总变差均为 $O_\psi(H)$：note 888 的统一核界为 $\|K_{H,M}\|_\infty\ll H$、$\|K'_{H,M}\|_\infty\ll H^2/M$，而 $HL/M=L/B\le1/64$。以 (11) 的前缀界作离散分部求和，再把 $f(n/M)$ 冻结在 $m/M$，利用 (12)，得到
\[
\sum_{m+L<n\le m+2L}\overline{d_j(n)f(n/M)}K_{H,M}(m-n)
=\kappa_j\overline{f(m/M)}\int_{m+L}^{m+2L}K_{H,M}(m-x)\,dx
+O_\psi\!\left(HLe^{-c_1V_M}+\frac{HL^2}{M}\right).
\tag{14}
\]
由于 $f$ 在 $(1,2)$ 内紧支撑，活动的 $m$ 与两端相隔固定比例，充分大时这里不产生窗口外边界。

note 849 的 Poisson 公式及 note 888 式 (5a) 的统一导数界给任意固定 $A>2$、$L\le k\le2L$，
\[
K_{H,M}(-k)=H\widehat\eta_M(k/B)+O_A(H^{1-A}).
\tag{15}
\]
故 (14) 中的积分为
\[
HBJ_M(L)+O_A(LH^{1-A}).
\tag{16}
\]
将 (14)–(16) 乘以 $d_i(m)f(m/M)/M^2$ 后对 $m$ 求和，用 (12)–(13) 与 $HB=M$，得到主项 $\kappa_i\kappa_jI_\psi J_M(L)$，误差至多
\[
O\!\left(\frac LB e^{-c_1V_M}
+\frac LB\frac LM+\frac LB H^{-A}\right).
\]
因 $L/M\le1/(64H)$、$H\gg M^{1/5}$，固定幂项可吸收入缩小常数后的 $e^{-cV_M}$，证明 (5)。

两种权均非负、偶、支撑于 $|u|\le4$，并在 $1\le|u|\le2$ 至少为一。当 $0\le t\le2L/B\le1/32$ 时，$\cos(2\pi ut)\ge\cos(\pi/4)>0$，故 $\widehat\eta_M(t)$ 有统一正下界与上界。这证明 $J_M(L)\asymp L/B$、(6) 与合并通道的陈述。

在 (6) 的 $P_o$–$Q_o$ 子和中，若右端 $n$ 也为素数，则每个外端素数 $m$ 对应的内端素数个数由 (11) 至多为 $O(L/\log M)$；全体外端素数至多 $O(M/\log M)$。这类配对的系数绝对值分别为 $O(\log M/M)$、$O(1/M)$，而核为 $O(H)$，故其绝对总贡献为
\[
O\!\left(\frac{H}{M^2}\frac{M}{\log M}\frac{L}{\log M}\log M\right)
=O\!\left(\frac{L}{B\log M}\right).
\]
从 $T_{P_oQ_o}$ 扣除这些配对，便得 (6a)。

最后，若 $g=(m,n)>G_{\rm phys}>2$ 且 $0<n-m\le2L=o(M)$，两端都不可能是素数或二倍素数：与 $p$ 或 $2p$ 不同的、具有大于 $2$ 的共同因子的最近倍数相距 $\gg M$。余下三个通道在平方自由位置的系数有绝对常数界。因 $g\mid n-m$，有 $g\le2L$；对每个 $g$，活动有序对数为 $O((M/g)(L/g))$。允许重复计数并用 $|K_{H,M}|\ll H$，每对指标的高 gcd 部分绝对值至多
\[
O\!\left(\frac{H}{M^2}\sum_{g>G_{\rm phys}}\frac{ML}{g^2}\right)
=O\!\left(\frac{L/B}{G_{\rm phys}}\right)
=O\!\left(\frac LB e^{-c'V_M}\right).
\]
这里 (1) 保证 $H^4e^{\alpha V_Y}\le M$，从而 $G_{\rm phys}\gg e^{\alpha V_Y}\log^2M$。缩小 $c$，得到 gcd 限制后的版本。$\square$

## 物理互素配对的证明

对奇数 $q$，note 885 式 (6) 的平方自由计数给
\[
\sum_{\substack{n\le x\\(n,2q)=1}}\mu^2(n)
=\rho_o(q)x+O(\tau(2q)\sqrt x),
\qquad
\rho_o(q)=\frac4{\pi^2}\prod_{p\mid q}\frac p{p+1}.
\tag{17}
\]
这对 $q\asymp M$ 仍一致：平方自由恒等式只产生 $O(\tau(2q)\sqrt x)$ 个取整误差。为平均外端的密度，置
\[
h(q)=\mathbf1_{2\nmid q}\mu^2(q)\prod_{p\mid q}\frac p{p+1}.
\]
其 Dirichlet 级数在 $\Re s>1$ 中可写为 $\zeta(s)B(s)$，其中
\[
B(s)=(1-2^{-s})
\prod_{p\ge3}\left(1-\frac{p^{-s}}{p+1}
-\frac{p}{p+1}p^{-2s}\right).
\tag{18}
\]
乘积 $B$ 的 Dirichlet 系数 $b(d)$ 对每个固定 $\epsilon>0$ 满足
$\sum_d|b(d)|d^{-1/2-\epsilon}<\infty$：奇素数的两个非平凡局部系数分别为 $-1/(p+1)$、$-p/(p+1)$，其加权素数和分别由 $\sum_p p^{-3/2-\epsilon}$、$\sum_p p^{-1-2\epsilon}$ 控制；素数 $2$ 只贡献一次因子。因此 $h=1*b$，取整求和给
\[
\sum_{q\le x}h(q)=B(1)x+O_\epsilon(x^{1/2+\epsilon}),
\qquad
B(1)=\frac12\prod_{p\ge3}
\left(1-\frac1p\right)
\left(1+\frac1{p+1}\right).
\tag{19}
\]
因为 $\rho_o(q)=(4/\pi^2)\prod_{p\mid q}p/(p+1)$，式 (19) 与固定 BV 权的分部求和给
\[
\sum_{M<q<2M}\mathbf1_{2\nmid q}\mu^2(q)\rho_o(q)|f(q/M)|^2
=C_o M I_\psi+O_{\psi,\epsilon}(M^{1/2+\epsilon}),
\tag{20}
\]
其中
\[
C_o=\frac4{\pi^2}B(1)
=\frac14\prod_{p\ge3}(1-3p^{-2}+2p^{-3}),
\qquad
d_o:=\frac4{\pi^2},\quad C_o=d_o^2\Theta_o.
\tag{21}
\]
后一乘积也可逐素数核对：对奇素数 $p$，两个独立指标均平方自由且不同时被 $p$ 整除的局部密度是 $1-3p^{-2}+2p^{-3}$；素数 $2$ 要求两指标都奇，给 $1/4$。并且
\[
(1-p^{-2})^2-(1-3p^{-2}+2p^{-3})=(p-1)^2p^{-4}>0,
\]
所以 $0<\Theta_o<1$。

固定奇平方自由外端 $m\asymp M$，在 $m+L<n\le m+2L$ 的每个前缀上，把 (17) 用于 $q=m$，则
\[
\sum_{\substack{n\in I\\(m,n)=1}}d_{Q_o}(n)
=6\zeta(2)\rho_o(m)|I|+O_\epsilon(M^{1/2+\epsilon}).
\tag{22}
\]
沿用 (14) 的同一核变差估计、冻结 $f(n/M)$ 并应用 Poisson 公式 (15)，内端和等于
\[
6\zeta(2)\rho_o(m)HB\overline{f(m/M)}J_M(L)
+O_{\psi,\eta,\epsilon}\!\left(HM^{1/2+\epsilon}
+\frac{HL^2}{M}+LH^{1-A}\right).
\tag{23}
\]
外端乘 $d_{Q_o}(m)f(m/M)/M^2$ 后求和，使用 (20)、$HB=M$ 与 $\sum_{m\asymp M}|d_{Q_o}(m)|\ll M$。主项成为
$(6\zeta(2))^2 C_oI_\psi J_M(L)=16\Theta_oI_\psi J_M(L)$；误差相对于 $L/B=HL/M$ 至多为
\[
O_\epsilon\!\left(\frac{M^{1/2+\epsilon}}L
+\frac LM+H^{-A}\right)
=O_\epsilon(M^{-1/10+\epsilon}),
\]
其中 $L\gg M^{3/5}$。这证明 (8)。

若某端是 $P_o$ 的素数 $p\asymp M$，另一端与之相距至多 $2L=o(M)$ 且不相等，则两端自动互素。因此 (5) 的 $P_oP_o$、$P_oQ_o$、$Q_oP_o$ 三个主项在互素限制下不变。它们合计 $16-16-16=-16$；再加 (8) 即得 (9)。不限 gcd 时 $Q_oQ_o$ 的主项是 $+16$，故差为 $16(1-\Theta_o)$。上一节高 gcd 的绝对界把这个差定位到 $1<(m,n)\le G_{\rm phys}$。$\square$

对于奇外端 $m$、偶内端 $n=2r$，(17) 在 $r$ 的半长区间给偶平方自由内端的每整数密度 $\rho_o(m)/2$，误差仍为 $O_\epsilon(M^{1/2+\epsilon})$。重复 (22)–(23) 的分部求和，改用 $d_{Q_e}(n)=-3\zeta(2)\mu^2(n)\mathbf1_{2\mid n}$，所得主系数是
\[
(6\zeta(2))\left(-\frac{3\zeta(2)}2\right)C_o
=-4\Theta_o.
\]
外端为偶、内端为奇时，令外端 $m=2r$；$r$ 在半长区间中的平均密度同样使外层的 $C_o$ 再乘 $1/2$，内端使用 $6\zeta(2)\rho_o(r)$，所以主系数仍为 $-4\Theta_o$。两种方向的内层平方自由计数误差、冻结误差及外层平均误差均与 (23) 同阶，证明 (9a)。

所有含 $P_o$ 的近位移配对都物理互素：$P_o=p>M$ 的另一倍数不在窗口内。含 $P_e=2p$ 且另一端为奇数的配对也互素，因为最近可能共有因子 $p$ 的不同位置与 $2p$ 相距至少 $p\gg M$。偶–偶配对绝无物理互素者。因此双臂 $F_{\rm phys}$ 的互素主系数来自奇–奇的 $-16(1-\Theta_o)$ 和两个混合方向各 $+4(1-\Theta_o)$，总计 $-8(1-\Theta_o)$，证明 (9b)。高 gcd 支付同前。$\square$

## 互素 Möbius 短和与完整三通道

需要一条对变化的外端 $m$ 一致的短和。对所有 $1\le m\le3M$ 与位于 $[M/2,3M]$、长度不超过 $2L$ 的整数区间 $I$，有某个固定 $c_2>0$ 使
\[
\boxed{\quad
\left|\sum_{n\in I}\mu(n)\mathbf1_{(n,m)=1}\right|
\ll L e^{-c_2V_M}.
\quad}\tag{24}
\]
证明时令 $a_m(q)=1$ 当 $q$ 的每个素因子都整除 $m$，否则令 $a_m(q)=0$。Dirichlet Euler 乘积给精确卷积
\[
\mu(n)\mathbf1_{(n,m)=1}=(\mu*a_m)(n),
\qquad
\sum_{q\ge1}\frac{a_m(q)}{q^s}
=\prod_{p\mid m}(1-p^{-s})^{-1}\quad(\Re s>1).
\tag{25}
\]
记 $E_\sigma(m)=\prod_{p\mid m}(1-p^{-\sigma})^{-1}$。对任意固定 $0<\sigma<1$，从 $p\le\log M$ 与 $p>\log M$ 两段直接估计
\[
\log E_\sigma(m)
\ll_\sigma(\log M)^{1-\sigma}=o(\log M),
\qquad E_1(m)\ll(\log M)^C
\tag{26}
\]
一致于 $m\le3M$。后一式用 $\sum_{p\le\log M}p^{-1}\ll\log\log M$，且 $m$ 中大于 $\log M$ 的素因子至多 $O(\log M/\log\log M)$ 个。

在 (25) 的卷积和中先取 $q\le M^{1/8}$。note 851 式 (4) 取 $\nu=59/100$，对缩放区间 $I/q$ 的 Möbius 和一致给
\[
\ll (|I|/q)e^{-c_0V_M}+(M/q)^\nu+1,
\]
因为起点 $\asymp M/q\ge M^{7/8}$，故其 $V_{M/q}$ 与 $V_M$ 可比。对此求和，利用 (26)，总量至多
\[
O\!\left(L e^{-c_0V_M}E_1(m)
+M^\nu E_\nu(m)+M^{1/2+o(1)}\right).
\tag{27}
\]
最后一项也覆盖 $+1$ 项，因为
$\#\{q\le3M:a_m(q)=1\}\le(3M)^{1/2}E_{1/2}(m)=M^{1/2+o(1)}$。

对 $q>M^{1/8}$ 用平凡的 $O(|I|/q+1)$ 计数。Rankin 界与 (26) 给
\[
\sum_{q>M^{1/8}}\frac{a_m(q)}q
\le M^{-1/32}E_{3/4}(m)
=M^{-1/32+o(1)},
\]
而 $+1$ 项的总数仍为 $M^{1/2+o(1)}$。因 $L\gg M^{3/5}$、$\nu=59/100<3/5$，(27) 与尾部的固定幂误差都可吸收进缩小常数后的 $Le^{-c_2V_M}$，证明 (24)。同一界对 $I$ 的每个前缀成立。

固定任意外端 $m$、任意五通道系数 $d_i(m)$，把 (24) 用于内端的 $d_\mu(n)=-4(\log2)\mu(n)$。核和 $f$ 在长度 $L$ 窗口的上确界与总变差为 $O_\psi(H)$，所以离散分部求和给内端 $O_\psi(HLe^{-c_2V_M})$。由 $\sum_{M<m<2M}|d_i(m)|\ll M$，归一化后
\[
T_{i\mu}^{(1)}(L)\ll_{\psi,\eta}\frac LB e^{-c_2V_M}.
\tag{28}
\]
互换两个端点并使用反向位移区间的同一个 (24)，也得到 $T_{\mu i}^{(1)}(L)$ 的相同界，包括 $i=\mu$。于是完整 $w$ 的互素有向 Gram 与 $F_{\rm phys}$ 的互素有向 Gram 只差 $O((L/B)e^{-c_2V_M})$。结合 (9b) 得 (9c)，再用 (5) 及高 gcd 支付得到最后的补偿主项。$\square$

## 算术边界

式 (5) 是秩一主项及次指数误差，能定位正核领圈中的真实负交叉：在奇臂，素数与平方自由背景的主系数 $-16$ 正好抵消素数同号块的 $+16$，平方自由背景自身还有 $+16$，四项合计为零；偶臂同理。式 (9c) 进一步表明，若按**物理互素**与非互素拆开约化后的完整 $w$ 三通道，前者有 $-8(1-\Theta_o)$、后者有 $+8(1-\Theta_o)$ 的同阶主项；仅支付或保留互素配对都无法替代完整 Gram。note 889 的 $c\mapsto w$ 误差界针对不限 gcd 的硬窗口，本节不宣称它逐 gcd 分块仍成立。这个补偿无需依靠观察核变号，仅继续细分 note 890 的 $F$–$\mu$ 符号子块也不会处理它。对任意固定 $L=M^{3/5+\delta}$，上述次指数误差仍是 $M^{-1/5+\delta-o(1)}$ 量级，达不到 note 849 式 (15) 要求的 $M^{-1/5+\varepsilon}$（$\varepsilon<\delta$）。五通道的固定幂联合协方差、全尺度局部 Weil 正性与 RH 均未由此推出。
