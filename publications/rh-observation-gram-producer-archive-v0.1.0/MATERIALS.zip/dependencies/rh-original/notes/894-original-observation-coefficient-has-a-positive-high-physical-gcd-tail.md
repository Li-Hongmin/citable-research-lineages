> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 原始观察系数的高物理 gcd 正尾

日期：2026-10-03。**证明草案；式 (5)–(6) 的承重链已独立只读复核，异源复核未完成。**沿用 [note 849](849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的原始两端点系数与观察核、[note 851](851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 式 (4) 的全区间 Möbius 短和，以及 [note 891](891-squarefree-parity-arms-cancel-prime-density-on-positive-collar.md) 的正核位移窗口。与 [note 892](892-exact-physical-gcd-strata-of-squarefree-two-arm-gram.md) 不同，本 note 直接处理原始系数 $c(m)$，不逐 gcd 使用 $c\mapsto w$ 的平方自由替换。

## 定理

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$、$B=M/H$、$V_M=(\log M/\log\log M)^{1/3}$。固定 note 891 的 $\psi\in C_c^3((1,2);\mathbb C)$、$f(v)=\psi(v)/v$、$I_\psi=\int_1^2|f(v)|^2\,dv$、合格非负偶观察权 $\eta_M$ 与
\[
K_{H,M}(k)=\sum_{h\in\mathbb Z}\eta_M(h/H)e(-hk/M),
\qquad J_M(L)=\int_{L/B}^{2L/B}\widehat\eta_M(t)\,dt.
\tag{1}
\]
取 note 891 式 (1) 的整数 $L$，即 $K_\alpha\le L\le B/64$。对 $M<m<2M$，定义 note 849 的**原始**系数
\[
c(m)=2\mathbf1_{2\mid m}\bigl(\Lambda(m/2)-1\bigr)
-4\bigl(\Lambda(m)-1+(\log2)\mu(m)\bigr),
\qquad a_m^{(c)}=\frac{c(m)}M f(m/M).
\tag{2}
\]
令 $T_{cc}^{[g]}(L)$ 为 $L<n-m\le2L$ 且物理 $\gcd(m,n)=g$ 的有向 $a^{(c)}$–$a^{(c)}$ Gram。置
\[
\mathcal D(G)=\frac{32}{3\zeta(2)}
\sum_{\substack{g>G\\g\ {m odd}}}\frac1{g^2}
+\frac4{\zeta(2)}
\sum_{\substack{g>G\\g\ {m even}}}\frac1{g^2}.
\tag{3}
\]
固定 $3/5\le\lambda<4/5$，假设另有 $L\ge M^\lambda$。则对每个固定
\[
0<\beta<\frac{12\lambda-7}{5}
\tag{4}
\]
存在 $c_{\lambda,\beta}>0$，使全部充分大的 $M$、全部允许的 $H,L$ 及 $2\le G\le M^\beta$ 一致满足
\[
\boxed{\quad
\sum_{g>G}T_{cc}^{[g]}(L)
=\mathcal D(G)I_\psi J_M(L)
+O_{\psi,\eta,\lambda,\beta}\!\left(
\frac{L/B}{G}e^{-c_{\lambda,\beta}V_M}\right).
\quad}
\tag{5}
\]
并且对任意 $G\ge2$，不要求 (4)，逐配对的绝对尾已有一致界
\[
\sum_{\substack{L<n-m\le2L\\(m,n)>G}}
|a_m^{(c)}a_n^{(c)}K_{H,M}(m-n)|
\ll_{\psi,\eta}\frac{L/B}{G}.
\tag{5a}
\]
这一绝对计数还可直接用于 note 888 的整个硬窗口。固定 $C>0$，令 $U=C B\log(2M)$、$G_{\rm phys}=\lceil M\log^2(2M)/H^4\rceil$。则
\[
\sum_{\substack{0<|m-n|\le U\\(m,n)>G_{\rm phys}}}
|a_m^{(c)}a_n^{(c)}K_{H,M}(m-n)|
\ll_{\psi,\eta,C}\frac{H^4}{M\log(2M)}.
\tag{5b}
\]
特别地，$\mathcal D(G)=22/[3\zeta(2)G]+O(G^{-2})$；若 $I_\psi>0$，式 (5) 左侧的实部与绝对尾 $\sum_{g>G}|T_{cc}^{[g]}(L)|$ 均为 $\asymp_{\psi,\eta,\lambda,\beta}(L/B)/G$。对任意固定 $0<\beta_0\le\beta$，在 $M^{\beta_0}\le G\le M^\beta$ 中可把 (5) 的主项改写为
\[
\sum_{g>G}T_{cc}^{[g]}(L)
=\frac{22}{3\zeta(2)G}I_\psi J_M(L)
+O_{\psi,\eta,\lambda,\beta_0,\beta}\!\left(
\frac{L/B}{G}e^{-c'_{\lambda,\beta}V_M}\right).
\tag{6}
\]

在 $H=Y^{1/5}$、$L=\lfloor M^{3/5+\delta}\rfloor$、$0<\delta<1/5$、$G=\lfloor M^\delta\rfloor$ 时，取 $\lambda=3/5+\delta/2$ 并选 $\delta<\beta<(12\lambda-7)/5$，式 (4) 允许该 $G$，且 (6) 的真实正主项为 $\asymp H^4/M$。原始观察 Gram 的负向位移是本有向和的复共轭，故对应的双向高 gcd 部分有正实主项 $2\mathcal D(G)I_\psi J_M(L)$。此结论只覆盖一个正核位移窗口，不证明 note 849 式 (15) 的完整算术界。

## 证明

把 (2) 精确写成
\[
c(m)=b(m)-4(\log2)\mu(m)+r(m),
\quad b(m)=4-2\mathbf1_{2\mid m},
\quad r(m)=2\mathbf1_{2\mid m}\Lambda(m/2)-4\Lambda(m).
\tag{7}
\]
在 $g>2$、$L<n-m\le2L=o(M)$ 的配对上，若一端为素数 $p$ 或二倍奇素数 $2p$，则另一端不可能与它有大于 $2$ 的共同因子：任何不同的共同素数倍数相距至少 $p\gg M$。所以 $r$ 在这些配对上只可能来自 $p^k$ 或 $2p^k$，$k\ge2$，以及它们中有限个 $2$ 的幂。记这一稀疏集合为 $E_M$；有 $\#E_M\ll\sqrt M\log(2M)$，其元素的除数个数 $\tau(m)\ll\log(2M)$，而 $|c(m)|+|b(m)-4(\log2)\mu(m)|\ll\log(2M)$。

固定 $m\in E_M$。若 $g=(m,n)>G$ 且 $L<|n-m|\le2L$，则 $g\mid m$、$g\le2L$；对每个这样的 $g$，可选 $n$ 至多 $O(L/g+1)=O(L/g)$ 个。因此，对所有涉及 $E_M$ 的配对取绝对值，并允许按 $g\mid m$ 重复计数，得到
\[
\sum_{g>G}\left|
T_{cc}^{[g]}(L)-T_{bb-\mu}^{[g]}(L)
\right|
\ll_{\psi,\eta}
\frac{L/B}{G}M^{-1/2}\log^C(2M),
\tag{8}
\]
其中 $T_{bb-\mu}^{[g]}$ 表示把两端系数都改为 $b-4(\log2)\mu$ 的同一有向 Gram。式 (8) 对 $G\ge2$ 一致；每个素数幂端点至多贡献 $O(L\tau(m)/G)$ 个待计配对。

现在计算 $b$–$b$ 主项。写 $m=gu$、$n=gv$，则精确 gcd 条件是 $(u,v)=1$。任意 $v$ 的前缀区间 $I$ 上，初等互素计数给
\[
\sum_{\substack{v\in I\\(u,v)=1}}b(gv)
=r_g(u)|I|+O(\tau(2u)),
\tag{9}
\]
其中
\[
r_g(u)=
\begin{cases}
2\varphi(u)/u,&2\mid g,\\
4\varphi(u)/u,&2\nmid g,\ 2\mid u,\\
3\varphi(u)/u,&2\nmid gu.
\end{cases}
\tag{10}
\]
当 $g$ 为奇数且 $u$ 为偶数时，互素 $v$ 必为奇数；当 $g,u$ 均奇时，互素 $v$ 中偶数的密度为 $\varphi(u)/(2u)$。这直接给 (10)。

置 $P_o=\prod_{p\ge3}(1-p^{-2})=4/[3\zeta(2)]$。由 $\varphi(u)/u=\sum_{d\mid u}\mu(d)/d$ 逐项取整，均匀于 $x\ge2$ 有
\[
\sum_{\substack{u\le x\\u\ {m odd}}}\frac{\varphi(u)}u
=\frac{P_o}{2}x+O(\log(2x)),
\quad
\sum_{\substack{u\le x\\u\ {m even}}}\frac{\varphi(u)}u
=\frac{P_o}{4}x+O(\log(2x)),
\quad
\sum_{u\le x}\frac{\varphi(u)}u
=\frac{x}{\zeta(2)}+O(\log(2x)).
\tag{11}
\]
所以 $b(gu)r_g(u)$ 的每整数平均密度，$g$ 奇时为
$12(P_o/2)+8(P_o/4)=8P_o=32/[3\zeta(2)]$，$g$ 偶时为 $4/\zeta(2)$。以固定 BV 权 $|f(gu/M)|^2$ 分部求和，(11) 给
\[
\sum_{M<gu<2M} b(gu)r_g(u)|f(gu/M)|^2
=d_g\frac Mg I_\psi+O_\psi(\log(2M)),
\qquad
d_g=
\begin{cases}
32/[3\zeta(2)],&g\text{ 奇},\\
4/\zeta(2),&g\text{ 偶}.
\end{cases}
\tag{12}
\]

在内端对 (9) 作离散分部求和。因为 $\|K_{H,M}\|_\infty\ll H$、$\|K'_{H,M}\|_\infty\ll H^2/M$，且物理位移区间长度为 $L\le B/64$，核与固定 $f$ 的总变差为 $O_\psi(H)$，与 $g$ 无关。把 $f(n/M)$ 冻结到 $f(m/M)$，再由 note 891 式 (15)–(16) 的 Poisson 公式将核积分换为 $MJ_M(L)$。把所得式乘外端 $b(gu)f(gu/M)/M^2$ 求和，并代入 (12)，可得每个 $g$ 的主项 $d_gI_\psi J_M(L)/g^2$。对 $G<g\le T$ 求和后的四类误差分别至多
\[
O_{\psi,\eta,A}\!\left(
\frac{L/B}{G}
\left[
\frac{G\log^2(2M)}L
+\frac{G\log^2(2M)}M
+\frac LM+H^{-A}
\right]\right).
\tag{13}
\]
其中前两项来自 (9) 的 $\tau(2u)$ 误差和 (12) 的外层取整误差，后两项来自冻结 $f$ 与 Poisson 别名。取固定 $A>2$。

对任何平方自由 $g$，含 Möbius 端点的精确 gcd 子和仍是 note 892 式 (11) 的互素 Möbius 短和；对非平方自由 $g$，这种子和为零。设 $X=M/g$。将 note 891 式 (25) 的卷积在除数 $d\le X^{1/8}$ 处分开，note 851 式 (4) 对任意固定 $\nu>7/12$ 给内端每个前缀相对于 $L/g$ 的误差上界
\[
e^{-cV_M}(\log M)^C
+M^{\nu-\lambda+o(1)}g^{1-\nu}
+M^{1/2-\lambda+o(1)}g^{1/2}
+(M/g)^{-1/32}M^{o(1)}.
\tag{14}
\]
若选择 $\beta<\tau<(\lambda-\nu)/(1-\nu)$、$\nu>7/12$ 足够接近 $7/12$，并置 $T=\lfloor M^\tau\rfloor$，则 (14) 在 $g\le T$ 一致为 $O(e^{-c'V_M})$：第一项的对数幂可吸收，后三项都有固定幂节省。对 $g>2$，$b$ 与 Möbius 系数均有绝对常数界；反向位移也用同一短和。核分部求和及逐层配对数 $O(ML/g^2)$ 给
\[
\sum_{G<g\le T}
\left|T_{bb-\mu}^{[g]}(L)-T_{bb}^{[g]}(L)\right|
\ll_{\psi,\eta,\lambda,\beta}
\frac{L/B}{G}e^{-c'V_M}.
\tag{15}
\]

最后 $b-4(\log2)\mu$ 有界，故对 $g>T$ 的真实有向 Gram 可用逐层 $O(ML/g^2)$ 配对数绝对支付为 $O((L/B)/T)$；(12) 的形式主项尾同样是 $O((L/B)/T)$。由 (4) 可选上述 $\nu,\tau$，且 $\tau<2\lambda-1<\lambda$。因此 (8)、(13)–(15) 及 $G/T\ll M^{\beta-\tau}$ 中所有非次指数误差相对于 $(L/B)/G$ 都有固定幂节省，可以吸入 (5) 的误差。由 (11) 中的奇偶整数密度，对 $G\to\infty$ 分别有
$\sum_{g>G,\,g\text{ 奇}}g^{-2}=1/(2G)+O(G^{-2})$、$\sum_{g>G,\,g\text{ 偶}}g^{-2}=1/(2G)+O(G^{-2})$；它们代入 (3) 得 $22/[3\zeta(2)G]$。正性与双向结论由 $J_M(L)\asymp L/B>0$、$I_\psi>0$ 和复共轭对称性给出。$\square$

式 (5a) 的非例外部分由 $g>2$ 时 $b-4(\log2)\mu$ 有界及逐层配对数 $O(ML/g^2)$ 给出；涉及素数幂的部分按 (8) 的同一绝对计数支付。相同论证把位移长度 $L$ 换成 $U=o(M)$，只需 $G_{\rm phys}>2$，给整个硬窗口的上界 $O(HU/(MG_{\rm phys}))=O(H^4/[M\log(2M)])$，即 (5b)。式 (5) 的正实主项与三角不等式给 $\sum_{g>G}|T_{cc}^{[g]}(L)|$ 的下界。

## 边界

式 (5) 是**原始系数 $c$** 的真实高 gcd 渐近式；它直接处理了素数幂与非平方自由背景。对自然截断 $G\asymp L/H^3$，正尾仍处于 note 849 式 (15) 的目标量级；更低的固定幂截断会留下更大的正尾。这个结论不估计低 gcd 层的固定幂 signed 抵消，也不覆盖正核窗口以外的全部中距离位移；全尺度局部 Weil 正性和 RH 仍未判定。
