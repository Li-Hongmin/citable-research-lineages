> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 平方自由共同因子平均的误差与留下的加权 Möbius 主和

日期：2026-10-03。依赖 [note 849](849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的频带核和 [note 850](850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的完整奇数源两臂 Gram。这里定量检验“先对共同因子作平方自由计数”能支付多少误差。得到的是一个带误差的算术重排，不是 note 849 式 (15) 的上界，也不证明 RH。

## 命题

沿用 note 850 的 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$、$D$、$R$、$W$、$\phi$、$J_H$ 与
\[
G_\natural=\left\lceil\frac{M\log^4(2M)}{H^4}\right\rceil.
\]
这里取 note 849 的 $\eta\in C_c^\infty(\mathbb R)$。令整数 $1\le G\le G_\natural$，$I_G=[G,\min(2G,G_\natural+1))$，且 $a,b$ 为互素正奇数。对 $k,\ell$ 满足 $W(k)W(\ell)\ne0$，置 $r=ka-\ell b$，并定义 $I_G$ 上的分片光滑权
\[
F_{a,b;k,\ell}(x)=
\mathbf1_{D<ax,bx<2M/3}\,
\phi(kax/M)\overline{\phi(\ell bx/M)}J_H(rx).
\tag{1}
\]
由于 $\phi$ 紧支撑，乘子事实上满足 $k,\ell<64H$。令
\[
\rho_{\rm odd}(q)=\frac4{\pi^2}\prod_{p\mid q}\frac p{p+1}
\qquad(q\text{ 为奇数}),
\tag{2}
\]
并以 $\mathcal B_G$ 表示 note 850 的不同源 signed Gram 中 $g=(u,v)\in I_G$ 的部分；等价地，
\[
\mathcal B_G=\frac1{M^2}\sum_{k,\ell}W(k)\overline{W(\ell)}
\sum_{\substack{a,b\ge1\ \mathrm{odd}\\(a,b)=1}}
\mu(a)\mu(b)
\sum_{\substack{g\in I_G\ g\ \mathrm{odd}\\(g,ab)=1}}
\mu^2(g)F_{a,b;k,\ell}(g).
\tag{3}
\]
式 (3) 中 $a=b=1$ 的对角由物理窗口排除。把最内层的 $g$ 和改为 $\rho_{\rm odd}(ab)\int_{I_G}F_{a,b;k,\ell}(x)\,dx$，得到 $\mathcal B_G^{\rm av}$。那么对任意 $\varepsilon>0$，一致于上述参数，
\[
\boxed{\quad
|\mathcal B_G-\mathcal B_G^{\rm av}|
\ll_{\psi,\eta,\varepsilon}
\frac{M^\varepsilon\log^4(2H)}{G^{3/2}}.
\quad}\tag{4}
\]
实际上，把外层每个 $(a,b,k,\ell)$ 的差先取绝对值再求和，仍满足 (4)。

特别在 $H=Y^{1/5}$ 时，任取固定 $0<\varepsilon<1/30$，从 $G_0=\lceil M^{2/15+\varepsilon}\rceil$ 到 $G_\natural$ 的各层可同时作此替换，且总误差为
\[
O_{\psi,\eta,\varepsilon}(M^{-1/5-\varepsilon/2})
=o(H^4/M).
\tag{5}
\]
因此这一范围的**平方自由计数误差**已低于目标；替换后的主和仍是完整待估的 signed 和的一部分。

## 证明

先对奇数 $q$ 计数。平方自由恒等式 $\mu^2(n)=\sum_{d^2\mid n}\mu(d)$ 与互素整数计数
\[
\#\{m\le z:(m,2q)=1\}
=\frac{\varphi(2q)}{2q}z+O(\tau(2q))
\]
给出，对 $x\ge1$，
\[
\sum_{\substack{n\le x\\(n,2q)=1}}\mu^2(n)
=\rho_{\rm odd}(q)x+O\bigl(\tau(2q)\sqrt x\bigr).
\tag{6}
\]
确实，$d\le\sqrt x$ 的取整误差至多 $\tau(2q)\sqrt x$；把主项中的 $d$ 和延到无穷的尾误差至多 $O(\sqrt x)$。Euler 乘积是
\[
\frac{\varphi(2q)}{2q}
\sum_{(d,2q)=1}\frac{\mu(d)}{d^2}
=\frac1{\zeta(2)}\prod_{p\mid2q}\frac p{p+1}
=\frac4{\pi^2}\prod_{p\mid q}\frac p{p+1},
\]
证明 (2)。由 (6) 及分部求和，任意支撑在 $I_G$ 的分片 $C^1$ 权 $F$ 满足
\[
\left|\sum_{\substack{g\in I_G\\(g,2q)=1}}
\mu^2(g)F(g)-\rho_{\rm odd}(q)\int_{I_G}F(x)\,dx\right|
\ll \tau(2q)\sqrt G\bigl(\|F\|_\infty+\operatorname{Var}_{I_G}F\bigr).
\tag{7}
\]

固定 $a,b,k,\ell$，写 $T=HG|r|/M$。在 (1) 的非零支撑上，$|rx|/M\le1-2\sigma_\psi$，其中 $\sigma_\psi>0$ 只依赖 $\operatorname{supp}\psi$。Poisson 展开
\[
J_H(rx)=H\sum_{j\in\mathbb Z}
\widehat\eta\!\left(H\left(\frac{rx}M+j\right)\right)
\]
以及 $\widehat\eta$ 和其导数的任意阶衰减表明，对任意固定 $A>2$，
\[
\|F_{a,b;k,\ell}\|_\infty+
\operatorname{Var}_{I_G}F_{a,b;k,\ell}
\ll_{\psi,\eta,A} H(1+T)^{-A}.
\tag{8}
\]
这里 $\phi(kax/M)$、$\phi(\ell bx/M)$ 在 $I_G$ 的变差均为 $O_\psi(1)$；(1) 的硬端点只添加有界个值跳跃。对 $j\ne0$ 的 Poisson 别名，物理支撑使 $|rx/M+j|\ge2\sigma_\psi$，故选更高的固定衰减阶数后也满足 (8)。

若 (1) 在 $I_G$ 上非零，则 $a\ll M/(kG)$。对固定 $a$ 与 $T\le U$，条件 $|ka-\ell b|\le UM/(HG)$ 把整数 $b$ 限在长 $O(UM/(HG\ell))$ 的区间。因为 $G\le G_\natural$ 且 $k,\ell<64H$，
\[
\frac M{kG}\gg\frac{H^3}{\log^4(2M)}\to\infty,
\qquad
\frac M{HG\ell}\gg\frac{H^2}{\log^4(2M)}\to\infty.
\]
故对任意 $U\ge1$，放宽奇性、互素性和 $b$ 的物理窗口后，
\[
\#\{(a,b):F_{a,b;k,\ell}\not\equiv0, T\le U\}
\ll_{\psi}\frac{UM^2}{Hk\ell G^2}.
\tag{9}
\]
所有活动 $a,b\ll M$，因而 $\tau(2ab)\ll_\varepsilon M^\varepsilon$。把 $T\le1$ 与 $2^j<T\le2^{j+1}$ 分壳，将 (7)–(9) 相乘并取 $A>3$，得到固定 $(k,\ell)$ 的全部绝对误差
\[
\ll_{\psi,\eta,\varepsilon}
\frac{H\sqrt G}{M^2}M^\varepsilon
\sum_{j\ge0}(1+2^j)^{-A}
\frac{2^jM^2}{Hk\ell G^2}
\ll\frac{M^\varepsilon}{k\ell G^{3/2}}.
\tag{10}
\]
最后 $\sum_{k<64H}|W(k)|/k\ll\log^2(2H)$，证明 (4)。按 $G_0,2G_0,4G_0,\ldots$ 求和，几何级数给总误差 $O(M^{\varepsilon'}\log^4(2H)G_0^{-3/2})$。在 (5) 中先取 $\varepsilon'<\varepsilon/4$，再吸收对数，即得所述余量。$\square$

## 小共同因子处的绝对误差确实过大

式 (4) 在 $G=1$ 的损失不只是证明中的粗估计。取 $H=Y^{1/5}$、note 849 的任意非负偶 $\eta$（在 $1\le|t|\le2$ 上至少为 $1$），并明确定义逐 $(a,b,k,\ell)$ 的绝对误差和
\[
\mathfrak E_1^{\rm abs}=\frac1{M^2}\sum_{k,\ell}|W(k)W(\ell)|
\sum_{\substack{a,b\ge1\ \mathrm{odd}\\(a,b)=1}}
|\mu(a)\mu(b)|
\left|F_{a,b;k,\ell}(1)-\rho_{\rm odd}(ab)
\int_1^2F_{a,b;k,\ell}(x)\,dx\right|.
\]
存在固定非负 $\psi\in C_c^\infty((1,2))$，使对每个固定 $\varepsilon>0$，
\[
\boxed{\quad \mathfrak E_1^{\rm abs}
\gg_{\psi,\eta,\varepsilon}M^{-\varepsilon}\log^2 M.
\quad}\tag{11}
\]
特别取 $\varepsilon<1/5$，它比目标 $H^4/M\asymp M^{-1/5}$ 大固定幂。这个断言只涉及**先取绝对值的平方自由计数误差**，不下界实际 signed 差 $\mathcal B_1-\mathcal B_1^{\rm av}$。

证明时选 $t_0\in(1,2)$ 和充分小的固定 $\delta>0$，让 $\psi$ 在 $[t_0,t_0+\delta/4]$ 等于 $1$，支撑于 $(t_0-\delta,t_0+\delta)$，且 $0\le\psi\le1$。把 $k,\ell$ 限为 $[H,2H]$ 中的奇整数；于是各有 $\gg H$ 个选择，且 $|W(k)W(\ell)|\gg\log^2H$。对每个 $k$，把 $a$ 限为奇平方自由整数，满足
\[
t_0+\delta/16\le ka/M\le t_0+\delta/8.
\tag{12}
\]
式 (6) 在这个长度 $\asymp M/H$ 的区间给 $\gg M/H$ 个 $a$。固定这些 $a,k,\ell$ 后，把 $b$ 限为奇平方自由、$(a,b)=1$ 且
\[
|ka-\ell b|\le M/(100H).
\tag{13}
\]
该 $b$ 区间长 $\asymp M/(H\ell)\asymp M/H^2$，中心 $\asymp M/H$；对充分大 $M$，其 $\ell b/M$ 仍位于 $\psi=1$ 的平台内。由 (6) 的区间形式，这样的 $b$ 至少有
\[
\rho_{\rm odd}(a)\frac{cM}{H\ell}
-O\bigl(\tau(2a)\sqrt{M/H}\bigr)
\gg_\varepsilon \frac{M^{1-\varepsilon}}{H\ell}.
\tag{14}
\]
这里对任意固定小 $\varepsilon>0$，有限个小素数与 $p/(p+1)\ge p^{-\varepsilon}$（充分大 $p$）给 $\rho_{\rm odd}(a)\gg_\varepsilon M^{-\varepsilon}$；再用 $\tau(2a)\ll_\varepsilon M^\varepsilon$。在 $H\asymp M^{1/5}$ 下，(14) 的主项为 $M^{3/5-\varepsilon}$，误差为 $O(M^{2/5+\varepsilon})$，所以任取 $\varepsilon<1/10$ 即足够。

对这些四元组，$I_1=[1,2)$ 中唯一奇整数是 $g=1$，且 $a,b>D$、$a,b<2M/3$。由 (13) 及 $\eta$ 的支撑，$J_H(ka-\ell b)\ge c_\eta H$，因为每个活动 $h$ 都满足 $|2\pi h(ka-\ell b)/M|\le8\pi/100<\pi/2$。平台上 $\phi>0$，故 $F_{a,b;k,\ell}(1)\ge c_{\psi,\eta}H$。另一方面，若 $F(x)\ne0$ 且 $x\in[1,2)$，(12) 与 $\operatorname{supp}\psi\subset(t_0-\delta,t_0+\delta)$ 强迫 $1\le x\le1+C\delta$；又 $|F(x)|\ll_{\psi,\eta}H$。先选足够小的固定 $\delta$，可使
\[
\left|F(1)-\rho_{\rm odd}(ab)\int_1^2F(x)\,dx\right|\ge cH.
\tag{15}
\]
最后 (12)–(14) 对每对 $k,\ell$ 给 $\gg_\varepsilon M^{2-\varepsilon}/H^3$ 个平方自由互素 $(a,b)$。把它们、$\gg H^2$ 个乘子对、每项 $\gg H\log^2H/M^2$ 的绝对误差相乘，得到 (11)。$\square$

## 留下的算术因子

由于 $(a,b)=1$，(2) 分离成 $\rho_{\rm odd}(ab)=(4/\pi^2)\omega(a)\omega(b)$，其中 $\omega(n)=\prod_{p\mid n}p/(p+1)$。因此 $\mathcal B_G^{\rm av}$ 仍含 $\lambda(a)\lambda(b)\mathbf1_{(a,b)=1}$，$\lambda(n)=\mu(n)\omega(n)$，以及 (1) 中的两乘子和物理位移。这个权的单变量 Dirichlet 级数为
\[
\sum_{n\ge1}\frac{\lambda(n)}{n^s}
=\prod_p\left(1-\frac p{p+1}p^{-s}\right)
=\frac{E(s)}{\zeta(s)},
\qquad
E(s)=\prod_p\left(1+\frac1{p+1}
\frac{p^{-s}}{1-p^{-s}}\right).
\tag{16}
\]
$E$ 在 $\Re s>0$ 绝对收敛且无零；其 Dirichlet 系数 $e(n)$ 满足 $e(p^j)=1/(p+1)$（$j\ge1$）。实际主和只取奇数 $a,b$；其单变量级数是
\[
\sum_{n\ \mathrm{odd}}\frac{\lambda(n)}{n^s}
=\frac{E_{\rm odd}(s)}{\zeta(s)},
\qquad
E_{\rm odd}(s)=\frac{E(s)}{1-\frac23 2^{-s}},
\]
而 $E_{\rm odd}$ 在同一半平面也绝对收敛且无零。因此
\[
\sum_{\substack{n\le x\\n\ \mathrm{odd}}}\lambda(n)=O_\varepsilon(x^{1/2+\varepsilon})
\text{ 对所有 }\varepsilon>0
\quad\Longleftrightarrow\quad \mathrm{RH}.
\tag{17}
\]
正向由 $E_{\rm odd}$ 的非零解析因子与 Dirichlet 级数收敛推出 $1/\zeta$ 在 $\Re s>1/2$ 解析；反向由 RH 下的 Möbius 平方根界和 $E_{\rm odd}$ 的绝对收敛 Dirichlet 级数卷积推出。(17) 只说明新主和仍保留 RH 强度的单变量因子，不声称它与 note 849 的完整频带门等价。

式 (11) 证明小 $g$ 的逐项绝对计数误差实际超过目标；(16)–(17) 则表明大 $g$ 的密度主项依然包含 Möbius 零点障碍。故单独平均 $g$ 不支付完整门。大 $g$ 层的替换可用作重排，但不能把其带符号主和删去。
