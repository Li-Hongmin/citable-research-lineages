> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 留存观察环带从内缘开始的多尺度 Möbius 符号抵消

日期：2026-10-03。依赖 [note 889](889-centered-squarefree-profile-removes-nonsquarefree-observation-core.md) 的平方自由奇臂与物理 gcd 归约、[note 888](888-scale-adaptive-observation-weight-gives-a-single-logarithm-collar.md) 的留存环带和可变观察权、[note 885](885-squarefree-gcd-averaging-leaves-weighted-mobius-main.md) 式 (6) 的固定模数平方自由计数，以及 [note 851](851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 式 (4) 中可取任意固定 $\nu>7/12$ 的全区间 Möbius 短和。本文把 note 889 式 (17a) 的单个宏观位移窗口推进到留存环带的内缘；在每个固定幂内点，两种符号的单独质量均超过算术门的允许尺度，但完整联合 signed covariance 仍未估计。

## 定理

沿整数 $Y\to\infty$，令
\[
M=2Y,\qquad H=Y^{1/5},\qquad B=M/H,\qquad
V_M=(\log M/\log\log M)^{1/3}.
\]
固定非负、非零的实函数 $\psi\in C_c^3((1,2))$，记 $f(v)=\psi(v)/v$，并取正长度闭区间 $J_1\Subset(1,2)$，使 $f$ 在 $J_1$ 上严格为正；连续性使 $f$ 在其一个固定邻域内仍为正。观察权可以是 note 849 的任意固定合格非负偶光滑权 $\eta$，或 note 888 式 (5) 取 $A=2$、$N=\lceil\lambda_2\log(2M)\rceil$ 的可变权 $\eta_M$；相应地令 $\eta_*=\eta$ 或 $\eta_*=\eta_0$。取 note 888 的固定小 $\alpha>0$ 并置
\[
K_\alpha=\lfloor H^3e^{\alpha V_Y}\rfloor,\qquad
I_\psi(J_1)=\int_{J_1}f(v)^2\,dv>0.
\]
对每个满足 $K_\alpha\le L\le B/64$ 的整数 $L$、$\sigma\in\{+1,-1\}$，使用 note 889 式 (12) 的奇臂系数，定义
\[
S_\sigma(L)=
\sum_{\substack{p/M\in J_1,\ p\text{ 为奇素数}\\
 r\ge1,\ (r,6)=1,\ \mu(3r)=\sigma\\
 L<3r-p\le2L}}
a_p^{F,\mathrm o}\overline{a_{3r}^{\mu,\mathrm o}}\,
K_{H,M}(p-3r).
\tag{1}
\]
存在固定 $c>0$，使下式对上述全部 $L$ 一致成立：
\[
\boxed{\quad
S_\sigma(L)=
\sigma\frac{8\log2}{\pi^2}I_\psi(J_1)
\int_{L/B}^{2L/B}\widehat{\eta_*}(t)\,dt
+O_{\psi,\eta}\!\left(
\frac LB\left(\frac1{\log M}+e^{-cV_M}\right)\right).
\quad}
\tag{2}
\]
这里 $\widehat{\eta_*}(t)=\int\eta_*(u)e(-ut)\,du$。由于 $0<t\le1/32$ 时 $\widehat{\eta_*}(t)\ge c_\eta>0$，从而一致有
\[
\boxed{\quad S_+(L)\asymp_{\psi,\eta}L/B,\qquad
-S_-(L)\asymp_{\psi,\eta}L/B,\qquad
S_+(L)+S_-(L)\ll_{\psi,\eta}(L/B)e^{-cV_M}.\quad}
\tag{3}
\]
所有计入的配对都是奇平方自由合数 $3r$ 与素数 $p$，且物理 $\gcd(p,3r)=1$；其位移完全属于 note 889 式 (5) 留存的环带。特别取 $L=K_\alpha$，每个符号子块的绝对值为
\[
\asymp_{\psi,\eta}\frac{H^4}{M}e^{\alpha V_Y},
\tag{4}
\]
比基准 $H^4/M$ 大 $e^{\alpha V_Y}$ 倍；由于 $e^{\alpha V_Y}=M^{o(1)}$，这一内缘比较本身仍可被 $M^\varepsilon$ 余量吸收。对任意固定 $0<\delta<1/5$，另取 $L=\lfloor M^{3/5+\delta}\rfloor$，则两子块各为 $\asymp M^{-1/5+\delta}$；若 $\varepsilon<\delta$，单独取绝对值不能达到 $H^4M^{-1+\varepsilon}$ 的门。式 (3) 中的负项由真实 Möbius 符号产生；在此窗口内观察核严格为正。

## 证明

先建立比 note 889 式 (19) 更短尺度的一致短和。固定 $\nu=59/100$，故 $7/12<\nu<3/5$。对位置 $\asymp M$、长度 $\ell\le2L$ 的任意整数区间 $I$，用 note 889 式 (18) 的精确卷积
$b(r)=\mu(r)\mathbf1_{(r,6)=1}
=\sum_{q\mid r,\ q=2^a3^d}\mu(r/q)$。
当 $q\le M^{1/4}$，note 851 式 (4) 在 $I/q$ 给
\[
\sum_{r\in I,\ q\mid r}\mu(r/q)
\ll (\ell/q)e^{-c_0V_M}+(M/q)^\nu+1;
\]
若 $\ell/q<1$，同一界由平凡的 $O(1)$ 计数给出。因 $M/q\ge M^{3/4}$，可把 $V_{M/q}$ 的固定比例差吸收到缩小后的 $c_0>0$。对 $q>M^{1/4}$ 使用 $O(\ell/q+1)$。几何级数与活动 $q$ 的 $O(\log^2M)$ 个数给
\[
\left|\sum_{r\in I}b(r)\right|
\ll \ell e^{-c_0V_M}+M^\nu+\ell M^{-1/8}+\log^2M.
\tag{5}
\]
由于 $L\ge K_\alpha\gg M^{3/5}$，式 (5) 对任意长度不超过 $2L$ 的前缀一致简化为 $O(Le^{-c_1V_M})$，其中 $c_1>0$ 固定。

note 885 式 (6) 取 $q=3$ 给
$\sum_{r\le x,(r,6)=1}\mu^2(r)=3x/\pi^2+O(\sqrt x)$。
令
\[
I_p(L)=((p+L)/3,(p+2L)/3],\qquad
W_p(x)=f(3x/M)K_{H,M}(p-3x).
\]
note 888 的核上界及导数上界给
$\|W_p\|_\infty+\operatorname{Var}_{I_p(L)}W_p\ll_\psi H$，
一致于 $p/M\in J_1$ 和全部规定的 $L$。把平方自由计数与式 (5) 对每个前缀作离散分部求和，得到
\[
\sum_{\substack{r\in I_p(L)\\(r,6)=1,\ \mu(3r)=\sigma}}W_p(r)
=\frac3{2\pi^2}\int_{I_p(L)}W_p(x)\,dx
+O_\psi\!\left(H\sqrt M+HL e^{-c_1V_M}\right).
\tag{6}
\]
这里用了 $\mu(3r)=-b(r)$。由于 $\sqrt M/L\ll M^{-1/10}$，缩小 $c_1$ 后可把式 (6) 的误差写成 $O_\psi(HL e^{-c_1V_M})$。

在 $L/B\le t\le2L/B\le1/32$ 上，Poisson 公式及非零别名的统一衰减给
\[
\frac{K_{H,M}(-Bt)}H
=\widehat{\eta_*}(t)+O_\eta(1/\log M).
\tag{7}
\]
固定权的误差实际为任意固定负幂 $O_A(H^{-A})$。对可变权，note 888 式 (5) 给
$\widehat{\eta_M}(t)=\widehat{\eta_0}(t)\widehat g(at/N)^N$；
$g$ 为偶概率密度，$N\asymp\log M$，故在 $0\le t\le1/32$ 上
$\widehat g(at/N)^N=1+O(1/N)$。又因 $2L/M\le1/(32H)$，有
$f((p+Bt)/M)=f(p/M)+O_\psi(1/H)$。在式 (6) 的积分中换元 $t=(3x-p)/B$，便得
\[
\frac3{2\pi^2}\int_{I_p(L)}W_p(x)\,dx
=\frac{HB}{2\pi^2}f(p/M)
\int_{L/B}^{2L/B}\widehat{\eta_*}(t)\,dt
+O_{\psi,\eta}(HL/\log M).
\tag{8}
\]

由 note 889 式 (12)，每对系数相乘等于
$(16\log2/M^2)F(p)\mu(3r)f(p/M)f(3r/M)$，其中
$F(p)=\log p-\tfrac32\zeta(2)$。
note 851 式 (4) 在固定比例长区间的素数定理、去掉总质量 $O(\sqrt M\log M)$ 的高次素数幂、再对固定 BV 权分部求和，连同 Chebyshev 界分别给
\[
\sum_{p/M\in J_1}F(p)f(p/M)^2
=M I_\psi(J_1)+O_\psi(M/\log M),\qquad
\sum_{p/M\in J_1}F(p)\ll M.
\tag{9}
\]
将 (6)、(8)、(9) 代入 (1)，使用 $HB=M$，即得 (2)。直接在 (1) 中先合并 $\sigma=\pm1$，再对 $b(r)W_p(r)$ 应用式 (5) 的前缀界，可避免式 (8)、(9) 的无符号近似误差，得到式 (3) 最后一项。

最后 $\eta_*$ 非负、偶且支撑于 $|u|\le4$。当 $0\le t\le1/32$ 时，
$\cos(2\pi ut)\ge\cos(\pi/4)>0$，所以 $\widehat{\eta_*}(t)\ge c_\eta>0$。
又 $F(p)>0$、$f>0$ 于 $J_1$，且核在当前位移上严格为正，证明式 (3) 的符号及比较。由于 $0<3r-p\le B/32=o(M)<p$，有 $\gcd(p,3r)=1$；$\mu(3r)=\pm1$ 使 $3r$ 平方自由，且充分大时为合数。$L\ge K_\alpha$ 和 $2L\le B/32<U$ 保证位移留在环带，式 (4) 由 $K_\alpha/B=(H^4/M)e^{\alpha V_Y}(1+o(1))$ 得到。$\square$

## 边界

这证明从留存环带的内缘起，每个尺度都已有大小相等、符号相反的真实算术子块；在任何固定幂内点，若企图单独以逐项绝对值支付此子块，就会丢失固定幂目标。式 (3) 的合并界仍只是次指数相对节省：取 $L=M^{3/5+\delta}$ 时，它只给 $O(M^{-1/5+\delta}e^{-cV_M})$，并未达到任意 $\varepsilon<\delta$ 的目标。该界只覆盖指定的素数–$3r$ 子块。完整的 $F$–$\mu$、$F$–$F$、$\mu$–$\mu$ 及跨奇偶臂 signed Gram 尚无 $O_\varepsilon(H^4M^{-1+\varepsilon})$ 界；本文不证明或反驳 RH，也不判定全尺度局部 Weil 正性。
