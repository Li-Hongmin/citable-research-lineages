> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Ramachandra 短和推进真实两端点观察门的四分之一次幂邻域

日期：2026-10-02。依赖 [note 849](849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的式 (1)、(7)、(8)、(10)–(12)，[note 850](850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的完整奇数源两臂核及 [note 847](847-quarter-power-observation-fourier-tail-for-full-k2-residual.md) 的高频尾。外部输入已直接核对 K. Ramachandra, *Some problems of analytic number theory*, *Acta Arith.* **31** (1976), 313–324, DOI 10.4064/aa-31-4-313-324，Main Theorem、Remark 4–5（原版扫描件第 315–316 页）；Matomäki–Teräväinen, *On the Möbius function in all short intervals*, DOI 10.4171/JEMS/1205，§2.1 也记录其 Möbius 特例。承重链于 2026-10-02 经异源只读复核，原文输入、周期 Parseval、两端点误差及协方差对角均核对成立。本定理控制完整余项的一个真实频带，不控制全部频率、全尺度局部 Weil 正性或 RH。

## 命题

固定 $\psi\in C_c^3((1,2))$ 和非负偶函数 $\eta\in C_c^\infty(\mathbb R)$，其中 $\operatorname{supp}\eta\subset\{t:1/2\le|t|\le4\}$ 且 $\eta\ge1$ 于 $1\le|t|\le2$。令 $Y\to\infty$ 沿整数，$M=2Y$、$V_Y=(\log Y/\log\log Y)^{1/3}$，并使用 note 849 的真实两端点系数 $\mathcal A_h(Y)$ 与余项观察系数 $S_h$。存在固定常数 $c>0$，使得一致于 $Y^{1/5}\le H\le Y^{1/4}$，

\[
\sum_{h\in\mathbb Z}\eta(h/H)|\mathcal A_h(Y)|^2
\ll_{\psi,\eta} e^{-2cV_Y}. \tag{1}
\]

特别地，对任意固定 $0<b<c/2$，令 $d=2c-4b>0$。若

\[
Y^{1/4}e^{-bV_Y}\le H\le Y^{1/4}, \tag{2}
\]

则

\[
\sum_h\eta(h/H)|\mathcal A_h(Y)|^2
\ll_{\psi,\eta}\frac{H^4}{Y}e^{-dV_Y},
\qquad
\frac1Y\sum_{H\le|h|<2H}|S_h|^2
\ll_{\psi,\eta}Y^2e^{-dV_Y}. \tag{3}
\]

若 $\mathfrak C_{\rm odd}$ 是 note 850 式 (3) 的完整两臂不同源 Möbius signed covariance，使用同一个 $\eta$，则

\[
|\mathfrak C_{\rm odd}|\ll_{\psi,\eta}e^{-2cV_Y}
\quad(Y^{1/5}\le H\le Y^{1/4}),
\qquad
|\mathfrak C_{\rm odd}|\ll_{\psi,\eta}
\frac{H^4}{M}e^{-dV_Y}\quad\text{在 (2) 内}. \tag{C}
\]

此外，对任意固定 $0<b<c/2$，令 $H_0=\lceil Y^{1/4}e^{-bV_Y}\rceil$，以 $q(h)=\min(h,Y-h)$（$0\le h<Y$）表示观察频率的周期距离，则完整 $k=2$ 余项有低频归约
\[
\sum_{Y<N\le2Y}|\psi(N/Y)R_N|^2
=\frac1Y\sum_{\substack{0\le h<Y\\q(h)<H_0}}|S_h(Y)|^2
+O_{\psi,\eta}(Y^2\log(2Y)). \tag{T}
\]

这里 $c,b,d$ 均为某些固定正数；没有声称其显式数值。式 (2) 比任意固定对数宽度严格更深，但仍未到任一 $H=Y^{1/4-\theta}$，$\theta>0$。

## 外部短和的精确适用

Ramachandra 的 Main Theorem 取零密度指数 $B=12/5$，给 $\varphi=1-1/B+\varepsilon=7/12+\varepsilon$。其式 (10) 与 Remark 4 对固定允许的 Dirichlet 级数 $F$ 及所有 $1\le u\le x$ 一致给

\[
\sum_{x<n\le x+u} a_F(n)
=I_F(x,u)+O_{F,\varepsilon}\!\left(u e^{-g_F(\log x/\log\log x)^{1/3}}+x^{7/12+\varepsilon}\right), \tag{4}
\]

其中 $g_F>0$；Remark 4 只改进 (10) 中的指数衰减项，不删除 $x^\varphi$ 项。取 $F=1/\zeta$ 时 $a_F=\mu$，$F$ 在 $s=1$ 解析，故圆轮廓积分 $I_F=0$。取 $F=-\zeta'/\zeta$ 时 $a_F=\Lambda$，其 $s=1$ 的留数为 $1$，故 $I_F(x,u)=u$。这两个 $F$ 均属于原文式 (8) 的函数类；特别地，后者由 $\zeta^{-1}\zeta'$ 及常数 $-1$ 组成。又有 $\sum_{x<n\le x+u}1=u+O(1)$，故 (4) 同时给 $\mu$ 和 $\Lambda-1$ 的普通短和。

令 $Q=\lfloor Y^{2/3}\rfloor$。对 $x\asymp Y$ 和 $u\in\{Q,Q/2+O(1)\}$，固定取 $\varepsilon=1/24$，则 $x^{7/12+\varepsilon}=O(Y^{5/8})$，而 $u\asymp Y^{2/3}$。由于 $Y^{-1/24}=o(e^{-cV_Y})$，缩小 $c>0$ 后，(4) 给所有起点上一致的

\[
\left|\sum_{x<n\le x+u}\mu(n)\right|
+\left|\sum_{x<n\le x+u}(\Lambda(n)-1)\right|
\ll Qe^{-cV_Y}. \tag{5}
\]

这里 $Q/2+O(1)$ 来自偶数换元及端点取整，仍处于定理的允许长度；有限个端点误差 $O(\log Y)$ 也吸收于右侧。

## 短块向观察频带的传递

令 $M=2Y$，按 note 849 式 (10) 写

\[
c(m)=2\mathbf1_{2\mid m}(\Lambda(m/2)-1)
-4(\Lambda(m)-1+(\log2)\mu(m)),
\qquad
a_m=\frac{c(m)}m\psi(m/M), \tag{6}
\]

并在 $(M,2M)$ 以外置 $a_m=0$。由 (5)，对任何包含于 $(M,2M)$、长度 $Q$ 的整数区间 $J$，偶数项作 $m=2n$ 后落入长度 $Q/2+O(1)$ 的区间，因而

\[
\left|\sum_{m\in J}c(m)\right|\ll Qe^{-cV_Y}. \tag{7}
\]

取 $L=\lfloor Y/(16H)\rfloor\asymp M/H$。将任意长度不超过 $L$ 的区间拆为完整长 $Q$ 块及最多两个短余块；余块以 $|c(m)|\ll\log Y$ 平凡支付。故

\[
\sup_{|J|\le L}\left|\sum_{m\in J}c(m)\right|
\ll Le^{-cV_Y}+Q\log Y. \tag{8}
\]

在 $m\asymp M$ 上，$w(m)=\psi(m/M)/m$ 满足 $\|w\|_\infty\ll_\psi M^{-1}$ 且每个长度不超过 $L$ 的区间上的变差为 $O_\psi(L/M^2)$。离散 Abel 求和由 (8) 给

\[
\sup_{|J|\le L}\left|\sum_{m\in J}a_m\right|
\ll_\psi \frac{L}{M}e^{-cV_Y}+\frac{Q\log Y}{M}. \tag{9}
\]

将 $a_m$ 周期化为模 $M$ 的序列 $b_x=a_{x+M}$。因 $\psi$ 的支撑与拼接端点隔开固定比例，任何长 $L$ 的周期窗口至多拆为两个适用 (9) 的区间。令 $D_L(h)=\sum_{j=0}^{L-1}e(-hj/M)$；在 $\eta(h/H)\ne0$ 时，$|h|L/M\le1/8$，所以 $|D_L(h)|\gg L$。这些 $h$ 在模 $M$ 下互异；note 849 式 (11) 又给 $\widehat b(h)=\mathcal A_h(Y)$。于是周期 Parseval 给

\[
\begin{aligned}
\sum_h\eta(h/H)|\mathcal A_h(Y)|^2
&\ll_\eta\frac{M}{L^2}\sum_{x\bmod M}
  \left|\sum_{j=0}^{L-1}b_{x-j}\right|^2\\
&\ll_{\psi,\eta}
\left(e^{-cV_Y}+\frac{Q\log Y}{L}\right)^2. \tag{10}
\end{aligned}
\]

在 $H\le Y^{1/4}$ 时 $Q/L\ll Y^{-1/12}$，其多项式衰减可吸收于 $e^{-cV_Y}$；这证明 (1)。若 (2) 成立，$H^4/Y\ge e^{-4bV_Y}$，故 (1) 推出 (3) 的第一式。

最后 note 849 式 (1)、(8) 给 $S_h=Y^2\mathcal A_h/(2\pi h^2)+E_h$，其式 (7) 给

\[
\frac1Y\sum_{H\le|h|<2H}|E_h|^2
\ll_\psi \frac{Y^3}{H^5}+\frac{H^5}{Y}. \tag{11}
\]

由第一式，主项的归一化能量至多 $O(Y^2e^{-dV_Y})$；在 (2) 内，(11) 至多
$O(Y^{7/4}e^{5bV_Y}+Y^{1/4})=o(Y^2e^{-dV_Y})$。平方三角不等式证明 (3) 的第二式。$\square$

为证 (C)，取 $D=\lfloor M/(32H)\rfloor$，把 note 850 的完整两臂源核自然延拓到全部奇数 $u\ge1$：
\[
\mathcal K_h(u)=\frac1M\sum_{\substack{k\ge3\\M<ku<2M}}W(k)\phi(ku/M)e(-hku/M),
\quad \phi(x)=\psi(x)/x,
\]
其中对奇数 $t\ge3$，$W(t)=-4\log(t/2)$、$W(2t)=2\log(t/4)$，其余 $k$ 处 $W(k)=0$。note 850 式 (0) 的精确 Möbius 反演将 $\mathcal A_h$ 写成全部奇数源之和、光滑背景及至多一个二的幂项。背景在当前非零频带为 $O_\psi(H^{-3})$，二的幂项为 $O_\psi(M^{-1})$。对 $u\le D$，奇臂与偶臂的 cofactor 采样尺度分别至少为 $32H$ 与 $16H$，所以其奇格 Poisson 别名与 $H/2\le|h|\le4H$ 保持 $\gg H$ 的距离；三次分部积分逐源给 $|\mathcal K_h(u)|\ll_\psi\log M/(uH^3)$。因此
\[
\mathcal A_h=\sum_{\substack{D<u<2M/3\\u\ {\rm odd}}}\mu(u)\mathcal K_h(u)
+O_\psi(H^{-3}\log^2M+M^{-1})
\quad(H/2\le|h|\le4H).
\]
带权平方误差至多 $O_{\psi,\eta}(H^{-5}\log^4 M+H/M^2)$。又因每个 $u>D$ 只有 $O(M/u)$ 个活动 cofactor，$|\mathcal K_h(u)|\ll_\psi\log(2M/u)/u$；源对角至多 $O_{\psi,\eta}(H^2\log^2(2H)/M)$。由 $\ell^2$ 三角不等式、(1) 及“不同源协方差 = 源包能量 $-$ 对角”，
\[
|\mathfrak C_{\rm odd}|
\ll_{\psi,\eta} e^{-2cV_Y}
+H^{-5}\log^4M+H/M^2+H^2\log^2(2H)/M. \tag{12}
\]
后面三项在 $Y^{1/5}\le H\le Y^{1/4}$ 上一致小于任意固定的次指数衰减，因而得 (C) 第一式；由 (2) 和 $M=2Y$ 得第二式。$\square$

为证 (T)，以 $H_0,2H_0,4H_0,\ldots$ 作 dyadic 分段，只取起点小于 $Y^{1/4}$ 的分段。使用 (3) 的第二式时，每段起点都在 (2) 内，覆盖 $H_0\le q(h)<Y^{1/4}$；段数为 $O(V_Y+1)$，故这部分周期频率的归一化能量为 $O(Y^2V_Ye^{-dV_Y})=o(Y^2)$。$S_{Y-h}=S_{-h}$ 是整数 $N$ 上的精确周期恒等式，因而正负两侧都已计入。对 $q(h)\ge Y^{1/4}$，应用 note 847 式 (2)，得 $O_\psi(Y^2\log(2Y))$；完整周期 Parseval 即给 (T)。$\square$

## 回顾与边界

此处最小的决策性输入是同一固定幂长短块上对 $\mu$ 与 $\Lambda-1$ 的**一致次指数节省**。实际使用的是 Ramachandra 定理加 $Q\gg Y^{7/12+\varepsilon}$，并非把旧稿中不成立的 Matomäki–Shao–Tao–Teräväinen 指数量化重新引入。短块 Parseval 的传递率是平方的；因此这种一阶输入最多直接达到 $H\gtrsim Y^{1/4}e^{-cV_Y/2}$，不能产生固定幂内点所需的二点 signed covariance。下一条决定性未知仍是 note 849 式 (15) 的中距离真实算术和。
