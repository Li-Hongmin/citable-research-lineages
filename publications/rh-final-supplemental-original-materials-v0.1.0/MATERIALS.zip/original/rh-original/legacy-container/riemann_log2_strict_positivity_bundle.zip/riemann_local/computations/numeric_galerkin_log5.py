import numpy as np, math, sys
from fractions import Fraction
from scipy.special import digamma
from scipy.linalg import eigh
R=int(sys.argv[1]) if len(sys.argv)>1 else 200
N=int(sys.argv[2]) if len(sys.argv)>2 else 500
PAR=sys.argv[3] if len(sys.argv)>3 else '+'
a=math.log(5)/2
pi=math.pi
eps=1 if PAR=='+' else -1

def rate_value(k):return complex(float(k[0]),float(k[1])*pi/a)
def Iexp(k,lo,hi):
 z=rate_value(k)
 if abs(z)<1e-15:return hi-lo
 return (np.exp(z*hi)-np.exp(z*lo))/z
def inner(r1,r2,lo,hi):
 s=0j
 for c1,k1 in r1:
  for c2,k2 in r2:
   k=(k1[0]+k2[0],-k1[1]+k2[1]);s+=np.conj(c1)*c2*Iexp(k,lo,hi)
 return s.real
def basis(k):
 if PAR=='+':
  if k==0:return [(1/math.sqrt(a),(Fraction(0),Fraction(0)))]
  n=math.sqrt(2/a);return [(n/2,(Fraction(0),Fraction(k))),(n/2,(Fraction(0),Fraction(-k)))]
 q=Fraction(2*k+1,2);n=math.sqrt(2/a);return [(-1j*n/2,(Fraction(0),q)),(1j*n/2,(Fraction(0),-q))]
def transform(rep,kind,d):
 out=[]
 for c,k in rep:
  z=rate_value(k)
  if kind=='ref':out.append((c*np.exp(z*d),(-k[0],-k[1])))
  elif kind=='plus':out.append((c*np.exp(z*d),k))
  elif kind=='minus':out.append((c*np.exp(-z*d),k))
 return out
def rankrep(n):
 c=2*(n+.25);em=math.exp(-c*a)
 if PAR=='+':
  den=math.sqrt(1-em*em);return [(em/den,(Fraction(4*n+1,2),Fraction(0))),(em/den,(Fraction(-(4*n+1),2),Fraction(0)))]
 den=math.sqrt(1+em*em);return [(em/den,(Fraction(4*n+1,2),Fraction(0))),(-em/den,(Fraction(-(4*n+1),2),Fraction(0)))]
def polar():return [(1,(Fraction(1,2),Fraction(0))),(1 if PAR=='+' else -1,(Fraction(-1,2),Fraction(0)))]
BAS=[basis(i) for i in range(R)]
D=np.zeros(R)
for k in range(R):
 q=k if PAR=='+' else k+.5;kap=q*pi/a;D[k]=digamma(.25+0.5j*kap).real-math.log(pi)
A=np.diag(D)
# positive Yukawa ranks
for n in range(N):
 f=rankrep(n);h=np.array([inner(b,f,0,a) for b in BAS]);A+=np.outer(h,h)
# polar
f=polar();h=np.array([inner(b,f,0,a) for b in BAS]);A+=(1 if PAR=='+' else -1)*np.outer(h,h)
# prime terms
d2=math.log(2);d3=math.log(3);d4=2*d2
alpha2=d2/math.sqrt(2);alpha3=d3/math.sqrt(3);alpha4=d2/2
terms=[(-eps*alpha2,'ref',d2,0,d2),(-alpha2,'plus',d2,0,a-d2),(-alpha2,'minus',d2,d2,a),(-eps*alpha3,'ref',d3,d3-a,a),(-eps*alpha4,'ref',d4,d4-a,a)]
for coeff,kind,d,lo,hi in terms:
 RB=[transform(b,kind,d) for b in BAS]
 M=np.array([[inner(BAS[i],RB[j],lo,hi) for j in range(R)] for i in range(R)])
 A+=coeff*M
A=(A+A.T)/2
w=eigh(A,eigvals_only=True,subset_by_index=[0,9])
print(PAR,R,N,w)
