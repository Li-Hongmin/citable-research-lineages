# 黎曼猜想项目当前承重状态：严格正性推进至 \(a=\log2\)

**日期：** 2026-08-11  
**当前主结论：** 在既有 notes 003、017、018、021、022、023 的归一化与定义域链上，新增 Arb--Feshbach 证书证明

\[
A_a^+>0,\qquad A_a^->0,\qquad 0<a\le\log2.
\]

因此若首次退化尺度存在，

\[
a_{\rm deg}>\log2=0.6931471805599453\ldots .
\]

## 新增承重文件

- `024-two-prime-band-complete-strict-positivity-to-log2.md`
- `verify_two_prime_band_endpoint_log2.py`
- `log2_+_R30_N80.txt`
- `log2_-_R30_N80.txt`
- `log2_+_R40_N100.txt`
- `log2_-_R40_N100.txt`
- `SHA256SUMS.txt`

## 证书结构

\[
\text{Fourier diagonal}
+\text{前 }N\text{ 个正 Yukawa atoms}
+\text{精确两反射 prime operator}
+\text{极点 rank one}
\to
R\times R\text{ Feshbach matrix}.
\]

主参数：\((R,N)=(30,80)\)。冗余参数：\((40,100)\)。两组均通过 320-bit Arb interval LDL；主组还在 220/480-bit 下重放稳定。

## 重要边界

- 这是项目内部严格证书，尚未经过外部解析数论专家独立审稿。
- 它不证明 RH；它排除了 \(0<a\le\log2\) 内的首次退化。
- \(a>\log2\) 后，\(d_2=\log2<a\)，prime shift 同时产生同半区 translation 与跨中心 reflection；note 023 的纯反射 fiber 不能直接沿用。

## 下一唯一主任务

严格推导 \(a>\log2\) 的 parity compression：

\[
-\alpha_d(S_d+S_d^*)-\varepsilon\alpha_dJ_d,
\]

并建立 translation--reflection graph 的统一 resolvent/Feshbach 接口；在该接口完成前，不继续扩大数值矩阵。
