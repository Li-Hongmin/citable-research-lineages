# 历史文献驱动的因果—全正性证明路线图

日期：2026-08-12。

本文不声称解决黎曼猜想。目标是从历史文献中重新找出一个可能被现代路线分流、但仍能与本项目局部 Weil 形式接上的证明接口，并把它压缩成可证伪的引理链。

## 1. 本轮改变的判断

本轮要改变的不是“是否已经有 RH 证明”，而是：在已有局部 Weil 谱流、Schur 补和 global screw-kernel 路线之外，是否存在一条历史上已有严格等价判据、但尚未被系统地接到本项目正性链的路线。

最便宜的区分性观测是核读原始定理和其明确留下的缺口，而不是继续搜集一般性的 RH 等价命题。检索边界为：截至 2026-08-12；重点覆盖 Pólya–Schoenberg 全正性、Nyman–Beurling–Báez-Duarte 近似、Burnol 因果性、de Branges–Weil 正性，以及 de Bruijn–Newman 热流。项目矩阵见 ResearchLibrary 的 `riemann-alternative-routes-2026-08-12`。

## 2. 文献直接支持的四个锚点

### 2.1 Schoenberg：把 RH 改写为单侧 PF∞ 问题

Schoenberg 的全正性理论给出：Pólya frequency function 的 Laplace 变换是 Laguerre–Pólya 类函数的倒数，反之亦然。Gröchenig 2020 将这一对应明确应用于 
\(\Xi\)：若写 \(\Xi(z)=\Xi_1(-z^2)\)，则 RH 等价于存在支撑在 \([0,\infty)\) 上的 Pólya frequency function \(\Lambda\)，使

\[
  \Xi_1(s)^{-1}=\int_0^\infty \Lambda(x)e^{-sx}\,dx
\]

在相应半平面成立。等价地，\(\Lambda\) 的所有平移行列式必须非负，卷积算子必须全阶 variation-diminishing。

这条路线的关键事实不是“PF∞ 自动证明 RH”，而是它把目标写成一个明确的全阶符号问题。Gröchenig 也明确指出，现有文献没有可用的 \(1/\xi\) Fourier/Laplace 变换公式，甚至不知道足以推出一阶正定性的直接输入。因此它不是已关闭路线；但原文没有把它接到 Weil 二次型或整数伸缩近似上。

### 2.2 Báez-Duarte：整数伸缩已经是最小算术生成集

Báez-Duarte 2002 证明，RH 等价于 \(\chi_{(0,1)}\) 属于由整数伸缩的分数部分函数生成的 \(L^2\) 闭包。Burnol 2002 把它写成临界线上 Dirichlet 多项式逼近

\[
  \frac1s\approx \frac{\zeta(s)}s P_N(s),
  \qquad P_N(s)=\sum_{n\le N}c_{n,N}n^{-s},
\]

并给出 square-integrability 与单侧因果性的等价表述。Burnol 同时明确记录：当时仍没有“自然的”显式系数 \(c_{n,N}\) 及其趋零误差上界。

因此真正未解决的接口不是抽象 cyclicity，而是构造带整数支撑的系数，使相应的 Mellin 残差在临界线上趋于零。

### 2.3 Lagarias–de Branges：Weil 正性是同一个对象的另一坐标

Lagarias 2006 说明，完成的 \(L\)-函数及其导数构成的 de Branges 结构函数在 Hermite–Biehler 条件下与 RH 等价，并将 de Branges 范数与 Weil Hermitian form 联系起来。Connes 1997 的 adelic trace-formula 路线给出相同的谱性解释。

这类结果提供的是“若正性成立则零点在临界线”的严格桥梁，不是正性本身。它们提示可以把 PF∞ 的全阶行列式、Báez-Duarte 的整数伸缩 Gram 矩阵、以及本项目的局部 Weil Schur 补视为同一正性问题的三种有限截面。

### 2.4 Rodgers–Tao：热流路线只留下稀有小间隙控制

de Bruijn–Newman 常数满足 \(\Lambda\ge0\)，RH 等价于 \(\Lambda=0\)。这条历史路线将问题变成逆热流的全高度 no-collision 估计；但现有平均零间距和有限高度计算不能控制最危险的小间隙。因此它适合作为反证/压力测试，不适合作为本轮主路线。

## 3. 可能被忽略的拼接：因果 Möbius 逼近 → Weil Schur 链 → PF∞

### 3.1 候选主命题

设 \(\mathcal V_N\) 是由整数伸缩 \(\rho_n(x)=\{1/(nx)\}\) 生成的有限空间，\(d_N\) 是 \(\chi_{(0,1)}\) 到 \(\mathcal V_N\) 的距离。候选证明路线是先证明一个带局部 Weil 输入的乘法递推：

\[
  d_{MN}^2 \le d_N^2\,\prod_{p\le M}(1-\kappa_{p,N})
       + \operatorname{Tail}(M,N),
\]

其中 \(\kappa_{p,N}\ge0\) 是加入 prime-shift 后的真实 Schur 增益，且对某个分块序列满足

\[
  \sum_{p\le M}\kappa_{p,N}\to\infty,
  \qquad
  \operatorname{Tail}(M,N)=o(1).
\]

则 \(d_N\to0\)，由 Báez-Duarte 判据得到 RH。若把同一递推写成 Mellin 变换，所得系数就是一个显式阻尼 Möbius 近似；若把它写成平移核的所有有限 minors，则其极限正是 Schoenberg 的单侧 PF∞ 条件。

这里的“被忽略”不是声称历史作者没有意识到这些对象相关，而是：三条文献路线各自把另一侧当作等价背景，尚未见到把“整数生成集的 Schur 增益”作为 PF∞/Weil 正性之间的定量传递量。

### 3.2 证明链的最小引理

**引理 A（整数 dilation–Weil Gram 恒等式）。** 对有限整数集 \(\mathcal N\)，把 \(\rho_n\) 的 Mellin 变换写成 \(\zeta(s)n^{-s}/s\)，证明 \(\mathcal V_\mathcal N\) 的 Gram 矩阵和投影残差可表示为本项目局部 Weil 二次型的一个显式压缩。要求给出完整归一化、边界项和共轭约定，不能只引用“同构”。

**引理 B（prime-band Schur 增益）。** 在加入一个 prime band 后，若现有局部算子 \(A_a\) 在该 band 的尺度区间具有严格正谱隙，则对应的投影残差有一个显式非负下降量 \(\kappa_{p,N}\)。这一步是本项目已有 Schur 证书最可能直接贡献的地方；但必须证明该下降量作用在整数 dilation 的目标向量上，而不是只作用在抽象局部零模态上。

**引理 C（乘法尾控制）。** 将未激活 prime powers 和高频 Archimedean 尾写成同一加权 resolvent 尾，证明其在分块极限中可求和。现有 notes 021、030、034 已说明粗无权 frame 尾不足，需要保留 weighted tail 与 collective compactness；因此不能用逐项绝对值 majorant 代替本引理。

**引理 D（Schur 增益 → 因果残差）。** 将有限 Gram 的 Schur 补下降量转写为

\[
  \left\|1-\zeta(s)P_N(s)\right\|_{L^2(\Re s=1/2,\,|s|^{-2}dt)}^2.
\]

若下降量的乘积趋零，则得到 Burnol 的单侧因果性；反过来，若该恒等式发现不可消失的正项，则主路线在有限尺度已关闭，而不是继续扩大矩阵。

**引理 E（因果残差 → PF∞，可选升级）。** 只在 A–D 闭合后再处理：用整数 dilation 的全阶 Gram minors 及其一致尾界，证明逆 Mellin 核的所有平移 minors 非负。此处不应假设 PF∞；它是主链之后的升级结论。

## 4. 为什么这条路线比单独 PF 或单独 Hilbert–Pólya 更值得先测

- 单独 PF 路线要求直接构造 \(1/\Xi_1\) 的全阶正性，历史文献已明确指出缺少可操作变换公式。
- 单独 de Branges/谱路线只把 RH 改写为 Weil 正性，当前项目已经发现正性与 injectivity/cyclicity 不能由抽象谱结构推出。
- 单独 Nyman–Beurling 路线知道“存在逼近”，但自然系数和定量误差一直是算术瓶颈。
- 拼接路线先只要求一个可测的 prime-band Schur 下降量；它能直接利用本项目已经完成的局部严格正性、prime activation 分带和加权尾分析。只有当这个下降量真的能作用到整数 dilation 目标向量时，才进入全局证明。

## 5. 最便宜的区分性实验与关闭条件

本轮下一步不应先写 PF∞ 的一般理论，而应选一个有限整数集 \(\mathcal N\) 和一个已完成严格正性的 prime band，计算并严格核对：

1. dilation Gram 的 Schur 补；
2. 对应局部 Weil 压缩的 Schur 补；
3. 两者的归一化比值及剩余边界项。

互斥结果如下：

- 若出现精确恒等式且 \(\kappa_{p,N}>0\)，主路线存活，下一引理是 uniform prime-band gain；
- 若只得到同阶但不相等的两个量，路线需改为寻找显式 intertwiner，不能把局部正性直接晋级为 Nyman–Beurling 收敛；
- 若出现符号不定或 prime-band gain 对目标向量为零，说明当前局部 Weil 正性不能驱动整数逼近，主路线关闭；
- 若有限实验只显示数值下降而无 uniform 尾界，结论仍是 unknown，不得称为证据支持 RH。

## 6. 现阶段结论

截至 2026-08-12，最有价值的历史发现是：Schoenberg 的单侧 PF∞ 判据和 Báez-Duarte–Burnol 的整数因果逼近都保留了“显式算术生成集”这一结构，而不是抽象存在性。把它们通过局部 Weil Schur 增益连接起来，是目前最值得做的一条候选证明路线；它仍只是一条待验证路线，最薄接口是引理 A–B，尤其是目标向量上的非零 Schur 增益。

本 note 不把 de Branges、Connes、Schoenberg 或 Nyman–Beurling 的等价判据当作已经完成的证明，也不把当前项目的有限尺度严格正性外推到全尺度。

## 文献与项目入口

- Gröchenig, *Schoenberg's Theory of Totally Positive Functions and the Riemann Zeta Function*, arXiv:2007.12889；本地全文：`ResearchLibrary/lib/unknownarxiv2007b/unknownarxiv2007b.pdf`。
- Báez-Duarte, *A strengthening of the Nyman-Beurling criterion for the Riemann Hypothesis*, arXiv:math/0202141。
- Burnol, *On an analytic estimate in the theory of the Riemann zeta function and a theorem of Báez-Duarte*, arXiv:math/0202166；本地全文：`ResearchLibrary/lib/unknownarxivmathaj/unknownarxivmathaj.pdf`。
- Lagarias, *Hilbert spaces of entire functions and Dirichlet L-functions*, 2006；本地记录：`ResearchLibrary/lib/lagarias2006hilbert/`。
- Connes, *Trace formula on the Adele Class Space and Weil Positivity*, 1997。
- Rodgers–Tao, *The De Bruijn-Newman constant is non-negative*, 2020；本地记录：`ResearchLibrary/lib/tao2020de/`。
- 当前项目相关入口：[局部谱底与第一次退化的文献归约](001-local-weil-first-degeneration-literature-reduction.md)、[极点项的签名分解与约化 Markov 形式](007-indefinite-polar-splitting-and-reduced-markov-form.md)、[固定秩 Robin deficit 全尾归约](021-fixed-rank-robin-deficit-tail-reduction.md)、[统一 Yukawa coercivity 与无谱逃逸](034-uniform-yukawa-coercivity-and-no-spectral-escape.md)。
