> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 首个 prime activation band 的完整严格正性

日期：2026-08-11。

## 1. 定理

令

\[
a_2:=\frac{\log3}{2}.
\]

则局部 Weil 算子的两个奇偶扇区满足

\[
\boxed{
A_a^+>0,
\qquad
A_a^->0,
\qquad
0<a\le a_2.}
\]

因而

\[
\boxed{
A_a>0
\qquad
\left(0<a\le\frac{\log3}{2}\right).}
\]

特别地，若首次退化尺度存在，则

\[
\boxed{a_{\rm deg}>\frac{\log3}{2}=0.5493061443\ldots .}
\]

## 2. 端点的 prime 结构

在

\[
\frac{\log2}{2}<a\le\frac{\log3}{2}
\]

内，唯一具有正测度重叠的 prime shift 是 \(n=2\)。在右端点，\(n=3\) 的 shift 长度恰为区间
直径，只产生零测度端点接触，故二次型贡献仍为零。

在奇偶半区 \(L^2(0,a)\) 上，令

\[
p=\frac{\log2}{\sqrt2},
\qquad
(Jf)(x)=\mathbf1_{(\log2-a,a)}(x)f(\log2-x).
\]

则

\[
J^*=J,
\qquad
J^2=P_{(\log2-a,a)},
\]

且 prime 项分别为

\[
-pJ\quad\text{和}\quad+pJ.
\]

## 3. 固定秩 Yukawa 下模型

沿用 note 021 的记号。对每个 Yukawa summand \(T_n\)，选择 Robin 模式 \(M\) 作为标量底：

\[
T_n\succeq
\ell_{n,M}I-
\sum_{j<M}d_{n,j}|g_{n,j}\rangle\langle g_{n,j}|,
\]

\[
d_{n,j}=\ell_{n,M}-\ell_{n,j}\ge0.
\]

对 \(n<K\) 保留精确 Robin 模。对 \(K\le n<T\)，不用正交投影，而直接写显式 Taylor 分解

\[
g_{n,j}=p_{n,j}+r_{n,j},
\]

其中 \(p_{n,j}\) 位于固定空间

\[
V_{M,S}=\operatorname{span}
\left\{x^k\cos\left(\frac{\theta_jx}{a}+\phi_k\right):
j<M, 0\le k\le S\right\}.
\]

Young 不等式给出

\[
|g_{n,j}\rangle\langle g_{n,j}|
\preceq
(1+\tau)|p_{n,j}\rangle\langle p_{n,j}|
+(1+\tau^{-1})\|r_{n,j}\|^2I.
\]

聚合 covariance

\[
\mathcal C_j=\sum_{K\le n<T}d_{n,j}c_{n,j}c_{n,j}^{\mathsf T}
\]

用 Arb Cholesky 精确变为有限秩列。note 021 的解析全尾界支付

\[
\rho=(1+\tau^{-1})E,
\]

并覆盖全部 \(n\ge K\) 的 Taylor 余项；\(n\ge T\) 的完整 \(T_n\ge0\) 直接删除。因此该下模型覆盖
完整无穷 Yukawa 和，而不是有限截断的数值近似。

## 4. 偶扇区端点

取

\[
(M,S,K,T)=(5,5,80,10000).
\]

偶 Robin 根满足

\[
z\tan z=2ab_n,
\qquad
j\pi<z<(j+\tfrac12)\pi.
\]

固定秩下模型为

\[
L^+=\beta_+I-W_+W_+^*-pJ+|u\rangle\langle u|,
\qquad
u(x)=2\cosh(x/2).
\]

因 \(\beta_+>p\)，算子 \(B_+=\beta_+I-pJ\) 严格为正。Sherman--Morrison 后，只需证明

\[
S_+=I-W_+^*(B_++|u\rangle\langle u|)^{-1}W_+>0.
\]

完整保留 \(400\) 个低 Robin deficit 与 \(30\) 个聚合方向，故

\[
S_+\in\mathbb{IR}^{430\times430}.
\]

所有 full、collar、reflection 以及与 \(u\) 的矩阵元均化为

\[
\int x^k e^{i\omega x}\,dx,
\qquad
\int x^k e^{(\pm1/2+i\omega)x}\,dx,
\]

并用 Arb 递推或带显式余项的小频级数计算；没有数值求积。输入矩阵最大元素半径为

\[
2.4148\times10^{-56}.
\]

用 32-bit dyadic Householder 方向把唯一近零模隔离为 \(1+429\) 分块。48-bit dyadic Cholesky
witness 给出

\[
C_+\succeq0.000699999999585085\,I,
\]

以及

\[
a_+=1.3577047943466374\times10^{-9},
\qquad
\|r_+\|^2=1.7992535980568122\times10^{-18}.
\]

故

\[
\boxed{
a_+-\frac{\|r_+\|^2}{\lambda_{\min}(C_+)}
\ge1.3577022239843529\times10^{-9}>0.}
\]

所以 \(S_+>0\)，进而 \(A_{a_2}^+\ge L^+>0\)。

## 5. 奇扇区端点

取

\[
(M,S,K,T)=(4,3,80,3000).
\]

奇 Robin 根满足

\[
z\cot z=-2ab_n,
\qquad
(j+\tfrac12)\pi<z<(j+1)\pi.
\]

固定秩下模型为

\[
L^-=\beta_-I-W_-W_-^*+pJ-|v\rangle\langle v|,
\qquad
v(x)=2\sinh(x/2).
\]

令 \(B_-=\beta_-I+pJ>0\)，并把负极点向量 \(v\) 作为一个额外 deficit 列。所得有限 Schur 球矩阵
维数为

\[
320+16+1=337.
\]

36-bit dyadic Householder 与 52-bit dyadic Cholesky witness 给出

\[
C_-\succeq0.0099999999999785375\,I,
\]

\[
a_-=6.3948527058555824\times10^{-6},
\qquad
\|r_-\|^2=6.4821749128210880\times10^{-21},
\]

从而

\[
\boxed{
a_--\frac{\|r_-\|^2}{\lambda_{\min}(C_-)}
\ge6.3948527058549342\times10^{-6}>0.}
\]

所以 \(S_->0\)，进而 \(A_{a_2}^->0\)。

## 6. 从端点传播到整个首带

note 003 的零延拓 min--max 单调性分别保持奇偶子空间。因此对任意 \(0<a\le a_2\)，

\[
\lambda_1^\pm(a)ge\lambda_1^\pm(a_2)>0.
\]

这同时覆盖 prime-free 区间、\(n=2\) 阈值、整个首个 activation band 以及 \(n=3\) 的零测度接触
端点，完成定理证明。

## 7. 可复现证书

~~~bash
uv run --with python-flint --with mpmath python \
  computations/verify_first_band_endpoint_analytic_integrals.py

uv run --with numpy --with python-flint python \
  computations/verify_first_band_endpoint_even.py

uv run --with numpy --with python-flint python \
  computations/verify_first_band_endpoint_odd.py
~~~

承重文件：

- [公共解析 Arb 积分与偶矩阵装配](../computations/verify_first_band_endpoint_even_analytic.py)；
- [偶扇区一维隔离证书](../computations/verify_first_band_endpoint_even.py)；
- [奇扇区解析 Arb 装配](../computations/verify_first_band_endpoint_odd_analytic.py)；
- [奇扇区一维隔离证书](../computations/verify_first_band_endpoint_odd.py)；
- [解析积分独立数值交叉检查](../computations/verify_first_band_endpoint_analytic_integrals.py)。

普通浮点特征向量和 Cholesky 因子只用于选择 dyadic witness；最终不等式全部在 Arb 球上验证。
