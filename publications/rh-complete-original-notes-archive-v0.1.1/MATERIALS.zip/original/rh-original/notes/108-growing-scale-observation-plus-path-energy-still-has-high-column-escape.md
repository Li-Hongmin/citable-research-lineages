> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 增长尺度观测加路径能量仍有高列带逃逸模

日期：2026-08-14。

依赖：
[note 105](105-the-cell-detector-is-zero-free-to-the-imaginary-axis.md)、
[note 106](106-hminus2-observation-and-path-energy-lose-two-thirds-of-an-exponent.md)、
[note 107](107-growing-scale-mellin-frame-fails-at-additive-nyquist-sampling.md)。

证据等级：显式定量近零向量与有限窗 BV 振荡和估计。

note 107 的 additive-Nyquist 反例有一阶路径能量
\(D\asymp\|q\|_2^2\)，因而不排除联合桥

\[
\|q-\bar q\|_2^2
\stackrel{?}{\ll}
\sum_{j\le\log_2Y}\|B_Y^{(j)}q\|_2^2
+\sum_d|q(d+1)-q(d)|^2.
\tag{1}
\]

本文给出同时逃逸两项的显式向量，从而严格否定 (1)。

## 1. 对象

沿用 note 107 的

\[
L_j=2^{-j},\qquad R_j=e^{L_j},
\tag{2}
\]

\[
b_d^{(j,N)}=G_{L_j}(d/N)-G_{L_j}((d+1)/N),
\qquad
(B_Y^{(j)}q)_N=\sum_db_d^{(j,N)}q(d),
\tag{3}
\]

其中 \(Y<N\le2Y\)，且

\[
\operatorname{supp}G_{L_j}\subset[2/3,e^{L_j}].
\tag{4}
\]

取包含全部非零列的共同列域

\[
\mathcal D_Y={d\in\mathbb Z:2Y/3-1<d<2eY\}.
\tag{5}
\]

定义内部高列带和中间振荡频率

\[
I_Y=[2.2Y,2.3Y]\cap\mathbb Z,
\qquad \xi=Y^{1/2},
\tag{6}
\]

\[
v_Y(d)=\left(\frac dY\right)^{i\xi}\mathbf1_{I_Y}(d),
\qquad
c_Y=\frac1{|\mathcal D_Y|}\sum_{d\in\mathcal D_Y}v_Y(d),
\qquad
q_Y=v_Y-c_Y\mathbf1_{\mathcal D_Y}.
\tag{7}
\]

## 2. 主定理

### 定理

上述 \(q_Y\) 满足

\[
\sum_{d\in\mathcal D_Y}q_Y(d)=0,
\qquad
\|q_Y\|_2^2\asymp Y,
\tag{8}
\]

但

\[
\boxed{
\sum_{j=0}^{\lceil\log_2Y\rceil}\|B_Y^{(j)}q_Y\|_2^2
+\sum_d|q_Y(d+1)-q_Y(d)|^2
\ll1.}
\tag{9}
\]

特别地，(1) 不存在与 \(Y\) 无关的常数。

**证明。**

**中心化。** 对每个 \(j,N\)，由 (5) 严格包含该行全部非零 cell，
望远镜和给出

\[
\sum_{d\in\mathcal D_Y}b_d^{(j,N)}=0.
\tag{10}
\]

因此

\[
B_Y^{(j)}q_Y=B_Y^{(j)}v_Y.
\tag{11}
\]

**细尺度的严格屏蔽。** 若 \(j\ge4\)，则

\[
e^{L_j}\le e^{1/16}<1.065<1.1.
\tag{12}
\]

另一方面，对 \(d\in I_Y\) 和 \(N\le2Y\)，

\[
\frac dN\ge1.1,
\qquad
\frac{d+1}{N}>1.1.
\tag{13}
\]

由 (4)，每个相关 cell 都在 \(G_{L_j}\) 支撑之外，故

\[
B_Y^{(j)}v_Y=0\qquad(j\ge4).
\tag{14}
\]

**粗尺度的振荡消去。** 只剩四个固定核 \(j=0,1,2,3\)。
令 \(A_j=G'_{L_j}\)；每个 \(A_j\) 是固定紧支撑 BV 函数。
cell-integral 表示或直接的 BV 平移估计给出，一致于 \(Y<N\le2Y\)，

\[
\|b^{(j,N)}\|_{\ell^\infty(I_Y)}
+\operatorname{Var}_{I_Y}b^{(j,N)}
\ll_jY^{-1}.
\tag{15}
\]

相位 \(\phi(d)=\xi\log(d/Y)\) 在 \(I_Y\) 上满足

\[
\phi'(d)\asymp\frac\xi Y,
\qquad \phi'\ 单调.
\tag{16}
\]

一阶 Kusmin--Landau 估计因此对每个子区间 \(I\subset I_Y\) 给出

\[
\left|\sum_{d\in I}e^{i\phi(d)}\right|
\ll\frac Y\xi.
\tag{17}
\]

对 (15) 作离散 Abel 求和，得

\[
|(B_Y^{(j)}v_Y)_N|
\ll \frac1Y\frac Y\xi
\ll Y^{-1/2}.
\tag{18}
\]

所以

\[
\sum_{j=0}^{\lceil\log_2Y\rceil}\|B_Y^{(j)}q_Y\|_2^2
=\sum_{j=0}^{3}\|B_Y^{(j)}v_Y\|_2^2
\ll Y\cdot Y^{-1}\ll1.
\tag{19}
\]

**路径能量。** 在 \(I_Y\) 内，

\[
|v_Y(d+1)-v_Y(d)|\ll\frac\xi Y=Y^{-1/2}.
\tag{20}
\]

内部差分的平方和为 \(O(1)\)，两个硬截断端点也只贡献 \(O(1)\)。
减去常数不改变内部差分。若将 \(\mathcal D_Y\) 两端连到外部零值，
中心化只额外贡献 \(2|c_Y|^2\)。

最后，(17) 作用于整个 \(I_Y\) 给出

\[
\left|\sum_{d\in I_Y}(d/Y)^{i\xi}\right|
\ll\frac Y\xi\ll Y^{1/2},
\qquad |c_Y|\ll Y^{-1/2}.
\tag{21}
\]

因此中心化仅移除 \(O(1)\) 的平方能量，得

\[
\|q_Y\|_2^2
=|I_Y|-\frac{|\sum_{I_Y}v_Y|^2}{|\mathcal D_Y|}
\asymp Y.
\tag{22}
\]

合并 (19)--(22) 即得 (8)--(9)。\(\square\)

## 3. 机制与边界

逃逸机制可分为三个可检验部件：

\[
\boxed{
\text{高列带屏蔽全部细尺度}
+\text{固定粗块上的中频振荡}
+\text{渐小加法路径频率}.}
\tag{23}
\]

它不是 note 104 的共同 Mellin 精确零，也不是 note 107 的纯 Nyquist 载波。
反例使

\[
\frac{\sum_j\|B_Y^{(j)}q_Y\|_2^2+D(q_Y)}{\|q_Y\|_2^2}
\ll Y^{-1}.
\tag{24}
\]

因此 note 106 中的指数损失不能仅靠将固定 \(H^{-2}\) 观测替换为
growing-scale observation 来消除；在此之前，有限 \(N\)-窗还有独立的高列带几何泄漏。

定理是任意向量的算子反例，不是真实 Mertens 向量的算术非集中定理。
若要修复确定性 frame，最先需要的不是更细的 \(L_j\)，而是使细尺度支撑覆盖
\(d/N>1\) 的中心或尺度轨道；否则总能在其外侧带重复 (23)。
