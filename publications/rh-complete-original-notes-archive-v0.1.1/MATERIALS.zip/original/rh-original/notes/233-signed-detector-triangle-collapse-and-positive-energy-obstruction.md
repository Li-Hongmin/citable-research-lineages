> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有符号 detector 的三角坍缩与正能量逼近障碍

日期：2026-08-16。

本 note 把一个容易与正能量混淆的精确恒等式单独写出。它给出一个很薄的
算术结构，但同时说明为什么它不能直接替代 \\(|h|\\)-能量门。

## 1. 三角坍缩恒等式

令 (V) 是 ((0,1)) 上的多项式零延拓，并定义

\[
P_V(y)=\sum_{c\le y}V(c/y),\qquad y\ge1,
\]

以及偶的有符号对数核

\[
g_V(t)=\frac12P_V(e^{|t|}),qquad t\in\mathbb R.
\]

对 (N\ge1) 定义

\[
Q_{V,N}=\sum_{a,b\le N}\mu(a)\mu(b)
g_V\!\left(\log\frac ab\right).
\]

由于 (g_V(0)=P_V(1)/2=V(1)/2)，分离对角项并按
(a>b) 与 (b>a) 配对，得到

\[
Q_{V,N}=\frac{V(1)}2\sum_{a\le N}\mu(a)^2
 +\sum_{a\le N}\mu(a)\sum_{b<a}\mu(b)P_V(a/b).
\]

展开 (P_V)，并令 (k=cb)：

\[
\begin{aligned}
Q_{V,N}
&=\frac{V(1)}2\sum_{a\le N}\mu(a)^2
 +\sum_{a\le N}\mu(a)
  \sum_{b<a}\mu(b)
  \sum_{c\le a/b}V(cb/a)\\
&=\frac{V(1)}2\sum_{a\le N}\mu(a)^2
 +\sum_{a\le N}\mu(a)\left[
  \sum_{k<a}V(k/a)\sum_{b\mid k}\mu(b)
  +V(1)\sum_{b\mid a,\,b<a}\mu(b)\right]\\
&=\boxed{\frac{V(1)}2\left(1-\sum_{a=2}^{N}\mu(a)^2\right)
  +\sum_{a=2}^{N}\mu(a)V(1/a)}.
\end{aligned}
\tag{1}
\]

这里最后一步还使用了
\(\sum_{b\mid a,\,b<a}\mu(b)=-\mu(a)\)（(a>1)）。因此对一般 (V)，若
(V(u)=O(u^2)) 于 (u\downarrow0)，则该二次型通常含有
\(-\frac{V(1)}2\sum_{2\le a\le N}\mu(a)^2=O_V(N)\) 的对角残项；若进一步
(V(1)=0)，才恢复原来的 (Q_{V,N}=O_V(1)) 一致结论。
对 (V_{15}) 的 (N=1,\ldots,20) 精确有理核验见
`computations/check_signed_detector_triangle_collapse.py`。

## 2. 与 Mellin/Fourier 符号的关系

在 (P_V(e^t)=O(e^{-2t})) 等可积条件下，(g_V\in L^1(\mathbb R))，且其
Fourier 符号是相应的偶化 Mellin 乘积

\[
h_V(\xi)=\operatorname{Re}\{\zeta(i\xi)K_V(i\xi)\},
\qquad
K_V(s)=\int_0^1V(u)u^{s-1}\,du.
\tag{2}
\]

恒等式 (1) 是对有符号 (h_V) 的二次型恒等式；它不是对
(w_V=|h_V|) 的正能量估计。后者的核是
(check w_V)，一般不再等于 (g_V)。

## 3. 为什么不能用 detector 线性组合逼近正能量权

对任何有限线性组合 (V=\sum_j a_jV_j)，只要它非零且仍满足
(V(1)=0)，相应 (g_V(0)=0)。由 Fourier 反演，

\[
\int_{\mathbb R}h_V(\xi)\,d\xi=2\pi g_V(0)=0.
\tag{3}
\]

另一方面，若 (h_{15}\not\equiv0)，则

\[
\int_{\mathbb R}|h_{15}(\xi)|\,d\xi>0.
\]

因此对任意这样的有符号 detector 组合，均有严格的 (L^1) 障碍

\[
\boxed{
\|,|h_{15}|-h_V\,\|_{L^1}
\ge \int_{\mathbb R}|h_{15}(\xi)|\,d\xi.}
\tag{4}
\]

换言之，三角坍缩族不能在 (L^1) 中逼近目标正权。若人为加入一个补偿项
以恢复总质量，它不再享有 (1) 的坍缩；在频率原点集中的补偿会重新产生

\[
\left|\sum_{n\le N}\mu(n)\right|^2,
\]

正是 RH-strength 的 Mertens 通道。

## 4. 对当前 RH 主线的裁决

这个恒等式确认了一个真实的“可消去部分”：有符号 detector quadratic form
本身只留下一个有界的一维 Möbius 和。真正困难全部集中在从 (h_V) 到
(|h_V|) 的符号通道，也就是负频率部分的二次型。

因此下一步不能再把 (1) 当作正能量门的替代品；需要新的 signed
intertwiner，或直接控制

\[
\int h_{V,-}(\xi)\left|\sum_{n\le N}\mu(n)n^{i\xi}\right|^2d\xi.
\]

本 note 是严格结构性进展，不是 RH 证明。

## 5. 任意正频率权的精确半三角正规形

这个坍缩还可以改写成一个不依赖 detector 的正规形。令 (w\ge0) 为偶频率
权，令

\[
k(u)=\frac1{2\pi}\int_{\mathbb R}w(\xi)e^{i\xi u}\,d\xi,
\qquad
P_k(y)=2k(\log y)\quad(y>1),
\]

并约定 (P_k(1)=0) 以把对角线单独取出。则对任意有限 (N)，仅按
(a>b) 分解便有精确恒等式

\[
\boxed{
\sum_{a,b\le N}\mu(a)\mu(b)k\!\left(\log\frac ab\right)
=k(0)\sum_{a\le N}\mu(a)^2
 +\sum_{a\le N}\mu(a)A_k(a),}
\tag{5}
\]

其中

\[
A_k(x)=\sum_{b\le x}\mu(b)P_k(x/b).
\tag{6}
\]

对 (w=|h_{15}|)，左侧正是相应的正能量；第一项已经是 (O(N))，所以
全部困难等价地集中在一个一维的 Möbius-periodization (A_k) 上，而不在
对角线 bookkeeping 上。

在 (operatorname{Re}s>1) 的绝对收敛区，Mellin--Fubini 给出

\[
\int_1^\infty A_k(x)x^{-s-1}\,dx
=\frac1{\zeta(s)}
  \left(2\int_1^\infty k(\log y)y^{-s-1}\,dy\right).
\tag{7}
\]

因此任何能把 (A_k) 压到平方根尺度的估计，都会再次直接暴露
(1/\zeta(s)) 的临界带；这与 notes 212--213 的 RH 门完全一致。式 (5)--(7)
给出了正能量门的更短算术表述，但没有消除 signed Möbius 缺口。
