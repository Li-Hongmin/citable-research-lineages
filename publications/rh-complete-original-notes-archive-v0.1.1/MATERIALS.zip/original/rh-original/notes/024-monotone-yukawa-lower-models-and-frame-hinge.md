> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Yukawa 谱截断下模型的单调极限与 frame 铰链

日期：2026-08-11。

本文建立 note 021 所用 Robin--Yukawa 下模型随 baseline 模数的精确单调性，并确定其不能自动推出
端点正性的原因。对象固定为一个奇偶扇区；结论对任意固定尺度均成立，特别适用于 note 023 的
两素数带端点 \(a=\log2\)。

## 1. 精确谱截断

写第 \(n\) 个正 Yukawa 算子的谱分解为

\[
Y_n=\sum_{j\ge0}\ell_{n,j}P_{n,j},
\qquad
0<\ell_{n,0}<\ell_{n,1}<\cdots<\frac1{b_n},
\quad b_n=n+\frac14.
\]

定义 mode-\(M\) 下模型

\[
L_{n,M}
=\ell_{n,M}I-
\sum_{j<M}(\ell_{n,M}-\ell_{n,j})P_{n,j}.
\tag{1}
\]

等价地，

\[
L_{n,M}
=\sum_{j\ge0}\min(\ell_{n,j},\ell_{n,M})P_{n,j}.
\tag{2}
\]

因此

\[
\boxed{
L_{n,M+1}-L_{n,M}
=(\ell_{n,M+1}-\ell_{n,M})
\left(I-\sum_{j=0}^{M}P_{n,j}\right)
\succeq0.}
\tag{3}
\]

并且

\[
0\preceq L_{n,M}\preceq Y_n,
\qquad
L_{n,M}\xrightarrow[M\to\infty]{\rm strong}Y_n.
\tag{4}
\]

## 2. 固定 \(M\) 的有界算子级数

令

\[
\theta_M^+=\left(M+\frac12\right)\pi,
\qquad
\theta_M^-=(M+1)\pi.
\]

Robin 根满足 \(\mu_{n,M}<\theta_M^\pm/a\)，从而

\[
\|L_{n,M}\|=\ell_{n,M}
\le
\frac{(\theta_M^\pm)^2}{4a^2b_n^3}.
\tag{5}
\]

所以对每个固定 \(M\)，\(\sum_nL_{n,M}\) 按算子范数收敛。令 \(F_a^\pm\) 汇集固定的常数、
prime-shift 与极点秩一项，并置

\[
B_{a,M}^\pm=F_a^\pm+\sum_{n\ge0}L_{n,M}^\pm.
\tag{6}
\]

则

\[
\boxed{
B_{a,M}^\pm\preceq B_{a,M+1}^\pm\preceq A_a^\pm.}
\tag{7}
\]

对任意 \(f\in D(q_{A_a^\pm})\)，标量单调收敛给出

\[
\boxed{
q_{B_{a,M}^\pm}[f]\uparrow q_{A_a^\pm}[f].}
\tag{8}
\]

因此 \(B_{a,M}^\pm\) 以单调闭形式及强预解式意义收敛到 \(A_a^\pm\)。

## 3. 精确增量与高模泄漏

令

\[
\Delta_{n,M}=\ell_{n,M+1}-\ell_{n,M},
\qquad
Q_{n,M+1}=I-\sum_{j=0}^{M}P_{n,j}.
\]

由 (3)，

\[
\boxed{
B_{M+1}-B_M
=R_M
=\sum_n\Delta_{n,M}Q_{n,M+1}\succeq0.}
\tag{9}
\]

若 \(B_M+tR_M\) 的最低本征值简单，归一化基态记为 \(f_{M,t}\)，则 Hellmann--Feynman
公式给出

\[
\boxed{
\lambda_1(B_{M+1})-\lambda_1(B_M)
=\int_0^1\sum_n\Delta_{n,M}
\|Q_{n,M+1}f_{M,t}\|^2\,dt.}
\tag{10}
\]

根间距的初等估计给出

\[
\Delta_{n,M}\lesssim
\begin{cases}
b_nM^{-3},&b_n\lesssim M,\\
Mb_n^{-3},&b_n\gtrsim M,
\end{cases}
\qquad
\|R_M\|=O(M^{-1}).
\tag{11}
\]

因此，若要证明比 \(O(M^{-1})\) 更快的负部消失，真正需要的是近零向量的加权高模泄漏估计。
例如，\(\lambda_1(B_M)\sim-cM^{-2}\) 将强迫

\[
\sum_n\Delta_{n,M}
\|Q_{n,M+1}f_{M,t}\|^2=O(M^{-3}).
\tag{12}
\]

## 4. 不存在算子范数捷径

对每个固定 \(M\)，

\[
\|Y_n-L_{n,M}\|
=\frac1{b_n}-\ell_{n,M}
\sim\frac1{b_n}
\qquad(n\to\infty).
\]

故

\[
\boxed{
\sum_n\|Y_n-L_{n,M}\|=\infty.}
\tag{13}
\]

也就是说，(8) 是真正的形式收敛，不能升级为 \(\|A-B_M\|\to0\)。此外，若写

\[
\sum_nL_{n,M}=\alpha_MI-Q_M,
\]

则端点诊断显示

\[
\alpha_M=O(\log M),
\qquad
\operatorname{tr}Q_M=\Theta(M).
\tag{14}
\]

所以 \(\|Q_M\|\le\operatorname{tr}Q_M\) 的粗估计随 \(M\) 恶化，不能给出趋零负部。

## 5. 单调极限不决定符号

即使 \(B_M\uparrow A\) 且每个 \(B_M\) 只有有限负谱，也不能推出 \(\|(B_M)_-\|\to0\)。例如

\[
B_M=-\left(1+\frac1M\right)|e\rangle\langle e|
\uparrow-|e\rangle\langle e|.
\tag{15}
\]

因此端点正性不能由 (7)--(8) 单独推出。

## 6. 精确剩余不等式

把正 base 与精确 prime-orbit resolvent 吸收到 \(E_M\succ0\)，把全部负 deficit 写成
\(W_MW_M^*\)：

\[
B_M=E_M-W_MW_M^*.
\]

若存在 \(\eta_M\downarrow0\) 使

\[
\boxed{
I-W_M^*E_M^{-1}W_M\succeq-\eta_MI,
\qquad
\eta_M\|E_M\|\longrightarrow0,}
\tag{16}
\]

则 \(CC^*\) 与 \(C^*C\) 的非零谱一致（\(C=E_M^{-1/2}W_M\)），从而

\[
B_M\succeq-\eta_M\|E_M\|I.
\]

结合 (7) 即得 \(A\succeq0\)。

式 (16) 是当前最薄的剩余铰链：它要求不同 \(n\) 的 Robin frames 在精确 prime-orbit resolvent
度量中的统一 cancellation/frame 界。baseline coercivity、trace 估计、有限参数的
\(T^{-2}\) 拟合或形式单调性本身均不能替代它。

## 7. 频率紧性的可选接口

若 \(P_R\) 是某个紧预解式参考算子的前 \(R\) 模投影，一个足以防止负方向逃逸的条件是

\[
\lim_{R\to\infty}
\sup_{M\ge M(R)}
\sup_{\substack{\|f\|=1\\q_{B_M}[f]\le0}}
\|(I-P_R)f\|=0.
\tag{17}
\]

但 (17) 只把持久负隙压成 \(A\) 的真实局域化负向量；要得正性，仍须在紧极限通道上证明极限
Schur 算子非负。因此当前首选目标仍是直接建立 (16)，或等价地控制 (10) 中的高模泄漏。
