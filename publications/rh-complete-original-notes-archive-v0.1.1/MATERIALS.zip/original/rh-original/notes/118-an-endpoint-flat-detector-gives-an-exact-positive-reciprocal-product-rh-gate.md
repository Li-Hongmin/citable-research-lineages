> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 端点平坦 detector 给出精确正 reciprocal-product RH 门

日期：2026-08-14。

依赖：
[note 101](101-a-bv-mellin-detector-sees-exactly-uncancelled-zeta-multiplicity.md)、
[note 116](116-the-first-cosine-gate-has-an-rh-strength-zero-frequency-rank-one-block.md)、
[note 117](117-zero-mean-mellin-differentiation-moves-rank-one-into-a-sawtooth-covariance.md)。

证据等级：有理 Mellin 变换、精确 Faulhaber 恒等式及截断卷积恒等式。

note 117 表明零均值本身只把 bulk rank-one 搬到 Euler 边界。
本文同时消去 detector 的两个端点值，得到一个无渐近余项的正
reciprocal-product 核。相应双 Möbius 和与原 detector 和只差 \(O(1)\)，
从而给出一个新的显式 RH 等价门。

## 1. 最小端点平坦 detector

令

\[
H(u)=u(1-u)^2\mathbf1_{(0,1)}(u)
\tag{1}
\]

及

\[
\begin{aligned}
V(u)
&=(-u\partial_u-1)H(u)\\
&=-2u+6u^2-4u^3\\
&=-2u(1-u)(1-2u),
\qquad 0<u<1,
\end{aligned}
\tag{2}
\]

并在区间外取零。则

\[
V(0+)=V(1-)=0,\qquad
\int_0^1V(u)\,du=0.
\tag{3}
\]

零延拓连续且属于 \(BV_c\)。其 Mellin 变换为

\[
\begin{aligned}
K_V(s)
&=-\frac2{s+1}+\frac6{s+2}-\frac4{s+3}\\
&=\boxed{\frac{2(s-1)}{(s+1)(s+2)(s+3)}}.
\end{aligned}
\tag{4}
\]

所以 \(K_V\) 在 \(1/2<\Re s<1\) 零自由。note 101 给出

\[
\boxed{
\mathrm{RH}
\iff
\forall\varepsilon>0,\quad
|U_V(x)|\ll_\varepsilon x^{1/2+\varepsilon},}
\tag{5}
\]

其中

\[
U_V(x)=\sum_n\mu(n)V(n/x).
\tag{6}
\]

同样，(5) 可替换为 dyadic \(L^2\) 门。

## 2. 精确 Faulhaber 核

定义

\[
P_V(y)=\sum_{c\le y}V(c/y),\qquad
N=\lfloor y\rfloor,\qquad r=\{y\}.
\tag{7}
\]

前三个幂和公式给出

\[
\begin{aligned}
P_V(y)
&=-\frac2y\sum_{c=1}^Nc
+\frac6{y^2}\sum_{c=1}^Nc^2
-\frac4{y^3}\sum_{c=1}^Nc^3\\
&=-\frac{N(N+1)}y
+\frac{N(N+1)(2N+1)}{y^2}
-\frac{N^2(N+1)^2}{y^3}.
\end{aligned}
\tag{8}
\]

提取 \(N(N+1)/y^3\) 后，余下括号是

\[
-y^2+(2N+1)y-N(N+1)=r(1-r).
\tag{9}
\]

因此有无余项的严格恒等式

\[
\boxed{
P_V(y)
=\frac{\lfloor y\rfloor(\lfloor y\rfloor+1)}{y^3}
\{y\}(1-\{y\}).}
\tag{10}
\]

特别地，

\[
P_V(y)\ge0,\qquad
P_V(y)=0\ (y\in\mathbb N),\qquad
P_V(y)\ll y^{-1}\ (y\ge1).
\tag{11}
\]

这是 endpoint-flat 修正带来的精确正核，而不是 Euler 渐近式。

## 3. 精确双 Möbius 门

置

\[
\nu_x(n)=\mu(n)\mathbf1_{n\le\sqrt x}.
\tag{12}
\]

由 note 116 的截断恒等式，对 \(n\le x\)，

\[
\mu(n)=2\nu_x(n)-(\nu_x*\nu_x*1)(n).
\tag{13}
\]

乘 \(V(n/x)\) 并求和，得到

\[
U_V(x)=2A_V(x)-T_V(x),
\tag{14}
\]

其中

\[
A_V(x)=\sum_{n\le\sqrt x}\mu(n)V(n/x),
\tag{15}
\]

\[
\boxed{
T_V(x)=
\sum_{a,b\le\sqrt x}\mu(a)\mu(b)
P_V\left(\frac{x}{ab}\right).}
\tag{16}
\]

由于 \(V(u)=-2u+O(u^2)\) 于 \(u=0\)，直接取绝对值得

\[
|A_V(x)|
\le\frac2x\sum_{n\le\sqrt x}n
+\frac6{x^2}\sum_{n\le\sqrt x}n^2
+\frac4{x^3}\sum_{n\le\sqrt x}n^3
\ll1.
\tag{17}
\]

故

\[
\boxed{T_V(x)=-U_V(x)+O(1).}
\tag{18}
\]

结合 (5)，得到：

### 定理

以下命题等价：

1. RH；
2. 对每个 \(\varepsilon>0\)，

   \[
   \boxed{
   \left|
   \sum_{a,b\le\sqrt x}\mu(a)\mu(b)
   \frac{\lfloor x/(ab)\rfloor(\lfloor x/(ab)\rfloor+1)}
   {(x/(ab))^3}
   \left\{\frac{x}{ab}\right\}
   \left(1-\left\{\frac{x}{ab}\right\}\right)
   \right|
   \ll_\varepsilon x^{1/2+\varepsilon}.}
   \tag{19}
   \]

这里核逐项非负；符号完全来自 \(\mu(a)\mu(b)\)。

## 4. Centered Bernoulli 分解

由

\[
r(1-r)=\frac16-B_2(r),\qquad
B_2(r)=r^2-r+\frac16,
\tag{20}
\]

以及

\[
\frac{N(N+1)}{y^3}
=\frac1y+\frac{1-2r}{y^2}+\frac{r^2-r}{y^3},
\tag{21}
\]

首个 separated component 是 \(1/(6y)\)。代入 (16) 得

\[
\boxed{
\frac1{6x}
\left(\sum_{a\le\sqrt x}a\mu(a)\right)^2.}
\tag{22}
\]

逐块要求 (22) 为 \(O_\varepsilon(x^{1/2+\varepsilon})\)，等价于

\[
\sum_{a\le z}a\mu(a)
\ll_\varepsilon z^{3/2+\varepsilon}.
\tag{23}
\]

而 (23) 与 Mertens 的 RH 强度界等价。两个方向分别由

\[
\sum_{n\le z}n\mu(n)
=zM(z)-\sum_{n<z}M(n)
\tag{24}
\]

和

\[
M(z)
=\frac1z\sum_{n\le z}n\mu(n)
+\sum_{n<z}
\frac{\sum_{k\le n}k\mu(k)}{n(n+1)}
\tag{25}
\]

得到。

因此不能单独估计 (22)；它必须与
\(B_2(\{x/(ab)\})\) 的 centered reciprocal-product 部分发生 signed
cancellation。

## 5. 一般系数边界

核的正性不会自动给出上界。取一般系数 \(\lambda(a)=1\)，支撑在

\[
0.72\sqrt x\le a\le0.74\sqrt x.
\tag{26}
\]

此方块中的 \(x/(ab)\) 位于避开整数的固定紧区间，故由 (10)

\[
P_V(x/(ab))\ge c>0.
\tag{27}
\]

该方块含 \(\asymp x\) 个 pairs，所以

\[
\sum_{a,b}\lambda(a)\lambda(b)P_V(x/(ab))\gg x.
\tag{28}
\]

另一方面，逐项绝对值和 (11) 也只给

\[
|T_V(x)|
\ll\sum_{a,b\le\sqrt x}\frac{ab}{x}
\ll x.
\tag{29}
\]

所以仅使用核正性、两侧 \(\ell^2\) 范数或无额外算术结构的标准
large-sieve/Type-II 界，不能突破 \(x\) 级。目标 \(x^{1/2+\varepsilon}\)
必须保存实际 Möbius signed covariance。

## 6. Beta detector 层级

上述例子属于一般族

\[
H_{p,q}(u)=u^p(1-u)^q\mathbf1_{(0,1)},\qquad
V_{p,q}=(-u\partial_u-1)H_{p,q}.
\tag{30}
\]

对 \(p\ge0,\ q\ge1\)，

\[
V_{p,q}(u)
=u^p(1-u)^{q-1}
\big((p+q+1)u-(p+1)\big),
\tag{31}
\]

\[
\boxed{
K_{V_{p,q}}(s)
=(s-1)B(s+p,q+1).}
\tag{32}
\]

Beta 因子在 \(\Re s>0\) 无零，所以这些 detector 都保持临界条带
零自由。增加 \(p,q\) 可把 Euler 边界推到更高 jet，但不会改变
截断恒等式 (14)；相应完整双和的平方根界仍与其 RH-visible detector
门等强。

## 7. 结论

端点平坦化成功产生了一个完全显式、非负、无渐近余项的
reciprocal-product 核，并把 RH 等价门压到 (19)。它同时证明：

- bulk 零频和低阶 endpoint rank-one 都可从核中显式移除；
- separated Bernoulli mean 仍携带 RH 强度的加权 Möbius moment；
- 一般系数与绝对值方法停在 \(x\) 级；
- 唯一可能的平方根增益来自真实 Möbius signed covariance。

这是新的精确 RH 等价判据与结构性边界，不是 RH 的证明。
