> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# L=2 raw 累计核：尾部与低指标正性

日期：2026-08-15。

本 note 给出 notes/163 中唯一未闭合的 raw cumulative Beta 核的进一步严格归约。
结论只针对 raw 系数，不宣称 γ_{m,h,2} 的全称正性。

## 1. 离散系数的归一化

令
\[
 D=3m+3,\qquad M=m-1-r,\qquad N=3m-2-M,
 \qquad L=N+3=3m+1-M .
\]
对 notes/163 的 Beta-β^r 分量，若
\(p_j=[x^j]P_{m,r}(x)\)，则
\[
 p_j=\binom Lj R_{m,M}(u),\qquad u=L-j,
\]
其中
\[
\begin{aligned}
 A(u)&=\frac{(3m+1)u}{2L}
 -\frac{(m-1)u(u-1)}{2L(L-1)}
 -\frac{Mu(u-1)(u-2)}{8L(L-1)(L-2)}-3,\\
 B(u)&=\frac{(3m+1)u}{L}
 -\frac{2(m-1)u(u-1)}{L(L-1)}
 -\frac{Mu(u-1)(u-2)}{L(L-1)(L-2)},\\
 R_{m,M}(u)&=2^uA(u)+4(2^{M+1}-1)B(u)+12(1-2^M).
\end{aligned}
\tag{1}
\]
因此 raw cumulative 系数的正性可由该离散序列的符号变化或前缀和控制。

## 2. 尾部 (u\ge7) 的严格结构性归约与闭合

对 (m\ge4)、(0\le M\le m-1)，有：

1. \(A(7)>0\)。写成共同正分母后的分子
\[
 Q=12M^3-66M^2m+14M^2+72Mm^2+42Mm-187M
   +54m^3-252m^2+330m-84 .
\]
作为 M 的二次差分/连续二阶导数满足凹性，故在区间端点取最小值；
\[
 Q(0)=6(m-2)(3m-7)(3m-1)>0,\qquad
 Q(m-1)=72m^3-172m^2+43m+105>0.
\]

2. \(A(u)\) 在整数 \(u\ge7\) 上递增。\(\Delta A(u)\) 是凹二次式；其在 7 处的分子为
\[
 N=6M^2m+2M^2-36Mm^2+22Mm-89M
   +54m^3-84m^2+106m-28,
\]
且 \(N\) 随 M 下降，最小端点为
\[
 N(m-1)=3(8m^3-12m^2-m+21)>0.
\]
另一端
\[
 \Delta A(L-1)=\frac{-3M+4m+12}{8L}>0,
\]
故 \(\Delta A(u)\ge0\) 于整个可行区间。

3. \(B(u)>0\) 于整数 \(u\ge1\)。将 B 写为 \(uH(u)/L\)；\(H(L)=m+3-M>0\)，且相应凹性给出 \(B(u)\ge B(1)>0\)。

因此对 \(u\ge7\)，第一项 \(2^uA(u)\) 与第二项均为正；但这两项仍须与
\(12(1-2^M)\) 的负常数项合并，不能仅凭逐项符号推出 \(R\ge0\)。
\[
 R_{m,M}(u)\ge 2^uA(7)+4(2^{M+1}-1)\min\{B(7),B(L)\}+12(1-2^M),
\tag{2}
\]
其中使用了 \(A(u)\ge A(7)\) 与 \(LB(u)=uH(u)\) 的凹性（从而相应端点下界）。这个二变量标量不等式实际上可以严格闭合如下。令 \(z=2^M\ge2\)、\(C=4(z-1)\)、\(E=12(1-z)\)，分别记右端在 \(B(7)\) 和 \(B(L)\) 处为 \(S_7,S_L\)。有
\[
S_7(z)=\frac{4H_7}{L(L-1)(L-2)}\quad(z=2),
\]
其中
\[
H_7=99M^3-492M^2m+133M^2+279Mm^2+525Mm-2360M
 +918m^3-2772m^2+3594m-924.
\]
它关于 M 凹（\(H_7''=594M-984m+266<0\)），且两个端点分别为
\(H_7(1)=918m^3-2493m^2+3627m-3052>0\) 与
\(H_7(m-1)=2(402m^3-853m^2+124m+735)>0\)。同时 \(S_7\) 关于 z 的斜率分子随 M 下降，最小端点值为 \(4(36m^3-58m^2-17m+105)>0\)，故 \(S_7(z)>0\)。

另一方面，\(S_L\) 的 z 斜率为 \(4(-2M+2m+3)>0\)，且
\[
S_L(2)=\frac{4H_L}{L(L-1)(L-2)},
\]
\[
H_L=3M^4-30M^3m+90M^3+108M^2m^2-474M^2m+109M^2
 -162Mm^3+414Mm^2+348Mm-1490M
 +81m^4+594m^3-2025m^2+2622m-672.
\]
对 \(M\in[1,m-1]\)，\(H_L\) 严格递减（\(m=4\) 时由 \(H_L''<0,H_L'(1)<0\)；\(m\ge5\) 时 \(H_L''\ge0,H_L'(m-1)<0\)），故取最小端点；\(H_L(m-1)=4(162m^3-317m^2+95m+210)>0\)。因此 \(S_L>0\)，从而 (2) 给出
\[
R_{m,M}(u)\ge0\qquad(m\ge4,\;M\ge1,\;u\ge7).
\]
这一步是显式多项式端点证明，不是有限数值扫描。

有一个可严格关闭的边界：当 \(M=0\) 时，常数项为零，且 \(A(u),B(u)>0\) 对 \(u\ge7\)，所以 \(R(u)>0\) 于该尾部。此时
\[
R(0)=-3,\quad R(1)=-1,\quad
R(2)=-\frac{20(m-1)}{3m(3m+1)},\quad
R(3)=-\frac{24(m-1)}{m(3m+1)},
\]
\[
R(4)=-\frac{64(m-1)}{m(3m+1)},\quad
R(5)=\frac{4(3m^2-39m+40)}{m(3m+1)},\quad
R(6)=\frac{8(9m^2-47m+50)}{m(3m+1)}>0.
\]
因此 \(M=0\) 分支至多一次符号变换。其端点总和直接为
\[
P_{m,r}(1)=\frac{2^{3m}(24m+24)+3^{3m}(7m-22)}3>0
\qquad(m\ge4).
\]
故该分支的 raw cumulative 前缀和也均为正。

## 3. 尚未闭合的最薄缺口

对 \(M\ge1\)，低点 \(u=0,\ldots,6\) 的严格符号与端点总和已由配套
note 164-low-index-sign-control-and-prefix-lemma 给出。因此对 \(m\ge4\) 的每个
\(M\) 分量，raw cumulative 前缀系数均已闭合为正。剩余只包括
\(m=2,3\) 的有限低层；完整 \(\gamma_{m,h,2}\) 已由 note 170 的精确表处理，
尽管对应 raw cumulative 本身可以有负项。

精确重算还显示：m=2、3 的 raw cumulative 序列确有负项（例如 m=2 的序列含 \(-4/49\)），但这不等于完整 \(\gamma_{m,h,2}\) 为负；低 m 可保留有限直接核验。

## 4. 算术边界

即便补上六点不等式并得到 L=2 正性，它仍只加强 detector 的有限 Newton 层。notes/148、156 已给出 entrywise 非负核的固定负 Möbius 块，因此仍缺少保持 \(\mu(a)\mu(b)\) signed Hankel 结构的 arithmetic intertwiner；这一步不能由本 note 的系数正性推出。
