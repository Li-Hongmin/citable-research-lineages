> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Prime-free 全谱严格尺度流与正交换子

日期：2026-08-11。本文把 note 003 的全谱单调不增在第一个 prime-shift 阈值以前升级为严格下降，
并给出固定区间上的精确形式导数。该结果控制 crossing 的方向与横截性，但不排除 crossing。

## 1. Archimedean multiplier

prime-free 约化算子的全直线 Fourier multiplier 为

\[
m(\xi)
=\operatorname{Re}\psi\!\left(\frac14+\frac{i\xi}{2}\right)-\log\pi.
\]

令

\[
b_n=n+\frac14,\qquad y=\frac{\xi}{2}.
\]

由 trigamma 级数

\[
\psi'(z)=\sum_{n=0}^{\infty}\frac1{(n+z)^2}
\]

及局部一致收敛，可逐项微分得到

\[
m'(\xi)
=y\sum_{n=0}^{\infty}
\frac{b_n}{(b_n^2+y^2)^2}.
\]

因此

\[
\boxed{
w(\xi):=\xi m'(\xi)
=\sum_{n=0}^{\infty}
\frac{b_n\xi^2}
{2(b_n^2+\xi^2/4)^2}>0
\qquad(\xi\ne0).}
\]

此外，

\[
w(\xi)=O(\xi^2)\quad(\xi\to0),
\qquad
w(\xi)\to1\quad(|\xi|\to\infty).
\]

故

\[
\boxed{w\in L^\infty(\mathbb R),\qquad w>0\ \text{a.e.}}
\]

这个有界性使尺度导数在 \(L^2\) 层面成立，不需要额外的 dilation-generator 定义域。

## 2. 固定区间形式

定义酉映射

\[
(U_aw)(x)=a^{-1/2}w(x/a):
L^2(-1,1)\longrightarrow L^2(-a,a).
\]

在

\[
0<a<\frac{\log2}{2}
\]

内没有 prime-power shift。把 \(q_a^{\rm red}\) 拉回 \((-1,1)\)，得到

\[
\mathfrak q_a(w)
=\frac1{2\pi}\int_{\mathbb R}
m(\eta/a)|\widehat w(\eta)|^2\,d\eta.
\]

不同 \(a\) 的 form domain 相同，因为 \(m(\eta/a)\) 的 logarithmic 增长彼此等价。由
\(w(\xi)=\xi m'(\xi)\in L^\infty\) 和支配收敛，

\[
\boxed{
\partial_a\mathfrak q_a(w)
=-\frac1a\frac1{2\pi}\int_{\mathbb R}
w(\eta/a)|\widehat w(\eta)|^2\,d\eta<0
\qquad(w\ne0).}
\]

对任意紧尺度区间，该导数是共同 form domain 上的 \(L^2\)-有界形式。因此拉回后的闭形式构成
\(C^1\) 族；结合紧预解式，退化本征空间上的一阶扰动矩阵为

\[
-\frac1a\,P_Ew(D/a)P_E,
\]

且严格负定。

## 3. 全部编号本征值严格下降

若

\[
0<a_1<a_2\le\frac{\log2}{2},
\]

则对任意 \(0\ne f\) 属于共同 form domain，

\[
\mathfrak q_{a_2}(f)<\mathfrak q_{a_1}(f).
\]

固定 \(j\)，取 \(\mathfrak q_{a_1}\) 的前 \(j\) 个本征空间之和 \(E_j\)。单位球
\(E_j\cap\{\|f\|=1\}\) 紧，连续函数

\[
\mathfrak q_{a_1}(f)-\mathfrak q_{a_2}(f)
\]

在其上有严格正的最小值。由 min--max 原理，

\[
\boxed{
\lambda_j(M_{a_2})<\lambda_j(M_{a_1})
\qquad
\forall j\ge1.}
\]

同一论证分别适用于偶、奇不变子空间：

\[
\boxed{
\lambda_j(M_{a_2}^{\pm})<\lambda_j(M_{a_1}^{\pm})
\qquad
\forall j\ge1.}
\]

阈值 \(a_2=\frac12\log2\) 包含在内：刚出现的 \(n=2\) 位移等于区间直径，其 jump 质量与标量
修正精确抵消，算子仍等于 prime-free 左极限。

若某条局部可微谱支在 \(a\) 处由归一化本征函数 \(u_a\) 表示，则

\[
\boxed{
\lambda'(a)
=-\frac1a\frac1{2\pi}\int_{\mathbb R}
\xi m'(\xi)|\widehat u_a(\xi)|^2\,d\xi<0.}
\]

退化点的一阶分裂矩阵严格负定。因此 prime-free 的任何可微零 crossing 都是向下且横截的。

## 4. Pohozaev 边界

形式正交换子

\[
\frac1{2\pi}\int_{\mathbb R}
\xi m'(\xi)|\widehat u(\xi)|^2\,d\xi>0
\]

不能直接与本征方程测试 \(x\partial_xu\)。exterior-zero logarithmic 本征函数的尺度路径通常不在
form 范数中可微，形式积分分部会遗漏边界 anomaly。现有 fractional Pohozaev 恒等式依赖
\[
\xi m_s'(\xi)=2s\,m_s(\xi)
\]
的齐次性与 \(u/d^s\) 的边界迹；这里二者均不存在现成替代。

更重要的是，

\[
\text{谱简单或 crossing 横截}
\not\Longrightarrow
\langle u,\cosh(x/2)\rangle\ne0
\]

或

\[
\langle u,\sinh(x/2)\rangle\ne0.
\]

因此本文不把严格尺度流解释为零谱 cyclicity。

## 5. 文献与新增边界

Kaleta--Kwaśnicki--Małecki,
*Asymptotic estimate of eigenvalues of pseudo-differential operators in an interval*,
[arXiv:1507.05483](https://arxiv.org/abs/1507.05483)，处理 complete Bernstein 符号并要求

\[
r\Psi'(r)\to\infty.
\]

其正文明确指出 \(\Psi(r)=\log(1+r)\) 不满足该条件。本文的 digamma 符号同样是 slowly varying
的 order-zero 端点，

\[
r\Psi'(r)\to\frac12,
\]

所以该文的高频分离定理不能直接推出这里的严格谱流。

本文的正交换子级数、共同形式域上的有界尺度导数、全部编号本征值的严格 min--max 不等式以及
退化谱支的负定一阶矩阵，是由 Suzuki 约化 multiplier 得到的新推论。它们把 prime-free spectral
flow 的方向完全确定，但不排除首次退化。
