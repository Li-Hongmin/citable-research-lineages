> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Signless dyadic correlation gate 足以推出 RH

日期：2026-08-16。

## 命题（充分条件，不声称必要性）

令
\[
 L(X)=\sum_{n\le X}\lambda(n),
\qquad
 D_H(X)=
 \sum_{H\le h<\min(2H,X)}
 \sum_{n\le X-h}\lambda(n)\lambda(n+h),
\]
其中 \(H=1,2,4,\ldots\) 遍历不超过 \(X\) 的 dyadic 尺度。若对每个
\(\varepsilon>0\) 有统一估计
\[
 |D_H(X)|\ll_\varepsilon X^{1+\varepsilon}
\tag{1}
\]
则
\[
 L(X)\ll_\varepsilon X^{1/2+\varepsilon},
\]
从而 RH 成立。

## 证明

展开平方并按正移位分组：
\[
 |L(X)|^2
 =X+2\sum_{h=1}^{X-1}\sum_{n\le X-h}
 \lambda(n)\lambda(n+h)
 =X+2\sum_H D_H(X).
\]
dyadic 块的数量是 \(O(\log X)\)。由 (1)，并把其中的
\(\varepsilon\) 换成更小的值，
\[
 |L(X)|^2\ll_\varepsilon X^{1+\varepsilon},
\]
故 \(L(X)\ll_\varepsilon X^{1/2+\varepsilon}\)。最后使用
Littlewood--Denjoy 判据得到 RH。

## 与 QSLB 的关系

这个 gate 只取 \(\theta_h=1\)、\(y_h=X-h\)，没有 QSLB 中的任意符号和独立最大
部分和。因而它严格弱于 QSLB，却已经足以关闭 RH。这里“更弱”只表示相对于
QSLB 的假设更少；目前没有证明该 signless gate 是 RH 的必要条件，也不能把它
称作 RH 的最小等价形式。

即使把尚未证明的固定移位 Chowla 作为假设，它也不能给出对随 \(X\) 增长的
dyadic 块统一的 \(X^{1+\varepsilon}\) 估计；当前无条件结果更弱，只覆盖平均化或
对数平均的相关。该命题因此把一条可检验的 signless、全块、增长移位充分路线压缩出来；
若只对每个 \(h\) 取绝对值，则会回到 QSLB/AC 的更强门，且会丢失块内的 signed
cancellation。
