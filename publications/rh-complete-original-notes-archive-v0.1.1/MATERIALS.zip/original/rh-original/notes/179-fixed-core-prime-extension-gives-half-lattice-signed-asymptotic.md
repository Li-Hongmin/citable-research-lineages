> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定 squarefree 核上加大素数的半格 signed 渐近

日期：2026-08-15。

本 note 从 [note 171](171-one-sided-detector-half-lattice-boundary-identity.md)
的精确恒等式出发，固定一个 squarefree 核 \(q\)，再加入一个趋于无穷的
素数 \(p\)。结果是：真实 reciprocal 半格项 \(Q_{qp}\) 衰减，而 ordinary
boundary 项 \(G_{qp}\) 稳定为固定的 \(G_q\)。因此完整单侧二次型的极限符号
由 \(G_q\) 决定，不能由 \(P(y)\ge0\) 的逐点信息替代。

本文只证明有限 divisor 格上的精确公式和在已知 \(P(y)=O(y^{-2})\) 条件下的
渐近；不声称 RH。

## 1. 半格稳定化

令 \(q\ge2\) 为固定 squarefree 整数，令 \(p>q\) 为素数且 \(p\nmid q\)，并置

\[
X=qp,
\qquad
L_X=\{d\mid X:d<\sqrt X\}.
\]

若 \(d\mid q\)，则 \(d\le q<\sqrt{qp}\)（因 \(p>q\)），所以 \(d\in L_X\)。
若 \(d=pd_0\) 且 \(d_0\mid q\)，则

\[
(pd_0)^2\ge p^2>qp=X,
\]

故 \(pd_0>\sqrt X\)。因此有逐项恒等式

\[
\boxed{L_{qp}=D(q):=\{d:d\mid q\}.} \tag{1}
\]

特别地，\(L_{2p}=\{1,2\}\) 对所有奇素数 \(p>2\) 都成立。

## 2. \(Q\)-项的显式衰减

沿用 note 171 的定义

\[
Q_X=\sum_{a,b\in L_X}\mu(a)\mu(b)P\!\left(\frac X{ab}\right),
\qquad
G_X=\sum_{a,b\in L_X}\mu(a)\mu(b)g\!\left(\log\frac ab\right),
\]

其中 \(p(t)=P(e^t)\mathbf 1_{t\ge0}\)，\(g(t)=(p(t)+p(-t))/2\)。由 (1)，

\[
\boxed{Q_{qp}=\sum_{a,b\mid q}\mu(a)\mu(b)P\!\left(\frac{qp}{ab}\right),
\qquad G_{qp}=G_q.} \tag{2}
\]

假设 detector periodization 已有（如 note 174 中）

\[
|P(y)|\le C_P y^{-2}\qquad(y\ge1). \tag{3}
\]

则从 (2) 直接得到不使用任何符号抵消的可审计界

\[
|Q_{qp}|
\le C_P q^{-2}p^{-2}\left(\sum_{a\mid q}a^2\right)^2.
\]

即

\[
\boxed{Q_{qp}=O_{P,q}(p^{-2}),\qquad G_{qp}=G_q.} \tag{4}
\]

如果使用更高阶平坦性得到 \(|P(y)|\le C_{P,r}y^{-r}\)，同一证明给出
\[
|Q_{qp}|\le C_{P,r}q^{-r}p^{-r}\left(\sum_{a\mid q}a^r\right)^2. \tag{5}
\]

## 3. 完整单侧二次型的极限

令
\[
H_X=\sum_{a,b\mid X}\mu(a)\mu(b)p\!\left(\log\frac X{ab}\right).
\]

note 171 的精确半格恒等式为
\[
H_X=Q_X+2\mu(X)G_X. \tag{6}
\]

由于 \(p\nmid q\)，
\(\mu(qp)=-\mu(q)\)。结合 (4)，得到

\[
\boxed{H_{qp}=-2\mu(q)G_q+O_{P,q}(p^{-2}).} \tag{7}
\]

因此只要 \(G_q\ne0\)，存在 \(p_0(q,P)\)，使所有素数 \(p>p_0\) 满足

\[
\operatorname{sgn}H_{qp}=-\operatorname{sgn}\bigl(\mu(q)G_q\bigr). \tag{8}
\]

这是一个严格的 signed inequality：它把随 \(p\) 增大的 reciprocal 项与
不衰减的 boundary 项分开，而没有把 \(G_q\) 当作正 Gram。

## 4. \(X=2p\) 与一个素数核心

若 \(q=2\)，则 \(D(q)=\{1,2\}\)，且 \(P(1)=0\) 时

\[
G_2=2\mu(1)\mu(2)g(\log2)=-P(2). \tag{9}
\]

所以

\[
\boxed{H_{2p}=P(2p)-2P(p)+P(p/2)-2P(2),
\qquad H_{2p}\longrightarrow-2P(2).} \tag{10}
\]

对当前正 detector 层级，\(P(2)=V(1/2)>0\)，故极限严格为负。这是
note 174 的 \(X=2p\) 结论的结构性证明。

若 \(q=\ell\) 为任意一个素数，则同理
\[
G_\ell=-P(\ell),\qquad H_{\ell p}\longrightarrow-2P(\ell). \tag{11}
\]
只要 \(P(\ell)>0\)，这给出任意固定 prime edge 的严格负极限。

若 \(q=\ell r\) 是两个不同素数的乘积，令 \(a=\log\ell\)、\(b=\log r\)，
则对 Möbius 符号向量 \((1,-1,-1,1)\) 直接展开得到
\[
\begin{aligned}
G_{\ell r}
&=4g(0)-4g(a)-4g(b)+2g(a+b)+2g(a-b)\\
&=-2P(\ell)-2P(r)+P(\ell r)+P(r/\ell),
\end{aligned} \tag{12}
\]
其中使用了 \(P(1)=0\)、\(\ell<r\) 以及
\(g(\log y)=P(y)/2\)（\(y>1\)）。因此
\[
H_{\ell r p}=-2G_{\ell r}+O_{P,\ell,r}(p^{-2}). \tag{13}
\]
若随后令 \(r\to\infty\)，在同一个 \(P(y)=O(y^{-2})\) 假设下，
\[
G_{\ell r}=-2P(\ell)+O_{P,\ell}(r^{-2}),\qquad
H_{\ell r p}=4P(\ell)+O_{P,\ell}(r^{-2})+O_{P,\ell,r}(p^{-2}). \tag{14}
\]
这与 \(X=\ell p\) 的负极限符号相反，显示增加一个固定的额外 prime
会把 parity 号翻转；该翻转来自完整 \(G_q\)，不是 \(Q_X\) 的小尾项。

## 5. 与 parity/intertwiner 的直接校准

把 \(c_q=(\mu(a))_{a\mid q}\) 视为固定核心的 Möbius mode，则

\[
G_q=c_q^T A_qc_q,
\]

其中 \(A_q=[g(\log(a/b))]_{a,b\mid q}\) 是 even ordinary block。将其嵌入
\(X=qp\) 的完整反射格，note 177 给出

\[
c_{qp}^TH^pc_{qp}
=\mu(qp)c_{qp}^TA_{qp}c_{qp}
=Q_{qp}+2\mu(qp)G_q. \tag{12}
\]

这里的第二项正是固定核心的 parity energy；它不会因新素数 \(p\) 变大而
消失。故任何声称“增大一个 prime 后 reciprocal 边界自动变成正性”的
论证，必须显式支付 \(2\mu(qp)G_q\)，例如由真实 signed Feshbach cross block
抵消；仅控制 \(Q_{qp}\) 的 \(p^{-2}\) 尾部不够。

## 6. 可交给 A 线的最小命题

对于固定 \(q\)，一个足以推进而不要求完整谱 intertwiner 的命题是：给定
真实 archimedean/prime 修正 \(F_{qp}\)，证明其在 parity Möbius mode 上满足

\[
c_{qp}^TF_{qp}c_{qp}
\ge 2\mu(q)G_q-C_{F,q}p^{-2}. \tag{13}
\]

那么由 (7) 可得
\[
c_{qp}^T(H_{qp}+F_{qp})c_{qp}\ge0
\]
对充分大的 \(p\) 成立。

式 (13) 只要求一个标量 quadratic-form matching，但其右侧保留了完整
\(G_q\) 的 signed ordinary Toeplitz 能量；不能以 \(|G_q|\) 或逐 entry 绝对值
替代。这不是 RH 证明，也不说明 (13) 已由现有 true-Schur 数据得到；它是
从 half-lattice identity 到可检验补偿的最薄标量接口。

## 7. 真实单侧块的无界负惯性（直和意义）

假设 (P(1)=0)、(P(2)>0)，并且 (P(y)=O(y^{-2}))。由 (10)，对所有充分大的
奇素数 (p)，完整 (X=2p) divisor 矩阵 (H^p_{2p}) 上的 Möbius 向量
(c_{2p}=(1,-1,-1,1)^T) 满足

\[
c_{2p}^{T}H^p_{2p}c_{2p}
=P(2p)-2P(p)-2P(2)+P(p/2)<-P(2)<0.
\]

因此每个这样的块至少有一个负特征值。取 (k) 个互不相同且充分大的
奇素数 (p_1,\ldots,p_k)，形成直和

\[
\mathcal H_k=H^p_{2p_1}\oplus\cdots\oplus H^p_{2p_k}.
\]

则 (n_-(\mathcal H_k)\ge k)。若 (F_k=F_k^*) 且
(mathcal H_k+F_k\succeq0)，惯性扰动不等式给出

\[
\operatorname{rank}F_k\ge n_-(\mathcal H_k)\ge k.
\]

这排除了在这些真实单侧 reciprocal 块的直和模型上使用固定秩
Feshbach/Schur 修正的可能性；它不声称原始单一 Möbius 总和的算子本身已经
具有同样的直和分解，跨尺度耦合仍是待解决的 arithmetic intertwiner。
