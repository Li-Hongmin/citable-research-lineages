> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cauchy 权重与 Möbius 尾：平方根门等价于 RH 强度

日期：2026-08-15。

本 note 检查一个可能的捷径：先用 Cauchy--Schwarz 处理
\(\sum_{n\le z}\mu(n)/n\)，再用 \(\sum_{n\ge1}\mu(n)/n=0\) 把它改写成尾和，是否能够得到正能量门所需的平方根估计。结论是严格的否定：该权重尾估计与 Mertens 平方根界等价，本身已经是 RH 强度；裸 Cauchy 只给正质量上界，不产生所需的负幂次。

## 1. Abel 恒等式与尾和

记
\[
M(x)=\sum_{n\le x}\mu(n),\qquad
A(x)=\sum_{n\le x}\frac{\mu(n)}n.
\]
部分求和给出
\[
A(x)=\frac{M(x)}x+\int_1^x\frac{M(u)}{u^2}\,du.\tag{1}
\]
PNT 等价于 \(A(\infty)=\sum_{n\ge1}\mu(n)/n=0\)。因此同一个恒等式也写成
\[
A(x)=-\sum_{n>x}\frac{\mu(n)}n
 =\frac{M(x)}x-\int_x^\infty\frac{M(u)}{u^2}\,du.\tag{2}
\]
（边界项按通常的平滑/极限意义理解。）

由 (1)--(2)，对任意固定 \(\varepsilon>0\)，有精确等价
\[
\boxed{
M(x)\ll_\varepsilon x^{1/2+\varepsilon}
\quad\Longleftrightarrow\quad
A(x)\ll_\varepsilon x^{-1/2+\varepsilon}.}
\tag{3}
\]
正向使用 (2)；反向由
\[
M(x)=xA(x)-\int_1^x A(u)\,du
\tag{4}
\]
和部分积分得到。故任何从 \(A(x)\) 尾部得到的 \(x^{-1/2+\varepsilon}\) 估计已经等价于 RH 的经典 Mertens 形式，而不是较弱的中间命题。

## 2. 裸 Cauchy 的严格上限

对任意 \(0<\sigma<1/2\)，正质量 Cauchy--Schwarz 给出
\[
|A(x)|^2
\le
\left(\sum_{n\le x}\frac{\mu(n)^2}{n^{1+2\sigma}}\right)
\left(\sum_{n\le x}\frac{\mu(n)^2}{n^{1-2\sigma}}\right).
\tag{5}
\]
使用平方自由数的初等上界，右端至多
\[
\ll_\sigma (1+\log x)\,x^{2\sigma}.
\tag{6}
\]
这在 \(\sigma\downarrow0\) 时仍是对数级的正质量上界；它既不反映 \(\mu\) 的符号，也不可能推出 (3) 右侧所需的负幂次。将 (5) 作用于尾部时，第二个正质量和在无截断情形发散；加入截断只会把问题转移到尾截断边界，并没有消除 (3) 的 RH-strength 输入。

更直接地，把 \(\mu(n)\) 暂时替换为恒等于 \(1\) 的有界系数，(5) 仍完全成立，而对应的加权和为 \(\sum_{n\le x}1/n\sim\log x\)。所以任何只使用系数绝对值、正质量和 Cauchy--Schwarz 的论证，在逻辑上无法区分 Möbius 符号抵消与“全正”序列；必须额外输入 signed correlation 或等价的零点信息。

## 3. 与截断卷积/余弦门的对应

令 \(z=\sqrt x\)，\(\nu_z(n)=\mu(n)\mathbf 1_{n\le z}\)。对 \(n\le x=z^2\) 有精确卷积恒等式
\[
\mu(n)=2\nu_z(n)-(\nu_z*\nu_z*1)(n).\tag{7}
\]
对紧支撑余弦权 \(W\) 定义 \(U_W(x)=\sum_n\mu(n)W(n/x)\)，则
\[
U_W(x)=2\sum_{a\le z}\mu(a)W(a/x)
-\sum_{a,b\le z}\mu(a)\mu(b)P_W\!\left(\frac{x}{ab}\right),\tag{8}
\]
其中 \(P_W(y)=\sum_{c\le y}W(c/y)\)。Euler--Maclaurin 的零频项
\(P_W(y)=c_Wy+O_W(1)\) 产生
\[
T_0(x)=c_Wx\left(\sum_{a\le\sqrt x}\frac{\mu(a)}a\right)^2.\tag{9}
\]
若要求该项达到 \(O_\varepsilon(x^{1/2+\varepsilon})\)，就必须有
\(A(\sqrt x)\ll_\varepsilon x^{-1/4+\varepsilon}\)，即 (3) 的同一 RH-strength 条件。第一项在 (8) 只有平凡 \(O(\sqrt x)\)，故不能抵消 (9) 的承重门；剩余双线性项若保留符号，其平方根估计与原余弦和的 RH 判据等价。

## 4. 结论

* \(A(x)\) 的负半幂尾界与 \(M(x)\) 平方根界等价，不能作为无条件捷径；
* 裸 Cauchy--Schwarz 的正质量估计至多给对数/正幂上界，不产生 Möbius 符号抵消；
* 截断卷积的零频主项精确暴露该 RH-strength 门，尾部估计若不保留 signed cancellation 不能闭合正能量门。

本文不把 Cauchy 权重或有限数值尾部当作 RH 证明。
