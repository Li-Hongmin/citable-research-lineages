> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Lehmer 尾核门的显式对数评价常数

日期：2026-08-16。

note 346 给出
\[
I_N=\pi\,\boldsymbol\mu_N^T K_N\boldsymbol\mu_N,
\qquad
K_N=L_N-v_Nv_N^T.
\]
由于 \(K_N\) 的第一行和第一列为零，只需限制到指标
\(2,\ldots,N\)。令 \(K_N^{(2)}\) 为该 \((N-1)\times(N-1)\) 主块，
\[
u=(1,\ldots,1)^T\in\mathbb R^{N-1},
\qquad
x=(\mu(2),\ldots,\mu(N))^T.
\]

## 1. 显式三角因子化

由 note 346，
\[
K_N^{(2)}=R^TR,
\qquad
R_{k,n}=\frac{\sqrt{2k+1}}n{\bf1}_{k<n},
\]
其中 \(1\le k\le N-1\)、\(2\le n\le N\)。令
\(y=R^{-T}u\)。方程 \(R^Ty=u\) 等价于
\[
\sum_{k<n}\sqrt{2k+1}\,y_k=n.
\]
故
\[
y_1=\frac2{\sqrt3},
\qquad
y_k=\frac1{\sqrt{2k+1}}\quad(2\le k\le N-1).
\]
从而得到精确评价常数
\[
\boxed{
Q_N:=u^T(K_N^{(2)})^{-1}u
=\frac43+\sum_{k=2}^{N-1}\frac1{2k+1}
\ll\log(2N).}
\tag{1}
\]

## 2. 直接推出 Mertens 界

有限维 Cauchy--Schwarz 给出
\[
|u^Tx|^2
\le (x^TK_N^{(2)}x)\,Q_N
=\frac{I_N}{\pi}\,Q_N.
\tag{2}
\]
而 \(u^Tx=M(N)-1\)，故
\[
\boxed{
|M(N)-1|^2
\le \frac{I_N}{\pi}
\left(\frac43+\sum_{k=2}^{N-1}\frac1{2k+1}\right).}
\tag{3}
\]
因此若对所有 \(N\) 有
\[
I_N\ll_\varepsilon N^{1+\varepsilon},
\]
则吸收对数因子立即得到
\[
M(N)\ll_\varepsilon N^{1/2+\varepsilon},
\]
进而推出 RH。这个反向蕴含不需要素数定理、最大点选择或外函数因子化。

## 3. 与 RH 的双向关系

RH 到 \(I_N\ll_\varepsilon N^{1+\varepsilon}\) 已由 note 342 的
\(A_N\ll_\varepsilon N^{-1/2+\varepsilon}\) 和尾和恒等式证明；反向则由
(1)--(3) 的显式有限维评价常数证明。因此指数外函数模型满足
\[
\boxed{
\mathrm{RH}
\Longleftrightarrow
\forall\varepsilon>0,\quad
\|\mathcal K_{N,o}\|_2\ll_\varepsilon N^{1/2+\varepsilon}.}
\]
该命题把 RH 门化成一个具体 Lehmer 型正半定 Möbius 二次型；剩余困难不是
评价常数，而是无条件证明该二次型达到 \(O(N^{1+\varepsilon})\)。

作为一致性检查，将 note 342 的无条件估计
\(I_N\ll N^2e^{-cL(N)}\) 代入 (3)，只恢复
\[
M(N)\ll N e^{-c' L(N)}(\log N)^{1/2},
\]
即经典零自由区尺度；有限维评价常数本身没有隐藏额外幂次节省。
