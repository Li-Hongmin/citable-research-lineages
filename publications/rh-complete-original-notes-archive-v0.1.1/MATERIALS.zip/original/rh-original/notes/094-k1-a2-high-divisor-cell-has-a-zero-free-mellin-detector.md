> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(k=1\) 的 \(a=2\) 高除数 cell 给出零自由 Mellin detector

日期：2026-08-14。

依赖：[note 074](074-mellin-poles-force-dyadic-mean-shell-growth.md)、
[note 079](079-path-dst-reduces-the-centered-defect-to-sqrtN-low-modes.md)、
[note 084](084-fixed-mode-gram-reduces-to-high-divisor-multiplicative-near-diagonal.md)。

证据等级：解析恒等式 + Arb 计算机辅助零自由定理。

## 1. Cell

对 \(Y<N\le2Y\)、\(Y\ge8\) 置 \(D=Y^{3/4}\)，并在 note 084 的同一
divisor--\(\Delta\) 坐标中取 \(a=2\) cell：

\[
T_N:=\sum_{2N/3<d<N}\mu(d)\log\frac Nd
\left[\frac1d\cot\frac\pi{2N}+\sin\frac{2\pi d}{N}\right].
\tag{1}
\]

这里 \(2N/3<d<N\) 时局部和唯一来自 \(a=2\)，故 (1) 是 exact cell，
不是 product 坐标的截取。

令

\[
F(t):=\log\frac1t\left(\frac2{\pi t}+\sin2\pi t\right)
\mathbf1_{(2/3,1)}(t),
\qquad
U_N:=\sum_{d\ge1}\mu(d)F(d/N),
\tag{2}
\]

\[
V_N:=\sum_{2N/3<d<N}\frac{\mu(d)}d\log\frac Nd,
\qquad
C_N:=\cot\frac\pi{2N}-\frac{2N}{\pi}.
\tag{3}
\]

则逐 \(N\) 有精确分解

\[
\boxed{T_N=U_N+C_NV_N.}
\tag{4}
\]

## 2. Discrete Mellin factorization

定义

\[
K(z):=\int_{2/3}^1F(t)t^{z-1}\,dt.
\tag{5}
\]

**命题 1。** 存在 \(H\) 全纯于 \(\Re s>1\)，使初始在
\(\Re s>2\) 有

\[
\boxed{
\sum_{N\ge1}T_NN^{-s}=\frac{K(s-1)}{\zeta(s-1)}+H(s).
}
\tag{6}
\]

**证明。** 对 \(\sigma>2\)，交换 \(d,N\) 的绝对收敛和，写

\[
\sum_{N\ge1}U_NN^{-s}
=\sum_{d\ge1}\mu(d)\sum_{n\ge1}F(d/n)n^{-s}.
\tag{7}
\]

令

\[
\phi_s(u):=F(1/u)u^{-s}\mathbf1_{(1,3/2)}(u).
\tag{8}
\]

则 \(\phi_s\) 在 \(s\) 的紧集上局部一致为 bounded variation，且

\[
\sum_{n\ge1}F(d/n)n^{-s}
=d^{1-s}K(s-1)+E_d(s),
\tag{9}
\]

\[
E_d(s)=d^{-s}\left(
\sum_{n\ge1}\phi_s(n/d)-d\int_0^\infty\phi_s(u)\,du
\right)
=O_{\rm compact}(d^{-\sigma}).
\tag{10}
\]

故 \(\sum_d\mu(d)E_d(s)\) 全纯于 \(\sigma>1\)。又

\[
C_N=-\frac\pi{6N}+O(N^{-3}),\qquad |V_N|\ll1,
\tag{11}
\]

所以 \(\sum_NC_NV_NN^{-s}\) 全纯于 \(\sigma>0\)。合并即得 (6)。\(\square\)

右端同时给出原 Dirichlet 级数在 \(\Re s>1\) 的同支亚纯延拓；后文的极点论证使用此延拓，
而非把初始的 \(\sigma>2\) 绝对收敛域误当作延拓域。

端点 \(2/3\) 的 jump 只贡献 (10) 中的 BV 求积误差；它不产生额外
\(\zeta\)-分母。

## 3. 零自由性

**定理 2。**

\[
\boxed{K(s)\ne0\qquad\left(\tfrac12\le\Re s\le1\right).}
\tag{12}
\]

令 \(x=\log t\)、\(\alpha=-\log(3/2)\)，则

\[
K(s)=\int_\alpha^0
-x\left(\frac2\pi+e^x\sin(2\pi e^x)\right)e^{(s-1)x}\,dx.
\tag{13}
\]

端点 \(x=0\) 消失而 \(x=\alpha\) 不消失。一次分部积分的主项为

\[
\frac{-f(\alpha)(3/2)^{1-s}}{s-1},
\qquad
|f(\alpha)|=
\log(3/2)\left(\frac2\pi-\frac{\sqrt3}{3}\right)
=0.02403171551356695\ldots.
\tag{14}
\]

十二次 endpoint expansion 与 Arb derivative-\(L^1\) 余项在
\(|s|\ge75\) 给出严格余量

\[
0.02403171551356695\ldots
-0.02384514638670640\ldots
>1.8656912686054\cdot10^{-4}.
\tag{15}
\]

在余下矩形 \(1/2\le\Re s\le1,\ 0\le\Im s\le75\)，ACB 全段像避开
零，辐角原理给 winding \(=0\)；最小 segment modulus 下界为

\[
8.6171033986810568\cdot10^{-5}.
\tag{16}
\]

共轭对称补全下半平面。完整 source、输出和重放命令见
[proof bundle](../computations/bundles/k1-a2-mellin-zero-free/README.md)。

## 4. 结论与边界

若 \(\zeta(\rho)=0\)、\(\Re\rho>1/2\)，且重数为 \(q\)，则 (6)、(12)
使 \(\sum_NT_NN^{-s}\) 在 \(s=\rho+1\) 有 \(q\) 阶极点。离散版
note 074 的 Cauchy--dyadic 论证于是给

\[
\boxed{
\limsup_{Y\to\infty}
\frac{\sum_{Y<N\le2Y}|T_N|^2}
{Y^{2\Re\rho+1}(\log Y)^{2q-2}}>0.
}
\tag{17}
\]

因而得到一个单 cell 的 RH 等价式：

\[
\boxed{
\mathrm{RH}
\iff
\forall\varepsilon>0,\quad
\sum_{Y<N\le2Y}|T_N|^2\ll_\varepsilon Y^{2+\varepsilon}.
}
\tag{18}
\]

反向蕴含由 (17)。正向蕴含中，RH 的经典等价式
\(M(x)=O_\delta(x^{1/2+\delta})\) 与 (2) 的分部求和给

\[
U_N=O_\delta(N^{1/2+\delta}),\qquad C_NV_N=O(N^{-1}),
\tag{19}
\]

从而 \(T_N=O_\delta(N^{1/2+\delta})\)，对 dyadic shell 求和即得 (18)。

(18) 仍不是无条件估计：它只把 RH 归约为一个比完整 high-divisor Gram 更窄的
Möbius 加权二次均值。它**不**证明该均方，也不控制完整
\(H_{N,1}^{>Y^{3/4}}\) 的其它 cofactor cell 或其 signed covariance。故本 note
不证明 RH；它把 \(k=1\) 首个 surviving cell 从“可能有 Mellin null”严格提升为
“所有离线零均可见”。

截至 2026-08-14 的定向检索覆盖 Davenport 的 Möbius--sawtooth 公式、
Burnol 的 Nyman--Beurling/Möbius 加权残量与当前可检索的离散 Laplace--Möbius
判据；未发现直接包含 (6)、(12) 或其均方结论的既有定理。这个结果标作项目内新命题，
投稿前仍须作更广的新颖性核验。
