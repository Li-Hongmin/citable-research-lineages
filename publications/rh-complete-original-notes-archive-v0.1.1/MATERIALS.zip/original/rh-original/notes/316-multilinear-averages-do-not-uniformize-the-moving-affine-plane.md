> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 多线性乘法平均定理不能统一化当前移动仿射平面

日期：2026-08-16。

## 1. 看似相同的二维系统

note 315 的三点项可以写成
\[
T_{U,Q}
=\sum_{\substack{U<x<2U\\1\le q\le Q}}
\lambda(x)\lambda(q+C)\lambda(x+q),
\qquad C=2U-1.
\tag{1}
\]
因此形式上对应于二维仿射线性系统
\[
L_1(x,q)=x,\qquad L_2(x,q)=q+C,\qquad
L_3(x,q)=x+q.
\tag{2}
\]

## 2. 现有多线性定理的两个不匹配

Klurman--Mangerel 的有效多线性平均定理（
<https://arxiv.org/abs/1708.03176>）要求 primitive integral system 的
高度由一个固定参数控制；其主定理是在尺度趋于无穷而系统固定时给出
盒平均的渐近。Frantzikinakis--Host 的二维多线性结果（
<https://arxiv.org/abs/1502.02646>）同样是固定线性系统的渐近框架。

系统 (2) 不满足可直接用于本项目的统一版本：

1. \(L_2\) 的常数项 \(C=2U-1\) 与盒尺度同时增长。把变量平移到
   从 \(1\) 开始的盒后，线性形式的高度仍为 \(O(U)\)，不是固定高度；
2. 若只把 \(q\) 视为平均参数，则 \(q+C\) 与 \(q\) 的线性部分完全相同，
   是一条平行的移位切片，而不是独立移位系统。正是这条切片保留了
   \(\lambda(q+C)\) 的权，不能由对独立移位取绝对值的 MRT 定理恢复；
3. 现有定理的渐近 \(o(1)\) 也没有给出本项目要求的
   \(U^{1+\varepsilon}\) 级定量界，更不能把随 \(U\) 变化的常数项吸收到
   隐含常数中。

因此，不能引用一般“二维 affine multilinear average”来闭合 (1)。
要得到端点望远镜所需的界，至少需要一个对移动常数
\(C\asymp U\) 统一、并保留平行切片权 \(\lambda(q+C)\) 符号的定量三点估计。
这正是 note 315 所称的二维 affine-Chowla/arithmetic-intertwiner 门，
而不是现有固定系统平均定理的直接推论。

