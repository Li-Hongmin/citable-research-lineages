> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Reciprocal-product Hankel 核的精确反射 Gram 表示

日期：2026-08-15。

本 note 给出一个连续层面的精确 intertwiner：\(ab\)-型 reciprocal-product
核可以表示为 Fourier 乘法算子与 log-reflection 的 \(J\)-Gram。它解释了
为什么 local Weil 算子与该核结构相容，也同时说明普通 Hilbert PSD
Gram 不能替代 \(J\)-正性。

## 1. 精确恒等式

令 \(p(u)\) 是实值、足够衰减的 log-kernel，内积取第二变量线性，并采用
\[
p(u)=\frac1{2\pi}\int_{\mathbb R}\widehat p(\xi)e^{i\xi u}\,d\xi .
\]
固定 \(x>0\)，对 \(a>0\) 定义 Fourier 向量
\[
\phi_{a,x}(\xi)=\left(\frac a{\sqrt x}\right)^{i\xi},
\qquad
(Jf)(\xi)=f(-\xi).
\]
这里的 \(\phi_{a,x}\) 是 Fourier 广义向量而非 \(L^2(\mathbb R)\) 元素；
当 \(\widehat p\in L^1\) 时下式按绝对收敛积分解释，或一般按 tempered
distribution 配对解释。
则 \(J=J^*=J^{-1}\)，并且
\[
\begin{aligned}
\left\langle \phi_{a,x},\,M_{\widehat p}J\phi_{b,x}\right\rangle
&=\frac1{2\pi}\int_{\mathbb R}\widehat p(\xi)
\left(\frac a{\sqrt x}\right)^{-i\xi}
\left(\frac b{\sqrt x}\right)^{-i\xi}\,d\xi\\
&=p\!\left(\log\frac x{ab}\right).
\end{aligned}
\tag{1}
\]
这里 \(M_{\widehat p}\) 是 Fourier 乘法算子。于是
\[
\boxed{
P\!\left(\frac x{ab}\right)
=\left\langle \phi_{a,x},\,M_{\widehat p}J\phi_{b,x}\right\rangle.}
\tag{2}
\]

对任意有限系数 \(c_a\)，令
\[
\Phi_c=\sum_a c_a\phi_{a,x}.
\]
则原 reciprocal-product 二次型精确为
\[
\sum_{a,b}c_ac_bP\!\left(\frac x{ab}\right)
=\left\langle \Phi_c,M_{\widehat p}J\Phi_c\right\rangle,
\tag{3}
\]
（实系数情形；复系数时应保留相应的双线性配对）。

## 2. 与普通 PSD Gram 的区别

即使在 \(\widehat p\) 为实偶且 \(\widehat p\ge0\) 的特殊情形，
\(M_{\widehat p}\succeq0\) 也不能推出
\(M_{\widehat p}J\succeq0\)：反射 \(J\) 有无限维的 \(+1\) 与 \(-1\)
子空间。式 (3) 的正确对象是 \(J\)-正性/Krein 型二次型，而不是
\(\|\cdot\|^2\)。

若进一步假设 \(\widehat p\) 实偶且非负，则 \(M_{\widehat p}\) 与 \(J\) 交换，
并可写成
\[
\left\langle f,M_{\widehat p}Jf\right\rangle
=\left\|M_{\widehat p}^{1/2}P_+f\right\|_2^2
-\left\|M_{\widehat p}^{1/2}P_-f\right\|_2^2,
\qquad P_\pm=\frac{I\pm J}{2}.
\tag{4}
\]
所以在这种最有利的符号情形，所需的算术命题也不是普通 PSD，而是
Möbius 生成子空间上的 uniform even-dominance。对
\(\phi_{a,x}\) 而言，\(J\) 把尺度 \(a/\sqrt{x}\) 反射为
\(\sqrt{x}/a\)，即 \(a\mapsto x/a\)；正整数采样集一般不在这个变换下闭合。
这正是 common-scale/divisor 基底失配的连续 Fourier 版本。

项目中的 V15 \(x=4\) 有严格有限见证
\[
\det\!\left[P_{15}\!\left(\frac4{ab}\right)\right]_{a,b\in\{2,3\}}
=-\left(\frac{473}{16384}\right)^2<0,
\]
所以保持 \(ab\)-采样的普通 PSD Gram 化不可能。这个负子式并不否定
\(M_{\widehat p}J\) 的精确表示；它只说明 \(J\)-符号不能被丢掉。

## 3. 对 Weil/RH 路线的含义

式 (2) 是 reciprocal-product 与 local Weil Fourier/reflection 语言之间的
最薄对象级识别：

\[
\text{reciprocal Hankel}
\quad\longleftrightarrow\quad
M_{\widehat p}J.
\]

因此 A 的局部 Weil 算子在形式结构上已经是正确候选；未解决的不是再找一个
普通 PSD intertwiner，而是证明包含 Möbius 向量的算术子空间上
\[
\left\langle \Phi_\mu,M_{\widehat p}J\Phi_\mu\right\rangle\ge0
\]
或得到足够强的 signed 上界。对所有尺度的这种 \(J\)-正性正是 Weil
判据的 RH-strength 内容；局部压缩正性、有限 rank-one Yukawa 增益及
Toeplitz 自相关都不能自动替代它。

本文只建立精确反射 Gram 恒等式，不声称 RH 已被证明。
