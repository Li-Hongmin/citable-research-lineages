> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 增长移位的 additive-Fourier 低频门

日期：2026-08-16。

本 note 给出一个与 Mellin 分解互补的精确恒等式。它说明平滑差值窗口在
\(H\asymp X\) 时只探测 Liouville Fourier 多项式的 \(O(X^{-1})\) 低频区；
因此一般 large-sieve/正 Gram 论证不能自动产生
\(O(X^{1+\varepsilon})\) 的增长移位界。

## 1. 精确 Fourier 恒等式

令 \(\phi\in C_c^\infty((0,1+\eta))\) 为实值截断，令
\(\psi\in C_c^\infty(\mathbb R)\) 为实值差值权。取 Fourier 约定
\[
\psi(x)=\frac1{2\pi}\int_{\mathbb R}\widehat\psi(t)e^{itx}\,dt.
\]
定义
\[
S_{\psi,H}(X)
=\sum_{n,m\ge1}\lambda(n)\lambda(m)
\phi(n/X)\phi(m/X)\psi\!\left(\frac{m-n}{H}\right).
\]
有限和与积分交换，得到严格恒等式
\[
\boxed{
S_{\psi,H}(X)
=\frac1{2\pi}\int_{\mathbb R}\widehat\psi(t)
\left|A_X(t/H)\right|^2\,dt,
}
\tag{1}
\]
其中
\[
A_X(\theta)=\sum_{n\ge1}\lambda(n)\phi(n/X)e^{i\theta n}.
\]

## 2. 增长移位只看到低频

当 \(H=\alpha X\) 且 \(\alpha\asymp1\) 时，固定频带满足
\(\theta=t/H=O(X^{-1})\)。特别地，
\[
A_X(0)=\sum_n\lambda(n)\phi(n/X),
\]
且
\[
|A_X(t/H)-A_X(0)|
\le \frac{|t|}{H}\sum_n n|\phi(n/X)|
\ll_\phi |t|X/H.
\tag{2}
\]
因此 \(H\asymp X\) 时，\(A_X(t/H)\) 是 \(A_X(0)\) 的有界扰动；
若 \(\widehat\psi\) 在零频附近有非零质量，平方根级差值块估计必然
处理 \(\left|\sum_n\lambda(n)\phi(n/X)\right|^2\)，这正是
RH-strength 的 Liouville/Mertens 门。

## 3. 正 Fourier 权也不能软化算术门

若额外假设 \(\widehat\psi\ge0\)，(1) 是正 Gram 能量，但正定性只给
\(S_{\psi,H}(X)\ge0\)。对一般向量 \(b_n\equiv1\)，在含零频区间
\(\widehat\psi(t)\ge c>0\) 时，Riemann 和给出相应 Gram 算子范数
\(\gg X\)，一般向量能量可达 \(\gg X^2\)。因此正定性本身不提供
\(X^{1+\varepsilon}\) 算术上界；对实际 \(\lambda\) 向量所需的额外估计
仍是 signed low-frequency cancellation。

## 4. 与 dyadic gate 的关系

把 \(\psi\) 取为平滑近似 \(\mathbf1_{[1,2]}\)，
\(S_{\psi,H}(X)\) 就是 dyadic 相关块的平滑版本。现有 averaged-Chowla
估计先对移位取绝对值，不能给出 pre-absolute-value 的低频 bound；
经典零自由区只产生 \(X^{2-o(1)}\) 级估计。

结论：差值 Fourier 恒等式没有绕过 RH 门，但把其最小形态明确为
\[
\boxed{
\int_{|t|\le T}\left|A_X(t/X)\right|^2\,dt
\ll_\varepsilon X^{1+\varepsilon}
}
\]
（固定 \(T>0\) 的适当平滑版本）。任何真正闭合 RH 的新路线必须证明
这一类 Liouville-specific 低频 signed estimate，或构造保留其相位的
arithmetic intertwiner。
