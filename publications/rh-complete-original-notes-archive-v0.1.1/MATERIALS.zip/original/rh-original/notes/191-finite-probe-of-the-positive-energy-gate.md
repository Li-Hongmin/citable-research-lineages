> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有限频窗下的 \(\lvert h\rvert\)-正能量门：诊断性探针

对 note 190 的半格 Schur 门，令
\[
h(\xi)=\operatorname{Re}\{\zeta(i\xi)K_{15}(i\xi)\},\qquad
E_z=\frac1{2\pi}\int_{\mathbb R}|h(\xi)|
\left|\sum_{n\le z}\mu(n)n^{i\xi}\right|^2\,d\xi .
\]
这里的 \(E_z\) 只是正权能量诊断；它不是原始 reciprocal Hankel
二次型，也没有包含不整除给定 \(X\) 的 common-scale completion。

probe_v15_positive_energy_gate.py 在有限频窗
\([-160,160]\)、8192 个等距点和 30 位工作精度下实际运行得到的
\(\lvert h\rvert\) 积分为
\(0.128853505399\)，表中数值为：

| \(z\) | \(E_z\) | \(E_z/z\) |
|---:|---:|---:|
| 20 | 0.120721984392 | 0.00603609921958 |
| 40 | 0.176196554000 | 0.00440491384999 |
| 80 | 0.189282566548 | 0.00236603208185 |
| 120 | 0.144572925937 | 0.00120477438281 |
| 200 | 0.953852572760 | 0.00476926286380 |
| 300 | 0.420105263623 | 0.00140035087874 |
| 400 | 0.381301271832 | 0.00095325317958 |
| 600 | 1.20902338795 | 0.00201503897991 |
| 800 | 0.568300482459 | 0.000710375603074 |
| 1000 | 0.760121226762 | 0.000760121226762 |

这些数值只说明在该有限窗口中正能量很小；它们没有给出尾部界、
\(z\to\infty\) 一致性，也不能推出 RH。真正未解决的承重命题仍是：
把 note 190 的 \(\lvert h\rvert\)-正能量门取得足以跨过
\(\Re s=1/2\) 的全整数统一估计。

补充复核：将上限增至 \(z=5000\)，频率网格取 4096 点（同一
\([-160,160]\) 窗口），得到
\[
E_{2000}=2.02309028026,\quad
E_{3000}=1.91367426587,\quad
E_{4000}=2.92122613310,\quad
E_{5000}=2.14699455135.
\]
对应 \(E_z/z\) 分别为
\(1.0115,\,0.6379,\,0.7303,\,0.4294\times10^{-3}\)。
这只是有限窗数值，且与 8192 点结果一样不控制频率尾部；
它不能被外推为 \(E_z=O(z^\varepsilon)\) 或任何 RH 结论。
