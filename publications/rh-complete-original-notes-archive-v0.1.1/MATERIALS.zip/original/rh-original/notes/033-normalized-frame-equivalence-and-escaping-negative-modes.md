> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Normalized frame 条件、负谱底与逃逸负模态

日期：2026-08-11。

本文判定 note 024 的统一 Robin-frame 条件究竟比极限正性多要求了什么。结论是：在项目实际的
scalar base 渐近下，frame 余量与 Yukawa 下模型的负谱底渐近相等；但形式单调收敛和极限算子的
紧预解式都不能阻止负方向逃向高频。因而 A3 的真正剩余命题不是普通 frame cancellation，而是
负谱子的 collective compactness。

## 1. Normalized physical Schur

固定一个奇偶扇区，省略指标。令

\[
B_M=E_M-W_MW_M^*,\qquad E_M>0,
\]

其中 (E_M) 有界且有界可逆，并定义

\[
\widetilde S_M=E_M^{-1/2}B_ME_M^{-1/2}.
\]

若 (alpha_M\to\infty) 且

\[
C_M:=\frac{E_M}{\alpha_M}\longrightarrow I
\quad\text{in operator norm},
\tag{1}
\]

则在闭形式意义下有精确 congruence

\[
\boxed{
\alpha_M\widetilde S_M=C_M^{-1/2}B_MC_M^{-1/2}.}
\tag{2}
\]

这里

\[
D(q_{\widetilde S_M})
=\{f:E_M^{-1/2}f\in D(q_{B_M})\},
\qquad
q_{\widetilde S_M}[f]=q_{B_M}[E_M^{-1/2}f].
\]

式 (2) 是形式合同，不是酉等价。

## 2. Frame 余量等价于下模型负谱底

记

\[
\varepsilon_M=(-\inf\sigma(B_M))_+,
\qquad
\eta_M=(-\inf\sigma(\widetilde S_M))_+.
\]

由广义 Rayleigh 商可得

\[
\boxed{
\varepsilon_M
\le \eta_M\|E_M\|
\le \kappa(E_M)\varepsilon_M,}
\qquad
\kappa(E_M)=\frac{\|E_M\|}{\lambda_{\min}(E_M)}.
\tag{3}
\]

事实上，

\[
\eta_M
=\sup_{f\ne0}
\frac{(-q_{B_M}[f])_+}{\langle E_Mf,f\rangle}.
\]

由 (1)，

\[
\kappa(E_M)\to1.
\]

故 note 024 的 frame 条件严格等价于

\[
\boxed{
\eta_M\|E_M\|\to0
\iff
(-\inf\sigma(B_M))_+\to0.}
\tag{4}
\]

## 3. 单向蕴含与最小反例

若 \(B_M\uparrow A\) 于闭形式意义且 \(\varepsilon_M\to0\)，则对极限形式域中的任意 \(f\)，

\[
q_A[f]=\sup_Mq_{B_M}[f]\ge0.
\]

所以 (4) 足以推出 (A\succeq0)。反向即使 (A) 有紧预解式也不成立。

在 (ell^2(\mathbb N)) 上令

\[
Ae_n=ne_n,
\]

并定义有界自伴算子

\[
B_Me_n=
\begin{cases}
ne_n,&n\le M,\\
-e_n,&n>M.
\end{cases}
\tag{5}
\]

则 (A>0) 且有紧预解式，(B_M\uparrow A) 于形式及强预解式意义，但

\[
\inf\sigma(B_M)=-1
\qquad\forall M.
\tag{6}
\]

取

\[
\alpha_M=M+1,
\qquad E_M=\alpha_MI,
\qquad W_MW_M^*=E_M-B_M\succeq0,
\]

则 (E_M/\alpha_M=I) 精确成立，而 (eta_M\|E_M\|=1)。负方向 (e_{M+1}) 逃向无穷
高频。这证明

\[
\boxed{
A\succeq0\ \text{且}\ A\ \text{有紧预解式}
\not\Longrightarrow (4).}
\tag{7}
\]

## 4. (L^2)-范数接近不足以传递无界形式极限

即使 (C_M\to I) 于算子范数，也不能仅由 (2) 推出
(alpha_M\widetilde S_M\to A)。令 (U_M) 在
(operatorname{span}\{e_1,e_M\}) 上交换两个基向量，并取

\[
C_M=I+M^{-1/2}U_M.
\]

则 (C_M\to I) 于 (L^2)-算子范数，但 (C_M^{-1/2}e_1) 含有
(O(M^{-1/2})e_M) 分量。对 (Ae_M=Me_M)，这个小旋转产生 (O(1)) 的形式能量变化。
因此还需要共同控制形式 (q_G) 下的 graph-norm compatibility，例如

\[
\|C_M^{-1/2}-I\|_{D(q_G)\to D(q_G)}\to0.
\tag{8}
\]

## 5. 正确替代：负方向 collective compactness

令

\[
P_R={\bf1}_{(-\infty,R]}(A).
\]

为了从 \(A\succeq0\) 反推 \(\varepsilon_M\to0\)，必须排除 (5) 中的高频逃逸。一个直接的
充分接口是

\[
\boxed{
\lim_{R\to\infty}
\sup_{M\ge M(R)}
\sup_{\substack{\|f\|=1\\q_{B_M}[f]<0}}
\|(I-P_R)f\|=0,}
\tag{9}
\]

再配合统一下半界和极限形式的局部连续性。式 (9) 使所有潜在负方向相对于 (A) 的谱分解一致
紧，从而禁止负谱底藏在随 (M) 外移的通道。

## 6. 路线结论

1. 统一 frame 余量与 (B_M) 的负谱底消失严格等价；它不是一个更便宜的独立正性机制。
2. (B_M\uparrow A)、(A\succeq0) 及紧预解式不足以闭合反向蕴含。
3. 仅有 (E_M/\alpha_M\to I) 的 (L^2)-范数收敛也不足以传递无界形式极限。
4. A3 的最小正确目标应改为 (9) 的 collective compactness，或一个直接蕴含 (9) 的统一高频
   coercivity/泄漏不等式。

因此，不应继续把固定维 frame 矩阵的数值趋近当作全尺度正性的证据；真正承重的是负方向能否
逃向 Robin 高频。
