> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 430. 2026 年两条 Möbius 新路线与本项目算术门的关系

## 1. 离散 Laplace 变换

Liflandsky 的 arXiv:2607.09797（v3，2026-07-25）研究
\[
\Phi(e^{-t})=\sum_{n\ge1}\mu(n)e^{-nt}
\]
的显式公式。摘要明确区分了两个方向：变换的
\(O(x^{-1/2})\) 界可无条件推出 RH，而反向蕴含还需要关于零点的附加假设。
因此它提供的是一个新的 RH 判据/显式公式，不是平方根界本身，也没有给出本项目
按 \(\log(m/n)\) 加权的 Möbius 二次能量估计。

## 2. 临界尺度局部 Fourier 矩

Verjovsky 的 arXiv:2607.25002（2026-07-27）定义
\[
P_N(t)=N^{-1/2}\sum_{n\le N}\mu(n)e^{2\pi int},
\]
并证明 RH 等价于任意高阶、临界弧半径 \(c/N\) 上局部矩的次多项式增长。
其局部 moment-to-point-value 不等式把 \(P_N(0)=M(N)/\sqrt N\) 重新取回；
这仍是 RH 的临界尺度等价形式，未给出无条件的局部矩上界。

## 3. 对当前路线的裁决

上述两篇工作都没有提供以下缺失输入：
\[
\sum_{m,n\le N}\mu(m)\mu(n)\,K(\log(m/n))
\ll N^{1+\varepsilon}
\]
或等价的固定乘法比率 signed intertwiner。因而它们不能替代 notes 410、418、420
所识别的一阶 Möbius 能量门；后续应继续寻找新的跨尺度算术消去，而不是把这些
等价判据误作证明。

来源：

- <https://arxiv.org/abs/2607.09797>
- <https://arxiv.org/abs/2607.25002>
