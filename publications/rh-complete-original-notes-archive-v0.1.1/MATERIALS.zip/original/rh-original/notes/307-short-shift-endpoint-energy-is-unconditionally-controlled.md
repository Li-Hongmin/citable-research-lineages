> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 极短移位的端点均方门可由 averaged-Chowla 闭合

日期：2026-08-16。

本 note 补充 note 306 的中程端点门。记
\[
C_h^{\rm end}(X)=\sum_{n\le X-h}f(n)f(n+h),\qquad |f(n)|\le1,
\]
以及
\[
\mathcal E_f(X,H)=\sum_{H<h\le2H}|C_h^{\rm end}(X)|^2.
\]
目标门是
\[
\mathcal E_f(X,H)\ll_{\varepsilon}X^{2+\varepsilon}H^{-1}.
\tag{1}
\]

## 1. 端点统一与尾项

令 \(Y=X-2H\)，并假设 \(2H\le X\)。对 \(H<h\le2H\)，有
\[
C_h^{\rm end}(X)=\sum_{n\le Y}f(n)f(n+h)+R_h,
\qquad |R_h|\le 2H.
\]
因此
\[
\sum_{H<h\le2H}|C_h^{\rm end}(X)|
\le \sum_{H<h\le2H}\left|\sum_{n\le Y}f(n)f(n+h)\right|+O(H^2).
\tag{2}
\]
这一步是必要的：MRT 型 averaged-Chowla 定理的端点是同一个 \(Y\)，不能
直接把 \(Y=X-h\) 当作随 \(h\) 变化的定理参数。

## 2. 已知平均输入给出的范围

对 \(f=\lambda\)，Matomäki--Radziwiłł--Tao 的 averaged-Chowla 定理给出
（并说明同一框架适用于 \(\mu\)）
\[
\sum_{1\le h\le L}
\left|\sum_{n\le Y}f(n)f(n+h)\right|
\ll YL\,\rho_X(H),
\qquad 10\le L\le Y,
\tag{3}
\]
其中可取
\[
\rho_X(H):=\frac{\log\log(3H)}{\log(3H)}
          +\frac1{\log^{1/3000}(3X)}.
\]
用 \(L=2H\) 代入 (2)，并在 \(H\le Y\rho_X(H)\) 时吸收 \(H^2\) 尾项，得到
\[
\sum_{H<h\le2H}|C_h^{\rm end}(X)|
\ll XH\rho_X(H).
\tag{4}
\]
因为 \(|C_h^{\rm end}(X)|\le X\)，一次 Cauchy（更准确地说
\(|z|^2\le X|z|\)）给出
\[
\boxed{
\mathcal E_f(X,H)\ll X^2H\rho_X(H)
}
\tag{5}
\]
在上述范围内。对 \(H<10\)，平凡界
\(\mathcal E_f(X,H)\le HX^2\) 足够处理固定的有限个移位。

于是目标 (1) 已在所有满足
\[
H^2\rho_X(H)\le X^{\varepsilon}
\tag{6}
\]
的极短区间成立；例如对任意固定 \(\varepsilon>0\)，它至少覆盖
\[
H\le X^{\varepsilon/2}\rho_X(H)^{-1/2}
\]
（对足够大的 \(X\)，该范围自动满足 \(H\le X\rho_X(H)\)）。

## 3. 尚未关闭的范围

式 (5) 在宏观 \(H\) 上只有
\(X^{2-o(1)}\) 量级，不能替代 (1)。因此当前端点平方恒等式的精确剩余门是
\[
X^{\varepsilon/2}\rho_X(H)^{-1/2}\ll H\le X^{1-\eta},
\]
其中终端 \(H>X^{1-\eta}\) 已由 note 306 的
\(\sum_{t<X^\eta}t\ll X^{2\eta}\) 平凡处理。

结论仅是一个严格的局部推进：averaged-Chowla 消除了极短移位区间，
但没有触及中程的四点 signed 均方门；不得将 (5) 外推为平方根级估计或 RH 证明。

来源：Matomäki--Radziwiłł--Tao, *An averaged form of Chowla's conjecture*,
arXiv:1503.05121, Theorem 1.1/1.6；其摘要明确给出对 Liouville 的移位平均，
正文说明可推广到 Möbius。
