> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 次数十五正 detector 在 \(x=4\) 的精确负 Möbius 块

日期：2026-08-15。

依赖：[note 144](144-a-positive-degree-fifteen-detector-removes-four-collective-residues.md)、
[note 148](148-all-positive-detector-layers-retain-a-fixed-indefinite-two-by-two-block.md)、
[note 155](155-fixed-detector-signed-mobius-gate-and-growing-m-sensitivity.md)。

本文给出一个完全有理的有限反例：即使次数十五 detector 的
periodization \(P_{15}(y)\) 在 \(y\ge1\) 逐点非负，完整 reciprocal-product
核仍可在实际 Möbius 向量上取负值。因此逐项正性不能升级为 PSD Gram 或正
Schur 补。本文不声称 RH。

## 1. Detector 与三个精确值

取 note 144 的次数十五 detector
\[
V_{15}(u)=u^2(1-u)^9
\bigl(-3-27u-57u^2+207u^3+1024u^4\bigr),
\qquad 0<u<1,
\]
以及
\[
P_{15}(y)=\sum_{c\le y}V_{15}(c/y).
\]
直接有理求和得到
\[
\boxed{
P_{15}(1)=0,\qquad
P_{15}(2)=\frac{473}{16384},\qquad
P_{15}(4)=\frac{149005}{134217728}.}
\tag{1}
\]
这些值与 note 144 的全半轴非负性证书一致；此处只使用三个有限值。

记
\[
U_{V_{15}}(x)=\sum_n\mu(n)V_{15}(n/x),\qquad
T_{V_{15}}(x)=\sum_{a,b\le\sqrt{x}}\mu(a)\mu(b)
P_{15}\!\left(\frac{x}{ab}\right).
\]
由于 \(V_{15}(u)=O(u^2)\) 且 \(|\mu(n)|\le1\)，截断项还满足
\[
\sum_{n\le\sqrt{x}}\mu(n)V_{15}(n/x)=O(x^{-1/2}),
\]
所以该层的完整双和有精确尺度转移
\[
T_{V_{15}}(x)=-U_{V_{15}}(x)+O(x^{-1/2}).
\]
这是一条无条件的 transfer 估计，但并不降低后续 \(U_{V_{15}}\) 的 RH 强度。

## 2. \(2\times2\) 主子式与实际 Möbius 方向

令 \(x=4\)，指标为 \(a,b\le\sqrt{x}=2\)，并定义
\[
K_4(a,b)=P_{15}\!\left(\frac4{ab}\right).
\]
在顺序 \((1,2)\) 下，
\[
\boxed{
K_4=
\begin{pmatrix}
\dfrac{149005}{134217728}&\dfrac{473}{16384}\\[4pt]
\dfrac{473}{16384}&0
\end{pmatrix}.}
\tag{2}
\]
故
\[
\boxed{\det K_4
=-\left(\frac{473}{16384}\right)^2<0.}
\tag{3}
\]
负方向并非抽象系数向量：实际 Möbius 截断向量为
\[
\mu_{\le2}=(\mu(1),\mu(2))=(1,-1),
\]
于是
\[
\boxed{
\mu_{\le2}^{\mathsf T}K_4\mu_{\le2}
=P_{15}(4)-2P_{15}(2)+P_{15}(1)
=-\frac{7600627}{134217728}<0.}
\tag{4}
\]

## 3. 路线边界

式 (1) 的逐点正性只说明 \(K_4\) 的 entrywise 非负，式 (3) 说明它不是
正半定矩阵，式 (4) 更说明实际 Möbius 向量也没有固定正号。因而以下推理在
第一次有限尺度就被严格关闭：
\[
\text{entrywise }P_{15}\ge0
\Longrightarrow
\text{PSD reciprocal Gram}
\Longrightarrow
\text{正 Schur 尾}.
\]
次数增加、消去更多 Mellin residues 或单独控制正 detector 尾，都不能绕过
这个 signed block；剩余问题仍是保留 \(\mu(a)\mu(b)\) 符号的双线性估计。

这并不排除有限维的 Kreĭn 因子化
\(K_4=L^\ast\operatorname{diag}(1,-1)L\)。但这类因子化保留了负方向，
不能提供正 Schur 尾；沿 squarefree primorial，负惯性至少为
\(m-2\asymp\log x/\log\log x\)，所以任何全局 Kreĭn/非正 Gram 方案都必须
处理增长的负签名，并对实际 Möbius 向量的正负投影给出新的算术估计。
这只是一个有限维 no-go，不是对任意非正 Gram/Feshbach 变换的普遍不可能性，
也不是 RH 的证明。
