> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 对数 Mellin 试验函数的稠密性与固定算子修正的进一步 no-go

日期：2026-08-16。

本 note 把 note 268 的无限维负指标障碍连接到实际使用的 Mellin 试验函数
\(e^{i\xi\log n}\)。结论只针对“同一个有限秩算子修正对所有截断试验空间均
成立”的算子级主张；它不等价于对一个固定 Möbius 向量的二次型给出下界或上界。

## 1. 稠密性

令 \(I\subset\mathbb R\) 为有界非退化区间，并记
\[
 V_N=\operatorname{span}\{e^{i\xi\log n}:1\le n\le N\}
 \subset L^2(I).
\]
则
\[
 \overline{\bigcup_{N\ge1}V_N}=L^2(I).
\tag{1}
\]

证明如下。若 \(f\in L^2(I)\) 与所有这些指数函数正交，则因 \(I\) 有限，
\(f\in L^1(I)\)，其 Fourier--Laplace 变换
\[
 F(z)=\int_I f(\xi)e^{-iz\xi}\,d\xi
\]
是有限指数型整函数，并满足
\[
 F(\log n)=0\qquad(n=1,2,\ldots).
\tag{2}
\]
这里的正交关系正好给出 (2)，因为测试函数的共轭为
\(e^{-i\xi\log n}\)。

若 \(F\not\equiv0\)，取一点 \(z_0\) 使 \(F(z_0)\ne0\)。由于 \(I\) 有界，存在
常数 \(A,C\) 使
\[
 |F(z)|\le C e^{A|z|}\qquad(z\in\mathbb C).
\]
对以 \(z_0\) 为中心的圆盘应用 Jensen 公式：半径为 \(2R\) 的圆周上
\(\log|F|\le O(R)\)，因此圆盘半径 \(R\) 内的零点数满足
\[
 N_F(R)=O_F(R).
\tag{3}
\]
若 \(F(0)=0\)，先除去零点的有限阶因子即可；若圆盘中心不在原点，只改变
常数。另一方面，(2) 中满足 \(0\le\log n\le R/2\) 的零点个数为
\(\lfloor e^{R/2}\rfloor\)，而这些零点在以固定 \(z_0\) 为中心、半径 \(R\)
的圆盘内。它与 (3) 矛盾。故 \(F\equiv0\)，再由紧支撑 Fourier 变换的唯一性
得 \(f=0\)。这证明了 (1)。

因此这里使用的只是有限指数型 Fourier--Laplace 变换的直接 Jensen 估计，
没有把一般整函数的零点计数误用于本问题。

## 2. 固定有限秩修正不可能在所有 Mellin 试验空间上正化非对角壳

取 note 268 中一个非零非对角壳，令 \(b(\xi)=\widehat{k_\eta}(\xi)\)。由
note 268，存在闭区间 \(I_-) 与 \(c>0\)，使
\[
 b(\xi)\le-c\quad(\xi\in I_-).
\tag{4}
\]
设 \(R\) 是 \(L^2(I_-)\) 上固定的自伴有限秩算子，并假设对每个 \(N\)，
\[
 \langle (M_b+R)f,f\rangle\ge0
 \qquad(f\in V_N|_{I_-}),
\tag{5}
\]
其中 \(M_b\) 为乘法算子。由 (1)，\(\bigcup_N V_N|_{I_-}\) 在
\(L^2(I_-)\) 中稠密；而 \(M_b+R\) 有界且自伴，所以 (5) 连续延拓为
\[
 M_b+R\succeq0\quad\text{on }L^2(I_-).
\tag{6}
\]

但有限秩扰动不能消除乘法算子的无限负指标。确实，
\(\ker R\cap L^2(I_-)\) 仍为无限维；对其中任意单位向量 \(f\)，由 (4) 得
\[
 \langle(M_b+R)f,f\rangle
 =\int_{I_-}b(\xi)|f(\xi)|^2d\xi\le-c<0,
\]
与 (6) 矛盾。因此
\[
 \boxed{\text{不存在一个固定有限秩自伴修正，使该非对角壳在所有 }V_N\text{ 上 PSD。}}
\]

等价地，这不是只在完备化后的抽象极限中失败：从
\(\ker R\cap L^2(I_-)\) 取一个使二次型严格小于零的单位向量，再用稠密性选取
\(f_N\in V_N|_{I_-}\) 充分逼近它；因二次型连续，某个有限的 \(N\) 已满足
\[
 \langle(M_b+R)f_N,f_N\rangle<0.
\]
因此任何声称“固定 rank 的修正对所有截断 \(N\) 有效”的证明，原则上都可被
一个有限截断反例击穿；这里只是没有给出该反例的有效规模上界。

这比单个有限维 divisor 主块的负惯性更强：即使试验空间逐渐加入全部
\(e^{i\xi\log n}\)，固定 rank 的 archimedean、Schur 或 Yukawa 修正仍无法
完成逐壳正化。

## 3. 结论边界

上述结论排除的是一个算子级捷径：同一个有限秩 \(R\) 对所有截断 \(N\) 及
所有 Mellin 试验向量都给出 PSD。它没有排除以下两类可能性：

1. 修正的秩随 \(N\) 或尺度增长；
2. 只对实际 Möbius 系数向量
   \(F_N(\xi)=\sum_{n\le N}\mu(n)n^{i\xi}\) 进行跨壳 signed cancellation。

第二类正是当前 RH 门的实质缺口；若能直接证明相应正能量
\(E_N(w)\ll_\varepsilon N^{1+\varepsilon}\)，则按 note 212 进入 RH，
而不是被本 note 的算子 no-go 自动解决。
