> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Active-prime graph 在 \(a=\log6\) 的无限稠密轨道

日期：2026-08-11。

本文否定“所有尺度上 active-prime 联合图的 component 均有限”这一候选，并给出全尺度可保留的
最小替代结构。

令

\[
d_2=\log2,\qquad d_3=\log3,\qquad L=d_2+d_3=\log6.
\]

半区 translation edge 为

\[
x\longleftrightarrow x+d_n
\quad(0\le x<x+d_n\le a).
\]

取 \(a\ge L\)，在 \([0,L)\) 定义

\[
T(x)=
\begin{cases}
x+d_2,&0\le x<d_3,\\
x-d_3,&d_3\le x<L.
\end{cases}
\]

则每一步分别是允许的无向 \(d_2\)-edge 或 \(d_3\)-edge，并且

\[
T(x)=x+d_2\pmod L.
\]

若 \(d_2/L\in\mathbf Q\)，则存在非零整数 \(p,q\) 使

\[
q\log2=p\log6
\Longrightarrow
2^{q-p}=3^p,
\]

矛盾。因此

\[
\frac{\log2}{\log6}\notin\mathbf Q.
\]

故任意 \(x\in[0,L)\) 的 \(T\)-轨道无限，且在圆
\(\mathbf R/L\mathbf Z\) 中稠密。特别地，active-prime 联合图含无限
component。

端点核对：

\[
d_2,d_3<a\quad\text{在 }a=L\text{ 已严格成立};
\qquad d_2,d_3<2a
\]

故两个 prime shift 均 active，且两个同半区 translation 分支均存在。
当 \(x<d_3\) 时 \(x+d_2<L\)；当 \(x\ge d_3\) 时
\(0\le x-d_3<d_2\)。轨道从 \(0\) 出发不会命中分割点 \(d_3\) 或再次
命中 \(0\)，否则会给出上述有理关系。半开区间没有端点歧义。

reflection edges 不改变反例：它们只向图中加边；包含无限 translation
轨道的 component 仍为无限 component。

最小安全结论：

\[
\boxed{a\ge\log6\Longrightarrow
\text{“所有联合 component 有限”是假的}.}
\]

所以任何有限-component 定理的尺度范围至多只能写成
\(a<\log6\)。这里不反向声称 \(a<\log6\) 时所有 component 有限；该区间
仍需另证。

全尺度可保留的最小替代命题是：固定有限 \(a\) 时 active prime powers
只有有限多个，每个 partial translation/reflection 的度有限，故每个
component 至多可数，且任意有限 word-radius ball 有限。即

\[
\boxed{\text{finite component 应替换为 locally finite, countable orbit}.}
\]
