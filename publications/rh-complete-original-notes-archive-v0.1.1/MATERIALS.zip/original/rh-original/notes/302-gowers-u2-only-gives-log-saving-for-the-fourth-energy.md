> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius \(U^2\) 统一性与 Fourier 四阶能量的换算

日期：2026-08-16。

## 已知输入

Tao--Teräväinen 的已发表结果（JEMS 27 (2025), DOI
<https://doi.org/10.4171/JEMS/1404>）给出 Möbius 的区间
\(U^2\) 统一性为任意固定幂的对数衰减：
\[
\|\mu\|_{U^2[N]}\ll_A (\log N)^{-A}.
\]
（常数允许无效。）这不是随机序列尺度的
\(N^{-1/4}\) 估计，而是只含对数的统一性。

## 精确换算

把 \(\mu(1),\ldots,\mu(N)\) 零延拓到循环群
\(\mathbb Z/M\mathbb Z\)，取 \(M\ge4N\)，并记未归一化 Fourier 变换为
\[
\widehat f(k)=\sum_{n\bmod M}f(n)e(-kn/M).
\]
由于支撑长度小于 \(M/2\)，循环加法没有边界折返，故
\[
\int_0^1\left|\sum_{n\le N}\mu(n)e(n\theta)\right|^4d\theta
=\frac1M\sum_{k\bmod M}|\widehat f(k)|^4
=M^3\|f\|_{U^2(\mathbb Z/M\mathbb Z)}^4.
\tag{1}
\]
区间 \(U^2[N]\) 的归一化因子
\(\|1_{[N]}\|_{U^2(\mathbb Z/M\mathbb Z)}\) 在固定 \(M/N\) 下上下有界，因此已知输入至多给出
\[
\int_0^1|F_N(\theta)|^4d\theta
\ll_A N^3(\log N)^{-4A}.
\tag{2}
\]

这比任意有界系数的 \(O(N^3)\) 只节省对数，仍远大于所需的
\(O(N^{2+\varepsilon})\)。代入 note 301 的 Bessel 边界，只得到
\[
\sum_H\frac{|D_H(N)|^2}{H}
\ll_A N^3(\log N)^{-4A},
\]
而不是无权的
\[
\sum_H|D_H(N)|^2\ll N^{2+\varepsilon}.
\]

## 裁决

现有 \(U^2\) 统一性不能关闭本项目的 block-square/RH 门；缺少的不是再提高 Gowers 阶数，而是从对数级 \(U^2\) 控制获得随机尺度 \(N^{-1/4+\varepsilon}\)，或直接证明带 dyadic 壳结构的四点 signed 估计。该换算也解释了为什么一般 Gowers/Fejér 正性路线在这里仍停在 \(N^{3-o(1)}\)。
