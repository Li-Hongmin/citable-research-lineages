> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 完全乘法性的 Mellin 分解：二维 dyadic 区域仍保留 RH 门

日期：2026-08-16。

考虑一个紧支撑、分段光滑的二维权 \(W(u,v)\)，定义
\[
 S_W(X):=\sum_{n,m\ge1}\lambda(n)\lambda(m)
 W\!\left(\frac nX,\frac mX\right).
\]
令二维 Mellin 变换为
\[
 \widehat W(s,t)=
 \int_0^\infty\!\!\int_0^\infty
 W(u,v)u^{s-1}v^{t-1}\,du\,dv.
\]
在 \(\Re s,\Re t>1\) 时，Mellin--Fubini 给出精确恒等式
\[
 S_W(X)=\frac1{(2\pi i)^2}
 \int_{(c)}\!\int_{(c)}
 \widehat W(s,t)X^{s+t}
 \frac{\zeta(2s)}{\zeta(s)}
 \frac{\zeta(2t)}{\zeta(t)}\,ds\,dt,
\qquad c>1.
\tag{1}
\]
这里使用了完全乘法性
\(\lambda(n)\lambda(m)=\lambda(nm)\) 以及
\[
 \sum_{n\ge1}\frac{\lambda(n)}{n^s}
 =\frac{\zeta(2s)}{\zeta(s)}.
\]

## 对 dyadic 移位块的含义

当 \(H=\alpha X\) 且 \(\alpha\) 固定时，
\[
 \sum_{\substack{n,m\le X\\ \alpha X\le m-n<2\alpha X}}
 \lambda(n)\lambda(m)
\]
正是一个尺度不变二维权 \(W_\alpha(n/X,m/X)\) 的尖锐版本。
将其用固定 \(C^\infty\) 权近似后仍适用 (1)；尖锐边界只改变
\(\widehat W_\alpha\) 的衰减，不改变两个 \(1/\zeta\) 因子。

若想从 (1) 得到 \(O(X^{1+\varepsilon})\)，自然需要把两条轮廓线推进到
\(\Re s+\Re t=1+O(\varepsilon)\)，例如各推进到
\(\Re s=\Re t=1/2+O(\varepsilon)\)。这一步要求
\(1/\zeta(s)\) 和 \(1/\zeta(t)\) 在相应临界带内解析。若存在
\(\rho\) 满足 \(\Re\rho>1/2\)，选取变换 \(\widehat W\) 在
\((\rho,\rho)\) 附近不为零，(1) 的留数项具有规模
\[
 X^{2\Re\rho}
\]
（更一般地是 \(X^{\Re\rho+\Re\rho'}\)），不能统一满足
\(O(X^{1+\varepsilon})\)。

因此，完全乘法性确实提供了一个精确的 Mellin 因子化，但并没有产生
新的无条件平方根抵消；对足够丰富的平滑 dyadic 权，平方根级二维界本身
就是 RH-strength 的轮廓移动命题。尖锐 dyadic 块还额外带来边界正则性问题，
不能用“\(\lambda(n)\lambda(m)=\lambda(nm)\)”一行跳过。

更具体地，取一参数平滑移位族
\[
 W_\alpha(u,v)=\phi(u)\psi(v-u-\alpha),
\]
其中 \(\phi,\psi\) 固定且非零，\(\alpha\) 在一个开区间内变化。若对该族有
统一的 \(S_{W_\alpha}(X)\ll_\varepsilon X^{1+\varepsilon}\)，则任意
\(\Re\rho>1/2\) 的零点都会在 (1) 中产生
\(X^{2\Re\rho}\) 留数；而 \(\widehat W_\alpha(\rho,\rho)\) 不可能对所有
\(\alpha\) 恒为零（它是非零解析函数族）。所以这种“平滑 dyadic 全族”
平方根界本身即可推出 RH。将尖锐区间界提升到这类平滑族，需要额外的
统一边界近似估计，不能无条件地省略。

这与 note 223 的滑动能量二阶差分重写相互独立：note 223 处理的是实空间
窗口曲率；本 note 说明在 Mellin 空间，完全乘法性路线的最小缺口正是
\(1/\zeta\) 临界带解析性。
