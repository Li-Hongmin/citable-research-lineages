> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 零自由 Mellin detector 在完整输出窗上具有统一 cell coercivity

日期：2026-08-14。

依赖：
[note 107](107-growing-scale-mellin-frame-fails-at-additive-nyquist-sampling.md)、
[note 108](108-growing-scale-observation-plus-path-energy-still-has-high-column-escape.md)、
[note 110](110-full-output-finest-scale-has-uniform-discrete-coercivity.md)。

证据等级：一般紧支撑 BV detector 的解析定理及其尺度反例。

note 110 对一个特定 cell detector 证明了完整活动输出窗上的最细尺度
coercivity。本文证明该现象只依赖 Mellin 符号的定量非退化，并确定当前
离散稳定机制的尺度边界。

## 1. 对象

设 \(F:(0,\infty)\to\mathbb C\) 的零延拓属于 \(BV_c\)，且

\[
\operatorname{supp}F\subset[a,b],\qquad 0<a<b<\infty.
\tag{1}
\]

定义

\[
K_F(s)=\int_0^\infty F(t)t^{s-1}\,dt,\qquad
m_0(\xi)=-i\xi K_F(i\xi),
\tag{2}
\]

并假设存在 \(c_F>0\)，使

\[
\boxed{|m_0(\xi)|\ge c_F\min(|\xi|,1)\quad(\xi\in\mathbb R).}
\tag{3}
\]

固定 \(U=[u_-,u_+]\Subset(0,\infty)\)。对 \(0<L\le C_0/Y\)，令

\[
G_L(t)=\frac1L\int_0^L F(te^{-y})\,dy,\qquad A_L=G_L'.
\tag{4}
\]

若整数列向量 \(q\) 支撑于 \(YU\)，令

\[
h_Y(u)=q(d),\qquad d/Y\le u<(d+1)/Y,
\tag{5}
\]

并在 \(U\) 外零延拓。置

\[
D_0(q)=\sum_{d\in\mathbb Z}|q(d+1)-q(d)|^2
\tag{6}
\]

及

\[
(B_{F,L,Y}q)_N
=\sum_d\left[G_L(d/N)-G_L((d+1)/N)\right]q(d).
\tag{7}
\]

完整可能活动输出区间是

\[
\boxed{I_L=\left[\frac{u_-}{be^L},\frac{u_+}{a}\right].}
\tag{8}
\]

## 2. 连续 minimum modulus

令

\[
(T_0h)(x)=-\int h(xt)\,dF(t).
\tag{9}
\]

在 log 坐标中，\(T_0\) 的 Fourier 乘子是 \(m_0\)。若
\(p(v)=h(e^v)\)，则 \(p\) 支撑在固定区间 \(\log U\)，且

\[
|\widehat p(\xi)|\le|\log(u_+/u_-)|^{1/2}\|p\|_2.
\tag{10}
\]

取充分小但固定的 \(\delta>0\)，可使

\[
\int_{|\xi|<\delta}|\widehat p(\xi)|^2\,d\xi
\le\frac12\|p\|_2^2.
\tag{11}
\]

在 \(|\xi|\ge\delta\) 上，(3) 有统一正下界。Mellin--Plancherel
及固定紧区间上 \(du/u\) 与 \(du\) 的等价性因而给出

\[
\boxed{\|h\|_2\le C\|T_0h\|_2.}
\tag{12}
\]

这是固定 log-support 的不确定性估计，而不是全线 \(L^2\) multiplier
gap；此处不需要 mean-zero。

## 3. 精确 log 平均与阶梯稳定性

直接换元给出

\[
\boxed{
T_Lh(x):=-\int_0^\infty A_L(t)h(xt)\,dt
=\frac1L\int_0^L T_0[h(e^y\,\cdot)](x)\,dy.}
\tag{13}
\]

若 \(f(v)=F(e^v)\)，则 \(G_L(e^v)\) 是 \(f\) 与长度 \(L\) 的概率
box 的卷积。因此几乎处处

\[
A_L(t)=\frac{F(t)-F(te^{-L})}{Lt},
\qquad
\|A_L\|_{L^1(dt)}\le\operatorname{Var}(f),
\tag{14}
\]

且 \(\operatorname{supp}A_L\subset[a,be^L]\)。一般不能要求
\(A_Ldt\to dF\) 的总变差收敛，也不能要求
\(\operatorname{Var}(A_L)\) 一致有界。

当 \(|y|\le C_0/Y\) 时，固定列窗上的 dilation 只跨越 \(O(1)\)
个输入 cell。telescoping 与有界重叠给出

\[
\int|h_Y(e^yu)-h_Y(u)|^2\,du
\le\frac{C}{Y}D_0(q).
\tag{15}
\]

由 (13)、\(T_0\) 的 \(L^2\) 有界性及 Jensen 不等式，

\[
\boxed{Y\|T_Lh_Y-T_0h_Y\|_2^2\le CD_0(q).}
\tag{16}
\]

## 4. 输出采样

当 \(x=N/Y\) 时，

\[
xt\in[d/Y,(d+1)/Y)
\iff t\in[d/N,(d+1)/N).
\tag{17}
\]

逐 cell 积分严格给出

\[
\boxed{(T_Lh_Y)(N/Y)=(B_{F,L,Y}q)_N.}
\tag{18}
\]

没有 floor remainder。对 \(N/Y\le x<(N+1)/Y\)，以
\(|A_L(t)|dt\) 作 Cauchy--Schwarz，再用 (14)--(15) 的有界重叠，
得到

\[
\boxed{
Y\|T_Lh_Y\|_{L^2(I_L)}^2
\le C\sum_{N/Y\in I_L}|(T_Lh_Y)(N/Y)|^2+CD_0(q).}
\tag{19}
\]

区间 (8) 的方向来自 \(t\in[a,be^L]\) 与 \(xt\in U\)；端点不足
一个采样 cell 的部分由同一零延拓差分支付。

## 5. 一般离散 coercivity

合并 (12)、(16)、(19) 与 (18)，得到：

### 定理 1

在 (1)--(3) 的假设下，对每个固定 \(U\) 与 \(C_0>0\)，存在
只依赖 \(F,U,C_0\) 的 \(C\)，使对所有 \(Y\ge2\)、
\(0<L\le C_0/Y\) 及所有支撑于 \(YU\) 的列向量 \(q\)，

\[
\boxed{
\|q\|_{\ell^2}^2
\le C\left(
\sum_{N/Y\in I_L}|(B_{F,L,Y}q)_N|^2+D_0(q)
\right).}
\tag{20}
\]

零延拓是承重条件。若只保留内部差分，则列窗两端的 trace 未被
(15) 与 (19) 支付；mean-zero 本身不能以统一常数补回它们。完整输出窗
也不可删除：notes 107--108 已给出缩窗下的显式逃逸族。

## 6. 尺度尖锐性

条件 \(L=O(Y^{-1})\) 在 \(L\to0\) 的尺度族中是尖锐的。设

\[
L_Y\to0,\qquad YL_Y\to\infty,
\tag{21}
\]

并取非零 \(\phi\in C_c^1(\log U^\circ)\)。令

\[
t_Y=\frac{2\pi}{L_Y},\qquad
p_Y(v)=\phi(v)e^{it_Yv},\qquad
q_Y(d)=p_Y(\log(d/Y)).
\tag{22}
\]

log-average 的频率因子

\[
\frac{e^{itL}-1}{itL}
\tag{23}
\]

在 \(t=t_Y\) 精确为零。冻结包络 \(\phi(v+y)\) 后主项消失，而
\(|\phi(v+y)-\phi(v)|\le\|\phi'\|_\infty y\) 给出

\[
\|T_{L_Y}p_Y\|_{L^\infty}\le C_{F,\phi}L_Y.
\tag{24}
\]

从光滑 packet 到 cell 阶梯函数的误差为

\[
\|h_Y-p_Y(\log\cdot)\|_\infty
\ll\frac1{YL_Y}.
\tag{25}
\]

完整活动 rows 有 \(O(Y)\) 个，故

\[
\sum_N|(B_{F,L_Y,Y}q_Y)_N|^2
\ll YL_Y^2+\frac1{YL_Y^2}.
\tag{26}
\]

packet 支撑远离列窗端点，且 \(t_Y/Y\to0\)，所以

\[
\|q_Y\|_2^2\asymp_\phi Y,\qquad
D_0(q_Y)\ll\frac1{YL_Y^2}.
\tag{27}
\]

因此

\[
\boxed{
\frac{\sum_N|(B_{F,L_Y,Y}q_Y)_N|^2+D_0(q_Y)}
{\|q_Y\|_2^2}
\ll L_Y^2+\frac1{Y^2L_Y^2}\longrightarrow0.}
\tag{28}
\]

### 定理 2

对任何满足 (1) 的非平凡 BV detector，若 (21) 成立，则完整输出窗上
也有 Rayleigh quotient 趋于零的 compact-envelope Mellin packet。因此在
趋零尺度族中，\(L_Y=O(Y^{-1})\) 是 observation 加零延拓路径能量具有统一
gap 的尖锐尺度级别。

## 7. 结论边界

定理 1 是一般离散稳定性结果，定理 2 给出尺度反例。它们解释了 note 110
的机制及其极限，但没有给出 note 111 中 Möbius observation 的无条件
\(Y^{2+\varepsilon}\) 上界，因而不构成 RH 的证明。
