> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mellin 正能量的二维 Abel 恒等式与零频边界通道

日期：2026-08-16。

本 note 给出一个把固定 Mellin 能量压到 Mertens 路径的精确恒等式。
它不提供无条件平方根估计，但把跨尺度项分成一个端点通道、一个一次
边界通道和一个 log-scale 二次卷积；后者的 Fourier 符号在零频处有一个
必然的二阶零点。因此只控制“导数型路径能量”不能代替零频 Mertens 门。

## 1. 二维分部恒等式

令 \(a_1,\ldots,a_N\) 为任意有限实序列，

\[
 A(x)=\sum_{1\le n\le x}a_n,
 \qquad 1\le x\le N,
\]

并令 \(K\in C^2((-\log N,\log N))\) 为偶函数。定义

\[
 \mathcal E_N(K)=\sum_{m,n\le N}a_ma_n
 K\!\left(\log\frac mn\right).
\]

对两个变量分别使用有限 Abel 分部（端点 \(x=1\) 的跳跃已经包含在
\(A(1)\) 中），得到精确恒等式

\[
\boxed{\begin{aligned}
 \mathcal E_N(K)
 ={}&K(0)A(N)^2
 +2A(N)\int_1^N A(x)
 K'\!\left(\log\frac Nx\right)\frac{dx}{x}\\
 &-\int_1^N\!\int_1^N A(x)A(y)
 K''\!\left(\log\frac xy\right)\frac{dx}{x}\frac{dy}{y}.
\end{aligned}}
\tag{1}
\]

确切地说，先对 \(m\) 分部得到
\[
 \sum_{m\le N}a_m f(m,n)
 =A(N)f(N,n)-\int_1^N A(x)\partial_xf(x,n)\,dx,
\]
再对 \(n\) 分部。取
\(f(x,y)=K(\log(x/y))\) 后
\[
 f_x=\frac{K'(\log(x/y))}{x},
 \qquad
 f_y=-\frac{K'(\log(x/y))}{y},
 \qquad
 f_{xy}=-\frac{K''(\log(x/y))}{xy}.
\]
偶性给出两个边界积分相同，因而得到 (1)。

对本项目 \(a_n=\mu(n)\)，\(A=M\)；对
\[
 K(u)=\int_{\mathbb R}w(t)e^{itu}\,dt,
 \qquad w(t)\ge0,
\]
式 (1) 正好等于
\[
 E_N(w)=\int_{\mathbb R}w(t)
 \left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt
\]
（若 \(w=|h|/(2\pi)\)，按所选 Fourier 归一化统一常数即可）。

## 2. log-scale 形式与正性

令 \(L=\log N\)、\(B_N(r)=A(Ne^{-r})\)，\(0\le r\le L\)。则 (1) 等价于

\[
 \mathcal E_N(K)=K(0)B_N(0)^2
 +2B_N(0)\int_0^L B_N(r)K'(r)\,dr
 -\int_0^L\!\int_0^L B_N(r)B_N(s)K''(s-r)\,dr\,ds.
\tag{2}
\]

若 \(K\) 是 \(w\) 的 Fourier 变换，则
\[
 -K''(u)=\int_{\mathbb R}t^2w(t)e^{itu}\,dt,
\]
所以最后一项本身是一个正半定二次型：对实 \(B_N\)，
\[
 -\iint B_N(r)B_N(s)K''(s-r)\,drds
 =\int_{\mathbb R}t^2w(t)\left|
 \int_0^L B_N(r)e^{-itr}\,dr\right|^2dt\ge0.
\tag{3}
\]
一次边界项的 Fourier 形式为
\[
 2B_N(0)\int B_N(r)K'(r)dr
 =2B_N(0)\operatorname{Re}\int_{\mathbb R}
 w(t)\,(-it)\left(\int_0^L B_N(r)e^{-itr}dr\right)dt.
\]
与 (3) 合并正好得到
\[
 \mathcal E_N(w)=\int_{\mathbb R}w(t)
 \left|B_N(0)-it\int_0^L B_N(r)e^{-itr}dr\right|^2dt.
\tag{4}
\]

因此二维分部没有制造新的正性；它只是把原始 Dirichlet 多项式的
Mellin transform 写成 Mertens 路径的一个端点加 log-scale 导数项。

## 3. 零频缺口是结构性的

二次卷积项 (3) 的符号含有 \(t^2w(t)\)，在 \(t=0\) 必然为零。于是任何
只估计 (3) 的“路径导数能量”的方法都看不到 \(B_N(0)=M(N)\) 的零频通道。
一次边界项也不能被逐项取绝对值后免费吸收：对任意 \(B\)，Cauchy--Schwarz
只给出
\[
 \left|\int w(t)(-it)\widehat B(t)dt\right|^2
 \le K(0)\int t^2w(t)|\widehat B(t)|^2dt,
\]
这是原式正性对应的 Schur 不等式，而不是对 \(M(N)\) 的独立衰减。

最简单的结构性测试是 \(a_n\equiv1\)。此时 \(A(x)\asymp x\)，(4) 的
零频端点为 \(A(N)^2\asymp N^2\)，而 (3) 与一次项共同重建同一量级；
log-scale 导数正性本身不会产生任何平方根节省。对 \(a_n=\mu(n)\)，要使
\(\mathcal E_N(w)\ll N^{1+\varepsilon}\)，仍必须同时控制端点 \(M(N)\)
与路径项的 signed 交叉，而不能只证明一个正半定卷积项很小。

## 4. 对当前 RH 路线的裁决

式 (1)--(4) 给出一个新的精确跨尺度坐标，但没有关闭算术门。它把可行的
下一步压缩为一个更具体的二通道问题：在 \(B_N(0)\) 与
\(\widehat B_N\) 之间建立保留符号的联合估计，使端点与一次项发生真实
Möbius cancellation；仅用窗口能量、逐移位绝对值或
\(-K''\) 的正性都不足以达到 \(N^{1+\varepsilon}\)。

这与 note 212 的 RH 等价门一致，但比原始双和展开额外给出了明确的
log-scale 路径核和零频 Schur 缺口。
