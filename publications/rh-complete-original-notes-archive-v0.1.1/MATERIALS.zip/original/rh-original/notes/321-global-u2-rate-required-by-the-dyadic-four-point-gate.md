> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Dyadic 四点平方门强制多项式全局 \(U^2\) 速率

日期：2026-08-16。

本 note 把当前 dyadic 四点门与一个无归一化的全局 \(U^2\) 量作精确尺度比较。
它不声称新的 Möbius 估计；作用是排除把“所有短区间 \(U^2\) 的任意对数级小量”
误读成目标平方根门。

## 1. 精确定义与恒等式

令 \(f_Y(n)=\mu(n)\mathbf 1_{1\le n\le Y}\)，并定义

\[
 C_Y(h)=\sum_{n\in\mathbb Z}f_Y(n)f_Y(n+h),
 \qquad
 \mathfrak U_2(f_Y)^4:=Y^{-3}\sum_{h\in\mathbb Z}|C_Y(h)|^2.
\tag{1}
\]

这是零延拓序列的无归一化 \(U^2\) 质量；按定义即有

\[
 \sum_{h\in\mathbb Z}|C_Y(h)|^2=Y^3\mathfrak U_2(f_Y)^4.
\tag{2}
\]

## 2. Dyadic 门的必要后果

假设对所有 dyadic \(H=2^j<Y\) 都有（把区间写成
\(H\le h<2H\)；若沿用 notes 320 的 \(H<h\le2H\) 约定，遗漏的
\(h=1\) 只贡献 \(O(Y^2)\)）：

\[
 E_Y(H):=\sum_{H<h\le 2H}|C_Y(h)|^2
 \ll_{\varepsilon}Y^{2+\varepsilon}H^{-1}.
\tag{3}
\]

这些区间覆盖 \(1\le h<Y\)，而 \(C_Y(-h)=C_Y(h)\)。因此

\[
 \sum_{h\in\mathbb Z}|C_Y(h)|^2
 \ll Y^2+\sum_{j\ge0}Y^{2+\varepsilon}2^{-j}
 \ll_{\varepsilon}Y^{2+\varepsilon}.
\tag{4}
\]

由 (2) 得到必要条件

\[
 \boxed{\mathfrak U_2(f_Y)\ll_{\varepsilon}Y^{-1/4+\varepsilon}.}
\tag{5}
\]

所以目标 dyadic 四点门不是“\(U^2\) 只需趋于零”，而是要求随机量级的
多项式衰减。反向并不成立：全局 (5) 只给每个
\(E_Y(H)\ll Y^{2+\varepsilon}\)，不能恢复 (3) 中的 \(H^{-1}\)。

## 3. 与 all-interval 定理的尺度差

Matomäki--Shao--Tao--Teräväinen 的 all-interval 结果给固定阶 nilsequence
相关的任意对数级衰减；它本身不是 (3) 的四点均方定理。在 notes 320 的
区间拼接换算中，这对应

\[
 E_Y(H)\ll Y^2H(\log Y)^{-A}.
\tag{6}
\]

（这里 \(H\) 是块长，常数和允许范围按该定理的短区间条件理解。）与 (3)
比较，二者相差 \(H^2(\log Y)^{-A}\)。即使 \(A\) 任意固定，宏观
\(H=Y^\theta\) 仍保留一个正幂缺口；所需的局部 \(U^2\) 规模正是

\[
 \delta_Y\ll H^{-1/2}Y^{\varepsilon/4},
\tag{7}
\]

而不是 \((\log Y)^{-A}\)。

## 4. 裁决

这给出当前 \(U^2\) 路线的最小尺度判据：

* all-interval 只解决了“每个区间”的量词，不提供 (5) 的多项式速率；
* 通过区间拼接再取 Cauchy 会把长度 \(H\) 付回去，不能关闭正 detector 的
  \(N^{1+\varepsilon}\) 能量门；
* 若要继续沿此路线，最小新输入必须是多项式 \(U^2\) 速率或直接的全局四点
  signed 估计，而不能再重复对数级 nilsequence 均匀性。

这只定位算术缺口，不把任何有限计算或现有 all-interval 定理外推成 RH。
