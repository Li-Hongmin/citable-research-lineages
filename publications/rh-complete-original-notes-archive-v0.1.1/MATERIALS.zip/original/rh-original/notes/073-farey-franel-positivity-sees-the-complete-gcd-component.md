> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Farey--Franel 正性只看完整 gcd 分量

日期与检索截止：2026-08-12。

依赖：[note 065](065-barban-vehov-hminus1-obstruction-and-weak-mertens-bridge.md)、
[note 069](069-gcd-completion-cancels-the-fixed-slice-antidiagonal.md)、
[note 072](072-critical-low-frequency-band-has-no-type-II-oscillation.md)。

历史主源：
[Kanemitsu--Yoshimoto 1996](https://doi.org/10.4064/aa-75-4-351-374)。

## 1. 弄清问题

Franel--Landau 给出罕见的一侧正 RH 判据。其核与 note 065 的 gcd/Jordan
正核完全相同。本轮只判别

\[
\boxed{
\text{Farey discrepancy positivity}
\quad\Longrightarrow?\quad
\text{Selberg incomplete shell boundary}.
}
\tag{1}
\]

```mermaid
flowchart LR
  A["Farey: all reduced numerator residues"] --> B["complete Bernoulli Gram"]
  B --> C["gcd kernel G(d,e)"]
  D["Selberg: one reciprocal trajectory y/d"] --> E["shell kernel K_N(d,e)"]
  E --> C
  E --> F["signed incomplete boundary E_N(d,e)"]
  C --> G["Q₂ already o(N)"]
  F --> H["unresolved near-resonance"]
```

## 2. 拟定计划

\[
\text{Franel exact form}
\to \text{kernel identification}
\to K_N=NG/12+E_N
\to \text{short Kubert/log-taper transfer test}.
\tag{2}
\]

## 3. 实现计划

### 3.1 Franel 正量的精确 gcd Gram

令 \(\mathcal F_N=\{\rho_\nu\}\) 为 order-\(N\) Farey sequence，

\[
\Phi(N):=\sum_{n\le N}\varphi(n),
\qquad
\delta_\nu:=\rho_\nu-\frac{\nu}{\Phi(N)},
\tag{3}
\]

并置

\[
v_m:=M(\lfloor N/m\rfloor),
\qquad
G_N(m,n):=\frac{(m,n)^2}{mn}.
\tag{4}
\]

Kanemitsu--Yoshimoto, Theorem 3 的 Franel 公式为

\[
\boxed{
12\Phi(N)\sum_{\nu=1}^{\Phi(N)}\delta_\nu^2+1
=\sum_{m,n\le N}v_mv_nG_N(m,n).
}
\tag{5}
\]

正性亦可由 Jordan 分解直接看出：对任意实向量 \(c\)，

\[
\boxed{
c^TG_Nc
=\sum_{k\le N}J_2(k)
\left(\sum_{k\mid d}\frac{c_d}{d}\right)^2
\ge0.
}
\tag{6}
\]

Franel 临界估计

\[
\sum_\nu\delta_\nu^2=O_\varepsilon(N^{-1+\varepsilon})
\tag{7}
\]

本身就是 RH 等价条件，不是可无条件导入的较弱定理。

这里必须区分 raw Farey Gram 与 (5) 的最终收缩。若

\[
(A_Fc)(\rho):=\sum_{a\le N}c_aB_1(a\rho),
\]

则论文 Lemma 7 给出

\[
\boxed{
\mathcal G_N^F(a,b)
:=\sum_{\rho\in\mathcal F_N}B_1(a\rho)B_1(b\rho)
=\sum_{q\le N}M(N/q)
\sum_{r=1}^qB_1(ar/q)B_1(br/q).
}
\tag{7a}
\]

Fourier 语言中，内和检测的是 \(ha\equiv kb\pmod q\) 的 modular aliases；
故 \(\mathcal G_N^F\ne G_N\) entrywise。只有特殊向量
\(v_a=M(N/a)\)、常数模与 generalized-Dedekind 三项关系合并后，raw Farey
二次型才收缩为 (5) 的 \(v^TG_Nv\)。

### 3.2 Selberg shell 精确多出一个边界核

定义

\[
K_N(d,e):=
\int_N^{2N}\beta(y/d)\beta(y/e)\,dy.
\tag{8}
\]

notes 065、069 已证明

\[
\boxed{
K_N(d,e)
=\frac N{12}G_N(d,e)+E_{d,e}(N).
}
\tag{9}
\]

若

\[
\lambda_d:=\mu(d)\frac{\log(N/d)}{L},
\qquad
F_N(t):=\sum_{d\le N}\lambda_d\beta(Nt/d),
\tag{10}
\]

则

\[
\boxed{
N\int_1^2|F_N(t)|^2dt
=\frac N{12}Q_2(N)
+\sum_{d,e\le N}\lambda_d\lambda_eE_{d,e}(N),
}
\tag{11}
\]

\[
Q_2(N)=\lambda^TG_N\lambda
\ll\frac{N\log\log(3N)}L=o(N).
\tag{12}
\]

所以 Farey 与 Selberg 并非“核完全不同”，而是

\[
\boxed{
\begin{array}{c|c|c}
&\text{向量}&\text{核}\\
\hline
\text{Franel}&v_m=M(N/m)&G_N\\
\text{Selberg complete period}&\lambda_d&G_N\\
\text{Selberg shell}&\lambda_d&NG_N/12+E_N
\end{array}
}
\tag{13}
\]

Franel positivity 精确命中 (11) 中已经证明为 \(o(N^2)\) 的第一项；
当前未知量是第二项 \(\lambda^TE_N\lambda\)。

而且 gcd/Franel 标量能量不决定 shell 能量。首个有限反例已在 \(N=4\) 出现。
限制到坐标 \(d=3,4\)：

\[
G_N|_{3,4}
=\begin{pmatrix}1&1/12\\1/12&1\end{pmatrix},
\qquad
K_N|_{3,4}
=\begin{pmatrix}7/27&-1/18\\-1/18&1/3\end{pmatrix}.
\tag{12a}
\]

取

\[
c=e_3,
\qquad
c'=\sqrt{6/13}\,(e_3+e_4).
\]

则

\[
\boxed{
c^TG_Nc=(c')^TG_Nc'=1,
}
\tag{12b}
\]

但

\[
\boxed{
c^TK_Nc=\frac7{27},
\qquad
(c')^TK_Nc'=\frac29.
}
\tag{12c}
\]

差值来自非共振核；例如

\[
K_N(3,4)-\frac N{12}G_N(3,4)
=-\frac1{18}-\frac1{36}
=-\frac1{12}.
\tag{12d}
\]

故即便知道一个向量的完整 gcd 能量，也不能由该标量恢复其 shell 能量。

### 3.3 complete numerator average 与 reciprocal selector 不可互换

Franel 证明使用完整 Farey 节点和完整 residue systems，例如

\[
\sum_{\rho_\nu\in\mathcal F_N}
B_1(a\rho_\nu)B_1(b\rho_\nu).
\tag{14}
\]

Selberg shell 对每个 \(d\) 只观察一条 reciprocal trajectory

\[
\beta(y/d),
\qquad N\le y\le2N.
\tag{15}
\]

对 \(d,e\asymp N\) 常有

\[
[d,e]\asymp N^2,
\qquad
\frac{[d,e]}{|[N,2N]|}\asymp N.
\tag{16}
\]

把 (15) 补成完整共同周期需增加约 \(N\) 倍长度；补周期后的主项正是
\(NG_N/12\)，丢下的余量仍是 \(E_N\)。Fourier 语言中，完整平均执行
residue/congruence 正交；长度 \(N\) 的 shell 则保留

\[
he-kd=\pm1,
\qquad
N|h/d-k/e|\asymp N^{-1}
\tag{17}
\]

的 Bézout near-resonance。故 (14) 不能替代 (15)。

### 3.4 short Kubert formulas 严格返回 RH 级 Mertens 量

Kanemitsu--Yoshimoto, Theorem 1 给出

\[
\boxed{
D_N(\xi)
=\sum_{n\le N}\frac{M(N/n)}n
\{n\xi\}\bigl(\{n\xi\}-1\bigr)+O(1),
}
\tag{18}
\]

其中 \(D_N(\xi)\) 是相应 Farey short-interval discrepancy。
在 \(\xi=1/2,1/3,1/4\) 时，(18) 分别化为有限个伸缩差

\[
S(N)-cS(N/q),
\qquad
S(N):=\sum_{n\le N}\frac{M(N/n)}n.
\tag{19}
\]

该文 Lemmas 2、4 证明

\[
S(N)-cS(N/q)=O(N^{1/2+\varepsilon})
\iff
S(N)=O(N^{1/2+\varepsilon})
\iff\mathrm{RH}.
\tag{20}
\]

因此历史上的“更短 Farey 区间”不是弱输入；它是 RH 的有限伸缩重编码。

### 3.5 log taper 给出一个真实但更强的平均判据

由

\[
\log(N/d)=\int_d^N\frac{dU}{U},
\tag{21}
\]

可写

\[
F_N(t)
=\frac1L\int_1^NH_{N,U}(t)\frac{dU}{U},
\qquad
H_{N,U}(t):=\sum_{d\le U}\mu(d)\beta(Nt/d).
\tag{22}
\]

Cauchy--Schwarz 给出

\[
\boxed{
\int_1^2|F_N(t)|^2dt
\le
\frac1L\int_1^N\int_1^2|H_{N,U}(t)|^2dt\frac{dU}{U}.
}
\tag{23}
\]

故

\[
\frac1L\int_1^N\int_1^2|H_{N,U}(t)|^2dt\frac{dU}{U}=o(N)
\tag{24}
\]

连同已由 PNT 控制的 affine 标量，是一个 RH 充分条件。但 Farey complete
numerator average 不控制 (24) 的 reciprocal selector；(24) 自身因推出首壳判据而
推出 RH，不能作为弱于 RH 的既有输入。

## 4. 回顾反思

\[
\boxed{
\begin{array}{c|c}
\text{候选转移}&\text{裁决}\\
\hline
\text{Franel positive Gram}&\text{只给 complete }G_N\text{ component}\\
\text{three-term Dedekind completion}&\text{余下 }N\bmod[d,e]\text{ boundary}\\
\text{short Kubert }\xi=1/q&\text{RH-equivalent dilation difference}\\
\text{log taper average}&\text{新充分判据，但不弱于 RH}\\
\text{continuous shell near-resonance}&\text{仍未控制}
\end{array}
}
\tag{25}
\]

因此 Farey--Franel 路线被精确定位，而不是笼统排除：它解释并控制
complete-period gcd 正项，却没有跨过 incomplete shell boundary。

下一最简单元必须直接作用于 \(E_N\) 或 note 072 的
\(P^\perp D_{I,N}\)，且保留 single reciprocal selector；任何先做全 numerator
completion 的方法都会回到 (12) 或 RH 等价的 (20)。

本 note 没有证明 RH。
