> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有限 prime delays 不传播 polar moment

日期：2026-08-11。

本文承接 notes 026、036、037，证明有限 active-prime translation--reflection algebra 在半整数指数矩
上逐坐标作用，不能把 polar moment 的消失递推为全部 Archimedean moments 消失。因此
prime-delay moment-propagation 不能证明 zero-cyclicity。

## 1. 全线 shifts 逐指数坐标对角化

将 \(u\in L^2(-a,a)\) 零延拓到全线，记

\[
U^\pm(u;\rho)=\int_{-a}^a u(x)e^{\pm\rho x}\,dx,
\qquad \rho_m=2m+\frac12.
\]

对 \((T_du)(x)=u(x+d)\)，变量替换直接给出

\[
U^+(T_du;\rho)=e^{-\rho d}U^+(u;\rho),
\qquad
U^-(T_du;\rho)=e^{\rho d}U^-(u;\rho).
\tag{1}
\]

反射交换 \(U^+\) 与 \(U^-\)；限制到固定奇偶扇区后，它同样在每个固定 \(\rho\) 上乘一个标量。
因此任意有限 active-prime word 或其有限线性组合满足

\[
U_m\longmapsto p_a^\sigma(\rho_m)U_m,
\tag{2}
\]

其中 \(p_a^\sigma\) 是有限指数多项式。式 (2) 的第 \(m\) 个等式不含任何 \(U_k\)、\(k\ne m\)。

等价地，若

\[
H(z)=\sum_{m\ge0}U_mz^m,
\]

则 \(d=\log n\) 的 delay 只产生

\[
n^{\pm1/2}H(n^{\pm2}z).
\tag{3}
\]

这是有限 dilation，而不是 Taylor 系数的三角递推。特别地，\(U_0=0\) 的子空间在整个有限
prime-delay algebra 下不变，并允许任意尾序列 \((U_1,U_2,\ldots)\)。

## 2. 区间压缩只增加边界未知量

真实零方程具有压缩形式

\[
P_ITP_Iu=0,
\qquad I=(-a,a).
\tag{4}
\]

对 partial shift 在 \(I\) 上取指数矩时，式 (1) 会多出被端点截断的 collar integrals。这些是新的
边界泛函，并非有限个 \(U_m\) 的线性组合。所以压缩不会把 (2) 改造成矩递推，反而增加未知数据。

等价的全线 Wiener--Hopf 表示为

\[
Tu=g_++g_-,
\qquad \operatorname{supp}g_\pm\subset I^c,
\tag{5}
\]

其中 \(g_\pm\) 是压缩方程允许的自由外侧源。在 \(\rho_m\) 上，关系只能写成

\[
\bigl(m_{\rm arch}(\rho_m)+p_a^\sigma(\rho_m)\bigr)U_m
=G_{+,m}+G_{-,m}.
\tag{6}
\]

右端并不为零；即使左端标量非零，(6) 也不能推出 \(U_m=0\)。

## 3. 与 Archimedean 外侧级数的关系

对 \(x>a\)，Archimedean 势为

\[
(\mathcal Ku)(x)=\sum_{m\ge0}e^{-\rho_mx}U_m.
\tag{7}
\]

有限 shifts 只按 (2) 改变各系数，不能令 (7) 在外侧开区间消失。只有额外得到一个外侧齐次解析
恒等式，才能利用解析唯一性逐系数推出 \(U_m=0\)；而 notes 036、037 已证明，这正是尚缺的
exterior-potential UCP，与 zero-cyclicity 本身等价。

## 4. 结论与范围

\[
\boxed{
U_0=0
\quad\not\Longrightarrow\quad
U_m=0\ (m\ge1)
\text{ by any finite active-prime delay identity}.}
\]

这里的否定针对由有限 translation/reflection 恒等式产生的传播机制，不声称真实 reduced Weil
算子存在不可见零核。后者仍是未决的 exact zero-mode 问题。

因此，任何成功的 zero-cyclicity 证明都必须加入真正的无限边界信息、外侧齐次恒等式，或不经矩
传播而直接控制真实零模态；有限 arithmetic delays 本身不能提供所需桥梁。
