> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mertens 超平方根增长必然产生宏观正 dyadic 相关块

日期：2026-08-16。

依赖：[note 265](265-one-sided-dyadic-correlation-gate-is-sufficient-for-rh.md)、
[note 277](277-smoothed-averaged-chowla-transfer-only-log-saving.md)。

本文只给出一个严格的尺度定位引理。它不证明 RH；作用是把任何
Mertens 超平方根增长定位到必须由 signed arithmetic intertwiner 处理的
移位尺度。

## 1. 精确 dyadic 分解

令

\[
M(X)=\sum_{n\le X}\mu(n),
\qquad
C_h(X)=\sum_{n\le X-h}\mu(n)\mu(n+h),
\]

并对 dyadic $H=1,2,4,\ldots<X$ 定义

\[
D_H(X)=\sum_{H\le h<\min(2H,X)}C_h(X).
\]

按正移位分组的平方恒等式为

\[
M(X)^2=\sum_{n\le X}\mu(n)^2+2\sum_{H<X}D_H(X).
\tag{1}
\]

因为 $\sum_{n\le X}\mu(n)^2\le X$，记
$J_X=\lceil\log_2X\rceil$，则

\[
\boxed{
\max_{H<X}D_H(X)^+
\ge
\frac{M(X)^2-X}{2J_X}.}
\tag{2}
\]

这里 $r^+=\max(r,0)$。证明只是从 (1) 删除所有负的 dyadic 块，并使用
$\sum_H D_H^+\le J_X\max_H D_H^+$。

因此若在某个 $X$ 有
\[
|M(X)|\ge X^{1/2+\delta},
\qquad X^{2\delta}\ge 2,
\]
则存在一个 $H<X$ 使

\[
\boxed{
D_H(X)^+
\ge \frac{X^{1+2\delta}}{4J_X}.}
\tag{3}
\]

这一步完全是有限恒等式，没有使用 Chowla、PNT 或 RH。

## 2. 与 averaged-Chowla 输入的尺度下界

假设在 $X$ 的固定倍数范围内有一个 dyadic averaged-Chowla 估计

\[
\sum_{H\le h<2H}|C_h(X)|
\le C XH\rho(X),
\qquad 10\le H<X,
\tag{4}
\]

其中 $\rho(X)=o(1)$。这是 note 277 所采用的平滑转移输入的
不加权 dyadic 版本；对 $H<10$ 可使用平凡估计。

若 $H_*(X)$ 是满足 (3) 的块，(4) 给出

\[
\frac{X^{1+2\delta}}{4J_X}
\le D_{H_*}(X)^+
\le |D_{H_*}(X)|
\le C XH_*(X)\rho(X).
\]

于是

\[
\boxed{
H_*(X)
\ge
\frac{X^{2\delta}}{4C\,J_X\rho(X)}.}
\tag{5}
\]

例如对 MRT 型
$\rho(X)\ll \log\log X/\log X+\log^{-c}X$
，任何固定 \(\delta>0\) 的 Mertens 超平方根增长，都不能由
固定移位或次多项式移位块承载；其正相关块必须满足
$H_*(X)\ge X^{2\delta-o(1)}$。

## 3. 这条定位不能封口 RH

式 (5) 只把异常块推向增长的移位尺度，并没有给出该尺度上的上界。对
\(H\asymp X\)，现有 averaged-Chowla 输入 (4) 的右端仍是
\(X^2\rho(X)\)，远大于所需的 \(X^{1+\varepsilon}\)；而把
\(D_H\) 展开成四点或 Rademacher block 能量，又回到
notes 243--244 的 signed correlation 门。

所以当前最薄的剩余命题可更具体地写成：对所有 $X$ 与
$H\ge X^{\eta}$（任意固定 $\eta>0$），证明足以控制
\(D_H(X)^+\) 的跨移位 signed estimate；或者直接证明
\(
\sum_H D_H(X)^+\ll_\varepsilon X^{1+\varepsilon}
\)
。后者由 note 265 立即推出 RH，前者若覆盖 (5) 所需的全部宏观尺度，也会
排除任意固定 \(\delta>0\) 的 Mertens 超平方根增长。

本 note 的结论是一个严格的异常尺度定位，不是 RH 证明，也不把
averaged-Chowla 的对数节省误写成平方根级 cancellation。
