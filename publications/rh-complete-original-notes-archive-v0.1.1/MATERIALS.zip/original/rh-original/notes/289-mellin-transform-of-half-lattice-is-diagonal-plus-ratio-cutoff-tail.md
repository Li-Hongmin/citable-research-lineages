> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Half-lattice reciprocal sum 的 Mellin 分解与 ratio-cutoff 尾

日期：2026-08-16。

本 note 给出 sharp half-lattice

$$
T_P(x)=\sum_{a,b\le\sqrt x}\mu(a)\mu(b)
P\!\left(\frac{x}{ab}\right)
$$

的精确 Mellin 变换。它把 cutoff 误差写成一个单独的 ratio-kernel
Dirichlet 尾，并说明提高 detector 在 \(y=\infty\) 的衰减不能自动改善
该尾的绝对收敛边界。

## 1. 精确 Mellin 恒等式

设 \(P(y)=0\) 于 \(0<y<1\)，并假设 \(P(y)=O(y^{-1-\eta})\)；对
\(\sigma=\operatorname{Re}s>1\)，逐项换序合法。令

$$
Q_s(r):=\int_r^\infty P(y)y^{-s-1}\,dy,\qquad r\ge1.
$$

在 \(T_P(x)\) 中固定 \(a,b\)，条件 \(a,b\le\sqrt x\) 等价于
\(x\ge\max(a^2,b^2)\)。作变换 \(x=ab\,y\)，得到

$$
\boxed{
\int_1^\infty T_P(x)x^{-s-1}\,dx
=\sum_{a,b\ge1}\mu(a)\mu(b)(ab)^{-s}
Q_s\!\left(\max\!\left(\frac ab,\frac ba\right)\right).}
\tag{1}
$$

特别地，按 \(a=b\) 与 \(a>b\)、\(b>a\) 分解，

$$
\begin{aligned}
\mathcal T_P(s)
={}&Q_s(1)\sum_{a\ge1}\mu(a)^2a^{-2s}\\
&+2\sum_{a>b\ge1}\mu(a)\mu(b)(ab)^{-s}Q_s(a/b).
\end{aligned}
\tag{2}
$$

由 periodization 的 Mellin 恒等式，
\[
Q_s(1)=\int_1^\infty P(y)y^{-s-1}\,dy=\zeta(s)K(s),
\]
所以对角项是

$$
\zeta(s)K(s)\frac{\zeta(2s)}{\zeta(4s)}.
\tag{3}
$$

式 (2) 是 exact identity；第二项正是 sharp cutoff 的 ratio-tail，而不是
一个可以事后忽略的 lcm 分层误差。

## 2. 为什么高阶 \(y=\infty\) 衰减不能自动关闭 cutoff

若 \(P(y)=O(y^{-L})\) 对任意大的固定 \(L\) 成立，则
\(Q_s(r)=O_s(r^{-\sigma-L})\)。对 \(a>b\) 的绝对值项，这给出

$$
(ab)^{-\sigma}(a/b)^{-\sigma-L}
=a^{-2\sigma-L}b^L.
\tag{4}
$$

在 \(b<a\) 上求和后，\(b^L\) 的体积因子恰好抵消了额外的 \(L\)：

$$
\sum_{b<a}a^{-2\sigma-L}b^L
\asymp a^{1-2\sigma}.
\tag{5}
$$

因此 ratio-tail 的绝对求和仍要求 \(\sigma>1\)，并不会因为 \(P\) 在
\(y=\infty\) 的衰减阶提高而自动进入 \(\sigma>1/2\)。

这不是粗界的假象。若 \(P\ge0\) 且非零，存在
\(1<r_1<r_2\) 使 \(Q_\sigma(r)\) 在
\([r_1,r_2]\) 上严格为正。取平方自由的 \(a,b\) 满足
\(r_1\le a/b\le r_2\)，其数量在 \(a,b\le A\) 时为
\(\gg A^2\)。于是 ratio-tail 的绝对值部分至少包含

$$
\sum_{a\le A}a^{-2\sigma}\,A
\asymp
\sum_{a\le A}a^{1-2\sigma},
\tag{6}
$$

在 \(\sigma\le1\) 不可能有绝对收敛。

## 3. 对 RH 算术门的定位

完整 product sum \(U_V(x)=\sum_n\mu(n)V(n/x)\) 的 Mellin 变换可以利用
\(\mu*1=\varepsilon\) 坍缩到 \(K(s)/\zeta(s)\)；sharp half-lattice 的
\(\mathcal T_P(s)\) 则多出式 (2) 的 ratio-tail。故两者之间的差异不是
“再提高一个 endpoint order”即可消除的。

要把 \(T_P\) 推进到平方根界，必须直接对式 (2) 的 ratio-tail 做 signed
\(\mu(a)\mu(b)\) 估计，或构造一个保留 reciprocal reflection 的跨尺度
intertwiner。逐项取绝对值、只利用 \(P(y)\) 的高阶衰减，均停在
\(\operatorname{Re}s>1\) 的初始区。

更精确地，若某个平方根级估计
\(T_P(x)\ll_\varepsilon x^{1/2+\varepsilon}\) 成立，则
\(\mathcal T_P(s)\) 由 Mellin--Abel 延拓到
\(\operatorname{Re}s>1/2+\varepsilon\)。于是式 (2) 的 ratio-tail 必须在
该区域精确抵消对角项
\(\zeta(s)K(s)\zeta(2s)/\zeta(4s)\) 所有不允许的奇点；这不是一个
绝对收敛问题，而是一个 RH-strength 的 signed analytic continuation
命题。该表述把“cutoff intertwiner”具体化为一个可检验的 Dirichlet 尾
延拓/增长条件。

本文只给出 exact Mellin 分解与收敛边界，不声称 RH。
