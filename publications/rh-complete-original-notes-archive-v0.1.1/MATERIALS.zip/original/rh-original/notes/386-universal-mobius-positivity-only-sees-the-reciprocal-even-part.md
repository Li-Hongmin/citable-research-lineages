> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Universal Möbius positivity 只看 reciprocal-even 部分

## 定理

设 \(\phi:(0,\infty)\to\mathbb R\) 连续，并满足
\[
\lim_{u\downarrow0}\phi(u)=\lim_{u\to\infty}\phi(u)=0.
\]
定义
\[
Q_\phi(X):=
\sum_{a,b\mid X}\mu(a)\mu(b)\phi(ab/X)
\]
（\(X\) 取平方自由整数），以及
\[
\phi^\vee(u):=\phi(1/u),\qquad
\phi_{\mathrm e}(u):=\frac{\phi(u)+\phi(1/u)}2.
\]
若
\[
Q_\phi(X)\ge0\qquad\text{对所有平方自由 }X,
\tag{1}
\]
则
\[
\boxed{\phi_{\mathrm e}\equiv0.}
\tag{2}
\]
特别地，若 \(\phi(1/u)=\phi(u)\)，则 \(\phi\equiv0\)；若
\(\phi(1/u)=-\phi(u)\)，则 \(Q_\phi(X)\equiv0\)，该部分不携带任何
Möbius reciprocal 信号。

## 1. Möbius 向量自动消去 reciprocal-odd 部分

对平方自由 \(X\)，补集映射 \(a\mapsto X/a\) 保持
\[
\mu(X/a)=\mu(X)\mu(a)
\]
的乘积关系，因此在二次型中作 \((a,b)\mapsto(X/a,X/b)\) 得
\[
Q_\phi(X)=Q_{\phi^\vee}(X)=Q_{\phi_{\mathrm e}}(X).
\tag{3}
\]
所以 \(Q_\phi\) 只能看到 reciprocal-even 部分。

## 2. 加入大素数的反射递推

固定平方自由 \(Y\)，取不整除 \(Y\) 的素数 \(p\)。逐项展开
\(Yp\) 的四个除数类型，得到
\[
Q_\phi(Yp)
=-2Q_\phi(Y)
+\sum_{d,e\mid Y}\mu(d)\mu(e)
\left[
\phi\!\left(\frac{de}{Yp}\right)
+\phi\!\left(\frac{pde}{Y}\right)
\right].
\tag{4}
\]
两端衰减与 \(D_Y\) 有限保证括号内总和在 \(p\to\infty\) 时趋于零，故
\[
Q_\phi(Yp)=-2Q_\phi(Y)+o_Y(1).
\tag{5}
\]
若 (1) 成立而某个 \(Q_\phi(Y)>0\)，则 (5) 对足够大的 \(p\) 给出
\(Q_\phi(Yp)<0\)，矛盾。因此
\[
Q_\phi(Y)=0\qquad\text{对所有平方自由 }Y.
\tag{6}
\]

## 3. 两素数尺度恢复核的 even 部分

先取 \(Y=p\) 为素数。由 (6)
\[
0=Q_\phi(p)=\phi(1/p)-2\phi(1)+\phi(p).
\]
令 \(p\to\infty\)，得 \(\phi(1)=0\)。再取互异素数
\(r_j,q_j\to\infty\) 且 \(r_j/q_j\to u\in(0,\infty)\)
（\(r_j<q_j\) 或 \(r_j>q_j\) 按 \(u<1\) 或 \(u>1\) 选择）。
逐项展开 \(X_j=r_jq_j\)，
再用两端衰减，得到
\[
0=\lim_jQ_\phi(r_jq_j)
=\phi(u)+\phi(1/u).
\tag{7}
\]
因 \(u\) 任意，(7) 正是 \(\phi_{\mathrm e}\equiv0\)。

## 对 RH 算术桥的含义

任何企图把完整 reciprocal Möbius 门普遍正化的连续核，只有两种可能：

1. reciprocal-even 部分非零：定理说明某个平方自由尺度必出现负门；
2. 只剩 reciprocal-odd 部分：式 (3) 说明它在实际 Möbius 二次型上恒为零，
   因而同时丢失 RH 的 reciprocal 信号。

这把 note 384 的紧支撑 no-go 推广到两端衰减的非紧核，并明确指出：
真正的 RH 桥不能是固定连续核的 universal PSD；必须是保留跨尺度
signed/reflection 的非平凡算术算子。

本定理不声称 RH。
