> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一个十六次正 detector 同时消去四个 collective residues

日期：2026-08-15。

相关背景：[note 144](144-a-positive-degree-fifteen-detector-removes-four-collective-residues.md)、
[note 141](141-a-minimal-degree-twelve-positive-detector-removes-three-collective-residues.md)。

证据等级：精确 Mellin 变换与 Bernstein--falling-factorial 正证书。

本 note 构造一个全半轴逐项非负的十六次 detector，同时消去
\(s=-1,-3,-5,-7\) 四个 odd Mellin residues。它是一个独立的十六次正证书；
次数十五的更低阶实现见 note 144，因此本 note 不主张次数最小性。

## 1. Detector 与 Mellin numerator

令

\[
\boxed{
V_{16}(u)=
-\frac{u^2(1-u)^9}{287232}
\bigl(287232u^5-287232u^4-73755u^3+11405u^2+6615u+735\bigr)}
\tag{1}
\]

于区间外作零延拓。直接展开或 Beta 积分给出

\[
V_{16}(0)=V_{16}(1)=0,qquad
\int_0^1V_{16}(u)\,du=0,
\tag{2}
\]

\[
v_1=v_3=v_5=v_7=0,
\tag{3}
\]

其中 \(v_j=[u^j]V_{16}\)。其 Mellin 变换为

\[
\boxed{
K_{16}(s)=
\frac{9450(s-1)(125s+9168)}{
17(s+2)(s+4)(s+6)(s+8)(s+9)(s+10)(s+11)(s+12)
(s+13)(s+14)(s+15)(s+16)}.}
\tag{4}
\]

唯一额外零点 \(-9168/125\) 位于临界带左侧，故

\[
K_{16}(s)\ne0qquad(1/2<\Re s<1).
\tag{5}
\]

## 2. 全半轴正性

定义

\[
P_{16}(y)=\sum_{c\le y}V_{16}(c/y),qquad y\ge1.
\tag{6}
\]

写 \(y=N+r\)，其中 \(N=\lfloor y\rfloor\ge1\)、\(0\le r<1\)，并令
\(m=N-1\)。精确 Faulhaber 求和可写成

\[
P_{16}(N+r)=
\frac{N(N+1)}{(N+r)^{16}}Q_N(r),
\tag{7}
\]

其中 \(Q_N\) 是十四次多项式。令

\[
\beta_{k,14}(r)=\binom{14}{k}r^k(1-r)^{14-k},
\qquad
m^{\underline j}=m(m-1)\cdots(m-j+1).
\tag{8}
\]

则有精确展开

\[
Q_N(r)=\sum_{k=0}^{14}b_k(m)\beta_{k,14}(r),
\qquad
b_k(m)=\frac1{L_k}\sum_{j=0}^{5}c_{k,j}m^{\underline j},
\tag{9}
\]

其中下表给出 \((L_k;c_{k,0},\ldots,c_{k,5})\)：

\[
\begin{array}{c|r|rrrrrr}
k&L_k&c_{k,0}&c_{k,1}&c_{k,2}&c_{k,3}&c_{k,4}&c_{k,5}\\ \hline
0&8616960&0&1808260&173490785&265811557&77037800&5502700\\
1&60318720&0&21232270&1507863470&2034165349&558540650&38518900\\
2&784143360&0&459394585&24080071535&28842498937&7515082100&500993200\\
3&784143360&0&758016585&29248545735&31387304992&7772979095&501488200\\
4&196035840&0&309688440&8777838540&8518523773&2008511945&125538925\\
5&196035840&0&500630205&10412546235&9222083923&2074080980&125711425\\
6&98017920&0&399677140&6104438580&4975819399&1069599765&62921025\\
7&14002560&0&89873020&1011585765&764332102&157363500&8992200\\
8&98017920&0&973750240&8139047205&5732255539&1132636110&62921025\\
9&196035840&9375&2954410305&18578128710&12242938903&2325818895&125711425\\
10&196035840&220020&4376157900&21099610455&13040585593&2385350430&125538925\\
11&784143360&7590255&25228424625&95550012045&55460850712&9779107905&501488200\\
12&784143360&40569555&35300790525&107928354520&58897672537&10019679900&500993200\\
13&60318720&12250110&3688113450&9356989765&4807127749&789620850&38518900\\
14&8616960&5424780&695771400&1502548570&728038357&115556700&5502700
\end{array}
\tag{10}
\]

每个 \(L_k>0\)，表中所有 \(c_{k,j}\ge0\)，且 \(m^{\underline j}\ge0\) 对整数
\(m\ge0\) 成立。因此 \(b_k(m)\ge0\)，再由 Bernstein 基函数非负得到

\[
\boxed{P_{16}(y)\ge0\qquad(y\ge1).}
\tag{11}
\]

这是一份纯有理、无数值采样的全半轴证书。

## 3. 正 reciprocal-product RH 门

令

\[
U_{16}(x)=\sum_{n\ge1}\mu(n)V_{16}(n/x),
\]

\[
T_{16}(x)=
\sum_{a,b\le\sqrt x}
\mu(a)\mu(b)P_{16}\!\left(\frac{x}{ab}\right).
\tag{12}
\]

精确截断卷积恒等式与 \(V_{16}(u)=O(u^2)\) 给出

\[
T_{16}(x)=-U_{16}(x)+O(x^{-1/2}).
\tag{13}
\]

结合 (4)--(5) 的 Mellin detector 定理，得到

\[
\boxed{
\mathrm{RH}\iff
\forall\varepsilon>0,
\quad T_{16}(x)\ll_{\varepsilon}x^{1/2+\varepsilon}.}
\tag{14}
\]

同样可替换为对应 dyadic \(L^2\) 门。

## 4. 四个 residue 的移位

首批非零 odd 系数为

\[
v_9=-\frac{5745}{68},\quad
v_{11}=-\frac{7793}{34},\quad
v_{13}=-\frac{264005}{2244},\quad
v_{15}=-10.
\tag{15}
\]

若 \(S_k(z)=\sum_{a\le z}a^k\mu(a)\)，则完整 collective 分解为

\[
\boxed{
T_{16}(x)=
\frac{1915}{2992}\frac{S_9(\sqrt x)^2}{x^9}
-\frac{5384963}{1113840}\frac{S_{11}(\sqrt x)^2}{x^{11}}
+\frac{264005}{26928}\frac{S_{13}(\sqrt x)^2}{x^{13}}
-\frac{3617}{816}\frac{S_{15}(\sqrt x)^2}{x^{15}}
+T_{16}^{(0)}(x),}
\tag{16}
\]

其中 \(T_{16}^{(0)}\) 的周期系数均值为零。故正性又向左删除了一个
RH-strength collective residue，但未消除完整 signed Möbius cancellation 的核心困难。

## 5. 边界

次数十五的正 detector 已由 note 144 给出，因此这里不作最小次数断言。该结果不是 RH 的证明：仍需控制 (14) 中的完整 signed quadratic form，
不能分别对 (16) 的四个平方项或 \(T_{16}^{(0)}\) 取绝对值。
