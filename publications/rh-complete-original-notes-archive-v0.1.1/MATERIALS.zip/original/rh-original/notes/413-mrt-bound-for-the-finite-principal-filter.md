> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 413. MRT 对有限主部滤波器的直接上界

note 408 的有限系数并不是普通的截断 Möbius 向量，而是
\[
a_m^{(Y)}=2\mu(m)\mathbf 1_{m\le Y}
 -\mathbf 1_{2\mid m}\mu(m/2)\mathbf 1_{m\le2Y}.
\tag{1}
\]
本 note 把它精确分解为三个 Lehmer 型二次项，并说明现有
Matomäki--Radziwiłł--Tao (MRT) 差值分块定理可直接给出一个独立的
对数级上界；这不是平方根级结果。

## 1. 三项分解

令
\[
L_N(m,n)=\frac{\min(m,n)}{\max(m,n)},
\qquad N=2Y,
\]
并令
\[
u_m=\mu(m)\mathbf 1_{m\le Y},
\qquad
v_m=\mathbf 1_{2\mid m}\mu(m/2)\mathbf 1_{m\le2Y}.
\]
由 note 409，
\[
Q_w(\mu_{\le Y})=\frac12(2u-v)^T L_N(2u-v),
\]
即
\[
Q_w=2u^TL_Nu-2u^TL_Nv+\frac12v^TL_Nv.
\tag{2}
\]
第二个纯项因 $v_{2k}=\mu(k)$ 且
$L_N(2k,2\ell)=L_Y(k,\ell)$，严格满足
\[
v^TL_Nv=\boldsymbol\mu_Y^T L_Y\boldsymbol\mu_Y.
\tag{3}
\]

## 2. 对三项应用差值分块

note 350 的差值 dyadic 分块适用于任意固定尺度比的两个 dyadic 块；
其输入是 MRT Theorem 1.6 的式 (1.11)，第一因子为 $\mu$，第二因子
可为任意 $1$-bounded 函数。因此有
\[
u^TL_Nu\ll Y^2\rho(Y)+Y\log Y,
\qquad
v^TL_Nv\ll Y^2\rho(Y)+Y\log Y,
\tag{4a}
\]
其中
\[
\rho(Y)=\frac{\log\log Y}{\log Y}+\frac1{\log^{1/3000}Y}.
\]

交叉项只涉及 $m\le Y$、$k\le Y$，其核为
\(L_N(m,2k)\)。先作精确的三段拆分：
\[
L_N(m,2k)=
\begin{cases}
\frac12\,\frac{m}{k},&k\ge m,\\[1mm]
\frac12\,\frac{m}{k},&m/2<k<m,\\[1mm]
2\,\frac{k}{m},&k\le m/2.
\end{cases}
\tag{4b}
\]
（边界等号任取一侧，只有 $O(Y)$ 项。）第一段令 $h=k-m$，于是
$m/k=1-h/k$；第二段令 $h=m-k$，于是 $m/k=1+h/k$，且此时
$0<h<k$。把 $h$ 按 $H<h\le2H$ 分段，并写
\[
\frac{h}{k}=\frac{H}{k}+\frac{h-H}{H}\frac{H}{k},
\]
其中 $H/k$ 是第二变量的 $1$-bounded 权，而 $(h-H)/H$ 是外层有界系数；
这正是 note 350 的 MRT 参数化。第三段直接是标准的小者/大者比值
$k/m$。因此按 $(m,k)$ 的 dyadic 块分解，在每个有序区域中交换变量后，
同尺度部分使用 note 350 的差值参数化；尺度比为 $2^d$ 的部分使用
note 349 的两个窗口不重不漏分解。窗口指示函数与上述有界权均落在 MRT
允许的范围内，故同样得到
\[
|u^TL_Nv|\ll Y^2\rho(Y)+Y\log Y.
\tag{5}
\]
这里没有逐项取 $L_N$ 的绝对值；每个块内部保留了 MRT 的 signed 移位平均。

## 3. 主部的独立无条件基线

将 (3)--(5) 代入 (2)，得到
\[
\boxed{
Q_w(\mu_{\le Y})
 \ll Y^2\left(\frac{\log\log Y}{\log Y}
 +\frac1{\log^{1/3000}Y}\right)+Y\log Y .}
\tag{6}
\]
这是对 note 409 主部的直接算术上界，不依赖 note 412 的 PNT 零自由区余项。
数值上它比 note 412 的 $Y^2e^{-c\Lambda(Y)}$ 弱，但它明确验证了
主部滤波器的三项交叉结构没有隐藏的“普通 $\mu$ 向量”假设。

## 4. 与 RH 门的关系

式 (6) 仍然只是 $Y^{2-o(1)}$，不能推出 note 410 所需的
$Y^{1+\varepsilon}$。若把 MRT 的对数节省替换成固定幂次
$\rho(Y)\ll Y^{-\delta}$，同一分解才会给出固定幂次能量改进，随后由
note 412 §5 转化为固定零自由线。现有 MRT 输入本身不跨越这一门。
