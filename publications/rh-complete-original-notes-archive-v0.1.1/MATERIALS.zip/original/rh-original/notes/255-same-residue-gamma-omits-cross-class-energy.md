> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# same-residue Gamma 不是完整 shell energy：跨 class 交叉项不可省略

日期：2026-08-16。

## 有限代数事实

设一个完成 shell 的 packet/root 数据被分成有限个 residue/frozen class，记

\[
 c_\alpha=\sum_{\xi\in X_\alpha}w_\xi e(\phi_\xi),
 \qquad c_\eta=\sum_\alpha c_\alpha .
\]

则精确恒等式是

\[
 |c_\eta|^2
 =\sum_{\alpha,\beta}c_\alpha\overline{c_\beta}
 =\sum_\alpha|c_\alpha|^2
  +\sum_{\alpha\ne\beta}c_\alpha\overline{c_\beta}.
\tag{1}
\]

若把同一 residue/class 内的 pair 归并成
\(\Gamma_{\eta,r,\ell}\)，它至多直接描述第一项的某些对角块；完整平方能量还需要
所有不同 residue/class 的交叉块。源码中 Gamma 的索引只有同一 residue \(r\) 和
同一 frozen pair class \(\ell\)，没有 \((r',\ell')\) 的双重索引，因此不能从定义
自动得到 (1) 的完整右端。

## 最小反例

取两个 class，各自只有一个单位振幅：\(c_1=c_2=1\)。完整 shell energy 为
\(|c_1+c_2|^2=4\)，而只保留同 class 对角项得到
\(|c_1|^2+|c_2|^2=2\)；缺失的交叉贡献正是
\(c_1\overline{c_2}+c_2\overline{c_1}=2\)。若相位相反，完整能量为零而对角和仍为 2，
说明这些交叉项不能以符号无关的方式删除或取绝对值。

## 对原稿接口的限制

这条观察不否定原稿可能存在某个尚未写出的线性 contraction，使 pair sum 表示线性
\(c_\eta\)；它只说明：一旦把 \(W_{\xi_1,\xi_2}\) 解释成与
\(|c_\eta|^2\) 相容的 Hermitian 自相关，就必须同时定义

1. 所有 residue/class 交叉权；
2. 共轭、相位和归一化约定；
3. 交叉块在 packet/capacity 预算中的控制。

因此，现有 same-residue Gamma 的 support、\(\ell^1\)、sup 和 total-variation 估计，
即使逐项正确，也不能单独推出 cellwise energy
\(\mathcal E^X_\eta=|c_\eta|^2\)。这把原稿的缺口进一步定位为“完整 pair kernel / cross-class
contraction”缺失，而不仅是低频零矩或 harmonic 包络问题。

## 结论

该结论是有限维代数恒等式，不依赖 RH、Möbius 估计或任何数值外推。修复原稿前，
应先给出完整 pair kernel 的索引集合和 contraction 公式，再重新核对 Theorem 19.216
的 primal energy 定义；否则从 Gamma 估计到 RH 的链条仍不成立。
