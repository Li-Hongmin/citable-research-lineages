> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 多移位 Chowla 平均不能抽出 Lehmer 的平行四边形薄片

日期：2026-08-17。

## 1. 相关文献输入

* Averages of the Möbius Function on Shifted Primes* 的 Theorem 1.3 给出多移位平均：对
固定的 Möbius 因子数 \(m\ge1\)，在独立移位
\(h_1,\ldots,h_m\le H\) 上求和，得到 \(XH^m\) 乘以对数级节省；定理还允许与固定的 von Mangoldt 因子相乘。来源：
<https://academic.oup.com/qjmath/article/73/2/729/6446139?login=true>。

这是当前固定移位 Chowla 的重要平均结果，但它的平均域是整个 \(m\)-维移位盒子。

## 2. Lehmer 四点门所在的子集

note 434 中平方展开的核心是
\[
 \mu(n)\mu(n+h)\mu(n+d)\mu(n+d+h).
\tag{1}
\]
把四个相对移位写成
\[
 (h_1,h_2,h_3,h_4)=(0,h,d,h+d),
\tag{2}
\]
可见目标只落在四维移位盒子中的一个平行四边形子集
\[
 h_4-h_2-h_3+h_1=0.
\tag{3}
\]
在 \(1\le h_j\le H\) 的尺度上，整个盒子有 \(H^4\) 个点，而 (3) 的结构化子集只有 \(O(H^2)\) 个点。Theorem 1.3 的总绝对值平均允许这条薄片成为异常集合；直接丢弃其余 \(H^4-O(H^2)\) 个点，不能得到薄片上的任何非平凡上界。

## 3. 为什么 Cauchy 不能恢复薄片

即使把四点平均写成
\[
 \sum_{h_1,h_2,h_3,h_4\le H}
 \left|\sum_n\prod_{j=1}^4\mu(n+h_j)\right|,
\tag{4}
\]
并假设它有 \(H^4\rho(X,H)\) 的对数节省，(4) 对平行四边形片的唯一直接结论仍是
\[
 \sum_{h,d\le H}\left|\sum_n
 \mu(n)\mu(n+h)\mu(n+d)\mu(n+d+h)\right|
 \ll XH^4\rho(X,H),
\]
这比目标的结构化二阶均方或 \(H^{-1}\) 门弱得多。Cauchy、Markov 或逐项 \(|\mu|\le1\) 只会把薄片损失重新转成 \(H^2\) 或 \(H^4\) 的体积因子，不能制造平行四边形约束带来的额外消去。

## 4. 当前裁决

该文献说明“任意阶、多移位的平均 Chowla”是真实可用的背景输入，但尚未给出沿加法关系 (3) 的结构化四点估计，更没有给出 note 434 所需的移动比值振幅和
\[
 \sum_{H<h\le2H}|C_N(h)|^2\ll N^{2+\varepsilon}/H.
\]
因此当前最小新命题仍是：在平行四边形薄片上证明 uniform signed four-point cancellation，或构造等价的跨移位 intertwiner。它不能由独立移位平均自动推出。
