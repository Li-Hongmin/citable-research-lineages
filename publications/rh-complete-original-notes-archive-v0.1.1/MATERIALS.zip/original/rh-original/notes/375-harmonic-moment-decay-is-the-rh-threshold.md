> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 矩层二次差的 (1/j) 衰减是平方根门槛

## 精确充分条件

沿用 note 373 的记号
\[
B_j(z)=\frac{A_j(z)^2}{z^{2j}},
\qquad
T_j(z^2)=B_j(z)-B_{j+1}(z),
\qquad
A_j(z)=\sum_{n\le z}\mu(n)n^j .
\]
无条件地有
\[
0\le B_j(z)\le \frac{4z^2}{(j+1)^2}.
\tag{1}
\]

假设对某个固定 \(\varepsilon>0\)，所有 \(j\ge0\)（或至少 \(0\le j\le z\)）满足
\[
|T_j(z^2)|\le \frac{C_\varepsilon z^{1+\varepsilon}}{j+1}.
\tag{2}
\]
则对任意 \(J\le z\)，望远镜与 (1) 给出
\[
\begin{aligned}
M(z)^2=B_0(z)
&\le \sum_{j=0}^{J}|T_j(z^2)|+B_{J+1}(z)\\
&\le C_\varepsilon z^{1+\varepsilon}H_{J+1}
 +\frac{4z^2}{(J+2)^2}.
\end{aligned}
\tag{3}
\]
取 \(J=\lfloor z\rfloor\)，便得到
\[
M(z)^2\ll_\varepsilon z^{1+\varepsilon}\log(2z),
\qquad
M(z)\ll_\varepsilon z^{1/2+\varepsilon}.
\tag{4}
\]
最后一步吸收平方根的对数因子到任意稍大的 \(\varepsilon\) 中。因此，
\[
\boxed{
|T_j(z^2)|\ll_\varepsilon z^{1+\varepsilon}(j+1)^{-1}
\Longrightarrow
M(z)\ll_\varepsilon z^{1/2+\varepsilon}.}
\]

这是一条严格的 RH-strength 充分条件，不是对 (2) 的证明。

## 衰减指数的连续标度

更一般地，若
\[
|T_j(z^2)|\le C z^{1+\varepsilon}(j+1)^{-\alpha},
\tag{5}
\]
则
\[
M(z)^2\ll z^{1+\varepsilon}
\begin{cases}
J^{1-\alpha}+1,&0\le\alpha<1,\\
\log(2J),&\alpha=1,\\
1,&\alpha>1,
\end{cases}
 +\frac{z^2}{J^2}.
\tag{6}
\]
当 \(0\le\alpha<1\) 时，平衡两项给出
\[
M(z)\ll z^{(2-\alpha)/(3-\alpha)+\varepsilon}.
\tag{7}
\]
指数随 \(\alpha\) 单调下降，并在 \(\alpha\uparrow1\) 时趋近 \(1/2\)。
在临界值 \(\alpha=1\) 处，(4) 给出平方根级（允许对数因子）。所以 note 374 的等权假设对应 \(\alpha=0\) 与 \(2/3\) 恰好一致，而越过 \(2/3\) 的最小定量目标就是一个 harmonic \(1/(j+1)\) 衰减。

## 算术缺口

条件 (2) 不能由 \(B_j\le4z^2/(j+1)^2\) 自动推出：后者只控制单个矩模式，不能控制相邻模式的差。要证明 (2)，至少需要一个跨 \(j\) 的 signed 估计；例如把
\[
T_j(z^2)=\frac{A_j(z)^2}{z^{2j}}-\frac{A_{j+1}(z)^2}{z^{2j+2}}
\]
与 \(A_j\) 的 Abel/partial-summation 关系联立，并获得随 \(j\) 衰减的相关项。现有 notes 373–374 的正核包络没有提供这一点，incomplete-lcm boundary 也尚未被消除。

因此本 note 把下一步变成一个明确、可证伪的算术问题：证明或否证 (2)；若只能得到 \((j+1)^{-\alpha}\)（\(\alpha<1\)），则 (7) 给出对应的最优 Mertens 指数。
