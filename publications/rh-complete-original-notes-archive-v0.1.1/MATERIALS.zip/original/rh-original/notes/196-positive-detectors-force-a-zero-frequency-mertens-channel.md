> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正 detector 必然保留零频 Mertens 通道

日期：2026-08-15。

本 note 给出一个与 detector 次数无关的严格边界：只要 periodization 非零且
逐点非负，就不可能把其 boundary Fourier 权重在 ξ=0 消掉。

## 1. Mellin 零频恒等式

设 V 满足端点平坦条件，使

    P(y) = Σ_{c≤y} V(c/y) = O(y^(−1−δ))       (y→∞)

对某个 δ>0；设 P(y)≥0 且不恒为零。沿用 reciprocal kernel 的 Mellin 恒等式

    I(s) := ∫₁∞ P(y)y^(−s−1)dy = ζ(s)K(s).

左端在 Re s>−δ 全纯，故可在 s=0 取值。由 ζ(0)=−1/2，

    K(0) = I(0)/ζ(0)
         = −2 ∫₁∞ P(y)dy/y < 0.                (1)

若 g(t)=(p(t)+p(−t))/2、h=ĝ，且 p(t)=1_{t≥0}P(e^t)，则

    h(0)=∫_R g(t)dt = ∫₁∞ P(y)dy/y = −K(0)/2 > 0

（Fourier 归一化若采用无 2π 的约定，只改变最后常数，不改变严格正号）。

所以任何非零正 detector 都在 ξ=0 保留一个开放正邻域；提高 detector 次数、
消去更多 odd Mellin residues 或增加正 Schur 层都不能改变这个事实。

## 2. 对正能量门的量化后果

记

    F_N(ξ)=Σ_{n≤N} μ(n)n^(iξ),    M(N)=F_N(0),
    E_N=(1/(2π))∫ |h(ξ)| |F_N(ξ)|²dξ.

由 h(0)>0 的连续性，存在 δ₀>0、c₀>0，使
|h(ξ)|≥c₀ 对 |ξ|≤δ₀。另一方面

    |F_N'(ξ)| ≤ Σ_{n≤N} log n ≤ N log N.

当 N 足够大时，取
\(\delta=|M(N)|/(2N\log N)\le\delta_0\)，则
|F_N(ξ)|≥|M(N)|/2（|ξ|≤δ）。因此

    E_N ≥ c₀ |M(N)|³/(16π N log N).             (2)

（若 δ>δ₀，直接取 δ₀ 得到更强的二次下界。）

于是正能量门 E_N≪ε N^(1+ε) 至多推出

    M(N) ≪ε N^(2/3+ε)(log N)^(1/3),            (3)

这正是低频 Lipschitz/局部化方法的 2/3 障碍，而不是 RH 所需的
N^(1/2+ε)。要跨越 2/3，必须控制 F_N 在整个低频邻域的 signed
variation 或提供新的 arithmetic intertwiner；仅增加 detector 的正性、
次数或 Schur rank 不足以完成。

更精确地，固定 δ₀ 的低频 Gram 为

    G_{δ₀}(m,n)=∫_{−δ₀}^{δ₀}e^(iξ(log m−log n))dξ
      = 2 sin(δ₀ log(m/n))/log(m/n).

它是正半定 Gram，且
\[
E_N\ge c_0(2\pi)^{-1}\,\mu_N^*G_{\delta_0}\mu_N .
\]
若想由此直接恢复 |M(N)|²，必须另证有限维评价常数
\( \mathbf1^*G_{\delta_0}^{\dagger}\mathbf1\) 的统一上界；对密集的
\(\log n\) 频率，这不是由 h(0)>0 自动得到的独立 RKHS 命题。

本 note 是严格的不可能绕过与量化下界，不是 RH 的否定。需要区分量词：
式 (3) 只针对固定 \(N\) 的点值局部化；若正能量门对所有截断统一成立，
可在 \(\max_{x\le X}|M(x)|\) 的最大点使用 Abel 部分求和，直接恢复
\(X^{1/2+\varepsilon}\)（见 note 246）。因此真正未解的仍是正能量门本身，
而不是它推出 Mertens 界时的固定-\(N\) \(2/3\) 估计。
