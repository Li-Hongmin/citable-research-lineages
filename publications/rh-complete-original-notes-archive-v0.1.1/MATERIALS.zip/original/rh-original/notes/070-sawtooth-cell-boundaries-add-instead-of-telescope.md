> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# sawtooth cells 的共享边界同号相加而非望远镜消去

日期：2026-08-12。

依赖：[note 064](064-selberg-affine-first-shell-rh-criterion.md)、
[note 065](065-barban-vehov-hminus1-obstruction-and-weak-mertens-bridge.md)、
[note 069](069-gcd-completion-cancels-the-fixed-slice-antidiagonal.md)。

## 1. 弄清问题

note 069 把 complete high block 化为有限个

\[
\sum_{A<d\le B}a_d
\left(\frac{tN}{d}-n-\frac12\right),
\qquad
a_d:=\mu(d)\log(N/d).
\tag{1}
\]

本轮只判别

\[
\boxed{
\text{相邻 }n\text{-cells 的 }\pm\frac12\text{ 端点是否精确 telescope？}
}
\tag{2}
\]

```mermaid
flowchart LR
  A["cell n: upper −A/2"] --> C["shared boundary"]
  B["cell n−1: lower −A/2"] --> C
  C --> D["total −A, not 0"]
  D --> E["finite moving samples A(floor(tN/n))"]
  E --> F["full n-sum = log N + ψ"]
```

## 2. 拟定计划

\[
\text{cellwise Stieltjes}
\longrightarrow
\text{exact discrete Abel}
\longrightarrow
\text{jump-packet tiling}
\longrightarrow
\mu*1,\ -\mu*\log=\Lambda.
\tag{3}
\]

## 3. 实现计划

### 3.1 精确离散 Abel--packet 恒等式

令

\[
1\le p<q\le N,
\qquad
A_m:=\sum_{d=p}^{m}a_d,
\qquad
b_m(t):=\beta(tN/m).
\tag{4}
\]

离散 Abel 求和逐点给出

\[
\boxed{
\sum_{d=p}^{q}a_db_d(t)
=A_qb_q(t)+\sum_{m=p}^{q-1}A_m\bigl(b_m(t)-b_{m+1}(t)\bigr).
}
\tag{5}
\]

置

\[
\delta_m:=\frac{N}{m(m+1)},
\qquad
J_{m,n}:=
\left[\frac{nm}{N},\frac{n(m+1)}N\right).
\tag{6}
\]

由 \(\{x\}=x-\lfloor x\rfloor\)，严格有

\[
\begin{aligned}
b_m(t)-b_{m+1}(t)
&=t\delta_m-
\left(\left\lfloor\frac{tN}{m}\right\rfloor
-\left\lfloor\frac{tN}{m+1}\right\rfloor\right)\\
&=t\delta_m-
\sum_{n\ge1}\mathbf1_{J_{m,n}}(t).
\end{aligned}
\tag{7}
\]

故

\[
\boxed{
\sum_{d=p}^{q}a_d\beta(tN/d)
=A_q\beta(tN/q)
+t\sum_{m=p}^{q-1}\delta_mA_m
-\sum_{n\ge1}\sum_{m=p}^{q-1}
A_m\mathbf1_{J_{m,n}}(t).
}
\tag{8}
\]

若 \(p\ge\alpha N\) 且 \(t\in[1,2]\)，则 (8) 中只有

\[
1\le n\le K_\alpha:=\lceil2/\alpha\rceil
\tag{9}
\]

可能出现。对每个固定 \(n\)，区间 \(J_{m,n}\) 随 \(m\) 首尾相接且内部互不相交。

### 3.2 共享端点不消去

固定 \(y=tN\)，第 \(n\) 个 floor-cell 为

\[
\left(\frac{y}{n+1},\frac yn\right],
\qquad
w_n(x):=\frac yx-n-\frac12.
\tag{10}
\]

其上下端点值为

\[
w_n(y/(n+1))=+\frac12,
\qquad
w_n(y/n)=-\frac12.
\tag{11}
\]

在共享端点 \(x_n=y/n\)，cell \(n\) 的上端贡献为
\(-A(x_n)/2\)；cell \(n-1\) 的下端在分部积分中带负号，贡献仍为
\(-A(x_n)/2\)。因此

\[
\boxed{
-\frac12A(x_n)-\frac12A(x_n)=-A(x_n)\ne0.
}
\tag{12}
\]

这正是 (7) 的 floor jump。所谓相邻 \(+1/2,-1/2\) 并不 telescope；
忽略 Stieltjes 下端的负号才会产生假消去。

### 3.3 等价的复合梯形误差

为精确显示 cell 内仍可能存在的联合消去，改用物理截断

\[
\ell<d\le q,
\qquad
\mathcal A(x):=\sum_{d\le x}a_d,
\qquad
X:=tN.
\]

令

\[
y_0:=X/q,
\qquad
y_1:=X/\ell,
\qquad
G_X(v):=\mathcal A(X/v),
\]

并定义整数点左值

\[
\beta_-(u):=lim_{\varepsilon\downarrow0}\beta(u-\varepsilon).
\]

cellwise Stieltjes 分部积分与变量 \(v=X/x\) 给出

\[
\boxed{
\begin{aligned}
\sum_{\ell<d\le q}a_d\beta(X/d)
={}&\int_{y_0}^{y_1}G_X(v)\,dv
-\sum_{y_0<k<y_1}G_X(k)\\
&+\beta(y_0)G_X(y_0)
-\beta_-(y_1)G_X(y_1).
\end{aligned}
}
\tag{12a}
\]

特别地，对完整 cell \(X/(n+1)<d\le X/n\)，

\[
\boxed{
C_n
=\int_n^{n+1}G_X(v)\,dv
-\frac{G_X(n)+G_X(n+1)}2.
}
\tag{12b}
\]

故 cell 算子是“积分减梯形求积”，消去仿射 \(G_X\)。但其精确误差测度为

\[
d\nu_{X,I}
=\mathbf1_{(y_0,y_1)}(v)\,dv
-\sum_{y_0<k<y_1}\delta_k
+\beta(y_0)\delta_{y_0}
-\beta_-(y_1)\delta_{y_1}.
\tag{12c}
\]

点质量系数仍为 \(-1\)。而 \(G_X(v)=\mathcal A(X/v)\) 在一个单位
\(v\)-cell 内跨过 \(\asymp_I N\) 个整数跳跃，不能套用光滑函数的经典梯形误差界。
(12b) 是一个真实的联合结构，但不是自动正则化。

### 3.4 packet tiling 给出的最强直接 \(L^2\) 上界

由固定 \(n\) 时 \(J_{m,n}\) 不交，

\[
\int_1^2
\left|\sum_{m=p}^{q-1}A_m\mathbf1_{J_{m,n}}(t)\right|^2dt
\le\frac nN\sum_{m=p}^{q-1}|A_m|^2.
\tag{13}
\]

另一方面，若 \(p\ge\alpha N\)，则

\[
\sum_{m=p}^{q-1}\delta_m
=N\left(\frac1p-\frac1q\right)\ll_\alpha1,
\qquad
\max_m\delta_m\ll_\alpha N^{-1}.
\tag{14}
\]

Cauchy--Schwarz、(8)--(14) 遂给出

\[
\boxed{
\int_1^2
\left|\sum_{d=p}^{q}a_d\beta(tN/d)\right|^2dt
\ll_\alpha
|A_q|^2+\frac1N\sum_{m=p}^{q-1}|A_m|^2.
}
\tag{15}
\]

取 \(a_d=\mu(d)\log(N/d)\)，则 hard high block 满足

\[
\boxed{
\int_1^2|F_{I,N}(t)|^2dt
\ll_I\frac1{L^2}
\left(
|A_q|^2+\frac1N\sum_{m=p}^{q-1}|A_m|^2
\right).
}
\tag{16}
\]

packet 正交只把问题降为 dyadic weighted-Mertens 均方；它不自动估计这些系数。
特别地，(MI) 的直接充分尺度仍是

\[
|A_q|^2=o(NL^2),
\qquad
\sum_{m=p}^{q-1}|A_m|^2=o(N^2L^2),
\tag{17}
\]

而非仅有 \(A_m=o(N)\) 的素数定理尺度。

### 3.5 完整 packet 求和的唯一 telescope 是 von Mangoldt 卷积

对任意 \(x\ge1\) 定义未在 \(N\) 截断的

\[
\mathcal A_N(x):=
\sum_{d\le x}\mu(d)\log(N/d).
\tag{18}
\]

交换有限双和，得到精确历史恒等式

\[
\begin{aligned}
\sum_{n\le y}\mathcal A_N(y/n)
&=\sum_{k\le y}\sum_{d\mid k}\mu(d)\log(N/d)\\
&=L+\Psi(y),
\end{aligned}
\tag{19}
\]

因为

\[
\sum_{d\mid k}\mu(d)=\mathbf1_{k=1},
\qquad
-\sum_{d\mid k}\mu(d)\log d=\Lambda(k)\quad(k>1).
\tag{20}
\]

对 \(N\le y<2N\)，(8) 的完整内部 jump 项相应为

\[
\boxed{
\sum_{m=1}^{N-1}\mathcal A_N(m)
\left(
\left\lfloor\frac ym\right\rfloor
-\left\lfloor\frac y{m+1}\right\rfloor
\right)
=L+\Psi(y)-\mathcal A_N(y).
}
\tag{21}
\]

因此全部 cells 合并后确有一次 Dirichlet-convolution telescope，但其输出不是零，
而是 \(\Psi(y)\) 与 weighted Mertens tail。把 smooth 与外端点一并恢复，恰返回
note 065 的 \(M\)--\(\Psi\) 首壳恒等式；没有遗漏的第二次消去。

### 3.6 exact Fourier resonance 已被 gcd 校正移除，但近共振仍密集

在 \(L^2\) 意义下

\[
\beta(x)=-\sum_{h\ne0}\frac{e(hx)}{2\pi ih}.
\]

若

\[
\Phi(\xi):=\int_1^2e(\xi t)\,dt,
\qquad
a_d=\mu(d)\log(N/d),
\]

则

\[
\boxed{
\int_1^2|F_{I,N}(t)|^2dt
=\frac1{4\pi^2L^2}
\sum_{d,e}a_da_e
\sum_{h,k\ne0}
\frac{\Phi\!\left(N(h/d-k/e)\right)}{hk}.
}
\tag{F1}
\]

精确共振 \(h/d=k/e\) 等价于
\(h=\ell d/(d,e),k=\ell e/(d,e)\)，故其总贡献恰为

\[
\boxed{
\frac1{12L^2}
\sum_{d,e}a_da_e\frac{(d,e)^2}{de}.
}
\tag{F2}
\]

这正是 notes 065、069 中从 incomplete-lcm boundary 扣除的 gcd 周期项；
它不是剩余障碍。

但非共振只有

\[
\left|\frac hd-\frac ke\right|
=\frac{|he-kd|}{de}
\ge\frac{(d,e)}{de}.
\tag{F3}
\]

当 \((d,e)=1\)、\(d,e\asymp N\) 时，Bézout 给出某些 \(h,k\) 使

\[
|he-kd|=1,
\qquad
N|h/d-k/e|\asymp N^{-1},
\qquad
\Phi=1+O(N^{-1}).
\tag{F4}
\]

故长度为 \(1\) 的 \(t\)-积分不会仅凭相位把全部 off-diagonal 压小；
exact resonance 被扣除后，仍必须处理算术 near-resonance 的联合符号。

## 4. 回顾反思

\[
\boxed{
\begin{array}{c|c}
\text{候选机制}&\text{裁决}\\
\hline
\text{相邻 cell 端点 telescope}&\text{否：共享边界为 }-A\\
\text{完整 cell 求积结构}&\text{积分减梯形；只消去仿射模式}\\
\text{固定-}n\text{ packet 正交}&\text{是：给出 }N^{-1}\sum|A_m|^2\\
\text{完整 }n\text{-sum telescope}&\text{是：输出 }L+\Psi\\
\text{Fourier exact resonance}&\text{已等于并扣除 gcd 校正}\\
\text{Fourier off-diagonal 正交}&\text{否：存在 Bézout 近共振}\\
\text{弱于 Mertens/prime-error 的现成界}&\text{未产生}
\end{array}
}
\tag{22}
\]

故 cellwise telescoping 路线关闭。下一次若继续进攻，不能再拆开估计
smooth packet 与 jump packet；二者承担 note 065 中

\[
(y-\Psi(y))+y(LA_N-1)
-\log(y/N)M(y)+\int_N^y\frac{M(u)}u\,du
\tag{23}
\]

的联合抵消。最小尚未裁决的问题是：该特定联合算子是否存在一个来自
\(\Lambda=-\mu*\log\) 的正交换子或耗散恒等式，而不是另一个逐项 Mertens 界。

本 note 没有证明 (MI) 或 RH。
