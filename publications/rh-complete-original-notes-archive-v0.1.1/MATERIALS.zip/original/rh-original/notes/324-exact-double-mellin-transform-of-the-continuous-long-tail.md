> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 连续长尾的精确双 Mellin 变换：可分离项减去比值核

日期：2026-08-16。

note 323 处理平滑产品窗口。本 note 对 note 310--311 的原始三角尾项
直接做 \(U,X\) 的连续 Mellin 变换，得到一个不依赖近似的分解。

## 1. 连续化的精确尾项

对实数 \(U,X>0\)，定义
\[
 \mathscr B(U,X):=
 \sum_{a,b\ge1}\lambda(a)\lambda(b)
 \mathbf 1_{\{U<a<2U\}}
 \mathbf 1_{\{b<X<b+2U-a\}} .
\tag{1}
\]
当 \(U,X\) 为整数时，严格不等式等价于 note 311 的整数区域，故
\(\mathscr B(U,X)=B_U(X)\)。对 \(p,q>2\) 定义
\[
 \mathcal M(p,q):=
 \int_0^\infty\!\int_0^\infty
 \mathscr B(U,X)U^{-p-1}X^{-q-1}\,dX\,dU .
\tag{2}
\]
绝对收敛可由 \(|\lambda|\le1\) 及下式得到的 \(a^{-p}b^{-q}\) 上界保证。

固定 \(a,b\) 时，条件 \(U<a<2U\) 给出
\(a/2<U<a\)，而 \(b<X<b+2U-a\)。因此
\[
 \int_b^{b+2U-a}X^{-q-1}\,dX
 =\frac{b^{-q}-(b+2U-a)^{-q}}q .
\tag{3}
\]
令 \(v=(2U-a)/a\)，逐项积分得到
\[
\begin{aligned}
 J_{p,q}(a,b)
 &: =\int_{a/2}^{a}U^{-p-1}
       \int_b^{b+2U-a}X^{-q-1}\,dX\,dU \\
 &=\frac{2^p-1}{pq}\,a^{-p}b^{-q}
   -\frac{2^p}{q},a^{-p-q}
     \Phi_{p,q}\!\left(\frac ba\right),
\end{aligned}
\tag{4}
\]
其中正比值核为
\[
 \Phi_{p,q}(r):=
 \int_0^1(1+v)^{-p-1}(r+v)^{-q}\,dv .
\tag{5}
\]

## 2. 精确 Dirichlet 分解

记
\[
 F(s):=\sum_{n\ge1}\frac{\lambda(n)}{n^s}
      =\frac{\zeta(2s)}{\zeta(s)},
 \qquad \Re s>1.
\]
将 (4) 对 \(a,b\) 求和，得到第一层精确恒等式
\[
\boxed{
 \mathcal M(p,q)
 =\frac{2^p-1}{pq}F(p)F(q)
 -\frac{2^p}{q}
  \sum_{a,b\ge1}\lambda(a)\lambda(b)a^{-p-q}
  \Phi_{p,q}(b/a).
 }
\tag{6}
\]
这一步没有把三角区域替换成产品区域；第二项正是三角边界留下的比值核。

对 \(\Phi_{p,q}\) 再作 Mellin 反演。其变换在
\(\max(0,q-1)<\Re z<q\) 内为
\[
 \widehat\Phi_{p,q}(z)
 =B(z,q-z)
   \int_0^1(1+v)^{-p-1}v^{z-q}\,dv,
\tag{7}
\]
因为
\[
 \int_0^\infty r^{z-1}(r+v)^{-q}\,dr
 =v^{z-q}B(z,q-z).
\]
取一条满足 \(1<\sigma<q\) 且 \(\sigma>q-1\) 的竖线（例如
\(q>2\) 时取 \(\sigma=q-\tfrac12\)），绝对收敛给出
\[
\boxed{
 \mathcal M(p,q)
 =\frac{2^p-1}{pq}F(p)F(q)
 -\frac{2^p}{q}\frac1{2\pi i}
  \int_{(\sigma)}\widehat\Phi_{p,q}(z)
  F(z)F(p+q-z)\,dz .
 }
\tag{8}
\]
这里 \(a^{-p-q}(b/a)^{-z}=a^{-p-q+z}b^{-z}\)，故第二项的两个
Dirichlet 因子确实是 \(F(p+q-z)\) 与 \(F(z)\)。

## 3. 零点通道与三角边界

若把比值 Mellin 变量形式上置于对称点
\(z=(p+q)/2\)，算术因子变成
\[
 F\!\left(\frac{p+q}{2}\right)^2
 =\frac{\zeta(p+q)^2}
        {\zeta((p+q)/2)^2}.
\tag{9}
\]
这与 note 323 的 \(\tau=0\) reciprocal-square 通道是同一结构在
\((U,X)\) 变换中的表现。若先把 \(p,q\) 作为复参数作解析延拓，并形式上令
\(p+q=2\rho\)，则该对称点直接命中 \(1/\zeta(\rho)^2\)。原始实参数
公式只在绝对收敛域内成立；把它移到临界带当然需要额外的解析延拓与
截断控制，所以 (9) 本身不是 RH 证明。

另一方面，(8) 也说明为什么不能从完整模型直接推出原始 \(B_U\) 的界：
第二项沿整个 \(z\)-线积分，非对称频率可以与对称 reciprocal-square
通道发生 signed 抵消。逐频率取绝对值会丢掉这项抵消；把第二项替换成
正的完整 \(d(r)\) 权同样不合法。

## 4. 当前最小算术输入

若要从长尾统一界
\(B_U(X)\ll X^{1+\varepsilon}\) 继续走向 RH，至少需要下列两者之一：

1. 对 (8) 的整条比值 Mellin 线建立保持符号的 uniform bound，并控制将
   \(p+q=2\rho\) 推入临界带时的截断误差；或
2. 构造一个跨 \(z\) 的 signed arithmetic intertwiner，使 (8) 中的非对称
   频率不会以普通绝对值损失抵消结构。

固定 \(q\) 的端点已经由 notes 312--313 证明是 RH 等价门；(8) 的作用是
说明即便改用连续 Mellin 平均，剩余对象仍然携带同一 reciprocal-square
结构，而不是一个可由正性自动闭合的新尾项。

## 5. 有限参数调节不能普遍消去离线零点

设 \(\rho\) 是一个满足 \(1/2<\Re\rho<1\) 的零点，并先假设它是简单零点。
把 (8) 的 \(z\)-轮廓从绝对收敛线向左移动、避开
\(\widehat\Phi_{p,q}\) 的显式 Beta 极点时，\(F(z)\) 在 \(z=\rho\) 给出
residue
\[
 -\frac{2^p}{q}\,
 \widehat\Phi_{p,q}(\rho)
 \frac{\zeta(2\rho)}{\zeta'(\rho)}
 F(p+q-\rho).
\tag{10}
\]
对实数 \(p,q>2\)，\(\Re(p+q-\rho)>1\)，所以
\(F(p+q-\rho)\) 有绝对收敛的 Euler 级数且不为零；
\(\zeta(2\rho)\ne0\)。因此唯一可能的自动消失来源是
\(\widehat\Phi_{p,q}(\rho)\)。

但由 (7)，固定 \(q\) 后的解析延拓可写成
\[
 \widehat\Phi_{p,q}(\rho)
 =B(\rho,q-\rho)
  \frac{{}_2F_1(p+1,\rho-q+1;\rho-q+2;-1)}
       {\rho-q+1}.
\tag{11}
\]
除去显式 Gamma/Beta 极点后，这是关于 \(p\) 的非零解析函数：若它在
\(p>2\) 恒等为零，解析延拓到 \(p=-1\) 将给出
\(1/(\rho-q+1)=0\)，矛盾。故其零点至多是离散集合。重零点只把 (10)
换成非零的高阶主部，结论不变。

这给出一个有范围的路线关闭：对每一个给定的离线零点，单窗口参数至多落在
一个离散的消零集合；因此有限维参数自由度本身不能被当作“自动消去任意
零点”的证明。若要同时处理所有零点，仍必须给出额外的全局恒等式、统一的
轮廓界、跨参数的 signed cancellation，或直接构造保留零点响应的算术
intertwiner。

## 6. 对称参数下的非零对角系数

还可以直接检验三角边界是否在对称点把 reciprocal-square 通道的系数
结构性地置零。令 \(p=q=s>2\)，则由 (7)
\[
\begin{aligned}
 \widehat\Phi_{s,s}(s)
 &=B(s,s)\int_0^1(1+v)^{-s-1}\,dv \\
 &=\frac{\Gamma(s)^2}{\Gamma(2s)}
   \frac{1-2^{-s}}s>0 .
\end{aligned}
\tag{12}
\]
故 (8) 中 \(F(z)F(2s-z)\) 在 \(z=s\) 的 reciprocal-square 通道具有
严格非零系数。特别地，三角截断本身并没有一个代数恒等式把该通道消掉；
任何实际抵消都必须来自整条 \(z\)-线的 signed oscillation，而不能归因于
局部边界核的形状。

本 note 给出严格变换和边界定位，不声称证明 RH。
