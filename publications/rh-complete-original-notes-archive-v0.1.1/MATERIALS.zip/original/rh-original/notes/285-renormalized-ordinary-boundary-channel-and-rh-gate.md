> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# ordinary boundary 的共振扣除与余项 RH 门

日期：2026-08-16。

本 note 是 note 284 的精确后续。固定非零频率的完整 ordinary 系数有
\(s=1\pm it\) 极点；把两项显式极点系数扣除后，得到一个自然的
renormalized channel。该 channel 不再含这两个极点，但一般仍保留
\(1/\zeta(s)^2\) 在 zeta 零点处的极点，因此其平方根部分和估计仍是
RH-strength，而不是无条件捷径。

## 1. 定义与精确 Dirichlet 级数

沿用 note 284 的
\[
a_X(t)=\mu(X)|\Phi_X(t)|^2,
\qquad
L(s,t)=\sum_{X\ge1}a_X(t)X^{-s}.
\]
对充分小的固定非零 \(t\)，令
\[
s_+(t)=1+it,\qquad s_-(t)=1-it,
\]
以及极点留数
\[
R_+(t)=
\frac{\zeta(1+2it)S(1+it,t)}{\zeta(1+it)^2},
\qquad
R_-(t)=\overline{R_+(t)}.
\tag{1}
\]
定义
\[
b_X(t):=a_X(t)-R_+(t)X^{it}-R_-(t)X^{-it}.
\tag{2}
\]
因为
\[
\sum_{X\ge1}X^{it}X^{-s}=\zeta(s-it),
\qquad
\sum_{X\ge1}X^{-it}X^{-s}=\zeta(s+it),
\]
其 Dirichlet 级数严格为
\[
B(s,t):=\sum_{X\ge1}b_X(t)X^{-s}
=L(s,t)-R_+(t)\zeta(s-it)-R_-(t)\zeta(s+it).
\tag{3}
\]

## 2. 两个显式共振极点被完全消去

由 note 284，\(L(s,t)\) 在 \(s_+\) 的主部为
\(R_+(t)/(s-s_+)\)，在 \(s_-\) 的主部为
\(R_-(t)/(s-s_-)\)。右端的两个 zeta 项正好具有相同主部，故
\[
B(s,t)\quad\text{在 }s=1+it,1-it\text{ 均可去。}
\tag{4}
\]
这是恒等式，不依赖 Perron 余项估计。

另一方面，利用
\[
L(s,t)=\frac{\zeta(s-it)\zeta(s+it)}{\zeta(s)^2}S(s,t),
\tag{5}
\]
若 \(\rho\) 是 zeta 的零点，且
\[
\zeta(\rho\pm it)S(\rho,t)\ne0,
\tag{6}
\]
则 (3) 的第一项在 \(s=\rho\) 具有来自
\(1/\zeta(s)^2\) 的极点，而两项显式 zeta 反项在 generic \(t\) 下全纯。
因此 renormalized channel 仍保留 zeta 零点信息；(4) 只消除了右侧
边界的两个显式共振，不消除临界带内的 RH 门。

## 3. 平方根余项蕴含 RH

令
\[
B_Y(t):=\sum_{X\le Y}b_X(t).
\]
若对某个 generic \(t\) 有
\[
B_Y(t)\ll_{t,\varepsilon}Y^{1/2+\varepsilon},
\tag{7}
\]
则 Abel 延拓给出
\[
B(s,t)=s\int_1^\infty B_y(t)y^{-s-1}\,dy
\tag{8}
\]
在 \(\Re s>1/2+\varepsilon\) 全纯。结合 (5)--(6)，这排除所有满足
非抵消条件 (6) 的 \(\Re\rho>1/2+\varepsilon\) zeta 零点；对任意假设存在的
离线零点，令 \(t\) 避开其对应的离散异常集合即可。若 (7) 在一个小频率区间
的 generic \(t\) 上统一成立（generic 集合的补集至多可数），便可排除全部
离线零点，令 \(\varepsilon\downarrow0\) 得到 RH。

故 (7) 不是弱于 RH 的中间命题，而是一个明确的 RH-equivalent
renormalized boundary gate。

## 4. 物理端的分解

对任意可积频率权 \(h(t)\)，完整 boundary 聚合可写成
\[
\begin{aligned}
\sum_{X\le B}\mu(X)G_X
&=\frac1{2\pi}\int h(t)\sum_{X\le B}a_X(t)\,dt\\
&=\frac1{2\pi}\int h(t)\sum_{X\le B}b_X(t)\,dt
  +\frac1{2\pi}\int h(t)\left[
    R_+(t)\sum_{X\le B}X^{it}
   +R_-(t)\sum_{X\le B}X^{-it}
  \right]dt.
\end{aligned}
\tag{9}
\]
第二行的两个显式和可用 Euler--Maclaurin 写成
\[
\sum_{X\le B}X^{\pm it}
=\frac{B^{1\pm it}}{1\pm it}+O(1+|t|),
\tag{10}
\]
其主项是 \(B\) 倍的 Fourier 振荡；在 \(t\to0\) 时
\(R_+(t)\sim it/2\)，因此频率积分可获得对数级积分分部消去。

这项分解的意义是结构性的：

* 显式共振项可以单独做频率分析，但不能逐频率取绝对值；
* 余项 \(b_X(t)\) 承载真正的 zeta 零点门；
* 从完整 divisor blocks 回到原始 half-lattice 仍有 cutoff remainder，
  (9) 没有自动消除它。

因此 renormalization 只是把跨频率候选桥分成两个可审计通道，尚未给出
任何无条件平方根估计或 RH 证明。
