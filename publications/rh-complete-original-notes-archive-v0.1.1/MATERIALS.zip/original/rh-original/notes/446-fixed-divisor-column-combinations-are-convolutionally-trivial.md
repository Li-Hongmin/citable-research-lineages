> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定除数列组合在调和尾坐标中只能给出平凡重构

日期：2026-08-17。

本 note 从 note 445 的列公式给出一个固定系数 no-go。它不排除尺度依赖的 signed 消去公式，但严格排除了最简单的“用固定除数权把缩放列重新拼成第一列”的方案。

## 1. 归一化列的卷积恒等式

令
\[
\tau_{k,d}:=\frac{(T_N)_{k,d}}{\sqrt{2k+1}}
=\frac1d\sum_{j=\lfloor k/d\rfloor+1}^{\lfloor N/d\rfloor}\frac{\mu(j)}j.
\]
对任意固定系数 \(c_1,\ldots,c_N\)，交换有限和并置 \(n=dj\)，得到
\[
\begin{aligned}
\sum_{d=1}^{N}c_d\tau_{k,d}
&=\sum_{d=1}^{N}\sum_{\substack{j\le N/d\\dj>k}}
\frac{c_d\mu(j)}{dj}\\
&=\sum_{k<n\le N}\frac{(c*\mu)(n)}n,
\end{aligned}
\tag{1}
\]
其中
\[
(c*\mu)(n):=\sum_{d\mid n}c_d\mu(n/d).
\tag{2}
\]
因此除数列组合在调和尾坐标中恰好变成一个 Dirichlet 卷积。

第一列对应 \(c=\varepsilon\)，因为 \(\varepsilon_1=1\)、\(\varepsilon_d=0\ (d>1)\)，且
\(\varepsilon*\mu=\mu\)。

## 2. 固定系数重构的唯一性

假设对某个 \(N\)，一个系数列满足
\[
\sum_{d=1}^{N}c_d\tau_{k,d}
=\sum_{k<n\le N}\frac{\mu(n)}n
\qquad(1\le k<N).
\tag{3}
\]
令 \(k\) 依次取 \(1,2,\ldots,N-1\)，相邻两式相减，得到
\[
(c*\mu)(n)=\mu(n),\qquad 2\le n\le N.
\tag{4}
\]
由于 \(\mu(1)=1\)，这个递推唯一决定
\[
c_1=1,\qquad c_n=0\quad(2\le n\le N).
\tag{5}
\]
例如 \(n=2\) 给出 \(c_2=0\)，随后按 \(n\) 递推即可。若要求同一组有限系数对任意 \(N\) 成立，则只能是
\[
c=\varepsilon.
\]

同理，若固定有限系数使左侧在所有 \(k,N\) 上恒为零，则
\((c*\mu)(n)=0\) 对全部 \(n\) 成立；Dirichlet 卷积中 \(\mu\) 可逆，故 \(c=0\)。

## 3. 路线含义

所以 note 445 中的第一列不能通过一个 \(N,k\) 无关的固定除数卷积被非平凡地重构或消去。任何成功的跨列公式必须至少具有以下一个特征：

1. 系数依赖于 \(N\)、\(k\) 或截断边界；
2. 使用非卷积的 signed kernel，而不只是除数列组合；
3. 显式保留 \(n>N\) 的边界项，并对其作新的算术估计。

因此固定系数的 ordinary Gram/Schur 操作不会产生新的 RH 证书；它们最多是 note 445 的精确重写。真正未决的对象是带边界的、尺度依赖的 signed intertwiner。本 note 只关闭固定卷积列组合，不宣称 RH 证明。

