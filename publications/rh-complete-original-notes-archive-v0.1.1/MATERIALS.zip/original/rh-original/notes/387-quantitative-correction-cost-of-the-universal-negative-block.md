> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Universal negative block 对任何正化修正的定量成本

沿用 note 382 的构造。设 \(\phi\) 连续、非负、两端满足
\(\phi(0)=0\)、\(\phi(u)=0\)（\(u\ge1\)），并取 \(u_0\in(0,1)\)
使 \(\phi(u_0)>0\)。对固定 \(k\)，令 \(H_t\) 为
\(X_t=qrY_t\) 的除数子格矩阵；则
\[
H_t\longrightarrow \phi(u_0)R_k
\]
在算子范数下成立。

## 1. 半正定化的秩和范数下界

补集反射 \(R_k\) 有 \(2^{k-1}\) 个负特征值 \(-1\)。由 Weyl 扰动，
对充分大的 \(t\)，
\[
\lambda_{2^{k-1}}^-(H_t)\le-\phi(u_0)+o(1),
\qquad
n_-(H_t)\ge2^{k-1}.
\tag{1}
\]
若 Hermitian 修正 \(F_t\) 使
\[
H_t+F_t\succeq0,
\]
则惯性扰动给出
\[
\boxed{\operatorname{rank}F_t\ge2^{k-1}.}
\tag{2}
\]
同时，取 \(H_t\) 的单位负特征向量 \(v_t\)，有
\[
v_t^*F_tv_t\ge-v_t^*H_tv_t
\ge\phi(u_0)-o(1),
\]
故
\[
\boxed{\|F_t\|_{\mathrm{op}}\ge\phi(u_0)-o(1).}
\tag{3}
\]
所以固定连续核的负块不能被趋于零的 Schur/Feshbach 边界误差修复。

## 2. 只修正实际 Möbius 模式也要支付常数

在完整 \(D_{X_t}\) 上令 \(c_t(a)=\mu(a)\)。note 383 给出，对奇数 \(k\)
\[
c_t^\top H_{X_t}c_t\longrightarrow-2^k\phi(u_0).
\tag{4}
\]
若某个 Hermitian 修正只要求实际模式非负，
\[
c_t^\top(H_{X_t}+F_t)c_t\ge0,
\]
则
\[
c_t^\top F_tc_t\ge2^k\phi(u_0)+o(1).
\tag{5}
\]
由于 \(X_t\) 含 \(k+2\) 个素因子，
\(\|c_t\|_2^2=2^{k+2}\)，从而
\[
\boxed{
\|F_t\|_{\mathrm{op}}
\ge\frac{c_t^\top F_tc_t}{\|c_t\|_2^2}
\ge\frac{\phi(u_0)}4-o(1).
}
\tag{6}
\]
这说明即使放弃全矩阵 PSD、只针对实际 Möbius 向量，所需修正仍不是
可忽略的低阶边界项。

## 结论

任何有效的 RH signed intertwiner 必须同时满足：

1. 在完整负 parity 子空间上处理至少指数增长的秩；
2. 保留固定大小的 signed/reflection 作用；
3. 不能把缺口归因于一个趋零的 cutoff 或 Schur 余项。

本 note 不声称 RH；它给出的是 universal negative block 的定量修正成本。
