> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 改回原始 Möbius 层仍留下三点 Chowla 门

日期：2026-08-16。

前一条路线使用 \(\lambda\) 是因为平方恒等式的对角项简单。一个可能的替代是直接对
\[
M(X)=\sum_{n\le X}\mu(n)
\]
使用
\[
M(X)^2=\sum_{n\le X}\mu(n)^2
 +2\sum_{h<X}\sum_{n\le X-h}\mu(n)\mu(n+h).
\]
这会把端点差分中的三点项改成
\[
T^{\mu}_{U,Q}=
\sum_{U<x<2U}\sum_{q\le Q}
\mu(x)\mu(x+q)\mu(2U+q-1). \tag{1}
\]

形式上，(1) 比 Liouville 版本更接近 Banks--Shparlinski 的 Möbius 加法约束；但两者仍不是同一个权：
\[
\mu(x)\mu(y)\mu(z)\ne \mu(xyz)
\]
在变量共享素因子时尤其明显。后者在任一重复素因子处为零，前者不一定为零。

确实可以用精确恒等式
\[
\mu(a)\mu(b)\mu(c)
 =\sum_{d\mid(a,b)}\mu(d)\mu(ab/d)\mu(c)
 =\sum_{d\mid(a,b)}\sum_{e\mid(ab/d,c)}
   \mu(d)\mu(e)\mu(abc/(de)) \tag{2}
\]
把三个独立 Möbius 权展开成单个 Möbius 权加 gcd/divisibility 层；但这些层带有变量之间的乘法约束，不能直接由 Banks--Shparlinski 的单一三变量加法定理吸收。即使逐层得到其对数级估计，尺度仍是 (U^2) 乘对数因子，而非 (U^{1+\varepsilon})。

因此，“从 \(\lambda\) 改回 \(\mu\)”只改变了平方因子和对角修正，不移除端点三点 signed 门。要关闭 RH 门，仍需直接控制 (1) 的三线性符号，或构造能够处理 (2) 中 gcd 层的统一 arithmetic intertwiner。
