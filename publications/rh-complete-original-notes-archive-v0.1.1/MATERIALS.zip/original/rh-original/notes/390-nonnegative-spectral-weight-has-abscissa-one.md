> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 非负频谱权的 parity 平均具有 abscissa-one 发散

沿用 note 389。令 g 为偶函数，\(\widehat g\in L^1(\mathbb R)\) 连续、非负且不恒为零，
并令 \(H_X^p\) 与
\[
a_X:=\mu(X)H_X^p
\]
按 note 177 定义。由 parity 恒等式，
\[
a_X=\frac1{2\pi}\int_{\mathbb R}\widehat g(\xi)
|\Phi_X(\xi)|^2\,d\xi\ge0.
\]

定义初始收敛域中的 Dirichlet 级数
\[
\mathscr D_g(\sigma)=\sum_{X\ {\rm squarefree}}a_X X^{-\sigma},
\qquad \sigma>1.
\]
note 389 给出
\[
\mathscr D_g(\sigma)
=\frac1{2\pi}\int_{\mathbb R}\widehat g(\xi)
\prod_\ell\left(1+\ell^{-\sigma}|1-\ell^{i\xi}|^2\right)d\xi .
\]

## 定理

若 \(\widehat g\ge0\) 且不恒为零，则存在 \(c_g>0\) 与
\(\sigma_g>1\)，使
\[
\boxed{
\mathscr D_g(\sigma)\ge
\frac{c_g}{(\sigma-1)^2}
\qquad (1<\sigma<\sigma_g).
}
\]
因此该正系数 Dirichlet 级数的 abscissa of convergence 至少为 1；
结合其定义域，它恰为 1。

## 证明

由于 \(\widehat g\) 连续、非负且不恒为零，可取一个紧区间
\(I\subset\mathbb R\setminus\{0\}\) 及 \(c_0>0\)，使
\(\widehat g(\xi)\ge c_0\)（\(\xi\in I\)）。

对 \(\xi\in I\)，令 \(x=\ell^{-\sigma}\)、\(z=\ell^{i\xi}\)。note 389 的因子化为
\[
\prod_\ell\left(1+\ell^{-\sigma}|1-\ell^{i\xi}|^2\right)
=
\frac{\zeta(\sigma)^2}{|\zeta(\sigma+i\xi)|^2}
\,\mathscr R(\sigma,\xi).
\]
在 \(\sigma\in[1,1+\eta]\)、\(\xi\in I\) 上：

1. \(\zeta(\sigma+i\xi)\) 连续且有界。这里使用经典的
   \(\zeta(1+it)\ne0\)（\(t\ne0\)）；
2. 每个局部 \(R_\ell(\sigma,\xi)>0\)，且
   \(\sum_\ell|R_\ell-1|\) 一致收敛，因为
   \[
   |R_\ell-1|
   \le \frac{12\ell^{-2\sigma}}{(1-\ell^{-\sigma})^2};
   \]
   有限首项在紧集上有正下界，尾乘积也有正下界。

故存在 \(c_1>0\)，使
\[
\prod_\ell\left(1+\ell^{-\sigma}|1-\ell^{i\xi}|^2\right)
\ge c_1\,\zeta(\sigma)^2
\qquad(\xi\in I,\ 1<\sigma<1+\eta).
\]
又 \(\zeta(\sigma)\sim(\sigma-1)^{-1}\)，所以
\[
\mathscr D_g(\sigma)
\ge \frac{|I|c_0c_1}{2\pi}\zeta(\sigma)^2
\ge \frac{c_g}{(\sigma-1)^2}.
\]
证毕。

## 研究含义

这个结果只针对把频谱权做成非负的 PSD 路线，但量词是全称的：
任何非零 \(\widehat g\ge0\) 都产生一个正系数 squarefree 平均，其自然
Dirichlet 收敛边界在 \(\Re s=1\)，而不是 \(\Re s=\frac12\)。

因此要把它推进到 RH，不能依靠逐项正性或绝对收敛；必须重新引入
signed Möbius cancellation、反射 parity 或跨频率 intertwiner。本文不声称 RH。

