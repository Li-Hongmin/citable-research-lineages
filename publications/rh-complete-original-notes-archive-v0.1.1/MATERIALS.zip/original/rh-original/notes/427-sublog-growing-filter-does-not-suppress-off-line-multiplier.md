> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 427. 次对数增长阶滤波器不会幂次抑制离线乘子

## 1. 精确乘子

固定整数 (q\ge2)，令
\[
P_r(z)=(1-qz)^r,
\qquad r=r(X)=o(\log X).
\]
在离散 Mellin 变量 (s) 上，对应的乘子是
\[
P_{r(X)}(q^{-s})=(1-q^{1-s})^{r(X)}.
\tag{1}
\]

设 (s) 固定且 (1/2<\Re s<1)。此时
\[
a_q(s):=1-q^{1-s}\ne0,
\]
因为 (a_q(s)=0) 只能发生在 (\Re s=1)。令
\(c_s=|\log|a_q(s)||<\infty)。由 (r(X)=o(\log X))，
\[
\log |P_{r(X)}(q^{-s})|=r(X)\log|a_q(s)|=o(\log X).
\]
因此对任意 (\eta>0)，当 (X\) 足够大时有严格的双边界
\[
X^{-\eta}
\le |P_{r(X)}(q^{-s})|
\le X^{\eta}.
\tag{2}
\]

## 2. 对离线零点的含义

若存在 ζ 零点 (\rho) 满足 (1/2<\Re\rho<1)，则 (2) 对 (s=\rho)
成立。故任何 (r(X)=o(\log X)) 的增长阶，只能把该零点的固定滤波器
响应改变一个次幂因子；它不能提供 (X^{-\delta}) 型的统一衰减。

这排除了“把阶数增大到 \(\log X/\log\log X\) 就自动抹掉离线响应”的
单纯乘子解释。它没有排除真正的算术抵消，因为有限截断 Mellin 变换仍是
\[
\mathcal F_{P,X}(z)
=P(q^{-(z+1)})\sum_{n\le X}\mu(n)n^{-(z+1)},
\]
而不是带 \(1/\zeta\) 的无限尾；见 note 426。

## 3. 当前最薄缺口

要把 (2) 变成 RH 结论，还需一个统一的残差/均方接口：对所有
\(r(X)=o(\log X)\)，把有限尾在 \(k\le X) 的能量控制转化为同一临界带中
\(1/\zeta(s)\) 的解析延拓，或证明离线零点 residue 在加权均方中不能被其余
零点抵消。现有 Cauchy--Abel 链只给正半幂 reciprocal 和界，不能提供该接口。

所以增长阶路线的状态是：乘子层面已严格排除固定幂次抑制；统一 Mellin/均方
延拓仍未证明，不能宣称 RH。
