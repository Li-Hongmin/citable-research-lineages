> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Shell energy 的 (q^{-1}) 归一化：源码中的形式缺口

日期：2026-08-16。

## 来源

本 note 直接核对 Zenodo 20082725 的源码 `main (19).tex`，而不是只依据预印本
正文的叙述。关键位置如下（按源码行号）：

- completed shell 与原始系数 (c_\eta)：约 28220--28264；
- cellwise coefficient energy 的定义：约 35601--35627；
- exact coefficient-energy reduction：约 35629--35677；
- Theorem 19.216 及其证明：约 29654--29742。

## 源码中的两个定义

源码把 shell 写成

\[
  \eta=(\ell_\eta,h_\eta,\mathfrak m_\eta),
  \qquad q_\eta=Q_*\mathfrak m_\eta,
\]

并定义未归一化的聚合系数

\[
  c_\eta=\sum_{\xi\in\mathfrak X_\eta}w_\xi e(\phi_\xi).
\]

随后定义

\[
  x_\eta(m)=c_\eta\,1_{m=m_\eta},
  \qquad
  \mathcal E^X_\eta=\sum_m|x_\eta(m)|^2=|c_\eta|^2,
\]

以及 cellwise 总能量

\[
  \mathcal E^X_{\nu,H,K}
  =\sum_{\eta\in\mathfrak E^{\rm reg}_{\nu,H,K}}|c_\eta|^2.
\tag{1}
\]

源码没有在这些定义中放入 (q_\eta^{-1/2})；(q_\eta) 也随
\(\mathfrak m_\eta\) 改变。

## Theorem 19.216 使用的另一种量

在证明 Theorem 19.216 时，固定一个 shell 后把“normalized dyadic energy”写成

\[
  \frac1{q_\eta}
  \sum_{H<|h|\le 2H}|c_\eta(h)|^2.
\tag{2}
\]

但源码没有给出把 (2) 与 (1) 连接起来的 shell--residue 多重度恒等式，也没有
重新定义 (x_\eta) 为 (q_\eta^{-1/2}c_\eta)。因此，从源码可直接读出的
定义并不推出

\[
  \sum_{\eta}|c_\eta|^2
  \stackrel{?}{=}
  \sum_{\eta}\frac1{q_\eta}\sum_h|c_\eta(h)|^2.
\tag{3}
\]

特别是，​(1) 左侧已经把 (h=h_\eta) 包含在 shell 索引中；要把它改写成
对 (h) 的求和，必须先说明固定的 ((\ell,\mathfrak m)) 族如何重组，以及
每个 (h) 的确切重数。若 (q_\eta) 随 (eta) 变化，还必须保留相应权重。

## 最小形式反例

这不是数值反例，而是定义层面的必要检查。取一个合法的有限 shell 家族
\(\mathfrak E=\{\eta\}\)，令 (q_\eta=q>1)、(c_\eta=1)，并令其余 shell
为空。则源码定义 (1) 给出

\[
  \mathcal E^X_{\nu,H,K}=1,
\]

而若把同一单个 shell 解释为 (2)，结果是 (1/q)。所以 (3) 不能由
“normalized energy”这一措辞推出；必须增加新的定义或证明新的恒等式。

更一般地，若有两个 shell (\eta_1,\eta_2) 且
\(q_{\eta_1}\ne q_{\eta_2})，则 raw energy 是
\(|c_{\eta_1}|^2+|c_{\eta_2}|^2)，而加权 energy 是
\(|c_{\eta_1}|^2/q_{\eta_1}+|c_{\eta_2}|^2/q_{\eta_2})；两者不可能由一个
与 shell 无关的常数相互替代。

## 必要修复条件

要保留 19.216 的证明路线，至少需要明确完成下列二选一之一：

1. **重定义系数。** 将 Kuznetsov 侧的 primal vector 改为
   \(x_\eta(m)=q_\eta^{-1/2}c_\eta1_{m=m_\eta})，并重新检查 cellwise
   Cauchy--Schwarz、dual energy 和 exact-level capacity；或
2. **证明真实加权恒等式。** 保留源码的 raw (c_\eta)，但证明 shell--residue
   多重度公式，把 raw sum 精确转换成带 (q_\eta^{-1}) 的二次和，并说明
   该公式与 Definition 20.12 的索引、重复 shell 和 degenerate remainder
   完全相容。

两条路线都会改变后续 energy 预算；不能只在 Theorem 19.216 的最后一行插入
一个 (q_\eta^{-1})。此外，Theorem 19.216 的显示式在同时求和多个不同
\(\eta\) 时只写一个 (q_\eta)，本身还需要明确是逐 shell 估计、按 (q) 分组，
还是取统一上界。

## 裁决

因此，note 248 的“归一化接口缺失”可以升级为一个精确的形式边界：

> 源码定义的 raw cellwise energy 与 19.216 证明使用的 (q^{-1})-weighted
> dyadic energy 尚未通过任何已写出的恒等式连接。

这独立于 19.216 的模乘频率错误和 19.218 的 capacity 缺口；即使前两者修复，
仍必须先解决这里的权重与量词问题。当前不能据此推出 packet bound，更不能推出
RH。
