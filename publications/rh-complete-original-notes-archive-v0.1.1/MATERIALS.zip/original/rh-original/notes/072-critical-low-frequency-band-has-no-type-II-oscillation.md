> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 临界低频带退化为有限 weighted-Mertens transforms

日期与检索截止：2026-08-12。

依赖：[note 069](069-gcd-completion-cancels-the-fixed-slice-antidiagonal.md)、
[note 070](070-sawtooth-cell-boundaries-add-instead-of-telescope.md)、
[note 071](071-selberg-shell-increment-parity-sign-obstruction.md)。

## 1. 弄清问题

note 071 把可能的新输入压到首壳增量的低频指数和。固定

\[
I=[\alpha,\eta]\Subset(0,1),
\qquad
a_d:=\mu(d)\log(N/d),
\tag{1}
\]

定义

\[
q_{I,N}(n):=
\sum_{\substack{d\mid n\\d/N\in I}}a_d,
\qquad
Q_{I,N}(\theta):=
\sum_{N<n\le2N}q_{I,N}(n)e(n\theta).
\tag{2}
\]

本轮判别：

\[
\boxed{
\theta\asymp N^{-1}
\quad\Longrightarrow?\quad
\text{Vaughan/Heath--Brown Type II power saving}.
}
\tag{3}
\]

```mermaid
flowchart LR
  A["high block d≈N"] --> B["n=dm in (N,2N]"]
  B --> C["m≤2/α=O(1)"]
  C --> D["θ=ξ/N"]
  D --> E["finite smooth weighted Mertens transforms"]
  E --> F["factor d=rs, RS≈N"]
  F --> G["box phase variation O(1)"]
  G --> H["no Type-II oscillatory saving"]
```

## 2. 拟定计划

\[
n=dm
\to m\text{ 的精确范围}
\to H^{-1}\text{ Fourier multiplier}
\to d=rs\text{ 相位量纲}
\to \text{历史指数和界比较}.
\tag{4}
\]

## 3. 实现计划

### 3.1 high block 的 cofactor 只有有限多个

交换有限和并写 \(n=dm\)：

\[
\boxed{
Q_{I,N}(\theta)
=\sum_{m=2}^{\lfloor2/\alpha\rfloor}
\sum_{\substack{d/N\in I\\N/m<d\le2N/m}}
a_de(dm\theta).
}
\tag{5}
\]

其中 \(m=1\) 为空，因为 \(d<N<n\)；左端 \(d=N/m\) 排除，右端
\(d=2N/m\) 包含。

令

\[
J_m:=I\cap(1/m,2/m].
\tag{6}
\]

在临界低频 \(\theta=\xi/N\) 上，

\[
\boxed{
Q_{I,N}(\xi/N)
=\sum_{m=2}^{\lfloor2/\alpha\rfloor}
\sum_{d/N\in J_m}
\mu(d)\log(N/d)e(m\xi d/N).
}
\tag{7}
\]

对固定 \(m,\xi\)，

\[
w_{m,\xi}(u):=\log(1/u)e(m\xi u)\in C^\infty(J_m),
\tag{8}
\]

故 (7) 是有限个

\[
\int_{NJ_m}w_{m,\xi}(x/N)\,dM(x)
\tag{9}
\]

的和。原始 convolution 变量并非双长：

\[
\boxed{
d\asymp_I N,
\qquad
m=O_I(1).
}
\tag{10}
\]

### 3.2 完整 residual 必须保留两个 affine modes

置

\[
S_{I,N}(y):=\sum_{N<n\le y}q_{I,N}(n),
\qquad
B_{I,N}:=\sum_{d/N\in I}\frac{a_d}{d},
\tag{11}
\]

\[
R_{I,N}(y):=
\sum_{d/N\in I}a_d\beta(y/d).
\tag{12}
\]

则

\[
R_{I,N}(y)
=R_{I,N}(N)+B_{I,N}(y-N)-S_{I,N}(y).
\tag{13}
\]

对 \(\theta\ne0\)，

\[
\boxed{
\int_N^{2N}S_{I,N}(y)e(-y\theta)\,dy
=\frac{Q_{I,N}(-\theta)-e(-2N\theta)Q_{I,N}(0)}
{2\pi i\theta}.
}
\tag{14}
\]

令

\[
\phi_0(\xi):=\int_1^2e(-\xi t)\,dt,
\qquad
\phi_1(\xi):=\int_1^2(t-1)e(-\xi t)\,dt,
\tag{15}
\]

\[
D_{I,N}(\xi):=
\frac{Q_{I,N}(-\xi/N)-e(-2\xi)Q_{I,N}(0)}{2\pi i\xi}.
\tag{16}
\]

则精确有

\[
\boxed{
\int_1^2R_{I,N}(Nt)e(-\xi t)\,dt
=R_{I,N}(N)\phi_0(\xi)
+NB_{I,N}\phi_1(\xi)-D_{I,N}(\xi).
}
\tag{17}
\]

因此不能把 raw \(Q\) 单独当作完整 residual。若

\[
\int_1^2|F_{I,N}(t)|^2dt=o(N),
\qquad
F_{I,N}(t)=L^{-1}R_{I,N}(Nt),
\tag{18}
\]

则对任意固定 \(0<c<C\)，Plancherel 必要地给出

\[
\boxed{
\int_c^C
|R_{I,N}(N)\phi_0+NB_{I,N}\phi_1-D_{I,N}|^2d\xi
=o(NL^2).
}
\tag{19}
\]

若 \(P_{c,C}^\perp\) 是
\(L^2([c,C])\) 中到 \(\operatorname{span}\{\phi_0,\phi_1\}^\perp\) 的投影，则更薄的必要条件为

\[
\boxed{
\|P_{c,C}^\perp D_{I,N}\|_2^2=o(NL^2).
}
\tag{20}
\]

这保留了 note 064 的两个 affine cancellation modes，避免把过强的 pointwise
\(Q=o(\sqrt N L)\) 误报成完整必要条件。

### 3.3 人为分解 \(d=rs\) 也没有渐近相位振荡

即使对 \(\mu(d)\) 使用 Vaughan/Heath--Brown/Ramaré 型恒等式，产生的典型块仍为

\[
\mathcal B_{R,S}(\xi)
=\sum_{r\asymp R}\sum_{s\asymp S}
\alpha_r\gamma_s
e(m\xi rs/N),
\qquad
RS\asymp N.
\tag{21}
\]

固定 \(s\asymp S\) 时

\[
\Delta_r(m\xi rs/N)\asymp R^{-1},
\qquad
R\Delta_r=O(1),
\tag{22}
\]

交换 \(r,s\) 同样。整个 dyadic box 只有 \(O(1)\) 圈相位；在相对宽度
\(\varepsilon\) 的子矩形上相位变化仅 \(O(\varepsilon)\)。取
\(\alpha_r=\gamma_s=1\) 即有

\[
|\mathcal B_{R,S}(\xi)|\gg_\varepsilon RS\asymp N.
\tag{23}
\]

故任意仅使用系数有界性的 Type-II 黑箱不可能在此制度给出 power saving。
从有理逼近看，\(m\xi/N=0/1+O(N^{-1})\) 是 major arc；标准双线性界退化为

\[
\mathcal B_{R,S}\ll N(\log N)^C.
\tag{24}
\]

即使人为把相位移到最优 \(q\asymp\sqrt N\) 的 minor arc，平衡块通常也只有
\(N^{3/4}(\log N)^C\)，仍未到平方根低模尺度。

### 3.4 历史 Möbius 指数和界仍差一个幂门槛

Davenport 1937 无条件证明，对每个固定 \(A>0\)，

\[
\sup_\theta
\left|\sum_{n\le x}\mu(n)e(n\theta)\right|
\ll_A x(\log x)^{-A}.
\tag{25}
\]

分部求和把 (25) 转移到 (7) 的固定光滑权，但在 (20) 中只给

\[
\|P_{c,C}^\perp D_{I,N}\|_2^2
\ll_{A,I,c,C}\frac{N^2}{L^{2A}},
\tag{26}
\]

而所需为 \(o(NL^2)\)。任意固定次对数节省不能跨过该 \(N\) 次幂。

Wei Zhang 2022 的 Theorem 1.1 假设所有 Dirichlet \(L(s,\chi)\) 在
\(\Re s>a\) 无零，并给 uniform exponent

\[
b=\frac{8a-7a^2}{4-2a},
\qquad
\sup_\theta|S(x,\theta)|\ll x^{b+\varepsilon}.
\tag{27}
\]

即使 \(a=1/2\)，仍为 \(b=3/4\)，所以 (20) 的黑箱尺度仅为

\[
N^{3/2+\varepsilon},
\tag{28}
\]

比 \(NL^2\) 大 \(N^{1/2-o(1)}\)。该假设已强于本项目允许的无条件输入，
而结论仍不足。

原始入口：
[Davenport](https://doi.org/10.1093/qmath/os-8.1.313)、
[Wei Zhang](https://arxiv.org/abs/2204.04613)、
[DHJ Polymath parity discussion](https://arxiv.org/abs/1407.4897)。

### 3.5 低频平均等价于临界加权二点相关

令

\[
K_{c,C}(u):=\int_c^Ce(\xi u)\,d\xi.
\tag{29}
\]

展开 (7)：

\[
\begin{aligned}
\int_c^C|Q_{I,N}(\xi/N)|^2d\xi
=\sum_{m,m'}\sum_{d,e}
a_da_e
K_{c,C}\!\left(\frac{md-m'e}{N}\right),
\end{aligned}
\tag{30}
\]

其中 \(m,m'=O_I(1)\)，\(d,e\asymp_I N\)。对角 \(m=m'\) 已包含

\[
\sum_hK_{c,C}(mh/N)
\sum_d a_da_{d-h}.
\tag{31}
\]

因此 \(\xi\)-平均并未制造长频率正交；它把问题改写成长度 \(N\)、全部
\(|h|\ll N\) 的平滑二点 Möbius 相关。Menon 2026 的 averaged Chowla/short-interval
技术只提供归一化对数节省，raw 尺度仍近 \(N^2\)，而 (20) 需要
\(o(NL^2)\)。这再次量化为一个完整 \(N\) 次幂缺口。

## 4. 回顾反思

\[
\boxed{
\begin{array}{c|c}
\text{候选机制}&\text{裁决}\\
\hline
n=dm\text{ 的双长 bilinear}&\text{否：}m=O_I(1)\\
d=rs\text{ 的 Type II 相位}&\text{否：box 总振荡 }O(1)\\
\text{Davenport uniformity}&N/L^A\text{，差一个幂}\\
\text{Dirichlet-GRH 条件 uniformity}&N^{3/4+\varepsilon}\text{，仍差 }N^{1/4}\\
\xi\text{-平均}&\text{临界 weighted two-point correlation}\\
\text{完整正确低频对象}&P^\perp D_{I,N}
\end{array}
}
\tag{32}
\]

故普通 bilinear exponential-sum 路线关闭。下一最简单元不再是分解 \(\mu\)，
而是判别 rank-two affine quotient 后的临界谱质量

\[
\boxed{
\|P_{c,C}^\perp D_{I,N}\|_2^2=o(NL^2)
}
\tag{33}
\]

是否能由某个历史上的 dilation/Franel--Landau 恒等式转成零点位置的**单边正量**；
若只用 Mertens、Chowla 或普通 sieve 均值，(33) 仍是 RH 级输入。

本 note 没有证明 (33) 或 RH。
