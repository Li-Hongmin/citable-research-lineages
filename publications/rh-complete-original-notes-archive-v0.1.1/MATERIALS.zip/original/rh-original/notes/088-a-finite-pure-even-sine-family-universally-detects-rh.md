> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 存在有限纯偶正弦 universal detector

日期：2026-08-13。

依赖：[note 081](081-every-offline-zero-is-visible-in-one-fixed-sine-mode.md)、
[note 087](087-two-sine-cutoff-mean-square-is-equivalent-to-rh.md)。

## 1. 定理

令

\[
W_k(s):=\int_1^2\sin\pi k(t-1)t^{s-1}dt.
\tag{1}
\]

**定理 1（有限纯偶 detector）。** 存在有限集合

\[
\boxed{E\subset2\mathbb N,\qquad |E|<\infty}
\tag{2}
\]

使

\[
\boxed{
\operatorname{rank}
\left(W_k(s),W_k'(s)\right)_{k\in E}=2
\qquad
\left(\frac12<\Re s<1\right).
}
\tag{3}
\]

因此每个满足 \(1/2<\Re\rho<1\) 的 \(\zeta\)-零点都被某个 \(k\in E\) 的固定偶正弦
cutoff 模以 Mellin 极点检出，并且

\[
\boxed{
\mathrm{RH}
\iff
\forall\varepsilon>0,\quad
\sum_{Y<N\le2Y}\sum_{k\in E}|\mathcal R_{N,k}|^2
\ll_\varepsilon Y^{2+\varepsilon}.
}
\tag{4}
\]

集合 \(E\) 的存在是纯解析的；本 note 不给最小或显式 \(E\)。

## 2. 偶正弦族处处秩二

先证明无限矩阵

\[
\mathsf M(s):=\left(W_{2a}(s),W_{2a}'(s)\right)_{a\ge1}
\tag{5}
\]

对

\[
\frac12\le\Re s\le1,\qquad s\ne1
\tag{6}
\]

秩为 \(2\)。

若不然，存在 \((A,B)\ne(0,0)\)，使

\[
A W_{2a}(s)+B W_{2a}'(s)=0
\qquad(a\ge1).
\tag{7}
\]

置 \(\alpha=s-1\)。式 (7) 等价于

\[
F(t):=t^\alpha(A+B\log t)
\tag{8}
\]

的全部偶正弦系数消失：

\[
\int_1^2F(t)\sin 2\pi a(t-1)\,dt=0
\qquad(a\ge1).
\tag{9}
\]

在 \(L^2(1,2)\) 中，\(\{\sin2\pi a(t-1):a\ge1\}\) 完备于关于
\(t\mapsto3-t\) 的反对称子空间。因此 (9) 强制

\[
F(t)=F(3-t).
\tag{10}
\]

令 \(c=3/2\)。对称性给

\[
F'(c)=F'''(c)=0.
\tag{11}
\]

由 \(F'(c)=0\)，若 \(B=0\) 则 \(A=0\)，矛盾；故 \(B\ne0\)，且

\[
A=-B\left(\log c+\frac1\alpha\right).
\tag{12}
\]

直接微分：

\[
F'''(c)=B\,\alpha(2\alpha-3)c^{\alpha-3}.
\tag{13}
\]

在 (6) 中，

\[
-\frac12\le\Re\alpha\le0,\qquad \alpha\ne0,
\tag{14}
\]

所以 (13) 不可能为零。矛盾证明

\[
\boxed{
\forall s\text{ 满足 (6)},\quad
\exists a<b:\quad
D_{2a,2b}(s)\ne0,
}
\tag{15}
\]

其中

\[
D_{2a,2b}(s)
:=W_{2a}(s)W_{2b}'(s)-W_{2a}'(s)W_{2b}(s).
\tag{16}
\]

## 3. 边界点 \(s=1\) 的正规化覆盖

所有偶模满足 \(W_{2a}(1)=0\)，故

\[
D_{2a,2b}(s)=(s-1)^2\widetilde D_{a,b}(s),
\tag{17}
\]

其中 \(\widetilde D_{a,b}\) 为整函数。必须证明至少一对满足
\(\widetilde D_{a,b}(1)\ne0\)。

反设所有 jet

\[
\left(W_{2a}'(1),W_{2a}''(1)\right)
\tag{18}
\]

共线。则存在 \((A,B)\ne(0,0)\)，使

\[
A\log t+B(\log t)^2
\tag{19}
\]

的全部偶正弦系数为零，故它关于 \(3/2\) 对称。一阶导数消失给

\[
A=-2B\log(3/2),
\tag{20}
\]

而三阶导数为

\[
-\frac{6B}{(3/2)^3}.
\tag{21}
\]

所以 \(B=A=0\)，矛盾。故存在某对 \(a_0<b_0\)，使

\[
\widetilde D_{a_0,b_0}(1)
=\frac12\left[
W_{2a_0}'(1)W_{2b_0}''(1)
-W_{2a_0}''(1)W_{2b_0}'(1)
\right]\ne0.
\tag{22}
\]

该固定对的正规化 Wronskian 覆盖 \(s=1\) 的一个邻域；原始 Wronskian 覆盖相应穿孔邻域
\(0<|s-1|<\delta\)。

## 4. 高频固定覆盖与紧性

令

\[
\lambda_a=2\pi a,\qquad L=\log2.
\tag{23}
\]

端点分部积分一致给出

\[
\boxed{
D_{2a,2b}(s)
=
\frac{
6L\,2^s\lambda_a\lambda_b(\lambda_b^2-\lambda_a^2)
}{s^6}
+O_{a,b}(|s|^{-7})
}
\tag{24}
\]

当 \(|s|\to\infty\) 时一致成立于 \(1/2\le\Re s\le1\)。故任意固定 \(a\ne b\) 都存在
\(T_{a,b}<\infty\)，使该对覆盖 \(|\Im s|\ge T_{a,b}\)。

取一个固定高频对及 (22) 的边界对。删去它们覆盖的高频区域和 \(s=1\) 邻域后，余下集合
为紧集。由 (15)，每一点都有某个偶模对的 Wronskian 非零；这些非零邻域构成开覆盖。有限
子覆盖只使用有限多个偶模。收集这些模即得 (2)、(3)。

~~~mermaid
flowchart LR
  H["one fixed even pair"] --> HF["high |t|"]
  J["one nonzero jet pair"] --> S1["near s=1"]
  R["infinite even family rank 2"] --> K["remaining compact set"]
  K --> F["finite subcover E"]
  HF --> F
  S1 --> F
~~~

## 5. Universal detection 与 RH 等价式

偶模满足

\[
c_k=0,\qquad C_k=-W_k',
\tag{25}
\]

所以 note 081 的 Mellin 像为

\[
\widehat{\mathscr R}_k
=-\frac{W_k'}{\zeta}
+W_k\frac{\zeta'}{\zeta}
+W_k'.
\tag{26}
\]

若 \(\rho\) 是 \(q\ge2\) 重零点且全部 \(k\in E\) 都漏掉最高阶极点，则
\(W_k'(\rho)=0\) 对全部 \(k\in E\) 成立，违反 (3)。若 \(\rho\) 是简单零且全部模都
无留数，则

\[
-W_k'(\rho)+\zeta'(\rho)W_k(\rho)=0
\qquad(k\in E),
\tag{27}
\]

同样迫使 (3) 中两列相关。故 \(E\) universal detect。

于是 (4) 的“均方 \(\Rightarrow\) RH”由 note 081 的 dyadic Mellin-pole 引理得到；反向由
note 087 对每个固定 \(k\) 的 RH 点态界得到。因 \(E\) 有限，常数可合并。

## 6. 算术意义

对每个偶 \(k\)，

\[
c_k=S_{N,k}=0
\tag{28}
\]

严格成立，故

\[
\boxed{
\mathcal R_{N,k}
=-\sum_{N<n<2N}
\left[\Lambda(n)+\mu(n)\log\frac nN\right]
\sin\pi k(n/N-1).
}
\tag{29}
\]

等价的 divisor 形式没有 \(B_NS_{N,k}\) 全局通道：

\[
\boxed{
\mathcal R_{N,k}
=-\sum_{d\le N}\mu(d)\log\frac Nd
\sum_{N<da<2N}\sin\pi k(da/N-1).
}
\tag{30}
\]

因此存在一条完全纯局部、有限通道的 RH 等价路线。尚未解决的两件事严格分开：

\[
\begin{array}{ll}
(A)&\text{构造尽可能小的显式 }E;\\
(B)&\text{无条件证明该有限偶模族的 cutoff 均方。}
\end{array}
\tag{31}
\]

浮点扫描提示 \(E=\{4,6\}\) 可能已经足够；该更强断言必须由
\(\widetilde D_{2,3}=D_{4,6}/(s-1)^2\) 的严格无零证书决定。
