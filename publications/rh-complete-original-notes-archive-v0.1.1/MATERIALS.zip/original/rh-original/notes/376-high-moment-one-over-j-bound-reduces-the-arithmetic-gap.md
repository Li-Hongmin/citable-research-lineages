> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 高矩层自动满足 \(1/j\) 界：缺口只在低矩

## 精确因子化

令
\[
S_j(z):=\frac{A_j(z)}{z^j}
 =\sum_{n\le z}\mu(n)\left(\frac nz\right)^j .
\]
则 note 373 的二次差可写成
\[
T_j(z^2)=S_j(z)^2-S_{j+1}(z)^2
       =\bigl(S_j-S_{j+1}\bigr)\bigl(S_j+S_{j+1}\bigr).
\tag{1}
\]
由 \(|\mu(n)|\le1\)，
\[
|S_j-S_{j+1}|
\le \sum_{n\le z}\left(\frac nz\right)^j
       \left(1-\frac nz\right),
\tag{2}
\]
\[
|S_j+S_{j+1}|
\le \sum_{n\le z}\left(\frac nz\right)^j
       \left(1+\frac nz\right).
\tag{3}
\]
在 \(0\le j\le z\) 时，使用如下单峰求和估计：
若 \(f\) 在 \([0,1]\) 上单峰且网格为 \(1/z\)，则
\[
\sum_{n=1}^{z}f(n/z)
\le z\int_0^1 f(x)\,dx+2\max_{[0,1]}f .
\tag{4a}
\]
对 \(f_j(x)=x^j(1-x)\)，有
\[
\int_0^1 f_j(x)\,dx=\frac1{(j+1)(j+2)},
\qquad
\max f_j=\frac{j^j}{(j+1)^{j+1}}
\le\frac1{j+1}
\le\frac{2z}{(j+1)(j+2)}
\]
（最后一步用 \(j\le z\)）。对 \(g_j(x)=x^j(1+x)\)，同理
\(\int_0^1g_j\le2/(j+1)\)、\(\max g_j\le2\)，故也有绝对常数 \(C\)，使
\[
|S_j-S_{j+1}|
\le \frac{Cz}{(j+1)(j+2)},
\qquad
|S_j+S_{j+1}|
\le \frac{Cz}{j+1}.
\tag{4}
\]
因此
\[
|T_j(z^2)|
\le \frac{C^2z^2}{(j+1)^2(j+2)}.
\tag{5}
\]
当 \(j+1\ge\sqrt z\) 时，\((j+1)(j+2)\ge z\)，从而
\[
\boxed{
|T_j(z^2)|\ll \frac{z}{j+1}
\qquad (j\ge\sqrt z).}
\tag{6}
\]
这一步完全无条件，不使用 PNT、RH 或任何 Möbius 相关估计。

## 对平方根门槛的缩减

将 note 375 的望远镜在 \(J=z\) 处分成低、高两段：
\[
M(z)^2
\le \sum_{j<\sqrt z}|T_j(z^2)|
   +\sum_{\sqrt z\le j<z}|T_j(z^2)|
   +B_{z+1}(z).
\tag{7}
\]
由 (6)，高矩段满足
\[
\sum_{\sqrt z\le j<z}|T_j(z^2)|
\ll z\sum_{j\ge\sqrt z}\frac1{j+1}
\ll z\log z.
\tag{8}
\]
尾项 \(B_{z+1}\le4z^2/(z+2)^2=O(1)\)。所以，要由这族核得到
\(M(z)^2\ll z^{1+\varepsilon}\)，唯一未解决部分已缩为
\[
\boxed{
\sum_{0\le j<\sqrt z}|T_j(z^2)|
\ll_\varepsilon z^{1+\varepsilon}.}
\tag{9}
\]
若能在低矩区证明 \( |T_j(z^2)|\ll z^{1+\varepsilon}/(j+1)\)，note 375 立即给出 RH-strength 的 Mertens 界；若只能得到低矩总和的对数或幂次损失，则 (7) 直接量化相应损失。

## 边界

估计 (5) 在 \(j<\sqrt z\) 时只有 \(O(z^2/j^3)\) 的信息，不能把低矩总和压到 \(O(z^{1+\varepsilon})\)。因此这不是 RH 的证明，而是一个严格的降维：高矩部分已经不再是障碍，剩余问题是有限但随 \(z\) 增长的低矩 signed cancellation。它仍需跨矩阶关系或 incomplete-lcm boundary 的联合控制。
