> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正 reciprocal-product RH 核具有统一二阶负方向

日期：2026-08-14。

依赖：
[note 118](118-an-endpoint-flat-detector-gives-an-exact-positive-reciprocal-product-rh-gate.md)。

证据等级：无限精确 \(2\times2\) 有理反例族。

note 118 得到 entrywise 非负核

\[
P(y)=
\frac{\lfloor y\rfloor(\lfloor y\rfloor+1)}{y^3}
\{y\}(1-\{y\}),
\tag{1}
\]

以及有限矩阵

\[
K_x(a,b)=P\left(\frac{x}{ab}\right),
\qquad 1\le a,b\le\sqrt x.
\tag{2}
\]

本文证明 \(K_x\) 不仅不是普遍 PSD，而且存在尺度不衰减的精确
二阶负方向。

## 1. 无限反例族

直接由 (1)，

\[
P(1)=0,\qquad
P(3/2)=\frac4{27},\qquad
P(9/4)=\frac8{81}.
\tag{3}
\]

任取整数 \(k\ge1\)，置

\[
x=9k^2,\qquad a=3k,\qquad b=2k.
\tag{4}
\]

则 \(a,b\le\sqrt x\)，且

\[
\frac{x}{a^2}=1,\qquad
\frac{x}{ab}=\frac32,\qquad
\frac{x}{b^2}=\frac94.
\tag{5}
\]

所以 \(K_x\) 在指标 \((a,b)\) 上的主子矩阵恒为

\[
\boxed{
\begin{pmatrix}
0&4/27\\
4/27&8/81
\end{pmatrix}.}
\tag{6}
\]

其行列式是

\[
\boxed{-\frac{16}{729}<0.}
\tag{7}
\]

故 \(K_x\) 不是 PSD。因为所有 \(1\times1\) 主子式均为非负数
\(P(x/a^2)\)，二阶是矩阵阶数意义下最小可能的失败。

## 2. 固定负谱隙

(6) 的两个特征值为

\[
\lambda_\pm=\frac4{81}(1\pm\sqrt{10}).
\tag{8}
\]

特别地，

\[
\boxed{\lambda_-=\frac4{81}(1-\sqrt{10})<0}
\tag{9}
\]

与 \(k\) 无关。一个对应负方向是

\[
v_-=\left(1,\frac{1-\sqrt{10}}3\right).
\tag{10}
\]

更简单地，向量 \((1,-1)\) 已给出

\[
(1,-1)
\begin{pmatrix}
0&4/27\\
4/27&8/81
\end{pmatrix}
\binom1{-1}
=-\frac{16}{81}<0.
\tag{11}
\]

因此不定性不是有限扫描、小 \(x\) 或连续极限误差；它在
\(x=9k^2\to\infty\) 上保持固定大小。

## 3. Gram 表示的直接障碍

任意 PSD 矩阵若某个对角元为零，则对应整行必须为零。但在 (6) 中

\[
K_x(a,a)=P(1)=0,\qquad
K_x(a,b)=P(3/2)>0.
\tag{12}
\]

所以不存在把完整 \(K_x\) 写成正 Gram 矩阵的表示。

在 log 坐标令

\[
f(t)=P(e^t),\qquad
r_a=\log(\sqrt x/a).
\tag{13}
\]

则 \(K_x(a,b)=f(r_a+r_b)\)。若存在正 Laplace--Hankel 表示

\[
f(r+s)=\int_0^\infty e^{-\lambda r}e^{-\lambda s}\,d\nu(\lambda),
\qquad \nu\ge0,
\tag{14}
\]

则 \(f\) 必为完全单调，且非零正测度的 Laplace 变换在有限点严格为正。
然而

\[
f(\log n)=P(n)=0\quad(n\in\mathbb N),
\tag{15}
\]

而相邻非整数点 \(f>0\)。这再次排除 (14)。

## 4. 结论

note 118 的核满足

\[
\boxed{\text{entrywise positive}\ \not\Rightarrow\
\text{positive semidefinite}.}
\tag{16}
\]

因此不能把 RH 门
\(\mu^TK_x\mu\) 直接送入正 Gram、Schur complement 或正
Laplace--Hankel 谱分解。任何可用的算子分解都必须保留正负谱，
或先完成一个有算术内容的 centered/deflated 变换；单靠核的逐项正性
不足。这是对直接 PSD 路线的严格关闭，不是 RH 的证明。
