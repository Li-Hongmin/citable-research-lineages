> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# BV Mellin detector 精确看见未被分子消去的 \(\zeta\) 重数

日期：2026-08-14。

依赖：
[note 094](094-k1-a2-high-divisor-cell-has-a-zero-free-mellin-detector.md)、
[note 098](098-continuous-scale-mean-square-is-an-exact-mellin-hardy-rh-criterion.md)。

证据等级：有界变差 Abel 求和、精确 Mellin 变换与全纯重数比较。
本文把 note 098 中对特定 \(F\) 的论证提升为一个一般 detector 定理，
并分清“分子在该点非零”与“分子零自由”的精确作用。

## 1. Detector 类

令 \(W\) 是 \((0,\infty)\) 上的可测函数，并假设它的零延拓满足

\[
W\in BV(0,\infty),
\qquad
W(t)=0\quad(t>B)
\tag{1}
\]

对某个 \(B>0\) 成立。\(W\) 在 \(0\) 附近不必消失；有界变差保证其
有界。定义

\[
U_W(x):=\sum_{n\ge1}\mu(n)W(n/x),
\tag{2}
\]

\[
K_W(s):=\int_0^\infty W(t)t^{s-1}\,dt.
\tag{3}
\]

(2) 对每个 \(x\) 是有限和，而 (3) 全纯于 \(\Re s>0\)。若
\(W\) 的支撑还远离 \(0\)，则 \(K_W\) 是整函数。

这些连续量只依赖 \(W\) 的 a.e. 等价类：改变 \(W\) 的零测集上取值，
只会在 \(x\) 的零测集上改变 \(U_W\)。因而本文的“非零 detector”
始终指 \(W\ne0\) a.e.，等价地 \(K_W\not\equiv0\)，而不是某个孤立点的点值非零。

## 2. 精确 Mellin 恒等式与正确 Hardy 归一化

对 \(\Re s>1\)，绝对 Fubini 与 \(t=n/x\) 给出

\[
\boxed{
H_W(s):=\int_0^\infty U_W(x)x^{-s-1}\,dx
=\frac{K_W(s)}{\zeta(s)}.
}
\tag{4}
\]

由于 \(U_W(x)=0\) a.e. 于 \(0<x<1/B\)，正确的半轴 Laplace 归一化是

\[
\widetilde H_W(s):=B^{-s}H_W(s).
\tag{5}
\]

事实上，令 \(y=\log(Bx)\)，则

\[
\widetilde H_W(s)
=\int_0^\infty U_W(e^y/B)e^{-sy}\,dy.
\tag{6}
\]

因而若

\[
I_\sigma(W):=
\int_{1/B}^\infty|U_W(x)|^2x^{-2\sigma-1}\,dx<\infty,
\tag{7}
\]

则 Paley--Wiener 等距式为

\[
\boxed{
\sup_{a>\sigma}\frac1{2\pi}
\int_{\mathbb R}|\widetilde H_W(a+it)|^2dt
=B^{-2\sigma}I_\sigma(W).
}
\tag{8}
\]

当 \(B>1\) 时，因子 \(B^s\) 使 \(H_W\) 本身不必属于标准
\(H^2(\Re s>\sigma)\)；(5) 才是无隐藏尺度增长的 Hardy 对象。

## 3. 一般可见性定理

**定理 1。** 对满足 (1) 的 \(W\)：

1. RH 蕴含对每个 \(\varepsilon>0\)，
   \[
   \boxed{
   \int_Y^{2Y}|U_W(x)|^2\,dx
   \ll_{W,\varepsilon}Y^{2+\varepsilon}
   \qquad(Y\ge1).
   }
   \tag{9}
   \]
2. 反之，若 (9) 对每个 \(\varepsilon>0\) 成立，那么每个满足
   \(\Re\rho>1/2\) 的非平凡 \(\zeta\) 零点都必须满足
   \[
   \boxed{
   \operatorname{ord}_\rho K_W
   \ge \operatorname{ord}_\rho\zeta.
   }
   \tag{10}
   \]

**证明。** RH 蕴含对每个 \(\delta>0\)，

\[
M(x)=O_\delta(x^{1/2+\delta}).
\tag{11}
\]

对 (2) 作离散 Abel 求和，并把 \(W\) 的所有跳跃纳入总变差，得

\[
|U_W(x)|
\ll_W\sup_{n\le Bx}|M(n)|
\ll_{W,\delta}x^{1/2+\delta}.
\tag{12}
\]

这给出 (9)。

现假设 (9) 对每个 \(\varepsilon>0\) 成立。逐 dyadic shell 求和给出

\[
I_\sigma(W)<\infty
\qquad(\sigma>1/2).
\tag{13}
\]

由 Cauchy--Schwarz，(4) 中由积分定义的 \(H_W\) 因而全纯于
\(\Re s>1/2\)。令

\[
Z(s):=(s-1)\zeta(s).
\tag{14}
\]

则全纯恒等定理将

\[
Z(s)H_W(s)=(s-1)K_W(s)
\tag{15}
\]

从 \(\Re s>1\) 延拓到 \(\Re s>1/2\)。若 \(\rho\ne1\) 是 \(\zeta\)
的 \(m\) 重零点，则 (15) 左边在 \(\rho\) 的零点阶数至少为 \(m\)。
因 \(\rho-1\ne0\)，右边迫使 \(\operatorname{ord}_\rho K_W\ge m\)，
即 (10)。\(\square\)

## 4. 零自由 detector 的充分等价式

若可以预先核验

\[
\boxed{
K_W(s)\ne0
\qquad\left(\frac12<\Re s<1\right),
}
\tag{16}
\]

则定理 1 与 \(\zeta\) 在 \(\Re s\ge1\) 的经典零自由性给出

\[
\boxed{
\mathrm{RH}
\Longleftrightarrow
\forall\varepsilon>0,
\quad
\int_Y^{2Y}|U_W(x)|^2\,dx
\ll_{W,\varepsilon}Y^{2+\varepsilon}.
}
\tag{17}
\]

不必要求 \(K_W\) 在整个 strip 零自由才能看见某一个给定零点：
对一个 \(m\) 重零点 \(\rho\)，只要

\[
\operatorname{ord}_\rho K_W<m,
\tag{18}
\]

它就与 gate 矛盾。相反，若 \(K_W\) 在 \(\rho\) 至少同阶消零，
该零点在局部极点机制中完全不可见。这种局部消零本身不会自动推出
\(H_W\) 的全局 Hardy 界，所以不能反过来把 (10) 当成 gate 的充分条件。

## 5. 不可删除的量词与点值边界

定理 1 中必须要求 **每个** \(\varepsilon>0\)。若只有一个固定
\(\eta>0\) 的 \(O(Y^{2+\eta})\) 界，同样的 Cauchy--Schwarz 论证只使
\(H_W\) 全纯于

\[
\Re s>\frac{1+\eta}{2},
\tag{19}
\]

因而只能看见更右侧的零点。

最后，若把“\(W\ne0\)”误解为点态条件，则
\(W=\mathbf1_{\{1\}}\) 给出一个伪 detector：它点态有界变差且不恒为零，
但 \(K_W\equiv0\)，而 \(U_W\) 只在可数个 \(x\) 上非零，所有连续 \(L^2\)
gate 都自动成立。因此 a.e. 非平凡性与重数条件 (10) 都不可省略。
