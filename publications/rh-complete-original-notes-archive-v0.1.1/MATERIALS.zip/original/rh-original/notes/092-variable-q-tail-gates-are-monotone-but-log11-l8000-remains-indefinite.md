> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# variable-\(q\)-tail gate 单调，但 \(\frac12\log11\) 的 \(L=8000\) 仍不定

日期：2026-08-14。

本 note 推广 [note 089](089-strict-local-weil-positivity-to-log201over20-half.md) 的
\(t_{2000}^{-1}\) Parseval tail payment，并以完整 full-space Yukawa family
\(F_{640}=(r_{500}^+,\ldots,r_{639}^+)\) 在 \(a=\frac12\log11\) 检验第一个较大 cutoff。

## 任意 cutoff 的 Loewner 门

记

\[
\mathcal B=P_0+\frac{R_P}{t_{400}}+B_FB_F^*,\qquad
U_q=PB_0^+e_q+B_FV^*e_q,
\]

并令

\[
R_L=\sum_{400\le q<L}U_qU_q^*,\qquad
H_L=\sum_{400\le q<L}\frac{U_qU_q^*}{t_q},\qquad
R_{\rm tot}=\sum_{q\ge400}U_qU_q^*.
\]

对每个整数 \(L\ge400\)，定义

\[
G_L=\mathcal B-H_L-\frac{R_{\rm tot}-R_L}{t_L}.
\tag{1}
\]

令 \(\mathscr S_F\) 为 note 089 中 \(\underline L_F^+\) 对补空间 \(Q\) 的真实 Schur complement：

\[
\mathscr S_F=\mathcal B-\sum_{q\ge400}\frac{U_qU_q^*}{t_q}.
\tag{2}
\]

则

\[
\boxed{G_L\preceq\mathscr S_F,\qquad
G_{L+1}-G_L=(t_L^{-1}-t_{L+1}^{-1})(R_{\rm tot}-R_{L+1})\succeq0.}
\tag{3}
\]

因此 \(G_L\) 随 \(L\) 单调增加，且任何严格 \(G_L>0\) 都推出

\[
\underline L_F^+>0\preceq A_{\frac12\log11}^+.
\tag{4}
\]

证明只需 note 089 的完整 Parseval 恒等式和 \(t_q\) 的严格增加性。写

\[
t_q=\Re\psi\!\left(\frac14+i\frac{q\pi}{2a}\right)-\log\pi-\rho_{\rm p},
\]

则对 \(y>0\)

\[
\partial_y\Re\psi\!\left(\frac14+iy\right)
=2y\sum_{n\ge0}\frac{n+\frac14}{((n+\frac14)^2+y^2)^2}>0.
\]

最后，(3) 的第一部分等价于

\[
\mathscr S_F-G_L
=\sum_{q\ge L}(t_L^{-1}-t_q^{-1})U_qU_q^*\succeq0.
\]

## \(L=8000\) 的严格结果

取 \(P=P_{400}^+\)、even \(F=F_{640}\)、256-bit Arb。分块为 \(7\oplus393\) 后，补块严格正：

\[
p_{\min}(H_{393})
=[0.040763986927637844750543975424627\ldots\pm2.75\cdot10^{-58}]>0.
\]

七维 verified Schur complement 在排列 \((6,2,3,4,5,1,0)\) 下前六个 LDL pivots
严格正，最后一个为

\[
[-1.60314879987627222815\cdot10^{-47}\pm4.53\cdot10^{-68}]<0.
\tag{5}
\]

所以

\[
\boxed{\operatorname{inertia}(G_{8000})=(399,1,0).}
\tag{6}
\]

完整输出、hash 和 replay 入口见
[`log11-even-variable-qtail-l8000-obstruction`](../computations/bundles/log11-even-variable-qtail-l8000-obstruction/README.md)。

## 边界

(6) 关闭的是 scalar endpoint payment 的这个有限 \(L=8000\) 门。由

\[
G_{8000}\preceq\mathscr S_F
\]

不能推出 \(\mathscr S_F\) 或 \(A_{\frac12\log11}^+\) 不定。也不能由有限
\(L\) 值外推 \(L\to\infty\)。要关闭或通过整个 fixed-\(F_{640}\) 下模型，仍需直接控制
\(\mathscr S_F-G_L\) 的全尾，而不是继续把有限 cutoff 的数值趋势当作证明。
