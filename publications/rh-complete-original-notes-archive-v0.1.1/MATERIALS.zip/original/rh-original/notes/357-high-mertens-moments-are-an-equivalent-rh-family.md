> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 高阶 Mertens 矩族只是 RH 的另一组等价门

日期：2026-08-16。

本 note 检查一个看似可能绕开 reciprocal-product 能量门的路线：先控制
\(
 S_q(N):=\sum_{n\le N}|M(n)|^{2q},\qquad
 M(n)=\sum_{r\le n}\mu(r),
\)
再用 \(M(n+1)-M(n)=\mu(n+1)\in\{-1,0,1\}\) 的单位步持续性把点值控制出来。

## 精确持续性引理

令
\(
 A_N:=\max_{1\le n\le N}|M(n)|
\)
并取 \(n_0\) 使 \(|M(n_0)|=A_N\)。对
\(0\le j\le L:=\min(\lfloor A_N/2\rfloor,n_0-1)\)，有
\[
 |M(n_0-j)|\ge |M(n_0)|-j\ge A_N/2.
\]
因此当 \(A_N\ge4\) 时
\[
 S_q(N)\ge (A_N/2-1)(A_N/2)^{2q}
      \ge 2^{-(2q+2)}A_N^{2q+1}.
\tag{1}
\]
若最大值落在 \(n_0\le A_N/2\)，则从 \(M(0)=0\) 到 \(M(n_0)\) 的单位步约束直接给
\(A_N\le n_0\le A_N/2\)，除非 \(A_N=0\)；故非平凡情形确实可用 (1)。

于是，对任意固定整数 \(q\ge1\)，假设
\[
 S_q(N)\ll_{q,\varepsilon}N^{q+1+\varepsilon},
\tag{2}
\]
便得到
\[
 A_N\ll_{q,\varepsilon}
 N^{(q+1+\varepsilon)/(2q+1)}
 =N^{1/2+(1/2+\varepsilon)/(2q+1)}.
\tag{3}
\]
固定一个 \(q\) 只给出严格大于 \(1/2\) 的指数；令 \(q\to\infty\) 才逼近临界指数。

## 与 RH 的等价性

RH 的经典 Mertens 形式
\(
 |M(n)|\ll_\delta n^{1/2+\delta}
\)
对每个固定 \(q\) 立即给出
\[
 S_q(N)\ll_{q,\varepsilon}N^{q+1+\varepsilon}
\]
（取 \(\delta=\varepsilon/(2q)\) 并求和）。反向地，若 (2) 对每个 \(q\) 和每个 \(\varepsilon>0\) 成立，给定目标 \(\eta>0\)，先取 \(q\) 足够大使
\((1/2+\varepsilon)/(2q+1)<\eta\)，再用 (3)，即得
\(M(N)\ll_\eta N^{1/2+\eta}\)。所以
\[
 \boxed{\mathrm{RH}\iff
 \forall q\in\mathbb N,\ \forall\varepsilon>0:\quad
 \sum_{n\le N}|M(n)|^{2q}\ll_{q,\varepsilon}N^{q+1+\varepsilon}.}
\tag{4}
\]

## 算术输入的真实阶数

展开 \(M(n)^{2q}\) 得到精确恒等式
\[
 S_q(N)=
 \sum_{r_1,\ldots,r_{2q}\le N}
 \mu(r_1)\cdots\mu(r_{2q})
 \bigl(N-\max(r_1,\ldots,r_{2q})+1\bigr).
\tag{5}
\]
故 (2) 不是普通的单点或二点平均，而是带最大值截断权的全体 \(2q\)-点 Möbius 相关。
特别地，\(q=2\) 已包含一般四点相关；它不是只含平行四边形的 \(U^2\) 相关。当前 notes 351--353 所控制的四点/U² 结构不能直接给 (2)，即使给出任意固定对数节省，也仍停留在 \(N^{2-o(1)}\) 型能量。

近期局部 Möbius Fourier 矩工作也明确指出：固定阶矩只产生大于 \(1/2\) 的指数，必须使用任意高阶矩族才恢复 RH；该结果是等价重述而非 RH 证明。见 [Verjovsky, arXiv:2607.25002](https://arxiv.org/abs/2607.25002)，尤其其引言及局部 moment-to-point-value 不等式。

## 当前裁决

高阶 Mertens 矩路线已严格降格为 RH 的等价判据族。它没有提供新的无条件入口；要使它成为证明，必须取得全阶、最大值截断的多点 Möbius 相关估计 (2)/(5)，这比已有 MRT 二点平均和 Tao--Teräväinen 的对数级 \(U^2\) 控制强得多。该路线关闭为“等价门”，不再作为独立突破方向继续枚举阶数。

