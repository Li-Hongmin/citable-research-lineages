> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定 Mellin multiplier 不能免费把 Nyman 残差正则化

日期：2026-08-15。

本 note 固定一个容易被误用的桥接步骤：先对 Nyman--Beurling 残差施加
一个 Mellin/Weil multiplier，再声称平滑后的残差趋零，因此得到 RH。对固定
multiplier，这一步本身已经是 RH 强度。

## 1. 精确 Mellin 形式

令
\[
 e=\mathbf 1_{(0,1)},\qquad
 \eta_n(x)=-\left\{\frac1{nx}\right\}.
\]
在标准 Mellin 区间 (0<\Re s<1)，有
\[
 \mathcal Me(s)=\frac1s,
 \qquad
 \mathcal M\eta_n(s)=\frac{\zeta(s)n^{-s}}s.
\]
故有限 Dirichlet 多项式 (P(s)=\sum c_n n^{-s}) 对应的残差
\[
 f_P=e+\sum_n c_n\eta_n
\]
满足
\[
 \mathcal Mf_P(s)=\frac{1-\zeta(s)P(s)}s.
\tag{1}
\]

设 (K(s)) 是一个在某个半平面 (Re s>\sigma_0) 解析的固定 multiplier，且
乘法卷积 (C_K) 在所用 Mellin--Hardy 范数中有定义：
\[
 \mathcal M(C_Kf)(s)=K(s)\mathcal Mf(s).
\tag{2}
\]

## 2. 离线零点的点值障碍

若存在零点 \(\rho\) 满足 \(\Re\rho>\sigma_0\)、\(\zeta(\rho)=0\)，并且
\(K(\rho)\ne0\)，则对每一个有限 (P)，由 (1)--(2) 得
\[
 \mathcal M(C_Kf_P)(\rho)=\frac{K(\rho)}\rho .
\tag{3}
\]
右端与 (P) 无关。另一方面，半平面 Hardy 范数的点评价是连续的；因此若
存在一列 (P_j) 使
\[
 \|C_Kf_{P_j}\|_{H^2(\Re s>\sigma_0)}\longrightarrow0,
\tag{4}
\]
则点值也趋于零，与 (3) 矛盾。于是
\[
 \boxed{
 \text{固定且在 \(\rho\) 不消失的 Mellin multiplier 下的残差收敛}\
 \Longrightarrow \text{不存在这样的离线零点}.}
\]

这只是点评价连续性的直接推论，不需要假设 (K) 可逆；固定 multiplier
只要在该零点不为零就足够。

## 3. 对当前 detector/Weil 路线的边界

对固定 reciprocal detector (V)，(K=K_V) 在临界带无零时，任何通过
\(C_{K_V}f_{P_j}\to0\) 得到的全尺度估计都已经排除全部
\(\Re\rho>1/2\) 的零点。它不是比 RH 更弱的中间命题。

若改用 moving multiplier (K_N)，必须同时给出对每个可能离线零点的统一响应下界，
例如
\[
\inf_{\substack{\zeta(\rho)=0\\\Re\rho\ge1/2+\delta\\|\Im\rho|\le T_N}}
 |K_N(\rho)|>0.
\tag{5}
\]
当前 detector 层级的精确比值显示 (K_m(\rho)) 随 (m\) 快速衰减，故不能把
moving (m) 当作免费正则化。缺失的正是 (5) 或一个等强的 signed arithmetic
intertwiner；局部 Gram/Schur 正性本身不提供它。

本文是严格的路线边界，不是 RH 证明。
