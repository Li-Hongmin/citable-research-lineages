> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 指数尾核的 Lehmer 矩阵形式

日期：2026-08-16。

令
\[
L_N(m,n)=\frac{\min(m,n)}{\max(m,n)},
\qquad
v_N(n)=\frac1n,
\qquad
\boldsymbol\mu_N=(\mu(1),\ldots,\mu(N))^T.
\]
由
\[
\int_{\mathbb R}\frac{e^{it\log(n/m)}}{1+t^2}\,dt
=\pi\frac{\min(m,n)}{\max(m,n)}
\]
和 note 343 的定义，得到精确矩阵恒等式
\[
\boxed{
I_N
=\pi\,\boldsymbol\mu_N^T
\bigl(L_N-v_Nv_N^T\bigr)\boldsymbol\mu_N.}
\tag{1}
\]
这里 \(I_N=8\pi^3\|\mathcal K_{N,o}\|_2^2\)。

矩阵 \(L_N-v_Nv_N^T\) 本身正半定，因为其条目可写成
\[
\bigl(L_N-v_Nv_N^T\bigr)_{m,n}
=\frac{\min(m,n)^2-1}{mn}
=\sum_{k<\min(m,n)}\frac{2k+1}{mn}.
\tag{2}
\]
因此若令
\[
R_{k,n}=\frac{\sqrt{2k+1}}n{\bf1}_{k<n},
\]
则
\[
L_N-v_Nv_N^T=R^TR.
\tag{3}
\]
这与 note 341 的尾和平方恒等式完全一致。

式 (1) 把指数外函数的平方根门改写成一个具体的 Lehmer 型 Möbius
二次型。对任意一般向量，\(L_N\) 的行和为 \(O(N)\)，所以普通算子范数或
逐项绝对值只能给 \(O(N^2)\)；所需的 \(O(N^{1+\varepsilon})\) 正是
\(\boldsymbol\mu_N\) 在该核上的新 signed cancellation。note 345 已证明
这一幂次界对所有 \(N\) 与 RH 等价。

该离散形式的价值在于：后续若有新的数论输入，可以直接针对
\(L_N-v_Nv_N^T\) 的 Möbius 二次型检验，而无需再次经过外函数或 Fourier
归一化。

## 4. 未滤波 Lehmer 矩阵的精确望远镜

为区分真正的 RH 门与其未滤波上界，令
\[
 E_N^{L}:=\boldsymbol\mu_N^T L_N\boldsymbol\mu_N,\qquad
 B(n):=\sum_{m\le n}m\mu(m),\quad B(0)=0.
\]
按 \(m<n\) 分拆，并记 \(b_n=n\mu(n)\)，有
\[
 E_N^{L}
 =\sum_{n\le N}\mu(n)^2
  +2\sum_{n\le N}\frac{b_n B(n-1)}{n^2}.
\]
由于
\[
 B(n)^2-B(n-1)^2=2b_nB(n-1)+b_n^2,
 \qquad b_n^2/n^2=\mu(n)^2,
\]
得到完全有限的恒等式
\[
\boxed{
 E_N^{L}
 =\sum_{n=1}^{N}\frac{B(n)^2-B(n-1)^2}{n^2}
 =\frac{B(N)^2}{N^2}
 +\sum_{n<N}B(n)^2
   \left(\frac1{n^2}-\frac1{(n+1)^2}\right).
}
\]
因此未滤波核的正二次型恰是 \(B(n)\) 的加权平方能量。真正的指数尾门则为
\[
 \frac{I_N}{\pi}=E_N^{L}
 -\left(\sum_{n\le N}\frac{\mu(n)}n\right)^2,
\]
即只差一个显式 rank-one 项。该恒等式把剩余算术问题直接压缩为
\(M_1(x)=\sum_{n\le x}n\mu(n)\) 的全尺度均方；它没有提供无条件平方根估计，
但排除了把困难误归因于 Lehmer 核的矩阵代数。
