> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正算子有限压缩的 canonical 延拓与 metric Schur 公式

日期：2026-08-12。

本笔记中的抽象算子事实属于 classical shorted-operator / generalized
Schur-complement 框架，不作为新的抽象算子定理声称。直接背景见 Anderson--Trapp,
*Shorted Operators. II* (1975), DOI
[`10.1137/0128007`](https://doi.org/10.1137/0128007)；Morley (1990), DOI
[`10.1007/BF01236449`](https://doi.org/10.1007/BF01236449)；以及 Li--Mathias
(2004), DOI [`10.1137/S0036144599337290`](https://doi.org/10.1137/S0036144599337290)。
本项目中的新用途是：它给出 Weil--Yukawa--Feshbach 区间认证的精确
Loewner 接口，并定位出孤立 Galerkin 正压缩无法晋级为全空间下模型的具体失效点。

令 \(Y\succeq0\) 为有界正算子，\(P\) 为有限秩正交投影。一般没有

\[
PYP\oplus0\preceq Y.
\]

例如 \(Y=\begin{psmallmatrix}1&1\\1&1\end{psmallmatrix}\)、
\(P=\operatorname{diag}(1,0)\) 时，两者之差行列式为 \(-1\)。因此在
Galerkin 块中孤立加入正压缩会删除无定号的 cross block，不是 Loewner 下界。

写 \(Y=WW^*\)，令 \(\Pi\) 为到
\(\overline{\operatorname{ran}(W^*P)}\) 的正交投影，则

\[
Y_{\rm can}=W\Pi W^*=YP(PYP)^\dagger PY\preceq Y.
\]

它精确保留 \(P\)-压缩，并强制保留相应 cross 与补块。若
\(T=PYP>0\)，且相对于 \(P\oplus Q\)

\[
Y=\begin{pmatrix}T&R\\R^*&U\end{pmatrix},
\]

则

\[
Y_{\rm can}=\begin{pmatrix}T&R\\R^*&R^*T^{-1}R\end{pmatrix}\preceq Y.
\]

设加入该子因子前的算子为
\(M_0=\begin{psmallmatrix}A&X\\X^*&C\end{psmallmatrix}\)，\(C>0\)。
定义

\[
M=RC^{-1}R^*,\qquad N=XC^{-1}R^*.
\]

则无需显式构造 \(T^{-1/2}\)，canonical 子因子的 true-Schur 增益为

\[
\boxed{\Delta_Y=(T-N)(T+M)^{-1}(T-N)^*.}
\]

等价地，在非正交 metric 坐标中若 \(F=YZ\)、
\(K=Z^*YZ>0\)，则子因子为 \(FK^{-1}F^*\)；所有补空间消去必须在
同一 metric 中保留 cross。对加权无限补空间，有限前缀和尾界也必须形成
联合 Gram

\[
\sum_q t_q^{-1}\binom{x_q}{r_q}\binom{x_q}{r_q}^*,
\]

不能分别估计对角块后丢弃 signed cross。canonical 延拓是把有限
PSD recovery 晋级为全空间 Loewner 下模型的一个标准充分接口；真正必要的是
构造合法的全空间 Loewner 子因子，并保留或控制所有 cross blocks。
