> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Polynomial-Chowla 高阶矩定理不能关闭固定斜率四点门

日期：2026-08-17。

## 1. 被核对的结果

2025 年的 *Higher Moments for Polynomial Chowla* 给出的是对多项式系数盒子的平均结果。其典型形式为：固定次数、测试长度和误差参数，在系数范数不超过 (H) 的全部多项式上，对
\[
 X^{-1/2}\sum_{n\le X} b_n\prod_i\lambda(f_i(n))
\]
或其二阶矩求和；当 (X\le(\log H)^\delta) 时，主项加上 (H^D(\log H)^{-A}) 级误差。定理 1.5 还允许 (|b_n|\le1)。原始来源：
<https://oup.silverchair-cdn.com/article-minimal/8114239>。

这是真正的高阶 Chowla 平均进展，但平均变量是多项式系数，不是固定斜率的移位参数。

## 2. 与当前 Lehmer 四点门的对象差异

note 434 的充分门要求，对每个固定 (N) 和每个 dyadic (H)，
\[
 \sum_{H<h\le2H}|C_N(h)|^2
 \ll_\varepsilon N^{2+\varepsilon}/H,
 \qquad
 C_N(h)=\sum_{m\le N-h}\mu(m)\mu(m+h)
 \frac{m^2-1}{m(m+h)}.
\tag{1}
\]
平方展开后，(1) 是带移动比值振幅的平行四边形四点相关
\[
 \mu(m)\mu(m+h)\mu(m+d)\mu(m+d+h).
\tag{2}
\]

相反，定理 1.5 在最简单的线性情形控制的是类似
\[
 \sum_{a,b}|X^{-1/2}\sum_n b_n\lambda(an+b)|^2,
\tag{3}
\]
其中 ((a,b)) 在一个大系数盒子中平均。即使把 (a=1) 的切片单独看，得到的也是
\[
 \sum_b\left|\sum_n b_n\mu(n+b)\right|^2,
\tag{4}
\]
而不是
\[
 \sum_h\left|\sum_m\mu(m)\mu(m+h)w(m,h)\right|^2.
\tag{5}
\]
前者是一个以 (b) 为外层参数的 Toeplitz 型二次型，后者先形成每个移位的二点相关，再对移位平方；其平方是 (2) 的四点收缩。两者没有可逆的重标或简单 Fubini 恒等式把 (3) 变成 (1)。

需要保留一个重要的近邻事实：若形式上取定两条线性多项式
\(f_1(n)=n\)、\(f_2(n)=n+h\)，再取定 (k=2)，则
\[
 \left(\sum_n b_n\lambda(n)\lambda(n+h)\right)^2
\]
的展开确实含有四点平行四边形。因此该定理的“高阶矩机制”与 (2) 同型；真正缺失的是把这两个多项式的系数固定在斜率 (1)、截距差 (h)，并对每个 (h) 保留精确的比值振幅。论文的定理把所有系数一起平均，不能从总和中无损抽出这条固定系数切片。

此外，论文使用的是 Liouville 函数 (lambda)。目标门使用 Möbius 函数 (mu) 及
\( (m^2-1)/(m(m+h))\) 权；将 \(lambda\) 换成 \(mu=\lambda\,1_{\mathrm{squarefree}}\) 还需要处理随 (m+h) 移动的平方因子条件，这不是有界序列 (b_n) 可以自动吸收的。

## 3. 为什么不能从系数平均抽出固定斜率

系数盒子平均允许一个固定斜率切片成为异常切片。若总系数对象数为约 (H^D)，一个固定切片的异常贡献在总平均中只占 (H^{-D}) 的权重；平均定理的误差完全可以吸收该切片。因此“所有系数的平均小”不推出斜率 (a=1) 的均匀小量，更不推出对每个 (h) 的 (H^{-1}) 四点衰减。

在最接近目标的 (s=2,d_1=d_2=1) 情形，总系数元组约有 (H^4) 个，而目标的
\(f_1(n)=n, f_2(n)=n+h\) 只给出约 (H) 个固定斜率元组；从总的非负二阶和抽取这条切片，最坏会损失 (H^3)，远大于 (1) 所需的 (H^{-1}) 结构。定理的误差项按总盒子体积归一化，不能消除这个切片损失。

即便先对 (3) 使用 Cauchy，再尝试按 (b) 或 (h) 重排，也只得到一阶移位平均与二阶平方之间的粗糙上界。note 434 已给出抽象极值：在 (|A_h|\le N) 且 (sum_h|A_h|\le NH\rho) 时，仍可能有
\[
 \sum_h|A_h|^2\asymp N^2H\rho,
\]
而不是所需的 (N^2/H)。

## 4. 当前裁决

该文献结果应吸收为“与四点平行四边形同型、但对多项式系数平均的 Liouville 高阶 Chowla 工具”。它不能直接作为固定斜率、固定比值、带移动振幅的 Lehmer 四点门的证明。要关闭 note 434，仍需新的 uniform fixed-slope four-point estimate，或保持 Möbius 符号的跨移位 signed intertwiner；当前没有从该定理得到此输入。

这是一条路线边界，不是 RH 证明，也不是对该文献结果的否定。
