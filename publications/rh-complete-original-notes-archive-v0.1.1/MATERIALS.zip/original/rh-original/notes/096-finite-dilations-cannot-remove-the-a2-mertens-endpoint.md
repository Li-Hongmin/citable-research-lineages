> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有限 dilation 滤波不能消除 \(a=2\) cell 的 Mertens 端点

日期：2026-08-14。

依赖：[note 094](094-k1-a2-high-divisor-cell-has-a-zero-free-mellin-detector.md)、
[note 095](095-k1-a2-cell-reduces-to-moving-scale-mobius-covariance.md)。

证据等级：分布导数恒等式与有限离散 Abel 恒等式。本文只关闭固定有限尺度滤波的端点消去，
不排除不同 Mertens 值之间的 RH 级算术消去。

## 1. 尺度滤波

沿用

\[
F(t)=\log\frac1t\left(\frac2{\pi t}+\sin2\pi t\right)
\mathbf1_{(2/3,1)}(t),
\qquad
K(s)=\int_0^\infty F(t)t^{s-1}\,dt.
\tag{1}
\]

置

\[
\kappa:=F(2/3+)
=\log\frac32\left(\frac3\pi-\frac{\sqrt3}{2}\right)>0,
\qquad F(1-)=0.
\tag{2}
\]

令 \(\lambda_1,\ldots,\lambda_m>0\) 互异，\(c_1,\ldots,c_m\in\mathbb C\)，并定义

\[
G(t):=\sum_{j=1}^mc_jF(t/\lambda_j),
\qquad
P(s):=\sum_{j=1}^mc_j\lambda_j^s.
\tag{3}
\]

则 Mellin 变换精确因子化为

\[
\boxed{
\int_0^\infty G(t)t^{s-1}\,dt=K(s)P(s).
}
\tag{4}
\]

因此有限 dilation 只给 note 094 的 detector 乘一个指数多项式 \(P\)。即使另证
\(P\) 在右半临界带无零，下节的端点刚性仍不改变。

## 2. 跳跃原子刚性

在分布意义下，

\[
DF=\kappa\,\delta_{2/3}
+F'_{\rm cl}(t)\mathbf1_{(2/3,1)}(t)\,dt.
\tag{5}
\]

右端 \(t=1\) 没有原子，因为 \(F(1-)=0\)。缩放给出

\[
D\bigl[F(\,\cdot\,/\lambda_j)\bigr]
=\kappa\,\delta_{2\lambda_j/3}
+\frac1{\lambda_j}F'_{\rm cl}(t/\lambda_j)
\mathbf1_{(2\lambda_j/3,\lambda_j)}(t)\,dt.
\tag{6}
\]

故

\[
\boxed{
DG=\kappa\sum_{j=1}^mc_j\delta_{2\lambda_j/3}
+\sum_{j=1}^m\frac{c_j}{\lambda_j}F'_{\rm cl}(t/\lambda_j)
\mathbf1_{(2\lambda_j/3,\lambda_j)}(t)\,dt.
}
\tag{7}
\]

原子位置 \(2\lambda_j/3\) 互异。即使某个 \(2\lambda_i/3=\lambda_j\)，后者只是另一
项的零值右端，并不提供反向原子。因此得到：

**定理 1（有限 dilation 跳跃刚性）。**

\[
\boxed{
G\text{ 在 }(0,\infty)\text{ 无跳跃}
\Longleftrightarrow
c_1=\cdots=c_m=0.
}
\tag{8}
\]

这里必须把 \(\operatorname{supp}G\) 的全局左端计入；若人为只看支撑的相对内部，单个
dilation 已是伪反例，而该左端正是 Abel 公式中的 Mertens 项。

```mermaid
flowchart LR
  F["F: left jump κ, right value 0"] --> L1["scale λ₁: atom at 2λ₁/3"]
  F --> L2["scale λ₂: atom at 2λ₂/3"]
  F --> Lm["scale λₘ: atom at 2λₘ/3"]
  L1 --> J["distinct atoms: no finite cancellation"]
  L2 --> J
  Lm --> J
```

## 3. 有理尺度上的精确 Möbius--Abel 公式

再设 \(\lambda_j=p_j/q_j\in\mathbb Q_{>0}\) 为既约分数，并令

\[
L:=\operatorname{lcm}_{1\le j\le m}(3q_j),
\qquad N\in L\mathbb N,
\qquad
a_j:=\frac{2\lambda_jN}{3},\qquad b_j:=\lambda_jN.
\tag{9}
\]

于是 \(a_j,b_j\in\mathbb N\)，且互异 \(\lambda_j\) 给出互异 \(a_j\)。令
\(M(x)=\sum_{d\le x}\mu(d)\)。逐 dilation 作离散 Abel 求和，得到

\[
\boxed{
\begin{aligned}
\sum_{d\ge1}\mu(d)G(d/N)
={}&-\sum_{j=1}^mc_j
F\!\left(\frac23+\frac1{\lambda_jN}\right)M(a_j)\\
&+\sum_{j=1}^mc_j
\sum_{d=a_j+1}^{b_j-1}M(d)
\left[
F\!\left(\frac d{\lambda_jN}\right)
-F\!\left(\frac{d+1}{\lambda_jN}\right)
\right].
\end{aligned}
}
\tag{10}
\]

由于

\[
F\!\left(\frac23+\frac1{\lambda_jN}\right)
=\kappa+O_{\lambda_j}(N^{-1}),
\tag{11}
\]

第 \(j\) 个 jump 在全局 Abel 表示中给 \(M(a_j)\) 的系数

\[
-\kappa c_j+O_{G}(N^{-1}).
\tag{12}
\]

其它 dilation 在该格点只贡献光滑差分 \(O_G(N^{-1})\)；右端重合仍无原子。因此对所有
充分大的公共倍数 \(N\)，每个 \(c_j\ne0\) 都留下一个非零 Mertens 端点系数。

## 4. 结论边界

不存在非零的固定有限正 dilation 组合，使 note 094 的权函数在 kernel/Abel 层变成
endpoint-free。由 (4)，这对所有额外满足 \(K(s)P(s)\ne0\) 的 detector-preserving
组合仍成立。

本文没有断言 (10) 中不同的 \(M(a_j)\) 不能在特殊 \(N\) 上偶然抵消，也没有排除它们与
光滑差分项之间的深层 signed cancellation。该剩余算术问题仍是 note 095 的移动尺度
Möbius covariance 门，而不是有限尺度 telescope。
