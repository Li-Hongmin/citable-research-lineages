> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Collar UCP、严格域单调与第一次立即负穿越

日期：2026-08-11。本文完成 M2-R3 的严格归约部分：把谱底可能出现的平台，等价地压缩为
“较大区间的基态是否可能严格支撑在较小区间”；并证明只要排除这种 collar 模态，首次零点就是
唯一零尺度，随后立即进入负谱。本文不宣称已经证明扰动后 UCP。

## 1. 等号情形的精确刻画

记

\[
\lambda_1(a)=\inf_{0\ne u\in H((-a,a))}
\frac{Q_W^a(u,u)}{\lVert u\rVert_2^2}.
\]

对 \(0<a<b\)，令 \(J_{a,b}\) 为零延拓。note 003 已证明

\[
J_{a,b}H((-a,a))\subset H((-b,b)),\qquad
Q_W^b(J_{a,b}u,J_{a,b}u)=Q_W^a(u,u).
\]

因此 \(\lambda_1(b)\le\lambda_1(a)\)。这个不等式取等的情形可以完全刻画。

**命题 1（平台等价于 collar 支撑基态）。** 对 \(0<a<b\)，以下两件事等价：

1. \(\lambda_1(b)=\lambda_1(a)\)；
2. \(A_b\) 的最低本征空间含有一个非零函数 \(u\)，且
   \(u=0\) a.e. 于 \((-b,-a)\cup(a,b)\)。

**证明。** 取 \(A_a\) 的归一化最低本征函数 \(v_a\)。若两个谱底相等，则

\[
\frac{Q_W^b(J_{a,b}v_a,J_{a,b}v_a)}{\lVert J_{a,b}v_a\rVert_2^2}
=\lambda_1(b).
\]

所以 \(J_{a,b}v_a\) 达到 \(Q_W^b\) 的 Rayleigh 下确界。闭形式的 Euler--Lagrange 方程给出

\[
J_{a,b}v_a\in D(A_b),\qquad
A_bJ_{a,b}v_a=\lambda_1(b)J_{a,b}v_a.
\]

它按定义在两个 collar 上为零。

反之，若 \(A_b\) 的一个归一化基态 \(u\) 支撑在 \([-a,a]\)，则 note 004 的能量域刻画和同一
闭形式恒等式给出 \(u\in H((-a,a))\) 以及

\[
\lambda_1(a)\le Q_W^a(u,u)=Q_W^b(u,u)=\lambda_1(b).
\]

再结合反向的域单调不等式即得等号。\(\square\)

这个命题说明，M2-R3 不需要先证明所有特征函数的完整唯一延拓。严格谱底单调所需的最小性质只是：

\[
\boxed{
\text{较大区间 }(-b,b)\text{ 的非零基态不能在任一非空 collar 上恒零。}}
\]

下文称它为 **ground-state collar UCP**。

## 2. 严格单调与首次穿越

**推论 2。** 若每个 \(b>0\) 都满足 ground-state collar UCP，则

\[
\boxed{0<a<b\quad\Longrightarrow\quad\lambda_1(b)<\lambda_1(a).}
\]

这是命题 1 的直接逆否命题。

假设 RH 为假，并按此前定义

\[
a_*=\inf\{a>0:\lambda_1(a)\le0\}.
\]

note 006 已证明 \(\lambda_1\) 连续，故 \(\lambda_1(a_*)=0\)。若再有 ground-state collar UCP，
则严格单调立即给出

\[
\boxed{
\lambda_1(a)>0\ (a<a_*),\qquad
\lambda_1(a_*)=0,\qquad
\lambda_1(a)<0\ (a>a_*).}
\]

因此：

- \(a_*\) 是唯一的零尺度；
- 不存在零本征值平台；
- 第一次退化零模态在任意更大尺度上已经产生负方向；
- norm-resolvent 连续谱流中的第一次 crossing 不再可能只是在零上停留。

这仍不证明 crossing 对尺度可微或横截；“立即为负”比非零导数弱。

## 3. Weil 方程需要的 UCP 与纯 \(L_\Delta\) UCP 不同

设 \(u\in D(A_b)\) 是本征函数，并在开区间 \(I\Subset(-b,b)\) 上恒零。由 note 004，

\[
\frac12L_\Delta u-\log(2\pi)u-P_bu-R_bu=\lambda u.
\]

在 \(I\) 上，含 \(u\) 的对角项消失，但一般仍有

\[
\boxed{L_\Delta u=2P_bu+2R_bu\quad\text{on }I.}
\]

有限平移 \(u(x\pm\log n)\) 和光滑卷积 \(R_bu(x)\) 不因 \(u(x)=0\) 自动消失。因此现有的

\[
u=L_\Delta u=0\text{ on }I\quad\Longrightarrow\quad u\equiv0

\]

不能直接使用。这里也解释了为何乘法势扰动的 UCP 结果不够：若右端是 \(V(x)u(x)\)，它在
零区间自动消失；平移和卷积扰动没有这个性质。

## 4. 平移核完备性：当前最直接的功能分析目标

把完整非对角部分写成平移不变分布核 \(\kappa_W\)。若 \(u=0\) 于开区间 \(I\)，取
\(I'\Subset I\)，则对 \(x\in I'\)，核与 \(u\) 的支撑之间有正距离，因而

\[
(\kappa_W*u)(x)
=\langle\kappa_W(x-\cdot),u\rangle

\]

是合法的普通核/有限原子配对。在固定有界尺度上只出现有限个 prime-power 原子。于是一个足够的
UCP 条件是：

\[
\boxed{
\operatorname{span}\left\{
\kappa_W(x-\cdot)\big|_{[-b,b]\setminus I}:x\in I'
\right\}
\text{ 在与连续能量函数配对的弱拓扑中具有零湮灭子。}}
\]

也就是说，若某个连续 exterior-zero 能量函数与所有这些局部平移都配对为零，则该函数必须为零。
note 007 已保证 Weil 本征函数确实有连续代表，所以这个分离条件足以排除 collar 基态。

Berger--Schilling 2026 对 Lévy 算子证明了相应的必要充分条件：Lévy 测度局部平移的线性包在有界
符号 Radon 测度空间中 vaguely dense，当且仅当算子满足 UCP。其 Hahn--Banach 湮灭子论证解释了
上面的目标为何自然。

但该定理不能直接覆盖 Weil 算子：

1. 它要求正的 Lévy 测度和连续负定符号；
2. \(L_\Delta\) 是 \(s=0\) 的对数端点，低频符号不具 Lévy 生成元所需的全局非负性；
3. Suzuki 的完整核还含带符号光滑部分与 prime-power 原子；
4. 从 Radon 测度推广到当前能量域/分布核时，必须重新指定配对拓扑并证明平滑逼近合法。

所以这篇新论文提供的是一个精确证明模板，而不是已经完成的 M2-R3。

## 5. 与边界非退化路线的关系

还有一条更弱、可能更便宜的排除机制。若较小区间基态 \(v_a\) 的零延拓也是较大区间本征函数，
则它在 \(a\) 外侧 collar 满足上节方程。若能证明某个 signed logarithmic boundary coefficient
非零，而 \(P_bv_a+R_bv_a\) 在该边界附近保持有界，则纯 \(L_\Delta\) 的外侧边界奇性不能被右端
抵消，从而得到矛盾。

note 007 目前只给出

\[
|v_a(x)|=O\!\left(\ell(a-|x|)^{1/2}\right),
\]

没有非零下界或 signed 极限。因此这条边界论证尚未闭合，但它表明 M2-R3 与剩余的 M2-R2
非退化边界系数不是两个无关问题：任一方向成功都可排除谱底平台。

## 6. 下一项最小判别

后续不再泛化地搜索“任意非局部 UCP”，而只检验以下两项中哪一项更先闭合：

1. **平移完备性判别：** 对 Suzuki 的显式 \(\kappa_W\)，证明上述局部平移族的湮灭子为零，至少
   先限制到 ground-state 方程可能产生的连续能量函数；
2. **边界系数判别：** 证明首次退化零模态至少一个端点的 signed \(\ell(d)^{1/2}\) 系数非零，并
   计算零延拓后 \(L_\Delta v\) 的外侧主项。

前者给出真正的 perturbative collar UCP；后者虽然更弱，但已经足以得到严格谱底单调和立即负穿越。

note 011 随后已在 prime-free collar 上完成第一种判别：若 collar 含有不被任何
\([\log n-a,\log n+a]\) 覆盖的开区间，则 Archimedean 核的完备指数矩强迫模态为零。特别地，
\(a<\frac12\log2\) 时谱底对任意扩域严格下降。剩余范围从这里开始才真正需要处理活跃的 finite
shifts。

## 7. 来源与新结论边界

- Huyuan Chen, Daniel Hauer and Tobias Weth,
  *An extension problem for the logarithmic Laplacian*,
  [arXiv:2312.15689](https://arxiv.org/abs/2312.15689)：纯 \(L_\Delta\) 的弱 UCP。
- David Berger and René L. Schilling,
  *On the Unique Continuation Principle for a Class of Translation Invariant Nonlocal Operators*,
  [arXiv:2604.02357](https://arxiv.org/abs/2604.02357)：Lévy 类的局部平移测度完备性判据和 resolvent
  UCP 等价。
- Masatoshi Suzuki, *Weil's quadratic form via the screw function*,
  [arXiv:2606.09096](https://arxiv.org/abs/2606.09096)：局部 Weil 闭形式与卷积核。

平台等价于 collar 支撑基态、ground-state collar UCP 足以推出严格谱底单调、以及第一次零尺度后的
立即负穿越，是本项目的新推论。本文没有证明 Weil 的平移核完备性，也没有证明非退化边界系数。
