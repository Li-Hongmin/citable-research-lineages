> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# reciprocal 单包估计是 RH 强度，但固定带局部可观测性失败

日期与检索截止：2026-08-13。

依赖：[note 074](074-mellin-poles-force-dyadic-mean-shell-growth.md)、
[note 076](076-cutoff-fourier-average-leaves-farey-near-collisions.md)。

## 1. 弄清问题

固定

\[
I=[\alpha,\eta]\Subset(0,1),
\qquad e(z):=e^{2\pi iz},
\tag{1}
\]

并令

\[
A_Y(c):=\sum_{d/Y\in I}\mu(d)\log\frac Yd\,e(cY/d),
\qquad
B_Y(c):=\sum_{d/Y\in I}\mu(d)e(cY/d).
\tag{2}
\]

note 076 的 \(h=1\) PSD 原子正是

\[
\boxed{
\mathfrak P_I(Y):=
\int_1^2\!\int_1^2
x\left|A_Y(xt)+(\log x)B_Y(xt)\right|^2dt\,dx.
}
\tag{3}
\]

本 note 判别：

\[
\begin{array}{ll}
\text{(a)}&
\operatorname{spec}f\Subset(0,\infty)
\ \Longrightarrow?\
|f(0)|^2\lesssim\|f\|_{L^2([3/2,2])}^2,\\[1mm]
\text{(b)}&
\mathfrak P_I(Y)\ll_\varepsilon Y^{1+\varepsilon}
\text{ 的真实算术强度。}
\end{array}
\tag{4}
\]

## 2. 拟定计划

\[
\text{Gram 分离}
\to
\text{超振荡反例}
\to
\text{解析传播}
\to
\text{Mertens 指数自举}.
\tag{5}
\]

## 3. 实现计划

### 3.1 \(A_Y,B_Y\) 在观察区间上可一致分离

在 (3) 中作 \(c=xt\)。因 \(x\,dt=dc\)，

\[
\mathfrak P_I(Y)
=\int_1^4\int_{J_c}
|A_Y(c)+(\log x)B_Y(c)|^2dx\,dc,
\tag{6}
\]

其中

\[
J_c=[1,2]\cap[c/2,c].
\tag{7}
\]

若 \(K=[3/2,2]\)，则 \(J_c=[1,c]\)。令

\[
G(c):=\int_1^c
\begin{pmatrix}1\\ \log x\end{pmatrix}
\begin{pmatrix}1&\log x\end{pmatrix}dx.
\tag{8}
\]

对任意 \((u,v)\ne(0,0)\)，

\[
\begin{pmatrix}\bar u&\bar v\end{pmatrix}
G(c)
\begin{pmatrix}u\\v\end{pmatrix}
=\int_1^c|u+v\log x|^2dx>0.
\tag{9}
\]

连续性与 \(K\) 的紧性给出绝对常数 \(\kappa>0\)，使

\[
G(c)\succeq\kappa I_2
\qquad(c\in K).
\tag{10}
\]

故

\[
\boxed{
\mathfrak P_I(Y)\ge
\kappa\int_{3/2}^{2}
\bigl(|A_Y(c)|^2+|B_Y(c)|^2\bigr)dc.
}
\tag{11}
\]

### 3.2 固定频带不提供一致线性外推

一般命题

\[
\operatorname{spec}f\subset[p,q]
\quad\Longrightarrow?\quad
|f(0)|^2\ll_{p,q}\int_{3/2}^{2}|f(c)|^2dc
\tag{12}
\]

是假的。

取

\[
c_*:=\frac74,
\qquad
[\lambda_0,\lambda_0+\Delta]\Subset[p,q],
\qquad
\delta_n:=\frac\Delta n,
\tag{13}
\]

并定义

\[
f_n(c):=
e(\lambda_0c)
\left(
\frac{1-e(\delta_n(c-c_*))}
{1-e(-\delta_nc_*)}
\right)^n.
\tag{14}
\]

二项式展开给出

\[
\operatorname{spec}f_n
\subset\{\lambda_0+k\delta_n:0\le k\le n\}
\subset[p,q],
\qquad f_n(0)=1.
\tag{15}
\]

另一方面，在 \(K=[3/2,2]\) 上，

\[
|f_n(c)|
=\left|
\frac{\sin(\pi\delta_n(c-c_*))}
{\sin(\pi\delta_nc_*)}
\right|^n
\le r^n
\tag{16}
\]

对充分大 \(n\) 及某个固定 \(r<1\) 成立，因为

\[
\sup_{c\in K}\frac{|c-c_*|}{c_*}=\frac17.
\tag{17}
\]

所以

\[
\int_K|f_n(c)|^2dc\to0,
\qquad f_n(0)=1.
\tag{18}
\]

该反例还可嵌入精确 reciprocal 格点。对固定 \(n,k\)，取

\[
d_{Y,k}:=
\left\lfloor
\frac{Y}{\lambda_0+k\delta_n}+\frac12
\right\rfloor.
\tag{19}
\]

则 \(Y/d_{Y,k}\to\lambda_0+k\delta_n\)，并且对充分大 \(Y\)，所有
\(d_{Y,k}/Y\in I\) 且互异。先固定 \(n\)，再令 \(Y\to\infty\)，即可把
(18) 一致逼近到 \(\{0\}\cup K\)。故不存在只依赖 \(I\) 的常数 \(C_I\)，使

\[
|f(0)|^2\le C_I\int_K|f(c)|^2dc
\tag{20}
\]

对所有 reciprocal-grid 指数多项式成立。

这与 Nazarov 1993 的 Turán--Nazarov 定理完全一致：\(n\) 项指数多项式的
局部到整体常数含

\[
\left(\frac{A|J|}{|E|}\right)^{n-1},
\tag{21}
\]

而当前项数 \(n\asymp Y\)。Logvinenko--Sereda 型定理需要全轴上的 thick
观察集，也不能用于单个远离 \(0\) 的固定区间。

### 3.3 可用替代物：带全域先验的 Hölder 传播

**引理 1（解析传播）。** 固定 \(K=[3/2,2]\)。存在固定复邻域
\(\Omega\supset[0,2]\) 及常数 \(C>0,\theta\in(0,1)\)，使每个在
\(\Omega\) 上全纯的 \(f\) 满足

\[
\boxed{
|f(0)|
\le C
\left(\sup_{z\in\Omega}|f(z)|\right)^{1-\theta}
\|f\|_{L^2(K)}^\theta.
}
\tag{22}
\]

**证明。** 取光滑有界域 \(\Omega_0\Subset\Omega\)，使
\([0,2]\Subset\Omega_0\)，再取闭区间 \(K_0=[a_0,b_0]\Subset K\)。令

\[
\mathcal D:=\Omega_0\setminus K_0.
\tag{23}
\]

把 slit \(K_0\) 的上下两侧合记为 \(\Gamma\)。若 \(\omega_0\) 是
\(\mathcal D\) 在 \(0\) 处的调和测度，则

\[
\theta:=\omega_0(\Gamma)\in(0,1).
\tag{24}
\]

归一化 slit 测度 \(d\nu=\theta^{-1}d\omega_0|_\Gamma\) 在 \(K_0\) 上有密度

\[
d\nu=h(t)dt,
\qquad
h(t)\ll|t-a_0|^{-1/2}+|b_0-t|^{-1/2}.
\tag{25}
\]

这是 slit 端点经平方根共形映射拉直后的标准调和测度估计。因此
\(h\in L^{4/3}(K_0)\)。若 \(\delta=\|f\|_{L^2(K)}\)，则 Hölder 与 Jensen 给出

\[
\int_{K_0}|f|^{1/2}d\nu\ll\delta^{1/2},
\qquad
\int_{K_0}\log|f|d\nu\le\log(C_0\delta).
\tag{25a}
\]

对次调和函数 \(\log|f|\) 使用调和测度最大原理：

\[
\log|f(0)|
\le(1-\theta)\log M
+\theta\int_{K_0}\log|f|d\nu,
\qquad M:=\sup_{\Omega_0}|f|.
\tag{25b}
\]

结合 (25a) 即得 (22)。以
\(\frac12\log(|f|^2+\rho^2)\) 正则化并令 \(\rho\downarrow0\)，可同时处理零点。
\(\square\)

### 3.4 单包平方根均方对所有尺度成立，当且仅当 RH

**定理 2（packet--RH 等强性）。** 固定任意
\(I=[\alpha,\eta]\Subset(0,1)\)。以下两命题等价：

\[
\mathrm{RH};
\tag{26}
\]

\[
\forall\varepsilon>0,\qquad
\mathfrak P_I(Y)\ll_{I,\varepsilon}Y^{1+\varepsilon}
\quad\text{对所有充分大的实数 }Y.
\tag{27}
\]

**证明 \((27)\Rightarrow(26)\)。** 设对某个
\(\sigma\in[1/2,1]\) 已知

\[
M(x)\ll_\varepsilon x^{\sigma+\varepsilon}
\qquad(\forall\varepsilon>0).
\tag{28}
\]

平凡界给出起点 \(\sigma=1\)。对固定 \(z\in\Omega\)，离散分部求和及

\[
\frac d{dt}e(zY/t)=O_{I,\Omega}(Y^{-1})
\qquad(t\asymp Y)
\tag{29}
\]

给出

\[
\sup_{z\in\Omega}|B_Y(z)|
\ll_{I,\Omega,\varepsilon}Y^{\sigma+\varepsilon}.
\tag{30}
\]

另一方面，(11) 与 (27) 给

\[
\|B_Y\|_{L^2(K)}
\ll_{I,\varepsilon}Y^{1/2+\varepsilon}.
\tag{31}
\]

将 (30)--(31) 代入 (22)，并重新命名 \(\varepsilon\)，得到

\[
|B_Y(0)|\ll_{I,\varepsilon}Y^{\sigma'+\varepsilon},
\qquad
\sigma':=(1-\theta)\sigma+\frac\theta2.
\tag{32}
\]

令 \(r=\alpha/\eta\)。对整数 \(n\)，取实数 \(Y=n/\eta\) 及

\[
m(n):=\lceil rn\rceil-1.
\tag{33}
\]

则精确地

\[
B_{n/\eta}(0)=M(n)-M(m(n)),
\qquad m(n)<rn.
\tag{34}
\]

递归定义 \(n_0=n,\ n_{j+1}=m(n_j)\)，并在 \(n_j=O(1)\) 时终止。于是

\[
n_j\le r^jn,
\qquad
M(n)=M(n_J)+\sum_{j<J}\bigl(M(n_j)-M(n_{j+1})\bigr).
\tag{35}
\]

故 (32) 与几何级数给出

\[
M(n)\ll_{I,\varepsilon}n^{\sigma'+\varepsilon}.
\tag{36}
\]

因此每次迭代都把可用指数变为

\[
\sigma-\frac12
\longmapsto
(1-\theta)\left(\sigma-\frac12\right).
\tag{37}
\]

从 \(\sigma_0=1\) 出发，有限次迭代可进入任意
\(1/2+\varepsilon\)，所以

\[
M(x)\ll_\varepsilon x^{1/2+\varepsilon}.
\tag{38}
\]

这是 RH 的经典等价形式。

反之，RH 给 (38)。对 (2) 中两个固定平滑权再作分部求和，得

\[
A_Y(c),B_Y(c)\ll_{I,\varepsilon}Y^{1/2+\varepsilon}
\qquad(1\le c\le4).
\tag{39}
\]

代入 (3) 即得 (27)。\(\square\)

### 3.5 量词边界

定理 2 要求 (27) 对所有大尺度 \(Y\) 成立。若只在 \(Y=2^k\) 上控制一个固定
\(I\)，(34) 只给一族固定 dyadic 子块，不能控制块内任意末端；上述几何望远镜与
分部求和自举尚不能闭合。

因此准确裁决为

\[
\boxed{
\begin{array}{ll}
\text{all-scale 单包估计}&\Longleftrightarrow\mathrm{RH},\\
\text{dyadic 单固定块估计}&\text{尚未证明等价},\\
\text{一般固定带线性可观测性}&\text{错误}.
\end{array}}
\tag{40}
\]

## 4. 回顾

note 076 的逐包正估计不是可由普通 band-limited 分析补上的弱引理。其 all-scale
版本已经是 RH 等强目标。故 Fourier 路线若要产生更弱的新输入，必须保留全部
\(h\) 后利用不同 packet 的联合抵消；不能逐 \(h\) 取绝对值。

原始文献：F. L. Nazarov, *Local estimates for exponential polynomials and their
applications to inequalities of the uncertainty principle type*, Algebra i Analiz 5
(1993), 3--66；本地全文：
[PDF]([unbundled local reference])。

本 note 新增 (11)、(14)--(20) 的 reciprocal-grid 超振荡反例，以及定理 2 的
解析传播--Mertens 指数自举。它没有证明 (27)，因而尚未证明 RH。
