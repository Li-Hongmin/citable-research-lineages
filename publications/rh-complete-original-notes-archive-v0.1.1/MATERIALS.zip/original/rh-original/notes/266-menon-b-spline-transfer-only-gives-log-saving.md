> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Menon 短区间均方经 B-spline 只给固定 Mellin 壳的对数级上界

日期：2026-08-16。

本 note 把 Menon 预印本的短区间均方与二次核能量的关系写成一个精确
解析恒等式，并区分它能够控制的加性模型与本项目的固定 Mellin 比例核。
结论是：即使把短区间结果无损转移到每个平滑 dyadic 壳，得到的仍是
\(N^{2-o(1)}\) 的对数级节省；真正的 \(N^{1+\varepsilon}\) 门仍需
跨移位的 signed cancellation。

## 1. 三角 B-spline 恒等式

令 \(a=(a_n)\) 是有限支撑复序列，零延拓到 \(\mathbb R\)，并定义

\[
 S_a(x,h):=\sum_{x<n\le x+h}a_n,\qquad
 Q_a(h):=\int_{\mathbb R}|S_a(x,h)|^2\,dx .
\]

两个整数 \(m,n\) 同时落在区间 \((x,x+h]\) 的 \(x\)-测度恰为
\((h-|m-n|)_+\)。因此

\[
 Q_a(h)=
 \sum_{m,n}a_m\overline{a_n}(h-|m-n|)_+ .
\tag{1}
\]

若 \(f\in C^2([0,\infty))\) 且 \(f,f'\) 在无穷远消失，则两次分部积分给出

\[
 \int_{|r|}^{\infty} f''(h/X)(h-|r|)\,\frac{dh}{X^2}
 =f(|r|/X).
\]

代入 (1)，得到严格恒等式

\[
\boxed{
 \sum_{m,n}a_m\overline{a_n}f(|m-n|/X)
 =
 \frac1{X^2}\int_0^\infty f''(h/X)Q_a(h)\,dh .
}
\tag{2}
\]

这说明短区间均方控制的是三角核的二阶导数展开；若
\(f''\) 变号，必须对 \(Q_a(h)\) 取绝对值或另保留跨 \(h\) 的符号。

## 2. Menon 型输入的最强直接转移

设 \(a_n=\mu(n)\phi(n/X)\)，其中 \(\phi\) 是固定光滑 dyadic cutoff。
把短区间定理通过有限次部分求和转到该 cutoff 后，抽象地写成

\[
 Q_a(h)\ll_\phi Xh+Xh^2\rho(X,h),
\tag{3}
\]

其中第一项是对角线，第二项来自归一化短区间均方；Menon 的 Theorem 1.1
给出的尺度为

\[
 \rho(X,h)\ll
 \frac{(\log\log h)^2}{(\log h)^2}
 +\frac{(\log\log X)^4}{(\log X)^2},
\qquad 10\le h\le X.
\tag{4}
\]

若 \(f\) 固定且 \(\int_0^\infty (u+u^2)|f''(u)|\,du<\infty\)，由 (2)--(4)

\[
 \left|\sum_{m,n}a_m\overline{a_n}f(|m-n|/X)\right|
 \ll_{\phi,f} X
 +X^2\sup_{10\le h\le X}\rho(X,h).
\tag{5}
\]

故该转移至多给

\[
 X^2\left(
 \frac{(\log\log X)^2}{(\log X)^2}
 +\frac{(\log\log X)^4}{(\log X)^2}
 \right),
\tag{6}
\]

即 \(X^{2-o(1)}\)，离 \(X^{1+\varepsilon}\) 仍有一个幂次缺口。

## 3. 与固定 Mellin 比例核的最后差异

在同一 dyadic 壳 \(m,n\asymp X\) 上，

\[
 K\!\left(\log\frac mn\right)
 =K\!\left(\log\left(1+\frac{|m-n|}{\min(m,n)}\right)\right).
\]

它不是仅依赖 \(|m-n|/X\) 的加性核：还含有
\(\min(m,n)/X\) 的 \(m\)-依赖。有限光滑 partition 可以把它近似为有限个
“权函数乘加性 B-spline”的组合，但每个组合项仍只能使用 (5)，并且
近似余项必须由额外的导数/变差估计支付。于是 Menon 定理即使经过这一步
也只能保留 (6) 的对数级量纲，不能自动产生

\[
\int |h(t)|\left|\sum_{n\le X}\mu(n)n^{it}\right|^2dt
\ll_\varepsilon X^{1+\varepsilon}.
\]

## 4. 路线裁决

Menon 的改进为固定 Mellin 核提供了一个可复用的三角核接口，但没有改变
主线判断：

1. 短区间均方的正性本身只给二阶差分的表示，不给相关块的上界；
2. 其当前定量 \(\rho(X,h)\) 只产生 \(X^{2-o(1)}\)；
3. 过平方根门仍需一个保留跨 \(h\) 符号的算术命题，例如 note 243 的
   dyadic block \(L^2\) 门，或直接的固定 Mellin signed-energy 估计。

来源：Menon, *Improved bounds for multiplicative functions in almost all short
intervals*, arXiv:2607.15574v1，Theorem 1.1、1.4、1.5。
