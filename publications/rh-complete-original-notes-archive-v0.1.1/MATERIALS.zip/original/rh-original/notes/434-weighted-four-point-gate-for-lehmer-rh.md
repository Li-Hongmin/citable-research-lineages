> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Lehmer 正核的一条显式 dyadic 四点充分门

日期：2026-08-17。

本 note 把固定 Mellin 能量门改写成一个明确的、带比值权的 dyadic
四点 Möbius 均方命题。它是一个严格的充分条件，不把它声称为必要条件，
也不把该条件当作已知定理。

## 1. Lehmer 核的差值分解

令
\[
 K_N(m,n)=\frac{\min(m,n)^2-1}{mn},
 \qquad 1\le m,n\le N.
\]
由 note 346--347，指数尾能量满足
\[
 I_N=\pi\sum_{m,n\le N}\mu(m)\mu(n)K_N(m,n).
\tag{1}
\]
对 \(m<n\) 写 \(h=n-m\)，并定义
\[
 C_N(h):=\sum_{m\le N-h}
 \mu(m)\mu(m+h)\,\frac{m^2-1}{m(m+h)}.
\tag{2}
\]
于是
\[
 \frac{I_N}{\pi}=2\sum_{h=1}^{N-1}C_N(h),
\tag{3}
\]
因为 \(K_N(1,n)=0\)，对角线也为零。

## 2. 充分的 dyadic 四点门

假设对每个 \(N\ge2\)、每个 dyadic \(1\le H<N\)，都有
\[
 \boxed{
 \sum_{H<h\le 2H}|C_N(h)|^2
 \ll_{\varepsilon} \frac{N^{2+\varepsilon}}{H}.}
\tag{4}
\]
这里 \(2H\) 超过 \(N\) 时按 \(h<N\) 截断。

将 (3) 按 dyadic \(H\) 分块，并用 Cauchy--Schwarz，得到
\[
 \left|\sum_{H<h\le2H}C_N(h)\right|
 \le H^{1/2}
 \left(\sum_{H<h\le2H}|C_N(h)|^2\right)^{1/2}
 \ll_{\varepsilon}N^{1+\varepsilon/2}.
\tag{5}
\]
求和 \(O(\log N)\) 个 dyadic 块，吸收对数因子后
\[
 I_N\ll_{\varepsilon}N^{1+\varepsilon}.
\tag{6}
\]
由 note 347 的有限维 Lehmer 对偶恒等式，(6) 给出
\[
 M(N)\ll_{\varepsilon}N^{1/2+\varepsilon},
\]
从而推出 RH。

因此 (4) 是一条完全明确的 RH 充分门；它比只要求
\(\sum_{h\asymp H}|C_N(h)|^2\ll N^{2+\varepsilon}\) 强一个 \(H^{-1}\) 因子。

## 3. 为什么它是四点而非二点问题

展开 (2) 的平方得到
\[
\begin{aligned}
 \sum_{H<h\le2H}|C_N(h)|^2
 ={}&\sum_{H<h\le2H}\sum_{m_1,m_2}
 \mu(m_1)\mu(m_1+h)\mu(m_2)\mu(m_2+h)\\
 &\qquad\times
 \frac{(m_1^2-1)(m_2^2-1)}
 {m_1(m_1+h)m_2(m_2+h)},
\end{aligned}
\tag{7}
\]
其中 \(m_i\le N-h\)。令 \(d=m_2-m_1\) 后，核心项是
\[
 \mu(m)\mu(m+h)\mu(m+d)\mu(m+d+h),
\tag{8}
\]
即平行四边形四点相关，带一个有界的移动比值振幅。

MRT 的 averaged-Chowla 二点平均可给出对
\(\sum_h|C_N(h)|\) 的对数级控制，但不能从二点输入推出 (4)。
即使有无权四点界
\(\sum_{h\asymp H}|C_N(h)|^2\ll N^{2+\varepsilon}\)，也只能通过
Cauchy 得到 \(N^{1+\varepsilon}H^{1/2}\)，在宏观 \(H\) 上仍不足以推出 (6)。

## 4. 当前裁决

式 (4) 是当前 Lehmer 路线一条可逐项检查的充分算术命题：

* 它保留了原始 Möbius 符号与 \(m/(m+h)\) 比值权；
* 它直接闭合 note 347 的正半定 Lehmer 门；
* 它明确要求跨移位的四点 signed cancellation，而不是逐移位取绝对值。

目前没有把 (4) 从已知 MRT、Guth--Maynard 大值估计或定性 Chowla 结果推出。
因此本 note 是证明目标的精确化，不是 RH 证明；任何后续声称“二点平均已经
关闭 Lehmer 门”的论证，都必须额外提供 (4) 或同强度的跨移位 intertwiner。

## 5. 一阶平均不能自动平方化

MRT 的公开摘要对 \(k=2\) 给出的是移位绝对值的一阶平均
\[
 \sum_{h\le H}\left|\sum_{n\le Y}
 \lambda(n)\lambda(n+h)\right|
 \ll YH\,\rho(Y,H),
\tag{9}
\]
其中 \(\rho(Y,H)\to0\) 仅为对数级衰减；见
<https://arxiv.org/abs/1503.05121>。

对任意满足 \(|A_h|\le Y\) 的数列，一阶平均至多推出
\[
 \sum_{h\le H}|A_h|^2
 \le Y\sum_{h\le H}|A_h|
 \ll Y^2H\,\rho(Y,H).
\tag{10}
\]
这个量级不能接近 (4) 所需的 \(Y^2/H\)。而且这不是估计技巧造成的：
取 \(\lfloor H\rho(Y,H)\rfloor\) 个 \(A_h=Y\)，其余 \(A_h=0\)，则
一阶和为 \(YH\rho(Y,H)\)，二阶和为
\[
 \asymp Y^2H\,\rho(Y,H),
\tag{11}
\]
达到 (10) 的量级。故从 MRT 一阶平均到 (4) 必须加入真正的
跨移位二阶/四点算术信息，不能由 Cauchy 或逐项有界性补出。
