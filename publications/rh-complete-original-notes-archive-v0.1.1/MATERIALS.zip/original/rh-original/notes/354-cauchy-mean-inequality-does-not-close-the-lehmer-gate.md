> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cauchy 均值不自动关闭 Lehmer 门

日期：2026-08-16。

Weber 的 Cauchy means of Dirichlet polynomials
(arXiv:1412.7812) 给出了离散尾和平方不等式。它看起来与
\[
 \boldsymbol\mu_N^T K_N\boldsymbol\mu_N
 =\sum_{j<N}(2j+1)
 \left(\sum_{n>j}\frac{\mu(n)}n\right)^2
\]
形式相同，但参数和右端权重必须严格对应。

## 1. 参数对应

将
\[
 D_N(t)=\sum_{n\le N}\mu(n)n^{it}
\]
写成 Weber 记号中的
\(\sum x_n n^{-1/2+it}\)，需要取
\[
 x_n=\mu(n)\sqrt n.
\]
于是其一般 Cauchy 均值上界的系数平方和为
\[
 \sum_{n\le N}|x_n|^2
 =\sum_{n\le N}n\mu(n)^2
 \asymp N^2,
\]
并非 \(O(N)\)。

等价地，直接在尾和形式中取其 \(s=1\) 参数时，离散 Hardy 右端是
\[
 \sum_{n\le N}n|x_n|^2,
\]
代入 \(x_n=\mu(n)\) 后仍为 \(\asymp N^2\)。

## 2. 为什么不能误读成 \(O(N)\)

若把右端误写成 \(\sum|x_n|^2\)，则对常数序列 \(x_n=1\) 会得到
\[
 \sum_{j<N}j\left(\sum_{n>j}\frac1n\right)^2\ll N,
\]
但左端实际为 \(\asymp N^2\)，所以这种无权右端不可能成立。

因此 Weber 型 Cauchy/Hardy 不等式只重现一般 Dirichlet 多项式的
\(O(N^2)\) 量级；它没有使用 Möbius 的零频 signed cancellation，不能替代
\[
 \boldsymbol\mu_N^T K_N\boldsymbol\mu_N\ll N^{1+\varepsilon}.
\]

这条审计与 note 347 的 RH-equivalent 结论一致：需要的不是另一个
Hilbert/Hardy 不等式，而是新的 Möbius 算术输入。

