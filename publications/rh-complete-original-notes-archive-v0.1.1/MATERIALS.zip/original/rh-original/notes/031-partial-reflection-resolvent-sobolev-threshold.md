> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Partial-reflection resolvent 的尖锐 Sobolev 阈值

日期：2026-08-11。

本文证明 note 030 提出的“一阶 commutator 产生频率衰减”路线已经被单个 collar reflection 否定，
并确定仍可保留的尖锐分数阶接口。

## 1. 精确逆

令

\[
I=(c,a),\qquad c=d-a,
\]

\[
(J_If)(x)=\mathbf1_I(x)f(d-x),
\qquad
J_I^2=P_I.
\]

固定

\[
E=\beta I+pJ_I,\qquad \beta>|p|>0.
\]

在 \(I^\perp\) 上 \(E=\beta I\)，在 \(I\) 上利用 \(J_I^2=I\) 可得

\[
\boxed{
E^{-1}
=\beta^{-1}I
+\frac{p^2}{\beta(\beta^2-p^2)}P_I
-\frac{p}{\beta^2-p^2}J_I.}
\tag{1}
\]

## 2. 一阶 commutator 反例

对 \(f\in C^\infty[0,a]\)，在内部端点 \(c\) 的左右 trace 为

\[
(E^{-1}f)(c-)=\beta^{-1}f(c),
\]

\[
(E^{-1}f)(c+)
=\frac{\beta f(c)-pf(a)}{\beta^2-p^2}.
\]

因此 jump 为

\[
\boxed{
(E^{-1}f)(c+)-(E^{-1}f)(c-)
=\frac{p}{\beta^2-p^2}
\left(\frac p\beta f(c)-f(a)\right).}
\tag{2}
\]

取支撑在 \(c\) 附近的光滑函数，使 \(f(c)=1\)、\(f(a)=0\)，则 jump 非零。故

\[
E^{-1}f\notin H^1(0,a).
\]

若一阶频率算子 \(\Lambda\) 满足

\[
[\Lambda,E^{-1}]\in\mathcal B(L^2),
\]

则由

\[
\Lambda E^{-1}f
=E^{-1}\Lambda f+[\Lambda,E^{-1}]f
\]

会推出 \(E^{-1}D(\Lambda)\subset D(\Lambda)\)，与 (2) 矛盾。因此

\[
\boxed{[\Lambda,E^{-1}]\notin\mathcal B(L^2).}
\tag{3}
\]

单个 partial reflection 已足以否定 note 030 中候选的一致一阶 commutator 界。

## 3. Fourier 衰减的临界阶

在 Neumann 或 Dirichlet--Neumann Fourier 基 \(\phi_j\) 中，(1) 的非对角元是

\[
\int_I\phi_j(x)
\left(
A\phi_k(x)+B\phi_k(d-x)
\right)\,dx,
\]

\[
A=\frac{p^2}{\beta(\beta^2-p^2)},
\qquad
B=-\frac{p}{\beta^2-p^2}.
\]

product-to-sum 给出有限个端点项

\[
\frac{\sin((\kappa_j\pm\kappa_k)x+\theta)}
{\kappa_j\pm\kappa_k}.
\]

故

\[
\boxed{
|\langle\phi_j,E^{-1}\phi_k\rangle|
\le C_{\beta,p,I}
\left(
\frac1{1+|j-k|}
+\frac1{1+j+k}
\right)
\quad(j\ne k).}
\tag{4}
\]

若 \(I\) 是 proper collar 且 \(p\ne0\)，则 \(A/B=-p/\beta\ne\pm1\)，两个端点的 leading traces
不可能对全部 \(k\) 同时抵消；存在指标子序列达到 \(1/|j-k|\) 阶。因此一般不能把 (4) 提升到
\(1/|j-k|^{1+\varepsilon}\)。

这恰位于一维标准 Jaffard inverse-closed 条件 \(s>1\) 的临界线以下，绝对 row tail 呈调和发散。

## 4. 正确的分数阶接口

区间示性函数是一维 \(H^s\) multiplier 当且仅当

\[
|s|<\frac12.
\]

reflection 不改变该阈值，因此由 (1)

\[
\boxed{
E^{-1}:H^s(0,a)\longrightarrow H^s(0,a)
\quad\text{有界},\qquad |s|<\frac12.}
\tag{5}
\]

在 \(s=\frac12\) 时，generic jump 产生对数发散，阈值尖锐。

需要区分 domain invariance 与更强的 \(L^2\) commutator。对任意 \(s>0\)，把单位 \(L^2\)
bump 缩放到宽度 \(\varepsilon\) 并跨越 \(c\)，jump 部分给出

\[
\|[|\Lambda|^s,E^{-1}]f_\varepsilon\|_2
\gtrsim \varepsilon^{-s}.
\]

因此

\[
\boxed{
[|\Lambda|^s,E^{-1}]
\notin\mathcal B(L^2)
\qquad\forall s>0.}
\tag{6}
\]

## 5. 对 A3 的裁决

不能通过一阶 commutator 或 \(1+\varepsilon\) 阶 Jaffard 衰减闭合 Robin-frame 不等式。可保留的
接口只有：

\[
\boxed{
\text{\(H^s\) multiplier stability for }|s|<\frac12,
}
\]

以及 note 029 的 graph-support Combes--Thomas 衰减。若继续频率路线，必须允许导数损失、使用
弱 Schatten/Lorentz 型临界估计，或对 deficit weights 作 dyadic block summation；不能再假设
绝对可和的 off-diagonal decay。

