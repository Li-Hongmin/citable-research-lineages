> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 429. 高阶 q-差分在加权能量中收缩回一阶滤波器

## 1. 有限支撑算子

固定 \(q\ge2\)、\(r\ge2\)，把截断尾先视为正实数变量上的函数
\[
B_X(y)=\sum_{\lceil y\rceil\le n\le X}\frac{\mu(n)}n\quad(y>0),
\qquad B_X(y)=0\quad(y>X).
\]
定义作用在正实数函数上的尺度算子
\[
(Sf)(k)=f(k/q),\qquad (Rf)(k)=f(qk).
\]
在这个函数空间上 \(S=R^{-1}\)，故 \(SR=RS=I\)；以下所有范数
只在正整数采样点上取。并且 \(R^jB_X(k)=0\) 对充分大的 \(j\) 成立。
有限 q-差分尾正是
\[
T_{r,q,X}=(I-S)^rB_X,\qquad
T_{1,q,X}=(I-S)B_X.
\tag{1}
\]

由 \(I-S=-S(I-R)\)，
\[
T_{r,q,X}=(-1)^rS^r(I-R)^rB_X.
\]
在有限支撑上
\[
(I-R)^{-1}=\sum_{j\ge0}R^j,
\qquad
(I-R)^{-(r-1)}
=\sum_{j\ge0}\binom{j+r-2}{r-2}R^j.
\]
因此得到精确反演
\[
\boxed{
T_{1,q,X}(k)
=(-1)^{r+1}\sum_{j\ge0}
\binom{j+r-2}{r-2}
T_{r,q,X}\!\left(q^{j+r-1}k\right).
}
\tag{2}
\]
右端实际只有有限项，因为 \(T_{r,q,X}\) 支撑在 \(k\le q^rX\)。

## 2. 加权 \(\ell^2\) 收缩

令
\[
\|f\|_{Y,1}^2=\sum_{n\le Y}n|f(n)|^2.
\]
对任意 \(m\ge0\)，伸缩算子满足
\[
\begin{aligned}
\|R^mf\|_{X,1}^2
&=\sum_{k\le X}k|f(q^mk)|^2\\
&=q^{-m}
\sum_{\substack{n\le q^mX\\q^m\mid n}}n|f(n)|^2
\le q^{-m}\|f\|_{q^mX,1}^2.
\end{aligned}
\tag{3}
\]
把 (3) 代入 (2)，并利用 \(T_{r,q,X}(n)=0\) 对 \(n>q^rX\)，得到
\[
\begin{aligned}
\|T_{1,q,X}\|_{X,1}
\le
\sum_{j\ge0}\binom{j+r-2}{r-2}
q^{-(j+r-1)/2}
\|T_{r,q,X}\|_{q^rX,1}\\
&=
(\sqrt q-1)^{-(r-1)}
\|T_{r,q,X}\|_{q^rX,1},
\end{aligned}
\tag{4}
\]
因为
\[
\sum_{j\ge0}\binom{j+r-2}{r-2}q^{-j/2}
=(1-q^{-1/2})^{-(r-1)}.
\]
若能量使用 \(2n-1\) 权重，则右端只会增加一个无害的常数因子。

## 3. 对增长阶路线的直接裁决

零模条件 \(P_r(q^{-1})=0\) 还给出
\[
T_{1,q,X}(k)=T_{1,q,\infty}(k),\qquad k\le X.
\tag{5}
\]
所以在 \(r=r(X)=o(\log X)\) 时，任何有限能量界
\[
\sum_{n\le q^{r(X)}X}(2n-1)|T_{r(X),q,X}(n)|^2
\ll X^{1+\varepsilon}
\tag{6}
\]
通过 (4)--(5) 推出一阶无限尾的部分能量界
\[
\sum_{k\le X}k|T_{1,q,\infty}(k)|^2
\ll X^{1+\varepsilon+o(1)}.
\tag{7}
\]
对每个固定的目标 \(\delta>0\)，可把能量假设中的 \(\varepsilon\) 取小并吸收
\(o(1)\)，从而得到 note 420 所需的 \(X^{1+\delta}\) 界，进而推出 RH。
这一步不需要 note 428 的统一 pole-isolation，但需要 \(r(X)=o(\log X)\)；
任意 \(O(\log X)\) 增长不再自动被吸收。

因此，次对数增长的高阶 q-差分不能构成独立的 RH 逃逸路线；其能量界仍会
回到一阶门。真正尚未证明的仍是一阶能量界 (7) 本身；线性对数阶增长则
还需额外支付 \((\sqrt q-1)^{-2r}\) 的因子。

## 4. 线性对数阶的定量阈值

上述收缩还给出一个稍强的参数化结论。令
\[
C_q=(\sqrt q-1)^{-1},
\]
并假设对某个 \(\theta\) 及所有足够大的 \(X\)，
\[
r(X)\le \eta\log X+O(1),
\qquad
\|T_{r(X),q,X}\|_{q^{r(X)}X,1}^{,2}
\ll_{\varepsilon}X^{\theta+\varepsilon}.
\tag{8}
\]
由 (4) 和内部恒等式 (5)，一阶无限尾满足
\[
\sum_{k\le X}k|T_{1,q,\infty}(k)|^2
\ll_{\varepsilon}
C_q^{,2r(X)}X^{\theta+\varepsilon}
\ll_{\varepsilon}
X^{\theta+2\eta\log C_q+\varepsilon}.
\tag{9}
\]
因此只要
\[
\boxed{\theta+2\eta\log C_q\le1,}
\tag{10}
\]
右端仍属于 note 420 的 \(X^{1+\varepsilon}\) RH 等价门。严格不等式
给出余量；等号情形也可由任意小的 \(\varepsilon\) 吸收。故线性对数增长
并非绝对排除，但它必须同时伴随足够强的高阶能量指数；仅有
\(\theta=1\) 的界时，任何固定正的 \(\eta\) 都不能由此自动闭合。
