> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 更正：撤回“次数不超过十六不可能”的旧草稿

日期：2026-08-15。

本文件名下的旧版本沿用了错误的非整数截断求和，并据此声称次数十五、十六均无
正 detector；该 no-go 结论无效，现正式撤回。

正确结果是：次数十五已经存在全半轴正 detector，见
[note 144](144-a-positive-degree-fifteen-detector-removes-four-collective-residues.md)；
独立的次数十六构造见 [note 143](143-a-positive-degree-sixteen-detector-removes-four-collective-residues.md)。
