> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Zero-free 区域对增长二进制差分的支付尺度

沿用 note 393 的部分和
\[
S_{q,X}(Y)
=\sum_{j=0}^{q}(-1)^j\binom qj
M\!\left(\min\!\left(X,\left\lfloor Y/2^j\right\rfloor\right)\right).
\]
本 note 只检查已知 zero-free 区域能否直接控制临界增长阶
\(q\asymp\log X/\log\log X\)；不假设任何新的 signed cancellation。

## 1. 内部区间的三角上界

在 \(Y\le X\) 时，令
\[
\Lambda(z)=(\log z)^{3/5}(\log\log z)^{-1/5},
\]
并假设经典无条件估计
\[
|M(z)|\le C z e^{-c\Lambda(z)}.
\tag{1}
\]
若 \(Y\ge 2^{q+2}z_0\) 且 \(q=o(\log Y)\)，则对 \(0\le j\le q\)
\[
\Lambda(Y/2^j)=(1-o(1))\Lambda(Y)
\]
一致成立。于是由三角不等式
\[
\begin{aligned}
|S_{q,X}(Y)|
&\le C Y e^{-c(1-o(1))\Lambda(Y)}
\sum_{j=0}^{q}\binom qj2^{-j}\\
&=C Y e^{-c(1-o(1))\Lambda(Y)}
\left(\frac32\right)^q.
\end{aligned}
\tag{2}
\]
这里没有使用 \(q\) 层之间的任何符号抵消。

## 2. 两个不同的尺度

若
\[
q\le \kappa\Lambda(Y)
\]
且 \(\kappa>0\) 足够小，则 (2) 仍给出
\[
|S_{q,X}(Y)|\le
Y e^{-c'\Lambda(Y)}
\tag{3}
\]
其中 \(c'>0\) 只依赖 \(c,\kappa\)。因此已知 zero-free 区域可以支付的增长滤波器阶数至多是
\[
q=O(\Lambda(Y)).
\]

另一方面，note 272 的局部化逃逸阈值是
\[
q\asymp\frac{\log Y}{\log\log Y}.
\tag{4}
\]
而
\[
\frac{\log Y}{\log\log Y}
\gg
(\log Y)^{3/5}(\log\log Y)^{-1/5}
=\Lambda(Y).
\]
在临界阶 \(q=c_0\log Y/\log\log Y\) 下，
\[
\left(\frac32\right)^q
=\exp\!\left(
\frac{c_0\log(3/2)+o(1)}{\log\log Y}\log Y
\right),
\]
其增长超过 zero-free 因子 \(e^{-c\Lambda(Y)}\)。所以已知 zero-free
估计配合逐项绝对值，无法控制达到 (4) 的滤波器；最好的粗界重新退化为
\(Y^{1+o(1)}\) 甚至更差的尺度。

## 3. 真正剩余的命题

在 \(q\asymp\log Y/\log\log Y\) 时，要改善 (2)，必须证明
\[
\sum_{j=0}^{q}(-1)^j\binom qj
M(Y/2^j)
\]
在 dyadic 尺度之间有大于三角不等式的联合抵消，并且同时控制
\(Y<2^qX\) 时 note 393 式 (6) 中的截断折点。该命题不是 zero-free 区域的推论，
也不是普通正 Gram 的算子范数估计；它是一个新的高阶 dyadic Möbius
signed-difference 门。

因此增长滤波器路线的当前边界可以精确写成：

- \(q=O(\Lambda)\)：zero-free 区域足以给出 stretched-log 型控制，但不能越过
  \(N^{2-o(1)}\) 能量层；
- \(q\asymp\log X/\log\log X\)：才可能规避有限阶零频局部化，但所需的
  binomial dyadic cancellation 尚未有证明。

本文不把 (4) 的高阶差分估计误报为已知结果，也不声称 RH。
