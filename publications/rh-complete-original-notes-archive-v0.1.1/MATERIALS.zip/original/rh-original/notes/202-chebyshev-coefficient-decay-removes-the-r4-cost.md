> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Chebyshev 系数衰减可去掉高阶 Jackson 的 \(R^4\) 代价

日期：2026-08-15。

note 201 为了稳妥地只使用系数 \(O(1)\)，付出了张量基函数总变差的
\(R^4\) 代价。对当前 \(V_{15}\) 的有限矩正则性，还可以严格利用
Chebyshev 系数衰减，把该代价降为 \(O(1)\)（至多对数因子），从而把
 stretched-log 指数常数任意推进到零自由区常数 \(c_1\) 的下方。

## 1. 每变量四阶正则性

若
\[
 \int_{\mathbb R}(1+|t|^{2q})w(t)\,dt<\infty ,
\tag{1}
\]
则 \(F_d(x,y)=K\!\left(\log(2^{-d}x/y)\right)\) 对两个变量分别具有 \(q\) 阶一致导数界，
并且所有混合导数 \(\partial_x^a\partial_y^bF_d\)（\(a,b\le q\)）一致有界。
对 \(V_{15}\)，已知 \(w(\xi)\ll_\varepsilon
(1+|\xi|)^{-19/2+\varepsilon}\)，故可取 \(q=4\)（八阶矩有限）。

将 \([1,2]\) 参数化为 \(x=3/2+(1/2)\cos\theta\)。Chebyshev 系数是
\(F_d\) 的余弦 Fourier 系数。由于该参数化使所有奇阶端点项消失，
对 \(q\) 次分部积分得到一致估计
\[
 |c_{rs}^{(d)}|
 \le C_{q,w}(1+r)^{-q}(1+s)^{-q},
\qquad r,s\ge0.
\tag{2}
\]
Jackson 权 \(\lambda_{r,R}\in[0,1]\) 不破坏 (2)。这里需要的是
\(q\) 阶每变量正则性，即总共 \(2q\) 阶矩；不能仅由 \(q\) 阶总矩推出
(2)。

这里的端点步骤可逐项核验。若
\(G_{d,y}(\theta)=F_d(3/2+\tfrac12\cos\theta,y)\)，则
\(G_{d,y}\) 在 \(\theta=0,\pi\) 的所有奇阶导数均为零；这是
\(\cos\theta\) 在两个端点的偶延拓，而不是额外假设。对 \(r\ge1\) 连续
分部积分四次时，前后两次的边界项分别含
\(G_{d,y}'\) 与 \(G_{d,y}^{(3)}\)，因而消失，得到
\[
 \left|\int_0^\pi G_{d,y}(\theta)\cos(r\theta)\,d\theta\right|
 \le r^{-4}\int_0^\pi |G_{d,y}^{(4)}(\theta)|\,d\theta .
\]
链式法则、\(x,y\in[1,2]\) 以及
\(\int |t|^8w(t)\,dt<\infty\) 给出右端对 \(d,y\) 的统一界；先对
\(x\)、再对 \(y\) 作同样处理即得 (2)（低阶 \(r=0\) 或 \(s=0\)
并入常数）。因此该系数衰减不依赖未证的端点光滑延拓。

## 2. 离散总变差的真实总和

令 \(\psi_r(x)=T_r(2x-3)\)。精确有
\[
 \operatorname{Var}_{[1,2]}\psi_r\le2r+2,
\qquad
 \operatorname{Var}_{m\in I_j}\psi_r(m/2^j)\le2r+4.
\tag{3}
\]
因此 Jackson 张量项的系数加权总变差为
\[
 \sum_{r,s\le R}|c_{rs}^{(d)}|(r+1)(s+1)
 \ll_{q,w}
 \left(\sum_{r\le R}(r+1)^{1-q}\right)^2.
\tag{4}
\]
当 \(q>2\) 时右端有界（\(q=2\) 时为 \(O((\log R)^2)\)）。
所以 note 201 的 \(R^4\) 只是“不使用系数衰减”时的保守代价，不是
当前 \(V_{15}\) 的真实代价。

## 3. 优化后的能量界

Jackson 逼近误差仍为
\[
 \|F_d-P_{R,d}\|_\infty\ll_{q,w}R^{-q}.
\tag{5}
\]
令 \(D=\lceil\beta\Lambda(N)/\log2\rceil\)，用 Mertens 零自由区估计及
(3)--(4) 作 dyadic 分块，得到
\[
 E_N(w)\ll_{q,w}
 N^2R^{-q}
 +D\,N^2e^{-c_1\Lambda(N)}
 +N\,2^D\,D
 +N^2e^{-\beta\Lambda(N)}.
\tag{6}
\]
由于 \(D=O(\Lambda(N))=o(\log N)\)，第三项是 \(N^{1+o(1)}\)，可忽略于
 \(N^2e^{-c\Lambda(N)}\) 之下。取
\[
 R=\lceil e^{\alpha\Lambda(N)}\rceil
\]
后，主指数为
\[
 \min\{q\alpha,\ c_1,\ \beta\}.
\tag{7}
\]
因此对任意固定 \(c<c_1\)，取
\[
 \alpha>c/q,\qquad \beta>c
\]
即得
\[
 \boxed{E_N(w)\ll_{w,c}N^2e^{-c\Lambda(N)}.}
\tag{8}
\]
对 \(V_{15}\) 的 \(q=4\) 版本，这把可证指数从 note 201 的
\(c_*<2c_1/3\) 推进到任意 \(c<c_1\)。若未来获得任意高阶矩（例如更高
 \(m\) detector 并同时控制矩常数），同一论证不改变 \(N^{2-o(1)}\) 阶，
只会把所需 \(R=e^{\alpha\Lambda}\) 的 \(\alpha\) 降低；指数上限仍是
 \(c_1\)，不能达到 \(N^{1+\varepsilon}\) 或 RH。

这里的 dyadic 分块包含一个容易漏写的交叉情形。令
\(J=\lfloor\tfrac12\log_2N\rfloor\)。对 \(d\le D\)，若
\(j<J\le j+d\)，则 \(j\ge J-D\)，从而

\[
2^{2j+d}\ll N2^D.
\]

高块的 Abel 界只需作用在第二个因子上，故所有低--高交叉项总和为

\[
 \ll_{q,w}N2^D e^{-\eta\Lambda(N)}
 \ll_{q,w}N2^D,
\]

其中 \(\eta>0\) 可取为任意小于零自由区常数乘以
\(2^{-3/5}\) 的数。低--低项给出式 (6) 的 \(N2^DD\) 粗界，高--高项给出
\(DN^2e^{-2\eta\Lambda(N)}\)（把常数 \(c_1\) 取为小于 \(2\eta\) 的数即可）。
因此交叉项不会改变式 (6)--(8) 的指数，但必须显式纳入证明；不能把
“低块”和“高块”误读成两个互斥且覆盖全部配对的分类。

## 4. 严格边界

式 (2) 的每变量系数衰减是优化的关键；若只保留
\(|c_{rs}|\ll1\)，必须回到 note 201 的 \(R^4\) 平衡。式 (2) 还要求
\(2q\) 阶矩和端点兼容的 Chebyshev 参数化，不能由“函数很光滑”的口头
判断替代。本文仍只给固定 \(w\) 的 \(N^{2-o(1)}\) 估计，不产生新的
Möbius 二点相关或 signed prime/reflection cancellation。
