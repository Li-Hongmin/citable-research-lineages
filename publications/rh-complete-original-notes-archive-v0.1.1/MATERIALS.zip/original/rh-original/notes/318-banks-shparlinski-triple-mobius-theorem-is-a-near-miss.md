> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Banks--Shparlinski 三变量 Möbius 定理与本项目 Liouville 仿射门的适配边界

日期：2026-08-16。

检索到 Banks--Shparlinski, *Multiple sums with the Möbius function*,
arXiv:2506.08787（2025 预印本，2026 年发表于 QJM）。该文研究
\[
 \mathsf S_\mu(M)=
 \sum_{f(n_1)+g(n_2)+\wp(n_3)=M}
 u_{n_1}v_{n_2}\,\mu(n_1n_2n_3),
\]
其中 \(f,g\) 为单射、\(\wp\) 为低复杂度多项式。长区间主定理给出
\((A+B)N(\log N)^{-C}\) 型界；在线性 \(\wp\) 且附加 Dirichlet
零点假设下，作者给出更强幂次界，GRH 情形为
\((A+B)N^{7/8+o(1)}\)。原文定理与量词见
<https://arxiv.org/html/2506.08787>，尤其 §§1.2、2.1、3.1。

## 与当前三点门的形式相似

令 \(C=2U-1\)，则 notes 315--317 的和可写为
\[
 T_{U,Q}=\sum_{x+y-z=C}
 1_I(x)1_{C+J}(y)1_{I+J}(z)\lambda(x)\lambda(y)\lambda(z),
\]
其中 \(I=(U,2U)\)、\(J=[1,Q]\)，且 \(C+J=\{C+q:1\le q\le Q\}\)。这与 Banks--Shparlinski
的三变量加法约束在几何形状上相近。

## 不能直接套用的两个严格原因

1. 算术权不同。该文的权是 \(\mu(n_1n_2n_3)\)，当三个变量有共同素因子时它直接为零；本项目的权是
   \(\lambda(n_1)\lambda(n_2)\lambda(n_3)\)，始终为 \(\pm1\)。一般有
   \[
   \lambda(n_1)\lambda(n_2)\lambda(n_3)
   \ne \mu(n_1n_2n_3).
   \]
   用精确恒等式
   \[
   \lambda(n)=\sum_{r^2\mid n}\mu(n/r^2)
   \]
   展开后，当前三点和变成
   \[
   \sum_{r,s,t}\ 
   \sum_{r^2a+s^2b-t^2c=C}
   \mu(a)\mu(b)\mu(c),
   \]
   带有平方因子层和移动线性系数。内层仍是三个独立 Möbius 权的乘积，而不是
   \(\mu(abc)\)；共同素因子不能被原定理的权自动吸收。

2. 即使存在完全对应的 Liouville 版本，定理的无条件主项也只是
   \((A+B)N\) 乘对数衰减。在本项目中三个变量都在 \(U\) 量级，因此至多是
   \(U^2(\log U)^{-C}\)，而不是端点望远镜需要的 \(U^{1+\varepsilon}\)。其 GRH 条件下的 \(U^{15/8+o(1)}\) 量级同样没有达到目标平方根门。
   平方因子层本身也不会改变这个幂次：若把每一层粗略按
   \((U/r^2+U/s^2)(U/t^2)\) 估计，\(r,s,t\) 的平方倒数和收敛，主量级仍为
   \(U^2\)（幂次版同理由 \(\sum r^{-2\theta}<\infty\) 保持原指数）。

## 决策

这篇新文献确认了“加法三点门”确有独立的 Möbius 解析技术，但它不是当前 Liouville signed 门的缺失桥。直接下一步仍不能是套用该定理；必须得到保留三个 Liouville 符号的三线性估计，或构造把移动仿射平面映射到该符号结构的算术 intertwiner。
