> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Prime-free 偶扇区的 Yukawa--Schur 显式谱隙

日期：2026-08-11。本文证明完整局部 Weil 算子的偶扇区在第一个 prime-power 阈值以前一致严格
为正。结合 [奇扇区的显式谱隙](017-prime-free-odd-yukawa-gap.md)，这完全排除 prime-free 区间内
的首次退化。

## 1. 定理

令

\[
a_*:=\frac{\log 2}{2}.
\]

则对全部 \(0<a\le a_*\)，

\[
\boxed{A_a^+\succeq \frac1{2000}I.}
\]

由 note 017 的 \(A_a^-\succeq0.0102973827753I\)，进一步有

\[
\boxed{A_a=A_a^+\oplus A_a^-\succeq\frac1{2000}I
\qquad(0<a\le a_*).}
\]

所以局部 Weil 形式在第一个 prime shift 激活以前没有零模态或负谱。

## 2. 偶半区的精确 Yukawa 分解

在端点 \(a=a_*\) 上，把偶空间酉映到 \(L^2(0,a)\)：

\[
(Wf)(x)=\sqrt2f(x),\qquad 0<x<a.
\]

令

\[
e_0=a^{-1/2},\qquad
e_k=(2/a)^{1/2}\cos(k\pi x/a)\quad(k\ge1),
\]

并记

\[
b_n=n+\frac14,\qquad c_n=2b_n,\qquad
m(\xi)=\operatorname{Re}\psi\!\left(\frac14+\frac{i\xi}{2}\right)-\log\pi.
\]

全直线 Yukawa resolvent 压到偶半区后的核为

\[
G_c^R(x,y)=\frac{e^{-c|x-y|}+e^{-c(x+y)}}{2c}
=\frac{\cosh(cx_<)e^{-cx_>}}c.
\]

它对应 \(u'(0)=0,\ u'(a)+cu(a)=0\)。两端 Neumann resolvent 的核为

\[
G_c^N(x,y)=
\frac{\cosh(cx_<)\cosh(c(a-x_>))}{c\sinh(ca)}.
\]

直接相减得到

\[
\boxed{
G_c^R=G_c^N-
\frac{e^{-ca}}{c\sinh(ca)}
|\cosh(cx)\rangle\langle\cosh(cx)|.}
\]

因此 note 017 的第 \(n\) 个 Yukawa 项在偶半区精确等于

\[
\frac1{b_n}(I-c_n^2G_{c_n}^R)
=f_n(-\Delta_N)+\rho_n|g_n\rangle\langle g_n|,
\]

其中

\[
f_n(\lambda)=\frac1{b_n}\frac{\lambda}{\lambda+c_n^2},\qquad
g_n(x)=\cosh(c_nx),\qquad
\rho_n=\frac{2e^{-c_na}}{\sinh(c_na)}>0.
\]

偶极点项在全区间为

\[
2|\langle f,\cosh(x/2)\rangle_{(-a,a)}|^2.
\]

经 \(W\) 后它成为 \(4|\langle Wf,g_0\rangle_{(0,a)}|^2\)，故只需令

\[
\rho_0'=\rho_0+4,\qquad \rho_n'=\rho_n\quad(n\ge1).
\]

在测试函数上逐项求和，再由正形式单调收敛延拓到完整定义域，得到

\[
\boxed{
WA_{a_*}^+W^{-1}
=D+\sum_{n=0}^{\infty}\rho_n'|g_n\rangle\langle g_n|,}
\]

其中

\[
De_k=D_ke_k,\qquad D_k=m(k\pi/a).
\]

端点刚出现的 \(n=2\) prime shift 等于区间直径；它的内部相关项为零，而 jump 对角质量与标量
修正精确抵消。因此端点仍等于上述 prime-free 左极限，见 notes 015、017。

## 3. 一个负方向的 Schur 惯性相消

取

\[
\delta=\frac1{2000},\qquad
B=D+\sum_{n=0}^{19}\rho_n'|g_n\rangle\langle g_n|.
\]

由

\[
m'(\xi)=\frac{\xi}{2}\sum_{n=0}^{\infty}
\frac{b_n}{(b_n^2+\xi^2/4)^2}>0\qquad(\xi>0),
\]

以及 Arb 严格验证

\[
D_0-\delta<0,\qquad D_1-\delta>0,
\]

知 \(D-\delta I\) 恰有一个负方向且可逆。

定义 \(U:\mathbb C^{20}\to L^2(0,a)\) 为

\[
Uq=\sum_{n=0}^{19}q_n\sqrt{\rho_n'}g_n,
\]

并令

\[
S_\delta=I+U^*(D-\delta I)^{-1}U.
\]

把 \(D\) 的 \(k=0\) 模式分出，得到

\[
S_\delta=I+G_+-vv^*,\qquad G_+\succeq0.
\]

所以

\[
\operatorname{ind}_-(S_\delta)+\dim\ker S_\delta\le1.
\]

下面的严格负二次型见证即证明它恰有一个负方向且无核。
标准有限秩 Schur 惯性公式随后给出

\[
\begin{aligned}
\operatorname{ind}_-(B-\delta I)
&=\operatorname{ind}_-(D-\delta I)-\operatorname{ind}_-(S_\delta)\\
&=1-1=0,\\
\ker(B-\delta I)&=\{0\}.
\end{aligned}
\]

因 \(D_k\to\infty\)，\(B\) 有紧预解式，故

\[
B\succeq\delta I.
\]

遗漏的 \(n\ge20\) 项不必按算子范数收敛；在共同核心上取正形式的单调极限 \(q_\infty=\sup_Nq_N\)，
所以

\[
A_{a_*}^+\succeq B\succeq\delta I.
\]

## 4. Arb 负见证及无限 Fourier 尾

Neumann 系数可显式写成

\[
h_{0n}:=\langle e_0,g_n\rangle
=\frac{\sinh(c_na)}{c_n\sqrt a},
\]

\[
h_{kn}:=\langle e_k,g_n\rangle
=\sqrt{\frac2a}\,
\frac{(-1)^kc_n\sinh(c_na)}{c_n^2+(k\pi/a)^2}\qquad(k\ge1).
\]

证书把脚本中列出的 20 个有限十进制数作为精确有理球输入 \(w\)，并对 \(K=20\) 计算

\[
Q_K=\|w\|^2
-\frac{|\sum_n\sqrt{\rho_n'}h_{0n}w_n|^2}{-(D_0-\delta)}
+\sum_{k=1}^{K}
\frac{|\sum_n\sqrt{\rho_n'}h_{kn}w_n|^2}{D_k-\delta}.
\]

令

\[
H=\sum_{n=0}^{19}|w_n|\sqrt{\rho_n'}c_n\sinh(c_na).
\]

由 \(m\) 严格递增和 \(\sum_{k>K}k^{-4}\le(3K^3)^{-1}\)，剩余正尾满足

\[
0\le R_K\le
\frac{2a^3H^2}{3\pi^4K^3(D_{K+1}-\delta)}.
\]

100 位 Arb 有向球算术给出

\[
\begin{aligned}
Q_{20}&<-4.94890707757635\times10^{-5},\\
R_{20}&<4.09192218855657\times10^{-7},\\
Q_{20}+R_{20}&<-4.90798785569078\times10^{-5}<0.
\end{aligned}
\]

因此 \(w^*S_\delta w<0\)，完成第 3 节的惯性证书。

## 5. 全 prime-free 区间

零延拓保持偶性。由 note 003 的 min--max 域单调性，对 \(0<a\le a_*\)，

\[
\lambda_1^+(a)\ge\lambda_1^+(a_*)\ge\frac1{2000}.
\]

这证明第 1 节定理。

## 6. 可复现证书

脚本：
[verify_prime_free_even_schur.py](../computations/verify_prime_free_even_schur.py)

运行：

~~~bash
uv run --with python-flint python \
  computations/verify_prime_free_even_schur.py
~~~

关键输出：

~~~text
delta=[0.0005000000000000 ...]
D0_minus_delta=[-5.372683419225665 ...]
D1_minus_delta=[0.365504749552327 ...]
schur_partial=[-4.94890707757635e-5 ...]
tail_upper=[4.09192218855656e-7 ...]
schur_quadratic_upper=[-4.90798785569078e-5 ...]
certified_negative=True
~~~

脚本不把浮点特征值当作证明；所有证书输入、特殊函数、无穷尾上界与最终符号判断均由 Arb
有向球算术完成。
