> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 指数外函数尾核的 Hardy--Laplace 恒等式：零频被精确去除

日期：2026-08-16。

令
\[
f_N(x):=e^x\sum_{e^x<n\le N}\frac{\mu(n)}n,
\qquad x\ge0,
\]
并令 \(f_N(x)=0\) 于 \(x>\log N\)。由 note 341 的模型公式，
\[
2\pi\,\mathcal K_{N,o}(x)=f_N(x).
\tag{1}
\]

## 1. Laplace 变换

记
\[
D_N(t):=\sum_{n\le N}\mu(n)n^{-it},
\qquad
A_N:=\sum_{n\le N}\frac{\mu(n)}n.
\]
直接逐项积分得到，对实数 \(t\)，
\[
\begin{aligned}
\widehat f_N(t)
&:=\int_0^\infty f_N(x)e^{-itx}\,dx\\
&=\sum_{n\le N}\frac{\mu(n)}n
  \int_0^{\log n}e^{(1-it)x}\,dx\\
&=\frac{D_N(t)-A_N}{1-it}.
\end{aligned}
\tag{2}
\]
Plancherel 因而给出精确恒等式
\[
\boxed{
8\pi^3\|\mathcal K_{N,o}\|_2^2
=\int_{\mathbb R}
\frac{|D_N(t)-A_N|^2}{1+t^2}\,dt .}
\tag{3}
\]
这里 \(D_N(t)=\overline{F_N(t)}\)，所以右侧是一个带有明确 Cauchy
核的、去掉常数项的 Dirichlet 多项式能量。

## 2. 结构含义

在零频处
\[
D_N(0)=M(N),
\qquad
D_N(0)-A_N=M(N)-A_N.
\tag{4}
\]
因此该模型外函数的对偶证书并没有 annihilate 零频 Möbius 模式；它测量的
是 \(M(N)-A_N\)。由素数定理 \(A_N\to0\)，在大尺度上这与 \(M(N)\) 只差
一个趋零边界项。

令 \(M^*(X)=\max_{x\le X}|M(x)|\)。对达到最大值的 \(X_0\)，Abel 部分求和
给出
\[
|D_{X_0}(t)-D_{X_0}(0)|
\le 2|t|M^*(X_0)\log X_0.
\tag{5}
\]
因 \(A_{X_0}=o(1)\)，若 \(M^*(X)\) 足够大，则
\(|D_{X_0}(0)-A_{X_0}|\ge \tfrac12M^*(X)\)。在
\(|t|\le c/\log X_0\) 的固定小区间内，(5) 保证
\(|D_{X_0}(t)-A_{X_0}|\gg M^*(X)\)，而权
\((1+t^2)^{-1}\) 有正下界。因此模型能量的统一平方根界同样通过
最大点 Abel 引理推出 Mertens 平方根界；详见 note 345。

## 3. 对一般外函数的设计提示

式 (2) 显示，若 \(o\) 在零点附近具有非零边界质量，截断卷积一般会产生
类似
\[
\frac{D_N(t)-\text{boundary term}}{1-it}
\]
的中心化结构。要保留 RH 信号，候选外函数必须同时满足：

1. 对偶核在正频率上仍能消去 \(\mathcal A_+\)；
2. 边界项不能恰好等于 \(D_N(0)\) 的全部贡献；
3. 由此产生的 signed remainder 仍须有可证明的算术估计。

这不是新的 RH 证明，而是一个可审计的等价门：指数模型的边界项虽改变了
频率表达式，但没有移除 \(M(N)\) 的零频信号。
