> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 同壳跨移位的 Mellin Gram 恒等式与固定幂次缺口

日期：2026-08-15。

本 note 只讨论一个 dyadic 壳 \(I_X=(X,2X]\) 的跨 \(h\) signed 组合，不逐个移位取绝对值。设
\[
 E_X(w)=\sum_{m,n\in I_X}\mu(m)\mu(n)
 K\!\left(\log\frac mn\right),\qquad
 K(u)=\frac1{2\pi}\int_{\mathbb R}w(t)e^{itu}\,dt ,
\]
其中 \(w\ge0\)。有限和与积分交换给出精确恒等式
\[
 \boxed{\;
 E_X(w)=\frac1{2\pi}\int_{\mathbb R}w(t)
 \left|\sum_{n\in I_X}\mu(n)n^{it}\right|^2dt .
 \;}
\tag{1}
\]
这就是完整跨 \(h\) cancellation-preserving 的对象；任何逐 \(h\) 绝对值估计都会丢失 (1) 中的相消。

## 1. 归一化后的算子

令 \(x_n=n/X\) 以及有限符号测度
\[
 \nu_X=\sum_{n\in I_X}\mu(n)\,\delta_{x_n}.
\]
则
\[
 X^{-it}\sum_{n\in I_X}\mu(n)n^{it}
 =\int_{(1,2]}x^{it}\,d\nu_X(x).
\tag{2}
\]
故 (1) 是 \(\nu_X\) 的 Mellin 特征函数在固定 \(t\)-窗上的 \(L^2(w\,dt)\) 范数。随着 \(X\) 增大，\(x^{it}\)（\(t\) 在固定 \(\operatorname{supp}w\) 内）不产生随 \(X\) 增长的相位振荡；所有 \(X\)-依赖都在算术测度 \(\nu_X\) 中。Mellin/Fourier 谱分解本身不能制造幂次节省。

## 2. 正算子谱范数的严格障碍

令 \(G_X=(K(\log(m/n)))_{m,n\in I_X}\)。由 (1)，\(G_X\) 是正半定 Gram 矩阵。若 \(t_0\) 是 \(w\) 的 Lebesgue 点且 \(w(t_0)>0\)，取一般向量 \(a_n=n^{it_0}\)，则
\[
 a^*G_Xa
 =\frac1{2\pi}\int w(t)
 \left|\sum_{n\in I_X}n^{i(t-t_0)}\right|^2dt
 \asymp_w X^2,
\tag{3}
\]
因为对固定 \(u\)，
\[
 X^{-1}\sum_{X<n\le2X}n^{iu}
 \longrightarrow \int_1^2x^{iu}\,dx\neq0
\]
在 \(u\) 的一个小邻域内一致成立。于是 \(\|G_X\|_{\mathrm{op}}\gg_w X\)，而 \(\|a\|_2^2\asymp X\)。任何只利用 \(G_X\succeq0\) 或一般谱范数的不等式最多给 \(O_w(X^2)\)，不能对 Möbius 向量自动产生 \(X^{2-\delta}\)。

对实际向量 \(a_n=\mu(n)\)，(1) 的固定幂次上界等价于整个固定 \(t\)-窗上的新 twisted-Mertens 平均：
\[
 \int w(t)\left|\sum_{n\in I_X}\mu(n)n^{it}\right|^2dt
 \ll X^{2-\delta}.
\tag{4}
\]
经典零自由区只给 \(X^{2-o(1)}\) 量级；MRT averaged Chowla 在平滑 dyadic 分区后至多提供对数级移位平均，不能把 (4) 推进到固定幂次。

因此，真正的跨 \(h\) 路线若要越过平方根能量门，必须加入新的 prime/reflection signed intertwiner，或直接证明 (4) 型固定幂次 twisted-Mertens 定理；仅有 Mellin/Fourier Gram 恒等式和正算子谱分解不够。
