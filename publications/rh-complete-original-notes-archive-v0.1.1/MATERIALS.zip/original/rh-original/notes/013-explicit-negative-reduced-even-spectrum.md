> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 约化偶谱的显式负阈值：\(a\ge1/8\)

日期：2026-08-11。本文对 note 012 提出的候选捷径

\[
\mu_1(M_a^+)\ge0
\]

作最便宜的直接检查，并给出完全解析的否定证书：约化偶算子从 \(a=1/8\) 起已有严格负谱。证明
不使用素数定理、浮点数或 Galerkin 近似。

## 1. 偶常函数的精确形式值

令

\[
u_a=\mathbf1_{(-a,a)},
\qquad
\|u_a\|_2^2=2a.
\]

它属于 exterior-zero logarithmic energy domain，因为

\[
\|u_a-\tau_tu_a\|_2^2
=2\min(t,2a).
\]

记

\[
\kappa
=\gamma+\frac\pi2+\log(8\pi)
=-\bigl(\psi(1/4)-\log\pi\bigr).
\]

由 note 008 的纯跳表示及

\[
k(t)=\frac{e^{-t/2}}{1-e^{-2t}}
=\sum_{m=0}^\infty e^{-(2m+1/2)t},
\]

逐项积分得到

\[
\boxed{
\begin{aligned}
q_a^{\mathrm{red}}(u_a)
={}&8\sum_{m=0}^\infty
\frac{1-e^{-(4m+1)a}}{(4m+1)^2}
-2a\kappa\\
&+2\sum_{2\le n\le e^{2a}}
\frac{\Lambda(n)}{\sqrt n}(\log n-2a).
\end{aligned}}
\]

这里 prime-power 和中的每项都非正。连续跳跃项的计算为

\[
2\int_0^{2a}tk(t)\,dt
+4a\int_{2a}^\infty k(t)\,dt
=8\sum_{m=0}^\infty
\frac{1-e^{-(4m+1)a}}{(4m+1)^2}.
\]

## 2. 在 \(a=1/8\) 时 prime 项为空

取

\[
a=\frac18.
\]

因 \(e^{1/4}<2\)，没有满足 \(2\le n\le e^{2a}\) 的整数，故 prime-power 和为空。令

\[
E_\gamma
=8\sum_{m=0}^\infty
\frac{1-e^{-(4m+1)/8}}{(4m+1)^2}.
\]

于是

\[
q_{1/8}^{\mathrm{red}}(u_{1/8})
=E_\gamma-\frac\kappa4.
\]

## 3. 连续跳跃项的纯有理上界

对 \(x\ge0\)，Taylor 公式的正余项给出

\[
e^{-x}>
S_5(x):=\sum_{j=0}^5\frac{(-x)^j}{j!}.
\]

对 \(m=0,1,2,3\) 使用该下界。对尾项，函数

\[
f(x)=\frac1{(4x+1)^2}
\]

严格凸且递减，故中点积分界给出

\[
\sum_{m=4}^\infty f(m)
\le\int_{7/2}^\infty f(x)\,dx
=\frac1{60}.
\]

因此

\[
\begin{aligned}
E_\gamma
&<8\sum_{m=0}^3
\frac{1-S_5((4m+1)/8)}{(4m+1)^2}
+\frac2{15}\\
&=\boxed{\frac{6364357}{4792320}}.
\end{aligned}
\]

最后一个等号是有限有理数恒等式。

## 4. 常数项的纯有理下界

使用标准初等界

\[
\gamma>\frac{57}{100},
\qquad
\pi>\frac{157}{50},
\qquad
\log5>\frac85.
\]

第三式例如由

\[
\log5
=2\sum_{j=0}^\infty
\frac{(2/3)^{2j+1}}{2j+1}
>2\sum_{j=0}^3
\frac{(2/3)^{2j+1}}{2j+1}
>\frac85
\]

得到。又因 \(8\pi>25\)，

\[
\kappa
>\frac{57}{100}+\frac{157}{100}+\frac{16}{5}
=\boxed{\frac{267}{50}}.
\]

## 5. 严格负证书

合并上述两个有理界，

\[
\begin{aligned}
q_{1/8}^{\mathrm{red}}(u_{1/8})
&<\frac{6364357}{4792320}-\frac{267}{200}\\
&=\boxed{-\frac{166951}{23961600}<0}.
\end{aligned}
\]

除以 \(\|u_{1/8}\|_2^2=1/4\)，得到

\[
\boxed{
\mu_1(M_{1/8}^+)
<-\frac{166951}{5990400}<0.}
\]

## 6. 全部更大尺度

约化形式是同一个全局 pole-deleted Weil 形式在不同偶支撑子空间上的限制。若 \(a\ge1/8\)，把
\(u_{1/8}\) 零延拓到 \((-a,a)\)，其 \(L^2\) 范数和约化形式值均不变。因此

\[
\boxed{
\mu_1(M_a^+)
\le
\frac{q_{1/8}^{\mathrm{red}}(u_{1/8})}
{\|u_{1/8}\|_2^2}
<-\frac{166951}{5990400}
\qquad\forall a\ge\frac18.}
\]

这个结论也可视为约化偶谱在零延拓下单调不增的一个显式见证。

## 7. 对首次退化路线的裁决

note 012 指出：若能在首次退化尺度证明 \(\mu_1(M_{a_*}^+)\ge0\)，则可借严格奇扇区谱隙排除
不可见核并只保留奇 Schur 方程。本文证明该策略不可能成为全尺度结构定理：

\[
\mu_1(M_a^+)<0\qquad(a\ge1/8).
\]

因此只剩两个有决策价值的分支：

1. 严格证明任何首次退化尺度都满足 \(a_*<1/8\)，再在该短尺度区间研究 \(\mu_1(M_a^+)\)；或
2. 接受约化偶负方向的存在，直接证明零谱 cyclicity/UCP
   \[
   \ker M_a^\pm\cap\phi_\pm^\perp=\{0\},
   \qquad \phi_+=c,\ \phi_-=s,
   \]
   并分别控制两个 Schur 符号。

Suzuki 只证明“充分小”尺度上完整 \(A_a\) 正定，当前没有 \(a_*<1/8\) 的显式文献界。因此第 2 条
现为更稳健的主路线。

## 8. 边界

本文证明的是约化偶算子 \(M_a^+\) 的负谱，不是完整偶算子 \(A_a^+\) 的负谱。因为

\[
A_a^+=M_a^++2|c\rangle\langle c|,
\]

正秩一极点项仍可能抬升该负方向。本文不定位完整 Weil 形式的首次退化尺度，也不推出 RH。
