> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 414. 单一端点抵消不足以降低 Lehmer 核范数

note 409 中有限主部系数满足精确端点条件
\[
\sum_{m\le2Y}m a_m^{(Y)}=0.
\]
本 note 给出一个显式反例：该线性条件本身并不能把
\(L_N(m,n)=\min(m,n)/\max(m,n)\) 的二次型降到次二次量级。

## 1. 端点约束向量

令 (N=2M)，并定义
\[
c_n=
\begin{cases}
1,&1\le n\le M,\\
-\alpha_M,&M<n\le2M,
\end{cases}
\qquad
\alpha_M=\frac{M+1}{3M+1}.
\tag{1}
\]
因为
\[
\sum_{n\le M}n=\frac{M(M+1)}2,
\qquad
\sum_{M<n\le2M}n=\frac{M(3M+1)}2,
\]
有精确恒等式
\[
\sum_{nle2M}n c_n=0.
\tag{2}
\]

## 2. 二次型的非零极限

设
\[
R_M=\frac12\sum_{m,n\le2M}c_mc_n\frac{\min(m,n)}{\max(m,n)}.
\tag{3}
\]
把 (m=2Mx,n=2My) 分成两个半区，按有序三角形积分（或直接用调和数
的有限和）得到
\[
\frac{R_M}{(2M)^2}
\longrightarrow
\frac1{12}-\frac{\log2}{18}
>0.
\tag{4}
\]
具体地，极限来自
\[
\frac12\iint_{(0,1]^2}f(x)f(y)\frac{\min(x,y)}{\max(x,y)}\,dx\,dy,
\qquad
f=\mathbf1_{(0,1/2]}-\frac13\mathbf1_{(1/2,1]},
\]
其中三块积分分别给出
\[
\frac1{16},qquad -\frac{\log2}{24},qquad
\frac1{48}-\frac{\log2}{72}.
\]
其和正是 (4) 的常数。

同时
\[
\frac1N\sum_{n\le N}c_n^2\longrightarrow\frac59.
\]
因此 Rayleigh 商满足
\[
\frac{R_M}{\sum_{n\le N}c_n^2}\asymp N.
\tag{5}
\]
换言之，Lehmer 矩阵在超平面
\(\sum n c_n=0\) 上仍有线性级算子范数。

## 3. 对主线的含义

式 (2) 与主部的精确端点抵消具有同样形式，但 (3)--(5) 说明：
端点条件只消掉一个线性模态，不能自动给出 (Q_w\ll Y^{1+\varepsilon})，
甚至不能给出任何固定幂次的次二次上界。真正需要的是 Möbius 系数在该
高范数方向上的额外 signed cancellation；这正是 note 410 的 RH-equivalent
算术门，而不是 PSD 或端点恒等式可以提供的结果。

本 note 只排除“端点抵消单独足够”的线性代数路线，不对实际 Möbius 向量
的二次型作负面渐近断言。
