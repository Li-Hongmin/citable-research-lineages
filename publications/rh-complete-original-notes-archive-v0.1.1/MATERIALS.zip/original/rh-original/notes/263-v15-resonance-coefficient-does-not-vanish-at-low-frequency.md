> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(V_{15}\) 的共振系数在低频不自动消失

日期：2026-08-16。

本 note 检查 note 261 的共振项是否可能被实际十五次 detector 的
Mellin 权自动消掉。答案是否定的：在 \(t\to0\) 时，共振系数有明确
的非零二阶首项。

## 1. 共振系数的低频展开

沿用
\[
C_0(t)=
\frac{R(1-it,t)}{\zeta(1-it)\zeta(1+it)}.
\]
由 note 260 的 Euler 乘积，\(R(1-it,t)\) 在 \(t=0\) 连续且
\[
R(1,0)=1.
\]
另一方面，zeta 在 \(1\) 点的 Laurent 展开给出
\[
\zeta(1+it)\zeta(1-it)=t^{-2}+O(1),
\]
从而
\[
C_0(t)=t^2+O(t^3).
\tag{1}
\]
这里的 \(O(t^3)\) 只记录可能的相位项；将 \(t\) 与 \(-t\) 对称化后，
余项可写成 \(O(t^4)\)。

## 2. 代入 \(V_{15}\) 的 Mellin 权

对 note 144 的 detector，
\[
K_{15}(0)=-\frac1{30},\qquad \zeta(0)=-\frac12.
\]
因此其实 Fourier/Mellin 权在零频满足
\[
h_{15}(0):=\operatorname{Re}\!\bigl[\zeta(0)K_{15}(0)\bigr]
=\frac1{60}>0.
\tag{2}
\]
把 (1) 与 (2) 相乘，得到共振主项的低频系数
\[
\operatorname{Re}\!\left[
h_{15}(t)\frac{C_0(t)}{1-it}
\right]
=\frac{t^2}{60}+O(t^3),
\tag{3}
\]
而 \(t\leftrightarrow -t\) 对称化后为
\[
\frac{t^2}{60}+O(t^4).
\tag{4}
\]
所以 \(V_{15}\) 的实际 Mellin 权没有自动消掉 \(s=1-it\) 共振；
其低频邻域反而保留严格非零的二阶质量。

## 3. 结论

式 (3)--(4) 只说明低频局部没有结构性消失，不声称整个频率积分
必为非零，因为远频段仍可能发生 signed cancellation。但任何这样的
消失都必须是全局频率恒等式或新的算术 intertwiner，不能由
\(V_{15}\) 的端点平坦、Bernstein 正性或有限 parity 正性推出。

因此，当前最小补偿命题进一步收紧为：先扣除 note 262 的显式共振反项，
再证明 renormalized channel 与物理频率积分之间的统一 signed estimate。
