> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(L=4\) Newton 层：五阶 Stirling 卷积与有限正性证据

日期：2026-08-16。

## 1. 精确指数分解

沿用
\[
\mathcal F_{r,t}(M)
=\sum_{a+b=M}
\left\{\begin{matrix}r\\a\end{matrix}\right\}
\left\{\begin{matrix}t\\b\end{matrix}\right\}a!b!.
\]
当 \(r,t\ge1\) 时，直接代入
\[
\begin{aligned}
S(r,1)1!&=1,\\
S(r,2)2!&=2^r-2,\\
S(r,3)3!&=3^r-3\cdot2^r+3,\\
S(r,4)4!&=4^r-4\cdot3^r+6\cdot2^r-4
\end{aligned}
\]
得到
\[
\boxed{\begin{aligned}
\mathcal F_{r,t}(5)
={}&4^r+4^t-6\,2^{r+t}
+2^r3^t+3^r2^t\\
&+15(2^r+2^t)-6(3^r+3^t)-20.
\end{aligned}}
\tag{1}
\]
端点 \(t=0\) 不能直接套用 (1)，而是
\[
\mathcal F_{r,0}(5)
=5^r-5\cdot4^r+10\cdot3^r-10\cdot2^r+5.
\tag{2}
\]
这给出了 \(L=4\) raw Beta 组合的有限指数基底；与 \(L=3\) 的六项式相比，
这里新增 \(4^r,4^t,5^r\) 端点通道，尚未找到保持全 \(m\) 符号的同类
单变号重排。

事实上，直接按 \(W\) 的单个 Beta 单项分解也不能沿用 \(L=3\) 的
“先正后负”模板。取 \(m=6\)、\(M=0\)，去掉共同正权后的 raw
系数（按 \(x^j\)，零项省略）为
\[
\begin{array}{c|rrrrrrrrrrrrrrr}
j&0&1&2&3&4&5&6&7&8&9&10&11&12&13&14\\ \hline
&969899532&4206517392&8513292060&10840615968&
9860566716&6835356528&3718446732&1609223616&
565945380&167447280&40828788&6298656&
-221676&940800&-117600
\end{array}
\]
其符号序列为 \(+\cdots+,-,+,-\)，有三次变号；但所有累计前缀仍为正。
因此 \(L=4\) 的正性若成立，必须利用不同 Beta 单项之间的完整组合，
不能逐分量套用 \(L=3\) 的单变号引理。

## 2. 精确有限扫描

使用 note 156 的完整 \(q\)-shift/Stirling/Fraction 公式，固定 \(L=4\)
逐个检查
\[
0\le h\le3m+1.
\]
结果为：

| \(m\) | 最小 \(\gamma_{m,h,4}\) | 达到的 \(h\) |
|---:|---:|---:|
| 1,2,3 | 0 | 0 |
| 4 | 6110 | 0 |
| 5 | 15721632 | 0 |
| 10 | 4700292877909219359283515 | 0 |

上表中的大整数仅作尺度示意；权威结果是 Fraction 程序的逐项比较，
而不是浮点近似。扫描 \(m=1,\ldots,40\) 未发现负系数；\(m\ge4\) 的
最小值均在 \(h=0\)。

## 3. 证据边界

式 (1)--(2) 是严格代数恒等式，有限扫描也是精确有理算术；但目前没有
证明其 raw/endpoint 累计系数对任意 \(m\) 具有单变号或 manifest-positive
分解。因此不能把 \(L=4\) 的扫描提升为全 \(m\) 定理。

即使最终关闭所有固定 \(L\) 的 Newton 系数层，它仍只说明正 detector 的
periodization 系数锥；要解决 RH，仍须独立证明
\[
\int_{\mathbb R}|h(t)|
\left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt
\ll_\varepsilon N^{1+\varepsilon},
\]
或构造等价的 signed Möbius intertwiner。本文不声称 RH。
