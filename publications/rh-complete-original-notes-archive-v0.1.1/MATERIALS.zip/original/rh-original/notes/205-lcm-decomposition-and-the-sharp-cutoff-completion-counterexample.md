> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# lcm/common-scale 分解与 cutoff completion 的最小反例

日期：2026-08-15。

记
\[
 T_P(x)=\sum_{a,b\le\sqrt x}\mu(a)\mu(b)P\!\left(\frac{x}{ab}\right).
\]
本 note 按 \(X=\operatorname{lcm}(a,b)\) 分组，比较完整 lcm 层与实际半格
cutoff；结论是：分解有精确恒等式，但完整层不能无误差替代 cutoff 层。

## 1. 精确 lcm 分层

令
\[
 H_X^{x,\mathrm{cut}}
 :=\sum_{\substack{a,b\le\sqrt x\\\operatorname{lcm}(a,b)=X}}
 \mu(a)\mu(b)P\!\left(\frac{x}{ab}\right),
\qquad
 T_P(x)=\sum_{X\le x}H_X^{x,\mathrm{cut}}.
\tag{1}
\]
由于 \(\mu(a)\mu(b)\neq0\) 时 \(a,b\) squarefree，只有 squarefree \(X\) 层
非零。对完整 divisor 层定义
\[
 H_X^x
 :=\sum_{\substack{a,b\mid X\\\operatorname{lcm}(a,b)=X}}
 \mu(a)\mu(b)P\!\left(\frac{x}{ab}\right).
\tag{2}
\]
当 \(X\le\sqrt x\) 时 cutoff 自动，故
\[
 H_X^{x,\mathrm{cut}}=H_X^x\qquad(X\le\sqrt x).
\tag{3}
\]
因此唯一 completion remainder 精确为
\[
 T_P(x)=\sum_{X\le\sqrt x}H_X^x+
 \underbrace{\sum_{\sqrt x<X\le x}
 H_X^{x,\mathrm{cut}}}_{\text{宏观 cutoff 层}},
\tag{4}
\]
而不是完整 divisor 层 \(\sum_{X\le x}H_X^x\)。

按 \(X\) 的 Möbius 反演本身也完全显式：对 \(a,b\mid X\)，
\[
 {\bf1}_{\operatorname{lcm}(a,b)=X}
 =\sum_{\substack{d\mid X\\a\mid d,\ b\mid d}}\mu(X/d).
\tag{4a}
\]
若 \(P(y)=\frac1{2\pi}\int h(\xi)y^{i\xi}\,d\xi\)，则 cutoff 层满足
\[
 H_X^{x,\mathrm{cut}}
 =\frac1{2\pi}\int h(\xi)x^{i\xi}
 \sum_{d\mid X}\mu(X/d)
 \left(\sum_{\substack{a\le\sqrt x\\a\mid d}}\mu(a)a^{-i\xi}\right)^2d\xi .
\tag{4b}
\]
这显示反演不会自动产生正交性：每个 \(d\) 仍是同一频率 \(\xi\) 下的
signed square，且 cutoff 通过 \(a\le\sqrt x\) 保留在所有项中。

## 2. 完整层的 Möbius/质因子公式

若 \(X\) squarefree，写 \(d=\gcd(a,b)\)、\(a=dr\)、\(b=ds\)，则
\(d r s=X\)、\((r,s)=1\)、\(ab=dX\)。于是
\[
 H_X^x
 =\sum_{d\mid X} C_X(d)\,P\!\left(\frac{x}{dX}\right),
\quad
 C_X(d)=
 \sum_{\substack{rs=X/d\\(r,s)=1}}\mu(dr)\mu(ds).
\tag{5}
\]
对 squarefree \(X\)，若 \(q=X/d\)，则
\[
 C_X(d)=(-2)^{\omega(q)},
\qquad
 \boxed{\;
 H_X^x=\sum_{q\mid X}(-2)^{\omega(q)}
 P\!\left(\frac{xq}{X^2}\right).
\;}
\tag{6}
\]
若 \(P(y)=\frac1{2\pi}\int h(\xi)y^{i\xi}\,d\xi\)，则同一恒等式也写成
\[
 H_X^x=\frac1{2\pi}\int h(\xi)x^{i\xi}
 \prod_{p\mid X}\bigl(p^{-2i\xi}-2p^{-i\xi}\bigr)\,d\xi .
\tag{7}
\]
从而只有粗界
\[
 |H_X^x|\le \frac{\|h\|_1}{2\pi}\,3^{\omega(X)}
=X^{o(1)}\|h\|_1 .
\tag{8}
\]
把 (8) 对 \(X\) 求和仍是 \(x^{1+o(1)}\)，没有产生所需的平方根级节省；
不同 \(X\) 层之间也没有由 (7) 自动给出的正交性。

## 3. 最小严格 completion 反例

取素数 \(X=p\) 且 \(\sqrt x<p\le x\)。完整层的三个 divisor 对为
\((1,p),(p,1),(p,p)\)，故
\[
 H_p^x=-2P(x/p)+P(x/p^2).
\tag{9}
\]
但 cutoff 半格中 \(a,b\le\sqrt x<p\)，该 lcm 层没有任何 pair：
\[
 H_p^{x,\mathrm{cut}}=0.
\tag{10}
\]
因此只要 \(-2P(x/p)+P(x/p^2)\neq0\)，完整层与 cutoff 层即严格不同。
特别地，对 \(P(y)=y^\alpha\)（\(\alpha>0\)）有
\[
 H_p^x=-2(x/p)^\alpha+(x/p^2)^\alpha\neq0.
\]
这排除了把 \(\sum_XH_X^x\) 当作 \(T_P(x)\) 的无误差 completion。

## 4. 逐层 Schur 会丢掉跨 \(X\) 的平方根相消

即使每个 \(X\) 层都有相对 Schur 收缩
\[
 |H_X^{x,\mathrm{cut}}|\le A_X^{x,\mathrm{cut}},
\]
对 \(X\) 求和后也只得到
\[
 \sum_X|H_X^{x,\mathrm{cut}}|
 \le \sum_{a,b\le\sqrt x}\widetilde P\!\left(\frac{x}{ab}\right),
\tag{11}
\]
其中 \(\widetilde P\) 是对应的正 Gram 核；右端没有 lcm 层之间的 signed
相消。这个损失不是记号问题：取形式上的常数核 \(P=\widetilde P\equiv1\)，
\[
 T_P(x)=\Bigl(\sum_{n\le\sqrt x}\mu(n)\Bigr)^2,
\qquad
 \sum_{a,b\le\sqrt x}\widetilde P\!\left(\frac{x}{ab}\right)
 =\lfloor\sqrt x\rfloor^2.
\tag{12}
\]
前者由 PNT 仅为 \(o(x)\)，后者严格为 \(x+O(\sqrt x)\)。因此逐层
Schur/取模的自然上界仍停在 \(x\) 量级，完全没有产生目标所需的平方根级
节省；必须建立跨 \(X\) 的 signed
orthogonality/intertwiner，而非层内 completion 估计。
常数核只用于展示纯代数损失；在固定 \(1\le ab\le x\) 的有限范围上，可用
平滑 admissible 核一致逼近它，故该反例不依赖数值实验。

## 5. 非反射不变 cutoff 的互补块公式

本节的 \(H_X=G_XR_X\) 是 common-scale Gram/Feshbach 模型中的记号；它给出
lcm 层若要嵌入该模型时的线性代数必要条件，不改变前述 \(H_X^x\) 的精确
lcm 分层公式。

固定 \(X>\sqrt x\)，令 \(\mathcal D_X=\{d:d\mid X\}\) 为完整 divisor 标签，
\[
 L_X=\{d\in\mathcal D_X:d\le\sqrt x\},\qquad
 U_X=\mathcal D_X\setminus L_X .
\]
这里必须注意：当 \(X\le x\) 时，反射 \(R_Xd=X/d\) **不一定**把 \(L_X\)
全部送入 \(U_X\)。若 \(X/\sqrt x<d\le\sqrt x\)，则 \(d\) 与 \(X/d\)
可能同时属于 \(L_X\)。因此原先写成 \(P_{L_X}R_XP_{L_X}=0\) 的断言过强，
不能用于 cutoff 层。
例如 \(x=100\)、\(X=30\) 时，\(\sqrt{x}=10\)，而 \(d=6\) 与
\(X/d=5\) 都属于 \(L_X\)，所以内部反射块确实非零。

当额外满足 \(X>x\) 时，\(R_X\) 才把 \(L_X\) 注入 \(U_X\)，此时上述
\(R_{U_X,L_X}:=P_{U_X}R_XP_{L_X}\) 是等距嵌入；但本节的主范围是
\(\sqrt x<X\le x\)，不能使用这个零块简化。对完整 ordinary Gram
\(H_X=G_XR_X\)，无条件的 cutoff 压缩公式为
\[
 \boxed{\;
 H_X^{\mathrm{cut}}
 =P_{L_X}H_XP_{L_X}
 =G_{X;L_X,L_X}R_{X;L_X,L_X}
  +G_{X;L_X,U_X}R_{X;U_X,L_X}.
\;}
\tag{13}
\]
因此它既不是由 \(L_X\)--\(U_X\) 的互补 Gram block 单独决定，也不是由
\(G_{X;L_X,L_X}\) 单独决定；两个反射块都可能出现。若试图用正 Gram 的 Feshbach 消元，出现的正
Schur 补是
\[
 G_{X;L_X,L_X}
 -G_{X;L_X,U_X}G_{X;U_X,U_X}^{\dagger}
  G_{X;U_X,L_X}\succeq0 ,
\tag{14}
\]
其中 \({}^\dagger\) 为 Moore--Penrose 逆；(13) 中的互补 block
仍然不能由 cutoff 内数据恢复。对所有
\(X>\sqrt x\) 求和时，这些互补标签 \(X/d>\sqrt x\) 跨越宏观 common scales，
而 \(R_{X;L_X,L_X}\) 还带来 cutoff 内部的反射项；所以逐 \(X\) Schur 正性
仍无法替代一个跨 \(X\) 的 completion/intertwiner。

结论：lcm 分解可精确识别 \(X\le\sqrt x\) 的完整 divisor 层；宏观
\(X>\sqrt x\) cutoff 层仍承载全部 completion 难度。除非另给跨 \(X\) 的
signed orthogonality/intertwiner，Schur 正性或 (8) 的 subpower 层界不能推出
\(T_P(x)\ll x^{1/2+\varepsilon}\)。

## 6. 正 detector 下的素数层严格负号

对当前单侧 periodization，约定 \(P(y)=0\)（\(0<y<1\)）。若

\[
 \sqrt{x}<p\le x
\]

为素数，则 \(x/p^2<1\)，所以完整素数层的恒等式 (9) 精确化为

\[
 \boxed{H_p^x=-2P(x/p).}
\tag{15}
\]

这不是“通常非零”的可能性陈述：若 \(P(x/p)>0\)，该完整反射层严格为负，
而实际 cutoff 层仍恒为零。

更一般地，若 \(P\) 在某个 \(y_0>1\) 连续且 \(P(y_0)>0\)，则存在
\(\delta,c>0\) 使 \(P(y)\ge c\) 于
\((y_0-\delta,y_0+\delta)\)。对充分大的 \(x\)，素数定理保证存在素数
\[
 p\in\left(\frac{x}{y_0+\delta},\frac{x}{y_0-\delta}\right).
\]
此时 \(\sqrt{x}<p\le x\) 且 \(x/p\) 落在上述正区间，从而
\[
 H_p^x\le-2c<0.
\tag{16}
\]

因此，只要 detector 在任一固定 \(y_0>1\) 处严格为正，完整 divisor completion
就沿无穷多个尺度含有严格负的宏观素数层。对当前 detector，已有
\(P(2)=V(1/2)>0\)，故可取 \(y_0=2\)。这不构成原始 cutoff 二次型的负见证；
它严格说明“先补齐完整 divisor 格、再利用其 reflection/PSD 结构”不能无误差
恢复实际截断和，缺失的跨层 signed completion 正是算术 intertwiner 的承重部分。

## 7. 逐层正化的总修正预算

沿用第 6 节的假设，取 \(y_0>1\)、\(\delta,c>0\) 使
\(P(y)\ge c\) 于 \((y_0-\delta,y_0+\delta)\)。定义

\[
 \mathcal P_x=
 \left\{p\ {\rm prime}:\frac{x}{y_0+\delta}<p<
 \frac{x}{y_0-\delta}\right\}.
\]

对充分大的 \(x\)，每个 \(p\in\mathcal P_x\) 满足
\(\sqrt{x}<p\le x\)，并由 (15) 得

\[
 H_p^x\le-2c.
\tag{17}
\]

若采用逐层标量修正 \(F_p\) 并要求每一层都非负，
\(H_p^x+F_p\ge0\)，则必有

\[
 F_p\ge2c\qquad(p\in\mathcal P_x).
\]

由素数定理

\[
 |\mathcal P_x|\sim
 \left(\frac1{y_0-\delta}-\frac1{y_0+\delta}\right)
 \frac{x}{\log x},
\]

从而

\[
 \boxed{\sum_{p\in\mathcal P_x}F_p\gg_{P,y_0,\delta}\frac{x}{\log x}.}
\tag{18}
\]

若 \(F_p\) 来自每层的 Hermitian 矩阵修正，则同一结论应用于该层 Möbius
向量的 Rayleigh quotient：修正必须在该 mode 上支付至少 \(2c\) 倍的范数。
式 (18) 只针对逐层正化，不排除不同 \(p\) 层之间的 signed cancellation；
它严格说明任何逐层 PSD/固定秩 completion 都不可能产生平方根级总误差。
要保留目标量级，修正必须跨素数层共同作用，并实现真正的 signed
completion/intertwiner，而不能逐层取正。

## 8. 正交层 completion 模型中的有限秩修正不可能性

第 7 节的预算还可以写成一个严格的惯性结论，但必须明确模型假设。固定
满足第 7 节条件的 x，令

\[
 \mathcal H_x=\bigoplus_{p\in\mathcal P_x}\mathbb C e_p
 \oplus\mathcal H_{\rm rest}
\]

是把 lcm 层当作正交通道的 completion 空间，并明确令

\[
 D_x=\left(\bigoplus_{p\in\mathcal P_x}H_p^x\right)\oplus D_{\rm rest},
\]

其中 D_rest 是其余层的自伴块；也就是说，本节假设这些素数层与
其余通道之间没有未写出的 cross block。由 (17)，

\[
 D_x|_{\operatorname{span}\{e_p:p\in\mathcal P_x\}}
 \preceq -2c I .
\]

故

\[
 n_-(D_x)\ge |\mathcal P_x|\asymp \frac{x}{\log x}.
\tag{19}
\]

对任意 Hermitian 修正 F_x 满足 rank(F_x)=r，惯性扰动不等式给出

\[
 n_-(D_x+F_x)\ge n_-(D_x)-r.
\tag{20}
\]

因此若要求 D_x+F_x 为半正定，必有

\[
 \boxed{r\ge |\mathcal P_x|\asymp x/\log x.}
\tag{21}
\]

这严格排除了在“lcm 层彼此正交”的 completion 模型中用固定秩、
O(1) 秩或任何 o(x/log x) 秩的 PSD/Feshbach 修正来支付宏观素数层。
它**不**是原始 cutoff 二次型的全局负惯性定理：实际
\(T_P(x)\) 保留不同 lcm 层之间的 cross terms，可能存在跨层 signed
相消。故若要回到原始 Möbius 问题，仍需构造真实的跨层 intertwiner；不能把
正交层模型的 (21) 直接当作全局 no-go。
