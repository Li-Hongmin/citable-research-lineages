> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Shimizu v8 自伴 det2 声称：来源核验与最小未决桥

日期：2026-08-16。

## 结论先行

Yoshinori Shimizu 的 v8 预印本提出：由自伴 Hilbert--Schmidt 算子 (K)
构造二阶 Fredholm 行列式 (F_K)，再通过有限窗口显式公式与极限识别
(F_K(s)=\xi(s))，从而由自伴性得到临界带内零点在临界线上。该稿目前是
未同行评审的预印本；本地不将其吸收为黎曼猜想证明。

本次核验没有证明稿件错误。能改变本项目决策的判断是：其真正承重的部分不是
(\det_2) 的形式性质，而是从有限窗口几何/边界数据到经典 (\xi)-函数的全局
算术极限桥。这个桥与本项目一直未闭合的 signed Möbius intertwiner 属于同一类困难。

## 来源与主张范围

- 版本：v8，2026-07-01 提交、2026-07-03 发布；页面明确标为未同行评审。
- 预印本页面：[Preprints.org manuscript 202505.2110](https://www.preprints.org/manuscript/202505.2110)。
- 外部评阅：[PREreview review 17143549](https://prereview.org/reviews/17143549)。

PREreview 提到的风险类别包括：有限带宽的等价关系与 (p=2) 半规则、对所有测试函数的分布恒等式、解析延拓与增长、端点项、
(\det_2)/迹理想近似、系数输运，以及密度和极限交换。这些意见不是本地证明，
但与逐式核验时出现的未决桥一致。

## 稿件内部的声称链

稿件的逻辑链可压缩为

\[
\text{Definition 6.78}
\;\longrightarrow\;
\text{finite-window identities (Lemmas 6.147--6.154)}
\;\longrightarrow\;
\text{Theorem 6.155 (}M\to\infty\text{)}
\;\longrightarrow\;
\text{Theorem 6.156 / Lemma 6.158}
\;\longrightarrow\;
F_K=\xi.
\]

Definition 6.78 先定义
\[
F_K^0(s)=\det_2\!\bigl(I+i(s-\tfrac12)K\bigr),
\qquad F_K(s)=e^{a_{\rm EF}+b_{\rm EF}(s-1/2)}F_K^0(s),
\]
其中 (a_{\rm EF},b_{\rm EF}) 被指定为显式公式账本的中心常数与中心斜率。
Theorem 6.155 随后把有限窗口相等式推进到 (M\to\infty)，Theorem 6.156
给出导数版本，Lemma 6.158 使用中心标量相等式得到局部相等，最终再用全纯恒等定理。

## 可直接接受的标准部分

若 (K=K^*) 且 (K\in S_2)，则二阶 Fredholm 行列式是标准的全纯对象；其零点
与 (K) 的实特征值经过 (s-\tfrac12=i\lambda) 的参数化相连。这一段本身
只说明“给定正确的 (K) 后，行列式具有对称零点结构”，并不说明该 (K) 的
行列式就是 Riemann (\xi)-函数。

同样，使用 (\xi'/\xi) 的显式公式把几何边界项与零点残数项配平，并不等于
使用 RH；但它只提供零点侧的显式公式账本，仍需要另一条独立恒等式把这个账本
与 (K) 的有限窗口数据连接起来。

## 最小未决桥

### 1. 有限窗口身份不是纯形式恒等式

Proposition 5.30 通过 seam transpose、Gram inverse 与 LCI 构造有限窗口项，并
使用 (C_{\rm seam}U_{\rm seam}=I) 型关系。必须逐项检查：

1. seam 空间、Gram 矩阵和逆矩阵的定义域是否在每个窗口都相同；
2. 端点/有限部项是否已全部列出，而不是被放入未量化的 remainder；
3. 该身份是否对稿件后面所用的全部测试函数成立，而非只对有限生成子空间成立。

这正对应 PREreview 所指出的分布恒等式、端点和有限带宽问题。

### 2. (M\to\infty) 是核心算术/分析桥

Lemma 6.154 只给固定窗口的比较。Theorem 6.155 需要 seminorm 收敛
（稿件引用 Lemma 6.109）和相应泛函连续性（Theorem 6.152），才能把有限窗口
身份传到无限对象。这里必须有可复核的统一估计，控制：

- 窗口边界随 (M) 移动时的端点项；
- Gram inverse 或 seam readout 的条件数；
- 显式公式分布在极限中的尾项；
- 交换密度极限、有限部极限与零点残数求和。

在本项目的语言中，这正是 signed arithmetic intertwiner：需要把带符号的
Möbius/prime 数据送入同一个 Hilbert 空间，并保留交叉项的符号。仅有局部
自伴性或有限窗口正交性不能替代它。

### 3. 中心常数必须独立识别

稿件把 (a_{\rm EF},b_{\rm EF}) 定义为显式公式账本的中心常数与斜率，之后
再在目标识别步骤使用 (F_K(1/2)=\xi(1/2)) 及导数相等。该步骤若是由独立的
有限窗口极限计算出来，则是合法归一化；若只是把常数选择成使中心值匹配，
则只能得到归一化后的行列式，不能得到 (\xi)。因此需要看到独立计算，而不
能只看 Definition 6.78 的定义。

## 与本地路线的关系

本项目已经严格得到：对 (V_{15})，half-lattice 二次型的
(x^{1/2+\varepsilon}) 上界与 RH 等价（见 notes/290--291）；同时已经有
有限负 Möbius 块、Toeplitz/Hankel 不相容以及 scale-alignment 坍缩为 Mertens
尾的结果（见 notes/292）。因此 Shimizu v8 若要成为独立的无条件证明，必须
提供一个本地尚未拥有的全局桥，而不能只提供另一个自伴 det2 表示。

最薄可检验接口是：在不预设 RH 的条件下，证明其有限窗口算子与经典
Möbius/prime 分布之间的统一 intertwining，并给出 (M\to\infty) 的显式误差；
随后再独立识别 (a_{\rm EF},b_{\rm EF})。在这两步完成前，本地裁决为
“有明确结构、尚未验证的 RH 声称”，不是证明，也不是已证反例。

## 裁决

1. 不把该预印本的结论写入项目定理或“已解决 RH”状态。
2. 保留其可复用的算子问题表述：有限窗口 seam/Gram 结构、det2 自伴零点
   参数化、以及需要独立证明的全局极限桥。
3. 后续若要推进，只检查上述三类桥中的一个具体估计；不再重复泛泛的
   “自伴 \(\Rightarrow\) RH”叙述。

