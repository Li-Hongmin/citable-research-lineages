> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(P(z)=1-2z\) 的离散 Mellin 变换与 RH 等价能量门

## 1. 无限尾差分

由 PNT，级数 \(\sum_{n\ge1}\mu(n)/n\) 收敛到 \(0\)。定义
\[
B(k)=\sum_{n\ge k}\frac{\mu(n)}n,
\qquad
H(k)=B(k)-B(\lceil k/2\rceil).
\]
这正是 note 400 中 \(P(z)=1-2z\) 的无限尾差分；它删掉了常数尾模态。

令 \(w_k(z)=k^{-z}\)，并约定 \(w_0(z)=0\)。对 \(\Re z>0\)，有限交换
求和给出
\[
\begin{aligned}
\mathcal F_H(z)
&:=\sum_{k\ge1}H(k)\bigl(w_k(z)-w_{k-1}(z)\bigr)\\
&=\sum_{n\ge1}\frac{\mu(n)}n
\left(\sum_{k\le n}(w_k-w_{k-1})
-\sum_{k\le2n}(w_k-w_{k-1})\right)\\
&=(1-2^{-z})\sum_{n\ge1}\frac{\mu(n)}{n^{z+1}}\\
&=\boxed{\frac{1-2^{-z}}{\zeta(z+1)}}.
\end{aligned}
\tag{1}
\]

这里第二个累计上限是 \(2n\)，因为
\(\lceil k/2\rceil\le n\) 等价于 \(k\le2n\)。

## 2. 能量界蕴含 RH

假设对每个 \(\varepsilon>0\)，所有 \(Y\ge2\) 都有
\[
E_H(Y):=\sum_{k\le Y}k|H(k)|^2
\ll_\varepsilon Y^{1+\varepsilon}.
\tag{2}
\]
在 dyadic 块 \(Y<k\le2Y\) 上，
\[
|w_k(z)-w_{k-1}(z)|\ll_z k^{-\sigma-1},
\qquad \sigma=\Re z.
\]
Cauchy--Schwarz 与 (2) 给出
\[
\sum_{Y<k\le2Y}|H(k)|\,|w_k-w_{k-1}|
\ll_{\varepsilon,z}
Y^{-\sigma-\frac12+\frac{\varepsilon}{2}}.
\tag{3}
\]
当 \(\sigma>-1/2\) 时取 \(\varepsilon<2\sigma+1\)，右端对 dyadic \(Y\)
可求和。因此 \(\mathcal F_H(z)\) 在半平面
\[
\Re z>-1/2
\tag{4}
\]
绝对收敛并定义全纯函数；它在 \(\Re z>0\) 与 (1) 相同，故
\((1-2^{-z})/\zeta(z+1)\) 可全纯延拓到 (4)。

若 \(\zeta(\rho)=0\) 且 \(\Re\rho>1/2\)，令 \(z=\rho-1\)，则
\(\Re z>-1/2\)。分子 \(1-2^{-z}\) 的零点为
\[
z=\frac{2\pi i\ell}{\log2},\qquad \ell\in\mathbb Z.
\]
若分子不为零，(1) 在 \(z=\rho-1\) 有极点，矛盾；若分子为零，则
\(\Re\rho=1\)，与 \(\zeta\) 在 \(\Re s=1\) 无零点矛盾。因此 (2) 排除
所有 \(\Re\rho>1/2\) 的零点，推出 RH。

## 结论

\(P(1/2)=0\) 虽然删掉了 note 399 的 \(k=1\) 直接观测，但其无限尾
差分仍有精确的 reciprocal-zeta Mellin 响应。只要给出自然的
\(Y^{1+\varepsilon}\) 加权能量界，就已经是 RH-equivalent 命题；真正未解
的仍是这个差分能量本身，而不是形式上的滤波器构造。
