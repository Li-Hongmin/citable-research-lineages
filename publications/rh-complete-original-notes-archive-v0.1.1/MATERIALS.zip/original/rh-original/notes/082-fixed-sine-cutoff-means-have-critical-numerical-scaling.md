> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定正弦 cutoff 均方呈临界数值尺度

日期：2026-08-13。

依赖：[note 079](079-path-dst-reduces-the-centered-defect-to-sqrtN-low-modes.md)、
[note 081](081-every-offline-zero-is-visible-in-one-fixed-sine-mode.md)。计算脚本：
[`scratch/probe_fixed_sine_cutoff_means.py`](../scratch/probe_fixed_sine_cutoff_means.py)。

## 1. 可证伪量

对固定 \(k\ge1\)，令

\[
M_{2,k}(Y):=\frac1Y\sum_{Y<N\le2Y}|\mathcal R_{N,k}|^2.
\tag{1}
\]

note 081 的充分条件等价于

\[
M_{2,k}(Y)\ll_{k,\varepsilon}Y^{1+\varepsilon}
\qquad(\forall k\text{ fixed}).
\tag{2}
\]

若存在 \(\rho=\beta+i\gamma\)、\(\beta>1/2\)，则至少一个固定 \(k=k(\rho)\)
在某个 dyadic 子列上满足

\[
M_{2,k}(Y)\gg_\rho Y^{2\beta}(\log Y)^{2m_\rho-2}.
\tag{3}
\]

故观测斜率 \(1\) 是临界线；它不是 RH 的证明。

## 2. 计算

运行

```bash
python3 -B scratch/probe_fixed_sine_cutoff_means.py \
  --max-power 20 --samples-per-shell 64 \
  --seed 20260813 --covariance residualized
```

即 \(Y=2^{10},\ldots,2^{19}\)，每壳等宽分层抽取 64 个 \(N\)，计算
\(1\le k\le16\)。对 \(\log M_{2,k}\) 关于 \(\log Y\) 作最小二乘拟合：

| \(k\) | 全十壳斜率 | 后五壳斜率 |
|---:|---:|---:|
| 1 | 1.0040 | 1.0017 |
| 2 | 1.0027 | 1.0888 |
| 3 | 0.9920 | 1.0033 |
| 4 | 0.9628 | 0.8927 |
| 8 | 1.0211 | 0.9480 |
| 16 | 1.0482 | 1.3306 |

后段高模受 64 点抽样噪声明显影响。对较稳定的加权量

\[
M_{2,\le16}^{(-2)}(Y):=
\sum_{k=1}^{16}\frac{M_{2,k}(Y)}{k^2},
\tag{4}
\]

全十壳与后五壳斜率分别为

\[
\boxed{0.9968,qquad1.0256.}
\tag{5}
\]

在最大壳 \(Y=2^{19}\) 上，分半样本差的最大相对值为 \(12.42\%\)。

## 3. 联合消去是承重结构

把

\[
\mathcal R_{N,k}=a_{N,k}+p_{N,k}+m_{N,k}
\tag{6}
\]

写成 residualized affine、prime、Möbius 三项：奇 \(k\) 时从 affine 项减去
\(2N/(\pi k)\)，同时加回 prime 项；偶 \(k\) 不变。此分解严格保持总和。

最大壳上 prime--Möbius 相关系数为

\[
\boxed{
\rho_{pm}(k=1,2,3)=(-0.8691,-0.9200,-0.9755).
}
\tag{7}
\]

所以

\[
\operatorname{Var}(p+m)ll
\operatorname{Var}(p)+\operatorname{Var}(m)
\tag{8}
\]

来自强负协方差。任何先分别绝对值估计 \(\Lambda\) 与 \(\mu\)，再相加的证明都会丢失当前
数据中最强的结构。

## 4. 新猜想与判决

**固定正弦 cutoff 猜想。** 对每个固定 \(k\ge1\) 与 \(\varepsilon>0\)，

\[
\boxed{
\sum_{Y<N\le2Y}|\mathcal R_{N,k}|^2
\ll_{k,\varepsilon}Y^{2+\varepsilon}.
}
\tag{9}
\]

由 note 081，(9) 推出 RH。当前计算支持其临界幂，但不区分
\(Y^2(\log Y)^A\) 与 \(Y^{2+\delta}\)，也不能排除稀疏 dyadic 异常子列。

```mermaid
flowchart LR
  H["历史 H⁰/large sieve"] --> G["generic bound: 差一幂"]
  P["prime residual"] --> C["strong negative covariance"]
  M["Möbius residual"] --> C
  C --> Q["fixed-k joint cutoff Gram"]
  Q --> T["Y^(2+o(1)) conjecture"]
  T --> RH((RH))
```

下一最小元不是扩大拟合范围，而是对固定 \(k\) 展开 \(N\)-Gram，并保留
\(\Lambda+\mu\log(n/N)\) 的联合系数。
