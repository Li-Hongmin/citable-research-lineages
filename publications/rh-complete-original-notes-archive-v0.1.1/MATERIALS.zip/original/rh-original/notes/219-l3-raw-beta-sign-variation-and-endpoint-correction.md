> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(L=3\) raw Beta 分量的全 \(m\) 单变号引理

> **状态：已撤回的历史草稿。** 该文件中的 Beta 分量与 q-shift
> 权重尚未在更正后的 (w_q=c_q\binom Dq) 约定下逐式对齐；其脚本只
> 检查辅助多项式，不能作为 (L=3) 全 (m) 正性证书。当前应以
> notes 366、367 的精确恒等式为准。

日期：2026-08-16。

本 note 把 note 176 的六项 \(L=3\) 生成式进一步压缩为一个
逐 Beta 分量的符号引理。结论是：对 \(m\ge4\)，每个 raw Beta
分量的 Bernstein 系数先正后负，且总和为正；因此其所有累计系数
均为正。端点修正也可在同一范围内严格证明非负。这里的结论只
关闭 \(L=3\) Newton 层的 detector 系数接口，不涉及 Möbius
signed energy，也不构成 RH 证明。

## 1. Beta 分量与系数

令
\[
D=3m+3,\qquad M=m-1-r,\qquad L=3m+1-M,
\]
其中 \(0\le M\le m-1\)。由 note 176 的六项式，去掉共同的正
Beta 权后，raw 分量可写成
\[
\begin{aligned}
A(y)&=(3m+1)y^{L-1}-2(m-1)y^{L-2}-My^{L-3},\\
F(y)&=A(y)-3y^L,\\
P_{m,M}(x)&=F(x+2)+4(2^{M+1}-1)A(x+1)
             +12(1-2^M)(x+1)^L .
\end{aligned}
\tag{1}
\]
写
\[
r_2={u\over L},\qquad
r_1={u(u-1)\over L(L-1)},\qquad
r_0={u(u-1)(u-2)\over L(L-1)(L-2)},\qquad u=L-j.
\]
直接二项式展开给出
\[
[x^j]P_{m,M}(x)=\binom LjR_{m,M}(u),
\tag{2}
\]
其中
\[
\begin{aligned}
f(u)&={3m+1\over2}r_2-{m-1\over2}r_1-{M\over8}r_0-3,\\
g(u)&=(3m+1)r_2-2(m-1)r_1-Mr_0,\\
R_{m,M}(u)&=2^u f(u)+4(2^{M+1}-1)g(u)+12(1-2^M).
\end{aligned}
\tag{3}
\]

## 2. \(M\ge1\) 的低指标

令 \(z=2^M\) 和 \(k=m-M\ge1\)。有
\[
R(0)=-3(4z-3)<0,\qquad
R(1)={9k+3M+3-z(12k+4)\over L}<0.
\tag{4}
\]
第二个不等式在 \(M=1\) 时为 \(-15k-2<0\)；在 \(M\ge2\)
时使用 \(z\ge M+1\) 即得。

对 \(u=2,\ldots,6\)，\(R(u)\) 关于 \(z\) 是仿射函数。清除共同
的正分母 \(L(L-1)(L-2)\) 后，其 \(z\)-斜率和 \(z=2\) 时的值
分别为正因子乘以下表中的 \(A_u\)、\(B_u\)。斜率侧的正因子
（按 \(u=2,\ldots,6\)）为
\(4(3m-M-1),12,4,4,12\)；\(z=2\) 侧为
\(4(3m-M-1),6,4,4,12\)：
\[
\begin{array}{c|l|l}
u&A_u&B_u\\ \hline
2&
12a^2+24ab+42a+9b^2+37b+42&
18a^2+33ab+58a+9b^2+41b+52\\
3&
16a^3+60a^2b+88a^2+72ab^2+218ab+172a
 +27b^3+129b^2+220b+124&
48a^3+168a^2b+240a^2+180ab^2+532ab+419a
 +54b^3+258b^2+464b+275\\
4&
72a^3+276a^2b+380a^2+342ab^2+972ab+708a
 +135b^3+603b^2+990b+520&
120a^3+420a^2b+548a^2+450ab^2+1200ab+840a
 +135b^3+567b^2+978b+532\\
5&
96a^3+372a^2b+480a^2+468ab^2+1250ab+816a
 +189b^3+795b^2+1264b+600&
204a^3+708a^2b+850a^2+747ab^2+1805ab+1074a
 +216b^3+795b^2+1321b+620\\
6&
40a^3+156a^2b+188a^2+198ab^2+496ab+276a
 +81b^3+321b^2+494b+200&
128a^3+444a^2b+504a^2+468ab^2+1058ab+536a
 +135b^3+453b^2+724b+280
\end{array}
\tag{5}
\]
这里 \(a=M-1\ge0\)、\(b=k-1\ge0\)。表中所有系数严格为正，
所以
\[
R(u)>0\qquad(M\ge1,\ u=2,\ldots,6).
\tag{6}
\]

## 3. \(u\ge7\) 的尾部

先证明 \(f\) 递增且 \(f(7)>0\)。其在整数点的二阶差分为
\[
\Delta^2f(u)=-
{ -4Mm+3Mu+4M+12m^2-16m+4
 \over4L(L-1)(L-2)}\le0 .
\tag{7}
\]
括号在 \(u\ge7\) 时为正：若 \(m\le6\) 取 \(M=1\) 已给
\(12m^2-20m+29>0\)，若 \(m\ge7\) 取 \(M=m-1\) 给
\((m-1)(8m+21)>0\)。此外
\[
\Delta f(7)=
{N\over4L(L-1)(L-2)},\qquad
\Delta f(L-1)={-3M+4m+12\over8L},
\]
其中
\[
N=6M^2m+2M^2-36Mm^2+22Mm-89M
 +54m^3-84m^2+106m-28.
\]
代入 \(a=M-1,b=m-M-1\) 后
\[
N=24a^3+96a^2b+108a^2+126ab^2+298ab+141a
 +54b^3+204b^2+302b+105>0.
\]
由于 \(\Delta f\) 为凹序列，两个端点为正即得
\(f(u)\ge f(7)>0\)。同样
\[
f(7)=
{Q\over4L(L-1)(L-2)},\quad
Q=12M^3-66M^2m+14M^2+72Mm^2+42Mm-187M
 +54m^3-252m^2+330m-84,
\]
而
\[
Q=72a^3+240a^2b+260a^2+234ab^2+486ab+219a
 +54b^3+144b^2+234b+79>0.
\]

再看 \(g\)。有
\[
\Delta^2g(u)=-
{2(-2Mm+3Mu+2M+6m^2-8m+2)\over L(L-1)(L-2)}\le0.
\tag{8}
\]
括号在 \(u\ge7\) 时为正；端点满足
\[
g(L)=m+3-M\ge4,
\]
并且
\[
g(7)=
{7G\over L(L-1)(L-2)},\quad
G=3M^2m+M^2-18Mm^2+9Mm-41M+27m^3-36m^2+45m-12.
\]
代入 \(a,b\) 后
\[
G=12a^3+48a^2b+58a^2+63ab^2+159ab+84a
 +27b^3+108b^2+165b+62>0.
\]
所以 \(g(u)\ge\min\{g(7),g(L)\}>0\)。

最后令
\[
S_7(z)=128f(7)+4(2z-1)g(7)+12(1-z),
\]
\[
S_L(z)=128f(7)+4(2z-1)g(L)+12(1-z).
\]
两者均为 \(z\) 的仿射函数。对 \(S_7\)，斜率的正分子在
\(a,b\) 中为
\[
144a^3+564a^2b+632a^2+720ab^2+1686ab+732a
 +297b^3+1107b^2+1644b+508>0,
\]
而 \(S_7(2)\) 的正分子为
\[
804a^3+2820a^2b+3118a^2+3033ab^2+6687ab+3072a
 +918b^3+3015b^2+4671b+1574>0.
\]
对 \(S_L\)，斜率为
\[
4(-M+3m)(-2M+2m+3)(-M+3m-1)(-M+3m+1)>0,
\]
而 \(S_L(2)\) 的正分子在 \(a,b\) 中为
\[
24a^3b+648a^3+108a^2b^2+2424a^2b+2620a^2
 +162ab^3+2898ab^2+5952ab+3084a
 +81b^4+1080b^3+3033b^2+4230b+1712>0.
\]
因此 \(S_7(z),S_L(z)>0\) 对 \(z=2^M\ge2\)。由
\(f(u)\ge f(7)\)、\(g(u)\ge\min\{g(7),g(L)\}\)，得到
\[
R(u)>0\qquad(M\ge1,\ u\ge7).
\tag{9}
\]

当 \(M=0\) 时，低端精确值为
\[
R(0)=-3,\ R(1)=-1,\ 
R(2)=-{20(m-1)\over3m(3m+1)},\
R(3)=-{24(m-1)\over m(3m+1)},\
R(4)=-{64(m-1)\over m(3m+1)},
\]
\[
R(5)={4(3m^2-39m+40)\over m(3m+1)},\qquad
R(6)={8(9m^2-47m+50)\over m(3m+1)}>0 .
\tag{10}
\]
尾部的同一二阶差分论证在 \(M=0\) 也成立：此时
\[
Q=6(m-2)(3m-7)(3m-1)>0,\quad
N=2(3m-1)(9m^2-11m+14)>0,
\]
\[
G=3(3m-1)(3m^2-3m+4)>0,
\]
且 \(g(L)=m+3\)。由于常数项为零，故 \(R(u)>0\) 于 \(u\ge7\)；
结合 (10)，\(R(u)\) 至多一次由负到正的变号。

## 4. Raw 前缀与端点修正

直接代入 (1) 得总和
\[
P_{m,0}(1)=
{2^{3m}(24m+24)+3^{3m}(7m-22)\over3}>0.
\tag{11}
\]
当 \(M\ge1\)，把 \(z=2^M\) 暂视为变量，\(P_{m,M}(1)\) 关于 \(z\)
的斜率为
\[
2^{3m-M+1}(8m-M-4)>0,
\]
且在 \(z=2\) 时
\[
{3^{3m-M}(-M+21m-66)\over9}
 +2^{3m-M}(24m-3M)>0,
\]
因为 \(M\le m-1\)、\(m\ge4\)。所以所有 raw 分量的总和为正。
结合 (2)、(4)、(6)、(9)、(10)，其系数先正后负且总和为正，
故每个 raw 累计前缀系数严格为正。

实际端点修正使用 note 176 的
\[
\delta_q=4^{q+1}-6\cdot3^{q+1}+10\cdot2^{q+1}-10.
\]
有 \(\delta_1=-8,\ldots,\delta_4=-124\)，且
\(\delta_q>0\) 且严格递增于 \(q\ge5\)。note 157 的尾和
\(T_Q=\sum_{q\ge Q}K_q>0\) 与 Abel 变换给出
\[
\sum_{q\ge5}K_q\delta_q\ge0.
\]
对 \(m\ge4\)，\(K_2,K_3,K_4\le0\)，因为
\[
K_q=w_q(D-q){q^2+3q-6m-4\over(2m-q)(q-1)}
\quad(2\le q\le m),
\]
而 \(q=2,3,4\) 时分子分别为 \(6-6m,14-6m,24-6m\)。
故 \(K_q\delta_q\ge0\) 对 \(q=1,2,3,4\)（\(K_1=-3w_2<0\)），
从而每个 \(Q=1,2,3,4\) 的端点尾和也非负；\(Q\ge5\) 已由 Abel
处理。于是 \(L=3\) 的端点修正不再构成 \(m\ge4\) 的障碍。

## 5. 结论边界

这给出 \(m\ge4\) 的 \(L=3\) raw/endpoint Newton 系数正性；
\(m=1,2,3\) 仍可用 Fraction 直接核验（其中 \(m=3\) 的完整最小值
为 \(928/15\)）。因此 \(L=3\) 层可从“\(m\le60\) 有限扫描”提升为
“全 \(m\) 的 Beta 分量符号证明 + 低层有限核验”。

这仍只推进 detector 的系数锥。要解决 RH，必须另外证明
\[
\int_{\mathbb R}|h(t)|\left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt
\ll_\varepsilon N^{1+\varepsilon},
\]
而该 Möbius signed-energy 门当前没有由本 note 得到的新估计。
