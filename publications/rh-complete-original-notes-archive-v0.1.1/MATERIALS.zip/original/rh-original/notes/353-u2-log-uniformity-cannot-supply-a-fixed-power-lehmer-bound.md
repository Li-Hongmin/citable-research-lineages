> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(U^2\) 对数统一性不能单独给出 Lehmer 固定幂次界

日期：2026-08-16。

note 352 已将 Tao--Teräväinen 的
\(\|\mu\|_{U^2[N]}\ll_A^{\mathrm{ineff}}(\log N)^{-A}\)
转成 Lehmer 能量的任意固定对数节省。本 note 固定该路线的逻辑上限：
即使把 \(U^2\) 对数估计取得任意高次，它本身也不能推出
\(N^{2-\delta}\) 的固定幂次节省。

## 1. 零频只得到对数级平均

对归一化局部 Gowers 范数，单调性给出
\[
 \frac1N\left|\sum_{n\le N}f(n)\right|
 =\|f\|_{U^1[N]}
 \le \|f\|_{U^2[N]}.
\]
因此 \(U^2\) 的估计只能直接推出
\[
 \left|\sum_{n\le N}\mu(n)\right|
 \ll_A^{\mathrm{ineff}}N(\log N)^{-A}.
\]
这仍是 \(N^{1-o(1)}\)，与平方根级 Mertens 界相差一个固定幂次。

## 2. 有界模型排除“范数本身自动给幂次”

令 \(0<\delta_N\le1\)，取模型序列 \(f_N(n)=\delta_N\)。
则
\[
 \|f_N\|_{U^2[N]}=\delta_N,
 \qquad
 \sum_{n\le N}f_N(n)=N\delta_N.
\]
取 \(\delta_N=(\log N)^{-A}\) 时，\(U^2\) 正好具有任意固定对数衰减，
但零频和仍为 \(N(\log N)^{-A}\)，没有任何固定幂次节省。

同样，Lehmer 核 \(K_N=L_N-v_Nv_N^T\) 对该模型满足
\[
 f_N^T K_N f_N
 =\delta_N^2\,\mathbf 1^T K_N\mathbf 1
 =\delta_N^2\left\{\frac{N(N+1)}2-H_N^2\right\}
 \asymp \delta_N^2N^2,
\]
其中 \(H_N=\sum_{n\le N}1/n\)，且
\[
 \mathbf 1^TL_N\mathbf 1
 =N+2\sum_{n=2}^N\frac1n\sum_{m<n}m
 =\frac{N(N+1)}2.
\]
因此减去 \((\sum_{n\le N}1/n)^2=H_N^2\) 仍只改变低阶项。
所以“\(U^2\) 很小”在抽象范数层面并不排除
\(N^2(\log N)^{-2A}\) 的 Lehmer 能量。

## 3. 对 Möbius 的精确缺口

对真实 Möbius 序列，额外的乘法结构当然可能提供更多信息；但那必须是
超出 \(U^2\) 对数统一性的独立算术输入，例如
\[
 \|\,\mu\,\|_{U^2[N]}\ll N^{-\delta},
 \quad\text{或直接}\quad
 \left|\sum_{n\le N}\mu(n)\right|\ll N^{1/2+\varepsilon},
\]
后者本身等价于 RH。Tao--Teräväinen 的 Theorem 1.3(ii)
只给任意固定对数幂衰减，故 note 352 的结论不能升级为固定幂次，
也不能关闭 note 347 的 RH-equivalent Lehmer 门。
