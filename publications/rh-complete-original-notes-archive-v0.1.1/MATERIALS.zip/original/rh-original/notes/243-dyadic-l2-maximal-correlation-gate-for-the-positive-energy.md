> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正能量门的 dyadic \(L^2\) 相关充分条件

本 note 先记录一个容易误用的逐移位绝对值上界，再给出保留移位块内
signed cancellation 的 dyadic \(L^2\) 门。后者更接近主问题，但两者都
不在本 note 中被声称为已知定理。

## 1. 精确相关展开

令

\[
 w(t)=\frac{|h(t)|}{2\pi},\qquad
 K(u)=\int_{\mathbb R}w(t)e^{itu}\,dt.
\]

这里把 Fourier 归一化常数吸收到 (K) 中；这样下面的相关展开与
\(E_N(w)=\int w(t)|F_N(t)|^2dt\) 完全一致。若采用
\((2\pi)^{-1}\) 归一化，只需将 (1)--(2) 的右端统一乘上 (2\pi)，
不改变任何增长阶或充分条件。

当前 \(V_{15}\) 的频率矩保证 \(K\in C^1(\mathbb R)\)。展开正能量：

\[
 E_N(w)
 =K(0)\sum_{m\le N}\mu(m)^2
 +2\sum_{1\le h<N} S_{h,N},
\]

这里 \(w\) 为偶函数，因而 \(K\) 为实偶函数。

\[
 S_{h,N}
 :=\sum_{m\le N-h}\mu(m)\mu(m+h)
 K\!\left(\log\frac m{m+h}\right).
 \tag{1}
\]

令

\[
 C_h(Y)=\sum_{m\le Y}\mu(m)\mu(m+h),\qquad
 A_h(N)=\max_{Y\le N-h}|C_h(Y)|.
\]

对 \(W_{h,N}(x)=K(\log(x/(x+h)))\)，函数
\(x\mapsto\log(x/(x+h))\) 单调递增，且

\[
 \operatorname{Var}_{[1,N-h]}W_{h,N}
 \le \|K'\|_\infty\log(1+h).
\]

Abel 分部求和给出严格界

\[
 |S_{h,N}|
 \le A_h(N)\bigl(\|K\|_\infty+\|K'\|_\infty\log(2+h)\bigr).
 \tag{2}
\]

## 2. 先取逐移位最大值：一个过强但严格的充分条件

假设存在任意 \(\varepsilon>0\) 的常数 \(C_\varepsilon\)，使所有 dyadic
 \(H<N\) 满足

\[
 \boxed{
 \sum_{H\le h< 2H} A_h(N)^2
 \le C_\varepsilon N^{2+\varepsilon}H^{-1}.
 }
 \tag{3}
\]

对一个 dyadic 块 \(\mathcal H=(H,2H]\)，由 Cauchy--Schwarz 和 (2)：

\[
 \begin{aligned}
 \sum_{h\in\mathcal H}|S_{h,N}|
 &\le
 \left(\sum_{h\in\mathcal H}A_h(N)^2\right)^{1/2}
 \left(\sum_{h\in\mathcal H}
  \bigl(\|K\|_\infty+\|K'\|_\infty\log(2+h)\bigr)^2\right)^{1/2}\\
 &\ll_{K,\varepsilon}
 N^{1+\varepsilon/2}\bigl(1+\log(2H)\bigr).
 \end{aligned}
 \tag{4}
 \]

对 \(O(\log N)\) 个 dyadic 块求和，并把对角项吸收进
\(N^{1+\varepsilon}\)，得到

\[
 \boxed{
 (3)\quad\Longrightarrow\quad
 E_N(w)\ll_{K,\varepsilon}N^{1+\varepsilon}.
 }
 \tag{5}
\]

由 notes 212、213，(5) 进一步推出 RH。

但是，(3) 不是“比逐移位 \(\ell^1\) 门更弱”的自然替代。若把
\(A_h(N)\) 粗略看成随机相关的平方根规模，则左侧约为 \(HN\)，而
(3) 的右侧为 \(N^2/H\)；当 \(H\) 宏观时二者相差一个幂次。因此 (3)
只是一个严格、但会丢掉块内 signed cancellation 的过强充分条件。

## 3. 保留移位块 signed cancellation 的正确 \(L^2\) 门

令 \(\mathcal D_N=\{2^j:2^j<N\}\)，并定义

\[
 \mathcal B_H(N):=
 \sum_{\substack{H\le h<2H\\h<N}}
 \sum_{m\le N-h}\mu(m)\mu(m+h)
 K\!\left(\log\frac m{m+h}\right).
 \tag{6}
\]

则 (1) 精确改写为

\[
 E_N(w)=K(0)\sum_{m\le N}\mu(m)^2+
 2\sum_{H\in\mathcal D_N}\mathcal B_H(N).
 \tag{7}
\]

因此，只要对每个 \(\varepsilon>0\) 有

\[
 \boxed{\displaystyle
 \sum_{H\in\mathcal D_N}|\mathcal B_H(N)|^2
 \ll_{\varepsilon} N^{2+\varepsilon},
 }
 \tag{8}
\]
就由 Cauchy--Schwarz 和 \(|\mathcal D_N|=O(\log N)\) 得

\[
 E_N(w)\ll_{\varepsilon}N^{1+\varepsilon}.
 \tag{9}
\]

这里的 (8) 只对完整 dyadic 移位块取平方，完全保留
\(\mu(m)\mu(m+h)\) 的块内 signed cancellation；它没有把每个 \(h\) 的
最大部分和先取绝对值。由 notes 212--213，(8) 仍足以推出 RH，但目前
没有无条件证明。

## 4. 与固定移位 Chowla 的量词差异

条件 (3) 同时要求：

1. \(h\) 在完整 dyadic 块内平均；
2. 对每个 \(h\) 取最大部分和 \(A_h(N)\)；
3. 平均平方规模达到 \(N^2/H\)。

因此逐个固定 \(h\) 的 \(C_h(Y)=o(Y)\) 不足以推出 (3)。即使有统一
 \(A_h(N)\le N\rho(N)\)，左侧也只有 \(H N^2\rho(N)^2\)，与 (3) 相比
仍差一个随 \(H\) 增长的幂次。已知 averaged-Chowla 型结果至多提供对数级
 \(\rho(N)\) 节省，不能替代 \(H^{-1}\) 的 dyadic square-root 结构。

## 5. 证据边界

式 (3) 是正能量门的严格但过强的充分条件；式 (8) 是保留块内符号抵消的
较自然充分条件。两者都不声称必要性，也都不声称已知。逐移位加权
\(\ell^1\) 条件 \(\sum_hA_h(N)\log(2+h)\ll N^{1+\varepsilon}\) 虽然容易
写出，但会丢掉块内抵消；所有这些门仍是 RH-strength 的 signed Möbius
相关命题。
当前最小算术任务应优先写成 (8)，而不是继续改进 detector 的有限层正性。
