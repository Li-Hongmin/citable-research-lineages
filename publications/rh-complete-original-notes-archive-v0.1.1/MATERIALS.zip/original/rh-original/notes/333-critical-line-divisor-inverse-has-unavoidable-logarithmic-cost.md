> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 除数关联反演在临界线至少支付对数代价

日期：2026-08-16。

本 note 量化 \(B_V=A_VD\) 路线中除数反演的最小代价。它不是 RH
证明，而是一个不依赖 detector 细节的必要性：在临界线自然的
Dirichlet 权重下，\(D^{-1}\) 不可能成为 uniformly bounded 的桥。

## 1. 有限除数矩阵

在 \(\{1,\ldots,N\}\) 上定义
\[
 (D_Nx)_d=\sum_{b\mid d}x_b.
\]
它是单位下三角矩阵，且
\[
 (D_N^{-1}y)_d=\sum_{b\mid d}\mu(d/b)y_b.
\tag{1}
\]
特别地，对第一坐标向量 \(e_1\)，
\[
 D_N^{-1}e_1=(\mu(1),\ldots,\mu(N))^T.
\tag{2}
\]

## 2. 加权范数下的精确下界

对 \(\sigma\in\mathbb R\)，令
\[
 \|x\|_{\sigma,N}^2=\sum_{n\le N}|x_n|^2n^{-2\sigma}.
\]
因为 \(\|e_1\|_{\sigma,N}=1\)，(2) 立即给出
\[
 \boxed{
 \|D_N^{-1}\|_{\sigma,N\to\sigma,N}^2
 \ge \sum_{n\le N}\frac{\mu(n)^2}{n^{2\sigma}}.
 }
\tag{3}
\]
利用 squarefree 计数（或
\(\mu(n)^2=\sum_{d^2\mid n}\mu(d)\)）可得：
\[
\sum_{n\le N}\frac{\mu(n)^2}{n^{2\sigma}}
\asymp_\sigma
\begin{cases}
N^{1-2\sigma},&\sigma<\frac12,\\[1mm]
\log N,&\sigma=\frac12,\\[1mm]
1,&\sigma>\frac12.
\end{cases}
\tag{4}
\]
在临界线上更精确地，
\[
 \sum_{n\le N}\frac{\mu(n)^2}{n}
 =\frac6{\pi^2}\log N+O(1).
\tag{5}
\]
因此
\[
 \|D_N^{-1}\|_{1/2,N\to1/2,N}
 \ge \sqrt{\frac6{\pi^2}\log N+O(1)}.
\tag{6}
\]

## 3. 对 periodization 桥的含义

note 234 的恒等式 \(B_V=A_VD\) 说明：从容易坍缩的
\(B_V\mu=A_Ve_1\) 回到保留 \(K_V/\zeta\) 的 \(A_V\mu\)，必须在某个
加权序列空间中实现 \(D_N^{-1}\)。若要求一个 uniformly bounded 的
算术 intertwiner，(6) 已经排除该要求；无权空间的代价更大，
\(\|D_N^{-1}\|^2\gg N\)。

在 \(\sigma>1/2\) 的右半平面，(4) 的下界保持有界，但这正是已经远离
临界线的区域；把桥推回 \(\sigma=1/2\) 必须承担至少对数增长。该对数
下界本身还不足以排除 \(N^\varepsilon\) 级 RH 估计，因此不能误称为
RH 障碍定理；它只是说明“正 periodization 输出 + 常数有界除数反演”
这条最直接的构造不可能成立。

真正需要的新输入仍是：在临界线权重下，利用 Möbius 的额外 signed
cancellation，把 \(D_N^{-1}\) 与 \(A_V\) 的几何结构联合处理，而不是
把 \(D_N^{-1}\) 当作一个独立的 bounded matrix。
