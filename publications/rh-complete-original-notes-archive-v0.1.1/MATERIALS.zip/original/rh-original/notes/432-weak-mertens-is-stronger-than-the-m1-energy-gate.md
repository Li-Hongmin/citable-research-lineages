> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 432. 弱 Mertens 假设与当前 (M_1) 能量门的强度关系

## 1. 两个命题

记
\[
 M(x)=\sum_{n\le x}\mu(n),
 \qquad
 U(x)=M_1(x)=\sum_{n\le x}n\mu(n).
\]
当前主线的门是
\[
 \sum_{n\le Y}\frac{|U(n)-U(\lfloor n/2\rfloor)|^2}{n^3}
 \ll_\varepsilon Y^{1+\varepsilon}.
 \tag{A}
\]
文献中更强的弱 Mertens 假设为
\[
 \int_1^X\left|\frac{M(t)}t\right|^2dt\ll\log X.
 \tag{WM}
\]
它被明确作为未解决猜想提出，并已知蕴含 RH；见
https://arxiv.org/abs/1705.00853，§1，式 (1.7) 及其后的说明。

## 2. 严格的单向蕴含

由 Abel 恒等式
\[
 U(x)=xM(x)-\int_1^xM(t)\,dt,
 \tag{1}
\]
在 dyadic 块 \(X\le x<2X\) 上，(WM) 给出
\[
 \int_X^{2X}\frac{|M(x)|^2}{x^2}\,dx\ll\log X,
 \qquad
 \left|\int_1^xM(t)\,dt\right|
 \ll X^{3/2}(\log X)^{1/2}.
 \tag{2}
\]
因此
\[
 \sum_{X\le n<2X}\frac{|U(n)|^2}{n^3}
 \ll X\log X.
 \tag{3}
\]
同样的估计适用于 \(U(\lfloor n/2\rfloor)\)，故
\[
 \sum_{X\le n<2X}
 \frac{|U(n)-U(\lfloor n/2\rfloor)|^2}{n^3}
 \ll X\log X.
 \tag{4}
\]
对 dyadic 块求和即得 (A)，因为 \(Y\log Y\ll_\varepsilon Y^{1+\varepsilon}\)。

反向关系在 notes 410--411 已严格给出： (A) 迭代恢复
\(\sum_{n\le Y}|U(n)|^2/n^3\ll Y^{1+\varepsilon}\)，再由
\(1/\zeta(s-1)=s\int_1^\infty U(x)x^{-s-1}dx\) 延拓到
\(\Re s>3/2\)，从而推出 RH。

## 3. 结论

(WM) 是一个不同但定量更强的均方猜想；这里不声称 (A) 与 (WM) 之间有
严格的逻辑蕴含。它不能作为无条件证明的替代输入。
当前主门仍是 (A) 的无条件证明，而不是寻找更强的弱 Mertens 假设。任何声称
由已知均方结果直接关闭 (A) 的路线，都必须解释它如何越过文献中明确保留的
弱 Mertens/零点负矩假设。
