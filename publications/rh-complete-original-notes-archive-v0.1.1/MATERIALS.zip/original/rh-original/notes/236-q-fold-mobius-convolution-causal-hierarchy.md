> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# q 次 Möbius 卷积的因果算子层级

近期的局部矩工作表明：若能对任意高阶局部矩给出 subpolynomial 界，便可从 \(M(N)\) 的点值局部化中恢复 RH。但这不能直接从当前的二次 detector 能量推出。下面给出一个精确的算子理由。

## 1. 卷积与除数 incidence

令 \(D\) 为除数 incidence：
\[
(Dc)(n)=\sum_{d\mid n}c(d).
\]
写 \(c_0=\varepsilon\)（\(\varepsilon(1)=1\)，其余为零），并令
\[
c_q=\underbrace{\mu*\cdots*\mu}_{q\ \text{次}}.
\]
由 \(\mathbf 1*\mu=\varepsilon\) 得
\[
D c_q=c_{q-1},\qquad D^q c_q=c_0.
\tag{1}
\]

## 2. 精确 q 阶交换子恒等式

对任意因果算子 \(A\)，令 \(C=[A,D]=AD-DA\)。归纳得到
\[
AD^q
=D^qA+\sum_{j=0}^{q-1}D^j C D^{q-1-j}.
\tag{2}
\]
将 (2) 作用于 \(c_q\)，并用 (1)，得到
\[
\boxed{
A c_q
=D^{-q}A c_0
-\sum_{j=0}^{q-1}D^{\,j-q}C c_{j+1}.
}
\tag{3}
\]
这里 \(D^{-1}\) 是 Möbius incidence inverse；式 (3) 在每个有限截断 \(1\le n\le N\) 上都是有限矩阵恒等式。

当 \(q=1\) 时，(3) 退化为
\[
A\mu=D^{-1}A\varepsilon-D^{-1}C\mu,
\]
正是 note 235 的分解。

对一般有限序列 \(x,y\)，同一个三角分解还给出
\[
\sum_{a,b}x_ay_b\,g_V(\log(a/b))
=\frac12\bigl(\langle x,A_VDy\rangle+\langle y,A_VDx\rangle\bigr).
\tag{4}
\]
因此在 \(x=c_i,y=c_j\) 上，signed detector 产生的卷积层矩阵是
\[
T_{ij}
=\frac12\left(
\langle c_i,A_Vc_{j-1}\rangle+
\langle c_j,A_Vc_{i-1}\rangle
\right).
\tag{5}
\]
这个矩阵不能直接当作正 Gram：对 \(V_{15}\)、截断 \(N=10\)，
\(\det(T_{ij})_{1\le i,j\le2}<0\)（精确有理数，验证脚本同时核验）。所以三角坍缩
虽然给出显式交叉项，却不会自动产生可迭代的正矩阵。

在 (N=10) 的精确有理计算中，矩阵条目为

\[
\begin{aligned}
T_{11}&=-\frac{745261875504099976533784856011631}
 {34061159291475841150500000000000000},\\
T_{12}&=-\frac{1509089166924807852829389826134077591100408989}
 {16015045656103247459624468594688000000000000000},\\
T_{22}&=-\frac{26742191739282277633790109576063864320156521}
 {200188070701290593245305857433600000000000000}.
\end{aligned}
\]

且

\[
\det T=-\frac{1527689582770778936255787488673238331973998869241822749443993048617023327430696106709076041}
 {256481687367071495895514422355251864423299634821335605621817344000000000000000000000000000000}<0.
\]

两个特征值约为 (-0.1872713329137525) 与 (0.0318058827336145)。这些数值只是阅读辅助；符号结论由有理数行列式直接给出，验证脚本还对 (N=3,ldots,17)、(q=1,ldots,4) 逐项核验了恒等式。

## 3. 对当前 RH 路线的含义

若把 \(|F_N(t)|^{2q}\) 展开，则其系数是 \(c_q=\mu^{*q}\)。因此，高阶局部矩路线若要通过当前因果 detector 实现，必须同时控制
\[
D^{j-q}C c_{j+1},\qquad 0\le j<q.
\]
它不是单个 \(\mu\) 通道的重复，而是所有较低卷积层的耦合；(2) 还表明每增加一阶矩，就新增一个非交换子通道。note 235 的秩下界说明 \(C\) 本身不是固定秩边界项，所以高阶化并不会自动消除算术 signed 问题。

近期局部矩论文的结论可作为目标形状：高阶局部矩若有 subpolynomial 上界则推出 RH；但目前没有把该加法 Fourier 局部矩上界转化为 (3) 中全部 \(c_q\) 非因子通道的无条件估计。当前最小新命题因此是：建立对所有 \(j<q\) 的联合 signed bound，而非只证明一个正二次 detector 能量。
