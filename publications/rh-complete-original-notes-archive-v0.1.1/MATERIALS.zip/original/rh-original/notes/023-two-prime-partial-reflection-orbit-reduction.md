> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 两个素数平移的有限轨道分解

日期：2026-08-11。

本文把第二个素数激活带

\[
\frac{\log 3}{2}\le a\le \log 2
\]

上的两个部分反射算子精确分解为至多四维的纤维。它延伸 note 019 的单反射结构，并为 note 021
的固定秩 Yukawa 尾归约提供素数部分的显式逆。本文只处理联合轨道与逆算子，不断言该带内完整
Weil 算子的正性。

## 1. 对象

记

\[
d_2=\log2,\qquad d_3=\log3,\qquad \Delta=d_3-d_2,
\]

并在 \(L^2(0,a)\) 上定义

\[
(J_i f)(x)=\mathbf 1_{[d_i-a,a]}(x)f(d_i-x),\qquad i=2,3.
\]

端点取舍不改变算子。令

\[
\ell_2=d_2-a,\quad \ell_3=d_3-a=\ell_2+\Delta,
\quad h=a-\Delta,
\]

\[
c=d_2-\Delta=2d_2-d_3,\qquad x_0=\frac c2.
\]

在整条带上

\[
0\le \ell_2\le x_0\le h<\frac{d_2}{2}<\ell_3\le a.
\tag{1}
\]

其中两个严格不等式归结为同一个初等事实：

\[
h<\frac{d_2}{2}<\ell_3
\quad\Longleftrightarrow\quad
2^{3/2}<3.
\tag{2}
\]

## 2. 联合轨道分类

两个反射 \(r_i(x)=d_i-x\) 满足

\[
r_3r_2(x)=x+\Delta,\qquad r_2r_3(x)=x-\Delta.
\tag{3}
\]

每个点在两个匹配的并图中度数至多为二；非平凡交替环将由 (2) 强迫
\(k\Delta=0\)（\(k\ne0\)），故不存在。除零测端点外，联合轨道只有以下三类。

### 孤立点

\[
x\in[0,\ell_2):\qquad \mathcal O_x=\{x\}.
\tag{4}
\]

### 二点链

以 \((h,d_2/2)\) 为基本域：

\[
x\xleftrightarrow{\ 2\ }d_2-x.
\tag{5}
\]

### 四点链

以 \([\ell_2,x_0)\) 为基本域，依次记

\[
v_0=x,\quad v_1=d_2-x,\quad
v_2=x+\Delta,\quad v_3=c-x.
\]

则

\[
v_0\xleftrightarrow{\ 2\ }v_1
\xleftrightarrow{\ 3\ }v_2
\xleftrightarrow{\ 2\ }v_3.
\tag{6}
\]

更精确地，\(v_0,v_3\) 在 \(x_0\) 两侧覆盖 \([\ell_2,h]\)，而

\[
v_2([\ell_2,x_0))=[\ell_3,d_3/2),\qquad
v_1([\ell_2,x_0))=(d_3/2,a]
\]

覆盖 \([\ell_3,a]\)（忽略端点零测差异），故已穷尽。于是

\[
\boxed{\operatorname*{ess\,max}_{x\in(0,a)}|\mathcal O_x|\le4.}
\tag{7}
\]

更精确地，\(a=d_3/2\) 时四点区域退化为零测集，essential maximum 为二；若
\(d_3/2<a\le d_2\)，则为四。带内没有其他组合临界尺度。

## 3. 纤维矩阵与显式逆

令

\[
p_2=\frac{\log2}{\sqrt2},\qquad
p_3=\frac{\log3}{\sqrt3},
\]

\[
D_\sigma=\beta I+\sigma(p_2J_2+p_3J_3),
\qquad \sigma\in\{-1,+1\}.
\tag{8}
\]

孤立纤维的逆为 \(\beta^{-1}\)。二点纤维上，令
\(E=\left(\begin{smallmatrix}0&1\\1&0\end{smallmatrix}\right)\)，则

\[
(\beta I+\sigma p_2E)^{-1}
=\frac{\beta I-\sigma p_2E}{\beta^2-p_2^2}.
\tag{9}
\]

四点纤维上，按 (5) 的顺序令

\[
B=
\begin{pmatrix}
0&p_2&0&0\\
p_2&0&p_3&0\\
0&p_3&0&p_2\\
0&0&p_2&0
\end{pmatrix},
\qquad X=\sigma B,
\]

\[
q=2p_2^2+p_3^2,qquad
\Delta_4(\beta)=\beta^4-q\beta^2+p_2^4.
\]

直接展开得到

\[
X^4-qX^2+p_2^4I=0.
\tag{10}
\]

因此，只要 \(\Delta_4(\beta)\ne0\)，

\[
\boxed{
(\beta I+X)^{-1}
=\frac{
\beta(\beta^2-q)I+(q-\beta^2)X+\beta X^2-X^3
}{\Delta_4(\beta)}.}
\tag{11}
\]

反转对称性还把 \(B\) 分成

\[
B_+=\begin{pmatrix}0&p_2\\p_2&p_3\end{pmatrix},
\qquad
B_-=\begin{pmatrix}0&p_2\\p_2&-p_3\end{pmatrix},
\tag{12}
\]

所以全部逆矩阵元也可只用两个二次分母表示。

## 4. 推论与边界

在第二激活带内，素数部分的 resolvent 计算不需要无限级数或一般反射群理论；它严格化为
\(1\times1\)、\(2\times2\)、\(4\times4\) 的可测纤维逆。因而与 note 021 的 Archimedean
固定秩尾结合后，完整端点 Schur 问题仍是有限维、可做区间认证的。

本文不证明 \(D_\sigma>0\) 的所有参数条件，也不证明
\(A_a^\pm>0\)。这些符号判断仍取决于 Archimedean Yukawa 部分与极点秩一项的联合 Schur 补。
