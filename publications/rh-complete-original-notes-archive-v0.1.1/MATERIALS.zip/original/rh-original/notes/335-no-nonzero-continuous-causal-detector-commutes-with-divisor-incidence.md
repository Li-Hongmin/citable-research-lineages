> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 非零连续 causal detector 不可能与除数算子交换

日期：2026-08-16。

note 334 中的 Weil 交换子接口会留下 \([A_V,D]\)。本 note 证明一个
全称 no-go：只要 \(V\) 连续且不恒为零，ratio-causal 算子 \(A_V\)
就不可能与除数 incidence \(D\) 交换。故该 commutator 不是某个
detector 选择造成的偶然误差。

## 1. 交换关系的坐标式

令
\[
 (A_Vx)(a)=\sum_{d\le a}x(d)V(d/a),
 \qquad
 (Dx)(a)=\sum_{d\mid a}x(d).
\]
若 \(A_VD=DA_V\)，取基向量 \(e_b\)，则对任意 \(a\ge b\)
\[
 \sum_{c\le a/b}V(bc/a)
 =
 \sum_{\substack{d\mid a\\d\ge b}}V(b/d).
\tag{1}
\]

## 2. 素数截断

令 \(a=p\) 为素数，并取 \(1<b<p\)。右端只有除数 \(d=p\)，故 (1)
化为
\[
 \sum_{c\le p/b}V(cb/p)=V(b/p).
\tag{2}
\]
记 \(x=b/p\)、\(k=\lfloor p/b\rfloor\)。则
\[
 \sum_{c=2}^{k}V(cx)=0,
 \qquad \frac1{k+1}<x\le\frac1k.
\tag{3}
\]

## 3. 区间归纳

当 \(k=2\) 时，取 \(p/3<b\le p/2\)，由 (3)
\[
 V(2b/p)=0.
\]
素数 \(p\to\infty\) 时这些点在 \((2/3,1)\) 稠密，连续性给出
\[
 V=0\quad\text{于 }(2/3,1).
\tag{4}
\]

现在归纳假设 \(V=0\) 于 \((2/k,1)\)，其中 \(k\ge2\)。取
\[
 \frac{p}{k+1}<b\le\frac pk.
\]
对每个 \(c=3,\ldots,k\)，有
\[
 \frac{c}{k+1}<\frac{cb}{p}\le\frac ck,
 \qquad
 \frac{c}{k+1}\ge\frac2k.
\]
故归纳假设使 \(V(cb/p)=0\)。式 (3) 遂给出
\[
 V(2b/p)=0.
\]
当素数 \(p\) 增大时，点 \(2b/p\) 在区间
\((2/(k+1),2/k]\) 稠密，连续性得到
\[
 V=0\quad\text{于 }(2/(k+1),2/k].
\]
归纳覆盖 \(k=2,3,\ldots\)，从而
\[
 V\equiv0\quad\text{于 }(0,1].
\tag{5}
\]
若 \(V\) 在 \([0,1]\) 连续，则 \(V(0)=0\) 也随之成立。

因此
\[
 \boxed{
 A_VD=DA_V,\quad V\in C([0,1])
 \Longrightarrow V\equiv0.
 }
\tag{6}
\]

## 4. 对 RH 算术桥的含义

式 (6) 比“某个 V 的交换子秩随截断增长”更强：不存在非零连续
ratio-causal detector 可以消掉 note 334 中的
\(D^{-1}[A_V,D]C_\Lambda\) 缺口。要构造 Weil/prime intertwiner，
必须允许非 causal/nonlocal kernel，或保留 growing-rank commutator 的
完整 signed cancellation；不能靠重新挑选一个正 periodization detector
使除数反演与 detector 对易。
