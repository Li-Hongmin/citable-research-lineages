> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 417. principal filter 精确压缩为紧支撑比值核

## 1. 从滤波系数回到原始 Möbius 向量

令 (Y\ge1)，(mu_Y=(\mu(1),\ldots,\mu(Y))^T)，并令
\[
 a_m=2\mu(m)\mathbf 1_{m\le Y}-\mathbf 1_{2\mid m}\mu(m/2)\mathbf 1_{m\le2Y},
 \qquad 1\le m\le2Y.
\]
若 (T_Y) 是 (2Y\times Y) 矩阵
\[
 (T_Y)_{m,n}=2\mathbf1_{m=n}-\mathbf1_{m=2n},
\]
则 (a=T_Y\mu_Y)。因此 note 416 的 principal 能量满足精确恒等式
\[
 Q_w(Y)=\frac12\mu_Y^T K_Y\mu_Y,
 \qquad K_Y=T_Y^TL_{2Y}T_Y,
\]
其中 (L_N(i,j)=\min(i,j)/\max(i,j))。

## 2. 压缩核的闭式

利用 (L(\lambda m,\nu n)=L(m,n)) 的齐次性，逐项展开得
\[
 K_Y(m,n)=5L(m,n)-2L(m,2n)-2L(2m,n).
 \tag{1}
\]
写 (r=m/n)。直接分段化简得到与 (Y) 无关的函数
\[
 K_Y(m,n)=\kappa(r),
 \qquad
 \kappa(r)=
 \begin{cases}
 0,&0<r\le \frac12,\\
 4r-r^{-1},&\frac12\le r\le1,\\
 4r^{-1}-r,&1\le r\le2,\\
 0,&r\ge2.
 \end{cases}
 \tag{2}
\]
端点处各表达式一致；特别地，
\[
 \kappa(1)=3,\qquad \kappa(1/2)=\kappa(2)=0,
 \qquad \kappa(r)=\kappa(1/r).
\]
所以滤波器把相互作用精确压缩到 (1/2\le m/n\le2) 的非负、紧支撑比值核。

## 3. 对角与加性移位形式

由 (K_Y(n,n)=3)，并把上、下三角成对合并，得到
\[
\boxed{
 Q_w(Y)=\frac32\sum_{n\le Y}\mu(n)^2
 +\sum_{n=1}^{Y-1}\sum_{1\le h\le\min(n,Y-n)}
 \mu(n)\mu(n+h)
 \left(\frac{4n}{n+h}-\frac{n+h}{n}\right).
 }
 \tag{3}
\]
这里 (m=n+h)。权重非负，且在 (h=n) 时为零；式 (3) 是 exact identity，不是渐近展开。

## 4. 它改变了什么、没有改变什么

式 (3) 把 principal gate 的剩余算术问题明确化为
\[
 1\le h\le n,
 \qquad \mu(n)\mu(n+h),
 \qquad \text{权重只依赖 }h/n.
\]
这比 note 413 的三项滤波分解更紧：固定滤波尺度的交叉项已被吸收到一个单一
紧支撑核中。它也说明下一道门不是抽象的正定性，而是所有相对移位尺度上的
Möbius 二点相关。

但这还不能直接调用固定 (h) 的 Chowla/MRT 型估计：这里 (h) 运行到 (n)，
权重随 (h/n) 移动，且必须在全部 dyadic 尺度上联合控制。现有对数级平均结果
至多给出 (Y^{2-o(1)}) 型基线；要得到 (Q_w(Y)\ll Y^{1+\varepsilon})，仍需新的
跨尺度 signed 二次均方或算术 intertwiner。因而本 note 是一次严格归约，
不是 RH 证明，也不是固定幂次改善。

## 5. 有理数核验

`computations/verify_principal_compact_ratio_kernel.py` 对 (Y\le80) 用 `Fraction`
直接比较 (T_Y^TL_{2Y}T_Y)、分段函数 (2) 和对角/上三角公式 (3)，全部条目逐项相等。
有限核验只确认公式，不外推无限维结论。
