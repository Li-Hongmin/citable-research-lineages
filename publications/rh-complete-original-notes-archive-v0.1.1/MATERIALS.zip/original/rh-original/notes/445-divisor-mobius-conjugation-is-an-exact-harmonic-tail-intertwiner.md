> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 除数—Möbius 共轭把 Lehmer 因子精确变成调和尾矩阵

日期：2026-08-17。

本 note 给出除数 incidence 与 Lehmer 三角因子的精确共轭。它不是一个新的平方根估计，但把“非对角 signed intertwiner”压缩成可直接研究的跨尺度调和尾矩阵。

## 1. 两个有限三角算子

令

\[
(D_N)_{n,d}=\mathbf 1_{d\mid n},\qquad 1\le n,d\le N.
\]

这是单位下三角矩阵，其逆为

\[
(D_N^{-1})_{n,d}=\mu(n/d)\mathbf 1_{d\mid n}.
\tag{1}
\]

在 \(1\le k<N\)、\(1\le n\le N\) 上定义

\[
(R_N)_{k,n}=\frac{\sqrt{2k+1}}n\mathbf 1_{k<n}.
\tag{2}
\]

则未滤波 Lehmer 核满足 \(K_N=R_N^{\mathsf T}R_N\)，其中第一行和第一列自动为零。

置 \(T_N:=R_ND_N^{-1}\)。直接代入 (1)--(2)，对 \(1\le k<N\)、\(1\le d\le N\) 得到

\[
\boxed{
(T_N)_{k,d}
=\frac{\sqrt{2k+1}}d
\sum_{j=\lfloor k/d\rfloor+1}^{\lfloor N/d\rfloor}
\frac{\mu(j)}j.}
\tag{3}
\]

因此每一列不是抽象的除数向量，而是一个缩放后的 Möbius 调和尾。

## 2. 共轭后的 Gram 恒等式

由定义有精确的有限维恒等式

\[
\boxed{
D_N^{-\mathsf T}K_ND_N^{-1}=T_N^{\mathsf T}T_N.}
\tag{4}
\]

写 \(A_q(Y):=\sum_{q<n\le Y}\mu(n)/n\)。则 (3) 可写为

\[
(T_N)_{k,d}
=\frac{\sqrt{2k+1}}d\,
A_{\lfloor k/d\rfloor}\!\left(\left\lfloor\frac Nd\right\rfloor\right).
\tag{5}
\]

故共轭 Gram 的条目是显式的跨尺度相关：

\[
\boxed{
\begin{aligned}
\bigl(D_N^{-\mathsf T}K_ND_N^{-1}\bigr)_{d,e}
&=\frac1{de}\sum_{k=1}^{N-1}(2k+1)\\
&\quad\cdot
A_{\lfloor k/d\rfloor}\!\left(\left\lfloor\frac Nd\right\rfloor\right)
A_{\lfloor k/e\rfloor}\!\left(\left\lfloor\frac Ne\right\rfloor\right).
\end{aligned}}
\tag{6}
\]

这里两个 \(A\) 的乘积保留了不同除数尺度之间的 signed 相关；逐项取绝对值会丢掉正是需要的抵消。

## 3. 第一列恢复原始 Lehmer 能量

由 \(D_N\mu_N=e_1\)，有 \(\mu_N=D_N^{-1}e_1\)。因此

\[
\begin{aligned}
\frac{I_N}{\pi}
&=\mu_N^{\mathsf T}K_N\mu_N\\
&=e_1^{\mathsf T}
\bigl(D_N^{-\mathsf T}K_ND_N^{-1}\bigr)e_1\\
&=\sum_{k=1}^{N-1}(2k+1)A_k(N)^2.
\end{aligned}
\tag{7}
\]

这正是 note 442 的对角尾能量恒等式；在共轭坐标中，它只是 \(T_N\) 第一列的平方范数。

更一般地，第 \(d\) 列满足

\[
\|T_Ne_d\|_2^2
=\frac1{d^2}\sum_{k=1}^{N-1}(2k+1)
\left|
A_{\lfloor k/d\rfloor}\!\left(\left\lfloor\frac Nd\right\rfloor\right)
\right|^2.
\tag{8}
\]

所以除数共轭没有制造新的正性；它把问题改写成所有缩放调和尾的 Gram 矩阵。

## 4. 最薄的非对角算术命题

记 \(G_N=D_N^{-\mathsf T}K_ND_N^{-1}\)。目标量是第一列的平方范数
\(G_{N,11}=I_N/\pi\)，而不是一个可以由正 Schur 补自动上界的量。事实上，
\(G_N\succeq0\) 只给出
\[
G_{N,11}\ge
G_{N,1,2:N}\,G_{N,2:N,2:N}^{\dagger}\,G_{N,2:N,1},
\]
方向与 RH 所需的上界相反。因此真正需要的是一个保留符号的跨列恒等式或消去公式，把第一列表示为缩放列的受控组合加上小余项：
\[
T_Ne_1=\sum_{d\ge2}\alpha_{N,d}\,T_Ne_d+\rho_N,
\qquad \|\rho_N\|_2^2\ll_\varepsilon N^{1+\varepsilon}.
\]
这才可能把 (7) 转成平方根级估计。但 (6) 表明，任何这样的表示都不是有限深度的局部问题，而是同时包含

\[
A_k(N)\,
A_{\lfloor k/d\rfloor}\!\left(\left\lfloor\frac Nd\right\rfloor\right)
\]

的全尺度相关。note 444 的对数下界只处理第一列的正差分；它并不估计这些非对角列。

因此当前真正的新接口可以精确写成：

> 对矩阵 \(T_N\) 的第一列与缩放列，构造保留 Möbius 符号的统一 signed 消去公式，并控制余项 \(\rho_N\)。

这不是由 \(K_N\succeq0\)、普通 Cauchy 或有限除数支撑自动推出的命题；若其强度达到 \(N^{1+\varepsilon}\)，按 notes 438--440 即为 RH-strength 输入。本 note 只给出精确 intertwiner，不宣称 RH 证明。
