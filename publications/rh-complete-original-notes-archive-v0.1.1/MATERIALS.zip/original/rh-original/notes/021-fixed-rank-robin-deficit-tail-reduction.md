> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Robin deficit 全尾的固定秩归约

日期：2026-08-11。

## 1. 定理

固定

\[
0<a_0\le a\le a_1,
\qquad b_n=n+\frac14,
\qquad \theta_j=\left(j+\frac12\right)\pi.
\]

令偶 Robin 频率 \(z_{n,j}=a\mu_{n,j}\) 为

\[
z_{n,j}\tan z_{n,j}=2ab_n,
\qquad j\pi<z_{n,j}<\theta_j,
\]

并令 \(g_{n,j}\) 为 \(L^2(0,a)\) 中归一化的 \(\cos(z_{n,j}x/a)\)。对整数
\(m\ge1,s\ge0\)，定义

\[
V_{m,s}(a)=\operatorname{span}\left\{
x^k\cos\left(\frac{\theta_jx}{a}+\frac{k\pi}{2}\right):
0\le j<m,\ 0\le k\le s
\right\},
\]

并以 \(P=P_{m,s}(a)\) 表示其正交投影。则

\[
\dim V_{m,s}(a)\le m(s+1).
\]

若

\[
d_{n,j}=\ell_n(\mu_{n,m})-\ell_n(\mu_{n,j}),
\qquad
\ell_n(\mu)=\frac{\mu^2}{b_n(4b_n^2+\mu^2)},
\]

以及

\[
Q_{K,m}=\sum_{n\ge K}\sum_{j<m}
d_{n,j}|g_{n,j}\rangle\langle g_{n,j}|,
\]

那么对任意 \(\tau>0\)，

\[
\boxed{
Q_{K,m}\preceq
(1+\tau)P Q_{K,m}P
+(1+\tau^{-1})E_{K,m,s}I,}
\]

其中

\[
E_{K,m,s}=O(K^{-2s-4})
\]

且具有下文给出的完全显式上界。因此，固定低段分割点 \(K\) 后，无限 Robin deficit 尾只增加至多
\(m(s+1)\) 个聚合方向；其维数与用于求和尾部的计算截断无关。

## 2. Robin 根与模式余项

写

\[
z_{n,j}=\theta_j-\varepsilon_{n,j}.
\]

由 \(\tan(\theta_j-\varepsilon)=\cot\varepsilon\) 和
\(\cot\varepsilon\le\varepsilon^{-1}\)，

\[
2ab_n=(\theta_j-\varepsilon_{n,j})\cot\varepsilon_{n,j}
\le\frac{\theta_j}{\varepsilon_{n,j}}-1,
\]

故

\[
\boxed{
0<\varepsilon_{n,j}\le\frac{\theta_j}{2ab_n+1}.}
\]

又

\[
\|\cos(z_{n,j}x/a)\|_2^2=a h_{n,j},
\qquad
h_{n,j}=\frac12+\frac{\sin(2z_{n,j})}{4z_{n,j}}.
\]

对 \(\varepsilon_{n,j}\) 作 \(s\) 阶 Taylor 展开；每一展开项都属于 \(V_{m,s}(a)\)。积分余项给出

\[
\boxed{
\|(I-P)g_{n,j}\|_2^2
\le
\frac{\varepsilon_{n,j}^{2s+2}}
{(2s+3)((s+1)!)^2h_{n,j}}.}
\]

令

\[
\underline z_{K,j}=
\theta_j\frac{2(K+1/4)a_0}{2(K+1/4)a_0+1},
\qquad
H_{K,j}=\frac12-\frac1{4\underline z_{K,j}}.
\]

当 \(\underline z_{K,j}>1/2\) 时，\(h_{n,j}\ge H_{K,j}>0\)。同时

\[
0\le d_{n,j}\le
\frac{\theta_m^2}{4a_0^2b_n^3}.
\]

因此

\[
\boxed{
E_{K,m,s}\le
\frac{\theta_m^2}{4a_0^2}
\sum_{j<m}
\frac{\theta_j^{2s+2}}
{(2a_0)^{2s+2}(2s+3)((s+1)!)^2H_{K,j}}
S_{K,2s+5},}
\]

其中

\[
S_{K,q}:=\sum_{n\ge K}(n+\tfrac14)^{-q}
\le(K+\frac14)^{-q}
+\frac{(K+\frac14)^{1-q}}{q-1}.
\]

## 3. 算子归约

令 \(p=Pg_{n,j}\)、\(r=(I-P)g_{n,j}\)。Young 不等式给出

\[
|p+r\rangle\langle p+r|
\preceq
(1+\tau)|p\rangle\langle p|
+(1+\tau^{-1})\|r\|^2I.
\]

乘以 \(d_{n,j}\) 并求和即得定理。另有

\[
D_{K,m}:=\sum_{n\ge K,j<m}d_{n,j}=O(K^{-2}).
\]

因此 Young 交叉代价可取为

\[
E_{K,m,s}+2\sqrt{D_{K,m}E_{K,m,s}}
=O(K^{-s-3}).
\]

在首个 prime band 的端点范围

\[
a_0=\frac25,\qquad a_1=\frac{\log3}{2},\qquad m=4,
\]

上述完全初等上界给出

\[
(s,K)=(3,80)
\Longrightarrow
\sqrt{D^{\rm up}_{K,m}E^{\rm up}_{K,m,s}}
<4.17\times10^{-7}.
\]

故一个稳健的后续证书接口是：显式处理前 \(80\) 个 Yukawa summand，并以 \(16\) 个固定聚合方向
控制完整无穷尾。

## 4. 推论与边界

这一归约消除了逐个增加 Yukawa summand 时 Schur 维数线性增长的障碍。它把
\(a=\frac12\log3\) 的偶扇区正性问题降为：

1. 有限个低段 Robin deficit；
2. 至多 \(m(s+1)\) 维的聚合尾矩阵；
3. 显式标量余项；
4. 精确的 \(n=2\) collar reflection 与正极点秩一项。

本 note 本身不证明端点算子为正；最后的固定维 Schur/Feshbach 正定性仍须用有向区间认证。

一个直接的替代方案已经被严格关闭：在 \(a=\frac12\log3\) 取 collar 两侧各次数小于 \(10\) 的
分段 Legendre 空间，\(\dim P=20\)，并以 Hilbert--Schmidt 范数控制 \(QKQ\)。Arb 给出

\[
QAQ\succeq0.83812973908184\,Q,
\]

但用标量界 \((QAQ)^{-1}\preceq0.83812973908184^{-1}Q\) 所得 Feshbach 下矩阵满足

\[
\lambda_{\min}(S_P)
\in[-0.001518753466,-0.001518753454].
\]

这不是原算子的负方向，而是证明该标量 resolvent 扣除过粗。因此后续应使用本 note 的 Robin-tail
聚合或多层、算子值的 \(Q\)-resolvent；继续只调整 \(r\le20\) 的分段多项式空间或 Yukawa 截断
不能消除这一损失。
