> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 截断 residual 的双曲线调和形式与 rank-one 边界块

日期：2026-08-17。

note 458 把截断倍数链 residual 写成大除数变量的 incomplete divisor sum。本 note
用 $n=ab$ 的双曲线换元，把它进一步改写成短 Möbius reciprocal sum；这使
completion 缺口直接显露为一个 reciprocal-Mertens 型调和变换。

## 1. 精确双曲线换元

沿用

\[
M=\left\lfloor\frac Nd\right\rfloor,
\qquad q=\left\lfloor\frac kd\right\rfloor,
\qquad 1\le A\le M,
\qquad B=\left\lfloor\frac{M}{A+1}\right\rfloor,
\]

以及 note 458 的 $\eta_A(n)=\sum_{a\mid n,\ a>A}\mu(n/a)$。定义
$H_r=\sum_{j=1}^{r}1/j$，$H_0=0$。将 $n=ab$ 且 $a>A$ 代入，有

\[
\begin{aligned}
\sum_{\substack{\max(A,q)<n\le M}}\frac{\eta_A(n)}n
&=\sum_{b=1}^{B}\frac{\mu(b)}b
\sum_{a=\max(A,\lfloor q/b\rfloor)+1}^{\lfloor M/b\rfloor}\frac1a\\
&=\boxed{\sum_{b=1}^{B}\frac{\mu(b)}b
\left(H_{\lfloor M/b\rfloor}-H_{\max(A,\lfloor q/b\rfloor)}\right).}
\end{aligned}
\tag{1}
\]

空和按零处理。OMEN 用精确有理数核验了 $N=20,31,64$ 的全部 $(d,A,k)$。

## 2. 小行号上的 rank-one 边界块

当 $k<d$ 时 $q=0$，所以式 (1) 与 $k$ 无关。令

\[
Z_{M,A}:=\sum_{b=1}^{B}\frac{\mu(b)}b
\left(H_{\lfloor M/b\rfloor}-H_A\right).
\tag{2}
\]

则截断 residual $\mathcal R_{d,A}=R_Ne_d-T_NC_{d,A}$ 满足

\[
(\mathcal R_{d,A})_k=\frac{\sqrt{2k+1}}d Z_{M,A},
\qquad 1\le k<d.
\tag{3}
\]

因此有精确下界

\[
\boxed{
\|\mathcal R_{d,A}\|_2^2
\ge \frac{d^2-1}{d^2}\,Z_{M,A}^2.
}
\tag{4}
\]

这不是估计常数造成的损失：它来自 residual 在 $k<d$ 上的完整 rank-one
边界块。

## 3. 算术含义

当 $A$ 取平方根尺度时，$B\asymp\sqrt M$，式 (2) 是长度约
$\sqrt M$ 的 Möbius reciprocal 调和变换。若要让截断 completion residual 达到
平方根级，至少必须统一控制 $Z_{M,A}$ 及其 $q>0$ 的变参数版本；普通正性、
逐项 Cauchy 或只看大除数尾都不能消除式 (4) 的 rank-one 贡献。

因此，completion 缺口现在可分成一个显式 reciprocal-Mertens 边界门和其余
非零 $q$ signed 相关。该分解进一步定位了 RH-strength 输入，但不宣称 RH 证明。
