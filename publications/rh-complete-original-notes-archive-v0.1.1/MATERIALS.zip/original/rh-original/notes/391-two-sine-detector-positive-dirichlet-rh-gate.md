> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 用二正弦 universal detector 构造正系数 RH Dirichlet 门

沿用 note 086 的二正弦行列式 \(D(s)\)。该 note 的严格结果是
\[
D(s)\ne0,\qquad \frac12\le\operatorname{Re}s\le1,\ s\ne1.
\]
定义实偶频谱权
\[
w_*(\xi):=
e^{-\xi^2}\left|D\!\left(\frac12+i\xi\right)\right|^2.
\]
于是 \(w_*\) 连续、严格正、偶且可积。令 \(g_*\) 为其 Fourier 逆变换，
并定义
\[
H_X^*=\sum_{a,b\mid X}\mu(a)\mu(b)\,
g_*\!\left(\log\frac{X}{ab}\right),
\qquad
a_X:=\mu(X)H_X^*,
\]
其中 X 遍历平方自由整数。

## 1. 正系数与 Euler 表示

由 note 177 的 Möbius parity 恒等式，
\[
a_X=
\frac1{2\pi}\int_{\mathbb R}w_*(\xi)
\left|\sum_{a\mid X}\mu(a)a^{i\xi}\right|^2d\xi
\ge0.
\]
因此
\[
\mathscr D_*(s):=
\sum_{X\ {\rm squarefree}}a_X X^{-s}
\]
在 \(\operatorname{Re}s>1\) 收敛，并由 note 389 得到
\[
\mathscr D_*(s)
=
\frac1{2\pi}\int_{\mathbb R}
w_*(\xi)\,
\frac{\zeta(s)^2}
{\zeta(s-i\xi)\zeta(s+i\xi)}
\,\mathscr R(s,\xi)\,d\xi,
\tag{1}
\]
其中 \(\mathscr R\) 是 \(\operatorname{Re}s>\frac12\) 的绝对收敛 Euler 修正，
且在实轴 \(s=\sigma>\frac12\) 上严格为正。

## 2. 离线零点产生不可消去的实轴奇性

设 \(\rho=\beta+i\gamma\) 是 ζ 的零点，\(\beta>\frac12\)，重数为 m。
由于 note 086 在整个闭带上给出 \(D(s)\ne0\)（除 \(s=1\) 外），且离线零点
不可能是区间 \((1/2,1)\) 内的实零点，故
\(D(1/2+i\gamma)\ne0\)，从而 \(w_*(\gamma)>0\)。在
\[
(s,\xi)=(\beta,\gamma)
\]
附近，
\[
\zeta(s+i\xi)
=\zeta^{(m)}(\rho)\frac{(s-\beta+i(\xi-\gamma))^m}{m!}
+\cdots,
\]
而共轭因子给出相反符号的线性项。故 (1) 的局部积分含有
\[
C\int_{-\delta}^{\delta}
\frac{du}
{\bigl((s-\beta)^2+u^2\bigr)^m},
\qquad C\ne0,
\]
沿实轴 \(s\downarrow\beta\) 取局部主部，可写成非零常数乘
\((s-\beta)^{1-2m}\) 的奇性（当 \(m=1\) 时为简单极点）。
\(\mathscr R\) 在该实轴点严格正，不能抵消此奇性；\(\zeta(s)^2\)
在 \(\beta\in(\frac12,1)\) 也不提供抵消。

因此，只要 \(\mathscr D_*\) 能解析延拓到
\(\operatorname{Re}s>\frac12\)（允许 \(s=1\) 的已知极点），就不可能存在
\(\beta>\frac12\) 的 ζ 零点。

## 3. RH 下的反向解析性

若 RH 成立，则在任意闭子带
\(\operatorname{Re}s\ge\frac12+\delta\) 内，
\(\zeta(s\pm i\xi)\) 无零点；标准 reciprocal-zeta 多项式界与
\(w_*(\xi)\) 的 Gaussian 衰减保证 (1) 在该子带局部一致收敛。
所以 RH 给出 \(\mathscr D_*\) 在 \(\operatorname{Re}s>\frac12\) 的亚纯延拓，
其内部唯一的主极点来自 \(s=1\)。

由此得到一个明确的等价门：
\[
\boxed{
\mathrm{RH}
\Longleftrightarrow
\mathscr D_*(s)\text{ 可亚纯延拓至 }\operatorname{Re}s>\frac12
\text{ 且无 }s=1\text{ 之外的极点}.
}
\]

## 结论

该构造把 note 086 的 finite universal detector 转化为一个单一、正系数、
squarefree Dirichlet 门，并保证每个可能的离线零点频率都被看见。
它没有证明 RH：真正未解的是证明这个正系数级数具有上述半平面解析延拓；
这仍等价于全尺度 Möbius signed cancellation。
