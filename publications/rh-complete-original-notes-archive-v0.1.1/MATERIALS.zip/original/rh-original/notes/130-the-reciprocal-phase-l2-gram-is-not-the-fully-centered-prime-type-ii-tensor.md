> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Reciprocal-phase \(L^2\) Gram 不是 fully-centered prime Type-II tensor

日期：2026-08-14。

依赖：[note 128](128-the-mean-zero-rh-remainder-is-one-reciprocal-phase-field-with-square-jumps.md)、
[critical-line note 178](../units/critical-line-proportion/notes/178-continuum-subtraction-reduces-the-quartic-gate-to-the-fully-centered-word.md)、
[critical-line note 180](../units/critical-line-proportion/notes/180-the-fully-centered-ordered-form-factor-theorem-is-the-final-arithmetic-hinge.md)。

证据等级：精确平滑 Gram 展开与变量、measure、带宽逐项核对。

本文判断 note 128 的 reciprocal-phase 场作 dyadic \(L^2\) 后，是否就是临界线比例
路线的 fully-centered ordered \(II^4\) tensor。答案是否定的。

固定 \(z\)，定义

\[
G_z(x)=\sum_{n\ge1}\frac1{n^4}
\sum_{a,b\le z}(ab)^3\mu(a)\mu(b)e^{2\pi i nx/(ab)}.
\tag{1}
\]

令 \(w\) 为实光滑窗，并取 Fourier 约定

\[
\widehat w(\xi)=\int_{\mathbb R}w(u)e^{2\pi i u\xi}\,du.
\tag{2}
\]

则对任意中心 \(X\) 与窗长 \(W>0\)，

\[
\boxed{
\begin{aligned}
\int_{\mathbb R}w(u)|G_z(X+Wu)|^2\,du
={}&\sum_{\substack{n,m\ge1\\a,b,c,d\le z}}
\frac{(abcd)^3\mu(a)\mu(b)\mu(c)\mu(d)}{n^4m^4}\\
&\times
e^{2\pi iX(n/(ab)-m/(cd))}
\widehat w\!\left(W\left(\frac n{ab}-\frac m{cd}\right)\right).
\end{aligned}}
\tag{3}
\]

若

\[
\beta_z(r)=\sum_{\substack{ab=r\\a,b\le z}}\mu(a)\mu(b),
\tag{4}
\]

则 (3) 等价于

\[
\sum_{n,m,r,s}
\frac{r^3s^3\beta_z(r)\beta_z(s)}{n^4m^4}
e^{2\pi iX(n/r-m/s)}
\widehat w\!\left(W(n/r-m/s)\right).
\tag{5}
\]

所以其 near-diagonal 几何是

\[
ns-mr\approx0.
\tag{6}
\]

若 \(r,s\asymp R\)，有效带宽为

\[
\boxed{|ns-mr|\lesssim H_{\rm eff}:=\frac{R^2}{W}.}
\tag{7}
\]

这与 critical-line notes 178--180 的对象有三处首要失配。

第一，measure 不同。式 (3) 的四槽系数是

\[
\mu(a)\mu(b)\mu(c)\mu(d),
\tag{8}
\]

而 fully-centered word 使用

\[
(d\mu_\Lambda-d\rho_{\rm PNT})^{\otimes4}.
\tag{9}
\]

当前“mean-zero”只删除 Bernoulli Fourier 的零模；它不是对每个 prime carrier
作 continuum subtraction。

第二，carrier 不同。式 (3) 的核是 reciprocal determinant

\[
ncd-mab,
\tag{10}
\]

且 \(n,m\) 是 Bernoulli Fourier modes。B 线保留的是单一 common-height 下的
ordered \(+-+-\) carrier 与

\[
ad-pb.
\tag{11}
\]

没有变量替换同时保持四个原子槽、ordered orientation 与 (9)。

第三，带宽制度不同。当前 detector 的 dyadic 制度中

\[
R\asymp W\asymp x,
\tag{12}
\]

所以

\[
H_{\rm eff}\asymp R.
\tag{13}
\]

若把底层 \(a,b,c,d\) 与 B 线的 prime 尺度 \(X_B\) 对齐，则
\(R\asymp x\asymp X_B^2\)，当前带宽为

\[
H_{\rm eff}\asymp X_B^2.
\tag{14}
\]

B 线的承重 determinant 带宽却是

\[
H_B=X_B^{998/999+o(1)}.
\tag{15}
\]

由 (7)，要强行达到 (15) 需

\[
W\asymp\frac{R^2}{H_B}
=X_B^{\,4-998/999+o(1)}
=X_B^{3.001\ldots},
\tag{16}
\]

远大于合法 detector 中心尺度 \(x\asymp X_B^2\)。所以 dyadic 窗不能产生 B 的
窄 determinant strip。

此外，RH 门控制的是 note 128 中

\[
x^{-3}(D-3)(D-4)G_z,
\tag{17}
\]

而非裸 \(|G_z|^2\)。对实部取平方还同时产生
\(n/r-m/s\) 与 \(n/r+m/s\) 两种 orientation；这也不是 note 180 的单一 ordered
word。

因此：

\[
\boxed{
\text{两者共享四序列 product-difference 几何，但 measure centering、
ordered carrier 与带宽三者均不 intertwine}.}
\tag{18}
\]

critical-line 的 fully-centered theorem 即使成立，也不能直接代入 (3) 证明 RH；
反向亦然。若未来要桥接，最小新增命题必须显式给出从 Möbius convolution measure
到 \(\Lambda-\rho\) 的四槽变换，并同时把全宽 \(H_{\rm eff}\asymp X_B^2\) 压到
\(H_B=X_B^{998/999}\)。当前没有这样的恒等式。这不是 RH 的证明。
