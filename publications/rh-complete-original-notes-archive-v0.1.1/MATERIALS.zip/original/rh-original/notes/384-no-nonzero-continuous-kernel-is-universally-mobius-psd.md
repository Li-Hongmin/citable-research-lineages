> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 不存在对所有平方自由尺度都 Möbius-PSD 的非零连续紧支撑核

## 定理

设 \(\phi:[0,\infty)\to\mathbb R\) 连续，满足
\[
\phi(0)=0,\qquad \phi(u)=0\quad(u\ge1).
\]
对平方自由 \(X\) 定义完整 reciprocal Möbius 二次型
\[
Q_\phi(X):=
\sum_{a,b\mid X}\mu(a)\mu(b)\phi(ab/X).
\tag{1}
\]
若
\[
Q_\phi(X)\ge0
\qquad\text{对所有平方自由 }X,
\tag{2}
\]
则
\[
\boxed{\phi\equiv0.}
\tag{3}
\]
因此任何非零连续紧支撑核都必在某个平方自由尺度上产生负的实际
Möbius reciprocal 门；这不要求预先假设 \(\phi\ge0\)。

## 第一步：两素数尺度强迫点态非负

任取 \(u\in(0,1)\)。由素数定理，可取互异素数 \(r_j<q_j\)，使
\[
\frac{r_j}{q_j}\longrightarrow u,\qquad r_j,q_j\longrightarrow\infty.
\]
令 \(X_j=r_jq_j\)。逐项展开四个除数 \(1,r_j,q_j,r_jq_j\)，并用
\(\phi(1)=0\) 及 \(\phi(v)=0\)（\(v\ge1\)），得到
\[
Q_\phi(X_j)
=\phi\!\left(\frac1{r_jq_j}\right)
-2\phi\!\left(\frac1{q_j}\right)
-2\phi\!\left(\frac1{r_j}\right)
+\phi\!\left(\frac{r_j}{q_j}\right).
\tag{4}
\]
连续性和 \(\phi(0)=0\) 给出
\[
Q_\phi(X_j)\longrightarrow\phi(u).
\tag{5}
\]
假设 (2) 遂推出 \(\phi(u)\ge0\)。因 \(u\) 任意，
\[
\phi\ge0\quad\text{于 }(0,1).
\tag{6}
\]

## 第二步：超分离尺度产生矛盾

若 \(\phi\not\equiv0\)，则由 (6) 存在 \(u_0\in(0,1)\) 使
\(\phi(u_0)>0\)。note 383 已证明：对每个固定奇数 \(k\ge1\)，可选取
\[
X_j=r_jq_jY_j,
\]
其中 \(r_j/q_j\to u_0\)，\(Y_j\) 是与 \(r_jq_j\) 互素的 \(k\) 个
超分离奇素数之积，使实际完整 Möbius 向量满足
\[
Q_\phi(X_j)\longrightarrow -\,2^k\phi(u_0)<0.
\tag{7}
\]
这与 (2) 矛盾，故只能有 \(\phi\equiv0\)。

## 研究含义

定理把“全局 Möbius-PSD”路线从正核扩大到任意连续紧支撑核：

* 两素数尺度先把所有局部值 \(\phi(u)\) 强迫到非负锥；
* 超分离平方自由尺度再把任何非零非负值反射成负的 Möbius parity 门。

所以成功的 RH 算术桥不能是一个固定连续紧支撑核在所有平方自由尺度上
逐点/逐尺度正化；它必须保留尺度间 signed cancellation、非局部
reflection，或使用不固定于单一 reciprocal kernel 的完整 Weil 结构。

本定理不证明 RH；它是对 universal Möbius-PSD 方案的全称 no-go。
