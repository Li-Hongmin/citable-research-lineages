> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Selberg 渐消 Möbius 逼近的仿射首壳 RH 判据

日期与检索截止：2026-08-12。

依赖：[note 063](063-baez-duarte-tail-mertens-shell-localization.md)。

## 1. 弄清问题

Báez--Duarte 记载了 Conrey--Myerson 所考虑的 Selberg mollification

\[
\lambda_{k,N}:=\mu(k)\left(1-\frac{\log k}{\log N}\right),
\qquad
S_N(x):=\sum_{k\le N}\lambda_{k,N}\rho_k(x),
\qquad
\rho_k(x):=\left\{\frac1{kx}\right\}.
\tag{1}
\]

Bettin--Conrey--Farmer 随后证明：同一 Dirichlet polynomial

\[
V_N(s)=\sum_{k\le N}\frac{\lambda_{k,N}}{k^s}
\tag{2}
\]

在 RH 加一个 \(\zeta'(\rho)^{-1}\) 矩条件下达到 Nyman--Beurling 最优渐近。令

\[
r_N:=\chi_{(0,1)}+S_N,
\qquad
\mathcal E_N^{\rm Sel}
:=\int_{1/(2N)}^{1/N}|r_N(x)|^2\,dx .
\tag{3}
\]

本 note 只问一个原子问题：

\[
\boxed{\mathcal E_N^{\rm Sel}\longrightarrow0\quad\Longrightarrow\quad\mathrm{RH}\ ?}
\tag{4}
\]

```mermaid
flowchart LR
  A["Selberg 权重 λ(k,N)"] --> B["首倒数壳 y∈[N,2N)"]
  B --> C["常数 + 线性 + M,J,Ψ"]
  C --> D["W(0)=W(1)=0"]
  D --> E["Mellin 双极点消去"]
  E --> F["离线零 β>1/2 强制壳能量发散子列"]
  F --> G["首壳趋零 ⇒ RH"]
```

## 2. 拟定计划

记

\[
M(x):=\sum_{n\le x}\mu(n),
\qquad
J(x):=\sum_{n\le x}\mu(n)\log n,
\qquad
\Psi(x):=\sum_{n\le x}\Lambda(n),
\tag{5}
\]

以及

\[
A_N:=\sum_{k\le N}\frac{\lambda_{k,N}}k.
\tag{6}
\]

Descartes 分解为

\[
(4)
\Leftarrow
\begin{cases}
\text{精确首壳公式},\\
\text{消去首壳的仿射干扰},\\
\text{每个 }\zeta\text{-零点在剩余 Mellin 像中留下极点},\\
\text{极点 }\Rightarrow\text{ 壳能量下界}.
\end{cases}
\tag{7}
\]

## 3. 实现计划

### 3.1 精确仿射首壳

**定理 1（Selberg 首壳恒等式）。** 设 \(N\ge2\)。若

\[
N\le y<2N,
\qquad m:=\lfloor y\rfloor,
\tag{8}
\]

则

\[
\boxed{
r_N(1/y)
=A_Ny+M(m)-M(N)
-\frac{\Psi(m)+J(m)-J(N)}{\log N}.
}
\tag{9}
\]

因此，若

\[
b_N(m):=M(m)-M(N)
-\frac{\Psi(m)+J(m)-J(N)}{\log N},
\tag{10}
\]

则

\[
\boxed{
\mathcal E_N^{\rm Sel}
=\sum_{m=N}^{2N-1}
\left[
A_N^2
+2A_Nb_N(m)\log\!\left(1+\frac1m\right)
+\frac{b_N(m)^2}{m(m+1)}
\right].
}
\tag{11}
\]

**证明。** 由 \(\rho_k(1/y)=y/k-\lfloor y/k\rfloor\)，

\[
r_N(1/y)=1+A_Ny-
\sum_{k\le N}\lambda_{k,N}\left\lfloor\frac mk\right\rfloor.
\tag{12}
\]

在 \(N\le m<2N\) 上，

\[
\sum_{k\le N}\mu(k)\left\lfloor\frac mk\right\rfloor
=1-M(m)+M(N).
\tag{13}
\]

另一方面，Dirichlet convolution 给出

\[
\sum_{d\mid n}\mu(d)\log d=-\Lambda(n),
\tag{14}
\]

故

\[
\sum_{k\le N}\mu(k)\log k
\left\lfloor\frac mk\right\rfloor
=-\Psi(m)-J(m)+J(N).
\tag{15}
\]

代入 (12) 得 (9)。最后令 \(y=x^{-1}\)，逐个
\([m,m+1)\) 积分

\[
\int_m^{m+1}\left|A_N+\frac{b_N(m)}y\right|^2dy
\tag{16}
\]

即得 (11)。\(\square\)

### 3.2 为什么不能强制边界消去

一般有

\[
\sum_{k\le N}\frac{\lambda_{k,N}}k=A_N\ne0.
\tag{17}
\]

把 \(-NA_N\rho_N\) 加到 \(S_N\) 虽可令系数满足 Beurling cancellation，却把
(9) 中的 \(A_Ny\) 换成 \(NA_N\)。历史权重的主抵消是

\[
A_Ny\sim\frac y{\log N}
\quad\leftrightarrow\quad
\frac{\Psi(y)}{\log N}\sim\frac y{\log N}.
\tag{18}
\]

边界修正会在 \(y=tN\) 留下约 \((1-t)N/\log N\) 的伪主项。因此必须保留原始
Selberg 逼近；应消去的是**测试泛函中的仿射干扰**，不是逼近本身的系数。

更定量地，经典加权 Möbius 极限给出

\[
(\log N)A_N
=\sum_{k\le N}\frac{\mu(k)}k\log\frac Nk\longrightarrow1.
\tag{19}
\]

而 \(\rho_N(x)=\rho_1(Nx)\)，故

\[
\|NA_N\rho_N\|_2
=\sqrt N\,|A_N|\,\|\rho_1\|_2
\asymp\frac{\sqrt N}{\log N}\longrightarrow\infty.
\tag{20}
\]

该修正甚至不是 \(L^2\) 小扰动。

### 3.3 两个矩消去仿射干扰

固定任一非平凡零点

\[
\rho=\beta+i\gamma,
\qquad \zeta(\rho)=0,
\tag{21}
\]

并取复值 \(w\in C_c^\infty(1,2)\)。令

\[
W(s):=\int_1^2w(t)t^s\,dt.
\tag{22}
\]

可选择 \(w\) 使

\[
\boxed{
W(0)=W(1)=W(\rho)=0,
\qquad W'(\rho)\ne0.
}
\tag{23}
\]

确实，\(1,t,t^\rho,t^\rho\log t\) 在 \((1,2)\) 上线性无关；故前三个积分泛函的
公共核不包含第四个积分泛函。

前两个矩给出

\[
\int_1^2 w(t)\,dt=0,
\qquad
\int_1^2 tw(t)\,dt=0.
\tag{24}
\]

于是 (9) 中的壳常数和 \(NA_Nt\) 同时消失。

### 3.4 Mellin 极点只降一阶，不消失

定义

\[
\begin{aligned}
\mathcal M_w(X)&:=\int_1^2M(Xt)w(t)\,dt,\\
\mathcal B_w(X)&:=\int_1^2[J(Xt)+\Psi(Xt)]w(t)\,dt,\\
R_w(X)&:=\log X\,\mathcal M_w(X)-\mathcal B_w(X).
\end{aligned}
\tag{25}
\]

对 \(\Re s>1\)，

\[
\begin{aligned}
\int_1^\infty M(x)x^{-s-1}dx&=\frac1{s\zeta(s)},\\
\int_1^\infty J(x)x^{-s-1}dx&=\frac{\zeta'(s)}{s\zeta(s)^2},\\
\int_1^\infty \Psi(x)x^{-s-1}dx&=-\frac{\zeta'(s)}{s\zeta(s)}.
\end{aligned}
\tag{26}
\]

缩放 \(x=Xt\) 只产生来自 \(1\le x\le t\le2\) 的整函数修正。因此

\[
\begin{aligned}
\int_1^\infty \mathcal M_w(X)X^{-s-1}dX
&=\frac{W(s)}{s\zeta(s)}-H_M(s),\\
\int_1^\infty \mathcal B_w(X)X^{-s-1}dX
&=W(s)\left[
\frac{\zeta'(s)}{s\zeta(s)^2}
-\frac{\zeta'(s)}{s\zeta(s)}
\right]-H_B(s),
\end{aligned}
\tag{27}
\]

其中 \(H_M,H_B\) 为整函数。利用

\[
\mathcal M[\log X\,F(X)](s)
=-\frac d{ds}\mathcal M[F](s),
\tag{28}
\]

得到

\[
\boxed{
\int_1^\infty R_w(X)X^{-s-1}dX
=-\frac{W'(s)}{s\zeta(s)}
+\frac{W(s)}{s^2\zeta(s)}
+\frac{W(s)\zeta'(s)}{s\zeta(s)}
+H_R(s),
}
\tag{29}
\]

其中 \(H_R\) 整。这里

\[
\frac{W\zeta'}{s\zeta^2}
-\frac{W\zeta'}{s\zeta^2}=0
\tag{30}
\]

是关键的最高阶极点消去。

设 \(\rho\) 是 \(\zeta\) 的 \(q\) 重零点。由 (23)，(29) 在 \(\rho\) 的最高阶项为

\[
-\frac{W'(\rho)}{\rho a_\rho}(s-\rho)^{-q},
\qquad
\zeta(s)=a_\rho(s-\rho)^q+O((s-\rho)^{q+1}),
\tag{31}
\]

故该极点仍为严格的 \(q\) 阶极点。

### 3.5 极点强制首壳能量下界

**定理 2（离线零的首壳放大）。** 若 \(\rho\) 是 \(\zeta\) 的非平凡零点、
\(\rho=\beta+i\gamma\)，则存在 \(c_\rho>0\) 和无穷整数序列
\(N_j\to\infty\)，使

\[
\boxed{
\mathcal E_{N_j}^{\rm Sel}
\ge c_\rho\frac{N_j^{2\beta-1}}{\log^2N_j}.
}
\tag{32}
\]

**后续加强。** [note 074](074-mellin-poles-force-dyadic-mean-shell-growth.md) 证明极点不能只靠
稀疏点态尖峰承载：若 \(\rho\) 是 \(q\) 重零点，则某个 dyadic 子列满足

\[
\frac1Y\sum_{Y<N\le2Y}\mathcal E_N^{\rm Sel}
\gg_\rho Y^{2\beta-1}(\log Y)^{2q-4}.
\tag{32a}
\]

因此 dyadic 平均只要有次幂增长 \(Y^{o(1)}\) 即已推出 RH；本定理的点态判据不是最薄版本。

**证明。** 若 \(R_w(X)=o(X^\beta)\)，则对 \(\varepsilon\downarrow0\)，

\[
\varepsilon\int_1^\infty
R_w(X)X^{-\rho-\varepsilon-1}dX\longrightarrow0.
\tag{33}
\]

在该假设下，左侧 Mellin 积分于 \(\Re s>\beta\) 全纯，并由恒等定理等于 (29) 的
亚纯延拓。证明 (33) 只需在固定 \(T\) 分割积分：有限段乘 \(\varepsilon\) 后趋零；在尾部用
\(|R_w(X)|\le\delta X^\beta\)，再令 \(\delta\downarrow0\)。但 (29)--(31) 使 (33) 趋于
非零常数（\(q=1\)）或无界（\(q>1\)），矛盾。因此

\[
R_w(X)\ne o(X^\beta).
\tag{34}
\]

令 \(N\) 为离 \(X\) 最近的整数。对 \(1\le t\le2\)，\(Xt\) 与 \(Nt\) 之间只有
\(O(1)\) 个整数，故

\[
\mathcal M_w(X)-\mathcal M_w(N)=O_w(1),
\qquad
\mathcal B_w(X)-\mathcal B_w(N)=O_w(\log X).
\tag{35}
\]

又 \(\mathcal M_w(N)=O_w(N)\)，所以

\[
R_w(X)-R_w(N)=O_w(\log X)=o(X^\beta).
\tag{36}
\]

于是存在 \(c>0\) 和整数子列使 \(|R_w(N_j)|\ge cN_j^\beta\)。另一方面，(9)、
(24) 给出精确探针恒等式

\[
\int_1^2r_N(1/(Nt))w(t)dt=\frac{R_w(N)}{\log N}.
\tag{37}
\]

变量替换 \(x=(Nt)^{-1}\) 及 Cauchy--Schwarz 给出

\[
\begin{aligned}
\mathcal E_N^{\rm Sel}
&=\frac1N\int_1^2|r_N(1/(Nt))|^2\frac{dt}{t^2},\\
\left|\int_1^2r_N(1/(Nt))w(t)dt\right|^2
&\le
N\mathcal E_N^{\rm Sel}
\int_1^2|w(t)|^2t^2dt.
\end{aligned}
\tag{38}
\]

(32) 随即成立。\(\square\)

**推论 3（仿射首壳 RH 判据）。**

\[
\boxed{
\mathcal E_N^{\rm Sel}\longrightarrow0
\quad\Longrightarrow\quad
\mathrm{RH}.
}
\tag{39}
\]

**证明。** 若 RH 为假，功能方程给出某个零点 \(\beta>1/2\)。由 (32)，

\[
\mathcal E_{N_j}^{\rm Sel}
\gtrsim\frac{N_j^{2\beta-1}}{\log^2N_j}\longrightarrow\infty,
\tag{40}
\]

与 (39) 左侧矛盾。\(\square\)

固定任一已知临界线零点还无条件给出

\[
\boxed{
\limsup_{N\to\infty}
\mathcal E_N^{\rm Sel}\log^2N>0.
}
\tag{41}
\]

与 note 063 的 \(O(1)\) 首壳障碍相比，Selberg taper 精确消去了 Mellin 最高阶极点，
把临界壳底降到了 \(1/\log^2N\) 尺度；离线零仍被多项式因子
\(N^{2\beta-1}\) 放大。

## 4. 直接验算

对 \(2\le N\le100\) 的随机首壳点，(9) 与原始分数部分定义的最大绝对误差为

\[
2.5\times10^{-14}.
\tag{42}
\]

对 \(m\le500\)，(15) 的最大浮点误差为 \(1.2\times10^{-13}\)。分片闭式 (11) 与每个
unit cell 使用 2000 个中点的直接积分在 \(N=5,10,31,100\) 上误差均小于
\(2\times10^{-10}\)。低内存筛法得到：

\[
\begin{array}{c|c|c}
N&\mathcal E_N^{\rm Sel}&\mathcal E_N^{\rm Sel}\log^2N\\ \hline
2^5&6.0666\cdot10^{-3}&7.2868\cdot10^{-2}\\
2^{10}&5.5293\cdot10^{-4}&2.6566\cdot10^{-2}\\
2^{15}&1.8398\cdot10^{-4}&1.9888\cdot10^{-2}\\
2^{19}&9.7910\cdot10^{-5}&1.6982\cdot10^{-2}
\end{array}
\tag{43}
\]

这只是恒等式与尺度的 sanity check，不是 (39) 左侧的证明。

## 5. 回顾与下一证明路线

Mellin--Plancherel 给出

\[
\widehat r_N(s)=\frac{1-\zeta(s)V_N(s)}s,
\tag{44}
\]

所以 (3) 确实是 Bettin--Conrey--Farmer 历史逼近误差的第一个 dyadic 空间片，而非另造的
等价判据。新归约把 RH 压成显式有限量 (11) 的上界：

\[
\boxed{
\sum_{m=N}^{2N-1}
\left[
A_N^2+2A_Nb_N(m)\log(1+m^{-1})
+\frac{b_N(m)^2}{m(m+1)}
\right]=o(1).
}
\tag{45}
\]

等价地，若

\[
D_N(y):=A_Ny+M(\lfloor y\rfloor)-M(N)
-\frac{\Psi(\lfloor y\rfloor)+J(\lfloor y\rfloor)-J(N)}{\log N},
\tag{46}
\]

则只需证明

\[
\boxed{
\int_N^{2N}|D_N(y)|^2dy=o(N^2).
}
\tag{47}
\]

其离散增量为

\[
D_N(m+1)-D_N(m)
=A_N+\mu(m+1)\left(1-\frac{\log(m+1)}{\log N}\right)
-\frac{\Lambda(m+1)}{\log N}.
\tag{48}
\]

故下一最简单元不是继续制造等价命题，而是寻找 (48) 的历史均方估计或正型恒等式，直接证明
(47)。RH 尚未由本 note 证明；RH 单独是否推出 (47) 也未在此证明。

## 6. 证据与新判断边界

文献直接支持：

- Selberg approximation (1) 及 Conrey--Myerson 的历史来源：Luis Báez-Duarte,
  *A strengthening of the Nyman--Beurling criterion for the Riemann Hypothesis*,
  [arXiv:math/0202141](https://arxiv.org/abs/math/0202141)。
- 同一权重 (2) 在 RH 与 reciprocal-\(\zeta'\) 矩条件下达到全局 Nyman--Beurling 最优渐近：
  Sandro Bettin, J. Brian Conrey and David W. Farmer,
  *An Optimal Choice of Dirichlet Polynomials for the Nyman--Beurling Criterion*,
  [arXiv:1211.5191](https://arxiv.org/abs/1211.5191),
  [DOI](https://doi.org/10.1134/S0081543813030036)；
  [本地全文](<[unbundled local reference]>)。
- 该权重的现代 Gram-matrix 背景：Werner Ehm,
  *On certain Gram matrices and their associated series*,
  [arXiv:2405.06349](https://arxiv.org/abs/2405.06349)。

本 note 新增定理 1 的仿射首壳闭式、定理 2 的零点定量放大、推论 3 的单壳充分判据和
(41) 的无条件临界壳底。针对检索日所做的 `Selberg approximation + Nyman--Beurling +
local interval/first shell/dyadic/Mertens` 定向检索未发现相同陈述；这只限定本次检索覆盖，
不作绝对首创声明。
