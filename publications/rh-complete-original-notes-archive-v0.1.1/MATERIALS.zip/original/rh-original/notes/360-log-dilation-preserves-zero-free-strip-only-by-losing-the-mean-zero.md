> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 对数尺度伸缩不能同时保留 Mellin 零均值与 RH detector 结构

日期：2026-08-16。

## 伸缩与 Mellin 变换

令 \(V\) 为端点平坦 detector，并定义对数尺度伸缩

\[
 (D_aV)(u):=aV(u^a),\qquad a>0,\quad 0<u<1.
\]

直接代换 \(t=u^a\) 得

\[
 K_{D_aV}(s):=\int_0^1(D_aV)(u)u^{s-1}\,du
 =K_V(s/a).
\tag{1}
\]

对当前层级

\[
 K_V(s)=C\frac{s-1}{D(s)},
\]

其中 \(C\ne0\)，且 \(D\) 在 \(\Re s>0\) 无零点。因此 \(K_V\) 在有限复平面
的唯一零点是 \(s=1\)，而伸缩后的唯一零点变为 \(s=a\)。

## 零均值的精确损失

伸缩后的 periodization 为

\[
 P_{D_aV}(y)=\sum_{n\le y}aV((n/y)^a).
\]

若 \(V\) 具有当前 detector 的端点平坦性，则 Euler--Riemann 求和给出

\[
 P_{D_aV}(y)
 =y\int_0^1aV(u^a)\,du+O_a(1)
 =yK_V(1/a)+O_a(1).
\tag{2}
\]

因而

\[
 K_{D_aV}(1)=K_V(1/a)=0
 \quad\Longleftrightarrow\quad a=1.
\tag{3}
\]

也就是说，任意非平凡纯对数伸缩都会把 periodization 的零均值换成
线性主项 \(yK_V(1/a)\)。这不是小误差；它正是 reciprocal-product
分部求和中原本用来消掉零频主项的条件。

## 与临界带 zero-free 条件的冲突

由于 \(K_{D_aV}(s)=K_V(s/a)\) 的零点为 \(s=a\)：

- \(1/2<a<1\) 时，零点 \(s=a\) 落入临界带，失去 RH detector 的 zero-free
  条件；
- \(0<a\le1/2\) 或 \(a>1\) 时，临界带可保持无零点，但 (3) 表明零均值
  已丢失，(2) 产生线性 periodization 主项；
- \(a=1\) 是唯一同时保留 \(K(1)=0\) 和临界带无零点的纯伸缩。

对当前 orientation，\(a>1\) 还满足 \(1/a<1\)，故 \(K_V(1/a)<0\)，由
(2) 可知 periodization 最终变负，直接排除全半轴正性。\(a<1/2\) 时即使
线性主项为正，正性也只是一个由 \(yK_V(1/a)\) 支配的平凡大尺度事实，不能
提供原 detector 的 RH-sensitive 互补项。

## Jacobian 修正也不能给出可用的窄核

唯一自然的反例修正是加入 Jacobian：

\[
 (\widetilde D_aV)(u):=a\,u^{a-1}V(u^a).
\]

此时

\[
 K_{\widetilde D_aV}(s)
 =K_V\!\left(1+\frac{s-1}{a}\right),
\tag{4}
\]

所以 \(K_{\widetilde D_aV}(1)=K_V(1)=0\)，零均值确实被保留。然而当前
detector 在左端满足 \(V(u)=O(u^2)\)，于是

\[
 \widetilde D_aV(u)=O\!\left(u^{\,3a-1}\right)\qquad(u\downarrow0).
\tag{5}
\]

要保留原 reciprocal-product 估计所用的二阶端点平坦性
\(\widetilde D_aV(u)=O(u^2)\)，(5) 强迫 \(a\ge1\)。而 \(a<1\) 正是把
对数变量拉伸、试图把 Mellin 频率核变窄的参数区间；在该区间，\(s=0\)
附近还可能出现由 \(K_V\) 负极点映来的 Mellin 极点，原有 \(L^1\) 频率
权和 \(P(y)=O(y^{-2})\) 估计不再自动成立。

因此，加入 Jacobian 只能保留零均值，不能同时保留当前能量门所需的端点
平坦性与窄核收益。若再用额外因子修复左端阶数，就不再是纯伸缩，必须
重新证明全半轴 periodization 正性和 Mellin zero-free；现有 detector
层级没有提供这种闭合。

这并不声称已经排除所有 \(a>1\) 的重构 detector；\(a>1\) 保留左端阶数，
但其 periodization 正性必须单独验证。即使对已知的 \(V_{15}\)，最直接的
选择 \(a=2\) 也立即失败：取 \(y=2\)（第二项因 \(V_{15}(1)=0\) 消失），有

\[
 P_{\widetilde D_2V_{15}}(2)
 =V_{15}(1/4)
 =-\frac{7656687}{268435456}<0.
\tag{6}
\]

因此 \(a>1\) 不能被当作保持正性的自动尺度参数；若要利用它，仍需构造
新的 \(V\) 并证明全半轴 periodization 正性。

## 结论

“把 Mellin 核伸缩得更窄，从而降低正能量门”的自然伸缩路线不能自动闭合：
不加 Jacobian 时丢失 \(K(1)=0\)，加 Jacobian 且 \(a<1\) 时丢失二阶端点
平坦性；\(a>1\) 则必须重新承担 periodization 正性。若再加入第二个
detector 或额外因子修复其中一项，就变成新的 signed linear combination；
其 periodization 正性和频率符号必须重新证明，不能由伸缩继承。
