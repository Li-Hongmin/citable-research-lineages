> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 高阶 Jackson 逼近把固定 Möbius 能量推进到 stretched-log 节省

日期：2026-08-15。

本 note 检查 note 200 的高阶逼近升级。结论是：在固定 detector
\(V_{15}\) 的实际正则性范围内，可以严格把
\(N^2\Lambda(N)^{-1/2}\) 改进为 \(N^2e^{-c\Lambda(N)}\)，但指数 \(c>0\)
仍是零自由区常数的某个小倍数；这离 \(N^{1+\varepsilon}\) 仍很远。
关键代价不是“系数数目 \(R^2\)”本身，而是 Chebyshev/Jackson 基函数的离散
总变差，使二维因子化项出现 \(R^4\)；该多项式代价仍可由指数逼近参数吸收。

## 1. 需要的正则性

沿用 note 200 的
\[
 E_N(w)=\int_{\mathbb R}w(t)
 \left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt,\qquad
 K(u)=\frac1{2\pi}\int_{\mathbb R}w(t)e^{itu}\,dt .
\]
假设对某个整数 \(k\ge1\)
\[
 \int_{\mathbb R}(1+|t|^k)w(t)\,dt<\infty .
\tag{1}
\]
则 \(K\in C^k(\mathbb R)\)，并且
\[
 \|K^{(a)}\|_\infty\le\frac1{2\pi}\int |t|^a w(t)\,dt,\qquad 0\le a\le k.
\tag{2}
\]
对 \(d\ge0\) 和 \(x,y\in[1,2]\)，令
\[
 F_d(x,y)=K\!\left(\log(2^{-d}x/y)\right).
\]
链式法则和 \(1\le x,y\le2\) 给出 \(d\) 一致的 \(C^k\) 界
\[
 \max_{a+b\le k}\|\partial_x^a\partial_y^bF_d\|_\infty
 \le C_{k,w}.
\tag{3}
\]

对 note 200 的 \(V_{15}\)，已有
\[
 w(\xi)=|h(\xi)|\ll_\varepsilon
 (1+|\xi|)^{-19/2+\varepsilon}.
\]
故 (1) 至少对 \(k=8\) 成立。注意这里的 \(w=|h|\) 可能在 \(h\) 的零点不光滑，
但 (1) 只涉及 \(w\) 的矩，不需要 \(w\) 本身可微。

## 2. Jackson 多项式及其离散总变差

把 \([1,2]\) 仿射到 \([-1,1]\)，取一维 Jackson 算子 \(J_R\)（或
Chebyshev--Jackson 截断），其标准估计为
\[
 \|f-J_Rf\|_{\infty,[1,2]}
 \le C_k R^{-k}\|f^{(k)}\|_\infty,
\qquad
 \deg J_Rf\le R.
\tag{4}
\]
对 \(F_d\) 先后在两个变量施加 \(J_R\)，得到
\[
 P_{R,d}(x,y)=\sum_{r,s=0}^{R}c_{rs}^{(d)}
 \psi_r(x)\psi_s(y),\qquad
 \psi_r(x)=T_r(2x-3),
\tag{5}
\]
并且
\[
 \|F_d-P_{R,d}\|_\infty\le C_{k,w}R^{-k},
 \qquad
 |c_{rs}^{(d)}|\le C_w
\tag{6}
\]
一致于 \(d\le D\)。后一个界来自 Chebyshev 系数
\(|\widehat F_{rs}|\le4\|F_d\|_\infty\) 与 Jackson 权
\(0\le\lambda_r\le1\)；因此不存在随 \(R\) 指数增长的单项系数。

高阶基函数的代价必须明确保留。由于
\(T_r(\cos\theta)=\cos(r\theta)\)，
\[
 \operatorname{Var}_{[1,2]}(\psi_r)\le 2r+2.
\tag{7}
\]
在任意离散单调采样点列上，离散总变差不超过连续总变差加端点项，
故对 \(I_j=(2^j,2^{j+1}]\)
\[
 \operatorname{Var}_{m\in I_j}
 \psi_r(m/2^j)\le2r+4.
\tag{8}
\]
二维张量共有 \((R+1)^2\) 项，且
\[
 \sum_{r,s\le R}|c_{rs}^{(d)}|(r+1)(s+1)
 \ll_w R^4.
\tag{9}
\]
这正是高阶逼近相对 note 200 中 Bernstein 基的真实增长；不能把总变差
仍错误地记作 \(O(1)\)。

## 3. 近比值块的算术估计

设 \(M(x)=\sum_{n\le x}\mu(n)\ll xe^{-c_0\Lambda(x)}\)。部分求和及 (8) 给出
对 \(2^j\ge N^{1/2}\)
\[
 \left|\sum_{m\in I_j}\mu(m)\psi_r(m/2^j)\right|
 \ll (r+1)\,2^j e^{-c_1\Lambda(N)},
\tag{10}
\]
其中 \(c_1>0\) 只依赖零自由区常数；这里使用
\(\Lambda(2^j)\ge c_\Lambda\Lambda(N)\)。
若 \(2^j<N^{1/2}\)，使用平凡界 \(O(2^j)\)，不引入 \(r\) 因子。

将 (5) 代入每个 \(d\le D\) 的 dyadic block，并使用 (9)，得到
\[
 \sum_{\substack{j,d\\d\le D}}
 \left|\sum_{\substack{m\in I_j\\ n\in I_{j+d}}}
 \mu(m)\mu(n)
 (F_d-P_{R,d})(m/2^j,n/2^{j+d})\right|
 \ll_{k,w}R^{-k}N^2,
\tag{11}
\]
以及所有 Jackson 逼近项的总和
\[
 \ll_{k,w}R^4D
 \left(N^2e^{-c_1\Lambda(N)}
 +N\,2^D\right).
\tag{12}
\]
第二项中的 \(N2^D\) 来自至少一个 dyadic scale 小于
\(N^{1/2}\) 的块；在 (14) 的选择下它是
\(N e^{\beta\Lambda(N)+O(1)}=N^{1+o(1)}\)，仍远小于目标主尺度。
远比值 \(d>D\) 仍由 note 200 的有界核尾给出
\[
 \ll_w N^2\,2^{-D}.
\tag{13}
\]

## 4. 选择逼近阶数

取
\[
 R=\left\lceil e^{\alpha\Lambda(N)}\right\rceil,\qquad
 D=\left\lceil\frac{\beta\Lambda(N)}{\log 2}\right\rceil,\qquad
 \alpha=\frac{c_1}{k+4},\qquad
 \beta\ge\frac{k c_1}{k+4}.
\tag{14}
\]
则 (11)--(12) 的两个主指数分别为
\[
 R^{-k}=e^{-k\alpha\Lambda(N)},\qquad
 R^4e^{-c_1\Lambda(N)}
 =e^{-(c_1-4\alpha)\Lambda(N)},
\]
而这两个指数相等：
\[
 k\alpha=c_1-4\alpha=\frac{k\,c_1}{k+4}.
\]
这里 \(D=O(\Lambda(N))=o(\log N)\)，而 \(R=N^{o(1)}\)；不需要也不能
声称 \(R=o(\log N)\)。吸收 \(D\)、\(N2^D\) 和 (13) 的较慢项后，存在
 \(c_*>0\) 使
\[
\boxed{
 E_N(w)\ll_{w,k}N^2e^{-c_*\Lambda(N)}.
}
\tag{15}
\]
例如在已知 \(k=8\) 的 \(V_{15}\) 情形，可取任意
\(c_*<\frac23c_1\)（留出常数和对数因子的余量）。

## 5. 边界与不能声称的内容

1. 若只知道 note 200 的一阶矩条件 \(k=1\)，普通 Bernstein 的
 \(R^{-1/2}\) 误差和 \(R^4\) 代价也可平衡出某个 stretched-log 节省，
 但高阶 \(k=8\) 才给出上述明确的 \(R^{-8}\) 版本。
2. 这不是 \(N^{1+\varepsilon}\) 级别的二点 Möbius 相关估计：
 \(N^2e^{-c_*\Lambda(N)}=N^{2-o(1)}\)。
3. 逼近项仍使用 Mertens 零自由区估计，且没有制造任何新的
 prime/reflection signed cancellation；因此 (15) 不能推出 RH，也不能关闭
 note 192 的平方根能量门。
