> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Lehmer 共轭矩阵首行迫使除数支持增长或系数变大

日期：2026-08-17。

本 note 给出一个不依赖非对角 Gram 估计的首行下界。它说明：任何试图用
\(d\le N^\alpha\) 的小除数列消去首列的方案，若系数保持有界，就已经在
\(k=1\) 行失败。

## 1. 首行的精确公式

沿用 note 445 的

$$
(T_N)_{k,d}
=\frac{\sqrt{2k+1}}d
\sum_{\lfloor k/d\rfloor<n\le\lfloor N/d\rfloor}\frac{\mu(n)}n.
$$

记 \(S(x)=\sum_{n\le x}\mu(n)/n\)。在 \(k=1\) 时，

$$
(T_Ne_1)_1=\sqrt3\,(S(N)-1),
$$

而对 \(d\ge2\)，

$$
(T_Ne_d)_1=\frac{\sqrt3}{d}\,
S\!\left(\left\lfloor\frac Nd\right\rfloor\right).
\tag{1}
$$

这也直接重现 note 447 的逐行行和恒等式。

## 2. 次线性除数支持的系数下界

固定 \(0<\alpha<1\)，令 \(D\le N^\alpha\)，并取任意只支持在
\(2\le d\le D\) 的系数向量 \(c=(c_d)\)。设

$$
E_\alpha(N):=
\sup_{y\ge N^{1-\alpha}/2}|S(y)|.
$$

由 (1) 和三角不等式，

$$
\left|(T_N(e_1-c))_1\right|
\ge \sqrt3\left(
|1-S(N)|-\frac12E_\alpha(N)\|c\|_1
\right).
\tag{2}
$$

因此，若某个消去方案要求首行误差不超过 \(\sqrt3/4\)，且 \(N\) 足够大使
\(|S(N)|\le1/4\)，则必有

$$
\boxed{
\|c\|_1\ge \frac1{E_\alpha(N)}.
}
\tag{3}
$$

这个结论只使用首行，不需要任何关于非对角列相关的假设。

## 3. 无条件与 RH 下的尺度

经典零点自由区给出

$$
E_\alpha(N)
\le C_\alpha\exp\!\left(
-c_\alpha(\log N)^{3/5}(\log\log N)^{-1/5}
\right),
$$

故无条件地，(3) 至少要求

$$
\|c\|_1
\gg_\alpha
\exp\!\left(
c_\alpha(\log N)^{3/5}(\log\log N)^{-1/5}
\right).
\tag{4}
$$

在 RH 下，标准 \(S(y)\ll_\varepsilon y^{-1/2+\varepsilon}\) 代入 (3) 则给出

$$
\boxed{
\|c\|_1
\gg_{\alpha,\varepsilon}
N^{(1-\alpha)/2-\varepsilon}.
}
\tag{5}
$$

## 4. 对 arithmetic intertwiner 的含义

式 (3)--(5) 排除了一个具体的局部捷径：不能用固定数量、统一有界系数的
小除数列来消去首列。即使允许次线性支持，系数也必须随 \(N\) 增长；在 RH
尺度上，这个增长至少支付一个明确的平方根指数。

因此，任何真正的跨尺度 intertwiner 必须满足至少一个条件：

* 使用 \(d\) 达到接近 \(N\) 的大除数支持；
* 允许系数范数增长并控制其与非对角 signed 相关的共同结构；
* 或引入一个不是列线性消去的全局算术变换。

本 note 是可审计的首行结构性下界，不是 RH 证明；它把“必须跨尺度”提升为
一个量化的必要条件。
