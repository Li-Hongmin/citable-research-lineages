> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正则全比值核也不能与除数算子对易

日期：2026-08-16。

note 335 排除了连续 causal detector 与除数 incidence 的对易性。本 note
把结论扩展到一个更宽的类：即使允许核使用所有比值 \(d/a\)，只要它在
无穷整数半群上具有通常的绝对收敛性和 Mellin 正则性，也不可能与除数
算子对易。因而真正可能的 nonlocal intertwiner 必须保留算术分布奇性或
有限截断边界，不能是一个普通的平滑比值卷积。

## 1. 全比值算子与假设

令 \(W:(0,\infty)\to\mathbb C\) 连续，并定义

\[
 (T_Wx)(a)=\sum_{d\ge1}W(d/a)x(d).
\]

假设以下对象对每个 \(a,b\) 绝对收敛，并且在 \(x\) 落在紧子集时
\(\sum_{c\ge2}W(cx)\) 局部一致收敛：

\[
 \sum_{c\ge1}|W(cb/a)|<\infty,
 \qquad
 S(x):=\sum_{c\ge2}W(cx).
\]

再假设 \(W(t)\to0\) 当 \(t\to\infty\)。这些条件覆盖快速衰减的
连续 Mellin 核；它们只是为了保证以下逐项换序和极限有意义。

令
\[
 (Dx)(n)=\sum_{d\mid n}x(d).
\]
我们考察无限半群上的精确关系 \(T_WD=DT_W\)。

## 2. 素数测试给出 dilation 方程

将等式作用于基向量 \(e_b\)，并取 \(a=p\) 为素数。左边为

\[
 (T_WDe_b)(p)=\sum_{c\ge1}W(cb/p),
\]

右边只有 \(1,p\) 两个除数：

\[
 (DT_We_b)(p)=W(b)+W(b/p).
\]

令 \(x=b/p\)，抵消左边的 \(c=1\) 项，得到

\[
 \boxed{S(x)=W(px)}
 \qquad (x=b/p).
\tag{1}
\]

这里 \(b\) 不需要小于 \(p\)；全比值算子允许任意正整数 \(b\)。

固定任意 \(x_0>0\)，取趋于无穷的素数序列 \(p_j\)，并令
\(b_j\) 为使 \(b_j/p_j\to x_0\) 的整数。由局部一致收敛，
\(S(b_j/p_j)\to S(x_0)\)，而
\(W(b_j)=W(p_j(b_j/p_j))\to0\)。式 (1) 遂给出

\[
 S(x)=0\qquad(x>0).
\tag{2}
\]

## 3. Mellin 唯一性迫使 \(W=0\)

进一步假设 \(W\) 在某个右半平面有绝对 Mellin 变换：对某个
\(\sigma_0\)，

\[
 \mathcal MW(s)=\int_0^\infty W(t)t^{s-1}\,dt
\]

在 \(\Re s>\sigma_0\) 收敛。对足够大的 \(\Re s>\max(\sigma_0,3)\)，由
绝对收敛可将 (2) 的 Mellin 变换逐项计算：

\[
 0=\int_0^\infty S(x)x^{s-1}\,dx
  =\sum_{c\ge2}c^{-s}\mathcal MW(s)
  =(\zeta(s)-1)\mathcal MW(s).
\tag{3}
\]

存在 \(\sigma_1>3\) 使 \(\zeta(s)-1\ne0\) 对所有 \(\Re s>\sigma_1\) 成立；
例如由首项 \(2^{-s}\) 严格支配尾项即可。因此
\(\mathcal MW(s)=0\) 于该右半平面。

固定其中一个实部 \(\sigma>\sigma_1\)，令 \(t=e^u\)。此时
\[
 \mathcal MW(\sigma+i\tau)
 =\int_{-\infty}^{\infty}
   W(e^u)e^{\sigma u}e^{i\tau u}\,du
\]
是一个 \(L^1(\mathbb R)\) 函数的 Fourier 变换，恒为零。Fourier 唯一性
给出 \(W(e^u)e^{\sigma u}=0\) 几乎处处；连续性遂得

\[
 \boxed{W\equiv0.}
\tag{4}
\]

## 4. 对 RH 算术桥的含义

这不是对所有非局部算子的 no-go，而是一个精确的范围结论：

* 正常的连续、绝对收敛、Mellin 正则全比值核不能与 \(D\) 精确对易；
* 因而把 note 335 的 causal kernel 简单“放宽到 \(d>a\)”并不能消掉
  \([A_V,D]\)；
* 可行的 nonlocal intertwiner 必须至少包含一种不可忽略的结构：算术
  分布（例如 divisor-supported coefficients）、有限截断边界，或不绝对
  收敛的 signed cancellation；
* 这解释了为什么普通 Fourier/Mellin 平滑核只能给出
  \(-K\zeta'\) 一类已消去零点的通道，不能直接恢复
  \(-K\zeta'/\zeta\)。

因此，下一条真正可能通向 RH 的桥不能是一个平滑的“全比值 PSD 修正”，
而必须在算术奇性和跨尺度 signed cancellation 中保留 \(1/\zeta\) 通道。

## 5. 被排除类之外的自然剩余：Dirichlet 卷积

上述 no-go 并不排除 divisor-supported 的分布核。给定算术函数 \(f\)，定义

\[
 (C_f x)(a)=\sum_{d\mid a} f(a/d)x(d).
\]

这是比值 \(d/a=1/n\) 上的离散核；交换卷积次序立即给出

\[
 C_fD=DC_f.
\]

其 Dirichlet/Mellin 乘子为
\[
 F(s)=\sum_{n\ge1}f(n)n^{-s}.
\]
特别地，\(f=\mu\) 时 \(F(s)=1/\zeta(s)\)。所以 note 336 的结论不是说
所有 nonlocal bridge 都不存在，而是把可行桥压缩到算术分布类；而该类
若要保留 RH 的零点信号，天然就重新带回 \(1/\zeta\) 及其 signed Möbius
系数，不能由普通平滑正核替代。

## 6. 算术分布类自身也不能是正的 Hermitian 桥

对 \(n>1\)，标准基向量满足
\[
 (C_f e_1)(n)=f(n),
 \qquad
 (C_f e_n)(1)=0.
\]
因此若 \(C_f\) 在标准 \(\ell^2\) 结构下是 Hermitian，则
\[
 f(n)=\langle C_f e_1,e_n\rangle
     =\overline{\langle C_f e_n,e_1\rangle}=0
 \qquad(n>1).
\]
Hermitian 的 Dirichlet 卷积只有标量 \(f(1)I\)；非平凡的
\(C_\mu\) 不可能本身就是 PSD 算子。若只要求 entrywise 非负，则
\((C_f e_1)(n)=f(n)\ge0\)，同样排除了 \(f=\mu\)，因为
\(\mu(p)=-1\) 对每个素数 \(p\) 成立。

所以正性若要与 \(C_\mu\) 同时出现，只能放在形如
\(C_\mu^*MC_\mu\) 的外层因子化中；这会在 Mellin 端同时引入
\(1/\zeta(s)\) 与 \(1/\zeta(\overline{s})\)，而不是一个新的无零点正核。
