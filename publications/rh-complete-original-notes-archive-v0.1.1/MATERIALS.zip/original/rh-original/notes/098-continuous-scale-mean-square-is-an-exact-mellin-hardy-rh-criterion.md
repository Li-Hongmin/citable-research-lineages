> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 连续尺度均方给出精确 Mellin--Hardy RH 判据

日期：2026-08-14。

依赖：[note 094](094-k1-a2-high-divisor-cell-has-a-zero-free-mellin-detector.md)、
[note 095](095-k1-a2-cell-reduces-to-moving-scale-mobius-covariance.md)。

证据等级：有界变差采样引理、精确 Mellin 变换与 Paley--Wiener
等距。本文将 note 094 的离散 single-cell gate 无损转为连续尺度 gate；
它不估计该均方，因而不证明 RH。

## 1. 连续尺度对象

按零延拓定义

\[
F(t):=\log\frac1t\left(\frac2{\pi t}+\sin 2\pi t\right)
\mathbf 1_{(2/3,1)}(t),
\qquad
K(s):=\int_0^\infty F(t)t^{s-1}\,dt,
\tag{1}
\]

\[
\boxed{
U(x):=\sum_{d\ge1}\mu(d)F(d/x),
\qquad x>0.
}
\tag{2}
\]

对每个固定 \(x\)，(2) 只含 \(2x/3<d<x\) 的有限和。特别地，
\(U(x)=0\;(0<x\le1)\)，而 \(U(N)\) 正是 note 095 的 \(U_N\)。

## 2. BV 采样误差恰为临界阶

令 \(V_F=\operatorname{Var}_{(0,\infty)}F<\infty\)。对 \(x\in[Y,2Y]\)，
只有 \(2Y/3<d<2Y\) 可能在 (2) 中贡献。由于 \(x\mapsto d/x\)
单调，

\[
\operatorname{Var}_{[Y,2Y]}F(d/\cdot)\le V_F.
\tag{3}
\]

因此

\[
\|U\|_{L^\infty[Y,2Y]}\ll_FY,
\qquad
\operatorname{Var}_{[Y,2Y]}U\ll_FY,
\tag{4}
\]

并且

\[
\operatorname{Var}_{[Y,2Y]}|U|^2
\le2\|U\|_{L^\infty[Y,2Y]}
\operatorname{Var}_{[Y,2Y]}U
\ll_FY^2.
\tag{5}
\]

实际上还有更强的局部结论。在跳点之外，

\[
U'(x)=-\sum_{2x/3<d<x}\mu(d)\frac d{x^2}F'(d/x),
\qquad |U'(x)|\ll_F1.
\tag{5a}
\]

唯一的跳点族为 \(x=3d/2\)，相邻跳点间距 \(3/2\)，且每个跳跃
的模不超过 \(F(2/3+)\)。故

\[
\boxed{
\operatorname{Var}_{[n-1,n]}U\ll_F1
\qquad(n\ge1).
}
\tag{5b}
\]

对任意 \(a\in BV[A,B]\)，逐个单位区间比较端点值与积分给出

\[
\left|
\sum_{A<n\le B}a(n)-\int_A^B a(x)\,dx
\right|
\le \operatorname{Var}_{[A,B]}a+2\|a\|_\infty.
\tag{6}
\]

结合 (4)--(6)，对所有 \(Y\ge1\) 有

\[
\boxed{
\left|
\sum_{Y<N\le2Y}|U(N)|^2
-\int_Y^{2Y}|U(x)|^2\,dx
\right|
\ll_FY^2.
}
\tag{7}
\]

将 (5b) 分别代入
\(|U(x)|^2\le2|U(n)|^2+O_F(1)\) 与其反向不等式，对整数
\(Y\ge1\) 还得到

\[
\boxed{
\begin{aligned}
\int_Y^{2Y}|U(x)|^2\,dx
&\le2\sum_{Y<n\le2Y}|U(n)|^2+O_F(Y),\\
\sum_{Y<n\le2Y}|U(n)|^2
&\le2\int_Y^{2Y}|U(x)|^2\,dx+O_F(Y).
\end{aligned}
}
\tag{7a}
\]

因而连续与整数采样在该 dyadic gate 上存在双向稳定性，而不只是
粗糙的临界误差控制。

这个误差正好处于 RH gate 的临界 \(Y^2\) 阶，因而它对每个
\(Y^{2+\varepsilon}\) 界是无损的。

## 3. 无求积误差的 Mellin 分解

若 \(\Re s>1\)，则

\[
\sum_{d\ge1}\int_0^\infty
|F(d/x)|x^{-\Re s-1}\,dx
=
\left(\int_0^\infty|F(t)|t^{\Re s-1}\,dt\right)
\sum_{d\ge1}d^{-\Re s}<\infty.
\tag{8}
\]

所以 Fubini 定理与 \(t=d/x\) 给出精确恒等式

\[
\boxed{
\mathcal H(s):=
\int_0^\infty U(x)x^{-s-1}\,dx
=\frac{K(s)}{\zeta(s)},
\qquad \Re s>1.
}
\tag{9}
\]

与 note 094 的离散 Dirichlet 级数不同，(9) 没有 Euler--Maclaurin
或 BV 求积余项。

取 Fourier 变换约定
\(\widehat h(t)=\int_{\mathbb R}h(y)e^{-ity}\,dy\)。对 \(\sigma>1\)，令

\[
h_\sigma(y)=U(e^y)e^{-\sigma y}\mathbf1_{[0,\infty)}(y).
\tag{10}
\]

则 \(\widehat h_\sigma(t)=\mathcal H(\sigma+it)\)，且 Plancherel 定理给出

\[
\boxed{
\int_1^\infty |U(x)|^2x^{-2\sigma-1}\,dx
=\frac1{2\pi}\int_{\mathbb R}
\left|\frac{K(\sigma+it)}{\zeta(\sigma+it)}\right|^2dt,
\qquad \sigma>1.
}
\tag{11}
\]

## 4. 连续均方、加权 \(L^2\) 与 RH 等价

**定理 1。** 下列条件等价：

1. RH 成立；
2. 对每个 \(\varepsilon>0\)，
   \[
   \boxed{
   \int_Y^{2Y}|U(x)|^2\,dx
   \ll_{\varepsilon,F}Y^{2+\varepsilon}
   \qquad(Y\ge1);
   }
   \tag{12}
   \]
3. 对每个 \(\sigma>1/2\)，
   \[
   \boxed{
   \int_1^\infty|U(x)|^2x^{-2\sigma-1}\,dx<\infty;
   }
   \tag{13}
   \]
4. (9) 的右边全纯延拓到 \(\Re s>1/2\)，并且对每个
   \(\sigma>1/2\) 属于半平面 Hardy 类
   \(H^2(\Re s>\sigma)\)。

**证明。** RH 蕴含经典的

\[
M(x)=O_\delta(x^{1/2+\delta})
\qquad(\delta>0).
\tag{14}
\]

对 (2) 作 Stieltjes 分部求和，并把 \(F\) 在 \(2/3\) 的跳跃计入
总变差，得

\[
U(x)=O_{\delta,F}(x^{1/2+\delta}).
\tag{15}
\]

它立即给出 (12)。对给定 \(\sigma>1/2\)，在 (15) 中取
\(0<\delta<\sigma-1/2\)，又得 (13)。

反之，(12) 推出 (13)：固定 \(\sigma>1/2\)，并取
\(0<\varepsilon<2\sigma-1\)，则每个 dyadic shell 对 (13) 的贡献为

\[
\ll_{\varepsilon,F}
2^{k(1+\varepsilon-2\sigma)},
\tag{16}
\]

故可求和。而 (13) 推出 (12)：给定 \(\varepsilon>0\)，取
\(\sigma=1/2+\varepsilon/2\)，则

\[
\int_Y^{2Y}|U(x)|^2\,dx
\le(2Y)^{2\sigma+1}
\int_1^\infty|U(x)|^2x^{-2\sigma-1}\,dx
\ll_{\varepsilon,F}Y^{2+\varepsilon}.
\tag{17}
\]

在 (13) 下，\(h_\sigma\in L^2(0,\infty)\) 对每个 \(\sigma>1/2\)
成立。Laplace--Paley--Wiener 定理使 \(\mathcal H\) 全纯于
\(\Re s>1/2\)，并给出

\[
\boxed{
\sup_{a>\sigma}\frac1{2\pi}
\int_{\mathbb R}|\mathcal H(a+it)|^2dt
=\int_1^\infty|U(x)|^2x^{-2\sigma-1}\,dx.
}
\tag{18}
\]

这证明 (13) 推出条件 4。反之，若条件 4 成立，则在任意
\(a>1\) 的竖线上，它与 (9) 中由 \(U\) 定义的 Laplace 变换相同。
Paley--Wiener 逆变换的唯一性遂将其半轴数据识别为
\(U(e^y)\)；在每个 \(\Re s>\sigma>1/2\) 再用等距式即得 (13)。
因而 (13) 与条件 4 等价。最后，令

\[
Z(s):=(s-1)\zeta(s),
\tag{19}
\]

则 \(Z\) 全纯于 \(\Re s>1/2\)。由 (9)，全纯恒等定理将

\[
Z(s)\mathcal H(s)=(s-1)K(s)
\tag{20}
\]

从 \(\Re s>1\) 延拓到 \(\Re s>1/2\)。若 \(\zeta(\rho)=0\) 且
\(\Re\rho>1/2\)，则 (20) 左边在 \(s=\rho\) 为零，但 note 094 的
零自由定理给出

\[
(\rho-1)K(\rho)\ne0,
\tag{21}
\]

矛盾。因而 \(\zeta\) 在 \(\Re s>1/2\) 无非平凡零点；再由功能方程，
RH 成立。\(\square\)

在这些等价条件下，(11) 对每个 \(\sigma>1/2\) 都成立，
且 (18) 给出精确的 Hardy 范数。

## 5. 与离散 cell 的精确关系及边界

由 (7)，

\[
\boxed{
\text{(12)}
\Longleftrightarrow
\forall\varepsilon>0,
\quad
\sum_{Y<N\le2Y}|U_N|^2
\ll_{\varepsilon,F}Y^{2+\varepsilon}.
}
\tag{22}
\]

结合 note 094--095，这也给出了连续均方判据的第二条证明。
它不是一个较弱的无条件均方：它与离散 moving-scale Möbius
covariance 只差临界 \(O_F(Y^2)\) 采样项，且保留 \(K/\zeta\) 的全部
离线零点。本文的改进是把零点探测放到无离散求积余项的精确
Mellin--Hardy 对象上，而不是对 RH 的一个无条件估计。
