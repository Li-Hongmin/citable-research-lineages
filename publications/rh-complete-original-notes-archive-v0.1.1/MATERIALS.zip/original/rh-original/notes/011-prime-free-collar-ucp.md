> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Prime-free collar UCP：首个 prime 阈值前谱底严格下降

日期：2026-08-11。本文首次对完整 Weil 算子证明一个无条件的 collar UCP 区域。关键是：只要
collar 中存在一个不被任何 prime-power shift 映回支撑的开区间，本征方程就在该区间退化为
Archimedean 普通核的卷积零方程；该核的指数展开给出完备矩，从而强迫函数为零。

## 1. 外侧 Archimedean 核的精确指数展开

由 note 005，离开 \(t=0\) 与 prime-power 原子后，完整 Weil 卷积核的普通函数部分为

\[
h(t)=2\cosh\frac{|t|}{2}
-\frac{e^{-|t|/2}}{1-e^{-2|t|}}.
\]

对 \(t>0\)，几何级数直接给出

\[
\boxed{
h(t)=e^{t/2}-\sum_{j=1}^{\infty}e^{-(2j+1/2)t}.}
\]

该级数及其任意阶导数在每个 \([\varepsilon,\infty)\) 上局部一致收敛，所以 \(h\) 在
\((0,\infty)\) 上实解析。

## 2. Archimedean 外侧卷积具有 UCP

**命题 1。** 设 \(u\in L^2(-a,a)\)，零延拓到 \(\mathbb R\)，并定义

\[
F(x)=\int_{-a}^a h(x-y)u(y)\,dy,
\qquad x>a.
\]

若 \(F\) 在 \((a,\infty)\) 的任一非空开区间为零，则 \(u=0\) a.e.

**证明。** 对 \(x>a\)，上节级数可在积分中逐项使用：

\[
F(x)=e^{x/2}M_-
-\sum_{j=1}^{\infty}e^{-(2j+1/2)x}M_j,
\]

其中

\[
M_-=\int_{-a}^ae^{-y/2}u(y)\,dy,
\qquad
M_j=\int_{-a}^ae^{(2j+1/2)y}u(y)\,dy.
\]

这个表示说明 \(F\) 在 \((a,\infty)\) 实解析。若它在一个开区间为零，解析唯一性给出
\(F(x)=0\) 对所有 \(x>a\) 成立。令 \(x\to\infty\)，衰减级数不能抵消 \(e^{x/2}M_-\)，故
\(M_-=0\)。于是

\[
\sum_{j=1}^{\infty}M_je^{-2jx}=0\qquad(x>a).
\]

令 \(z=e^{-2x}\)，左边是在 \(0<z<e^{-2a}\) 上为零的幂级数，所以 \(M_j=0\) 对所有
\(j\ge1\) 成立。

最后，令 \(q=e^{2y}\)。函数族

\[
e^{y/2}q^j,qquad j\ge1,
\]

在 \([-a,a]\) 上的线性包稠密：\(q\) 的取值区间
\([e^{-2a},e^{2a}]\) 与零有正距离，所以没有常数项的多项式 \(qP(q)\) 仍稠密于该区间上的连续
函数；乘以处处非零的 \(e^{y/2}\) 不改变稠密性。所有 \(M_j\) 为零遂推出 \(u=0\)。\(\square\)

## 3. Prime-free collar 判据

设 \(u\) 支撑在 \([-a,a]\)，而 \(x>a\)。正向平移 \(u(x+\log n)\) 恒为零；反向平移
\(u(x-\log n)\) 只有在

\[
x\in[\log n-a,\log n+a]
\]

时才可能非零。记 prime-power 覆盖集

\[
\mathcal C_a
=\bigcup_{\substack{n\ge2\\\Lambda(n)>0}}
[\log n-a,\log n+a].
\]

**命题 2（prime-free collar UCP）。** 若 \(A_bu=\lambda u\)、
\(u=0\) a.e. 于 \((a,b)\)，且存在非空开区间

\[
I\subset(a,b)\setminus\mathcal C_a,
\]

则 \(u\equiv0\)。

**证明。** 在 \(I\) 上，\(u\) 及所有可能落回 \([-a,a]\) 的 prime shifts 都为零。对角项
\(\lambda u\) 与 \(\delta_0\) 项也为零。完整分布卷积方程因而化为

\[
\int_{-a}^ah(x-y)u(y)\,dy=0,
\qquad x\in I.
\]

命题 1 给出 \(u=0\)。\(\square\)

因此，任何非零 collar 支撑本征函数都必须满足纯算术覆盖必要条件

\[
\boxed{(a,b)\subset\mathcal C_a.}
\]

## 4. 首个 prime-power 阈值前的严格谱单调

最小正位移是 \(\log2\)。若

\[
0<a<\frac12\log2,
\]

则 \(\log2-a>a\)。对任意 \(b>a\)，区间

\[
I=\bigl(a,\min\{b,\log2-a\}\bigr)
\]

非空，且不与任何 \([\log n-a,\log n+a]\) 相交。因此命题 2 排除任何从 \((-a,a)\) 零延拓到
更大区间的非零本征函数。

结合 note 008 的平台等价命题，得到：

\[
\boxed{
0<a<\tfrac12\log2,quad b>a
\quad\Longrightarrow\quad
\lambda_1(b)<\lambda_1(a).}
\]

这不是条件性结论，也不要求基态单符号或 Hopf 引理。

在临界值 \(a=\tfrac12\log2\) 后，\(\log2\) 位移区间从 \(x=a\) 起激活。仅靠“寻找完全没有
prime shift 的 collar 空窗”一般不能继续：例如用 Bertrand 定理，任一 prime power 后存在一个
不超过其两倍的 prime，故相邻可用 \(\log n\) 中心的间距至多 \(\log2\)；当
\(2a\ge\log2\) 时，相应覆盖区间可以首尾相接。后续必须利用带平移方程本身，而不是继续寻找空窗。

## 5. 对 M2-R3 的意义

本文把未知范围进一步局限到真正的算术激活区：

- 首个 prime 阈值前，ground-state collar UCP 与严格谱底单调已经完成；
- 任意假想平台都必须处在 prime-power 覆盖连续存在的范围，并依赖平移项与 Archimedean 解析核的
  精确抵消；
- note 010 的任意振荡模型不够，因为它没有同时满足这些离散平移关系。

下一步应在覆盖区间内固定“活跃平移集合”，研究

\[
\sum_{\log n\in[x-a,x+a]}
\frac{\Lambda(n)}{\sqrt n}u(x-\log n)
=\int_{-a}^ah(x-y)u(y)\,dy
\]

能否递归提升 \(u\) 的正则性或建立延迟方程唯一性。

## 6. 来源与新结论边界

承重核公式来自 Masatoshi Suzuki, *Weil's quadratic form via the screw function*,
[arXiv:2606.09096](https://arxiv.org/abs/2606.09096)，以及 note 005 对其普通核的化简。

指数展开、完备矩证明、prime-free collar UCP、覆盖必要条件，以及
\(a<\frac12\log2\) 时对任意扩域的严格谱底单调，是本项目的新推论。本文没有解决
\(a\ge\frac12\log2\) 的带平移 collar UCP。
