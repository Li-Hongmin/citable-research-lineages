> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 2026 Liouville-collar 论文仍未提供其核心 signed estimate

日期：2026-08-16。

## 文献

Deep Bhattacharjee, *The Critical Line from First Principles: A Complete
Unconditional Liouville-Collar Closure of the Riemann Hypothesis*,
IJRST 16 (2026), 9--54，DOI
[10.37648/ijrst.v16i02.002](https://doi.org/10.37648/ijrst.v16i02.002)，
PDF：[ijrst.com/admin/upload/02%20Deep%20Bhattacharjee%2001463-1.pdf](https://ijrst.com/admin/upload/02%20Deep%20Bhattacharjee%2001463-1.pdf)。

## 逐项裁决

论文的最终解析步骤是正确的条件蕴含，但不是无条件证明：

1. Theorem 12.8 假设 (150.1) 的中短移位 maximal collar estimate 和
   (150.2) 的 terminal-shift estimate，然后推出
   \(L(X)\ll_\varepsilon X^{1/2+\varepsilon}\)。
2. §12.4 的式 (151.2) 明确把保留 Liouville 符号的 signed、
   endpoint-maximal、尺度精确估计列为“principal analytic construction still
   required”：
   \[
   \sup_{\|\beta\|_2\le1}\sup_Y
   \left|\sum_{H<h\le2H}\beta_h C_{h,\Delta}(Y)\right|
   \ll_\varepsilon X^{1+\varepsilon}H^{-1/2}.
   \]
3. Theorem 12.12 把该 estimate 写成假设 (b)，并同时要求平方因子尾和
   terminal range；正文随后明确说明 signed spectral estimate 尚未由先前的
   arbitrary-coefficient 论证提供。

因此，标题中的 “Complete Unconditional Closure” 与正文实际证据等级不一致：
论文证明的是
\[
\text{signed collar estimate}+\text{tail/terminal estimates}
\Longrightarrow RH,
\]
而非前件本身。

## 与本项目的关系

该论文的 (151.2) 比本项目的 dyadic block aggregate
\(\sum_H|D_H|^2\) 更细：它控制任意 \(\ell^2\) shift coefficients 和任意端点
\(Y\)。它正好解释了为什么普通 Parseval、Gowers \(U^2\)、以及 averaged-Chowla
\(L^1\) 结果都不够。前述 notes/303 和 notes/304 进一步说明，甚至一阶平方根
部分和也不能替代这一 signed 二点/四点估计。

本 note 不把该论文吸收为 RH 证明；它只把当前缺口与外部文献的最精确 formulation
对齐。
