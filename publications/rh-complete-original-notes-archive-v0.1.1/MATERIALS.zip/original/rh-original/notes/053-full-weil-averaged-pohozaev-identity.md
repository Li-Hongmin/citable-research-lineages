> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 完整局部 Weil 零模态的 averaged Pohozaev 恒等式

日期：2026-08-11。

本文把 notes 050--052 的 averaged logarithmic boundary trace 与 conormal variance 组装成完整
局部 Weil 零模态的边界恒等式。结论不要求逐个 prime correlation 经典可微，但也不单独排除首次退化。

## 1. 定理

设

\[
Q_W^a\succeq0,\qquad 0\ne u\in D(A_a),\qquad A_au=0,
\]

且 \(u\) 位于固定奇偶扇区。写

\[
U_+(t)=u(a-e^{-t}),\qquad U_-(t)=u(-a+e^{-t}).
\]

由 notes 050--052，存在 averaged boundary coefficients \(B_\pm\)，满足

\[
\frac1{\sqrt T}\int_{T_0}^{T}U_\pm(t)\,dt\longrightarrow2B_\pm,
\]

并且

\[
\frac1T\int_T^{2T}
\left|\sqrt t\,U_\pm(t)-B_\pm\right|^2dt\longrightarrow0.
\]

则 weak prime virial \(V_{\rm pr}^{\rm w}(u)\) 存在，且

\[
\boxed{
a\bigl(|B_+|^2+|B_-|^2\bigr)
=2\left[
\|u\|_2^2+V_{\rm pr}^{\rm w}(u)+V_r(u)+V_{\rm pol}(u)
\right].}
\tag{1}
\]

这里

\[
V_r(u)=\iint_{(-a,a)^2}
\bigl[k(x-y)+(x-y)k'(x-y)\bigr]u(y)\overline{u(x)}\,dy\,dx,
\tag{2}
\]

而若

\[
c=\langle u,\cosh(x/2)\rangle,\quad h=\langle u,\sinh(x/2)\rangle,
\]

\[
j_s=\langle u,x\sinh(x/2)\rangle,\quad
j_c=\langle u,x\cosh(x/2)\rangle,
\]

则

\[
V_{\rm pol}
=-2|c|^2-2\operatorname{Re}(\overline c\,j_s)
+2|h|^2+2\operatorname{Re}(\overline h\,j_c).
\tag{3}
\]

## 2. Weak prime virial

令 \(d_n=\log n\)、\(\alpha_n=\Lambda(n)/\sqrt n\)，并取端点 log-slow cutoff dilation
方向 \(X_Tu\)。定义

\[
V_{\rm pr}^{\rm w}(u):=\lim_{T\to\infty}2q_{\rm pr}(u,X_Tu).
\tag{4}
\]

该极限由零模态弱方程与其余各项的已知极限强制存在，不需要预先假设
autocorrelation \(C_u(d)=\int u(x+d)\overline{u(x)}dx\) 在 active delays 可微。若这些导数存在，则

\[
V_{\rm pr}^{\rm w}(u)
=-2\sum_{d_n<2a}\alpha_nd_n\operatorname{Re}C_u'(d_n).
\tag{5}
\]

式 (5) 的 Fourier multiplier 随频率换号，所以没有一般符号。

## 3. 边界项与 form stationarity 的区别

向内酉缩放为

\[
(U_su)(x)=e^{s/2}u(e^sx).
\]

logarithmic 主部的 cutoff Green pairing 给

\[
\|u\|_2^2-\frac a2\bigl(|B_+|^2+|B_-|^2\bigr).
\tag{6}
\]

将 (2)--(4) 与 (6) 代入 \(Q_W^a(u,X_Tu)=0\)，再令 \(T\to\infty\)，即得 (1)。

这不与零模态驻定性矛盾。若 \(B_+\) 或 \(B_-\) 非零，则

\[
Q_W^a(U_su-u)=sD_+(u)+o(s),
\qquad
D_+(u)=\frac a2\bigl(|B_+|^2+|B_-|^2\bigr),
\]

所以 \(U_su-u\) 只有 \(O(\sqrt s)\) 的 form 距离；它不是普通 form 可微切向量。弱方程消去的是
bulk virial 与 boundary anomaly 的总和，不能把两者分别置零。

## 4. 奇偶与 polar-invisible 简化

奇偶性给 \(B_-=\pm B_+\)。若零模态还满足相应 polar orthogonality，则
\(V_{\rm pol}=0\)，因而

\[
\boxed{
a|B_+|^2=\|u\|_2^2+V_{\rm pr}^{\rm w}(u)+V_r(u).}
\tag{7}
\]

## 5. 结论边界

式 (1) 是新的完整 averaged Pohozaev 恒等式，但不是首次退化排除定理。首次退化半正定性、严格
domain crossing、polar invisibility 与普通 commutator stationarity 均不足以控制 (7) 右端；有限维
模型允许其为正、零或负。要由此闭合 RH，仍至少需要以下二者之一：

\[
V_{\rm pr}^{\rm w}(u)+V_r(u)>-\|u\|_2^2
\quad\text{对所有候选零模态成立},
\tag{8}
\]

或

\[
u\in\ker A_a,\quad B_+=B_-=0
\quad\Longrightarrow\quad u=0.
\tag{9}
\]

现有抽象结构不能推出 (8) 或 (9)。因此 Pohozaev 路线在此准确停于一个核专属 virial 不等式或
averaged-boundary UCP，而不宣称已经排除 crossing。
