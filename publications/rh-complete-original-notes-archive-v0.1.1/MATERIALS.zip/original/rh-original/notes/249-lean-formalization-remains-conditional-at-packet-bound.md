> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Lean 形式化的证据边界：packet bound 仍是外部输入

日期：2026-08-16。

## 对象与来源

核验对象是随 Zenodo 记录
[`10.5281/zenodo.20082725`](https://zenodo.org/records/20082725)
提供的 `Mertens_aristotle` Lean 工程，特别是
`RequestProject/FinalChain.lean` 与其 `ARISTOTLE_SUMMARY.md`。本 note 只判断
形式化工程对声称的 Mertens 平方根界提供了什么证据，不把编译成功等同于解析数论
定理已经成立。

## 直接可核验的事实

`FinalChain.lean` 在最终链的入口处保留

```lean
lemma packet_bound_analytic ... := by
  sorry
```

其注释明确说明，这一命题是 Sections 10--21 的深层 per-packet analytic input，
需要 BDH、Kuznetsov、spectral large sieve、shifted convolution 等工具。随后
`global_covariance_bound` 和 `mertens_sq_polylog_bound` 都直接调用该 lemma。

`ARISTOTLE_SUMMARY.md` 同样把该命题列为工程中唯一保留的 `sorry`，并说明新增的
Lean 文件只把若干确定性分解、适用性检查和指数 bookkeeping 形式化；这些文件把
`AnalyticToolkit` 作为外部输入，不能消除 packet bound 本身。

因此，形式化工程当前证明的是如下条件蕴含：

\[
  \text{外部 analytic toolkit + packet bound}
  \Longrightarrow
  \text{global covariance bound}
  \Longrightarrow
  M(N)^2\ll N(\log N)^A.
\]

它没有证明外部 toolkit 的全部解析估计，也没有给出声称的
\(M(N)\ll N^{1/2+\varepsilon}\) 无条件证明。

## 与 dyadic 预印本缺口的关系

此前对 Theorem 19.216 和 19.218 的核验已发现：

1. 19.216 的模乘 residue 置换不保持逐 dyadic 频块；
2. 其低频 harmonic estimate 在给定的 \(\ell^1\)/sup/TV 假设下有显式区间函数反例；
3. 19.216 使用的 \(q^{-1}\sum_h|c_\eta(h)|^2\) 与 Definition 20.12 的
   \(\sum_\eta|c_\eta|^2\) 尚未由 shell--residue 多重度恒等式连接；
4. 19.218 的 exact-level cusp capacity 在无界 low-divisor sector 没有被
   capacity-weighted energy 支付。

Lean 工程没有形式化这些接口，因此它不能作为上述缺口已经修复的证据。形式化的
“无 `sorryAx`”只适用于依赖 `AnalyticToolkit` 的后续推理；不适用于其未提供的
解析输入。

## 对 RH 主线的结论

这项核验把一个可能的误读关闭为严格边界：

> 该 Lean 归档是条件性 proof shell，而不是对 dyadic covariance 预印本的独立
> 无条件验证。

要使它成为 RH 证据，至少还必须补出一个独立、可审计的 per-packet analytic
bound，并同时闭合 19.216 的 shell--residue normalization 与 19.218 的
capacity ledger。此前 note 248 的两个分析缺口仍然有效。

## 证据范围

本 note 依赖下载归档中的源码与摘要文件；它只证明“形式化工程没有封闭深层
analytic input”这一状态判断，不对预印本之外的解析定理作新的否定，也不声称
RH 已被证伪或已被证明。
