> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Dyadic Liouville block：无条件基线与真正困难的移位范围

日期：2026-08-16。

令
\[
 C_h(X)=\sum_{n\le X-h}\lambda(n)\lambda(n+h),\qquad
 D_H(X)=\sum_{H\le h<\min(2H,X)}C_h(X),
\]
以及
\[
 L_\lambda(Y)=\sum_{n\le Y}\lambda(n),\qquad
 M_\lambda(X)=\max_{Y\le X}|L_\lambda(Y)|.
\]
直接交换求和次序并使用 \(|\lambda(n)|=1\)，得到两个互补的无条件界：
\[
 |D_H(X)|\le XH,
\tag{1}
\]
以及
\[
\begin{aligned}
 |D_H(X)|
 &\le \sum_{n\le X-H}
 \left|\sum_{n+H\le m<n+2H}\lambda(m)\right|\\
 &\le 2X\,M_\lambda(X).
\end{aligned}
\tag{2}
\]
因此
\[
\boxed{|D_H(X)|\le 2X\min\!\left(H,M_\lambda(X)\right).}
\tag{3}
\]

经典零自由区对 \(\zeta(2s)/\zeta(s)\) 给出
\[
M_\lambda(X)\ll
X\exp\!\left[-c(\log X)^{3/5}(\log\log X)^{-1/5}\right],
\tag{4}
\]
于是当前无条件基线为
\[
 |D_H(X)|\ll
 X\min\!\left(
 H,\,
 X e^{-c(\log X)^{3/5}(\log\log X)^{-1/5}}
 \right).
\tag{5}
\]

这说明 \(H\le X^\varepsilon\) 的小移位已经自动满足
\(D_H(X)\ll X^{1+\varepsilon}\)；但当
\[
 H\gg X^\varepsilon
\]
时，平凡界迅速失去目标量级，而经典零自由区仍只给
\(X^{2-o(1)}\)。因此 signless dyadic gate 的困难并不均匀分布：
真正的未闭合区是增长到宏观尺度的移位，而非固定 \(h\) 或端点记号。

该估计没有使用 Chowla，也没有声称 RH；它只是把后续任何改进必须支付的
尺度范围精确隔离出来。

