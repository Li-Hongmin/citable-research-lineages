> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(n=11\) 激活的几何分段与最薄 Schur 缺口

日期：2026-08-15。

本 note 只审查从

\[
a_*={1\over2}\log {201\over20}
\]

向右推进时，下一项 \(n=11\) 的 partial-reflection block。结论是：在第一个
激活区间内它先是新增环带的 \(D\)-块，而不是旧区间与新环带之间的 \(C\)-块；真正的
\(C\)-块要到更大的尺度才出现。已有端点证书没有给出该尺度的 Schur 下界。

## 1. 精确几何

写

\[
d=\log 11,\qquad p_{11}={\log 11\over\sqrt {11}},\qquad
 a_{11}={d\over2}={1\over2}\log11.
\]

在半区 \(H_b=L^2(0,b)\) 上，\(n=11\) 的反射为

\[
(J_{11,b}f)(x)=\mathbf 1_{[d-b,b]}(x)f(d-x)
\quad (b<d).
\tag{1}
\]

其偶/奇扇区系数分别为 \(-p_{11}\) 与 \(+p_{11}\)。数值位置为

\[
\begin{aligned}
a_*&=1.153786317252542\ldots,\\
a_{11}&=1.198947636399185\ldots,\\
b_{\rm cross}:=d-a_*&=1.244108955545828\ldots,
\end{aligned}
\]

且
\[
a_*<a_{11}<b_{\rm cross}.
\tag{2}
\]

令 \(P\) 为 \(H_{a_*}\) 到 \(H_b\) 的零延拓投影，\(Q=I-P\)。由 (1) 直接得到

\[
\begin{array}{c|c|c}
\text{尺度}&\text{\(n=11\) 的支撑}&\text{旧/新块}\\ \hline
b\le a_{11}&d-b\ge b,\ J_{11,b}=0\ \text{(端点为零测)}&\text{无}\\
a_{11}<b\le b_{\rm cross}&[d-b,b]\subset(a_*,b]&PJ_{11,b}Q=0&QJ_{11,b}Q\\
b>b_{\rm cross}&[d-b,b]\text{ 跨过 }a_*&PJ_{11,b}Q\ne0&\text{真实 cross}
\end{array}
\tag{3}
\]

在所有这些尺度上 \(PJ_{11,b}P=0\)：若 \(x\le a_*\)，则
\(d-x\ge d-a_*>a_*\)。因此 \(n=11\) 并不是从 \(a_*\) 起就自动产生旧块
与新环带的 cross；它在 \((a_{11},b_{\rm cross}]\) 先完全留在 \(D\)-块。

但“先完全留在 \(D\)-块”不等于该块由 \(n=11\) 自身正定。对
\(a_{11}<b\le b_{\rm cross}\)，反射支撑
\([d-b,b]\subset Q\) 关于 \(d/2\) 对称；在该支撑上取偶/奇反射模式，
\(J_{11,b}\) 的特征值为 \(+1\) 与 \(-1\)。因此带符号系数的
\(\mp p_{11}J_{11,b}\) 在两个扇区之一含有精确负特征值
\(-p_{11}\)，其中 \(p_{11}=0.7229926\ldots\)。这说明该阶段的最薄缺口
首先是包含旧 prime/archimedean 项的 \(D\)-块联合下界，而不是单独的
cross 范数估计。
在这个区间 \(I_{11,b}\subset Q\)，所以 \(QJ_{11,b}Q=J_{11,b}\) 在
\(L^2(I_{11,b})\) 上有 \(+1\) 与 \(-1\) 两个对称类型的模式。故
\(-\sigma p_{11}QJ_{11,b}Q\) 自身含有精确的负特征值 \(-p_{11}\)；
新增 \(D\)-块的正性必须由其余 archimedean 与旧 prime 项支付，而不是由
\(n=11\) 项单独给出。

## 2. cross 的精确范数

当 \(b>b_{\rm cross}\) 时，令

\[
\ell=b-(d-a_*)>0.
\]

则 \(PJ_{11,b}Q\) 把
\([d-a_*,b]\subset Q\) 反射等距到 \([d-b,a_*]\subset P\)，两区间长度均为
\(\ell\)。所以

\[
\|PJ_{11,b}Q\|=1,\qquad
\|\,\mp p_{11}PJ_{11,b}Q\,\|=p_{11}
={\log11\over\sqrt{11}}
=0.7229926278581\ldots .
\tag{4}
\]

这个范数不随 \(\ell\downarrow0\) 变小；小支撑只能通过额外的正则性或 form
估计体现，不能用 operator norm 的小测度论证。注意这里的 partial reflection
满足 \(J=J^*\) 与 \(J^2=P_{[d-b,b]}\)，并不是整个 \(H_b\) 上的 involution。
直接计算得到

\[
(p_{11}PJQ)(p_{11}PJQ)^*
=p_{11}^2P_{[d-b,a_*]},
\qquad
(p_{11}QJP)(p_{11}QJP)^*
=p_{11}^2P_{[d-a_*,b]}
\tag{5}
\]

（区间投影均视为嵌入 \(H_b\) 的投影）。这只是 cross 的精确平方恒等式，
不是正性结论；将 \(J^2=P_I\) 错写成全空间 \(I\) 会虚增 Schur 预算。

## 3. 最薄 Schur 命题与可审计障碍

对完整 \(A_b^\sigma\) 写

\[
A_b^\sigma=\begin{pmatrix}A_*^\sigma&C_b^\sigma\\
(C_b^\sigma)^*&D_b^\sigma\end{pmatrix}.
\]

严格等价条件是

\[
D_b^\sigma-(C_b^\sigma)^*(A_*^\sigma)^{-1}C_b^\sigma\succeq0.
\tag{6}
\]

已有 note 089 只在 \(a_*\) 给出 \(A_*^\sigma>0\) 的固定下模型；其最后的
7 维/6 维 true-Schur pivots 已降至约 \(6.1\times10^{-44}\)（偶）与
\(5.6\times10^{-40}\)（奇），并没有输出可支付 (6) 的边界 resolvent 估计。
因此用一般范数支付 \(C_b^\sigma\) 会得到无用的大项；必须保留边界限制向量的真实
resolvent，而不能把 \(n=11\) cross 逐项取绝对值。

仅由 \(A_*^\sigma>0\) 与 \(D_b^\sigma>0\) 不能推出 (6)。最小抽象反例取

\[
\begin{pmatrix}1/2&\pm p_{11}\\\pm p_{11}&1/2\end{pmatrix},\qquad
\det={1\over4}-{(\log11)^2\over11}<0.
\tag{7}
\]

式 (7) 不是 \(A_b^\sigma\) 的负见证；它严格说明现有两块正性数据不足以支付
signed reflection cross。相应地，note 090 的 \(P_{400}\) 主压缩正性与 note 093
的 fixed-\(F_{640}\) 下模型负性，都不能替代 (6)：前者没有补空间，后者只是
\(\underline L\preceq A\) 的下模型。

## 4. 需要补的最小接口

推进到 \(b>b_{\rm cross}\) 至少需要一个保持 (1) 的 boundary-resolvent 命题，例如

\[
\bigl(D_b^\sigma-(C_{\rm old}^\sigma+C_{11}^\sigma)^*
(A_*^\sigma)^{-1}(C_{\rm old}^\sigma+C_{11}^\sigma)\bigr)
\succeq\eta_b I,\qquad \eta_b>0,
\tag{8}
\]

其中 \(C_{11}^\sigma=\mp p_{11}PJ_{11,b}Q\) 必须以完整向量保留。若只处理
\(a_{11}<b\le b_{\rm cross}\)，则 \(C_{11}=0\)，但仍需证明新增 \(D\)-块（含
\(\mp p_{11}QJ_{11,b}Q\)）的正性；端点 \(A_{a_*}>0\) 不提供这一步。

所以当前可审计结论是：\(n=11\) 的新 signed cross 没有已证严格 Schur 下界，
也没有实际 \(A_b\) 的反例；最小缺口是 (8) 型、按几何分段处理的真实
boundary-resolvent/annular lower bound。
