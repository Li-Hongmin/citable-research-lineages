> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Signed boundary Toeplitz 项的 Mellin 符号与不可消去的负边界

日期：2026-08-15。

本 note 补充 [note 171](171-one-sided-detector-half-lattice-boundary-identity.md)：给出
单侧边界项 \(G_X\) 的连续 Mellin/Fourier 表示，并给出一个对整个 detector
层级都成立的严格负号。它只处理有限 divisor 半格和一个显式 Fourier 符号；不把
有限符号扫描外推成 RH 结论。

## 1. 边界核与 Mellin 变换

写

\[
 p_m(t)=\begin{cases}P_m(e^t),&t\ge0,\\0,&t<0,\end{cases}
 \qquad g_m(t)=\frac{p_m(t)+p_m(-t)}2,
\]

其中 \(P_m(y)=\sum_{c\le y}V_m(c/y)\) 是 detector 的 periodization。于是

\[
 g_m(\log(a/b))=
 \begin{cases}
 P_m(a/b)/2,&a>b,\\
 P_m(1),&a=b,\\
 P_m(b/a)/2,&b>a.
 \end{cases}
\tag{1}
\]

对当前层级，\(\int_0^1V_m=0\)、\(V_m(0)=V_m(1)=0\)、
\(V_m'(0)=V_m'(1)=0\)。将 \(V_m\) 零延拓到 \(\mathbb R\)，它是 \(C^1\)
且二阶导数分段连续；Poisson 求和给出

\[
 P_m(y)=y\sum_{k\in\mathbb Z}\widehat V_m^{\,\mathrm{add}}(ky).
\]

零频率项因 \(\int V_m=0\) 消失，而两次分部积分给出
\(\widehat V_m^{\,\mathrm{add}}(\xi)=O_m(|\xi|^{-2})\)。因此

\[
 P_m(y)=O_m(y^{-2})\qquad(y\to\infty),
\tag{2}
\]

所以 \(g_m\in L^1(\mathbb R)\)。更高阶的已消去奇矩把 (2) 提升到更高的
有限阶，但本 note 只需可积性。

令

\[
 K_m(s)=\int_0^1V_m(u)u^{s-1}\,du.
\]

在 (Re s>1) 中交换求和与积分，并置 (u=c/y)，得到精确恒等式

\[
 I_m(s):=\int_1^\infty P_m(y)y^{-s-1}\,dy
 =\zeta(s)K_m(s).
\tag{3}
\]

左侧因 (2) 在 (Re s>-2) 全纯；故 (3) 延拓到临界线。取 Fourier 变换

\[
 \widehat g_m(\xi)=\int_{\mathbb R}g_m(t)e^{-i\xi t}\,dt,
\]

便有

\[
 \boxed{\widehat g_m(\xi)=\operatorname{Re}\!\left(\zeta(i\xi)K_m(i\xi)\right).}
\tag{4}
\]

若在端点先保留 \(e^{-\eta|t|}\)，(4) 先以
\(\operatorname{Re}(\zeta(\eta+i\xi)K_m(\eta+i\xi))\) 成立，再令
\(\eta\downarrow0\)；这也给出了无需依赖边界点值的 Abel 版本。

## 2. \(G_X\) 的 ordinary Fourier/Toeplitz 表示

对 squarefree 非平方 \(X\)，令 \(L_X=\{a\mid X:a<\sqrt X\}\)，并设

\[
 M_X(\xi)=\sum_{a\in L_X}\mu(a)a^{i\xi}.
\]

Fourier inversion 与 (1) 给出

\[
 \boxed{
 G_X=\frac1{2\pi}\int_{\mathbb R}
 \widehat g_m(\xi)|M_X(\xi)|^2\,d\xi.}
\tag{5}
\]

这是 \(a/b\) 型 ordinary Toeplitz Gram，而不是 reciprocal Hankel Gram。若
\(\widehat g_m\ge0\)，则 \(G_X\ge0\)；但是 (4) 显示真正的符号是
\(\operatorname{Re}(\zeta K_m)\)，而不是仅看 \(K_m\) 的实部。
在零频率处则始终为正：由 \(\zeta(0)=-1/2\) 及统一乘子式
\(K_m(0)<0\)，有 \(\widehat g_m(0)=-K_m(0)/2>0\)。这与下面的负频率
区间共同说明，边界符号不是一个固定整体号。

## 3. 一个对所有 (V_m) 的严格负边界

取任意奇素数 \(p>2\)，令 \(X=2p\)。此时

\[
 L_X=\{1,2\},\qquad (\mu(1),\mu(2))=(1,-1).
\]

对正 detector 层级有 \(P_m(1)=V_m(1)=0\)，且局部正性给出
\(P_m(2)=V_m(1/2)\)。这里的严格号也可直接从统一构造得到：写
\(V_m=-C_m^{-1}F_m'\)、\(F_m=u^3(1-u)^{2m+2}R_m(u)\)，其中
\(R_m>0\) 且 \(R_m'/R_m\le(m-1)/u\)。于是

\[
 \left.\frac{F_m'}{F_m}\right|_{u=1/2}
 \le 6-4(m+1)+2(m-1)=-2m<0,
\]

故 \(P_m(2)=V_m(1/2)>0\)。因此

\[
 G_{2p}=2(1)(-1)g_m(\log2)=-P_m(2)
 =-V_m(1/2)<0.
\tag{6}
\]

这不是数值扫描，而是一个两点有限恒等式。对 \(V_{15}\)，note 156 的有理值
\(P_{15}(2)=473/16384\) 给出

\[
 \boxed{G_{2p}=-\frac{473}{16384}}
 \qquad(p>2\text{ prime}).
\tag{7}
\]

因此单侧边界项没有统一的非负号；其负号在任意大的一族
\(X=2p\) 上保持不变。

事实上，这一族还直接破坏完整单侧二次型的正性。由 note 171 的边界恒等式，

\[
 Q_{2p}=P_m(2p)-2P_m(p)+P_m(p/2),
 \qquad H_{2p}=Q_{2p}-2P_m(2).
\tag{7a}
\]

由 (2)，\(Q_{2p}\to0\) 而 \(P_m(2)>0\)，故

\[
 H_{2p}\longrightarrow -2P_m(2)<0\qquad(p\to\infty).
\tag{7b}
\]

这不是对 RH 的反例；它只说明“单侧 \(P_m\) 核在完整 divisor 格上自带 Weil
正性”这一候选前提不成立，必须引入额外 archimedean/prime block。

作为独立的频率证据，\(V_{15}\) 的
\[
 K_{15}(s)=\frac{415134720(s-1)}{(s+2)(s+4)(s+6)(s+8)(s+9)\cdots(s+15)}
\]
满足（192-bit Arb）

\[
 \widehat g_{15}(2)=\operatorname{Re}(\zeta(2i)K_{15}(2i))
 \in[-5.0808400690614,-5.0808400690610]\times10^{-4}<0,
\]

而 \(\widehat g_{15}(0)>0\)。故符号变化发生在真正的 boundary symbol，而
非仅是 \(K_{15}\) 的一个无关相位。

## 4. 最薄的 archimedean compensation

若把

\[
 \widehat g_m=\widehat g_{m,+}-\widehat g_{m,-},
 \qquad \widehat g_{m,\pm}=\max(\pm\widehat g_m,0),
\]

定义

\[
 A_X=\frac1{2\pi}\int\widehat g_{m,-}(\xi)|M_X(\xi)|^2\,d\xi\ge0,
\]

则有精确的正化恒等式

\[
 G_X+A_X=\frac1{2\pi}\int\widehat g_{m,+}(\xi)|M_X(\xi)|^2\,d\xi\ge0.
\tag{8}
\]

这给出一个可行的 archimedean 候选：加入 Fourier symbol
\(\widehat g_{m,-}\) 的完整正块。但 \(A_X\) 是全频率、随 \(X\) 变化的无限秩
Toeplitz 补偿；它不是由 \(P_m(y)\ge0\) 或 \(H_X\ge0\) 自动产生的标量常数。
在 note 171 的边界式中，(8) 只能把 \(G_X\) 改写为正块减去 \(A_X\)；若要
得到实际半格的正性，仍需一个统一的 signed Schur 估计控制 \(A_X\)，或一个
archimedean--prime cross block 在 \(A_X\) 中完成抵消。

所以当前最小桥不是“证明 \(G_X\) PSD”，而是建立一个保留 (5) 的
frequency-weighted signed intertwiner，并给出 \(A_X\) 的算术上界。有限的负号
(6)--(7) 说明没有不带此补偿的普通 Toeplitz 正化。

本文只证明 (3)--(8) 及有限边界符号，不声称 RH。
