> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Positive/negative frequency-channel criterion for the reciprocal form

## 两个正通道

令 boundary symbol \(h\) 分解为

\[
h=h_+-h_-,
\qquad
h_\pm=\max(\pm h,0).
\]

对 divisor 指数映射 \(T_X\)，定义两个 ordinary Gram

\[
G_X^\pm=T_X^*M_{h_\pm}T_X\succeq0.
\]

由于 reciprocal reflection 仍满足
\(H_X=G_XR_X\)，有精确分解

\[
\boxed{H_X=(G_X^+-G_X^-)R_X.}
\]

这与 note 185 的 Krein factorization 等价，但把正、负频率通道分别显式化。

## Möbius 模式上的标量恒等式

在完整 squarefree divisor 格上，令

\[
c_X(a)=\mu(a),\qquad
R_Xc_X=\mu(X)c_X.
\]

定义

\[
\Phi_X(\xi)=\sum_{a\mid X}\mu(a)e^{i\xi\log a}
=\prod_{p\mid X}(1-p^{i\xi}).
\]

则

\[
c_X^*G_X^\pm c_X
=\frac1{2\pi}\int_{\mathbb R}
h_\pm(\xi)|\Phi_X(\xi)|^2\,d\xi
=:\mathcal E_X^\pm\ge0,
\]

并且 reciprocal 二次型严格为

\[
\boxed{
c_X^*H_Xc_X
=\mu(X)\bigl(\mathcal E_X^+-\mathcal E_X^-\bigr).
}
\]

因此任何保留 full Möbius parity 的正性命题，都必须控制同一个
\(|\Phi_X|^2\) 权重下的正/负频率能量差：

\[
\mathcal E_X^+\ge\mathcal E_X^-
\quad\text{或相反的 parity 版本}.
\]

逐频取绝对值、分别估计两个通道，都会丢掉这个 signed cancellation。

## 对当前 detector 的含义

对 V15，note 174 给出 \(h(0)>0\) 与 \(h(2)<0\)，所以两通道都非零。note 178
的 \(X=2p\) 极限给出一个具体负 seed，说明 \(\mathcal E_X^--\mathcal
E_X^+\) 可以严格占优；这不是 ordinary Gram 的抽象惯性，而是实际
Möbius product-sine 权重上的数值方向。

所以最薄的 arithmetic/A 接口可以明确写成：

\[
\text{在同一 }\Phi_X\text{ 上证明正/负频率能量的 parity-相容比较，}
\]

并且该比较必须保留随 \(X\) 增长的 divisor/reflection 通道。它不能由
\(G_X^\pm\succeq0\) 或固定 rank 的 Schur 补自动推出。

本 note 是精确的两通道恒等式与目标条件，不是 RH 证明。

