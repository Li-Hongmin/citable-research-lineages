> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一个负 Mellin moment 关闭全部高阶 Beta 正 detector

日期：2026-08-14。

依赖：
[note 118](118-an-endpoint-flat-detector-gives-an-exact-positive-reciprocal-product-rh-gate.md)、
[note 137](137-a-positive-degree-six-detector-removes-the-first-collective-residue.md)、
[note 139](139-a-minimal-degree-nine-positive-detector-removes-two-collective-residues.md)。

证据等级：单格显式负值与解析延拓后的负 Mellin moment。

notes 137、139 表明一般 polynomial detector 可以逐层删除 collective
residues。一个自然猜测是直接增加 Beta detector 的左端消失阶。本文给出统一否定：
所有 \(p\ge3\) 的 Beta detector 都在某处取负，独立于右端阶数 \(q\)。

## 1. Beta 家族

令整数

\[
p\ge3,\qquad q\ge1,
\tag{1}
\]

并定义

\[
H_{p,q}(u)=u^p(1-u)^q\mathbf1_{(0,1)}(u),
\tag{2}
\]

\[
\begin{aligned}
V_{p,q}(u)
&=(-u\partial_u-1)H_{p,q}(u)\\
&=u^p(1-u)^{q-1}
\big((p+q+1)u-(p+1)\big).
\end{aligned}
\tag{3}
\]

相应 Faulhaber 核为

\[
P_{p,q}(y)=\sum_{c\le y}V_{p,q}(c/y).
\tag{4}
\]

## 2. \(q\le p\) 的单格负值

若 \(q\le p\)，可取

\[
1+\frac{q}{p+1}<y<2.
\tag{5}
\]

此时 (4) 只有 \(c=1\) 一项，而且

\[
(p+q+1)-(p+1)y<0.
\tag{6}
\]

其余因子严格为正，故

\[
\boxed{P_{p,q}(y)=V_{p,q}(1/y)<0.}
\tag{7}
\]

## 3. \(q\ge p+1\) 的统一负 Mellin moment

现设 \(q\ge p+1\)。\(V_{p,q}\) 在左右端的消失阶足以使
shifted Euler--Maclaurin 展开给出

\[
P_{p,q}(y)=O(y^{-p}).
\tag{8}
\]

因此

\[
I_{p,q}(s)=
\int_1^\infty P_{p,q}(y)y^{-s-1}\,dy
\tag{9}
\]

在 \(\Re s>-p\) 绝对收敛且全纯。

在 \(\Re s>1\)，逐项换元 \(u=c/y\) 得

\[
I_{p,q}(s)=\zeta(s)K_{p,q}(s),
\tag{10}
\]

其中

\[
K_{p,q}(s)
=\int_0^1V_{p,q}(u)u^{s-1}\,du
=(s-1)B(s+p,q+1).
\tag{11}
\]

两侧解析延拓使 (10) 在 \(\Re s>-p\) 成立。取统一见证

\[
s=-\frac52.
\tag{12}
\]

因 \(p\ge3\)，

\[
B\!\left(p-\frac52,q+1\right)>0,
\tag{13}
\]

而 zeta 功能方程给出

\[
\zeta\!\left(-\frac52\right)>0.
\tag{14}
\]

故

\[
\boxed{
\int_1^\infty P_{p,q}(y)y^{3/2}\,dy
=-\frac72\,
\zeta\!\left(-\frac52\right)
B\!\left(p-\frac52,q+1\right)<0.}
\tag{15}
\]

若 \(P_{p,q}(y)\ge0\) 对所有 \(y\ge1\) 成立，(15) 左侧应非负，矛盾。

## 定理

对所有整数 \(p\ge3,\ q\ge1\)，

\[
\boxed{
P_{p,q}\not\ge0\quad\text{on }[1,\infty).}
\tag{16}
\]

特别地，试图通过提高 \(p\) 在单一 Beta 家族内删除更多低阶 Mellin residues
必然破坏逐项正性。note 139 的九次正 detector 必须使用非 Beta 的二次修正因子
\(20u^2-5u-1\)；这不是参数选择偶然，而是由 (15) 强制的结构性分叉。
