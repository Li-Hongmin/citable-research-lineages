> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 加性 Möbius 指数和定理仍不能关闭 dyadic 正部的低频门

日期：2026-08-16。

依赖：[note 280](280-dyadic-positive-part-is-an-additive-low-frequency-weighted-energy.md)。

## 1. 可用的外部输入

Srivastav 的 2026 年修订版预印本给出如下加性指数和估计。若

$$
\alpha=\frac aq+\frac{\delta}{x},\qquad (a,q)=1,qquad
|\delta|\le \frac{x^{1/5+\eta}}q,
$$

且 $1\le q\le x^{2/5-\eta}$，则

$$
\left|\sum_{n\le x}\mu(n)e(n\alpha)\right|
\le
\mathscr G_\eta\!\left(
\frac{\log(\delta_0q)}{\log x},
\frac{\log^+(\delta_0/q)}{\log x}
\right)
\frac{x}{\sqrt{\delta_0\varphi(q)}},
\qquad
\delta_0=\max(1,|\delta|/4).
\tag{1}
$$

来源：[Srivastav, *Log-free bounds on exponential sums over primes*](https://arxiv.org/abs/2505.07803)，其摘要明确同时给出 Möbius 版本。这里仅使用该定理的 $q=1$ 特例，不把预印本的其他结论外推到本项目。

## 2. 代入 note 280 的 $q=1$ 主弧

取 $x=N$、$a=0$、$q=1$，并令 $\alpha=\theta$。当

$$
0\le \theta\le \theta_*:=N^{-4/5+\eta},
$$

有 $\delta=N\theta\le N^{1/5+\eta}$，所以 (1) 适用。由于参数

$$
\frac{\log(\delta_0)}{\log N}\in[0,1/5+\eta]
$$

落在固定紧区间内，记该区间上显式函数的上界为 $C_\eta$，则

$$
|F_N(\theta)|
\ll_\eta
\begin{cases}
N,&0\le N\theta\le1,\\[1mm]
N(N\theta)^{-1/2},&1<N\theta\le N^{1/5+\eta}.
\end{cases}
\tag{2}
$$

另一方面，note 280 给出

$$
W_N(\theta)\ll
\begin{cases}
N,&0\le\theta\le N^{-1},\\[1mm]
\theta^{-1}(1+\log(2N\theta)),&N^{-1}<\theta\le1/2.
\end{cases}
\tag{3}
$$

将 (2)--(3) 代入低频正部 majorant，可得第一段

$$
\int_0^{1/N}W_N(\theta)|F_N(\theta)|^2\,d\theta
\ll_\eta N^2.
\tag{4}
$$

对第二段令 $u=N\theta$，则

$$
\begin{aligned}
\int_{1/N}^{\theta_*}W_N(\theta)|F_N(\theta)|^2\,d\theta
&\ll_\eta
N^2\int_1^{N^{1/5+\eta}}
\frac{1+\log(2u)}{u^2}\,du\\
&\ll_\eta N^2.
\end{aligned}
\tag{5}
$$

因此该目前最强的加性主弧估计，插入 note 280 的非负 majorant 后仍只给出

$$
\int_0^{\theta_*}W_N(\theta)|F_N(\theta)|^2\,d\theta
\ll_\eta N^2,
$$

而不是所需的 $N^{1+\varepsilon}$。这里的 $N^2$ 主要由 $N^{-1}$ 宽度的零频窗产生；不是远离零点的圆法弧控制问题。

## 3. 结论与剩余门

这个计算不否定 (1) 的价值：它可能有效压低非零有理弧或中频部分。但对本项目的目标，必须另外提供至少一种输入：

1. $|\theta|\lesssim N^{-1}$ 内的 Mertens 级加性界；或
2. 不取每个 dyadic block 的正部，而直接保留 $b_H(\theta)$ 之间的 signed cancellation；或
3. 一个把加性低频弧映射回乘法 Möbius 结构的算术 intertwiner。

所以“用当前加性指数和定理替代 reciprocal-product 能量门”这条路线已被严格定位为不足：它改善了非零弧，却没有触及零频峰，也没有改变 RH-strength 算术门。

该 note 只记录一个可复核的路线闭合，不声称证明 RH。
