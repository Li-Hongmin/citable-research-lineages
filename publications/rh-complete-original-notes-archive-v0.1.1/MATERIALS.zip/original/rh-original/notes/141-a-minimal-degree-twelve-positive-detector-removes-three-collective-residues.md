> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一个最小十二次正 detector 同时消去三个 collective residues

日期：2026-08-14。

依赖：
[note 139](139-a-minimal-degree-nine-positive-detector-removes-two-collective-residues.md)。

证据等级：精确十二次 Faulhaber 恒等式、Bernstein--falling-factorial
正证书、shifted Euler--Faulhaber 最小次数论证与有理 Mellin 变换。

本文把正 detector 层级再推进一步：同时令 \(s=-1,-3,-5\) residues 消失，
仍保持全半轴逐项非负，并证明次数十二最小。

## 1. 十二次 detector

令

\[
\boxed{
V(u)=u^2(1-u)^7(91u^3-3u^2-7u-1)}
\qquad(0<u<1),
\tag{1}
\]

并在区间外取零。展开为

\[
\begin{aligned}
V(u)={}&-u^2+25u^4-490u^6+1792u^7-3150u^8\\
&+3200u^9-1925u^{10}+640u^{11}-91u^{12}.
\end{aligned}
\tag{2}
\]

它满足

\[
V(0+)=V(1-)=0,\qquad
\int_0^1V(u)\,du=0,
\tag{3}
\]

\[
\boxed{v_1=v_3=v_5=0.}
\tag{4}
\]

Mellin 变换精确为

\[
\boxed{
K_V(s)=
\frac{403200(s-1)}
{(s+2)(s+4)(s+6)(s+7)(s+8)(s+9)(s+10)(s+11)(s+12)}.}
\tag{5}
\]

所以临界右半条带中没有 detector zero。

## 2. 精确 Faulhaber 核

定义

\[
P_V(y)=\sum_{c\le y}V(c/y).
\tag{6}
\]

写

\[
y=N+r,\qquad
N=\lfloor y\rfloor\ge1,\qquad
0\le r<1,\qquad
m=N-1.
\tag{7}
\]

前十二个幂和给出

\[
\boxed{
P_V(N+r)
=\frac{N(N+1)}{30(N+r)^{12}}Q_N(r),}
\tag{8}
\]

其中 \(Q_N\) 是关于 \(r\) 的十次多项式、关于 \(m\) 的三次多项式。

## 3. Bernstein--falling-factorial 正证书

令

\[
\beta_{k,10}(r)=\binom{10}{k}r^k(1-r)^{10-k}.
\tag{9}
\]

则

\[
\boxed{
Q_N(r)
=\sum_{k=0}^{10}
\left[
c_k^{(0)}
+mA_k
+m(m-1)B_k
+m(m-1)(m-2)C_k
\right]\beta_{k,10}(r).}
\tag{10}
\]

四组系数为

\[
c^{(0)}
=\left(
0,0,0,0,0,0,0,10,\frac{220}{3},285,735
\right),
\tag{11}
\]

\[
A=
\left(
245,395,\frac{5620}{9},\frac{2890}{3},1440,\frac{18560}{9},
\frac{8320}{3},\frac{10370}{3},\frac{36140}{9},4475,4925
\right),
\tag{12}
\]

\[
B=
\left(
1170,1245,\frac{11680}{9},\frac{4030}{3},\frac{4240}{3},
\frac{4640}{3},\frac{5240}{3},\frac{5900}{3},
\frac{19310}{9},2265,2340
\right),
\tag{13}
\]

\[
C=
\left(
234,234,\frac{2066}{9},\frac{662}{3},\frac{632}{3},
\frac{1856}{9},\frac{632}{3},\frac{662}{3},
\frac{2066}{9},234,234
\right).
\tag{14}
\]

所有系数、Bernstein basis functions 与 falling factorials 均非负。
因此

\[
\boxed{P_V(y)\ge0\qquad(y\ge1).}
\tag{15}
\]

## 4. 第三层正 reciprocal-product RH 门

置

\[
T_V(x)=
\sum_{a,b\le\sqrt x}\mu(a)\mu(b)
P_V\!\left(\frac{x}{ab}\right).
\tag{16}
\]

与 notes 137、139 相同，精确截断卷积和 \(V(u)=O(u^2)\) 给出

\[
T_V(x)=-U_V(x)+O(x^{-1/2}).
\tag{17}
\]

结合 (5)：

\[
\boxed{
\mathrm{RH}
\iff
\forall\varepsilon>0,\quad
T_V(x)\ll_\varepsilon x^{1/2+\varepsilon},}
\tag{18}
\]

并可等价替换为 dyadic \(L^2\) 门。

## 5. 同时删除前三个 odd residues

由 (4)，

\[
\operatorname*{Res}_{s=-1}K_V
=\operatorname*{Res}_{s=-3}K_V
=\operatorname*{Res}_{s=-5}K_V=0.
\tag{19}
\]

负偶数处仍由 zeta trivial zeros 消去。首批非零 odd residues 为

\[
v_7\zeta(-7)
=1792\cdot\frac1{240}
=\frac{112}{15},
\tag{20}
\]

\[
v_9\zeta(-9)
=3200\left(-\frac1{132}\right)
=-\frac{800}{33},
\tag{21}
\]

\[
v_{11}\zeta(-11)
=640\cdot\frac{691}{32760}
=\frac{11056}{819}.
\tag{22}
\]

故

\[
\boxed{
T_V(x)
=\frac{112S_7(z)^2}{15x^7}
-\frac{800S_9(z)^2}{33x^9}
+\frac{11056S_{11}(z)^2}{819x^{11}}
+T_V^{(0)}(x),}
\qquad z=\sqrt x.
\tag{23}
\]

## 6. 次数十二的最小性

设多项式 \(V\) 满足

\[
V(0)=V(1)=\int_0^1V=0,
\qquad
v_1=v_3=v_5=0,
\qquad
P_V(y)\ge0.
\tag{24}
\]

在 shifted Euler--Faulhaber 展开中依次考察
\(k=2,\ldots,7\)。下端项交替由于

\[
V'(0)=0,\ B_3=0,\ V'''(0)=0,\ B_5=0,\
V^{(5)}(0)=0,\ B_7=0
\tag{25}
\]

消失；相应 \(B_k(1-r)\) 均变号。故非负性迫使

\[
V^{(j)}(1)=0\qquad(1\le j\le6).
\tag{26}
\]

于是

\[
\boxed{u^2(1-u)^7\mid V(u).}
\tag{27}
\]

若 \(\deg V\le11\)，写

\[
V=u^2(1-u)^7(a+bu+cu^2).
\tag{28}
\]

\(v_3=v_5=0\) 依次给出

\[
b=7a,\qquad c=16a.
\tag{29}
\]

零均值则给出

\[
0=a\big[B(3,8)+7B(4,8)+16B(5,8)\big]
=\frac{2a}{165}.
\tag{30}
\]

所以 \(a=b=c=0\)。因此

\[
\boxed{
\deg V\le11,\quad
P_V\ge0,\quad
v_1=v_3=v_5=0
\Longrightarrow V=0.}
\tag{31}
\]

次数十二时约束空间为一维，(1) 是其非零代表，并由 (10)--(15) 达到正性。
所以十二次严格最小。

## 7. 边界

前三个 RH-strength collective moments 已被逐项非负 detector 删除，但
\(S_7,S_9,S_{11}\) 仍各自具有 RH 强度。本结果没有证明 RH；它建立了
最小次数序列 \(6,9,12\) 的第三层，并把下一问题压成是否存在一般
\(3(m+1)\) 次 residue-removing 正 detector 层级。
