> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 端点望远镜产生的三点仿射平面不在现有 averaged-Chowla 量词内

日期：2026-08-16。

沿用 note 314 的 \(q\)-差分。乘以端点符号并对 \(1\le q\le Q\) 求和后，出现
\[
T_{U,Q}
=\sum_{q\le Q}\sum_{U<a<2U}
\lambda(a)\lambda(a+q)\lambda(2U+q-1).
\tag{1}
\]
令
\[
x=a,\qquad y=2U+q-1,\qquad C=2U-1.
\]
则第三个因子为 \(\lambda(y)\)，第二个因子为
\(\lambda(x+y-C)\)，所以 (1) 是二维加法平面上的截断三点和
\[
T_{U,Q}
=\sum_{\substack{U<x<2U\\2U\le y\le2U+Q-1}}
\lambda(x)\lambda(y)\lambda(x+y-C).
\tag{2}
\]

## 与已有定理的量词差异

Matomäki--Radziwiłł--Tao 的 averaged-Chowla 定理（
<https://arxiv.org/abs/1503.05121>，Theorem 1.1/1.6）控制的是一条基变量 \(n\) 上的
\[
\sum_{h_1,\ldots,h_k\le H}
\left|\sum_{n\le X}
\prod_j\lambda(a_jn+b_j+h_j)\right|,
\]
即独立移位参数的 \(L^1\) 平均。

式 (1) 不属于这个量词：

1. \(a\) 与 \(q\) 同时运行，形成二维矩形，而不是一个基变量上的一维相关；
2. 三个线性因子是 \(x\)、\(y\)、\(x+y-C\)，其中第三个参数由前两个变量耦合；
3. 若把它强行写成一维移位形式，所需的两个移位落在一条对角切片
   \(h_3=h_2+C\) 上。独立 \((h_2,h_3)\) 的 \(L^1\) 平均不控制这条可能承载异常质量的对角切片。

## 现有定理仍可给出的对数级上界

这里需要区分“完全没有平均控制”和“没有目标尺度的控制”。令
\[
P_Y(q)=\sum_{n\le Y}\lambda(n)\lambda(n+q).
\]
区间恒等式给出
\[
\sum_{U<a<2U}\lambda(a)\lambda(a+q)=P_{2U-1}(q)-P_U(q).
\]
因此，先取绝对值再求和，且 \(10\le Q\le U\) 时，由 MRT 的
Theorem 1.1（<https://arxiv.org/abs/1503.05121>）可得
\[
\begin{aligned}
|T_{U,Q}|
&\le \sum_{q\le Q}\left|P_{2U-1}(q)-P_U(q)\right|\\
&\ll UQ\left(\frac{\log\log(3Q)}{\log(3Q)}
      +\frac1{\log^{1/3000}(3U)}\right).
\end{aligned}
\tag{3}
\]
这说明当 \(Q\to\infty\) 时，现有 averaged-Chowla 确实给出
\(T_{U,Q}=o(UQ)\)。但在宏观范围 \(Q\asymp U\) 时，(3) 仍是
\(U^2\) 量级乘一个对数衰减因子，远未达到端点望远镜所需的
\(U^{1+\varepsilon}\) 级界；而且绝对值步骤丢掉了权
\(\lambda(2U+q-1)\) 的跨移位符号。

因此，现有高阶 averaged-Chowla 不能直接给出本项目需要的
\(U^{1+\varepsilon}\) 级边界。要闭合这一端点望远镜，至少需要一个带截断、带权的二维仿射 Chowla 估计，例如
\[
\sum_{x\in I}\sum_{y\in J}
\lambda(x)\lambda(y)\lambda(x+y-C)
\ll_\varepsilon (|I||J|)^{1/2+\varepsilon}
\]
或一个保留该对角切片符号的等价 arithmetic intertwiner。

这不是把已有定理简单改写即可得到的结论；它是当前 \(q\)-跨尺度路线在三点层面的最小新算术输入。

## 4. 近期相邻文献的边界

Teräväinen--Walker 的 2025 年结果研究了 Liouville 函数沿 Beatty 序列的
对数平均相关，并在若干有理独立条件下给出高阶相关的“99%”型结论；其
Theorem 1.2/1.6 的量词仍是对数平均或 limsup，而不是本式的固定端点矩形
\((x,y)\) 和，也没有给出 \(U^{1+\varepsilon}\) 的幂次界。来源：
<https://link.springer.com/article/10.1007/s00209-025-03770-2>。

因此该结果是相邻的结构性支持，但不能覆盖这里的平行切片
\(x+y-C\)，也不能替代所需的带端点权三点估计。
