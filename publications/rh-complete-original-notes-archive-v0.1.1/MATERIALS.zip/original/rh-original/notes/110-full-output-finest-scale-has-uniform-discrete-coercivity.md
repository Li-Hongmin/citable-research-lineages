> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 完整输出窗上最细尺度具有统一离散 coercivity

日期：2026-08-14。

依赖：
[note 105](105-the-cell-detector-is-zero-free-to-the-imaginary-axis.md)、
[note 109](109-extended-endpoint-sweep-removes-the-high-column-escape.md)。

证据等级：连续 Mellin minimum modulus、阶梯函数的局部 dilation-translation
估计，以及输出采样误差的有界重叠证明。

note 109 将扩展行窗的剩余门归约为 endpoint 主部与正则部的
uniform minimum modulus。本文在完整活动输出窗上闭合该门。
最细一个 block 加零延拓路径能量已足够。

## 1. 精确阶梯嵌入

令

\[
a=\frac23,
\qquad
\mathcal D_Y=\{d\in\mathbb Z:\lceil aY\rceil\le d\le\lfloor2eY\rfloor\},
\tag{1}
\]

并将 \(q:\mathcal D_Y\to\mathbb C\) 在列域外零延拓。记

\[
D_0(q)=\sum_{d\in\mathbb Z}|q(d+1)-q(d)|^2.
\tag{2}
\]

取

\[
J=\lceil\log_2Y\rceil,
\qquad L=2^{-J}\in[1/(2Y),1/Y].
\tag{3}
\]

沿用 note 109 的 \(G_L\)，置 \(A_L=G_L'\)，并定义

\[
B_{N,d}=G_L(d/N)-G_L((d+1)/N),
\qquad (B_Yq)_N=\sum_dB_{N,d}q(d).
\tag{4}
\]

把 \(q\) 嵌入为零延拓阶梯函数

\[
h_Y(u)=q(d),
\qquad d/Y\le u<(d+1)/Y.
\tag{5}
\]

则

\[
\|q\|_{\ell^2}^2=Y\|h_Y\|_{L^2(du)}^2.
\tag{6}
\]

定义

\[
(T_Lh)(x)=-\int_0^\infty A_L(t)h(xt)\,dt.
\tag{7}
\]

当 \(x=N/Y\) 时，\(t\)-cell \([d/N,(d+1)/N)\) 正好映到 (5) 的第 \(d\) 个 cell，故

\[
\boxed{(B_Yq)_N=(T_Lh_Y)(N/Y).}
\tag{8}
\]

没有 floor remainder。令 \(U_Y=\operatorname{supp}h_Y\)，并取完整活动行集

\[
\mathcal N_Y=
\left\{N\ge1:
\left[N/Y,(N+1)/Y\right]\cap
\left[(\inf U_Y)e^{-L},(\sup U_Y)/a\right]
\ne\varnothing
\right\}.
\tag{9}
\]

因 \(\operatorname{supp}A_L\subset[a,e^L]\)，这些 cell 覆盖 \(T_Lh_Y\) 的完整输出支撑，且

\[
\mathcal N_Y\subset[aY-O(1),3eY+O(1)].
\tag{10}
\]

## 2. 连续 minimum modulus

令 \(T_0\) 为以 \(F\) 的分布导数代替 \(A_L\) 的极限算子。
它在 \(L^2(dx/x)\) 上的 Mellin 符号是

\[
m_0(t)=-itK(it).
\tag{11}
\]

note 105 给出

\[
c\min(|t|,1)\le |m_0(t)|\le C\min(|t|,1).
\tag{12}
\]

若 \(p(y)=h(e^y)\)，则 \(p\) 支撑在一个长度固定的区间 \(I\)。由
\(|\widehat p(t)|\le |I|^{1/2}\|p\|_2\)，可选只依赖 \(|I|\) 的 \(\delta>0\)，使

\[
\int_{|t|<\delta}|\widehat p(t)|^2dt
\le\frac12\|p\|_2^2.
\tag{13}
\]

在 \(|t|\ge\delta\) 上，(12) 有正下界。Mellin--Plancherel 因此给出

\[
\boxed{
\|h\|_{L^2(du/u)}^2
\le C_F\|T_0h\|_{L^2(dx/x)}^2.}
\tag{14}
\]

由支撑紧性，加权与不加权范数只相差固定常数，故

\[
\|h\|_{L^2(du)}^2
\le C_F'\|T_0h\|_{L^2(dx)}^2.
\tag{15}
\]

此处不需要 mean-zero：固定紧支撑排除了 \(t=0\) 的常数广义核。

## 3. 局部离散化

### 引理 1（dilation-translation）

对每个固定 \(C_0>0\)，一致于 \(|s|\le C_0/Y\)，

\[
\boxed{
\int|h_Y(e^su)-h_Y(u)|^2du
\le\frac{C}{Y}D_0(q).}
\tag{16}
\]

**证明。** 固定紧支撑上 \(|e^su-u|\le C/Y\)，所以两点所在 cell 的指标最多相差
一个固定整数 \(M\)。对 \(|r|\le M\)，

\[
|q(d+r)-q(d)|^2
\le M\sum_{k\text{ between }d\text{ and }d+r}|q(k+1)-q(k)|^2.
\]

每个 cell 长 \(Y^{-1}\)，每条差分只被有界多个相邻 cell 计数，积分即得 (16)。\(\square\)

### 引理 2（输出采样）

\[
\boxed{
Y\|T_Lh_Y\|_{L^2(dx)}^2
\le C\sum_{N\in\mathcal N_Y}|(T_Lh_Y)(N/Y)|^2+CD_0(q).}
\tag{17}
\]

**证明。** note 109 的 endpoint--regular 分解给出

\[
\|A_L\|_{L^1}\le C_F.
\tag{18}
\]

对 \(x_N=N/Y\le x<(N+1)/Y\)，

\[
|T_Lh_Y(x)-T_Lh_Y(x_N)|^2
\le\|A_L\|_1\int|A_L(t)|
|h_Y(xt)-h_Y(x_Nt)|^2dt.
\tag{19}
\]

对 \(t\in[a,e^L]\)，\(|xt-x_Nt|\le e^L/Y\)，所以只跨过 \(O(1)\) 个输入 cell。
对 \(N\) 求和并对 \(x\) 积分时，每条差分只被有界重数计数；
\(u=xt\) 的 Jacobian 由 \(a\le t\le e^L\) 一致控制。故

\[
Y\sum_{N\in\mathcal N_Y}\int_{x_N}^{x_N+Y^{-1}}
|T_Lh_Y(x)-T_Lh_Y(x_N)|^2dx
\le CD_0(q).
\tag{20}
\]

在每个 cell 上用
\(|T_Lh_Y(x)|^2\le2|T_Lh_Y(x_N)|^2+2|T_Lh_Y(x)-T_Lh_Y(x_N)|^2\)，
即得 (17)。\(\square\)

## 4. 统一离散谱隙

log-dilation 平均的定义给出

\[
T_Lh=\frac1L\int_0^LT_0[h(e^y\,\cdot)]dy.
\tag{21}
\]

为核对 dilation 方向，直接写出

\[
G_L(t)=\frac1L\int_0^LF(te^{-y})dy,
\qquad
G_L'(t)=\frac1L\int_0^Le^{-y}F'(te^{-y})dy
\]

（第二式按分布导数理解）。在 \(T_L\) 中令 \(r=te^{-y}\)，则
\(dt=e^ydr\) 恰好抵消 \(e^{-y}\)，所得输入是 \(h(xe^yr)\)，即 (21)。

\(T_0\) 在 \(L^2\) 上有界，故由 Jensen 与引理 1，

\[
\|T_Lh_Y-T_0h_Y\|_2^2
\le\frac{C}{Y}D_0(q).
\tag{22}
\]

将 (15)、(22)、(17)、(8) 依次合并，得

\[
\begin{aligned}
\|q\|_2^2
&=Y\|h_Y\|_2^2\\
&\le CY\|T_0h_Y\|_2^2\\
&\le CY\|T_Lh_Y\|_2^2+CD_0(q)\\
&\le C\sum_{N\in\mathcal N_Y}|(B_Yq)_N|^2+CD_0(q).
\end{aligned}
\tag{23}
\]

### 定理

存在只依赖 \(F\) 的 \(C>0\)，对所有 \(Y\ge2\) 和所有 \(q:\mathcal D_Y\to\mathbb C\)，

\[
\boxed{
\sum_{d\in\mathcal D_Y}|q(d)|^2
\le C\left(
\sum_{N\in\mathcal N_Y}|(B_Yq)_N|^2+D_0(q)
\right).}
\tag{24}
\]

常数与 \(Y\) 无关。不需要 mean-zero，也不需要任何粗尺度。

## 5. 边界

(24) 是有限离散统一谱隙，不是连续 Mellin frame 的软外推。关键组合是

\[
\text{完整活动输出窗}
+\text{最细 endpoint 尺度}
+\text{零延拓路径能量}.
\]

缩回 \(Y<N\le2Y\) 会重新出现 notes 107--108 的几何逃逸。
\(D_0\) 包含列域两端的 trace；直接代入 Mertens 向量时，这仍是算术代价。
下一个最小门是用慢变截断把 trace 转换为
\(\sum|\mu|^2\) 与可吸收的 \(Y^{-2}\sum|M|^2\)。
