> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 不完全 Möbius residual 的精确调和变换与两端边界

日期：2026-08-17。

本 note 把 note 458 的不完全除数 residual 再写成调和 Möbius 和的精确变换，并与 note 459 的高截断下界合并，得到截断尺度的两端结构性边界。

## 1. 一个精确恒等式

记

$$
S(X):=\sum_{n\le X}\frac{\mu(n)}n,
\qquad
\eta_A(n):=\sum_{\substack{a\mid n\\a>A}}\mu(n/a),
$$

并定义

$$
\mathcal H_A(X):=
\sum_{A<n\le X}\frac{\eta_A(n)}n
\qquad (1\le A<X).
$$

交换 \(n=aj\) 的求和顺序，得到

$$
\mathcal H_A(X)
=\sum_{A<a\le X}\frac1a
\sum_{j\le X/a}\frac{\mu(j)}j.
\tag{1}
$$

另一方面，完整的除数 Möbius 反演给出

$$
\sum_{a\le X}\frac1a S\!\left(\left\lfloor\frac Xa\right\rfloor\right)
=\sum_{n\le X}\frac1n\sum_{a\mid n}\mu(n/a)=1.
\tag{2}
$$

相减即得

$$
\boxed{
\mathcal H_A(X)
=1-\sum_{a\le A}\frac1a
S\!\left(\left\lfloor\frac Xa\right\rfloor\right).
}
\tag{3}
$$

这是有限整数恒等式，不需要 RH 或平均估计。

## 2. 任意 residual 行都是两个变换值之差

令 \(M_d=\lfloor N/d\rfloor\)，并令

$$
L_{d,k}:=\max\!\left(A,\left\lfloor\frac kd\right\rfloor\right).
$$

由于 \(\eta_A(n)\) 只在 \(n>A\) 处出现，note 458 式 (3) 中的标量 residual 恰为

$$
\sum_{L_{d,k}<n\le M_d}\frac{\eta_A(n)}n
=\mathcal H_A(M_d)-\mathcal H_A(L_{d,k}).
\tag{4}
$$

代入 (3)，常数项 \(1\) 消掉，得到完全显式的跨尺度公式

$$
\boxed{
\sum_{L_{d,k}<n\le M_d}\frac{\eta_A(n)}n
=
\sum_{a\le L_{d,k}}\frac1a
S\!\left(\left\lfloor\frac{L_{d,k}}a\right\rfloor\right)
-
\sum_{a\le M_d}\frac1a
S\!\left(\left\lfloor\frac{M_d}a\right\rfloor\right).
}
\tag{5}
$$

因此，截断链 residual 不是一个未定义的“边界项”，而是两个不同尺度的除数—调和变换之差。

## 3. 固定小截断的 residual 不会变小

若 \(A\) 固定而 \(X\to\infty\)，素数定理给出 \(S(X/a)\to0\) 对每个固定 \(a\)。由 (3)，

$$
\boxed{\mathcal H_A(X)\longrightarrow1\qquad(A\ \text{固定}).}
\tag{6}
$$

特别地，\(A=1\) 时有精确公式

$$
\mathcal H_1(X)=1-S(X).
\tag{7}
$$

所以把倍数链截在固定深度并不能产生小 residual；其 \(k=1\) 行贡献趋向 \(\sqrt3/d\)，而不是趋向零。更一般地，任何希望让 (4) 小的方案都必须让 \(A\) 随 \(M_d\) 增长，并控制变换 (5) 在两个相邻尺度上的 signed 差。

## 4. 与高截断边界合并

note 459 已证明：若 \(A>M_d/2\)，则

$$
\eta_A(n)=1\qquad(A<n\le M_d),
$$

并且

$$
\|\mathcal R_{d,A}\|_2^2
\ge\frac3{d^2}(H_{M_d}-H_A)^2.
\tag{8}
$$

因此有如下两端结论：

* \(A\) 固定（或保持很小）时，式 (6) 给出 residual 的确定性 \(1\)-级边界；
* \(A>M_d/2\) 且与 \(M_d\) 保持固定比例时，式 (8) 给出同号调和尾下界。

剩余的唯一可能区间是中间截断 \(A\to\infty\) 且 \(A\le M_d/2\)。在此区间，(5) 显示必须证明两个不同尺度的除数—调和变换之间的统一 signed cancellation；逐项绝对值、正 Gram 或单条链的 Cauchy 都不能完成它。

本 note 是精确的算术重写与两端 no-go，不是 RH 证明。若能在中间区间把 (5) 的平方加权和压到 \(N^{1+\varepsilon}\)，那将进入 notes 212、246 所述的 RH-strength 门。
