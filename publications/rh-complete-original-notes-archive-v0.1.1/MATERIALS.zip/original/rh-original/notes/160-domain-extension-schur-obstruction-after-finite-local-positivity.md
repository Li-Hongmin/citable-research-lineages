> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有限局部 Weil 正性不能自动拼接到更大支撑

日期：2026-08-15。

当前严格端点为
\[
a_*={1\over2}\log(201/20),
\qquad A_{a_*}\succ0.
\]
一个自然但错误的全尺度推进想法是：把更大区间的算子按旧区间与新增环带分块，
然后用旧块与环带块的正性推出整体正性。本 note 给出该想法的精确首断点。

## 1. 精确块条件

对 (b>a)，令
\[
H_b=H_a\oplus H_{\rm ann},
\qquad H_{\rm ann}=H_b\ominus H_a,
\]
并将 (A_b) 写成
\[
A_b=
\begin{pmatrix}
A_a&C\\ C^*&D
\end{pmatrix}.
\tag{1}
\]
若 (A_a\succ0)，则 Schur 补给出严格等价条件
\[
\boxed{
A_b\succeq0
\iff
D-C^*A_a^{-1}C\succeq0.}
\tag{2}
\]
因此 (A_a\succeq0) 与 (D\succeq0) 本身完全不够；新增环带与旧区间的 signed
prime cross (C) 必须被定量控制。

## 2. 最小 signed-reflection 反例

一个新 prime-power reflection 在两个相邻局部坐标上的精确 cross 块为
\[
B_n^\sigma=\pm p_n
\begin{pmatrix}0&1\\1&0\end{pmatrix},
\qquad
p_n={\Lambda(n)\over\sqrt n}.
\tag{3}
\]
即使两个对角自项分别为 (d_i,d_j>0)，总块
\[
\begin{pmatrix}d_i&\pm p_n\\ \pm p_n&d_j\end{pmatrix}
\]
的行列式仍为
\[
d_id_j-p_n^2,
\tag{4}
\]
当 (p_n^2>d_id_j) 时严格为负。最小抽象例是
\[
\begin{pmatrix}1&2\\2&1\end{pmatrix},
\]
其负特征值为 (-1)。这排除了“旧区间正性 + 新环带正性 + 普通 block 拼接”
这一无条件推理。

## 3. 对当前端点的实际首断点

令 \(d=\log11\)，并把半区间支撑写成 \([0,b]\)。新 reflection 的几何作用是
\[
J_{11,b}f(x)=\mathbf1_{[d-b,b]}(x)f(d-x).
\]

从 \(a_*=\frac12\log(201/20)\) 增大到
\[
a_{11}=\frac12\log11=d/2
\]
在 \(a_{11}\) 处只有端点 activation，没有正测度 overlap。对
\[
a_{11}<b<d-a_*
\]
其 reflection 完全落入新增环带 \(Q\)，仍有 \(P J_{11}Q=0\)；只有当
\(b>d-a_*\) 时才产生旧区间与新环带之间的真实 cross。此时
\[
\|P J_{11}Q\|=1,\qquad
p_{11}=\frac{\log11}{\sqrt{11}}=0.7229926278581\ldots,
\]
而 \(P J_{11}P=0\)。因此必须在 (2) 中控制 \(b>d-a_*\) 之后的 signed
reflection cross，不能由已有 \(A_{a_*}\succ0\) 或新增环带的对角正性推出。

当前端点 true-Schur 证书的最小 pivots 已降到约
\[
6.1\times10^{-44}\quad\text{(even)},
\qquad
5.6\times10^{-40}\quad\text{(odd)},
\]
所以直接用 (A_{a_*}^{-1}) 支付新 cross 没有稳定预算。正 Yukawa 尾的
Parseval covariance 可以保留，但 signed prime/polar cross 不具 PSD 结构。

## 4. 反射块可保留的精确恒等式

把新 reflection 写成半区上的 partial reflection
\(I_n=[\max(0,d_n-b),\min(b,d_n)]\)，则 \(J=J^*\)、\(J^2=P_{I_n}\)；
它不是整个 \(H_b\) 上的 involution。按同一分解写成
\[
J=\begin{pmatrix}J_{PP}&J_{PQ}\\J_{QP}&J_{QQ}\end{pmatrix}.
\]
由 partial reflection 的 \(J^2=P_{I_n}\) 的 \(P\)-(P\) 块，得到
\[
J_{PQ}J_{QP}=P P_{I_n}P-J_{PP}^2\succeq0.
\tag{5}
\]
因此新 prime cross \(C=\pm p_nJ_{PQ}\) 满足精确关系
\[
\boxed{CC^*=p_n^2(PP_{I_n}P-J_{PP}^2).}
\tag{6}
\]
只有在 \(P_{I_n}=I\) 的全支撑特殊情形下，(6) 才能简写成
\(p_n^2(I_P-J_{PP}^2)\)；本地 partial reflection 一般不满足该特殊情形。
这说明该 cross 不是任意矩阵；若将完整 \(J\) 块与其它 signed prime blocks
联合保留，(6) 是可用的 Schur/resolvent 接口。它仍不推出正性，因为不同 prime
involution 之间的 cross 没有共同 PSD Gram 结构。

## 5. 结论

有限端点正性向全尺度推进的最小新命题不是“继续增加正 Yukawa 原子”，而是
\[
\boxed{
D-C^*A_a^{-1}C\succeq0
\quad\text{对每个新 prime activation 及其全部后续 cross}.}
\]
这已经是一个全局 signed arithmetic/Weil intertwiner 问题；局部 Loewner 正性、
普通 Toeplitz 拼接和有限秩 Schur 正性均不能替代它。

本文是严格的路线边界，不是 RH 证明。
