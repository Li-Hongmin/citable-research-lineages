> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 聚合 deficit 在临界核中的对数障碍

日期：2026-08-11。

本文求出 Robin deficit 聚合权重的尖锐量级，并证明 note 031 后剩余的 weak-Schatten/dyadic
权重本身仍不足以闭合统一 frame 不等式。

## 1. 聚合权重

固定 \(a>0\) 与一个奇偶扇区。令

\[
d_{n,j}=\ell_{n,M}-\ell_{n,j},
\qquad
q_{M,j}=\sum_{n\ge0}d_{n,j},
\qquad 0\le j<M.
\]

写

\[
b=b_n=n+\frac14,
\qquad
x_{n,r}=\mu_{n,r}^2.
\]

由 Yukawa 本征值公式，

\[
\boxed{
d_{n,j}
=\frac{4b(x_{n,M}-x_{n,j})}
{(4b^2+x_{n,M})(4b^2+x_{n,j})}.}
\tag{1}
\]

Robin 根的标准隔离区间给出

\[
x_{n,r}\asymp_a(r+1)^2,
\]

\[
x_{n,M}-x_{n,j}
\asymp_a(M-j)(M+j+1).
\]

因此

\[
d_{n,j}\asymp_a
\frac{b((M+1)^2-(j+1)^2)}
{(b^2+(M+1)^2)(b^2+(j+1)^2)}.
\tag{2}
\]

对应连续积分满足

\[
\int_0^\infty
\frac{b(A^2-B^2)}
{(b^2+A^2)(b^2+B^2)}\,db
=\log(A/B).
\tag{3}
\]

离散积分比较遂给出尖锐双边界

\[
\boxed{
q_{M,j}
\asymp_a
\log\frac{M+1}{j+1}.}
\tag{4}
\]

特别地，

\[
q_{M,j}\asymp_a
\begin{cases}
\log M,&j=O(1),\\
\log(M/(j+1)),&1\ll j\le M/2,\\
(M-j)/M,&M-j=o(M),
\end{cases}
\tag{5}
\]

并且

\[
\sum_{j<M}q_{M,j}\asymp_a M.
\tag{6}
\]

## 2. Positive majorant 必然损失两个对数

令 \(Q_M=\operatorname{diag}(q_{M,j})\)，考虑临界正核

\[
H^+_{jk}
=\frac1{1+|j-k|}
+\frac1{1+j+k}.
\]

取前 \(L=\lfloor\sqrt M\rfloor\) 个指标。在该块上 \(q_{M,j}\gtrsim_a\log M\)，而
\((1+|j-k|)^{-1}\) 的常向量 Rayleigh 商为 \(\asymp\log L\)。另一方面，最大权重为
\(O_a(\log M)\)，Toeplitz majorant 的最大行和为 \(O(\log M)\)，Hilbert--Hankel 矩阵范数为
\(O(1)\)。故

\[
\boxed{
\|Q_M^{1/2}H^+Q_M^{1/2}\|
\asymp_a(\log M)^2.}
\tag{7}
\]

所以绝对值 majorization 不能用于统一 frame 闭合。

## 3. Hilbert cancellation 仍留下一个对数

对真正具有奇对称 cancellation 的离散 Hilbert 核

\[
H^{\rm Hil}_{jk}
=
\begin{cases}
(j-k)^{-1},&j\ne k,\\
0,&j=k,
\end{cases}
\]

未加权算子在 \(\ell^2\) 上一致有界，故

\[
\|Q_M^{1/2}H^{\rm Hil}Q_M^{1/2}\|
\lesssim_a\log M.
\]

但 \(j=0,1\) 的 \(2\times2\) 主块已有非对角元

\[
\sqrt{q_{M,0}q_{M,1}}\asymp_a\log M.
\]

因此

\[
\boxed{
\|Q_M^{1/2}H^{\rm Hil}Q_M^{1/2}\|
\asymp_a\log M.}
\tag{8}
\]

Hankel 核 \((1+j+k)^{-1}\) 的加权范数同样为 \(\Theta_a(\log M)\)，其 \(00\) 元已经达到该量级。

## 4. Lorentz 信息为何不足

由 (4)，

\[
\#\{j:q_{M,j}>t\}
\asymp_a Me^{-c_at}
\tag{9}
\]

在自然参数区间内成立。大权重确实只集中于低指标，但最大权重仍为 \(\Theta_a(\log M)\)；
固定低维主块已经强制 (8)。因此 weak-Schatten/Lorentz 计数不能单独改善 operator norm。

## 5. 对 A3 的裁决

以下三条路线均已关闭：

\[
\text{无权 \(n-m\) 衰减},
\qquad
\text{绝对值临界 majorant},
\qquad
\text{仅靠 Hilbert cancellation}.
\]

若要得到 \(O(1)\) 或 \(o(1)\) 的 frame 余量，必须先对随 \(M\) 增长的低-\(j\) 扇区做精确
Feshbach/Schur 消元，再在剩余高频块使用振荡或绝对估计：

\[
\boxed{
\text{low-mode exact Schur}
\;+\;
\text{high-mode weighted bound}.}
\tag{10}
\]

这不是技术偏好，而是由 (4)、(7)、(8) 强制的必要结构。

这里的增长陈述针对 raw critical kernel。note 024 的真实 metric 还包含

\[
E_M^{-1}\sim \alpha_M^{-1}I,
\qquad
\alpha_M\asymp\log M.
\]

因此真正待判定的对象是重整化权重

\[
r_{M,j}=\frac{q_{M,j}}{\alpha_M}
\asymp_a
\frac{\log((M+1)/(j+1))}{\log M}.
\tag{11}
\]

固定 \(j\) 时 \(r_{M,j}\) 不趋零，故低模仍然承重；但 (7)--(8) 不能直接用来判断完整
\(E_M^{-1}\) metric 中的最终常数或 \(1/\log M\) 修正。下一步必须先识别该重整化极限，不能把
raw \(\log M\) 增长误报为 frame 不等式本身失败。
