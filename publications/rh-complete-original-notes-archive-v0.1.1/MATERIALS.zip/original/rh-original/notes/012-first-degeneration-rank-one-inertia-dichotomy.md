> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 第一次退化的秩一惯性分类：可见 Schur 模态与不可见零核

日期：2026-08-11。本文把 notes 007--008 的奇偶秩一分解与约化基态定理施加到任意首次退化尺度，
完整分类零模态的两种机制。结论是：现有 Markov、严格正基态和奇扇区谱隙尚不足以把第一次退化
压缩为单个 Schur 标量；唯一遗漏机制是秩一向量看不见的约化零核。

## 1. 首次退化设定

设 \(a_*\) 是 RH 失败所产生的首次退化尺度。由 notes 001、003 与 006，

\[
A_{a_*}\succeq0,
\qquad
\ker A_{a_*}\ne\{0\}.
\]

省略下标 \(a_*\)，并记

\[
c=\cosh(x/2),\qquad s=\sinh(x/2).
\]

由 note 007，

\[
A^+=M^++2|c\rangle\langle c|,
\qquad
A^-=M^--2|s\rangle\langle s|.
\]

由 note 008，\(M\) 的全局谱底简单、基态严格正且为偶函数，并且

\[
\mu_1(M^+)<\mu_1(M^-).
\]

以下分类只用这些已证输入与秩一惯性公式。

## 2. 奇扇区：正约化算子减去负秩一

假设

\[
A^-=M^--2|s\rangle\langle s|\succeq0.
\]

立即有

\[
\boxed{M^-=A^-+2|s\rangle\langle s|\succeq0.}
\]

令

\[
K_-:=\ker M^-.
\]

若 \(u\in K_-\)，则

\[
0=\langle M^-u,u\rangle
=\langle A^-u,u\rangle+2|\langle u,s\rangle|^2.
\]

两项均非负，故

\[
\boxed{
K_-=\ker A^-\cap s^\perp.}
\]

特别地，\(M^-\) 的全部零核都自动是不可见零模态。

在 \(K_-^\perp\) 上 \(M^-\) 严格正且可逆。令

\[
g=(M^-|_{K_-^\perp})^{-1}s=(M^-)^\dagger s,
\qquad
\beta=2\langle s,g\rangle.
\]

则

\[
\boxed{
A^-\succeq0
\iff
M^-\succeq0,quad s\perp K_-,quad \beta\le1,}
\]

且

\[
\boxed{
\ker A^-=
\begin{cases}
K_-,&\beta<1,\\[1mm]
K_-\oplus\operatorname{span}\{g\},&\beta=1.
\end{cases}}
\]

因此奇扇区有两个互斥机制：

```mermaid
flowchart TD
    A["A⁻ ⪰ 0 且 ker A⁻ ≠ 0"] --> K{"K⁻ = ker M⁻?"}
    K -->|"K⁻ ≠ 0"| I["不可见零核：K⁻ ⊂ s⊥"]
    K -->|"K⁻ = 0"| S["M⁻ > 0"]
    S --> E["β = 1：可见 Schur 零模态"]
```

只有在 \(K_-=0\) 时，通常的标量方程

\[
1-2\langle s,(M^-)^{-1}s\rangle=0
\]

才完整刻画奇扇区退化。

## 3. 偶扇区：一个负方向被正秩一抬升

现在假设

\[
A^+=M^++2|c\rangle\langle c|\succeq0,
\qquad
\ker A^+\ne\{0\}.
\]

对任意 \(v\perp c\)，

\[
\langle M^+v,v\rangle=\langle A^+v,v\rangle\ge0,
\]

故任意负子空间维数至多为一：

\[
n_-(M^+)\le1.
\]

若 \(M^+\succeq0\)，取 \(0\ne v\in\ker A^+\) 得

\[
v\in\ker M^+\cap c^\perp.
\]

此时 \(0\) 是 \(M\) 的全局谱底；note 008 说明其核由严格正偶基态 \(\varphi\) 张成。但

\[
\langle\varphi,c\rangle>0,
\]

矛盾。因此

\[
\boxed{n_-(M^+)=1.}
\]

令

\[
K_+:=\ker M^+.
\]

若某个 \(k\in K_+\) 满足 \(\langle k,c\rangle\ne0\)，可用它与唯一负基态作线性组合，消去
\(c\)-矩而保留严格负的 \(M^+\)-能量，这与 \(A^+\succeq0\) 矛盾。故

\[
\boxed{c\perp K_+.}
\]

在 \(K_+^\perp\) 上令

\[
w=(M^+)^\dagger c,
\qquad
F=1+2\langle w,c\rangle.
\]

秩一惯性公式给出

\[
\boxed{F\le0,}
\]

及

\[
\boxed{
\ker A^+=
\begin{cases}
K_+,&F<0,\\[1mm]
K_+\oplus\operatorname{span}\{w\},&F=0.
\end{cases}}
\]

不可见偶零模态 \(0\ne k\in K_+\) 与严格正基态正交，因而必变号。可见 Schur 零模态 \(w\)
则不一定变号，不能由 \(c>0\) 或约化基态正性排除。

## 4. 抽象假设确实不能排除不可见核

下面的四维模型同时保留 parity、约化半群 positivity improving、简单严格正偶基态、严格奇扇区
谱隙和完整形式半正定。

在 \(\mathbb R^4\) 中取正交基

\[
\varphi=\tfrac12(1,1,1,1),
\qquad
\psi=\tfrac12(1,1,-1,-1),
\]

\[
h=\tfrac12(1,-1,1,-1),
\qquad
k=\tfrac12(1,-1,-1,1),
\]

前两者为偶，后两者为奇。定义

\[
M\varphi=-\varphi,
\quad M\psi=2\psi,
\quad Mh=3h,
\quad Mk=0,
\]

并令 \(c=\varphi\)、\(s=h\)。标准基下

\[
M=
\begin{pmatrix}
1&-1/2&0&-3/2\\
-1/2&1&-3/2&0\\
0&-3/2&1&-1/2\\
-3/2&0&-1/2&1
\end{pmatrix}.
\]

其非对角元非正且耦合图连通，所以 \(e^{-tM}\) positivity improving；唯一 ground state
\(\varphi>0\) 为偶函数，并且

\[
\mu_1(M^+)=-1<0=\mu_1(M^-).
\]

另一方面

\[
A^+=M^++2|c\rangle\langle c|,
\qquad
A^-=M^--2|s\rangle\langle s|
\]

的扇区本征值分别为

\[
\sigma(A^+)=\{1,2\},
\qquad
\sigma(A^-)=\{0,1\}.
\]

故 \(A\succeq0\)，但

\[
\boxed{
\ker A^-=\ker M^-=\operatorname{span}\{k\}
\subset s^\perp.}
\]

该模型证明：note 008 的全部抽象结论仍不能排除纯不可见首次零模态。单独计算伪逆 Schur 量也无法
检测它。

## 5. 正确的下一分叉

要把首次退化真正压缩为标量方程，必须先证明零谱 cyclicity：

\[
\boxed{
\ker M^\pm\cap\phi_\pm^\perp=\{0\},
\qquad \phi_+=c,\ \phi_-=s.}
\]

更强的“\(\phi_\pm\) 为 \(M^\pm\) 的 cyclic vector”足够，但并非必要；这里只需要零谱层面的
cyclicity。

另一个可能更便宜的单一不等式是，在首次退化尺度证明

\[
\boxed{\mu_1(M^+)\ge0.}
\]

因为 note 008 的严格扇区谱隙随后给出

\[
\mu_1(M^-) > \mu_1(M^+)\ge0,
\]

从而 \(M^->0\)。同时 \(M^+\succeq0\) 会使 \(A^+\) 严格正，故首次零模态只能位于奇扇区并满足
通常 Schur 方程。

若该符号不成立，则最终必须分别证明

\[
\ker M^\pm\cap\phi_\pm^\perp=\{0\}
\]

以及严格 Schur 非消失/符号。Cyclicity 文献中关于“几乎所有秩一参数”的一般定理不能替代这里固定
向量、固定参数、全部尺度的结论。

## 6. 能够推出与不能推出的内容

本文严格推出：

1. 首次退化时奇扇区 \(M^-\) 必半正定；
2. 偶扇区若退化，则 \(M^+\) 恰有一个负方向；
3. 两扇区零核均分成不可见约化核与至多一个可见 Schur 模态；
4. 现有 positivity-improving 与奇偶谱隙不足以排除不可见核。

本文没有推出：

- 首次零模态必在奇扇区；
- \(M^\pm\) 在零点可逆；
- \(c,s\) 的零谱 cyclicity；
- 任一 Schur 函数全尺度非消失；
- RH。

## 7. 文献边界

本分类本质上是 rank-one inertia 与 Moore--Penrose Schur complement 的直接推论。相关一般背景可见
Barry Simon, *Trace Ideals and Their Applications*, 2nd ed., Chapters 11--12；固定向量的 rank-one
cyclicity 背景可见 Abakumov--Liaw--Poltoratski, *Cyclicity in rank-one perturbation problems*,
[arXiv:1111.3095](https://arxiv.org/abs/1111.3095)。后者证明的泛型参数结论不解决本项目要求的固定
\(M_a^\pm\)、固定 \(c,s\)、全尺度 cyclicity。
