> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 低频 RKHS 评价常数至少有对数损失

日期：2026-08-15。

本 note 给出一个严格的局部 Gram 下界。它不提供 Möbius signed cancellation，
但排除了把低频评价常数误认为 \(O(1)\) 的路线；最优的后续目标至少应允许
一个 \(\log N\) 因子。

## 1. 低频 Gram 与评价常数

设 \(w\) 在 \([-\delta,\delta]\) 上满足 \(0<c_0\le w(t)\le C_0\)，并令
\[
G_{m,n}=\frac1{2\pi}\int_{-\delta}^{\delta}w(t)(m/n)^{it}\,dt,\qquad 1\le m,n\le N.
\]
对 \(\mathbf 1=(1,\ldots,1)^T\)，记
\[
Q_N=\mathbf 1^*G^{-1}\mathbf 1
\]
（若 \(G\) 退化则取 Moore--Penrose 逆）。有限维 Cauchy--Schwarz 给出
\[
|\mathbf 1^*a|^2\le Q_N\,a^*Ga.
\tag{1}
\]
因此 \(Q_N^{-1}\) 是在约束 \(\sum a_n=1\) 下的最小低频能量。

## 2. 一个显式近极小向量

取
\[
H_N=\sum_{n\le N}\frac1n,\qquad a_n=\frac1{nH_N}.
\]
则 \(\mathbf 1^*a=1\)，而
\[
F_N(t)=\sum_{n\le N}a_n n^{it}
=\frac1{H_N}\sum_{n\le N}n^{-1+it}.
\]
Euler--Maclaurin（或一次积分分部）在固定 \(|t|\le\delta\) 上给出一致估计
\[
\sum_{n\le N}n^{-1+it}=\frac{N^{it}-1}{it}+O_\delta(1),
\tag{2}
\]
其中 \(t=0\) 按连续值解释为 \(\log N+O(1)\)。故
\[
\left|\sum_{n\le N}n^{-1+it}\right|\ll_\delta \min(\log N,|t|^{-1})+1.
\]
于是
\[
\int_{-\delta}^{\delta}|F_N(t)|^2\,dt\ll_\delta\frac1{\log N}.
\tag{3}
\]
由 \(w\le C_0\)，同一向量满足
\[
a^*Ga\ll_{w,\delta}\frac1{\log N}.
\]
结合 (1) 的极小能量刻画，得到
\[
\boxed{Q_N\gg_{w,\delta}\log N.}
\tag{4}
\]

## 3. 对平方根门的含义

因此低频正能量不可能给出无损的
\(|M(N)|^2\ll E_N(w)\)；至少存在一个对数级评价损失。若能进一步证明
\[
Q_N\ll_{w,\delta}(\log N)^A
\]
（特别是 \(A=1\)），则正能量门
\(E_N(w)\ll N^{1+\varepsilon}\) 仍会推出
\(M(N)\ll N^{1/2+\varepsilon}\)，因为对数因子可吸收到
\(N^\varepsilon\) 中。当前缺口不是这一下界，而是该评价常数的统一上界，
以及更根本的 \(E_N(w)\ll N^{1+\varepsilon}\) Möbius-specific signed estimate。

本文只给出低频 Gram 的必要尺度，不把有限维数值外推为定理。

## 4. 高精度有限维探针：评价常数可能是线性而非对数

为检验第 3 节中“或许 \(Q_N\ll(\log N)^A\)”的可行性，直接用
\[
G_{m,n}=\frac{2\sin(\log(m/n))}{\log(m/n)}
\]
（对角元取 \(2\)）并以 180 位十进制精度求解
\(G^{-1}\mathbf 1\)。在 \(\delta=1\) 时得到
\[
\begin{array}{c|c|c}
N&Q_N&Q_N/N\\ \hline
8&2.4025152264&0.3003144\\
12&3.6716306937&0.3059692\\
16&4.9425845629&0.3089115\\
20&6.2143524421&0.3107176\\
24&7.4865583285&0.3119399\\
28&8.7590289897&0.3128225\\
32&10.0316727310&0.3134898
\end{array}
\]
复现实验为
[check_low_frequency_evaluation_gram.py](../computations/check_low_frequency_evaluation_gram.py)。
这不是渐近定理，但它否定了把评价常数当作“显然只有对数损失”的数值直觉；
若 \(Q_N\) 的线性尺度在理论上成立，则低频 RKHS 评价路线本身不能把
正能量门直接转成 Mertens 平方根界。后续若要使用该路线，必须先证明一个
真正的 Christoffel/非谐指数系统上界，而不能从有限频段的 PSD 性质推断。

补充的高精度有限探针（同一 δ=1 归一化）为

\[
\begin{array}{c|c|c}
N&Q_N&Q_N/N\\ \hline
40&12.5772860906075872&0.3144321523\\
48&15.1231645251811169&0.3150659276\\
56&17.6692013549849514&0.3155214528\\
64&20.2153406785736674&0.3158646981
\end{array}
\]

其中 (N=64) 的数值在 320、400、500 位精度下相同至显示位数。
这只加强有限维诊断；它既不能证明 (Q_N\asymp N)，也不能替代对
非谐指数系统评价常数的解析估计。
