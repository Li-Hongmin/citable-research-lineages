> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 两素数展开补足 reciprocal-even universal no-go

本 note 补足 note 386 第 3 节中两素数极限的完整展开。设 r、q 为互异素数，
X = rq，并写

$$
Qφ(X) = Σ_{a,b∣X} μ(a) μ(b) φ(ab/X).
$$

逐项列出 1、r、q、rq 四个除数，得到精确恒等式

$$
\begin{aligned}
Qφ(rq)={}&φ((rq)^{-1})-2φ(q^{-1})-2φ(r^{-1})
 +φ(q/r)+φ(r/q)\\
&+4φ(1)-2φ(r)-2φ(q)+φ(rq).
\end{aligned}
$$

在 note 386 的假设 φ(u) → 0（u ↓ 0 与 u → ∞）下，素数尺度

$$
Qφ(p)=φ(p^{-1})-2φ(1)+φ(p)
$$

与 universal 非负性及大素数反射递推共同给出 φ(1)=0。因此若
rⱼ、qⱼ → ∞ 且 rⱼ/qⱼ → u ∈ (0,∞)，由上式直接得到

$$
0=\lim_{j\to\infty} Qφ(rⱼqⱼ)=φ(u)+φ(1/u).
$$

这严格补足 note 386 的两素数极限：被省略的项分别由两端衰减消失，
而 4φ(1) 由素数基例先行消失，并非默认不存在。

## 结论

note 386 的 universal Möbius positivity 定理在两端趋零的连续核类中不需要
额外正则性；其 reciprocal-even 部分必为零。若核本身 reciprocal-even，则核恒为零；
若核 reciprocal-odd，则完整 Möbius 二次型恒看不见该部分。该补 note 只修补
展开的显式审计，不改变 note 386 的结论，也不声称 RH。
