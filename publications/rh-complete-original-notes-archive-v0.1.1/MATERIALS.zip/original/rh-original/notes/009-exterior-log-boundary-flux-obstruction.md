> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 外侧 logarithmic flux：非零边界系数排除谱底平台

日期：2026-08-11。本文把 note 008 的“边界非退化可以排除 collar 基态”变成带精确常数的定理。
在一维，零延拓函数的 logarithmic Laplacian 在支撑端点外就是 Cauchy 型积分。若内侧边界轮廓有
非零的 signed \(\ell(d)^{1/2}\) 主系数，则外侧值以 \(2/\sqrt{\ell(t)}\) 发散，不能满足较大区间
内具有有界右端的 Weil 本征方程。

## 1. 一维外侧公式

标准 logarithmic Laplacian 的一维积分表示中

\[
c_1=\pi^{-1/2}\Gamma(1/2)=1.
\]

设 \(u\in L^\infty(\mathbb R)\) 支撑在 \([-a,a]\)。对 \(t>0\)，点 \(a+t\) 与支撑有正距离，
Chen--Weth 的积分公式无需主值，且 \(u(a+t)=0\)。近场与远场两项合并为

\[
\boxed{
L_\Delta u(a+t)
=-\int_{-a}^{a}\frac{u(y)}{a+t-y}\,dy.}
\]

令 \(s=a-y\)，把靠近右端点的部分写成

\[
-\int_0^\delta\frac{u(a-s)}{t+s}\,ds.
\]

远离端点的积分在 \(t\downarrow0\) 时一致有界，所以全部奇性都由这个局部 Stieltjes 积分决定。

## 2. Abel 型边界渐近

仍记

\[
\ell(s)=\frac1{|\log(\min\{s,0.1\})|}.
\]

**命题 1（signed 边界系数到外侧 flux）。** 若存在 \(\beta_+\in\mathbb R\)，使

\[
\lim_{s\downarrow0}\frac{u(a-s)}{\ell(s)^{1/2}}=\beta_+,
\]

则

\[
\boxed{
\lim_{t\downarrow0}
\ell(t)^{1/2}L_\Delta u(a+t)=-2\beta_+.}
\]

**证明。** 对充分小的 \(s\)，\(\ell(s)^{1/2}=1/\sqrt{\log(1/s)}\)。主模型积分为

\[
J(t)=\int_0^\delta
\frac{ds}{(t+s)\sqrt{\log(1/s)}}.
\]

令 \(T=\log(1/t)\)、\(r=\log(1/s)\)，则

\[
J(t)=\int_{\log(1/\delta)}^\infty
\frac{r^{-1/2}}{1+e^{r-T}}\,dr.
\]

缩放 \(r=Tq\) 后，被积函数在 \(0<q<1\) 上趋于 \(q^{-1/2}\)，在 \(q>1\) 上指数衰减；因此

\[
J(t)\sim \sqrt T\int_0^1q^{-1/2}\,dq=2\sqrt T
=\frac2{\ell(t)^{1/2}}.
\]

把 \(u(a-s)=\bigl(\beta_++o(1)\bigr)/\sqrt{\log(1/s)}\) 代入；对任意 \(\varepsilon>0\)，
余项在足够小的端点邻域由 \(\varepsilon J(t)\) 控制，邻域外贡献一致有界。再乘
\(\ell(t)^{1/2}\) 即得结论。\(\square\)

左端点同理。若

\[
\lim_{s\downarrow0}\frac{u(-a+s)}{\ell(s)^{1/2}}=\beta_-,
\]

则按从左外侧趋近的相同约定，得到

\[
\boxed{
\lim_{t\downarrow0}
\ell(t)^{1/2}L_\Delta u(-a-t)=-2\beta_-.}
\]

符号与右端相同，因为外侧公式仍是负的正距离核积分。

## 3. 更弱的单符号下界也足够

不必预先知道极限存在。若对某个 \(\delta,c>0\) 和 \(\sigma\in\{-1,1\}\)，

\[
\sigma u(a-s)\ge c\ell(s)^{1/2}
\qquad(0<s<\delta),
\]

则同一计算给出

\[
-\sigma L_\Delta u(a+t)
\ge \frac{2c+o(1)}{\ell(t)^{1/2}}-O(1),
\]

所以 \(L_\Delta u\) 在外侧无界。特别地，任何非零 signed 边界系数都蕴含这个结论。

这里不能仅凭“\(u\ge0\)”援引现有 Hopf 引理。Hernández-Santamaría--López Ríos--Saldaña 的
Theorem 1.4 还假设 \(\mathcal E_L(u,\phi)\ge0\) 对所有非负试验函数成立；完整 Weil 零模态的
光滑卷积项目前没有这个符号。

## 4. 对谱底平台的无条件必要条件

假设 \(0<a<b\) 且 \(\lambda_1(a)=\lambda_1(b)\)。由 note 008，\(A_a\) 的某个归一化基态
\(v_a\) 零延拓后是 \(A_b\) 的基态，并在 \((a,b)\cup(-b,-a)\) 上为零。

note 007 给出 \(v_a\in L^\infty\)。在右 collar 上，较大区间本征方程化为

\[
L_\Delta v_a=2P_bv_a+2R_bv_a.
\]

右端有界：有限平移保持 \(L^\infty\)，连续核 \(R_b\) 把 \(L^2\) 映到 \(L^\infty\)。所以

\[
\sup_{0<t<b-a}|L_\Delta v_a(a+t)|<\infty.
\]

命题 1 立即给出：只要相应 signed 边界系数存在，就必须满足

\[
\boxed{\beta_+=0.}
\]

左端同理，\(\beta_-=0\)。更一般地，平台基态在任一端都不可能满足固定符号的
\(c\ell(s)^{1/2}\) 下界。

因此得到以下可直接使用的判别。

**推论 2（边界非退化排除平台）。** 若每个局部 Weil 基态至少在一个端点具有非零 signed
\(\ell(d)^{1/2}\) 边界系数，或满足同阶的固定符号下界，则

\[
0<a<b\quad\Longrightarrow\quad\lambda_1(b)<\lambda_1(a).
\]

结合 note 008，在 RH 为假时，这将使 \(a_*\) 成为唯一零尺度，并保证 \(a>a_*\) 时立即
\(\lambda_1(a)<0\)。

## 5. 平台要求的精细抵消

即使边界系数不存在，平台仍强制一个明确的 Cauchy--Dini 抵消条件：

\[
\boxed{
\sup_{0<t<\delta}
\left|\int_0^\delta\frac{v_a(a-s)}{t+s}\,ds\right|<\infty.}
\]

note 007 的上界只说明

\[
|v_a(a-s)|\le C\ell(s)^{1/2};
\]

它本身允许 Stieltjes 积分按 \(1/\sqrt{\ell(t)}\) 增长。要保持有界，端点附近必须发生跨尺度的
符号抵消，或边界消失严格快于最优轮廓。这是比“零模态可能变号”更精确的下一判别对象。

## 6. 下一步

最便宜的区分性问题已经变成：完整 Weil 基态方程能否允许上述 Cauchy--Dini 抵消？有三种可能
结果，且会改变路线：

1. 证明端点附近最终单符号或存在非零 signed coefficient：M2-R3 闭合，谱底严格下降；
2. 证明方程强制系数存在但可能为零，再用两个端点或正交条件排除同时为零；
3. 构造满足同一正则性和有界外侧 Stieltjes 变换的变号模型：说明单靠边界正则性不足，主线转回
   平移核完备性。

note 010 已实现第 3 种结果：\(\ell(s)^{1/2}\sin(\log(1/s))\) 型函数属于能量域、达到最优振幅，
但外侧 Stieltjes 变换仍一致有界。因此后续必须使用完整 Weil 方程，而不能从边界上界本身推出
非退化。

## 7. 来源与新结论边界

- Huyuan Chen and Tobias Weth, *The Dirichlet Problem for the Logarithmic Laplacian*,
  [arXiv:1710.03416](https://arxiv.org/abs/1710.03416)：一维积分归一化与 exterior-zero 框架。
- Víctor Hernández-Santamaría, Luis Fernando López Ríos and Alberto Saldaña,
  *Optimal boundary regularity and a Hopf-type lemma for Dirichlet problems involving the logarithmic
  Laplacian*, [arXiv:2401.18033](https://arxiv.org/abs/2401.18033)：最优 \(\ell(d)^{1/2}\) 上界、
  torsion 下界和带超解假设的 Hopf 引理。

精确外侧常数 \(-2\beta_\pm\)、平台强制零边界系数以及 Cauchy--Dini 抵消条件，是本项目的新推论。
本文尚未证明 Weil 基态的边界系数存在或非零。
