> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 对数级 \(U^2\) 控制不能推出 dyadic block-square 门

日期：2026-08-16。

本 note 给出一个确定性的“函数类”反例，说明即使一个有界序列具有任意给定的对数级 \(U^2\) 小量，也不能仅凭这个 \(U^2\) 信息推出
\[
\sum_H\left|\sum_{H\le h<2H}\sum_{n\le N-h}f(n)f(n+h)\right|^2
\ll N^{2+\varepsilon}.
\]
因此 Tao--Teräväinen 的 Möbius \(U^2\) 对数估计不能通过抽象范数不等式关闭本项目的 block-square 门。

## 构造

令 \(\eta_1,\ldots,\eta_N\) 为独立 Rademacher 变量，取
\[
f_n=\frac{\eta_n+\delta}{1+\delta},\qquad 0<\delta\le1.
\]
于是 \(|f_n|\le1\)。写
\[
F_f(\theta)=\sum_{n\le N}f_ne(n\theta).
\]
由 \(|a+b|^4\le8(|a|^4+|b|^4)\)、Parseval 和
\[
\mathbb E\int_0^1\left|\sum_{n\le N}\eta_ne(n\theta)\right|^4d\theta
\le 2N^2
\]
（四阶乘积的非零期望只来自偶数重数）可得，存在一个 Rademacher 实现满足
\[
\int_0^1|F_f(\theta)|^4d\theta
\ll \delta^4N^4+N^2.
\tag{1}
\]
在 \(M\asymp N\) 的标准循环归一化下，(1) 等价于
\[
\|f\|_{U^2}^4\ll \delta^4N+N^{-1}.
\tag{2}
\]

另一方面，令
\[
D_H(f)=\sum_{H\le h<2H}\sum_{n\le N-h}f_nf_{n+h}.
\]
对 \(n\ne n+h\)，
\[
\mathbb E[f_nf_{n+h}]=\frac{\delta^2}{(1+\delta)^2}.
\]
取一个二次壳 \(H\asymp N\)（例如 \(N\) 为足够大的二次幂，取
\(H=N/4\)）。记该壳的无向边集为 \(E_H\)，则
\(|E_H|\asymp N^2\)，每个顶点的度数至多 \(H\)。写
\[
Z_H=\sum_{\{i,j\}\in E_H}(\eta_i+\delta)(\eta_j+\delta)
   =Q_H+\delta L_H+\delta^2|E_H|.
\]
独立性给出
\[
\mathbb EQ_H=\mathbb EL_H=0,\qquad
\operatorname{Var}(Q_H)=|E_H|,\qquad
\operatorname{Var}(L_H)=\sum_i\deg(i)^2\ll NH^2,
\]
且 \(\operatorname{Cov}(Q_H,L_H)=0\)。所以
\[
\mathbb EZ_H\asymp\delta^2N^2,\qquad
\frac{\operatorname{Var}(Z_H)}{(\mathbb EZ_H)^2}
\ll\frac1{\delta^4N^2}+\frac1{\delta^2N}.
\tag{3}
\]
对下文的 \(\delta\)，右端趋于零；Chebyshev 因而以趋于一的概率有
\[
|D_H(f)|=Z_H/(1+\delta)^2\gg\delta^2N^2.
\]
同时 (1) 的 Markov 好事件概率至少为 \(1/2\)，故两事件有交集，存在同一个实现满足
\[
\int_0^1|F_f(\theta)|^4d\theta\ll\delta^4N^4+N^2,
\qquad
\sum_H|D_H(f)|^2\ge |D_H(f)|^2\gg\delta^4N^4.
\tag{4}
\]

取
\[
\delta=N^{-1/4}(\log N)^{-A}.
\]
则
\[
\|f\|_{U^2}\ll_A(\log N)^{-A},
\qquad
\sum_H|D_H(f)|^2\gg_A N^3(\log N)^{-4A}.
\]
这比目标 \(N^{2+\varepsilon}\) 大一个幂次（任意固定 \(A\) 都无法抵消 \(N\)）。

## 结论

这个反例不涉及 Möbius 本身，因而不否定 Möbius 的特殊算术结构；它精确否定的是
\[
\text{“小 \(U^2\) 范数}\Longrightarrow\text{无权 dyadic block-square 小”}
\]
这一纯泛函分析推论。要关闭 RH 门，必须加入新的 Möbius-specific 信息：直接四点 signed 估计、固定乘法频带的 twisted-Mertens 控制，或等价的算术 intertwiner。普通 \(U^2\)、Parseval 和 Bessel 权重都不足以提供该信息。
