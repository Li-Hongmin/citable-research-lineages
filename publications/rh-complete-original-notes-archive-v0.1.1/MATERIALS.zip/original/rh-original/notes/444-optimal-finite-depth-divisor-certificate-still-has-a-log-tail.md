> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有限深度除数证书的最优加权插值仍保留对数尾

日期：2026-08-17。

本 note 精确优化 note 443 的有限深度情形。结论不是只说阶跃残差会产生对数代价，而是给出在所有允许的低尺度残差中对偶能量的最小值。因而任何支撑于 \(n\le B\) 的除数修正，即使在低尺度上作最优平滑，也不能消除 \(B\) 以上的对数尾。

## 1. 固定深度的约束

令 \(2\le B<N-1\)，并考虑 note 443 中的残差

\[
r_d=1-\sum_{d\mid n\le N}b_n,
\qquad b_n=0\quad(n>B).
\]

于是
\[
r_d=1\quad(B<d\le N).
\tag{1}
\]

在 Lehmer 对偶能量中置
\[
s_1=0,
\qquad s_d=d\,r_d\quad(2\le d\le N).
\]
由 (1)，\(s_{B+1}=B+1\)，且对 \(k\ge B+1\)，
\[
s_{k+1}-s_k=1.
\tag{2}
\]

因此 note 443 的精确差分式分解为
\[
\mathcal C_N(b)
=\sum_{k=1}^{B}\frac{(s_{k+1}-s_k)^2}{2k+1}
+\sum_{k=B+1}^{N-1}\frac1{2k+1}.
\tag{3}
\]

## 2. 低尺度的严格最优值

对第一项应用加权 Cauchy--Schwarz，得到
\[
\sum_{k=1}^{B}\frac{(s_{k+1}-s_k)^2}{2k+1}
\ge
\frac{(s_{B+1}-s_1)^2}{\sum_{k=1}^{B}(2k+1)}
=\frac{(B+1)^2}{B(B+2)}.
\tag{4}
\]

等号当且仅当
\[
s_{k+1}-s_k
=\frac{B+1}{B(B+2)}(2k+1),
\qquad 1\le k\le B.
\tag{5}
\]
等价地，低尺度最优残差为
\[
r_d=\frac{(B+1)(d^2-1)}{B(B+2)d},
\qquad 2\le d\le B.
\tag{6}
\]

所以所有支撑于 \(n\le B\) 的除数修正满足严格下界
\[
\boxed{
\mathcal C_N(b)
\ge
\frac{(B+1)^2}{B(B+2)}
+\sum_{k=B+1}^{N-1}\frac1{2k+1}.}
\tag{7}
\]
而右端确实可由 (6) 达到；对应的 \(b\) 由有限除数矩阵的上三角 Möbius 逆唯一确定，且仍支撑于 \(n\le B\)。

特别地，
\[
\mathcal C_N^{\min}(B)
=1+\frac12\log\frac NB+O(B^{-1}).
\tag{8}
\]
这比 note 443 的阶跃下界更尖锐：低尺度平滑至最优只能把局部代价压到约 \(1\)，不能改变尾部的 \(\frac12\log(N/B)\)。

## 3. 边界标量的两种精确情形

由 \(D_N\mu_N=e_1\) 和 \(b_1=0\)，任意除数证书都满足
\[
\sum_{n=2}^{N}b_n
=-(M(N)-1)+\sum_{d=2}^{N}\mu(d)r_d.
\tag{9}
\]

在有限深度情形 \(r_d=1\)（\(d>B\)）时，这化为
\[
\sum_{n=2}^{N}b_n
=\sum_{d=2}^{B}\mu(d)\bigl(r_d-1\bigr),
\tag{10}
\]
即边界标量本身不再含显式的 \(M(N)\)，但 \(M(N)-1\) 仍完整地留在残差线性泛函
\(\sum_{d>B}\mu(d)\) 中；式 (7) 正是这种尾部未被除数证书触及的能量代价。

相反，若要求全尺度 \(r_d=0\)（\(2\le d\le N\)），则 (9) 退化为
\[
\sum_{n=2}^{N}b_n=-(M(N)-1),
\tag{11}
\]
这就是 note 443 的边界转移：精确消去全部残差并没有估计 Mertens 量，而是把它原样写入修正系数和。

## 4. 对 RH 路线的严格边界

由 note 443 的 Cauchy 证书，(7) 直接给出
\[
\left|M(N)-1+\sum_{n=2}^{N}b_n\right|^2
\le \frac{I_N}{\pi}\,\mathcal C_N(b),
\]
但对任意 \(B=N^{o(1)}\)，
\[
\mathcal C_N(b)\ge \tfrac12\log N-o(\log N).
\]
因此固定深度、次幂深度以及低尺度最优平滑都不能把正 Lehmer 能量直接转成平方根级的未加权 Mertens 界。真正可能越过该门的构造必须同时：

1. 延伸到接近全尺度的除数支撑；
2. 利用 \(D_N\) 的非对角 signed 结构，而不是只优化正差分能量；
3. 避免式 (11) 所示的边界转移。

本 note 是严格路线边界与最优性结果，不是 RH 证明。
