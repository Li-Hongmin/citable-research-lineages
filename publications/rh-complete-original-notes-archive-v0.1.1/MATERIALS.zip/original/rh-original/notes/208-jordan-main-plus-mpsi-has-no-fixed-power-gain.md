> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Jordan 正主项与 \(M\)--\(\Psi\) 分解的最小 signed correlation

日期：2026-08-15。

本 note 检查 note 065 的 Barban--Vehov 首壳余项能否仅由已有 Jordan
正主项和 \(M\)--\(\Psi\) 分解得到固定幂次改善。结论是 NO：现有信息只给
\(o(N^2)\) 级别；任意固定 \(\delta>0\) 都必须支付一个尚未控制的 signed
correlation。

## 1. Jordan 正主项的量纲

note 065 的精确分解是
\[
 I_N=\frac N{12}Q_2(N)+\mathcal B_N,
\tag{1}
\]
其中
\[
 Q_2(N)=\sum_{d,e\le N}\lambda_{d,N}\lambda_{e,N}
 \frac{(d,e)^2}{de},
\]
以及
\[
 \mathcal B_N=
 Nc_N^2+2c_N\sum_d\lambda_{d,N}E_d(N)
 +\sum_{d,e}\lambda_{d,N}\lambda_{e,N}E_{d,e}(N).
\tag{2}
\]
Jordan 正平方和和 Graham 估计目前只给
\[
 Q_2(N)\ll \frac{N\log\log(3N)}{\log N},
\qquad
 \frac N{12}Q_2(N)=o(N^2).
\tag{3}
\]
这是对 \(N\) 的对数节省，不是任何
\(O(N^{1-\delta})\) 的幂次节省。因此 (3) 本身不能推出
\(I_N\ll N^{2-\delta}\)。

## 2. 固定幂次改善的精确最小门

由 (1)，对任意固定 \(\delta>0\)，
\[
 I_N\ll N^{2-\delta}
\quad\Longleftrightarrow\quad
\boxed{
 \mathcal B_N+\frac N{12}Q_2(N)\ll N^{2-\delta}.}
\tag{4}
\]
这不是对 \(\mathcal B_N\) 的单独上界，而是要求 incomplete-lcm 边界
与 Jordan 正主项发生精确 signed cancellation：
\[
 \mathcal B_N=
 -\frac N{12}Q_2(N)+O(N^{2-\delta}).
\tag{5}
\]
逐项估计 \(|E_{d,e}(N)|\ll[d,e]\) 会删掉这一取消；即便假设
\(\mathcal B_N=o(N^2)\)，也仍只得到 note 065 的 \(I_N=o(N^2)\)，不能得到
固定 \(\delta\)。

## 3. \(M\)--\(\Psi\) 语言中的同一门

note 065 的恒等式
\[
 L D_N(y)=\mathscr R_N(y),
\]
其中
\[
 \mathscr R_N(y)
 =(y-\Psi(y))+y(LA_N-1)
 -\log(y/N)M(y)+\int_N^y\frac{M(t)}t\,dt,
\tag{6}
\]
给出完全等价的 signed-correlation 形式
\[
 \boxed{
 I_N\ll N^{2-\delta}
 \quad\Longleftrightarrow\quad
 \int_N^{2N}|\mathscr R_N(y)|^2\,dy
 \ll L^2N^{2-\delta}.}
\tag{7}
\]
现有零自由区的点态 \(M,\Psi\) 估计不能证明 (7)：它们没有控制四项在同一
dyadic 壳上的低频交叉项。特别是不能分别取绝对值后再求和，因为那会丢失
(5) 所需的 Jordan--boundary 抵消。

## 4. 最小可检验命题与边界

因此当前最薄的新命题可写成任一等价形式：
\[
 \boxed{
 \mathcal B_N+\frac N{12}Q_2(N)
 =O(N^{2-\delta})}
\tag{8}
\]
或 (7)。它必须是 signed、全移位、带 incomplete-lcm 端点的联合估计；
普通 Barban--Vehov \(H^0\) 二次均值、Jordan 正平方和及单独的
\(M\) 或 \(\Psi\) 均不足以替代它。

本文没有证明 (8)，也没有把 \(o(N^2)\) 外推为幂次节省或 RH。
