> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 2026 年固定移位 Chowla 证明声明的核验边界

日期：2026-08-16。

## 声明来源

一份由 Juan Moreno Borrallo 于 2026 年 4 月上传到 ResearchGate 的预印本
《An Unconditional Proof of the Chowla Conjecture via Exact 2-Adic Profile
Decomposition and Statewise Tail Decoupling》声称无条件证明所有固定阶、固定移位的
Möbius Chowla 相关，并将大模数部分描述为 BDH、Kuznetsov 与谱大筛的组合。

来源：

- <https://www.researchgate.net/publication/404030430_Proof_of_Chowla_conjecture>

该来源是独立作者的未同行评审预印本，不能单凭摘要或网页摘录晋级为本项目的数学事实。

## 当前可核验事实

2025 年 Cambridge 论文仍明确写道，固定移位的 Chowla 猜想尚未解决，并只总结了
logarithmically averaged 与 averaged-shift 的部分结果：

- <https://www.cambridge.org/core/journals/mathematical-proceedings-of-the-cambridge-philosophical-society/article/chowla-conjecture-and-landau-siegel-zeroes/515F3378450DED201A21E26BF801CEEB>

2026 年 IAS 的 Möbius 讲义也仍将固定移位 Chowla 作为极其困难的工作猜想：

- <https://publications.ias.edu/sites/default/files/MobiusFunctionsLectures%282%29_0.pdf>

预印本可检索到的正文片段在 Corollary 6.199--Remark 6.201 处仍把 genuinely
large-modulus factorable frontier 写成一个“在进入解析处理前的 final exact arithmetic
input”。这至少说明摘要中的“已完全解决”不能代替对该段及后续谱估计的逐行核验；在无法取得
稳定、可复现的完整证明前，本项目不采纳其主定理。

## 与当前 RH 能量门的关系

本项目需要的算术命题是全频、乘法比值加权的二次能量

\[
E_N(w)=\int_{\mathbb R}w(t)\left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt
\ll_\varepsilon N^{1+\varepsilon}.
\]

即使固定移位 Chowla
\(\sum_{n\le X}\mu(n)\mu(n+h)=o(X)\) 对每个固定 \(h\) 成立，它也不自动给出
上式。精确展开为

\[
E_N(w)=N_0K(0)+2\sum_{h=1}^{N-1}
\sum_{m=1}^{N-h}\mu(m)\mu(m+h)
K\!\left(\log\frac{m}{m+h}\right),
\qquad
N_0=\sum_{m\le N}\mu(m)^2,
\quad
K(u)=\frac1{2\pi}\int_{\mathbb R}w(t)e^{itu}\,dt.
\]

这里用到了当前 \(w=|h|/(2\pi)\) 的偶性，因此 \(K\) 为实偶函数。

右侧同时包含所有随 \(N\) 增长的移位 \(h\)，且权重依赖于 \(m\)，并跨越不同
dyadic scales。逐个固定 \(h\) 的 \(o(X)\) 没有统一速率时，不能交换这个增长的
求和与极限，更不能直接得到平方根级界。当前 notes
209--215 已将这一差异具体化为 reciprocal-frequency 与 variable-product-modulus
层。

因此该预印本即使日后经完整核验，也只能作为潜在的固定移位输入；还必须另证它能以
统一权重、统一尺度推出 \(E_N(w)\ll N^{1+\varepsilon}\)。

## 一个精确的充分算术条件

对当前 \(V_{15}\) 的 \(w=|h|/(2\pi)\)，已有
\(h(t)=O_\varepsilon((1+|t|)^{-19/2+\varepsilon})\)，故一阶频率矩有限；于是
\(K(u)=(2\pi)^{-1}\int w(t)e^{itu}\,dt\) 有界且 Lipschitz。令
\[
 C_h(X)=\sum_{m\le X}\mu(m)\mu(m+h),\qquad
 A_h(N)=\max_{1\le X\le N-h}|C_h(X)| .
\]
对 \(L=N-h\ge1\)，把
\(W_{h,N}(x)=K(\log(x/(x+h)))\) 代入 Abel 分部求和。由于
\(x\mapsto\log(x/(x+h))\) 单调，
\[
 \operatorname{Var}_{[1,L]}W_{h,N}
 \le \|K'\|_\infty\log(1+h),
\]
从而
\[
 \left|\sum_{m\le N-h}\mu(m)\mu(m+h)
 K\!\left(\log\frac m{m+h}\right)\right|
 \le A_h(N)\bigl(\|K\|_\infty+\|K'\|_\infty\log(2+h)\bigr).
\tag{*}
\]
因此，下列统一加权最大部分和估计是能推出正能量门的明确充分条件：
\[
 \sum_{1\le h<N}A_h(N)\log(2+h)\ll_{\varepsilon}N^{1+\varepsilon}.
\tag{**}
\]
将 (*) 与对角项
\(\sum_{m\le N}\mu(m)^2K(0)=O_K(N)\) 相加，即得到
\(E_N(w)\ll_{\varepsilon}N^{1+\varepsilon}\)。

这个引理量化了固定移位 Chowla 的不足：即便对每个固定 \(h\) 有
\(C_h(X)=o(X)\)，没有对随 \(N\) 增长的 \(h\) 给出统一速率，不能推出 (**)。
即便假设粗略的统一界 \(A_h(N)\le N\rho(N)\)，右端也只有
\(N^2\rho(N)\log N\)；要达到平方根门，必须取得 (**)，即平均每个移位达到
近似平方根级的最大部分和，而不是单纯的固定移位 \(o(X)\)。

## 预印本内部的承重断点

ResearchGate 可检索到的全文片段还显示：Remark 6.201 把大模数 factorable
部分精确化为对 combined background 的 signed weighted average，并称其为进入
解析处理前的最后算术输入；随后 Theorems 6.353--6.358 又直接给出 factorable
supercritical sector 的谱估计、packet law 和 statewise shell smallness。当前可取得的
文本没有展示一个明确的定理，把 Remark 6.201 的 signed background average 统一地
接到这些谱估计的假设上，也没有在片段中完整核对所有小模数、非 factorable 和
exceptional-spectrum 边界。因此这里至少存在一条未重建的承重连接，不能把后续编号
定理的结论当作已审计证明。

来源仍是同一份未同行评审预印本：[ResearchGate full-text page](https://www.researchgate.net/publication/404030430_Proof_of_Chowla_conjecture)。

## 裁决

1. 不把该预印本的 Chowla 主张写入 RH 证明状态。
2. 不改变 notes 212--216 对正能量门的逻辑边界：其算术门仍未解决，且平方根级估计仍是
   RH-strength 输入。
3. 若要重新打开该路线，最小可判定任务不是重复阅读摘要，而是从完整来源中抽取一个明确的
   大模数定理，证明它对本项目的 \(w(\log(m/n))\) 权重给出统一 \(N^{1+\varepsilon}\) 能量界。

这是一项来源与适用范围裁决，不是否定该预印本的数学正确性。

### 2026-08-16 再检索

今日检索再次找到同一 ResearchGate 条目，摘要仍声称“unconditional proof”，但没有出现
新的同行评审版本、可引用的 arXiv 版本或独立的证明附件。工作树中对应的
Mertens_aristotle 源码仍保留 RequestProject/FinalChain.lean 的
packet_bound_analytic := by sorry；正文中的 \(W_{\xi_1,\xi_2}\) 也仍没有独立定义。
因此本次再检索没有改变上述裁决，也没有提供可直接代入固定 Mellin 能量门的新算术定理。

## 第二条相关声明：dyadic covariance / Mertens 路线

另有一份同作者的 2026 年预印本《A Dyadic Covariance Framework for the Mertens Function
and the \(N^{1/2+\varepsilon}\) Problem》声称把完整 Mertens 平方拆成有限 dyadic
covariance packets，并以 packet law
\[
 |\Pi_N(j,u,m)|\ll_\varepsilon Y_N(j)N^\varepsilon
\]
聚合得到 \(|M(N)|\ll_\varepsilon N^{1/2+\varepsilon}\)。其正文把最后的
terminal rigid \((1,1)\)-colour 交给 opened affine-sieve ledger，目标形如
\[
 O_{\rm aff}(N;j,u,m;H)\ll_\varepsilon H\,Y_N(j)N^\varepsilon .
\]

来源是未同行评审的 ResearchGate 预印本：

- <https://www.researchgate.net/publication/403789954_A_Dyadic_Covariance_Framework_for_the_Mertens_Function_and_the_N12varepsilon_Problem>

这里最关键的不是作者是否使用了 BDH、Kuznetsov 或 Blomer--Harcos，而是上述
opened-affine-sieve 界是否已经对所有 packet、残余深度、冻结导体、异常分支和
multi-residual overflow 给出统一且不循环的证明。作者自己的反馈页明确把这一 passage
列为“most delicate branch”，并直接请求核对其解析正当性：

- <https://www.researchgate.net/post/Feedback_requested_on_the_analytic_bottlenecks_in_a_Lean-supported_proof_strategy_for_the_Mertens_function>

在当前可取得的文本片段中，后续 ledger 定理是以已构造的 finite packet 和系数能量为前提，
但没有可独立复现的完整文档把 terminal affine obstruction 的输入、所有异常/溢出分支和
最终 packet budget 连成一条无缺口的定理链。因此本项目将它标为“待重建的 RH-strength
候选输入”，而不是 Mertens 或 RH 的已证结果。若该界最终被完整证明，它会直接关闭
Mertens 门；在此之前，它与前一份固定移位 Chowla 声明一样，不改变当前正能量门状态。

### 完整 PDF 复核后的修正裁决

我随后取得了该路线的完整 Zenodo 版本，而不再只依据网页片段。完整 PDF 明确补入了
Lemma 9.299--9.301：它把 terminal opened-loss 统一写成
\(\Lambda_{\rm op}(U;N)\le N^{\omega_{\rm term}(N)}\)，其中
\(\omega_{\rm term}(N)\to0\)，并在固定幂次 \(A,B\) 下吸收到 \(N^\varepsilon\)。
因此，先前仅凭片段提出的“\(N^{o(1)}\) 不能吸收到 \(Y_N(j)^{\delta}\)”并不是完整版本的
最终缺口；该段尺度反例不再作为本项目的裁决依据。

完整版本留下的更直接问题位于 automorphic/spectral 分支。Definition 19.228 将
“uniform automorphic-cell admissibility modulus”定义为一个条件：存在
\(\omega_{\rm aut}(T;\varepsilon)\to0\)，使所有 active refined cells 满足
\[
 \Lambda_{\rm aut}(\nu;N;\varepsilon)^A(1+\log N)^B
 \le Y_N(j)^{\omega_{\rm aut}(Y_N(j);\varepsilon)}
\]
（任意固定 \(A,B\)）。Lemma 19.230 只是**在该定义成立的前提下**给出统一吸收，
Corollary 19.231 再据此吸收 Blomer--Harcos、Kuznetsov 和 spectral-large-sieve
的 cell-dependent constants。

对完整 PDF 的文本检索显示，Definition 19.228 只在此处被定义，随后只被 Lemma 19.230
作为假设调用；没有找到一个先于 Theorem 20.22、独立证明该 modulus 对所有 active
cells 成立的命题。换言之，\(\Lambda_{\rm aut}\) 的“记录进 ledger”不是其
\(Y_N(j)^{o(1)}\) 增长的证明。由于 Theorem 19.305 的外部 shifted-convolution
常数本身写成依赖 \(\pi_1,\pi_2,S(G)\)，而 Theorems 19.264、20.22 正是通过
Corollary 19.319、19.320 和 Lemma 19.230 使用这些常数，这条 uniform
cell-admissibility 仍是关闭全局 packet law 所需的未证输入。

这不是对预印本最终结论的反例；它是一条更强、可定位且可复现的 proof obligation：
要么证明 Definition 19.228 的 uniform modulus，要么把所有外部常数的谱参数依赖显式
估计并纳入同一尺度预算。未完成前，本项目不把该预印本的 Mertens/RH 结论升级为已证。

最小修复形式可以明确写成一个条件引理：若在固定 ambient modulus \(Q_*\) 下，所有
实际出现的谱高度 \(T\)、Sobolev 阶数和 cell 分裂参数都满足 \(N^{o(1)}\)，并且外部
Blomer--Harcos / spectral-large-sieve 常数统一满足
\[
 C_{\rm ext}(Q_*,T,S)\ll (1+Q_*+T+S)^C
\]
（固定 \(C\)），则 \(\Lambda_{\rm aut}=N^{o(1)}\)，Definition 19.228 随之成立。
当前完整 PDF 没有给出这个统一常数估计；因此这条条件引理尚未被实例化为证明。

### 完整 PDF 的进一步核对：谱标签计数也依赖同一未证 ledger

逐段检查 Definition 19.278--Lemma 19.280 后，缺口不只在
\(\Lambda_{\rm aut}\) 的数值吸收。Lemma 19.280 对
\(\#\mathcal X_{\rm spec}\) 的理由是“fixed-level cusp/oldform and exceptional
labels are counted by the same finite automorphic-cell ledger whose constants are
absorbed by Lemma 19.230”；对 refined-cell、root、shell 和 residue 计数则直接使用
“fixed polynomial ranges”“divisor bound gives \(Y^{o(1)}\)”等句子，但没有把这些
范围与 Definition 19.199 的谱尺度、Definition 19.227 的 source/cusp records
逐项对应。

因此这里存在一个明确的循环结构：

1. Definition 19.228 假设所有 active cells 的 \(\Lambda_{\rm aut}\) 为统一
   \(Y^{o(1)}\)；
2. Lemma 19.230 在该假设下吸收 cell-dependent constants；
3. Lemma 19.280 又用“该 ledger 已被 Lemma 19.230 吸收”来证明谱标签和
   frontier multiplicity 为 \(Y^{o(1)}\)；
4. Theorem 19.285 再用该 multiplicity 与 ledger absorption 完成聚合。

这不是数值反例，而是缺少一个先验的统一参数定理。最小可审计修复应至少给出：

\[
\begin{aligned}
&Q_*\text{ 固定，且所有实际 }T,D,M_{\rm split},
  \text{oldform/cusp records}=N^{o(1)},\\
&C_{\rm BH}(Q_*,T,D),\;C_{\rm SLS}(Q_*,T,D)
  \ll (1+Q_*+T+D)^C
\end{aligned}
\]

其中 \(C\) 对所有 active cells、residual packets 和 source labels 统一。仅有
“记录进 ledger”不能替代这两个先验估计。Harcos 的 polynomial-uniform shifted
convolution 结果提供了一个可能覆盖 \(C_{\rm BH}\) 的外部入口，但仍必须把其
source class、谱参数、Sobolev 规范和本稿的 cell split 一一映射；Kuznetsov/
spectral-large-sieve 分支也要单独完成同样的映射。

外部文献提供了一个可能的修复方向，但不能替代参数匹配：Harcos 的原始论文/学位论文
摘要明确声称其 shifted-convolution 界对 cusp-form 的 level、nebentypus 和谱参数具有
polynomial uniformity（见 [arXiv:math/0305299](https://arxiv.org/abs/math/0305299)）。
这说明“统一多项式增长”并非显然不可能；但仍需把该版本的精确常数、适用的 Maaß/
holomorphic source class、Sobolev 权以及本稿的 cell 分裂逐项对应起来，同时处理
Kuznetsov spectral-large-sieve 分支。当前稿件没有完成这份对应表，因此只能记为待验证
的修复路线，不能当作已经闭合的桥。

### 固定 Q* frontier 的部分收缩

完整 PDF 还给出一个重要限定：Definition 19.267 将 exceptional spectrum 写成
\(\mathcal X_{\rm exc}(Q_*)=\mathcal B_{\rm exc}(Q_*)\)，其中 ambient modulus
\(Q_*\) 固定；Definition 19.306--Lemma 19.308 的 Blomer source pair 是从这个
固定层、固定 cusp/oldform 分解产生的。因此在 genuinely large-modulus、fixed-level
frontier 内，若接受 Theorem 19.201 的 fixed-level large-sieve 归一化，则

* c_cusp、oldform/cusp-change/nebentypus 矩阵是 N-independent 的；
* \(C_{\rm BH}\) 只需取固定有限 exceptional source set 上的最大常数；
* C_SLS 是固定 Q* 版本的外部常数；
* smooth-test 的 Sobolev 阶数在 Lemma 19.200 的 cutoffs 固定后是固定的，
  其余 residue/source multiplicity 才由 divisor/splitting ledger 支付。

在这四个限定均明确写入定理的前提下，Definition 19.227 的 automorphic ledger
可压缩为
\[
 \Lambda_{\rm aut}(\nu;N;\varepsilon)
 \ll_{Q_*,\varepsilon,\vartheta,D} N^{o(1)},
\]
因为剩余的 cell[same-model review role] 因子正是 Lemma 19.280 所列的固定多项式范围
与 divisor-bound 因子。这说明原先的“所有 BH 常数都必须对任意增长谱高统一多项式”
表述对固定-level exceptional frontier 过强；Harcos 的 uniformity 主要在需要
变化 source 的版本才必要。

但这还不能关闭全局 packet law：Theorem 19.202 的 variable-level spectral
large sieve 仍出现在 standard-subcritical/dual-good low-divisor 接口，且正文明确
说在 bounded low-divisor 之外 cusp--nebentypus capacity 仍留在显式 ledger 中；此外，
Lemma 19.280 对 refined-cell 与 frontier multiplicity 的“fixed polynomial range”
仍需逐项给出结构性证明。故本节只能把缺口从“固定 frontier 的全部 automorphic
常数”收缩为“variable-level capacity + structural ledger 的统一实例化”，不能升级
为已证 Mertens 或 RH。

### Variable-level 接口的显式容量因子缺项

逐式检查 Theorem 19.202、Definition 19.204、Lemma 19.205--19.206 与
Theorems 19.216--19.218 后，还可以把上述剩余缺口写成一个具体的代数条件。
Theorem 19.202 的两侧大筛因子是
\[
 A_\eta(T)=T^2+1+c_{\rm cusp}(q_\eta,a_\eta,\chi_\eta)\frac{N_\eta^X}{q_\eta},
 \qquad
 B_\eta(T)=T^2+1+c_{\rm cusp}(q_\eta,a_\eta,\chi_\eta)\frac{N_\eta^Y}{q_\eta}.
\]
因此 Cauchy--Schwarz 后至少出现
\[
 \sqrt{A_\eta(T)B_\eta(T)}\,\sqrt{E_\eta^X E_\eta^Y},
\]
而不是自动出现 \(Y^\varepsilon\sqrt{E_\eta^X E_\eta^Y}\)。Lemma 19.206
明确承认：只有 bounded low-divisor 子范围内 \(c_{\rm cusp}\) 被证明为常数；
范围外该容量“remains in the explicit capacity-weighted ledger and is not absorbed”。

但 Theorem 19.218 的结尾在这句话之后直接给出
\(Y^\varepsilon\sqrt{E^{X,\rm std-sub}E^{Y,\rm std-sub}}\)，没有定义一个
包含 \(A_\eta,B_\eta\) 的 weighted energy，也没有给出
\[
 \sum_\eta \sqrt{A_\eta B_\eta E_\eta^X E_\eta^Y}
 \ll_\varepsilon
 Y^\varepsilon
 \sqrt{E^{X,\rm std-sub}E^{Y,\rm std-sub}}
\]
或任何等价补偿式。因而 variable-level 分支目前存在一个可审计的“容量因子
从大筛估计到最终 packet law 被删掉”的缺项。要修复它，必须二选一：

1. 证明所有 active low-divisor shells 上 \(A_\eta,B_\eta\ll Y^\varepsilon\)；或
2. 正式定义 capacity-weighted \(E\)-能量，并在 Theorem 19.217/19.219 的
   divisor-completion 估计中保留并支付 \(c_{\rm cusp}N/q\)；或
3. 给出跨 shell 的 Cauchy/正交不等式，证明这些容量因子与 shell energy 联合后
   仍能达到所声称的 \(o(1)\)。

在这三者之一出现前，Theorem 19.218/19.220 不能作为 variable-level packet law
的独立证明；这比泛泛要求“统一参数映射”更具体，也不依赖对作者结论的否定。

### Theorem 19.216 中的短 dyadic 置换反例

Theorem 19.216 的证明还有一个独立的离散错误。它在应用 Lemma 19.215 后写道：
因为 \((C_{\eta,\ell},q_\eta)=1\)，乘法 (h\mapsto C_{\eta,\ell}h) 置换模
\(q_\eta\) 的剩余类，“因此”
\[
 \left\|\frac{hC_{\eta,\ell}}{q_\eta}\right\|
 \asymp \left\|\frac h{q_\eta}\right\|
\]
并据此把短 dyadic 块的和估成 (C=1) 的 harmonic sum。模置换只保持**完整剩余类
全集**的总和，不保持短区间 (H<h\le2H)；上面的逐点比较是假的。

精确反例甚至满足正文的限制 (C=2^r)。取任意充分大的奇素数 (q)，令
\(H=\lfloor q/3\rfloor\)、(C=2)，并令
\[
 S_C(q,H):=\sum_{H<h\le2H}
 \min\!\left(U,\left\|\frac{Ch}{q}\right\|^{-1}\right)^2,
 \qquad U\ge q.
\]
因为 \(h_0=(q+1)/2\) 落在 \((H,2H]\) 且 (2h_0\equiv1\pmod q)，有
\(S_2(q,H)\ge q^2\)。另一方面，对 (C=1)，区间内
\(\min(h,q-h)\ge q/3-O(1)\)，故
\[
 S_1(q,H)=\sum_{H<h\le2H}(q/\min(h,q-h))^2\ll q.
\]
因此 (S_2(q,H)/S_1(q,H)\gg q\to\infty)。例如 (q=199,H=58,C=2) 时，
区间内 (h=100) 已把相位送到剩余类 (1\)，而 (C=1) 的相位距离零点始终为
\(\gg1/3\)。

在正文的尺度语言中，这不是一个可被 (Y^\varepsilon) 隐藏的常数：若
\(U=Y/A^{\rm eff}\ge q\)、(H\asymp q)，原证明所需的 harmonic 量级是
\(O(U)\)（例如 (q=199,H=66,U=q) 时为 (O(q))），而实际置换和已经含有
一个 (q^2) 项。Lemma 19.94 的约束 (q\ll_{Q_*}M^{1/2}) 并没有给出
\(H\not\asymp q\) 或 (U<q)，所以当前文本没有排除这一 regime。

还存在更强的单点族，直接比较 Theorem 19.216 的归一化量级。令 (H=1)、(h=2)，
取任意素数 (q\mid(2^{r+1}-1))，并令允许的 (C=2^r)。则
\(Ch\equiv1\pmod q\)。若 (U=Y/A^{\rm eff}=q)，正文左侧的相位和中出现
\[
 \frac1q\min\!\left(U,\|Ch/q\|^{-1}\right)^2=q,
\]
而 Theorem 19.216 右侧的 claimed bound 只有
\(YH/(A^{\rm eff}q)+\log(2q)/q=1+o(1)\)，再乘正文允许的固定
\((\log N)^{B_X}\) 也只有 polylogarithmic 大小。\(2^{r+1}-1\) 的不同素因子无界，
故这不是单个小数值现象。正文只说明 (C) 是非零二的幂和 (q) 为奇数，没有给出
排除该族的额外条件。

即使把 Lemma 19.94 的显示尺度约束一并考虑，也没有自动排除它：对 (C\ge q)
可取形式上的尺度 (A^{\rm eff}=C)、(m=q)、(Y=Cq)、(M\asymp Cq)，则
\(U=Y/A^{\rm eff}=q\)，且 (q\ll M^{1/2})；(H=1) 仍是允许的 dyadic block。
要排除该族，必须再证明 slope (C)、frequency (H) 与 extracted modulus (m)
之间的额外关系，而正文的 Theorem 19.216/Lemma 19.94 没有给出这种关系。

要修复 Theorem 19.216，必须重新估计
\[
 \sum_{H<h\le2H}\min\!\left(Y/A^{\rm eff},
   \|C h/q\|^{-1}\right)^2
\]
而不能把它替换成 (C=1) 的和。可能的修复是对 (C) 的完整模残余类平均、
对 (h) 的再分块，或把 (C)-置换后的短区间能量作为新的 arithmetic input；当前
正文没有给出其中任何一种。因此这不是单纯的 automorphic 常数记账问题，而是
variable-level packet law 中一个直接影响指数预算的离散缺口。

在没有额外结构时，唯一普适的替代上界只是
\[
 \frac1q\sum_{H<h\le2H}
 \min(U,\|Ch/q\|^{-1})^2
 \le \frac{H}{q}\min(U,q)^2,
\]
这比正文所需的 (UH/q) 多出最多一个 (\min(U,q)\) 因子。故即使把所有
automorphic 常数都完美记账，也不能由现有 Lemma 19.215 自动恢复原 packet budget。

### 原始 2-adic profile 确实允许增长的斜率

这里必须区分 Theorem 19.216 的加性频率 \(h\) 与 Section 8 生成 affine
profile 的偶移位。后者可取

\[
h_0=2^r,qquad R(h_0)=\nu_2(h_0)+1=r+1,qquad a=2^{r+1}-2.
\]

对 \(r\ge2\)，这个 \(a\) 满足 Definition 8.2 的 admissibility 条件。两端 parity
指标均为 \(t_0=t_1=1\)，所以 Definition 8.7 给出

\[
L_0(q)=2^r q+(2^r-1),qquad
L_1(q)=2^r q+(3\cdot2^{r-1}-1).
\]

因此 Theorem 19.214 中的 dyadic slope coefficient 确实可以是 \(C=2^r\)，且其
大小不由 Theorem 19.94 的 \(q_\eta\ll M^{1/2}\) 约束直接控制。这个 \(C\) 来自
packet 的 2-adic 移位，而不是 Theorem 19.216 里被分块的加性频率 \(h\)。

一个完全整数的局部实例是 \(r=4\)：

\[
h_0=16,\quad a=30,\quad (L_0,L_1)=(16q+15,16q+23).
\]

在 profile quotient \(q=1\) 处，\(L_0(1)=31\)、\(L_1(1)=39\)，所以
\(n=31\cdot39=1209\) 是 squarefree。形式上取 \(Q_*=1\)、\(m=31\)、
\(A^{\rm eff}=39\)、\(Y=M=1209\) 时，正文显示的 standard-subcritical 尺度约束
仍满足；再取 Theorem 19.216 的 dyadic frequency block (H=1)、(h=2)，就有

\[
\frac1{31}\min\!\left(31,\left\|\frac{16\cdot2}{31}\right\|^{-1}\right)^2=31,
\]

而未经 \(C\)-置换的目标量级只有 \(YH/(A^{\rm eff}q)=1\) 加上对数项。这个例子
首先是严格的 profile/尺度证书，不单独声称已经嵌入完整 completed-shell fibre；若要
排除它在完整活动集合中的出现，正文必须另给 (C,h,m,A^{\rm eff}) 之间的结构关系，
而当前 Theorem 19.216、Lemma 19.94 以及 Section 8--20 的相应定义没有给出该关系。

在没有额外结构时，正确的安全估计是

\[
\frac1q\sum_{H<h\le2H}
 \min\!\left(U,\left\|\frac{Ch}{q}\right\|^{-1}\right)^2
 \le \frac{H}{q}\min(U,q)^2,
\]

而不是正文所需的 (UH/q+\log(2q)/q)。当 (H<q) 且置换后的短区间命中小剩余类
时，两者可相差一个 (min(U,q)) 因子；这正是 packet budget 中尚未支付的离散损失。
### 可保留的完整周期区间与真正缺口

令

\[
f_{U,q}(a)=\min\!\left(U,\|a/q\|^{-1}\right)^2,
\qquad V=\min(U,q).
\]

直接按最小剩余类求和可得

\[
\sum_{a\bmod q}f_{U,q}(a)\ll qV.
\]

因此当 (H\ge q) 时，把 (H<h\le2H) 分成完整的模 (q) 周期和一个尾段，
对任意 ((C,q)=1) 都有

\[
\frac1q\sum_{H<h\le2H}f_{U,q}(Ch)
 \ll \left(\frac Hq+1\right)V.
\]

这在 (U\le q) 时就是 (UH/q+O(U))，在 (U\ge q) 时也是
(O(H+q))，所以完整周期区间本身不是障碍。相反，当 (H<q) 时，仅使用
Theorem 19.214 的支持长度、\(\ell^1\) 质量和总变差，普适安全界只有

\[
\frac1q\sum_{H<h\le2H}f_{U,q}(Ch)
 \le \min\!\left(V,\frac{HV^2}{q}\right),
\]

而不是 (UH/q+\log(2q)/q)。所以一个可能的修复架构是：把 (H\ge q) 的频段
按完整周期处理，把 (H<q) 的低频段单独交给新的 residue-discrepancy、
低频正交或 packet-specific arithmetic estimate。当前正文没有这条第二接口；这也是
比“所有 (C) 都可直接换成 1”更精确的最小缺口。

### 逐块错误与全频重排之间的区别

逐 (H) 的 harmonic 估计不能成立，并不自动意味着整个 standard-subcritical
packet law 无法修复。对一个固定 frozen class，若

\[
S_i(h)=\sum_u\Gamma_i(u)e(-hC_i u/q),
\qquad
|S_i(h)|\ll L\min\!\left(U,\|C_i h/q\|^{-1}\right)
\quad(h\not\equiv0\pmod q),
\]

则对所有非零残类合并求和，因 (C_i) 在 (mathbb Z/qmathbb Z) 上置换残类，有

\[
\frac1q\sum_{h=1}^{q-1}|S_i(h)|^2
 \ll L^2\min(U,q).
\]

这是由

\[
\frac1q\sum_{h=1}^{q-1}
 \min\!\left(U,\|h/q\|^{-1}\right)^2
 \ll \min(U,q)
\]

直接得到的。若一个 (c_\eta(h)) 只是 (J) 个 frozen-class 和，Cauchy--Schwarz
给出相应的 (J L^2\min(U,q)) 上界。因此，若后续谱大筛允许先对所有 (H) 合并、
且 (J) 及 residue (r) 的总容量确实为 (Y^{o(1)})，短区间置换错误只会被
重排为一个可吸收的 ledger 因子，而不必引入新的 Chowla 输入。

当前正文没有证明这两个前提：Proposition 19.214 的 (r=0,\ldots,A^{\rm eff}-1)
分解可能有增长的 residue 数，Theorem 19.218 也没有展示先合并 (H) 后再应用
variable-level spectral large sieve 的公式。因此目前应把该问题标为“逐块定理错误、
全频重排的可行修复尚待 capacity/structural ledger 证书”，而不是把逐块反例直接
升级为全局 Chowla 反例。

### Theorem 19.218 的实际作用域：它仍然逐 \(H\) 使用谱大筛

进一步核对 Theorems 19.181、19.193、19.197、19.202、19.216--19.218 及
Definitions 19.177、19.188、19.191 后，当前文本的重排顺序是：先在每个 dyadic
pair \((H,K)\) 内完成 shell aggregation，再对该固定 cell/block 应用 Kuznetsov
和 variable-level spectral large sieve。Theorem 19.181 的“full packet reassembly”
只说明同一个 \((H,K)\) block 内的 shell/root 数据已合并；它没有把不同 \(H\) 的
blocks 变成一个共同的 spectral coefficient system。Theorem 19.216 也明确是
固定 \(H\) 的 \(E_{\nu,H,K}^{X,\mathrm{std-sub}}\) 估计，而 Theorem 19.218 直接把
这个逐 \(H\) 结论代入 \(Y^\varepsilon\sqrt{E^XE^Y}\)，然后仅以“finite shell-rigid
family and dyadic parameters”结束证明。故此前提出的“先合并全部 \(H\)，再做谱大筛”
仍只是可能的修复路线，不是原证明中的隐含步骤。

此外，文中所谓 finite 不能替代统一的容量证书：Definition 19.204 与
Theorem 19.202 的两侧容量分别含

\[
 T^2+1+c_{\rm cusp}(q_\eta,a_\eta,\chi_\eta)N_\eta^X/q_\eta,\qquad
 T^2+1+c_{\rm cusp}(q_\eta,a_\eta,\chi_\eta)N_\eta^Y/q_\eta.
\]

Lemma 19.206 明确规定 bounded low-divisor 之外，这些因子必须留在
capacity-weighted ledger 中。可是 Theorem 19.218 的显示式没有相应的加权能量或
跨 shell 补偿不等式。更后面的 Lemma 19.280 将谱标签的 \(Y^{o(1)}\) 计数归入
“同一 automorphic-cell ledger”，而该 ledger 的统一吸收又以 Definition 19.228
的 uniform cell-admissibility 为前提；因此这里至少存在一个未给出的统一性命题，
不能把“finite”直接升级为 \(Y^{o(1)}\)。

当前最小可证修复接口可写成：对每个 frozen class
\[
 S_i(h)=\sum_u\Gamma_i(u)e(-hC_i u/q),
\]
先证明完整非零残类的二次能量
\[
 q^{-1}\sum_{h=1}^{q-1}|S_i(h)|^2\ll L_i^2\min(U_i,q),
\]
再给出 residue/frozen-class 总容量与 \(H\)-重排后的谱大筛联合不等式，并同时支付
上述 \(c_{\rm cusp}N/q\) 容量。原文目前三者均未给出。因此现阶段的裁决是：
Theorem 19.216 的逐块证明有明确错误；Theorem 19.218 的全局结论尚不能由现有
文本推出；但这仍是一个可定位的 packet-law 缺口，不足以把整篇工作判为已经构造了
一个全局 Chowla 反例。

### 完整频率聚合的严格恒等式，以及它没有自动给出谱大筛

对一个固定的 frozen class，写
\[
 S_i(h)=\sum_u\Gamma_i(u)e(-hC_i u/q),\qquad (C_i,q)=1.
\]
不再按 dyadic \(H\) 逐块估计，而是先遍历完整的 \(h\bmod q\)，则有限 Fourier
正交给出精确恒等式
\[
 \frac1q\sum_{h\bmod q}|S_i(h)|^2
 =\sum_{u,v}\Gamma_i(u)\overline{\Gamma_i(v)}
   {\bf 1}_{u\equiv v\pmod q}.
\tag{F1}
\]
因 \(C_i\) 只置换残类，它在 (F1) 中完全消失。若
\[
 |S_i(h)|\ll L_i\min\!\left(U_i,\|h/q\|^{-1}\right)
 \quad(h\not\equiv0\pmod q),
\]
则直接求和得到
\[
 \frac1q\sum_{h=1}^{q-1}|S_i(h)|^2
 \ll L_i^2\min(U_i,q).
\tag{F2}
\]
对 \(J\) 个 frozen classes，Cauchy--Schwarz 给出
\[
 \frac1q\sum_{h=1}^{q-1}\Big|\sum_{i=1}^{J}S_i(h)\Big|^2
 \ll J\sum_{i=1}^{J}L_i^2\min(U_i,q).
\tag{F3}
\]
因此，若能把 dyadic \(H\) 的平滑分割组成一个有界重叠的 partition of unity，
(F3) 确实是 Theorem 19.216 短区间估计的一个严格替代；它不需要错误的
\(\|C_i h/q\|\asymp\|h/q\|\) 断言。

但 (F1)--(F3) 仍不是 Theorem 19.202 的输入。后者对固定 \(q\)、固定谱包和一组
整数系数 \(a_n\) 给出的是
\[
 \sum_{\mathrm{spec}}\Big|\sum_n a_n\rho(n)\Big|^2
 \ll \Big(T^2+1+c_{\rm cusp}(q,a,\chi)N(a)/q\Big)
      \sum_n|a_n|^2.
\tag{F4}
\]
原文的 \(q_\eta\)、\(H\)、frozen class 和谱包同时变化；要把 (F3) 送入 (F4)，至少
还需证明一个跨 \(H\)、跨 residue、并保留 \(q_\eta\)-容量权重的联合不等式，例如
\[
 \sum_{q}\frac1q\sum_{h\bmod q}
 \mathcal S_{q,h}\big(a_{q,h}\big)
 \ll
 \sum_q\Delta_{\rm cap}(q)
       \frac1q\sum_{h\bmod q}\|a_{q,h}\|_2^2,
\tag{F5}
\]
其中 \(\Delta_{\rm cap}(q)\) 必须显式含
\(c_{\rm cusp}(q,a,\chi)N(a)/q\)，且右侧还要支付 residue/frozen-class 总容量。
Theorems 19.181、19.193、19.218 和 20.11 只给固定 \((H,K,q)\) 的版本，没有给出
(F5) 或其等价的 tensorized Kuznetsov lemma。因此“先合并 \(H\)”目前只能修补
局部离散错误，尚不能推出 global packet law，更不能推出
\(\sum |h(t)|\,|\sum_{n\le N}\mu(n)n^{it}|^2\ll N^{1+\varepsilon}\)。

后续 Theorems 19.281、19.285、19.286 的 frontier aggregation 也不能回补这一点：
它们只是在每个 route 已经有合法 atomic envelope 之后，控制标签数量并求和。
如果 Theorem 19.218 的 per-\(H\) envelope 尚未由 (F5) 或其他新输入证明，后续的
\(Y^{o(1)}\) multiplicity ledger 只能放大一个尚未成立的逐块上界，不能把它变成
全局有效的 packet law。

### 由现有 Theorem 19.202 能直接推出的最弱 tensorized 形式

设 \(\mathcal H_q\) 是固定水平 \(q\) 上保留下来的频率集合，
\(a_{q,h}\) 是对应的系数向量，并令
\[
 a_q:=\sum_{h\in\mathcal H_q}a_{q,h}.
\]
把固定 \(q\) 的系数先合并，再应用 Theorem 19.202，只能得到
\[
 \sum_{\mathrm{spec}(q)}
   |\langle a_q,\rho\rangle|^2
 \ll \Delta_q\|a_q\|_2^2
 \le
 \Delta_q\,|\mathcal H_q|
 \sum_{h\in\mathcal H_q}\|a_{q,h}\|_2^2,
\tag{F6}
\]
其中
\[
 \Delta_q=
 \Big(T^2+1+c_{\rm cusp}(q,a,\chi)N(a)/q\Big)(1+N(a)qT)^\varepsilon.
\]
对不同 \(q\) 再求和只会给出相应的直接和；Theorem 19.202 本身不会消掉
\(|\mathcal H_q|\)，也不会把不同 \(q\) 的谱空间自动正交化。

因此，完整残类 Parseval 若要真正修复 packet law，必须额外证明以下两件事之一：

1. 原始系数中已经存在精确的 \(1/q\)（或等价的 Fourier 归一化），使 (F6) 中的
   \(|\mathcal H_q|\) 与 (F1) 的完整残类平均相消；或
2. 建立一个真正跨 \(q,h\) 的谱大筛/张量化 Kuznetsov 定理，直接以
   \(q^{-1}\sum_h\|a_{q,h}\|_2^2\) 为右侧。

当前稿件只提供固定 \(q,H,K\) 的 Theorem 19.202/20.11，既没有 (1) 的系数核对，
也没有 (2) 的新谱定理。故“完整频率聚合可修复局部置换错误”已经严格成立，
但“完整频率聚合保留原 \(Y^\varepsilon\) packet budget”仍是未证命题。

这里需要修正一个过强的初步判断。Definition 19.150 的加法正交已经显式给出
\[
 \frac1{q^{\rm eff}_{a,c}}\sum_{h\bmod q^{\rm eff}_{a,c}},
\qquad
q^{\rm eff}_{a,c}=Q_*ac=A_{\rm eff}q_\eta,
\]
Proposition 19.152 也保留了同一个 \(1/(Q_*ac)\) 因子。因此，原始 packet 系数
理论上确实含有一个 \(1/(A_{\rm eff}q_\eta)\)；此前仅依据 Definition 19.208
\(c_\eta=A_{\rm eff}^{-1}\sum_rG_{\eta,r}(h)\) 就断言“没有 \(1/q_\eta\)”是不准确的。

逐项读 Definition 19.148、19.173、19.208--19.214 后，结论是：这个因子并没有被
放进单个 \(w_\xi\) 或点态 \(c_\eta(h)\)；后者仍是未归一化系数。它是在
Theorem 19.216 中作为归一化频率能量
\(q_\eta^{-1}\sum_{H<|h|\le2H}|c_\eta(h)|^2\) 出现的；Definition 20.13 的 dual
energy 另有精确的 \(E^Y_\eta\ll(Aq_\eta)^{-1}+q_\eta^{-2}\) 包络，Corollary 19.171
的 divisor Fourier 完成也有独立的 \(1/q\)。因此“原始 \(1/q\) 是否存在”已得到
肯定，但它不是点态系数的额外衰减，不能单独抵消 (F6) 中先合并 \(H\) 所产生的
\(|\mathcal H_q|\)。要完成这一步，仍需跨 \(H\)、residue、frozen class 的
Parseval/张量化大筛，并同时支付 \(c_{\rm cusp}(q,a,\chi)N/q\) 容量；正文尚未给出
这种联合不等式。

### \(1/q\) 归一化审计的最终结论（更正旧段落）

逐项读 Definition 19.148、19.173、19.208--19.214 后，结论是：显式的
\(1/q^{\rm eff}_{a,c}\) 并没有被放进单个 \(w_\xi\) 或点态 \(c_\eta(h)\)；后者仍是
未归一化系数。它是在 Theorem 19.216 中作为归一化频率能量
\[
q_\eta^{-1}\sum_{H<|h|\le 2H}|c_\eta(h)|^2
\]
出现的；Definition 20.13 的 dual energy 另有精确的
\(E^Y_\eta\ll(Aq_\eta)^{-1}+q_\eta^{-2}\) 包络，Corollary 19.171 的 divisor Fourier
完成也有独立的 \(1/q\)。因此，“原始 \(1/q\) 完全缺失”这一说法应撤回。

但这不等于 packet law 已经闭合：该 \(1/q_\eta\) 是频率能量的外部平均，不是点态
系数衰减，不能单独抵消先合并 \(H\) 时产生的 \(|\mathcal H_q|\)。还必须给出跨
\(H\)、residue、frozen class 和 variable \(q\) 的 Parseval/张量化谱大筛，并同时支付
\(c_{\rm cusp}(q,a,\chi)N/q\) 容量。正文尚未给出这种联合不等式；本节此前的“尚未核对
是否进入 \(w_\xi,c_\eta,E^X\)”应以本段为准。
### 完整 \(h\bmod q\) 聚合能直接给出的最弱严格界

固定一个 residue/frozen class，写
\[
 S_i(h)=\sum_u\Gamma_i(u)e(-hC_i u/q),\qquad
 c(h)=A^{-1}\sum_{i=1}^{J}S_i(h).
\]
对完整的 \(h\bmod q\) 求平均，有限 Fourier Parseval 给出精确恒等式
\[
\frac1q\sum_{h\bmod q}|S_i(h)|^2
 =\sum_{\substack{u,v\\u\equiv v\pmod q}}
   \Gamma_i(u)\overline{\Gamma_i(v)}. \tag{F7}
\]
特别地，若 \(\operatorname{supp}\Gamma_i\) 的长度小于 \(q\)，则右侧严格化为
\(\sum_u|\Gamma_i(u)|^2\)。对 \(J\) 个 frozen class 使用 Cauchy--Schwarz 得
\[
\frac1q\sum_{h\bmod q}|c(h)|^2
\le \frac{J}{A^2}\sum_{i=1}^{J}\sum_u|\Gamma_i(u)|^2. \tag{F8}
\]
若再把 \(u=0\) 对角项单独拆出，并对 \(u\ne0\) 使用
\(\|\Gamma_i\|_\infty\le V_i\)、\(\|\Gamma_i\|_1\le M_i\)，则
\[
\sum_u|\Gamma_i(u)|^2
\le |\Gamma_i(0)|^2+V_iM_i. \tag{F9}
\]
(F7)--(F9) 是不依赖短区间乘法置换的严格修复候选；但它们只处理完整
\(h\bmod q\)，而不是 Theorem 19.216 的单个 dyadic \(H\) 块。并且正文必须明确
\(|\Gamma_i(0)|^2\) 是被哪一个 diagonal/degenerate ledger 支付，\(J\) 与 residue
总数如何统一控制，以及不同 \(q\) 的谱容量如何进入同一右侧。缺少这三项时，
完整 Parseval 仍不能推出原文的 \(Y^\varepsilon\) packet budget。

### Theorem 19.216 显示假设的严格共振检验

这不是一个 active completed-shell 反例，但可以严格检验该证明接口本身。取任意
奇素数 \(q\mid(2^{r+1}-1)\)，令 \(C=2^r\)、\(H=1\)、\(h=2\)，于是
\(hC\equiv1\pmod q\)。令 \(Y/A^{\rm eff}=q\)，并在一个 frozen class 上取
\(\Gamma(u)=e(u/q)\)（\(0\le u<q\)，区间外为零）。则
\[
\|\Gamma\|_1=q,\qquad
\sup|\Gamma|+\operatorname{TV}(\Gamma)=O(1),\qquad
\sum_u\Gamma(u)e(-hCu/q)=q.
\]
这些量满足 Lemma 19.211--19.212 的显示 support、\(\ell^1\) 与 variation 量级，
但 Theorem 19.216 左侧的归一化项为
\[
\frac1q\left|\sum_u\Gamma(u)e(-hCu/q)\right|^2=q,
\]
而其右侧主项 \(YH/(A^{\rm eff}q)\) 仅为 \(1\)（对数项趋于零）。
因此，正文显示出的 \(\Gamma\) 界和短区间模置换不能单独证明 Theorem 19.216。
要把该抽象共振排除，必须证明 \(\Gamma\) 还满足正文未写出的相关核正定性/算术
约束，或直接改用完整 \(h\bmod q\) 的 Parseval 接口。

此外，正文在 Definition 19.210 直接写
\(\Gamma_{\eta,r,\ell}(u)=\sum W_{\xi_1,\xi_2}\)，但在可检索的预印本正文中没有
给出 \(W_{\xi_1,\xi_2}\) 的独立定义，也没有从前面的 packet 权重推导其
Hermitian、正定或其他可排除上述共振的结构。故当前不能把 \(\Gamma\) 的
\(\ell^1\)/variation 估计误当成相关核约束；这正是 Theorem 19.216 仍未闭合的
结构性缺口。

最后，完整 \(h\)-Parseval 也不能直接替代谱大筛：Definition 19.173 令
\(m_\eta=h\mu_{\nu,\lambda}\)，故 Kuznetsov/primal 系数实际是
\(\rho_j(h\mu_{\nu,\lambda})\)，随 \(h\) 改变。对 \(c_\eta(h)\) 的 Parseval 只控制
宏系数，不能消除谱侧不同 \(h\) 之间的交叉项；要把它推进到 packet law，仍需
一个同时处理 \(h\)-变化的 tensorized Kuznetsov/large-sieve 输入。

还存在一个独立的记号接口缺口：Theorem 19.216 使用带 “normalized” 标记的
\(E^{X,\mathrm{std-sub}}_{\nu,H,K}\)，而 Definition 20.12--20.13 在 Kuznetsov
Cauchy 中使用 \(E^X_{\nu,H,K}=\sum_\eta|c_\eta|^2\)。正文没有给出二者之间
关于 \(q_\eta\)、\(h\)-壳求和及 shell 聚合的精确恒等式或不等式。故即使接受
19.216 的局部 harmonic 估计，也不能未经这一步把它代入 Theorem 19.218 的
谱能量乘积。

若按字面把同一 shell 家族的 \(h\)-项对应起来，则点态能量与归一化能量至少
满足形式上的关系
\[
 E^X_{\nu,H,K}=\sum_h|c_\eta(h)|^2
 =\sum_h q_\eta\,\bigl(q_\eta^{-1}|c_\eta(h)|^2\bigr),
\]
而这里 \(q_\eta=Q_*m_\eta\) 又随 \(m_\eta=h\mu_{\nu,\lambda}\) 改变。正文没有
说明这个变化的 \(q_\eta\) 是否已包含在 \(E^{X,\mathrm{std-sub}}\) 的定义中；
若没有，19.216 到 20.13 的转换会重新付出一个变化的 \(q_\eta\) 权重。
### \(q_\eta\) 与 \(h\) 的同步导致的相位问题

Definition 19.173 同时规定
\[
m_{\nu,\lambda,h}=h\mu_{\nu,\lambda},\qquad
q_\eta=Q_*m_{\nu,\lambda,h}.
\]
因此 Proposition 19.214 中的相位实际上满足
\[
\frac{hC_{\eta,\ell}}{q_\eta}
=\frac{C_{\eta,\ell}}{Q_*\mu_{\nu,\lambda}},
\]
在固定 refined cell 上与 \(h\) 无关。Theorem 19.216 的证明却把
\(\|hC_{\eta,\ell}/q_\eta\|\) 当作随 \(h\) 变化的 harmonic 相位，并对 dyadic
\(h\)-块应用相应求和。若 \(Q_*\mu_{\nu,\lambda}\mid C_{\eta,\ell}\)，该相位恒为
整数；而正文给出的 \((C_{\eta,\ell},q_\eta)=1\) 并不能排除约分后
\(Q_*\mu_{\nu,\lambda}\mid C_{\eta,\ell}\)（例如 \(Q_*=\mu_{\nu,\lambda}=1\)）。
因此必须明确是固定 \(q_\eta\) 后再求 \(h\)，还是允许 \(q_\eta\propto h\)；
两种解释的能量估计不同，当前正文没有作出这一选择或给出排除共振的条件。
若采用 \(q_\eta=Q_*\mu h\) 的同步解释，Lemma 19.215 只能给出
\[
\left|\sum_u\Gamma(u)e(-hCu/q_\eta)\right|
\ll \min\!\left(\frac{Y}{A^{\rm eff}}(\log N)^B,\,
(\log N)^B\left\|\frac{C}{Q_*\mu}\right\|^{-1}\right),
\]
右侧的相位因子与 \(h\) 无关。要恢复 Theorem 19.216 的量级，至少需要一个
uniform non-resonance 条件，例如
\(\|C/(Q_*\mu)\|\gg (Y/A^{\rm eff})^{-1/2}\)（允许对数损失），或一条
利用 \(\Gamma\) 相关结构的替代估计；正文目前没有这两者。

在同步关系下还有更直接的检验：取 \(Q_*=\mu_{\nu,\lambda}=1\)、\(h=3\)，
于是 \(q_\eta=3\)；取 \(C=2\)，则 \(hC/q_\eta=2\in\mathbb Z\)。令
\(\Gamma(u)=1\) 在长度 \(U=Y/A^{\rm eff}\) 的整数区间上、区间外为零，则
\(\|\Gamma\|_1=U\)、\(\sup|\Gamma|+\operatorname{TV}(\Gamma)=O(1)\)，但相位和
等于 \(U\)，归一化平方为 \(U^2/3\)。Theorem 19.216 在 \(H=2\) 的右端主项
仅为 \(2U/3\)（乘固定对数因子）。这说明即使完全遵守
\(q_\eta=h\mu_{\nu,\lambda}\) 的同步关系，显示的 support/\(\ell^1\)/variation
条件仍不足以推出该能量估计。
这个同步分支还可以给出明确的预算差距。由 Lemma 19.212 的 \(\ell^1\) 界和
Definition 19.208 的 \(A^{\rm eff,-1}\) 前因子，粗略只有
\[
|c_\eta(h)|\ll Y/A^{\rm eff}\cdot(\log N)^{O(1)}.
\]
当 \(q_\eta\asymp Q_*\mu H\) 且 \(h\asymp H\) 时，这给出的归一化能量上界为
\[
\frac1{q_\eta}\sum_{h\asymp H}|c_\eta(h)|^2
\ll \frac{Y^2}{(A^{\rm eff})^2Q_*\mu}(\log N)^{O(1)}.
\]
而 Theorem 19.216 所需主项只有 \(Y/(A^{\rm eff}Q_*\mu)\)。缺失的因子正是
\(Y/A^{\rm eff}\)；所以同步分支必须补充 \(\Gamma\) 的平方根级相关抵消，
不能由 harmonic 求和或 1/qη 归一化单独提供。

### Q*=1 时的 Kloosterman 退化

预印本第 14 节明确允许 Q*=1。若 μν,λ=1，则 qη=hη，而 hη C k/qη=Ck
恒为整数，相位完全退化。按标准定义

    S(m,k;q)=Σ*_{a mod q} exp((ma+k a⁻¹)/q)

有精确恒等式

    S(q,k;q)=Σ*_{a mod q} exp(k a⁻¹/q)
            =Σ*_{a mod q} exp(k a/q)=c_q(k).

因此该允许分支中的 Kloosterman 项是 Ramanujan 和，而不是一般的双变量
大模数振荡；必须单独支付其系数能量，不能直接套用 generic variable-level
large sieve，也不能由该工具排除同步共振。

在同一分支，Corollary 19.171 的除数完成式还直接化为

    Σ(q; α) = Σ_{a mod q, (a,q)=1} α(a),

因为第一 Kloosterman 指数为 q。其有限 Fourier 展开是

    Σ(q; α) = q^{-1} Σ_{k mod q} α̂(k)c_q(k).

所以即使把 k=0 归入 Definition 19.176 的退化项，非零项仍是
Ramanujan 周期分量；若不另证 α 在单位剩余类上的零均值或相应的
算术抵消，不能从谱大筛直接得到所需的平方根能量。

从 Definition 19.173 和 Lemma 20.16 的原始定义看，Q*=1、μν,λ=1 时，
Proposition 19.214 中随商变量 k 变化的主相位恒为 1；剩余的 residue/frozen
数据至多留下单位相位 ωξ,h。因此该分支的 shell 系数形如

    cη = Σ_{ξ∈Xη} wξ ωξ,h,

但没有商变量方向的振荡。所需的 cη 小于平方根规模的结论在这一分支正是
未完成的 packet-shift signed cancellation 本身，而不是一个可由 Kuznetsov
归一化推出的结果。

即使对这个退化分支采取最有利的单位类 Cauchy，若
(alpha_h) 每个只在至多 U 个 residue 上非零且 (|alpha_h|le1)，也只能得到

    q_h^{-1}|Σ_h|^2 ≤ ||α_h||_2^2 ≤ U.

对 H 个 h 壳求和后是 O(HU)；而在 q_h ≍ H 的解释下，Theorem 19.216
给出的整块主项只有 O(U)。因此还必须明确一个额外的 1/H 归一化、壳间
正交性，或真正的跨壳 signed cancellation；单位类 Cauchy 本身不够。

### 同步参数下的逐 \(h\) 精确上界（对 19.216 的进一步校正）

预印本 Definition 19.169、Corollary 19.171 和 Definition 19.173 给出
\(\mu_{\nu,\lambda}\in\mathbb Z\)、\(m_h=h\mu_{\nu,\lambda}\) 以及
\(q_h=Q_*m_h\)。令
\[
    D:=Q_*\mu_{\nu,\lambda},\qquad q_h=Dh.
\]
在同一 refined cell 和同一 frozen class 上，Proposition 19.214 的相位因而满足
\[
    \frac{hC u}{q_h}=\frac{C u}{D},
\]
与 \(h\) 无关。这不是一个可用“对 \(h\) 做 harmonic 求和”处理的变化相位。

更具体地，若 \(\Gamma_h\) 满足正文 Lemma 19.212 的显示界
\[
 \|\Gamma_h\|_1\le U L,\qquad
 \|\Gamma_h\|_\infty+\operatorname{TV}(\Gamma_h)\le L,
 \qquad U:=Y/A^{\rm eff},
\]
其中 \(L\) 只含允许的对数因子，则 Lemma 19.215 只能给出
\[
 \left|\sum_u\Gamma_h(u)e(-hCu/q_h)\right|
 \le L\min\!\left(U,\,\|C/D\|^{-1}\right).
 \tag{F10}
\]
因此，对真正随壳变化的模数采用逐项归一化时，严格有
\[
 \sum_{H<h\le2H}\frac1{q_h}
 \left|\sum_u\Gamma_h(u)e(-hCu/q_h)\right|^2
 \ll \frac{L^2}{D}
 \min\!\left(U,\,\|C/D\|^{-1}\right)^2,
 \tag{F11}
\]
因为 \(\sum_{H<h\le2H}h^{-1}\ll1\)。当 \(D=1\) 时相位为整数，右端退化为
\(\ll L^2U^2\)；当 \(D>1\) 且 \((C,D)=1\) 时，虽有
\(\|C/D\|^{-1}\le D\)，但这仍至多给 \(\ll L^2D\)，而非正文所需的
\(U/D\) 量级。故 19.216 的 harmonic 估计只有在另加非共振条件、或证明
\(\Gamma_h\) 的平方根级相关抵消后才可能成立；\((C,q_h)=1\) 本身不够。

### 即使 \(W_{\xi_1,\xi_2}\) 被解释为自相关，仍没有平方根增益

正文没有定义 \(W_{\xi_1,\xi_2}\)。即使采取对其最有利的自然解释：
\[
    \Gamma(u)=\sum_k a(k)\,\overline{a(k+u)}
\]
（有限支撑，边界外取零），则有限 Fourier 恒等式给出
\[
    \sum_u\Gamma(u)e(-\theta u)
    =\left|\sum_k a(k)e(\theta k)\right|^2. \tag{F12}
\]
因此 Hermitian/正定自相关结构只保证左侧非负，并不保证其上界。若同步分支
\(D=1\)，则 \(\theta=C/D\in\mathbb Z\)，取 \(a(k)=1\) 于长度 \(U\) 的区间，
\(F12\) 的右侧恰为 \(U^2\)。即使 \(D>1\)，取 \(a\) 为一个完整的 \(D\)-周期
常数块也能使该平方达到与 \(D\) 同阶；要得到 \(O(U)\) 而非 \(O(U^2)\)，仍需
对实际 Möbius/packet 权重证明新的 Fourier 抵消。故把 \(W\) 补成正定相关核
并不能修复 Theorem 19.216，反而把缺口准确地转化成原始 signed Fourier
平方根估计。

### Theorem 6.352 的内部归一化不一致

公开全文中 Theorem 6.351 给出的 dominant-color Cauchy 因子是
\[
    \left(\frac{M}{A C_{i_0}}\right)^{1/2},
\]
而 Corollary 6.346 对剩余 one-color regularized block 给出
\[
    Y^\varepsilon A^{-1/2}C_{i_0}^{2\theta}.
\]
所以两者相乘的直接结果应为
\[
    Y^\varepsilon A^{-1/2}
    \left(\frac{M}{A C_{i_0}}\right)^{1/2}C_{i_0}^{2\theta}.
    \tag{F13}
\]
但 Theorem 6.352 的第一条 displayed bound 在可检索全文中写成
\[
    Y^\varepsilon
    \left(\frac{M}{A C_{i_0}}\right)^{1/2}C_{i_0}^{2\theta},
\]
漏掉了 \(A^{-1/2}\)；其紧接着的 “hence” 行和证明末句
“Reintroducing the divisor-completion gain \(A^{-1/2}\)” 又重新使用了该因子。
因此该定理的两行及证明并不字面一致。把第一行改成 (F13) 后，后续
Theorem 6.353 的阈值代数才彼此一致；在修正前，不能把 6.352 当作已排版一致的
独立证书。这是一个可修复的公式错误，不等同于前面 Remark 6.201 所留下的
signed background 算术缺口。
