> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Smoothing does not remove the boundary negative block

## 近似单位滤波

设 \(g\) 是连续偶核，\(\phi_\varepsilon\) 是偶的 \(L^2\)-归一化 bump，
其支撑尺度为 \(\varepsilon\)，并令

\[
\psi_\varepsilon=\phi_\varepsilon*\widetilde{\phi_\varepsilon}.
\]

对平移不变算子 \(C_p\)，smooth-bump Gram 的核是

\[
g_\varepsilon=g*\psi_\varepsilon,
\qquad
\widehat{g_\varepsilon}
=|\widehat{\phi_\varepsilon}|^2\widehat g.
\]

若 \(\phi_\varepsilon\) 形成近似单位，则对每个紧集
\(K\subset\mathbb R\)，

\[
\sup_{t\in K}|g_\varepsilon(t)-g(t)|\longrightarrow0.
\]

## 负 \(2\times2\) 块的稳定性

设

\[
g(0)=0,\qquad g(t_0)=A>0.
\]

在平移点 \(0,t_0\) 上，滤波 Gram 为

\[
G_\varepsilon=
\begin{pmatrix}
g_\varepsilon(0)&g_\varepsilon(t_0)\\
g_\varepsilon(t_0)&g_\varepsilon(0)
\end{pmatrix},
\]

故

\[
\det G_\varepsilon
=g_\varepsilon(0)^2-g_\varepsilon(t_0)^2.
\]

由近似单位性质，
\(g_\varepsilon(0)\to0\)、\(g_\varepsilon(t_0)\to A\)。因此存在
\(\varepsilon_0>0\)，使得

\[
0<\varepsilon<\varepsilon_0
\quad\Longrightarrow\quad
\det G_\varepsilon<0.
\]

换言之，smooth-bump realization 在小尺度极限下保留原始 boundary
negative block；它不是把 indefinite kernel 变成 PSD kernel 的方法。

## 对 endpoint-flat detector 的应用

对 \(g(t)=P(e^{|t|})/2\)，若 \(P(1)=0\)、\(P(2)>0\)，取
\(t_0=\log2\)，则

\[
g(0)=0,\qquad g(\log2)=P(2)/2>0.
\]

于是 note 180 的 bump intertwiner 在 \(\varepsilon\) 足够小时必然包含严格
负的 \(\{1,2\}\) 主子式。这与 note 175/181 一致，并且说明：

\[
\text{先平滑，再做 ordinary PSD Gram}
\]

不能绕过 Möbius signed boundary。

较宽的 bump 可能提高对角项，但那相当于引入一个尺度依赖的正 regularizer；
若 regularizer 是常数 rank-one，其 Möbius 二次型正是 note 181 的
\(cM(\sqrt x)^2\)，仍是 RH-strength 输入。

本 note 只给出 smoothing stability，不是 RH 证明。

