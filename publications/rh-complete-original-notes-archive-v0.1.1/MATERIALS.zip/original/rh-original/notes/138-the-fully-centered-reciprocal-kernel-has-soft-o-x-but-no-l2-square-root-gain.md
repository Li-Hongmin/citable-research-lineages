> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fully-centered reciprocal 核有软 \(o(x)\) 界但无通用二阶平方根增益

日期：2026-08-14。

依赖：
[note 126](126-the-endpoint-flat-rh-kernel-has-two-independent-collective-residues.md)、
[note 131](131-the-lowest-reciprocal-mode-saturates-the-full-width-gram.md)。

证据等级：精确 residue subtraction、PNT 部分求和、固定正方块与二阶不定主子式。

note 126 将三次正核写成两个 collective residues 加 fully-centered remainder。
本文确定该 remainder 的软无条件尺度，并关闭一个可能的误读：周期均值为零足以给
\(o(x)\)，但不产生对两个 Möbius 槽的 genuine differences，因而普通
\(\ell^2\)/大筛不能给平方根尺度。

## 1. 精确恒等式

沿用

\[
P(y)=\frac1{6y}-\frac1{30y^3}+C_0(y),
\tag{1}
\]

\[
S_k(z)=\sum_{a\le z}a^k\mu(a),\qquad z=\sqrt x.
\tag{2}
\]

定义

\[
T^{(0)}(x)=
\sum_{a,b\le z}\mu(a)\mu(b)
C_0\!\left(\frac{x}{ab}\right).
\tag{3}
\]

由 note 118 的 \(U_V=2A_V-T_V\) 与 note 126 的 residue 分解，

\[
\boxed{
T^{(0)}(x)
=-U_V(x)+2A_V(x)
-\frac{S_1(z)^2}{6x}
+\frac{S_3(z)^2}{30x^3}.}
\tag{4}
\]

## 2. 无条件 \(o(x)\)

素数定理等价地给出

\[
M(t)=\sum_{n\le t}\mu(n)=o(t).
\tag{5}
\]

离散 Abel 求和于是给出

\[
S_k(z)=o(z^{k+1})\qquad(k=1,3),
\tag{6}
\]

并且对固定 BV detector，

\[
U_V(x)=o(x).
\tag{7}
\]

又 \(A_V(x)=O(1)\)，故

\[
\frac{S_1(z)^2}{x}=o(z^2)=o(x),
\qquad
\frac{S_3(z)^2}{x^3}=o(z^2)=o(x).
\tag{8}
\]

代入 (4)：

\[
\boxed{T^{(0)}(x)=o(x).}
\tag{9}
\]

使用经典零自由区给出的
\(M(t)\ll_A t/(\log t)^A\)，并在输入处增加所需对数幂，同理得到

\[
\boxed{
T^{(0)}(x)\ll_A\frac{x}{(\log x)^A}
\qquad(A>0).}
\tag{10}
\]

但 (9)--(10) 的同类论证也适用于未中心化 \(T_V\)；这不是
fully-centering 独有的二阶增益。

## 3. 通用算子尺度仍为 \(x\)

直接计算

\[
\boxed{C_0(3/2)=\frac{19}{405}>0.}
\tag{11}
\]

取 \(x=z^2\)，并令一般系数 \(c_a=1\) 支撑在

\[
a\in
\left[\left(\sqrt{\frac23}-\eta\right)z,
\left(\sqrt{\frac23}+\eta\right)z\right]
\tag{12}
\]

的充分窄固定比例区间。由连续性，选取固定 \(\eta>0\) 后，该方块上

\[
C_0(x/(ab))\ge c>0.
\tag{13}
\]

支撑含 \(\asymp z\) 个指标，因此

\[
\boxed{
\sum_{a,b}c_ac_bC_0(x/(ab))
\gg z^2=x,}
\tag{14}
\]

而

\[
\sum_a|c_a|^2\asymp z.
\tag{15}
\]

所以该核的通用二阶算子尺度至少为

\[
z\sum_a|c_a|^2,
\tag{16}
\]

在满尺度向量上恰为 \(x\)。任何只使用
\(\sum|\mu(a)|^2\) 而丢失 Möbius 符号的估计不能推出 \(o(x)\)，更不能推出
\(O(x^{1/2+\varepsilon})\)。

## 4. Fully-centered 核仍然不定

在

\[
x=9k^2,\qquad (a,b)=(3k,2k)
\tag{17}
\]

上，\(C_0(x/(ab))\) 的固定主块为

\[
\boxed{
\begin{pmatrix}
-2/15&19/405\\
19/405&302/10935
\end{pmatrix}.}
\tag{18}
\]

其行列式

\[
\boxed{-\frac{193}{32805}<0.}
\tag{19}
\]

故 fully-centered 核既不是正 Gram，也不是负 Gram。

## 5. 首断点

\(C_0\) 中各周期系数的零均值只删除 fractional-part 变量的零 Fourier
mode。展开后的真实二次型仍为

\[
\sum_{a,b\le z}\mu(a)\mu(b)
\left(\frac{ab}{x}\right)^j
\psi_j\!\left(\left\{\frac{x}{ab}\right\}\right).
\tag{20}
\]

相位依赖乘积 \(ab\)，没有在 \(a\)、\(b\) 两槽分别出现的 covariance
differences；Mellin 侧也是 \(A_z(s)^2\) 的 Hankel square，而非模平方。
因此 fully centering 本身不能把 (20) 写成可由普通方差控制的
\(D_1^*TD_2\) 形式。

结论是：\(T^{(0)}=o(x)\) 无条件成立，但平方根尺度仍要求保存实际 Möbius
signed cancellation 的新 reciprocal-product 双线性估计。这不是 RH 的证明。
