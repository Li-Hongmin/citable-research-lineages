> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# (L=2) 的自然 Pascal 基底不保一次变号

日期：2026-08-16。

note 231 的 (L=1) 证明依赖一个关键事实：(K_q) 的一次变号经过
Pascal 矩阵后仍至多一次变号。对 (L=2)，这一模板不能直接复用。

## 1. 精确的 (y=x+1) 基底

令 (T_a(y)=y^{D-1}K(a/y))、(D=3m+3)。(L=2) raw 分子为
\[
 G_2(x)=T_1(x+2)+2T_2(x+1)-4T_1(x+1).
\]
在 (y=x+1) 中，(G_2(y-1)) 的系数按
(q=1,ldots,m+1) 写成
\[
 A_q=\sum_{r=1}^{q}K_r\binom{D-1-r}{q-r}
       +K_q(2^{q+1}-4).
\tag{1}
\]
这里的 (K_q) 是 notes 156--157 的 q-shift 系数；Beta 表示按 note 230 已更正，
本例不依赖逐项 Beta 正化。

## 2. 严格三变号例

取 (m=12)、(D=39)，并使用正确的 q-shift 权重
\(w_q=c_q\binom{D}{q}\)，精确计算得到
\[
\begin{array}{c|rrrrrrrrrrrrr}
q&1&2&3&4&5&6&7&8&9&10&11&12&13\\ \hline
A_q&-41247931725&-9157040842950&-411194738804850&-9248611251379500&-126932249442623625&-1119977905570974450&-6006932684661308400&-12382393530394087200&74786190344234869500&690239178177131583000&2003212835564161221000&-1726043721069352885200&-30714580549257436131300
\end{array}
\]
因此按 (q) 排列的序列为
\[
 -,-,-,-,-,-,-,-,+,+,+,-,-,
\]
具有三次符号变化。

这严格排除了“先证明 (K_q) 一次变号，再用一个 Pascal
variation-diminishing 引理闭合 (L=2)”的直接路线。它不构成
(L=2) 完整 (gamma_{m,h,2}) 的负反例；正确 Fraction 扫描中的完整
(gamma) 仍可非负，且 (x)-基底的 raw 分子在有限范围内可能重新恢复一次
变号。所需的是一个不同于自然 (y)-基底的正核或完整 (q)-和重排。

## 3. RH 相关边界

即便 (L=2) 最终闭合，它仍只加强 detector Newton 系数层，不触及
Möbius reciprocal-product 的 signed-energy 平方根门。当前最小未决算术命题
仍是保持 (mu(a)mu(b)) 符号的全尺度二次型估计。
