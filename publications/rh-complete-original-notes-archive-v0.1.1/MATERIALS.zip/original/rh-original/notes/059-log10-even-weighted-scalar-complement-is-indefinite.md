> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(\frac12\log 10\) 偶扇区的 weighted scalar-complement 下模型严格不定

## 1. 对象与结论

令

\[
 a=\frac12\log 10,
 \qquad R=280,
 \qquad N=500,
\]

并在偶 NN-cosine 基中令 \(P=P_R\)、\(Q=I-P\)。有限基础算子
\(B_0\) 包含全部 active prime blocks、\(n<N\) 的 Yukawa atoms 与 polar
项。写

\[
 v_q=PB_0e_q,
 \qquad
 t_q=\Re\psi\!\left(\frac14+\frac{i\pi q}{2a}\right)-\log\pi-\rho,
 \qquad q\ge R.
\]

由 \(QB_0P\) 的完整 covariance

\[
 CC=PB_0QB_0P=PB_0^2P-(PB_0P)^2
\]

及统一下界 \(t_q\ge\mu=t_R>0\)，得到 scalar-complement Schur 块

\[
 S_\mu=P(D+B_0)P-\frac{CC}{\mu}.
\]

取其七维 verified graph 坐标 \(Z\)。本文认证完整 diagonal-weighted
下模型

\[
 \boxed{
 M_{280,500}
 =Z^*P(D+B_0)PZ-
   \sum_{q=280}^{\infty}\frac{Z^*v_qv_q^*Z}{t_q}.}
 \tag{1}
\]

其严格惯性为

\[
 \boxed{\operatorname{inertia}(M_{280,500})=(5,2,0).}
 \tag{2}
\]

因此固定 \((R,N)=(280,500)\) 的完整 weighted scalar-complement 下模型
严格不定，不能证明 \(A^+_{\frac12\log10}>0\)。由于
\(M_{280,500}\preceq A^+_{\frac12\log10}\)，(2) **不能**反推出原算子
\(A^+_{\frac12\log10}\) 或 \(A_{\frac12\log10}\) 不定。

## 2. 两种等价写法与符号边界

由 \(CC=\sum_{q\ge R}v_qv_q^*\)，(1) 等价于

\[
 M_{280,500}
 =Z^*S_\mu Z+
 \sum_{q\ge R}
 \left(\frac1\mu-\frac1{t_q}\right)Z^*v_qv_q^*Z.
 \tag{3}
\]

式 (3) 把 refined resolvent 写成从 scalar model 出发的正恢复；式 (1)
把同一对象写成从 \(P(D+B_0)P\) 出发减去完整 covariance。有限前缀

\[
 Z^*P(D+B_0)PZ-
 \sum_{R\le q<Q}\frac{Z^*v_qv_q^*Z}{t_q}
\]

是 (1) 的上模型；负见证可以向完整模型传递，正性则不能。两种写法的
尾项符号相反，只有在完整 covariance 恒等式成立时才能互换。

## 3. 端点主通道与 canonical residual

整数 cosine 模式下，物理端点 \(0,a\) 的零阶边界项消失。prime cells
只留下六个内部 value jumps，位置互异，合并系数为

\[
 (+\alpha_3,-\alpha_4,\alpha_2-\alpha_5,
  -\alpha_7,-\alpha_8,-\alpha_9).
 \tag{4}
\]

故

\[
 v_q=s_qb+e_q,
 \qquad s_q=O(q^{-1}),\quad e_q=O(q^{-2}),
\]

其中 \(b_k=e_k(a)\)，leading low-space channel 为 rank one。若

\[
 \gamma=\sum w_qs_q^2,
 \quad d=\sum w_qv_qs_q,
 \quad K=\sum w_qv_qv_q^*,
 \quad w_q=t_q^{-1},
\]

则正确的 canonical 分解是

\[
 \boxed{
 K=\frac{dd^*}{\gamma}+
 \left(K-\frac{dd^*}{\gamma}\right),
 \qquad K-\frac{dd^*}{\gamma}\succeq0.}
 \tag{5}
\]

不能把 \(\gamma bb^*\) 单独当作 \(K\) 的 Loewner 子块；cross correlation
必须吸收到 \(d/\sqrt\gamma\) 中。六个相位序列由 Chebyshev--Vandermonde
严格线性无关，因而不存在进一步的精确 phase-rank collapse。

## 4. Signed tail enclosure

直接逐 phase 取绝对值的 Abel 界损失决定性的交叉抵消。令 \(Q=20000\)，
先在相同物理 phase 内合并 prime、Yukawa 与 polar，再对七维 rational
amplitudes 作共同 \(1/q\) 展开至 \(P=10\)。保留全部 signed scalar moments

\[
 \Phi_s(\theta)=
 \sum_{q\ge Q}\frac{e^{iq\theta}}{t_qq^s},
\]

以组装 tail Gram。same-phase 用 Euler--Maclaurin，nonzero phase 用 repeated
Abel；几何余项通过 Gram 扰动

\[
 \|C-C_P\|\le 2\sqrt{LE}+E
\]

支付。256-bit 区间计算得到

\[
 \delta_{\rm mom}=1.40256942296\times10^{-68},
\]

\[
 \varepsilon_{\rm rem}
 =1.70084224323464138\times10^{-32},
 \qquad
 \varepsilon_{\rm total}<10^{-31}.
 \tag{6}
\]

因此 \(q\ge20000\) 的完整 covariance 有严格七维 Loewner enclosure。

## 5. 区间惯性证书

对 \(280\le q<20000\) 流式严格累积 exact weighted covariance，并减去
由 (6) 得到的 tail upper。256-bit pivoted interval LDL 的排列为

\[
 (6,5,2,1,0,3,4),
\]

主元依次为

\[
\begin{aligned}
&4.2837032889624495\times10^{-10},\\
&2.4144618079354662\times10^{-14},\\
&2.27532229128611\times10^{-19},\\
&1.329396453\times10^{-24},\\
&2.047\times10^{-30},\\
&[-3\times10^{-32}\pm4.72\times10^{-33}],\\
&[-2\times10^{-32}\pm5.89\times10^{-33}].
\end{aligned}
\]

全部区间避开零，末两个区间上端严格为负，证明 (2)。

承重运行入口为
`scratch/log10_even_R280_N500_final_weighted_core_arb.py`，参数 metadata
固定为 `even, R=280, N=500, Q=20000, P=10, CORE7=true, precision=256`；
tail enclosure 为
`scratch/log10_even_R280_N500_P10_tail_upper_arb_256.npz`。这些文件属于
可丢弃执行层；本 note 的数学结论不依赖其文件名。

## 6. 决策后果

1. 固定 \((R,N)=(280,500)\) 的 scalar-complement resolvent refinement 即使
   完整支付所有 Fourier modes，仍有两个负方向；继续提高 tail 展开精度不能
   改变这一事实。
2. 失败源于下模型的 complement majorization，不是原局部 Weil 算子的负谱。
   任何下一条正性路线必须恢复更尖锐的真实 complement cross/Schur 结构，或构造
   合法的全空间 PSD 子因子；不得由不定下界推断原算子不定。
3. 已证明的完整正性范围仍严格为
   \(0<a\le\log3\)。
