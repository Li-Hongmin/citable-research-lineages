> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 连续分母子和：\(q=1\) 层包含 Chowla shift--1 相关

日期：2026-08-15。

## 1. Cotangent 系数在连续分母上不衰减

在 note 210 的 \(q=1\) 系数中取
\[
 d=n,\qquad e=n+1,\qquad r_0=1,\quad s_0=-1.
\]
于是
\[
 C_{n,n+1}(1)
 =-\frac1{4\pi}
 \left(\cot\frac\pi n-\cot\frac\pi{n+1}\right)
 =\frac1{4\pi}
 \left(\cot\frac\pi{n+1}-\cot\frac\pi n\right).
\tag{1}
\]
由 \(\cot z=z^{-1}-z/3+O(z^3)\)，
\[
 C_{n,n+1}(1)
 =\frac1{4\pi^2}+O(n^{-2}).
\tag{2}
\]
所以这条连续分母带没有 \(n^{-1}\) 或 \(n^{-2}\) 的衰减。

## 2. 对应的 reciprocal phase

其 Fourier 积分因子为
\[
 \mathcal I_N\!\left(\frac1{n(n+1)}\right)
 =N\exp\!\left(\frac{2\pi iN}{n(n+1)}\right)
 \left(1+O\!\left(\frac N{n^2}\right)\right)
\tag{3}
\]
在 \(n\asymp N\) 的宏观区间内成立。故 \(q=1\) 非共振双和包含有序对
\((n,n+1)\)、\((n+1,n)\) 产生的子结构
\[
 N\sum_{n\asymp N}
 \lambda_{n,N}\lambda_{n+1,N}
 \exp\!\left(\frac{2\pi iN}{n(n+1)}\right),
\tag{4}
\]
以及其共轭项。由于
\(\lambda_{n,N}=\mu(n)(1-\log n/\log N)\)，(4) 是带缓变相位的
Möbius Chowla shift--1 相关，而不是普通的零频 Jordan 项。

## 3. 算术含义

若只对 \(n\) 这一连续分母带做绝对值，(2)--(4) 给出 \(N^2\) 量纲；
任何固定幂次节省都必须利用
\[
\sum_{n\asymp N}\mu(n)\mu(n+1)
 e^{2\pi iN/(n(n+1))}
\tag{5}
\]
的 signed cancellation。现有 averaged Chowla 结果提供的是平均/对数级
控制，不能直接给出 (5) 所需的平方根级 bound；而且完整双和还包含其余
Bezout 轨道，不能把 (5) 单独当作原边界的下界。

因此 (5) 是一个严格的必要关注子结构（不是原总和的下界）：它说明
\(q=1\) reciprocity 门至少包含固定移位 Chowla 的 weighted 版本。本文不把
该子结构的困难外推为 RH 不可证，也不声称已得到平方根估计。

