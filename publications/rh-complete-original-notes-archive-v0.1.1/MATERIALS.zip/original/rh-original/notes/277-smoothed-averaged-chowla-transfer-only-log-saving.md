> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 平滑 averaged-Chowla 只能转移为对数节省

日期：2026-08-16。

## 1. 目标与输入

令
\[
E_N(w)=\int_{\mathbb R}w(t)\left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt,
\qquad
K(u)=\frac1{2\pi}\int_{\mathbb R}w(t)e^{itu}\,dt .
\]
对当前 \(w=|h|/(2\pi)\)，\(K\in C^1\)、\(\|K\|_\infty+\|K'\|_\infty<\infty\)。
假设一个 averaged-Chowla 输入：存在固定 \(A\) 使得，当
\(Y/2\le X\le 4Y\)、\(10\le H\le X\)、\(0\le b\le AX\) 时，
\[
 \sum_{1\le h\le H}
 \left|\sum_{m\le X}\mu(m)\mu(m+b+h)\right|
 \le C_A\,XH\,\rho(Y).
 \tag{1}
\]
其中 \(\rho(Y)=o(1)\)。在本节的宏观段 \(H\asymp Y\) 上，MRT 的
Theorem 1.6 结合其对 \(\mu\) 的说明给出可取
\[
\rho(Y)\ll \frac{\log\log Y}{\log Y}+\frac1{\log^{1/3000}Y};
\]
常数倍的 \(X,H,b\) 变化只改变隐含常数。
这里只把 (1) 当作明确的算术输入；它不是固定移位的 Chowla 猜想。
严格地说，MRT 的 Theorem 1.1 先对 Liouville 函数给出该估计，正文随后明确说明
同一论证适用于 Möbius 函数；其 Theorem 1.6 还允许固定常数范围内的平移参数。
参见 <https://arxiv.org/abs/1503.05121>，尤其正文 Theorem 1.1、1.6 及其对
\(\mu\) 的说明。

对本节的平滑壳，\(u\asymp Y\) 而可见的 \(h\) 只落在一个固定倍数的区间内。
把该区间切成有限个长度不超过 \(u\) 的段；对 \(h<10\) 用平凡界，对其余各段
使用 (1)。这样使用 MRT 时始终有 \(H\le X=u\)，而固定平移 \(b\) 只落在
\(b\le A u\) 的范围内，不再偷偷假设 \(H>X\) 或覆盖未证明的所有小 \(H\)。

## 2. 平滑 dyadic 转移

取 \(\phi\in C_c^1((1/2,4))\)，\(\phi=1\) 于 \([1,2]\)，并令
\[
 W_{h,Y}(x)=\phi(x/Y)\phi((x+h)/Y)
 K\!\left(\log\frac{x}{x+h}\right).
\]
正半轴的一个 dyadic 壳为
\[
 B_Y^+=\sum_{h\ge1}\sum_m
 \mu(m)\mu(m+h)W_{h,Y}(m),
\]
其中 \(h\ll Y\) 由支撑自动给出。令
\[
 C_h(u)=\sum_{m\le u}\mu(m)\mu(m+h).
\]
由于 \(\phi\) 在边界消失，Abel 分部求和没有端点项：
\[
 \sum_m\mu(m)\mu(m+h)W_{h,Y}(m)
 =-\int C_h(u)\,\partial_uW_{h,Y}(u)\,du.
 \tag{2}
\]
对 \(u\asymp Y\)、\(h\ll Y\)，有
\[
 \sup_h|\partial_uW_{h,Y}(u)|\ll_K Y^{-1},
 \qquad
 \sum_{h\ll Y}\sup_u|\partial_uW_{h,Y}(u)|\ll_K1.
 \tag{3}
\]
第二项来自
\[
\left|\partial_u\log\frac{u}{u+h}\right|
=\frac{h}{u(u+h)}\ll \frac{h}{Y^2},
\]
而 \(\sum_{h\ll Y}h/Y^2=O(1)\)。

在 (2) 中先取绝对值，再用 (1)（把 \(X\) 取为积分变量 \(u\)，只改变常数），得
\[
\begin{aligned}
 |B_Y^+|
 &\le \int_{u\asymp Y}
 \sup_h|\partial_uW_{h,Y}(u)|
 \sum_{h\ll Y}|C_h(u)|\,du\\
 &\ll_K
 Y\cdot Y^{-1}\cdot (Y^2\rho(Y))
 \ll_K Y^2\rho(Y).
\end{aligned}
\tag{4}
\]
负半轴给出同样的界，\(h=0\) 对角项为 \(O_K(Y)\)。用固定的 dyadic 分割
\(Y=2^j\le N\) 并求和，严格得到加权和
\[
 E_N(w)\ll_K
 \sum_{2^j\le N}4^j\rho(2^j)+O_K(N\log N).
\tag{5}
\]
若只假设 \(\rho(Y)=o(1)\)，(5) 给出无速率的 \(E_N(w)=o(N^2)\)：先固定一个
足够大的 \(Y_0\)，小于 \(Y_0\) 的有限个壳为 \(O_{Y_0,K}(1)\)，而其余壳的
\(\rho\) 可统一压到任意给定的正数。

对 MRT 型的显式函数
\[
\rho_{\rm MRT}(Y)=\frac{\log\log Y}{\log Y}+\frac1{\log^cY},
\]
其中固定 \(c=1/3000<2\)。令 \(L=\log N\)，将壳分成
\(\log(2^j)\ge L/2\) 与 \(\log(2^j)<L/2\) 两段：前一段中
\(\rho_{\rm MRT}(2^j)\ll\rho_{\rm MRT}(N)\)，后一段的几何和至多为
\(O(NL^{1-c})\)，故逐段求和可得
\[
 \sum_{2^j\le N}4^j\rho_{\rm MRT}(2^j)
 \ll N^2\rho_{\rm MRT}(N)+O(1).
\tag{6}
\]
因此在 MRT 输入下才可写成
\[
 E_N(w)\ll_K N^2
\left(\frac{\log\log N}{\log N}+\frac1{\log^cN}\right)+O_K(N\log N).
\tag{7}
\]
这里平滑 cutoff 消除了逐 \(h\) 最大部分和接口；首要损失不是 Abel 技术，而是
输入本身只有对数级 averaged correlation。

## 3. 为什么仍不能过 RH 门

\(N^2\rho_{\rm MRT}(N)\) 对任何固定 \(\varepsilon>0\) 都远大于
\(N^{1+\varepsilon}\)。因此 (5)--(7) 不能推出当前正能量门，更不能推出 RH。要得到
\(E_N(w)\ll N^{1+\varepsilon}\)，需要把 (1) 提升为
\[
\sum_{h\ll Y}|C_h(u)|\ll Y^{1+\varepsilon}
\quad\text{在 }u\asymp Y\text{ 上统一成立},
\tag{8}
\]
或给出一个直接跨 \(h\) 的 signed spectral/intertwiner 估计。式 (8) 已是
平方根级的宏观移位相关输入，强度与 RH 门相同。

故当前严格新增结论是：MRT 型 averaged-Chowla 输入确实可以无损地转移到
固定 Mellin 比例核的 \(N^{2-o(1)}\) 能量上界，但不会产生固定幂次节省，更不会
关闭 RH。
