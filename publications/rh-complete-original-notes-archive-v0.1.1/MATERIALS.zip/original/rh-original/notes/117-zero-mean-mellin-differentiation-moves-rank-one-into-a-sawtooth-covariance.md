> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 零均值 Mellin 微分把秩一块搬入锯齿 covariance

日期：2026-08-14。

依赖：
[note 101](101-a-bv-mellin-detector-sees-exactly-uncancelled-zeta-multiplicity.md)、
[note 114](114-the-first-dirichlet-neumann-cosine-mode-alone-is-an-rh-criterion.md)、
[note 116](116-the-first-cosine-gate-has-an-rh-strength-zero-frequency-rank-one-block.md)。

证据等级：精确 Mellin 微分、Euler--Maclaurin 展开和截断卷积恒等式。

note 116 在第一余弦 detector 的 Type-II 分解中识别出
\[
\frac{2x}{\pi}\left(\sum_{n\le\sqrt x}\frac{\mu(n)}n\right)^2
\]
这一 RH 强度的零频秩一块。本文检查最直接的修正：对 detector 作
Mellin 微分，使其积分为零。主积分项确实消失，但边界项与 reciprocal-product
锯齿 covariance 接管了全部难度。

## 1. 零均值导数 detector

令

\[
b=\frac{\pi}{2},\qquad
W(u)=\cos(bu)\mathbf1_{(0,1]}(u)
\tag{1}
\]

及

\[
V(u)=(-u\partial_u-1)W(u)
=bu\sin(bu)-\cos(bu),\qquad 0<u<1,
\tag{2}
\]

并在区间外取零。则 \(V\in BV_c(0,\infty)\)，且

\[
V(0+)=-1,\qquad V(1-)=b.
\tag{3}
\]

对 \(\Re s>0\)，边界项消失，分部积分给出

\[
\boxed{
K_V(s)=\int_0^1V(u)u^{s-1}\,du
=(s-1)K_W(s).}
\tag{4}
\]

特别地，

\[
\int_0^1V(u)\,du=K_V(1)=0.
\tag{5}
\]

note 114 已证明 \(K_W(s)\ne0\) 于 \(\Re s>0\)，故

\[
K_V(s)\ne0\qquad(1/2<\Re s<1).
\tag{6}
\]

因此 note 101 立即给出

\[
\boxed{
\mathrm{RH}
\iff
\forall\varepsilon>0,\quad
\int_Y^{2Y}|U_V(x)|^2\,dx\ll_\varepsilon Y^{2+\varepsilon},}
\tag{7}
\]

其中

\[
U_V(x)=\sum_n\mu(n)V(n/x).
\tag{8}
\]

在非整数点还有精确微分式

\[
\boxed{U_V(x)=xU_W'(x)-U_W(x).}
\tag{9}
\]

整数入口处两种自然代表只相差 \(b\mu(m)=O(1)\)，不影响 (7)。

## 2. 主积分消失后的 Euler 边界

定义

\[
P_V(y)=\sum_{c\le y}V(c/y),\qquad r=\{y\},
\tag{10}
\]

以及周期 Bernoulli 多项式

\[
B_1(r)=r-\frac12,\quad
B_2(r)=r^2-r+\frac16,\quad
B_3(r)=r^3-\frac32r^2+\frac12r.
\tag{11}
\]

Euler--Maclaurin 对 \(y\ge1\) 一致给出

\[
\boxed{
P_V(y)
=\frac12-bB_1(\{y\})
+\frac{b}{y}B_2(\{y\})
+\frac{\pi^3}{48y^2}B_3(\{y\})
+O(y^{-3}).}
\tag{12}
\]

所以 \(y\int V=0\) 确实消失，但首层变成

\[
\boxed{
P_V(y)=
\frac12+\frac{\pi}{2}\left(\frac12-\{y\}\right)+O(y^{-1}).}
\tag{13}
\]

固定常数 \(1/2\) 在双 Möbius 块中产生

\[
\boxed{\frac12M(\sqrt x)^2,}
\tag{14}
\]

而锯齿项可能与它发生 signed cancellation。若逐块取绝对值，(14)
已经要求 RH 强度的 \(M(z)\ll_\varepsilon z^{1/2+\varepsilon}\)。

更一般地，对 \(C_c^1\) detector \(H\)，令

\[
\psi(t)=\{t\}-\frac12.
\tag{15}
\]

Euler 求和可写成

\[
P_H(y)
=y\int H(u)\,du+\int\psi(yu)H'(u)\,du
\tag{16}
\]

（端点跳跃按 BV 测度并入）。若 \(\int H=0\)，主积分消失，但留下

\[
\boxed{
P_H(y)=\int\psi(yu)H'(u)\,du.}
\tag{17}
\]

因此零均值把可分离 rank-one 搬成 reciprocal-product 锯齿 coupling，
而没有产生独立变量的标准 oscillatory Type-II 核。

## 3. 双线性门与原 detector 门精确等强

令

\[
\nu_x(n)=\mu(n)\mathbf1_{n\le\sqrt x}.
\tag{18}
\]

note 116 的截断恒等式给出，对 \(n\le x\)，

\[
\mu(n)=2\nu_x(n)-(\nu_x*\nu_x*1)(n).
\tag{19}
\]

乘以任意有界 detector \(H(n/x)\) 并求和，得到

\[
\boxed{
U_H(x)=2A_H(x)-T_H(x),}
\tag{20}
\]

其中

\[
A_H(x)=\sum_{n\le\sqrt x}\mu(n)H(n/x),
\tag{21}
\]

\[
T_H(x)=
\sum_{a,b\le\sqrt x}\mu(a)\mu(b)
P_H\left(\frac{x}{ab}\right).
\tag{22}
\]

平凡地

\[
|A_H(x)|\le\|H\|_\infty\sqrt x.
\tag{23}
\]

因此

\[
\boxed{
T_H(x)\ll_\varepsilon x^{1/2+\varepsilon}
\iff
U_H(x)\ll_\varepsilon x^{1/2+\varepsilon}.}
\tag{24}
\]

若 \(K_H\) 在 \(1/2<\Re s<1\) 零自由，则右边是 note 101 型
RH gate。特别地，对本文的零均值 \(V\)，(24) 仍与 RH 等强。

把 (17) 代入 (22)，承重对象为

\[
\boxed{
\int H'(u)
\sum_{a,b\le\sqrt x}
\mu(a)\mu(b)
\psi\left(\frac{xu}{ab}\right)\,du.}
\tag{25}
\]

逐项绝对值只给

\[
|T_H(x)|
\le\frac12\|H'\|_1
\left(\sum_{a\le\sqrt x}|\mu(a)|\right)^2
\ll_Hx,
\tag{26}
\]

正好差一个平方根。任何有效估计必须保留 (25) 中的 signed Möbius
covariance；先对 \((a,b)\) blocks 取绝对值会删除承重消去。

## 4. 结论

零均值 Mellin 微分有两个严格效果：

\[
\begin{array}{c|c}
\text{被删除}&y\int H\\
\text{被保留}&\text{Euler 边界与 reciprocal-product sawtooth covariance}
\end{array}
\tag{27}
\]

它没有把 Type-II 门降到严格弱于 RH 的已知估计。下一项可能改变路线的
修正必须同时处理 detector 的端点 jet，或直接控制 (25) 的 signed
covariance；仅令 \(\int H=0\) 不足。这是结构性路线边界，不是 RH 的证明。
