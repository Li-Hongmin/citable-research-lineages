> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Logarithmic 边界模态的 conormal variance 消失

日期：2026-08-11。

本文闭合 [note 051](051-averaged-trace-controls-exterior-flux-but-not-pohozaev-pairing.md) 的最后
平均正则性缺口。对属于局部 Mellin form domain 的 bounded-forcing 边界解，dyadic conormal
variance 必须趋零；结论覆盖任意多频与频率级联，不要求点态 boundary trace。

## 1. 定理

设

\[
(\mathcal V+\mathcal M)U=F,\qquad F\in L^\infty(T_0,\infty),
\]

\[
\mathcal VU(t)=2tU(t)-\int_{T_0}^{t}U(\tau)\,d\tau,
\qquad |U(t)|\le Ct^{-1/2}.
\]

假设每个紧支撑 smooth cutoff \(\eta U\) 属于

\[
D((\operatorname{Re}\mathcal M)^{1/2}).
\tag{1}
\]

由 [note 050](050-existence-of-the-averaged-logarithmic-boundary-trace.md)，

\[
Z(t):=\frac1{\sqrt t}\int_{T_0}^{t}U(\tau)\,d\tau\longrightarrow2B.
\tag{2}
\]

则

\[
\boxed{
\frac1T\int_T^{2T}|tZ'(t)|^2\,dt\longrightarrow0.}
\tag{3}
\]

此外，由

\[
\mathcal MU=F-2\sqrt t\,tZ'(t)
\]

还得到

\[
\boxed{
\frac1T\int_T^{2T}\frac{|\mathcal MU(t)|^2}{t}\,dt\longrightarrow0.}
\tag{4}
\]

## 2. 局部能量证明

令

\[
W(t)=U(t)-Bt^{-1/2},\qquad
H(t)=\int_{T_0}^{t}W(\tau)\,d\tau.
\]

由 (2)，\(H(t)=o(\sqrt t)\)。取慢 cutoff \(\eta_T\)，使其在 \([T,2T]\) 等于 \(1\)，
支撑于 \([T/2,3T]\)，且 \(|\eta_T'|\le C/T\)。

以 \(\eta_T^2W\) 与方程配对。Volterra 项精确满足

\[
\operatorname{Re}\langle\eta_T^2W,\mathcal VW\rangle
=2\int\eta_T^2t|W|^2
+\int\eta_T\eta_T'|H|^2.
\tag{5}
\]

第二项是 \(o(T)\)。Mellin-local 项分解为

\[
\operatorname{Re}\langle\eta_TW,\mathcal M(\eta_TW)\rangle
-\operatorname{Re}\langle\eta_TW,[\mathcal M,\eta_T]W\rangle.
\tag{6}
\]

第一项由 (1) 与 \(\operatorname{Re}m\ge0\) 非负。因为 \(\mathcal M\) 只有固定 log-range，
\(|\eta_T(t)-\eta_T(s)|\le C|t-s|/T\) 消去核奇性，commutator 为 \(O(T^{-1})\)。右端
\(\langle\eta_T^2W,F\rangle=O(\sqrt T)\)。因此

\[
\frac1T\int_T^{2T}t|W(t)|^2\,dt\longrightarrow0.
\tag{7}
\]

又

\[
tZ'(t)=\sqrt t\,U(t)-\frac{Z(t)}2
=\sqrt t\,W(t)+o(1),
\]

所以 (7) 推出 (3)。

## 3. 对实际 Weil 零模态的适用性

条件 (1) 不是额外的 \(H^1\) 假设。实际 Weil 零模态属于完整 logarithmic form domain；在边界
坐标与 smooth cutoff 后，同尺度正 jump 部分恰给出
\(D((\operatorname{Re}\mathcal M)^{1/2})\) 的局部能量。operator-domain 弱方程则给出 bounded
forcing。finite prime shifts 与 smooth/polar 项只进入 \(F\)。

所以 (3) 对项目中的首次退化候选零模态成立。

## 4. 结论边界

式 (3) 消除了 smooth dyadic cutoff Green pairing 中的 conormal defect，严格弱于点态
\(\sqrt tU(t)\to B\)。它不排除稀疏点态尖峰，也不自动合法化 sharp cutoff；但 Pohozaev 配对可选
smooth dyadic cutoff，因此无需先解决这些更强问题。

下一步不再是边界正则性，而是把 Archimedean、prime、smooth remainder 与 polar commutators
按统一归一化组装成完整 Weil Pohozaev identity。

