> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有限窗口相等式传到中心极限所需的一致连续性

日期：2026-08-16。

## 引理

令 \(E\) 是带 seminorm 族的局部凸空间，\(x_M\to x\)。设
\(\Lambda,\Gamma\in E'\) 是连续线性泛函，\(\Lambda_M,\Gamma_M\) 是有限窗口
pairing，并且对每个 \(M\)
\[
\Lambda_M(x_M)=\Gamma_M(x_M).
\tag{1}
\]
若存在同一族 seminorm \(p_1,\ldots,p_r\) 和常数 \(C\)，使得对所有充分大的
\(M\) 及所有 \(y\in E\)
\[
|\Lambda_M(y)-\Lambda(y)|+|\Gamma_M(y)-\Gamma(y)|
\le C\sum_{j=1}^r p_j(y-x),
\tag{2}
\]
则
\[
\Lambda(x)=\Gamma(x).
\tag{3}
\]

证明只是三角不等式：
\[
|\Lambda(x)-\Gamma(x)|
\le |\Lambda(x)-\Lambda_M(x_M)|
 +|\Gamma_M(x_M)-\Gamma(x)|,
\]
中间两项由 (1) 抵消，再用 (2) 和 \(x_M\to x\)；令 \(M\to\infty\) 即得。
同样的证明适用于参数 \(w\) 的局部一致版本，只需在紧集上取统一的
seminorm 常数。

## 一致连续性不能省略

仅有 \(x_M\to x\) 和有限窗口相等式并不够。取 \(E=\ell^2\)、
\(x_M=e_1+e_M\to e_1\)，并令
\[
\Lambda_M(y)=\Gamma_M(y)=M y_M.
\]
则每个 \(M\) 都有精确有限窗口相等式，但
\(\Lambda_M(x_M)=\Gamma_M(x_M)=M\) 发散；这些 pairing 没有统一连续性，
不能传到 \(x=e_1\) 的极限。这个例子不涉及算术，只说明缺少 (2) 时，
“逐窗口恒等”在逻辑上不能替代极限估计。

## 对 Shimizu v8 声称的精确定位

稿件 Theorem 6.155 的三步链正对应：

1. Lemma 6.154：有限窗口 pairing 相等；
2. Lemma 6.109：有限窗口中心代表在 seminorm 中收敛；
3. Theorem 6.152：两侧 pairing 对这些 seminorm 一致连续。

所以，若 Lemmas 6.109 与 6.152 的定义域、常数和端点余项都确实按正文证明，
Theorem 6.155 的极限传递在逻辑形式上没有额外的循环步骤。真正需要独立核验
的是这两个 lemma 是否从其具体 seam/finite-part 构造得到，尤其是：

- 常数是否对窗口 \(M\) 一致，而不是随 \(M\) 的 Gram inverse 条件数增长；
- 过渡环、端点有限部和 jet counterterm 是否已经包含全部 remainder；
- pairing 的连续性是否作用于同一个 quotient/seminorm 空间，而不是把中心对象
  通过目标函数值预先定义出来；
- 这些估计是否保持 \(w\) 参数的局部一致性。

## 裁决

这个引理不能证明 RH，也不能反驳 Shimizu v8；它把外部声称的最小可审计门
从模糊的“取 \(M\to\infty\)”精确化为“验证两个统一 seminorm 估计”。在本项目
语言中，这仍是 signed arithmetic intertwiner 的极限版本，而非 det2 自伴性
本身带来的结论。

