> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Active-prime orbit 的算术坐标与 \(L^2\) resolvent 衰减

日期：2026-08-11。

本文在 note 027 的无限稠密轨道反例之后，给出全尺度仍然成立的 prime-side 结构：算术格点坐标、
多项式 word-ball 上界以及无需 orbit 直积分的 \(L^2\) resolvent 衰减。

## 1. 可测 orbit graph

固定 \(a<\infty\) 与奇偶扇区 \(\sigma\)。note 026 给出

\[
P_a^\sigma
=\sum_{\substack{n\le e^{2a}\\\Lambda(n)>0}}
\left\{
-\alpha_n(S_{d_n}+S_{d_n}^*)
-\sigma\alpha_nJ_{d_n}
\right\},
\qquad
\alpha_n=\frac{\Lambda(n)}{\sqrt n}.
\tag{1}
\]

活跃生成元有限。以这些 partial translations/reflections 的图为边，在 \((0,a)\) 上得到局部有限的
可测图。对可测集 \(E,F\subset(0,a)\)，定义本质 graph distance

\[
d_G(E,F)
=\inf\left\{
k\ge0:\ \mathbf1_E(P_a^\sigma)^k\mathbf1_F\ne0
\right\}.
\tag{2}
\]

该定义自动忽略零测度端点。

## 2. Neumann path-sum 定理

令

\[
p_a=\|P_a^\sigma\|,
\qquad
\beta>p_a,
\qquad
\delta=\beta-p_a.
\]

因为 \(P_a^\sigma\) 的 graph propagation 为一，

\[
(\beta I+P_a^\sigma)^{-1}
=\frac1\beta\sum_{k\ge0}(-P_a^\sigma/\beta)^k
\tag{3}
\]

按算子范数收敛。若 \(m=d_G(E,F)\)，则前 \(m\) 项的 \(E\)-\(F\) 块为零，故

\[
\boxed{
\left\|
\mathbf1_E(\beta I+P_a^\sigma)^{-1}\mathbf1_F
\right\|
\le
\frac1\delta
\left(\frac{p_a}{\beta}\right)^m.}
\tag{4}
\]

等价地，

\[
\left\|
\mathbf1_E(\beta I+P_a^\sigma)^{-1}\mathbf1_F
\right\|
\le
\delta^{-1}
\exp\!\left[-m\log(1+\delta/p_a)\right].
\tag{5}
\]

该结论不要求 component 有限、闭合或在实轴中离散。

## 3. 加权 Combes--Thomas 形式

给每类有向边 \(e\) 赋权 \(w_e\) 与长度 \(\ell_e>0\)。若可测函数 \(\rho\) 在 \(e\)-边两端的
差不超过 \(\ell_e\)，置

\[
\eta_a(\gamma)
=\sum_e |w_e|(e^{\gamma\ell_e}-1).
\tag{6}
\]

也可把右端替换为 essential supremum 的局部 weighted-degree Schur 界。若

\[
\eta_a(\gamma)<\delta,
\]

则截断指数权共轭给出

\[
\boxed{
\left\|
\mathbf1_E(\beta I+P_a^\sigma)^{-1}\mathbf1_F
\right\|
\le
\frac{e^{-\gamma d_\ell(E,F)}}
{\delta-\eta_a(\gamma)}.}
\tag{7}
\]

指数率不能只依赖 \(\delta\) 而对所有权重统一。权 \(M\) 的长路径在
\(\beta=2M+\delta\) 时具有衰减率

\[
\operatorname{arcosh}(1+\delta/(2M))\longrightarrow0.
\tag{8}
\]

因此任何全尺度估计必须保留 \(p_a\)、局部 weighted degree 或等价的 edge-scale 参数。

## 4. 算术 orbit 坐标

令 \(p_1,\ldots,p_r\) 为固定尺度下出现的活跃素数。选定起点 \(x_0\) 后，每个 orbit 点均可写成

\[
\Phi_{x_0}(\varepsilon,m)
=\varepsilon x_0+\sum_{i=1}^r m_i\log p_i,
\qquad
\varepsilon\in\{\pm1\},\quad m\in\mathbf Z^r.
\tag{9}
\]

素数对数的 \(\mathbf Z\)-线性独立性保证同一 sheet 上表示唯一。两个 sheets 发生识别当且仅当

\[
2x_0=\sum_i v_i\log p_i
\tag{10}
\]

对某个 \(v\in\mathbf Z^r\) 成立；这只产生相应的单个 sheet relation。

若 \(K_a\) 是活跃 prime powers 中最大的指数，则每个 graph step 至多使某个坐标改变 \(K_a\)。
因此

\[
\boxed{
\#B_G(x,R)
\le2(2K_aR+1)^r
=O_a(R^r).}
\tag{11}
\]

这解释了 note 027 的表面悖论：orbit 在实轴中可以稠密，但在内在 word metric 中仍具有多项式
上体积增长。

## 5. 为什么当前不直接套 Jaffard/Fang--Shin--Sun

局域矩阵代数在求逆下封闭是自然候选工具；参见
[Balazs--Gröchenig](https://arxiv.org/abs/1611.09692)、
[Fang--Shin--Sun](https://arxiv.org/abs/1909.08409) 与
[Köhldorfer--Balazs](https://arxiv.org/abs/2501.09603)。

但 (11) 只有球体积上界，不自动给 intrinsic counting measure 的 doubling；partial-domain 子图
可以有 bottleneck。另一方面，实轴中的稠密 orbit 不是 relatively separated。人工
\(\mathbf Z^r\times\{\pm1\}\) 坐标虽离散，仍需先建立原 \(L^2(0,a)\) 算子的可测
orbit-fibre/groupoid 实现，才能把这些离散矩阵定理合法传回原算子。

因此当前无需额外假设即可使用的最强接口是 (4) 与 (7)，而不是点态 Green kernel 或未经证明的
orbit 直积分。

## 6. 边界

\(\delta_x\notin L^2(0,a)\)。每个 generator word 是支撑在 partial-map 图上的 weighted
composition operator，所以 resolvent 一般具有 groupoid/distributional 核，而不是相对于二维
Lebesgue 测度的普通函数核 \(K(x,y)\)。式 (4)、(7) 的 support-off-diagonal 估计是正确的最小
\(L^2\) 陈述。

本 note 建立 prime resolvent 的局域性，但 Robin modes 是全局振荡函数；要完成 note 024 的
frame 铰链，还需把该 support 局域性转换为 deficit-weighted frequency estimate。

