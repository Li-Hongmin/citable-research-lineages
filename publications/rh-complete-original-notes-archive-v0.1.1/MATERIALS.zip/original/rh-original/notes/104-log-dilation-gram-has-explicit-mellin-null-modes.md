> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 对数 dilation Gram 有显式 Mellin 零模

日期：2026-08-14。

依赖：
[note 097](097-continuous-log-dilation-removes-the-endpoint-without-losing-the-detector.md)、
[note 100](100-log-dilation-gives-paired-additive-differences-but-not-a-divisor-gram.md)、
[note 103](103-the-centered-log-dilation-gram-has-a-compact-continuum-limit.md)。

证据等级：连续算子的精确零空间、有限离散 Gram 的显式定量近零向量，
以及真实 Mertens 系数上剩余门的严格归约。

本文强化 note 103 的紧性障碍。log-uniform dilation 产生的连续 Gram
不只是没有统一谱隙，而是有无限多个显式 Mellin 零模；相应有限矩阵也有
Rayleigh 商为 \(O(Y^{-2})\) 的显式向量。因此任何有效下界必须真正使用
\(M(d)\) 的算术结构，不能来自该正 Gram 的一般算子性质。

## 1. 连续 Gram 的精确零空间

固定 \(R>1\)，记 \(a=2/3\)、\(A=G_R'\)，并在

\[
D_R=(a,2R)
\]

上定义

\[
(Tf)(x)=\int_{D_R}x^{-1}A(u/x)f(u)\,du,
\qquad 1<x<2.
\tag{1}
\]

note 103 的连续核正是 \(T^*T\)。由 note 097，
\(G_R\in W^{1,\infty}_c\)、
\(\operatorname{supp}A\subset[a,R]\)，且

\[
K_R(s)=\int_0^\infty G_R(t)t^{s-1}\,dt
=K(s)\frac{R^s-1}{s\log R}.
\tag{2}
\]

分部积分给出整函数恒等式

\[
m_R(s):=\int_a^R A(t)t^s\,dt
=-sK_R(s)
=\frac{1-R^s}{\log R}K(s).
\tag{3}
\]

故对每个 \(k\in\mathbb Z\)，

\[
s_k=\frac{2\pi ik}{\log R},
\qquad m_R(s_k)=0.
\tag{4}
\]

令

\[
f_k(u)=u^{s_k}\mathbf 1_{D_R}(u).
\tag{5}
\]

对 \(1<x<2\)，变量代换 \(u=xt\) 后，
\(x[a,R]\subset(a,2R)\)，于是

\[
(Tf_k)(x)
=x^{s_k}\int_a^R A(t)t^{s_k}\,dt=0.
\tag{6}
\]

因此 \(f_k\in\ker T=\ker(T^*T)\)。这些函数线性无关，所以连续
Gram 有无限维精确零空间。\(k=0\) 是由
\(\int A=G_R(R)-G_R(a)=0\) 产生的平凡常数零模；
\(k\ne0\) 才是 log-uniform 平滑产生的非平凡 Mellin 零格。

## 2. 有限离散 Gram 的 \(Y^{-2}\) 近零模

沿用 note 103 的矩阵

\[
B_{N,d}=G_R(d/N)-G_R((d+1)/N),
\qquad Y<N\le2Y.
\tag{7}
\]

取一格端点 padding

\[
\mathcal D_Y={d\in\mathbb N:aY-1<d<2RY},
\qquad
q_{Y,k}(d)=\left(\frac dY\right)^{s_k}
\mathbf1_{\mathcal D_Y}(d).
\tag{8}
\]

该列集包含所有非零 \(B_{N,d}\)，并且

\[
\|q_{Y,k}\|_2^2=(2R-a)Y+O_R(1).
\tag{9}
\]

绝对连续性给出

\[
B_{N,d}=-\int_{d/N}^{(d+1)/N}A(t)\,dt.
\tag{10}
\]

将小区间重新合并，并使用 (3)--(4)，得到精确式

\[
(Bq_{Y,k})_N
=-\left(\frac NY\right)^{s_k}
\int_a^R A(t)
\left[
\left(\frac{\lfloor Nt\rfloor}{N}\right)^{s_k}-t^{s_k}
\right]dt.
\tag{11}
\]

当 \(Y\ge3\) 时，积分中
\(\lfloor Nt\rfloor/N\ge1/3\)。写
\(\tau_k=\Im s_k\)，由

\[
|x^{i\tau_k}-y^{i\tau_k}|
\le |\tau_k|\,|\log(x/y)|
\le \frac{3|\tau_k|}{N}
\tag{12}
\]

可得

\[
|(Bq_{Y,k})_N|
\le \frac{3|\tau_k|}{N}\|G_R'\|_1.
\tag{13}
\]

所以

\[
\boxed{
\frac{q_{Y,k}^*B^*Bq_{Y,k}}{\|q_{Y,k}\|_2^2}
\le
\frac{9\tau_k^2\|G_R'\|_1^2}
{2(2R-2/3)}Y^{-2}
\left(1+O_R(Y^{-1})\right).
}
\tag{14}
\]

对 \(k=0\)，甚至有 \(Bq_{Y,0}=0\)。对固定 \(k\ne0\)，从
\(q_{Y,k}\) 减去其离散均值不改变 \(Bq_{Y,k}\)，而所得向量的范数仍为
\(\asymp_{R,k}Y^{1/2}\)。故去掉常数方向后，\(O(Y^{-2})\) 退化依然存在。

## 3. 为什么 Möbius 增量不能软转移到 Mertens 向量

令 \(I_Y=\mathbb N\cap[aY,bY]\)，并记

\[
\phi_{\tau,Y}(d)=(d/Y)^{i\tau}.
\]

任意向量 \(q\) 到该复方向的距离满足精确恒等式

\[
\min_{c\in\mathbb C}\|q-c\phi_{\tau,Y}\|_2^2
=\|q\|_2^2-
\frac{\left|\sum_{d\in I_Y}q(d)(d/Y)^{-i\tau}\right|^2}{|I_Y|}.
\tag{15}
\]

若 \(q(d)=\mu(d)\)，则平方自由数密度给出

\[
\|q\|_2^2=\left(\frac6{\pi^2}+o(1)\right)|I_Y|,
\tag{16}
\]

而固定 \(\tau\) 时，素数定理与部分求和给出

\[
\sum_{d\in I_Y}\mu(d)(d/Y)^{-i\tau}=o(Y).
\tag{17}
\]

所以 Möbius 增量确实不会渐近落入任一固定 Mellin 零方向。
但 note 100 的 Abel 重组中真实系数是 \(M(d)\)，不是 \(\mu(d)\)。
差分 \(M(d)-M(d-1)=\mu(d)\) 损失一个尺度：即使 \(\mu\) 与零模
保持绝对 \(\gg\sqrt Y\) 的距离，也只推出 \(M\) 的绝对误差
\(\gg\sqrt Y\)，相对于可能大得多的 \(\|M\|_2\) 并无参数一致夹角。

对 \(q(d)=M(d)\)，所需投影是

\[
E_M(Y,\tau)=
\sum_{d\in I_Y}M(d)(d/Y)^{-i\tau}.
\tag{18}
\]

它经离散或连续部分求和化为 shifted-Möbius 量。其全区间原型为

\[
\boxed{
B_\tau(X):=
X^{1-i\tau}M(X)-\sum_{n\le X}\mu(n)n^{1-i\tau}
=(1-i\tau)\int_1^X M(x)x^{-i\tau}\,dx.
}
\tag{19}
\]

经典零自由区只给 \(B_\tau(X)\) 的 \(X^2\) 乘零自由区衰减因子级控制，
不足以证明 \(M\) 与实零空间
\(\operatorname{span}\{\cos(\tau\log u),\sin(\tau\log u)\}\)
保持统一夹角。另一方面，对任一固定 \(\tau\)，平方根级门

\[
B_\tau(X)=O_{\tau,\varepsilon}(X^{3/2+\varepsilon})
\qquad(\forall\varepsilon>0)
\tag{20}
\]

与 RH 等价：正向由 RH 下的 Mertens 界积分得到；反向由

\[
\int_1^\infty M(x)x^{-s-i\tau-1}\,dx
=\frac1{(s+i\tau)\zeta(s+i\tau)}
\tag{21}
\]

及一次分部积分延拓到 \(\Re s>1/2\)。

注意 (20) 是一个足够强的绝对控制；当前真正需要的只是 (18) 相对于
\(\|M\|_2\) 的非饱和夹角，尚未证明两者等价。这里不能把“现有软方法不足”
误写成“不可能存在较弱的算术可观测不等式”。

## 4. dilation 生成子空间也不能提供逃逸

把“算术子空间”理解成某个 Möbius/Mertens 函数的全部双侧 dilation
的闭线性包络，同样不能恢复下界。固定 \(\sigma>1\)，在 log 坐标中令

\[
v_\sigma(y)=e^{-\sigma y}U_F(e^y).
\tag{22}
\]

其 Fourier 变换为

\[
\widehat v_\sigma(t)=\frac{K(\sigma+it)}{\zeta(\sigma+it)}.
\tag{23}
\]

由于 \(\zeta\) 在 \(\Re s>1\) 无零，而非零 Mellin 分子 \(K\) 的零点
离散，(23) 几乎处处非零。Wiener 平移闭包定理于是说明 \(v_\sigma\)
的全部平移张成整个相应加权 \(L^2\) 空间。对 \(M\) 亦同，其 Mellin
像为 \(1/(s\zeta(s))\)。因此，任何在这类 dilation 闭线性包络上成立的
bounded-below 不等式都会自动成为整个 raw \(L^2\) 空间上的下界，
与 note 102 的无原子乘子障碍矛盾。

所以可能存活的对象只能是“不取任意线性组合”的真实单轨道、单 shell
算术不等式，而不能泛称为 dilation 生成子空间 coercivity。

## 5. 精确路线边界

由 (6) 与 (14)，下列两条路线已关闭：

1. 从连续 centered log-dilation Gram 的正号推出 raw \(L^2\) coercivity；
2. 希望有限离散化自动移除连续紧算子的近零模。

剩余最薄门是：证明真实 Mertens 向量在每个相关 shell 上与
log-uniform Mellin 零空间保持足以控制 note 100 covariance gate 的定量横截性；
或者构造与已知算术约束兼容的近零族，从而关闭这一最后逃逸。
现阶段两者均未完成。
