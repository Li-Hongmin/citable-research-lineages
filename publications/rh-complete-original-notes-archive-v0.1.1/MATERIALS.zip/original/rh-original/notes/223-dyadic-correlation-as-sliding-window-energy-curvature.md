> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Dyadic Liouville correlation as sliding-window energy curvature

日期：2026-08-16。

本 note 给出一个精确的、无需渐近假设的重写。它把 signless dyadic
相关块的缺口定位为滑动窗口平方能量的二阶差分，而不是边界或记号问题。

令 \(a_n\) 是任意有限支撑序列；在本项目中取
\(a_n=\lambda(n)\mathbf 1_{1\le n\le X}\)，并将 \(a_n\) 零延拓到
\(\mathbb Z\)。定义
\[
 S_{r,L}:=\sum_{n=r}^{r+L-1}a_n,\qquad
 \mathcal E_L:=\sum_{r\in\mathbb Z}|S_{r,L}|^2,
 \]
以及
\[
 C_h:=\sum_{n\in\mathbb Z}a_n\overline{a_{n+h}}.
 \]
有限支撑保证所有和式有限。每一对 \(n,n+h\) 同时落在长度 \(L\)
窗口中的起点数恰为 \((L-h)_+\)，故有精确恒等式
\[
 \mathcal E_L
 =L\,C_0+2\sum_{1\le h<L}(L-h)\operatorname{Re}C_h.
\tag{1}
\]
令
\[
 G_L:=\frac{\mathcal E_L-LC_0}{2}.
\]
则
\[
 G_{L+1}-G_L=\sum_{1\le h\le L}\operatorname{Re}C_h.
\tag{2}
\]
因此，对 \(H\ge1\)，
\[
\boxed{
 \sum_{H\le h<2H}\operatorname{Re}C_h
 =\frac12\bigl(
 \mathcal E_{2H}-\mathcal E_{2H-1}
 -\mathcal E_H+\mathcal E_{H-1}
 \bigr).
}
\tag{3}
\]
对实值 Liouville 序列，\(\operatorname{Re}C_h=C_h\)，这正是
\(D_H(X)\)（当 \(2H\le X\)；靠近 \(X\) 时零延拓自动处理边界）。

## 结论与限制

\(\mathcal E_L\ge0\) 只说明滑动窗口能量本身非负，并不控制右侧的
二阶差分。即使所有 \(\mathcal E_L\) 非负，式 (3) 仍可有正、负的大幅
振荡。因而把相关块写成平方能量差，并不能由 Hilbert 空间正性推出
\(O(X^{1+\varepsilon})\)。

最简单的代数反例是 \(a_n\equiv1\)（支撑在 \(1\le n\le X\)）。在
忽略 \(O(L^2)\) 的边界项时，\(\mathcal E_L\asymp XL^2\)，而
\[
 \sum_{H\le h<2H}C_h\asymp XH.
\]
所以“窗口平方能量非负”对一般有界序列完全不提供目标的 \(O(X)\)
级 dyadic 相关界；必须使用 \(\lambda\) 的额外乘法结构。

若存在统一的局部平方函数估计
\[
 \mathcal E_L\ll_\varepsilon X L^{1+\varepsilon}
\quad(1\le L\le X),
\tag{4}
\]
式 (3) 只给出 \(O(XH^{1+\varepsilon})\)，仍不足以在所有
\(H\) 上得到 \(O(X^{1+\varepsilon})\)。要得到后者，必须控制
\(\mathcal E_{2H}-\mathcal E_{2H-1}\) 与
\(\mathcal E_H-\mathcal E_{H-1}\) 的差，而不是分别取绝对值。
这正是跨移位 signed cancellation 的局部能量版本。

数值上，\(\mathcal E_L\) 的二阶差分与 note 222 的 \(D_H(X)\) 完全一致；
该恒等式不使用 RH、Chowla 或任何有限计算，因此可作为后续证明的精确入口。
它也排除了“只证明窗口能量非负即可”的捷径。
