> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Half-lattice Schur compression and the positive-energy gate

## 主压缩引理

设 \(A>0\)、\(H=H^*\) 且

\[
A-HA^{-1}H\succeq0.
\]

对任意等距嵌入 \(E_L\)，令

\[
A_L=E_L^*AE_L,\qquad H_L=E_L^*HE_L.
\]

定义

\[
V=A^{1/2}E_LA_L^{-1/2}.
\]

则 \(V^*V=I\)，并且

\[
A_L^{-1/2}H_LA_L^{-1/2}
=V^*(A^{-1/2}HA^{-1/2})V.
\]

因此压缩仍是 self-adjoint contraction：

\[
\boxed{
A_L-H_LA_L^{-1}H_L\succeq0.
}
\tag{1}
\]

这一步不需要 \(E_L\) 被 reflection 保持。

## 对 reciprocal detector 的精确形式

在 note 189 的完整 divisor 格上，取
\(A=G_{|h|}\)、\(H=G_hR_X\)，并令 \(L_X=\{a<\sqrt X:a\mid X\}\)。
对偶核
\(g(t)=P(e^{|t|})/2\) 有

\[
(H_L)_{ab}=g\!\left(\log\frac X{ab}\right)
=\frac12P\!\left(\frac X{ab}\right)
\]

（因为 \(a,b<\sqrt X\)）。所以论文 reciprocal 半格矩阵 \(Q_X\) 满足

\[
H_L=\frac12Q_X,
\]

从 (1) 得到

\[
\boxed{
A_L-\frac14Q_XA_L^{-1}Q_X\succeq0.
}
\tag{2}
\]

特别地，对任意半格向量 \(c_L\)，

\[
\left|c_L^*Q_Xc_L\right|
\le 2\,c_L^*A_Lc_L.
\tag{3}
\]

这是真正的 half-lattice Schur bridge；它比逐 entry 取绝对值严格得多。

## 真正承重的正能量门

式 (3) 将 reciprocal signed form 的控制压成一个正能量问题：

\[
\boxed{
c_L^*A_Lc_L
=\frac1{2\pi}\int |h(\xi)|
\left|\sum_{a\in L_X}c_a e^{i\xi\log a}\right|^2d\xi.
}
\tag{4}
\]

对 Möbius 半格向量 \(c_a=\mu(a)\)，若能证明

\[
c_L^*A_Lc_L\ll_\varepsilon X^{1/2+\varepsilon},
\tag{5}
\]

则立即得到 \(Q_X\ll_\varepsilon X^{1/2+\varepsilon}\)。但 (5) 仍是一个
加权 Möbius Dirichlet-polynomial \(L^2\) 界；仅由 \(A_L\succeq0\) 或
二通道 Gram 的正性不能推出。

因此当前最薄的可检验 A 接口已经从“证明 signed block 正性”变成：

\[
\text{在 }|h|\text{ 的正能量度量下，证明半格 Möbius 指数和的 }
X^{1/2+\varepsilon}\text{ 界。}
\]

这仍可能是 RH-strength；本 note 只给出精确 Schur 压缩与等价承重门。

范围修正：本 note 的 \(L_X\) 记号原先沿用了 divisor 半格。note 192
证明反射后的 \(X/a\) 可以只是实数 Hilbert 标签，因此同一 Schur 压缩
直接适用于全部 \(a\le\sqrt X\)。由此，原始 reciprocal-product 二次型
没有额外的 divisor-to-common-scale completion 误差；剩余门应理解为
全整数半格的式 (4)，而非仅 divisor 子格。
