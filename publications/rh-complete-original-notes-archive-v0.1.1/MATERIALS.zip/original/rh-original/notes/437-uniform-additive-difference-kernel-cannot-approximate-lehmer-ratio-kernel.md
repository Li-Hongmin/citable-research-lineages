> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 加法差核不能在完整 dyadic 块上统一近似 Lehmer 比值核

日期：2026-08-17。

## 1. 一个不依赖算术的有限障碍

在归一化 dyadic 块 \([1,2]^2\) 上令
\[
 R(u,v)=\frac{\min(u,v)}{\max(u,v)}.
\]
对任意只依赖差值的函数 \(S\colon[-1,1]\to\mathbb C\)，都有
\[
 \inf_S\|R(u,v)-S(u-v)\|_{L^\infty([1,2]^2)}\ge \frac1{24}.
\tag{1}
\]
证明只需取同一差值 \(\delta=1/2\) 的两点：
\[
 (u_1,v_1)=(3/2,1),\qquad (u_2,v_2)=(2,3/2).
\]
两点都满足 \(u_i-v_i=1/2\)，但
\[
 R(u_1,v_1)=\frac23,\qquad R(u_2,v_2)=\frac34.
\]
因此 \(S(1/2)\) 至少在一处产生误差
\(\frac12|\frac34-\frac23|=\frac1{24}\)，得到 (1)。

## 2. 离散版本

取偶数 \(X\)，在 \(m,n\in[X,2X]\) 中考虑
\[
 (m_1,n_1)=(3X/2,X),\qquad
 (m_2,n_2)=(2X,3X/2).
\]
两对的差值都为 \(X/2\)，而 Lehmer 核的比值分别为 \(2/3\) 与 \(3/4\)。
所以任意离散差核 \(S(m-n)\)，甚至任意缩放形式 \(S((m-n)/X)\)，在这两个矩阵
条目上也至少有一个 \(1/24\) 的误差。这个结论与 \(\mu\) 的取值无关。

## 3. 对局部 Fourier 路线的含义

加法局部 Fourier 矩产生的 sinc 核、有限 Fourier 和以及任何固定频带的
平移不变核都只依赖 \(m-n\)。因此它们在完整 dyadic 块上不能直接替代
\[
 L(m,n)=\frac{\min(m,n)}{\max(m,n)}
 =e^{-|\log m-\log n|}.
\]
把块切成相对宽度 \(1/J\) 的小块后，块内的比值核才可用差核作误差
\(O(J^{-1})\) 近似；但这需要 \(J\to\infty\)，并且留下所有小块之间的交叉项。
交叉项正是当前 signed multiplicative-energy 门，而不是局部 Fourier 矩已控制的
对角能量。

## 4. 裁决

式 (1) 排除了“把加法局部矩通过一次变量替换直接变成 Lehmer 能量”的具体捷径。
任何成功的桥都必须至少包含位置依赖的振幅、跨小块交叉项，或真正的
乘法对数频率 intertwiner；现有 \(U^2\)、局部 Fourier 矩和 additive large-sieve
结果均没有提供这一层。该障碍不是 RH 的证明，也不排除复杂的跨尺度构造。
