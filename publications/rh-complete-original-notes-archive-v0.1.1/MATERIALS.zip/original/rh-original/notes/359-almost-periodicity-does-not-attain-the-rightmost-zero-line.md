> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 几乎周期性不能把非临界零点的上确界变成最右零点

日期：2026-08-16。

## 命题

设

\[
 \sigma_*:=\sup\{\Re\rho:\zeta(\rho)=0,\ 0<\Re\rho<1\}.
\]

任何只利用零点重复、平移复现或局部 Rouché 稳定性得到的结论，若其
输出形式仅为

\[
 \forall\varepsilon>0\ \exists\rho_\varepsilon,
 \qquad \Re\rho_\varepsilon>\sigma_*-\varepsilon,
\tag{1}
\]

则不能推出存在零点 \(\rho_*\) 满足
\(\Re\rho_*=\sigma_*\)。

## 证明

由 \(\sigma_*\) 的定义，(1) 本身只是上确界的逼近性质。对应的
零点序列完全可能满足 \(|\Im\rho_\varepsilon|\to\infty\)，因而不含
收敛子列。零点集合在每个有界矩形内虽为离散集，但这不约束无界高
度方向上的聚集行为；因此不能从 (1) 提取一个有限高度的极限零点。

同样，若局部几乎周期性和 Rouché 定理给出

\[
 |\rho_n-(\rho+i\tau_n)|<\varepsilon_n,
 \qquad \varepsilon_n\to0,
\tag{2}
\]

它只说明存在实部趋近 \(\Re\rho\) 的复现零点。若 \(\Re\rho<\sigma_*\)，
它不会制造实部超过 \(\sigma_*\) 的零点；若取一列
\(\Re\rho_n\uparrow\sigma_*\)，(2) 仍没有给出某个 \(n\) 的等号。

## 对轮廓反证路线的直接影响

Abe 工作稿的极点矛盾需要先选定一条包含“最右非临界零点”的垂直线，
或至少需要一个严格达到的最大实部。仅知道存在非临界零点时，可以选
任意其所在直线 \(\Re s=\beta\)，但不能把 \(\beta\) 替换成
\(\sigma_*\) 并声称该线上有零点。若论证依赖 \(\sigma_*\) 线上的极点，
必须另行证明以下二者之一：

1. \(\sigma_*\) 被某个零点达到；或
2. 轮廓估计对一列 \(\beta_n\uparrow\sigma_*\) 具有统一常数和可交换的
   极限，从而直接得到矛盾。

现有的“重复零点/几乎周期性”叙述不提供第 1 项，也不自动提供第 2 项。
这与 note 358 发现的复极点留数遗漏是两个独立缺口；修复留数后仍不能
用上确界替代实际零点。

作为文献边界，Tao 对 Backlund 定理的表述明确把“按高度区间的本质零点
分布”与全部零点实部的上确界区分开来；前者可推出 Lindelöf 型结论，
但不等于后者被某个零点达到：
<https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/>。
相关符号 \(\Theta\) 与本质上确界的区分也见
<https://mathoverflow.net/questions/486575/relation-between-the-zeros-of-zetas-and-the-behavior-of-zetas-on-verti>。

## 结论

该路线目前只能被严格表述为：若补充一个“最右实部达到”或等强的
统一极限引理，轮廓方案才有进一步检验的对象。几乎周期性本身不是
这个引理，故不能作为 Abe 方案的修复步骤，也不构成 RH 的新证明。
