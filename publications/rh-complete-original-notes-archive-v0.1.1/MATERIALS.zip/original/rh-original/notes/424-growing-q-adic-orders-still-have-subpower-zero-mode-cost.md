> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 424. 次对数增长的 q-进制滤波阶仍付出次幂零模代价

> **更正（见 note 425）**：本 note 的增长阶 Cauchy 常数控制成立；但第 3 节把
> 有限能量界解释为 RH 门是不成立的，有限到无限尾的 moving-kink 转移仍未证明。

## 1. 适用的有限链

固定 (q\ge2)，允许阶数 (r=r(X)) 随 (X) 变化。沿用 note 423 的有限滤波器

\[
P_r(z)=(1-qz)^r,
\]

以及 reciprocal 尾 (T_{r,q,X}(k))。令 (J) 满足
\[
q^{J-1}\le X<q^J.
\]
有限 Newton 反演完全不依赖 (r) 固定，仍给出
\[
A_X=(-1)^r\sum_{j=1}^{J+r-1}
\binom{j}{r-1}T_{r,q,X}(q^j).
\tag{1}
\]

由于 (q^{J+r-1}\le q^rX)，这些采样点都包含在自然支撑的能量中。

## 2. 对阶数的显式 Cauchy 常数

定义
\[
C_{r,q}:=
\sum_{j\ge1}\frac{\binom{j}{r-1}^{2}}{2q^j-1}.
\tag{2}
\]
由 (1) 和 Cauchy--Schwarz，
\[
|A_X|^2\le C_{r,q}E_{r,q,X}.
\tag{3}
\]

取任意 (0<a<\sqrt q-1)。非负系数的生成函数给出
\[
\binom{j}{r-1}=[z^{r-1}](1+z)^j
\le \frac{(1+a)^j}{a^{r-1}}.
\]
又 (2q^j-1\ge q^j)，故
\[
C_{r,q}\le a^{-2(r-1)}
\sum_{j\ge1}\left(\frac{(1+a)^2}{q}\right)^j
=K_{q,a}\,a^{-2r},
\tag{4}
\]
其中 (K_{q,a}<\infty) 与 (r,X) 无关。特别地，对固定 (q)，
\[
\log C_{r,q}=O_q(r).
\tag{5}
\]

## 3. 次对数阶的统一 RH 门

设 (r(X)=o(\log X))，并假设存在对该阶数族统一的能量界
\[
E_{r(X),q,X}\ll_{q,\varepsilon}(q^{r(X)}X)^{1+\varepsilon}
\qquad(\varepsilon>0).
\tag{6}
\]
因为 \(q^{r(X)}=X^{o(1)}\)，由 (3)--(5) 只能得到
\[
|A_X|\ll_{q,\varepsilon}X^{1/2+\varepsilon+o(1)}.
\tag{7}
\]
这不是 RH 所需的 reciprocal 负半幂界，不能由 Abel 变换推出 RH。
若阶数固定，内部零模抵消可把能量转给无限尾并使用 note 420；但对真正变化的
\(r(X)\)，滤波器本身也随 \(X\) 变化，该 Mellin 延拓不能由 (6) 直接得到。

## 4. 对“增长阶逃逸”的含义

note 393 的局部零频估计显示，要把
\((1-2^{it})^r\) 在 \(|t|\lesssim1/\log X\) 的质量压到次幂尺度之外，临界候选阶至少为
\[
r\asymp\frac{\log X}{\log\log X}.
\]
这个阶仍满足 (r=o(\log X))，同时 (2^r=X^{o(1)})。因此 (6) 一旦以自然支撑尺度统一成立，(7) 仍恢复 RH；增大阶数并没有在逻辑上创造低于 RH 的能量门。

这不是对 (6) 的证明。它严格关闭的是“只靠让滤波器阶数增长，就能把同一个自然能量界降到 RH 以下”的推理：增长阶的唯一剩余问题，是对高阶 dyadic Möbius signed difference 及 moving-kink 边界带证明新的统一能量界。普通正 Gram 或 zero-free 区域尚未提供该界。
