> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 绝对可和的整数 Dirichlet 系数也不能实现 Möbius 频率反射

日期：2026-08-16。

note 338 的有限维指数独立性可提升到无限整数系数的
\(\ell^1\) 类。结论是：即使允许无限支撑，只要系数绝对可和，仍不能
把 \(F_\mu(t)\) 精确变成 \(F_\mu(-t)\)。

## 命题

令 \(c=(c_m)_{m\ge1}\in\ell^1(\mathbb N)\)、\(d=(d_n)_{n\ge1}\in\ell^1(\mathbb N)\)，
并假设
\[
 \sum_{m\ge1}c_m m^{it}
 =
 \sum_{n\ge1}d_n n^{-it}
 \qquad(t\in\mathbb R).
\tag{1}
\]
若某个 \(d_n\ne0\) 对应 \(n>1\)，则不可能成立。

## 证明

在实数轴上定义有限复测度
\[
 \nu_+=\sum_{m\ge1}c_m\,\delta_{\log m},
 \qquad
 \nu_-=\sum_{n\ge1}d_n\,\delta_{-\log n}.
\]
由于两组系数都在 \(\ell^1\)，\(\nu_+\) 与 \(\nu_-\) 都是有限复测度。式 (1) 正是
\(\nu_+\) 与 \(\nu_-\) 的 Fourier--Stieltjes 变换相同。有限复测度的
Fourier 唯一性给出
\[
 \nu_+=\nu_-.
\tag{2}
\]

但
\[
 \operatorname{supp}\nu_+\subset[0,\infty),\qquad
 \operatorname{supp}\nu_-\subset(-\infty,0],
\]
两者只有零点 \(\log1=0\) 相交。因此 (2) 强迫
\[
 c_m=0\ (m>1),\qquad d_n=0\ (n>1),
\]
与假设矛盾。

对有限截断 \(F_N(-t)\)，取 \(d_n=\mu(n)\mathbf 1_{n\le N}\)，便得到
直接推论：任何 \(\ell^1\) 的正向整数 Dirichlet 系数都不能精确反射
一个含有 \(\mu(2)\) 的 Möbius 截断。若使用无限 Möbius 系数，右侧本身
不属于 \(\ell^1\)，不能把本命题误读成无限 Möbius 级数的收敛断言。
它的作用是排除所有绝对可和的 coefficient-space exact reflection。

## 对 arithmetic intertwiner 的含义

这把 note 337/338 的剩余类进一步压缩为：

* 有限系数矩阵不行；
* 无限但 \(\ell^1\) 的整数系数也不行；
* exact reflection 若存在，必须是非绝对收敛的分布型对象，或只在
  \(M_h\) 的某个弱配对下成立；
* 若只要求近似反射，则必须同时给出系数范数、频率窗口和配对误差的
  统一量化；否则“稠密 Dirichlet 多项式可逼近”不能转化为 RH 算术界。

因此下一步的最小可检验对象不是一般的无限 Dirichlet 系数，而是一个
带明确非绝对收敛正则化和误差预算的 arithmetic distribution。
