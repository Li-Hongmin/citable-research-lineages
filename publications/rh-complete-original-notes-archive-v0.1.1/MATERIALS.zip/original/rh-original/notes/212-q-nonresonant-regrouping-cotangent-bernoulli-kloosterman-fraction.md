> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(q\ne0\) 非共振层的精确重聚合：cotangent--Bernoulli 变换与 Kloosterman-fraction 余项

日期：2026-08-15。

本 note 对 note 209 的
\(q=re+sd\ne0\) 双和作一次完整的 gcd/q 重排。结论是：对固定
\((d,e)\)，所有 \(k=q/(d,e)\) 频率可以精确消成有限的
Bernoulli--Dedekind 端点式；若保留 \(k\) 以研究双变量抵消，则 cotangent 的
有限 Fourier 展开给出 Bettin--Chandee 型 Kloosterman-fraction 相位。这个恒等式
本身没有产生现成的 Ramanujan 正交或平方根级估计。

以下无限 Fourier 和均按 Abel 因子取极限理解；因此重排不依赖跳点处的 Fourier
级数点态取值。

下文的 \(\mathcal B_N^{\ne0}\) 专指 note 209 中双边界
\(\sum_{d,e}\lambda_{d,N}\lambda_{e,N}E_{d,e}(N)\) 的非零频率部分；
one-boundary 交叉项另有其单和，不包含在 (3)--(4) 中。

## 1. gcd 与原始 \(q\) 的重聚合

令
\[
 d=gb,\qquad e=ga,\qquad (a,b)=1,\qquad \ell=[d,e]=gab,
\]
并记 \(L=\log N\)。note 209 中的原始频率记为
\(q=re+sd\)。只有 \(g\mid q\) 时它才可能出现；置
\(\mathrm e(x):=e^{2\pi i x}\)，
\[
 k=q/g,
\]
则约化方程为 \(ar+bs=k\)。定义主值卷积
\[
 C_{a,b}(k):=\operatorname {PV}
 \sum_{ar+bs=k\atop r,s\ne0}\frac1{rs}.
\]
由 \(\widehat B(r)=-1/(2\pi i r)\)，非零频率的 Fourier 系数为
\[
 \widehat C_{d,e}(gk)=-\frac1{4\pi ^2}C_{a,b}(k).
 \tag{1}
\]
对 \(k\ne0\)，取 \(\bar b=b^{-1}\pmod a\)、
\(\bar a=a^{-1}\pmod b\)，并把能导致 \(r=0\) 或 \(s=0\) 的端点解删去，则
\[
 C_{a,b}(k)=\frac\pi k\left[
 \cot^*\!\left(\frac{\pi\bar b k}{a}\right)+
 \cot^*\!\left(\frac{\pi\bar a k}{b}\right)\right]
 -\frac{ab}{k^2}\bigl({\bf1}_{a\mid k}+{\bf1}_{b\mid k}\bigr).
 \tag{2}
\]
这里 \(\cot^*(\pi t/a)=0\) 当 \(a\mid t\)，否则为通常的 cotangent；模数为
1 时相应的和为空。于是 note 209 的全部非共振边界可以写成
\[
 \boxed{
 \mathcal B_N^{\ne0}=
 -\frac1{4\pi ^2}
 \sum_{g\ge1}\sum_{\substack{a,b\le N/g\\(a,b)=1}}
 \lambda_{ga,N}\lambda_{gb,N}
 \sum_{k\ne0}C_{a,b}(k)\,
 \mathcal I_N\!\left(\frac{k}{gab}\right).}
 \tag{3}
\]
等价地，按 note 209 的原始 \(q\) 聚合为
\[
 \boxed{
 \mathcal B_N^{\ne0}=
 -\frac1{4\pi ^2}
 \sum_{q\ne0}\ 
 \sum_{g\mid q}
 \sum_{\substack{a,b\le N/g\\(a,b)=1}}
 \lambda_{ga,N}\lambda_{gb,N}
 C_{a,b}(q/g)\,
 \mathcal I_N\!\left(\frac{q}{g^2ab}\right),}
 \tag{4}
\]
其中 \(g\mid q\) 表示正整数 \(g\) 除以 \(|q|\)。

这个重排还暴露了 Möbius 支持的一个简化。若沿用
\(\lambda_{d,N}=\mu(d)L^{-1}\log(N/d)\)，则
\[
 \lambda_{ga,N}\lambda_{gb,N}
 =\frac{\mu(a)\mu(b)}{L^2}
 \log\frac N{ga}\log\frac N{gb}
 \tag{5}
\]
在其非零支撑上；此时 \(g,a,b\) 两两互素且均平方自由。式 (5) 只是支持恒等式，
不表示对共同尺度 \(g\) 有额外符号抵消。

## 2. 对 \(k\) 的精确 cotangent--Bernoulli 消除

写 \(\widetilde B_1(h/a)=h/a-1/2\)（\(1\le h<a\)），并令
\(B_2(x)=\{x\}^2-\{x\}+1/6\)、
\(B_3(x)=\{x\}^3-3\{x\}^2/2+\{x\}/2\) 为周期 Bernoulli 函数。有限 Fourier 恒等式为
\[
 \cot^*\!\left(\frac{\pi\bar b k}{a}\right)
 =2i\sum_{h=1}^{a-1}\widetilde B_1\!\left(\frac ha\right)
 \mathrm e\!\left(\frac{kh\bar b}{a}\right),
 \tag{6}
\]
而
\[
 \sum_{k\ne0}\frac{\mathrm e(kx)}{k^2}=2\pi ^2B_2(\{x\}).
 \tag{7}
\]
因此，对 \(\ell=gab\)，有精确恒等式
\[
\begin{aligned}
 &\sum_{k\ne0}\frac{\cot^*(\pi\bar b k/a)}{k^2}
 \left[\mathrm e\!\left(\frac{2Nk}{\ell}\right)-
 \mathrm e\!\left(\frac{Nk}{\ell}\right)\right] \\
 &\quad=4\pi ^2i\sum_{h=1}^{a-1}\widetilde B_1\!\left(\frac ha\right)
 \left[
 B_2\!\left(\frac{2N}{\ell}+\frac{h\bar b}{a}\right)-
 B_2\!\left(\frac{N}{\ell}+\frac{h\bar b}{a}\right)
 \right].
\end{aligned}
\tag{8}
\]
分数部分可省略，因为 \(B_j\) 取周期延拓。把 (8) 代回积分，cotangent 分支本身
完全等于
\[
\boxed{
 E^{\rm cot}_{gb,ga}(N)=
 \frac\ell2\sum_{h=1}^{a-1}\widetilde B_1\!\left(\frac ha\right)
 \left[B_2\!\left(\frac N\ell+\frac{h\bar b}{a}\right)-
 B_2\!\left(\frac {2N}\ell+\frac{h\bar b}{a}\right)\right]
 +(a\leftrightarrow b).}
\tag{9}
\]
这里的符号来自
\(\mathcal I_N(k/\ell)=\ell[\mathrm e(2Nk/\ell)-\mathrm e(Nk/\ell)]/(2\pi i k)\)
及 (1)。

端点修正同样可消成三阶 Bernoulli 函数。由
\[
 \sum_{k\ne0}\frac{\mathrm e(kx)}{k^3}=\frac{4\pi ^3i}{3}B_3(\{x\}),
\]
得到
\[
\boxed{
 E^{\rm div}_{gb,ga}(N)=\frac\ell6\left\{
 \frac b{a^2}\left[B_3\!\left(\frac{2N}{gb}\right)-B_3\!\left(\frac N{gb}\right)\right]
 +\frac a{b^2}\left[B_3\!\left(\frac{2N}{ga}\right)-B_3\!\left(\frac N{ga}\right)\right]
 \right\}.}
\tag{10}
\]
式 (9)+(10) 与 (2)--(3) 完全等价；例如当 \(\ell\mid N\) 时每个端点差均为零，
恢复完整周期上的非共振边界消失。

## 3. 保留 \(k\) 时的 reciprocity 结构

若不先使用 (7)，而把 (6) 代回 (3)，每个端点相位为
\[
 \mathrm e\!\left(\frac{kh\bar b}{a}+\frac{\tau Nk}{gab}\right),
 \qquad \tau\in\{1,2\}.
\]
加法互反律
\[
 \frac{\bar b}{a}+\frac{\bar a}{b}\equiv\frac1{ab}\pmod1
\]
把它改写为
\[
 \boxed{
 \mathrm e\!\left(-\frac{kh\bar a}{b}
 +\frac{k(h+\tau N/g)}{ab}\right).}
 \tag{11}
\]
这正是一个带平滑 reciprocal phase 的 Kloosterman-fraction 型核；但它不是固定模数的
经典 Kloosterman 和：模数 \(a,b\) 同时变化，且 \(h+\tau N/g\) 一般不是整数。
在平衡区 \(a\asymp b\asymp N/g\) 时，这个结构落入 variable-product-modulus 的
双线性/四线性范围，而非现成的 Ramanujan 正交。已有 cotangent/Kloosterman 黑箱需要
额外的尺度与系数条件，不能从 (11) 自动推出固定幂次节省。

## 4. 最小结论

1. 式 (4) 是按原始 \(q\) 的无损重聚合；式 (9)--(10) 说明对固定 \((g,a,b)\)，
   非零 \(q\) 全层其实是有限 Dedekind--Bernoulli 端点，而不是一个尚未求和的
   无限 Ramanujan 包。
2. 若保留频率以寻找跨 \((a,b)\) 抵消，唯一剩余的振荡是 (11) 的
   Kloosterman-fraction 相位，仍带 Möbius 权和不完整端点。对它逐项取模会回到
   \(N^2\) 量纲；本 note 不给出平方根级估计。
3. 因此 note 209 的最小未控命题可等价写成：对 (4) 或等价的
   (9)--(11) 加上 \(\lambda_{ga,N}\lambda_{gb,N}\) 的总和，证明某个固定次幂节省。
   现有恒等式只完成结构压缩，不能宣称已经得到 RH 或任何新的无条件幂次界。
