> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# a_11 = (log 11)/2 处 P_400^- 的 256-bit 500:850 joint-Schur 证书

日期：2026-08-16。

本 note 给出与 note 273 对偶的 odd-sector 有限维证书。令 a_11=(log 11)/2，A_11^- 为 A_{a_11} 在 odd sector 上的限制，P_400^- 为前 400 维 odd 压缩。

## 构造

本次计算使用统一 256-bit Arb 输入：

- odd clean full contract base：K=400，N=500；
- odd verified graph：R=280，N=500；
- 完整 odd joint Yukawa family F_{500:850}，350 个 atom，保留全部 atom cross-Gram；
- sharp checker 截断参数 q_f=8000。

生成与复核入口为：

~~~text
generate_log10_endpoint_contract_cache.py 256 400 500 - --endpoint 11 --export-full-safe-matrix
generate_log10_endpoint_contract_cache.py 256 280 500 - --endpoint 11 --export-verified-graph
extract_log10_even_K400_full_contract_base.py --cache-prefix log11 --precision 256 --n500-clean --odd
generate_log10_endpoint_contract_cache.py 256 400 500 - --endpoint 11 --export-yukawa-family 500 850
log10_even_K400_sharp_safe_arb.py --full400 --clean-no-yukawa --odd --family scratch/log11_odd_K400_N500_yukawa_500_850_parseval_arb_256.npz 350 --qf 8000 --cache-prefix log11 256 11 1
~~~

最终证书文件：

~~~text
scratch/log11_odd_K400_N500_clean_sharp_family_500_850_full394_q8000_arb_256.npz
~~~

## 严格输出

补空间区间 Cholesky 的最小 pivot 为：

~~~text
0.00729849667652575765778644546451513080286514931203064302696715
  +/- 2.94e-63 > 0
~~~

核心置换为 `(1, 4, 2, 3, 5, 0)`，六个核心 pivot 全部严格为正：

~~~text
7.3169763429e-17
6.7811300192e-21
1.5649428633e-26
5.1365734673e-32
6.9029148077e-38
2.97588371606871269319e-45 +/- 3.19e-66
~~~

因此 odd lower model 严格正定，并满足构造中的 Loewner 下界关系：

~~~text
L_lower(500:850, odd) > 0
L_lower(500:850, odd) <= P_400^- A_11^- P_400^-.
~~~

得到有限维结论：P_400^- A_11^- P_400^- 严格正定。

## 证据边界

结合 note 273，本次在 a_11 处同时闭合了 even 与 odd 的 400 维压缩 lower model，并且两者都使用统一 256-bit parent、verified graph 和完整 500:850 cross-Gram family。这是比单 sector 或较短 family 更强的有限尺度证书。

它仍然没有证明：

1. 完整无限维 A_11^+ 或 A_11^- 的正性；
2. 任意 P_N 或全尺度 a 的统一正性；
3. 全局 Möbius reciprocal-product 二次型的平方根级 signed cancellation；
4. 黎曼猜想。

本证书作为 note 275 的 odd 输入；结合 note 089 的 cutoff-free Loewner--Parseval 尾支付后，note 275 将其与 even 证书升级为完整的 \(A_{a_{11}}^\pm>0\) 局部定理。因此下一道真实门不是继续横向加长同一有限 family，而是构造保留 Möbius 符号的全局 arithmetic intertwiner。
