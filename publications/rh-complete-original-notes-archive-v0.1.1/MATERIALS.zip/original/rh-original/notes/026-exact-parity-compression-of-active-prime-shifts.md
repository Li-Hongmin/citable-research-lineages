> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 活跃 prime shift 的精确奇偶半区压缩

日期：2026-08-11。

本文给出任意单个 prime-power shift 在 \(L^2(0,a)\) 上的精确压缩公式，补齐 note 025 之后
\(a>\log2\) 所需的 mixed translation--reflection 接口。

## 1. 单位奇偶延拓

令 \(\sigma\in\{+1,-1\}\)，并定义酉算子

\[
(U_\sigma f)(x)=2^{-1/2}
\begin{cases}
f(x),&x>0,\\
\sigma f(-x),&x<0.
\end{cases}
\]

函数均在区间外零延拓。固定 \(0<d<2a\)，置

\[
I_d=[\max(0,d-a),\min(a,d)].
\]

定义 partial translation 与 partial reflection

\[
(S_df)(x)=\mathbf 1_{[0,a-d]}(x)f(x+d)\qquad(d<a),
\]

当 \(d\ge a\) 时令 \(S_d=0\)，并令

\[
(J_df)(x)=\mathbf1_{I_d}(x)f(d-x).
\]

于是

\[
J_d=J_d^*,\qquad J_d^2=P_{I_d},\qquad \|J_d\|=1.
\tag{1}
\]

## 2. 精确压缩公式

对 \(u=U_\sigma f\)，把积分分成两个同侧部分和一个跨中心部分，得到

\[
\int_{-a}^{a-d}u(x+d)\overline{u(x)}\,dx
=\int_0^{(a-d)_+}f(x+d)\overline{f(x)}\,dx
+\frac{\sigma}{2}\int_{I_d}f(d-x)\overline{f(x)}\,dx.
\tag{2}
\]

因此，以二次型意义理解复函数情形时，

\[
\boxed{
U_\sigma^*(T_d+T_{-d})U_\sigma
=S_d+S_d^*+\sigma J_d.}
\tag{3}
\]

Weil 形式中 \(n\) 对应的原子系数为

\[
\alpha_n=\frac{\Lambda(n)}{\sqrt n},\qquad d_n=\log n.
\]

故其半区算子恰为

\[
\boxed{
P_{n,a}^{\sigma}
=-\alpha_n(S_{d_n}+S_{d_n}^*)
-\sigma\alpha_nJ_{d_n}.}
\tag{4}
\]

这里没有额外的 prime-power multiplicity：它已完整包含在 \(\Lambda(n)\) 中。若 \(d_n=2a\)，
重叠只有零测度，原子相关项为零。

公式 (4) 给出两个清楚的尺度区间：

\[
\begin{array}{c|c}
a\le d_n<2a&-\sigma\alpha_nJ_{d_n}\\
0<d_n<a&-\alpha_n(S_{d_n}+S_{d_n}^*)-\sigma\alpha_nJ_{d_n}.
\end{array}
\tag{5}
\]

同侧 translation 在两个扇区中均为负号；reflection 在偶扇区为负、奇扇区为正。

## 3. 第一个 mixed chamber

在

\[
\log2<a\le\frac12\log5
\]

内，\(d_2=\log2<a\)，而 \(d_3=\log3>a\)。因此

\[
P_{2,a}^\sigma
=-\frac{\log2}{\sqrt2}(S_2+S_2^*)
-\sigma\frac{\log2}{\sqrt2}J_2,
\tag{6}
\]

\[
P_{3,a}^\sigma
=-\sigma\frac{\log3}{\sqrt3}J_3.
\tag{7}
\]

由于 \(2\log2>a\)，

\[
S_2^2=0,
\qquad
\|S_2+S_2^*\|=1.
\tag{8}
\]

单个 \(S_2,J_2,J_3\) 的纤维至多二维，但它们一般不交换。例如在共同定义域上，

\[
J_3J_2f(x)=f(x+\log2-\log3).
\tag{9}
\]

所以 mixed chamber 的最小可靠 prime-side 对象是三个 partial isometries

\[
\boxed{S_2,\ J_2,\ J_3,}
\]

而不是单一反射块。其联合轨道是否具有统一有限复杂度，需要另行分类。

## 4. 推论与边界

公式 (4) 对所有 \(a>0\) 及所有活跃 prime powers 成立，并为任意后续 chamber 提供无歧义的
半区算子接口。它本身不证明联合轨道有限，也不提供正性；这些分别是 active-prime graph theorem
与 Robin-frame/Feshbach 不等式的独立问题。
