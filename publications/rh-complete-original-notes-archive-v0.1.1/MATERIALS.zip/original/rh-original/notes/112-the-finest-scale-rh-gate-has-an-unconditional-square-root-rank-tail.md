> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 最细尺度 RH 门的谱尾可无条件压到平方根秩

日期：2026-08-14。

依赖：
[note 111](111-a-smooth-cutoff-finest-scale-mean-square-is-equivalent-to-rh.md)。

证据等级：精确矩阵因子分解、Schur 检验、前缀和矩阵的显式奇异值，
以及有限维 min--max 谱尾估计。

note 111 将 RH 等价于一个最细尺度 Möbius--dilation 均方门。
本文精确分离该门中可由一般算子理论无条件控制的部分：
排在第 \(\lceil\sqrt Y\rceil\) 个奇异值之后的全部谱尾只贡献 \(O(Y^2)\)。
因此 RH 的剩余算术门严格落在一个维数至多 \(O(\sqrt Y)\) 的移动子空间中。

## 1. Abel 变换的精确矩阵形式

沿用 note 111 的 \(L_Y\)、\(G_{L_Y}\)、cutoff \(\chi\)、列域与完整活动行集。
令 \(m=\lfloor2eY\rfloor\)，并定义前缀和矩阵

\[
(C_ma)(d)=\sum_{n\le d}a(n),
\qquad 1\le d\le m.
\tag{1}
\]

令

\[
(X_Yv)(d)=\chi(d/Y)v(d),
\tag{2}
\]

并令 \(B_Y\) 为 note 110 的最细尺度 cell-difference 矩阵。
对任意系数向量 \(a=(a(1),\ldots,a(m))\)，置

\[
A(d)=\sum_{n\le d}a(n).
\tag{3}
\]

则截断观测精确为

\[
\sum_d
\left[G_{L_Y}(d/N)-G_{L_Y}((d+1)/N)\right]
\chi(d/Y)A(d).
\tag{4}
\]

因此其从 \(a\) 到行输出的矩阵是

\[
\boxed{W_Y=B_YX_YC_m.}
\tag{5}
\]

当 \(a(n)=\mu(n)\) 时，\(A(d)=M(d)\)，note 111 的均方量正是

\[
\boxed{\mathcal O_\chi(Y)=\|W_Y\mu_{\le m}\|_2^2.}
\tag{6}
\]

等价地，直接交换前缀和可得到 Abel kernel

\[
(W_Y)_{N,n}
=\sum_{d\ge n}
\chi(d/Y)
\left[G_{L_Y}(d/N)-G_{L_Y}((d+1)/N)\right].
\tag{7}
\]

## 2. 最细 cell 矩阵的统一上界

### 引理 1

\[
\boxed{\|B_YX_Y\|_{\ell^2\to\ell^2}\le C_{F,\chi}}
\tag{8}
\]

一致于 \(Y\ge2\)。

**证明。** 对每个行 \(N\)，

\[
\sum_d|(B_Y)_{N,d}|
\le\operatorname{Var}G_{L_Y}
\le\operatorname{Var}F.
\tag{9}
\]

现固定一个列 \(d\asymp Y\)。note 109 的 endpoint--regular 分解将
\(G_{L_Y}'\) 写成一个总质量有界的 endpoint box 与一个 \(L^1\) 范数一致有界的正则项。
对变动的 \(N\asymp Y\)，区间

\[
[d/N,(d+1)/N]
\tag{10}
\]

在任意固定 \(t\in[a,e^{L_Y}]\) 上的覆盖重数一致有界：
相邻中心的间隔与 cell 长度均为 \(\asymp Y^{-1}\)。因此

\[
\sup_d\sum_{N\in\mathcal N_Y}|(B_Y)_{N,d}|
\le C_F.
\tag{11}
\]

对 \(B_YX_Y\) 应用 Schur 检验，并用 \(\|\chi\|_\infty\le1\)，得 (8)。\(\square\)

## 3. 前缀和奇异值

\(C_m^{-1}\) 是对角为 \(1\)、次对角为 \(-1\) 的一阶差分矩阵。
对应的离散 Dirichlet--Neumann 特征值给出显式公式

\[
s_k(C_m)
=\frac1{2\sin\left(\frac{(2k-1)\pi}{4m+2}\right)},
\qquad 1\le k\le m.
\tag{12}
\]

特别地，

\[
\boxed{s_k(C_m)\le C\frac{m}{k}\le C'\frac{Y}{k}.}
\tag{13}
\]

由 ideal property of singular values 与 (5)、(8)，

\[
\boxed{
s_k(W_Y)
\le\|B_YX_Y\|,s_k(C_m)
\le C_{F,\chi}\frac{Y}{k}.}
\tag{14}
\]

## 4. 无条件的平方根秩谱尾

令

\[
W_Y=\sum_{k=1}^{r_Y}s_k\,u_kv_k^*
\tag{15}
\]

为任意奇异值分解，并记

\[
P_{Y,K}=\sum_{k\le K}v_kv_k^*.
\tag{16}
\]

由 \(|\mu(n)|^2\le1\) 和 \(m=O(Y)\)，

\[
\|\mu_{\le m}\|_2^2\le m\ll Y.
\tag{17}
\]

因此由 (14)，

\[
\begin{aligned}
\|W_Y(I-P_{Y,K})\mu\|_2^2
&\le s_{K+1}(W_Y)^2\|\mu\|_2^2\\
&\ll_{F,\chi}\frac{Y^3}{K^2}.
\end{aligned}
\tag{18}
\]

取

\[
K_Y=\lceil\sqrt Y\rceil,
\tag{19}
\]

得到无条件上界

\[
\boxed{
\|W_Y(I-P_{Y,K_Y})\mu\|_2^2
\ll_{F,\chi}Y^2.}
\tag{20}
\]

又因为 SVD 的左奇异向量正交，

\[
\|W_Y\mu\|_2^2
=\|W_YP_{Y,K_Y}\mu\|_2^2
+\|W_Y(I-P_{Y,K_Y})\mu\|_2^2.
\tag{21}
\]

与 note 111 合并即得主结果。

### 定理

黎曼猜想等价于：对每个 \(\varepsilon>0\)，

\[
\boxed{
\|W_YP_{Y,\lceil\sqrt Y\rceil}\mu_{\le m}\|_2^2
\ll_{\varepsilon,F,\chi}Y^{2+\varepsilon}.}
\tag{22}
\]

也就是说，最细尺度 RH 门中排在前 \(\lceil\sqrt Y\rceil\) 个右奇异方向
之外的全部能量已无条件满足正确尺度。

## 5. 尖锐边界与文献比较

(20) 只使用了 \(\ell^2\) 大小 \(\|\mu\|_2^2\ll Y\)，没有使用 Möbius 消去。
平方根秩来自尺度平衡

\[
\left(\frac{Y}{K}\right)^2Y\asymp Y^2
\quad\Longleftrightarrow\quad
K\asymp\sqrt Y.
\tag{23}
\]

因此只靠任意系数的大筛或 Schur 上界不能将 (22) 再降到固定秩。
事实上，取 \(a(n)=1\)，则 \((C_ma)(d)=d\)。note 110 的 coercivity 作用于
\(q(d)=\chi(d/Y)d\) 给出

\[
\|B_YX_YC_ma\|_2^2\gg Y^3,
\tag{24}
\]

而 \(\|a\|_2^2\asymp Y\)。因此一般系数算子范数确实处在 \(Y^2\) 平方尺度，
比 Möbius 目标多一个 \(Y\) 因子。

2026-08-14 的 `paper-lib` 定向地图中，Davenport 的 Möbius 指数和对数节省、
Wei Zhang 2022 在附加零自由假设下的 \(3/4\) 指数，以及一般 Davenport--Halberstam
大筛，都已在项目文献矩阵中标记为至少缺少一个 \(Y\) 幂次或平方根级算术消去。
它们不能从一般估计直接控制 (22)。

本文的新边界是严格的维数归约，不是 RH 证明：

\[
\boxed{
\text{全维最细尺度门}
\quad\longrightarrow\quad
\text{至多 }\sqrt Y\text{ 维的移动算术核}.}
\]
