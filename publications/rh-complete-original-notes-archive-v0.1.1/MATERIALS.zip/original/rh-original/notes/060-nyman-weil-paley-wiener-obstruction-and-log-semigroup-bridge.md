> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Nyman--Weil 直接压缩障碍与对数半群桥

日期：2026-08-12。检索截止：2026-08-12。

> **后续关闭。** [note 062](062-baez-duarte-exact-window-interpolation-closes-compact-weil-transfer.md)
> 核对 Báez--Duarte 2002 的自然逼近 \(B_N\) 后证明：对每个有限 \(a\)，只要
> \(N\ge e^a\)，窗口残差已经由 Möbius 系数代数恒等地等于零；但同一 \(B_N\)
> 不在 \(L^2\) 收敛。因此本文末尾“窗口 Weil Schur 增益 \(\Rightarrow\) Nyman residual”
> 的候选也关闭。本文的 Paley--Wiener 障碍、窗口尾界及半群字典仍成立。

## 1. 弄清问题

要判定

\[
\boxed{\text{Nyman 有限 dilation Gram}
\stackrel{?}{=}
\text{有限尺度 local Weil 压缩}}
\tag{1}
\]

最便宜观测：两侧向量能否属于同一有限尺度 Paley--Wiener 类。

```mermaid
flowchart LR
  A["整数 dilation"] --> B["log-酉变换"]
  B --> C["全线平移半群"]
  C --> D{"紧支撑?"}
  D -->|"否"| X["关闭直接压缩"]
  C --> W["窗口 W_a"]
  W --> E["H((-a,a))"]
  E --> F["比较 L2 Gram 与 Weil form"]
  B --> G["Cayley"]
  G --> H["奇异内半群"]
```

## 2. 拟定计划

\[
\text{Mellin 归一}
\to PW_a\text{ 必要条件}
\to \zeta(-2k-1)\text{ 增长}
\to \text{窗口误差}
\to n\mapsto qn\text{ 协变}.
\tag{2}
\]

互斥输出：

\[
\begin{cases}
F_P\in PW_a &\Rightarrow \text{继续 (1)},\\
F_P\notin\bigcup_{a<\infty}PW_a
&\Rightarrow \text{关闭 (1)，只保留窗口/极限桥}.
\end{cases}
\tag{3}
\]

## 3. 实现计划

### 3.1 精确 Mellin--Fourier 归一

令

\[
(\mathcal Mf)(s)=\int_0^\infty f(x)x^{s-1}\,dx,
\qquad
(Uf)(u)=e^{u/2}f(e^u).
\tag{4}
\]

则

\[
U:L^2((0,\infty),dx)\xrightarrow{\sim}L^2(\mathbb R,du),
\qquad
\widehat{Uf}(t)=\mathcal Mf\!\left(\frac12+it\right),
\tag{5}
\]

其中

\[
\widehat g(t)=\int_{\mathbb R}g(u)e^{itu}\,du,
\qquad
\|g\|_2^2=\frac1{2\pi}\int_{\mathbb R}|\widehat g(t)|^2dt.
\tag{6}
\]

取

\[
\rho_n(x)=\left\{\frac1{nx}\right\},
\qquad
\eta_n=-\rho_n,
\qquad
e=\mathbf1_{(0,1)}.
\tag{7}
\]

Burnol 使用的经典公式给出

\[
\mathcal M\eta_n(s)=\frac{\zeta(s)n^{-s}}s,
\qquad
\mathcal Me(s)=\frac1s,
\qquad 0<\Re s<1.
\tag{8}
\]

对有限 Dirichlet 多项式

\[
P(s)=\sum_{n\in S}c_nn^{-s},
\tag{9}
\]

有

\[
\mathcal M\!\left(\sum_{n\in S}c_n\eta_n\right)(s)
=\frac{\zeta(s)P(s)}s.
\tag{10}
\]

### 3.2 定理：非零有限 Nyman 向量不属于任何有限尺度

**定理 1（Paley--Wiener 障碍）。** 若 \(P\not\equiv0\) 为有限 Dirichlet
多项式，则

\[
F_P(z):=
\frac{\zeta(\frac12+iz)P(\frac12+iz)}{\frac12+iz}
\notin \bigcup_{a<\infty}PW_a.
\tag{11}
\]

即使 \(P(1)=P(0)=0\) 消去 \(s=1,0\) 的两个可能极点，\(F_P\) 仍非有限指数型；更强地，

\[
\limsup_{|z|\to\infty}
\frac{\log^+|F_P(z)|}{|z|}=\infty.
\tag{12}
\]

**证明。** 若 \(P(1)\ne0\) 或 \(P(0)\ne0\)，则 \(s=1\) 的 zeta 极点或
\(s=0\) 的分母极点未消，故非整。

以下设二者均消去。令

\[
N=\max\{n:c_n\ne0\}.
\tag{13}
\]

则

\[
P(-m)=c_NN^m(1+o(1)).
\tag{14}
\]

取奇数 \(m=2k+1\)，避开 trivial zeros。函数方程给出

\[
|\zeta(-m)|
=2^{-m}\pi^{-m-1}m!\,\zeta(m+1).
\tag{15}
\]

令

\[
z_m=i\left(m+\frac12\right),
\qquad \frac12+iz_m=-m.
\tag{16}
\]

充分大时

\[
|F_P(z_m)|
\ge
\frac{|c_N|}{2\pi}(m-1)!
\left(\frac{N}{2\pi}\right)^m.
\tag{17}
\]

Stirling：

\[
\frac{\log|F_P(z_m)|}{|z_m|}
\ge \log m-1+\log\frac{N}{2\pi}+o(1)
\to\infty.
\tag{18}
\]

而 \(v\in L^2(-a,a)\) 必满足

\[
|\widehat v(z)|
\le \sqrt{2a}\,e^{a|\Im z|}\|v\|_2.
\tag{19}
\]

矛盾。\(\square\)

同证：

\[
\frac{1-\zeta(s)P(s)}s
\notin \bigcup_{a<\infty}PW_a
\qquad(P\ne0).
\tag{20}
\]

### 3.3 精确有限 Gram 与 Schur 量

内积取第二变量线性。令

\[
G_{nm}=\langle\eta_n,\eta_m\rangle,
\qquad
b_n=\langle\eta_n,e\rangle.
\tag{21}
\]

则

\[
\boxed{
G_{nm}=
\frac1{2\pi\sqrt{nm}}
\int_{\mathbb R}
\frac{|\zeta(\frac12+it)|^2}{\frac14+t^2}
e^{it\log(n/m)}dt
}
\tag{22}
\]

及

\[
\boxed{
b_n=-\frac{\log n+1-\gamma}{n}.
}
\tag{23}
\]

故

\[
\boxed{
d_S^2
=1-b^*G^{-1}b
=\inf_{P\in\operatorname{span}\{n^{-s}:n\in S\}}
\frac1{2\pi}\int_{\mathbb R}
\frac{|1-\zeta(\frac12+it)P(\frac12+it)|^2}
{\frac14+t^2}\,dt.
}
\tag{24}
\]

\[
G\succeq0\quad\text{无条件};
\qquad
Q_W^a\succeq0\ \forall a>0
\quad\Longleftrightarrow\quad RH.
\tag{25}
\]

因此普通 \(L^2\) Schur 补不能仅凭形式相似性等同于 Weil Schur 补。

### 3.4 关闭旧引理 A

由 note 004，

\[
D(Q_W^a)=H((-a,a)),
\tag{26}
\]

其元素零延拓后支撑于 \([-a,a]\)。定理 1 给出

\[
U\operatorname{span}\{\eta_n:n\in S\}
\cap H((-a,a))=\{0\}.
\tag{27}
\]

故 note 057 的“整数 dilation--Weil Gram 恒等式”若指自然 Mellin/Fourier
识别下的有限尺度压缩，则为假。

任意两个正定有限矩阵可经人为合同对应；此类对应不保持目标向量、\(n\mapsto pn\)
协变或 Schur 增益，因而不能作为证明桥。

### 3.5 正确桥 I：窗口化及显式尾界

记

\[
g_n=U\eta_n,
\qquad
g_0=Ue=e^{u/2}\mathbf1_{u<0},
\qquad
W_a=\mathbf1_{(-a,a)}.
\tag{28}
\]

对 \(a\ge0\)，

\[
\|(I-W_a)g_0\|_2^2=e^{-a},
\tag{29}
\]

且

\[
\boxed{
\|(I-W_a)g_n\|_2^2
\le e^{-a}(1+n^{-2}).
}
\tag{30}
\]

**证明。** \(u<-a\) 时 \(|g_n(u)|\le e^{u/2}\)；\(u>a\ge0\) 时

\[
g_n(u)=-n^{-1}e^{-u/2}.
\tag{31}
\]

分两尾积分即得。\(\square\)

于是窗口 Gram

\[
G^{(a)}_{nm}=\langle W_ag_n,W_ag_m\rangle
\tag{32}
\]

满足

\[
\boxed{
|G_{nm}-G^{(a)}_{nm}|
\le e^{-a}\sqrt{(1+n^{-2})(1+m^{-2})}.
}
\tag{33}
\]

对 \(v_c=\sum_{n\in S}c_ng_n\)，

\[
\|(I-W_a)v_c\|_2
\le e^{-a/2}
\sum_{n\in S}|c_n|\sqrt{1+n^{-2}}.
\tag{34}
\]

每个 \(W_ag_n\) 在 \((-a,a)\) 只有有限个跳点且分片光滑，故

\[
W_ag_n\in H((-a,a))=D(Q_W^a).
\tag{35}
\]

这里确有 form-domain 正则性：有限跳点的紧支撑分片 \(C^1\) 函数满足

\[
\|f(\cdot+h)-f\|_2^2=O(|h|),
\qquad
\int_{|h|\le1}\frac{\|f(\cdot+h)-f\|_2^2}{|h|}\,dh<\infty.
\]

这给出同一有限维映射

\[
J_{a,S}:\mathbb C^S\to H((-a,a)),
\qquad
J_{a,S}c=W_a\sum_{n\in S}c_ng_n,
\tag{36}
\]

上的两种矩阵：

\[
G_S^{(a)}=J_{a,S}^*J_{a,S},
\qquad
\mathsf W_S^{(a)}=J_{a,S}^*A_aJ_{a,S}
\quad\text{（形式意义）}.
\tag{37}
\]

\[
\boxed{G_S^{(a)}\ne\mathsf W_S^{(a)};
\quad\text{但定义在同一 arithmetic trial space 上}.}
\tag{38}
\]

### 3.6 正确桥 II：prime multiplication = log translation

令

\[
(\tau_\ell f)(u)=f(u+\ell).
\tag{39}
\]

则

\[
\boxed{
g_n=n^{-1/2}\tau_{\log n}g_1,
\qquad
\tau_{\log q}g_n=\sqrt q\,g_{qn}.
}
\tag{40}
\]

因此在全线上

\[
\boxed{
\frac1{\sqrt q}\langle\tau_{\log q}v_c,v_c\rangle
=
\left\langle\sum_nc_ng_{qn},\sum_mc_mg_m\right\rangle.
}
\tag{41}
\]

这与 local Weil prime block

\[
\mathcal P_a(v,v)
=2\sum_{q\le e^{2a}}\frac{\Lambda(q)}{\sqrt q}
\Re\langle\tau_{\log q}v,v\rangle
\tag{42}
\]

具有完全相同的 \(n\mapsto qn\) 半群作用。窗口后唯一新增项为 collar commutator：

\[
\tau_\ell W_a=W_a\tau_\ell+[\tau_\ell,W_a].
\tag{43}
\]

故正确接口不是 Gram 恒等式，而是

\[
\boxed{
\text{共同 trial space}
+\text{精确 prime-semigroup covariance}
+\text{显式 collar defect}.}
\tag{44}
\]

### 3.7 正确桥 III：Cayley 下的奇异内半群

令

\[
s(z)=\frac12+\frac{1+z}{1-z},
\qquad
(\mathcal Cf)(z)=\frac{\sqrt2}{1-z}f(s(z)).
\tag{45}
\]

边界换元给出 \(L^2(\Re s=1/2,dt/2\pi)\to L^2(\mathbb T)\) 的酉等距。
并且

\[
n^{-s(z)}
=n^{-1/2}B_{\log n}(z),
\qquad
B_\lambda(z)=\exp\!\left[-\lambda\frac{1+z}{1-z}\right].
\tag{46}
\]

\[
B_\lambda B_\mu=B_{\lambda+\mu},
\qquad
|B_\lambda(e^{i\theta})|=1\quad\text{a.e.}
\tag{47}
\]

更精确地，令

\[
\Omega(z)=
\frac{\sqrt2\,\zeta(s(z))}{(1-z)s(z)},
\qquad
\omega_0(z)=\frac{\sqrt2}{(1-z)s(z)}.
\tag{48}
\]

则临界线边界值意义下

\[
\left\|\frac{1-\zeta(s)P(s)}s\right\|_{L^2(dt/2\pi)}
=
\left\|\omega_0-Omega
\sum_{n\in S}c_nn^{-1/2}B_{\log n}\right\|_{L^2(\mathbb T)}.
\tag{49}
\]

所以 Báez--Duarte 最小二乘问题是由共同权乘子 \(\Omega\) 下的

\[
\{B_{\log n}:n\in\mathbb N\}
\tag{50}
\]

生成的**奇异内半群逼近**，不是由 \(\{z^k\}\) 生成的普通 OPA/Toeplitz 问题。
单个生成元已区分二者：

\[
n^{-s(0)}=n^{-3/2}\ne0,
\qquad z^k|_{z=0}=0\ (k\ge1).
\tag{51}
\]

这解释了为何 note 030 的普通 OPA Schur 递推不能直接搬到整数 dilation Gram；应建立
\(B_{\log p}\) 半群的广义 Schur 递推。

## 4. 回顾反思

### 已证明

\[
\boxed{
\text{direct finite-scale NB Gram = Weil compression}
\quad\text{为假}.}
\tag{52}
\]

\[
\boxed{
n\mapsto qn
\quad\longleftrightarrow\quad
\tau_{\log q}
\quad\longleftrightarrow\quad
B_{\log q}
}
\tag{53}
\]

是精确共同结构。

### 当时提出、现已关闭的最薄命题

令

\[
r_{N,c}=g_0-J_{\infty,[N]}c,
\qquad
r^{(a)}_{N,c}=W_ar_{N,c}.
\tag{54}
\]

需要证明存在 \(a_N\to\infty\)、显式 \(c^{(N)}\)，使

\[
e^{-a_N/2}\bigl(1+\|c^{(N)}\|_{\ell^1}\bigr)\to0,
\tag{55}
\]

且 local Weil 的 prime-semigroup Schur 递推推出

\[
\|r^{(a_N)}_{N,c^{(N)}}\|_2\to0.
\tag{56}
\]

由 (34) 得

\[
\|r_{N,c^{(N)}}\|_2\to0,
\tag{57}
\]

再由 Báez--Duarte 得 RH。

本文当时留下：

\[
\boxed{
\text{Weil prime-semigroup Schur 增益}
\Rightarrow
\text{窗口 Nyman }L^2\text{ 残差下降}.}
\tag{58}
\]

note 062 已证明窗口 residual 对 \(N\ge e^a\) 恒为零，而对应全局自然逼近仍不在
\(L^2\) 收敛。因此该命题不能传递所需全局信息；正确对象必须包含缩放后的逃逸左尾及
Báez--Duarte dual/Hardy causal channel。

## 证据边界

文献直接支持：

- Báez-Duarte 的整数 dilation 判据：[arXiv:math/0202141](https://arxiv.org/abs/math/0202141)。
- Burnol 的 Mellin 公式、临界线等距及显式逼近缺口：[本地全文](<[unbundled local reference]>)。
- Mellin--Paley--Wiener 背景：[Bardaro--Butzer--Mantellini--Schmeisser 2015](https://arxiv.org/abs/1509.08235)。
- Gaussian Mellin smoothing 后的 BN Gram 衰减是相邻结果，不证明本 note 的 Weil 比较：[Carvill 2025](https://arxiv.org/abs/2510.18132)。
- local Weil 定义域及显式 prime shifts：[note 004](004-exact-logarithmic-laplacian-normalization.md)、[Suzuki 2026](https://arxiv.org/abs/2606.09096)。

本 note 新推导：定理 1、窗口尾界 (30)--(34)、prime-semigroup 字典
(40)--(44)、奇异内半群重写 (45)--(51)。这些是项目内新结果；未声称已完成 RH 或已证明文献优先权。
