> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 多变量 prime-jet：完整补集边界的精确坐标化

单参数导数在 half-lattice 上至多看见一个大素数边界。多变量化后可以精确坐标化所有 complement vertices；代价是维数指数增长。

## 1. 多变量 incidence

令 \(X\) squarefree，素因子集合 \(\mathcal P(X)\)。对参数
\(\boldsymbol\sigma=(\sigma_p)_{p\mid X}\) 定义
\[
(D_{\boldsymbol\sigma}f)(e)
=\sum_{d\mid e}f(d)
\prod_{p\mid e/d}p^{-\sigma_p}.
\]
对 Möbius mode \(c_X(d)=\mu(d)\)，转置作用为
\[
(D_{\boldsymbol\sigma}^{\,T}c_X)(n)
=\mu(n)\prod_{p\mid X/n}(1-p^{-\sigma_p}).
\tag{1}
\]

## 2. 混合导数是精确坐标基

对 \(S\subseteq\mathcal P(X)\)，令
\(\partial_S=\prod_{p\in S}\partial_{\sigma_p}\)，并在
\(\boldsymbol\sigma=0\) 处取值。若 \(Y=X/n\)，则 (1) 的每个因子
\(1-p^{-\sigma_p}\) 在零点有一阶零点。因此
\[
\boxed{
\left.\partial_S D_{\boldsymbol\sigma}^{\,T}c_X\right|_0
=
\begin{cases}
\mu(n)\displaystyle\prod_{p\mid Y}\log p\;e_n,&S=Y,\\
0,&S\ne Y.
\end{cases}}
\tag{2}
\]
换言之，所有混合 prime jets 恰好给出 divisor vertices 的坐标基。限制到
\(L_X=\{n\mid X:n<\sqrt X\}\) 后，保留下来的 \(S=X/n\) 正是满足
\(S>\sqrt X\) 的 complement subsets。

## 3. 维数与 RH 桥的代价

若 \(X\) 有 \(k\) 个素因子且不是平方数，则
\(|L_X|=2^{k-1}\)。式 (2) 因而需要 \(2^{k-1}\) 个独立混合 jets 才能完整覆盖
half-lattice；单参数导数只有 \(k+1\) 个 jet，远远不够。

这给出一个精确的候选 intertwiner：以所有混合 prime jets 作为 complement
coordinates，再通过 \(A_V\) 或 Weil kernel 连接这些 coordinates。但它的 rank
至少指数增长，且归一化因子
\(\prod_{p\mid Y}\log p\) 必须支付。故多变量化解决了“如何坐标化”问题，
没有自动解决“如何以平方根成本控制”的问题；后者仍需跨坐标 signed
cancellation。

