> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Even--even collective coupling 阻断局部 Möbius 负能量累积

日期：2026-08-14。

依赖：[note 123](123-mobius-has-macroscopic-negative-projection-but-shallow-negative-energy.md)。

证据等级：精确跨块恒等式与统一二次型下界。

note 123 在普通 primorial 上找到真实 Möbius 符号的二指标负门。本文判定最自然的
增长复制族 \((q,2q)\)：局部负量不能直接相加，因为所有 even 坐标之间留下一个
稠密正 rank-one 主项。

令

\[
x=p_m^\#,
\tag{1}
\]

并取互异奇素数集合 \(\mathcal J\)，满足 \(2q\le\sqrt x\)。每一 pair 的真实
Möbius 系数为

\[
(\mu(q),\mu(2q))=(-1,1).
\tag{2}
\]

## 1. 单块与 residue 门

置 \(z_q=x/(4q^2)\)。单块二次量为

\[
\mathcal Q_q=P(4z_q)+P(z_q)-2P(2z_q).
\tag{3}
\]

若 \(\theta_q=\{z_q\}\)，则一致地

\[
\mathcal Q_q=\frac{4q^2}{x}F(\theta_q)
+O\!\left(\frac{q^4}{x^2}\right),
\tag{4}
\]

其中 \(h(t)=t(1-t)\)，且

\[
F(\theta)=h(\theta)-h(\{2\theta\})+\\frac14h(\{4\theta\}).
\tag{5}
\]

在 (0\le\theta\le1/2)，

\[
F(\theta)=
\begin{cases}
-\theta^2,&0\le\theta\le1/4,\\
-\theta^2+2\theta-1/2,&1/4\le\theta\le1/2,
\end{cases}
\tag{6}
\]

并有 (F(1-\theta)=F(\theta))。故主项为负恰在

\[
\operatorname{dist}(\theta,\mathbb Z)<1-2^{-1/2}.
\tag{7}
\]

对 \(q=3\)，模 \(6\) 的单位只有 \(1,5\)，所以 note 123 的负号被强制；一般
\(q\) 则立即变成补余积 \(x/(2q)\bmod 2q\) 的分布问题。

## 2. 跨块仅余 even--even 项

若 (q\ne r\)，则

\[
P(x/(qr))=P(x/(2qr))=0,
\tag{8}
\]

所以四个跨块条目中的三个精确消失。唯一剩余的是

\[
P\!\left(\frac{x}{4qr}\right)
=\frac{qr}{x}\left(1-\frac{4q^2r^2}{x^2}\right)>0,
\tag{9}
\]

因为 \\(x/(4qr)\\) 是半整数。因此完整限制二次型精确为

\[
\boxed{
\mathcal Q_{\mathcal J}
=\sum_{q\in\mathcal J}\mathcal Q_q
+2\sum_{q<r}\frac{qr}{x}
\left(1-\frac{4q^2r^2}{x^2}\right).}
\tag{10}
\]

这些 pair 不是 induced matching；正号坐标 \(2q\) 形成 complete graph。

## 3. 统一正补偿

精确平方恒等式给出

\[
0\le P(y)\le\frac1{4y}.
\tag{11}
\]

故由 (3)，

\[
\mathcal Q_q\ge-\frac{q^2}{x}.
\tag{12}
\]

又由 (q,r\le\sqrt x/2)，(9) 中括号至少为 (3/4)。记

\[
S_1=\sum_{q\in\mathcal J}q,\qquad S_2=\sum_{q\in\mathcal J}q^2.
\tag{13}
\]

代入 (10) 得

\[
\boxed{
\mathcal Q_{\mathcal J}
\ge\frac{3S_1^2-7S_2}{4x}.}
\tag{14}
\]

特别地，若

\[
S_1^2\ge\frac73S_2,
\tag{15}
\]

则整个真实 Möbius 限制二次型非负。对增长个彼此可比的素数，
(S_1^2/S_2\asymp |\mathcal J|)，所以 positive collective term 最终必压过
全部局部负量。

## 4. 决策边界

因此下述推理严格失败：

\[
\text{许多局部负 }(q,2q)\text{ 门}
\quad\Longrightarrow\quad
\text{增长的真实 Möbius 负能量}.
\tag{16}
\]

要删除 (9) 的主项，任意加权 pair 系数 \\(c_q(-1,1)\\) 至少必须满足

\[
\sum_q q c_q=0.
\tag{17}
\]

但真实 Möbius 限制对应 \\(c_q=1\\)，并不 centered。改用不同 Möbius parity
或不同共享素数虽可能削弱 collective 项，却同时必须控制 (7) 的 residue 门；普通
primorial 因子分解没有自动给出这两个条件。

截至 2026-08-14 的针对性文献核对中，Kanemitsu--Yoshimoto 的 Farey/Franel
正形式控制 complete gcd component，不覆盖这里的 incomplete reciprocal-product
boundary，因而不改变 (10)--(17) 的边界。

结论是：未经 collective centering 的局部块累积路线应停止。下一项承重对象只能是
保存真实 Möbius 权重的全局 Schur/差分恒等式，或同时解决 (7) 与 (17) 的新算术族。
这不是 RH 的证明。
