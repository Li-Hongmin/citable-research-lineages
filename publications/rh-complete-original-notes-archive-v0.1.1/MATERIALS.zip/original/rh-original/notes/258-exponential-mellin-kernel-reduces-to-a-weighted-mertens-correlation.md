> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 指数 Mellin 核的精确化：没有出现 Möbius 望远镜

日期：2026-08-16。

为检验 note 257 的路径坐标是否可能产生额外的算术望远镜，取最简单的
正频率权
\[
 w_0(t)=\frac{1}{\pi(1+t^2)},\qquad
 K_0(u)=e^{-|u|}.
\]
该权在零频有正邻域，并具有任意阶 \(<1\) 的正频率矩，因此若其能量达到
\(N^{1+\varepsilon}\)，同样会给出 RH；它不是一个逃避 RH 的假测试。

## 1. 精确有限和恒等式

令
\[
 E_N^{(0)}
 :=\sum_{m,n\le N}\mu(m)\mu(n)
 \frac{\min(m,n)}{\max(m,n)}.
\]
按 \(m<n\) 分拆，记
\[
 M(x)=\sum_{n\le x}\mu(n),\qquad
 S_1(r)=\sum_{m\le r}m\mu(m).
\]
则
\[
 E_N^{(0)}
 =\sum_{n\le N}\mu(n)^2
 +2\sum_{n=2}^N\frac{\mu(n)}{n}S_1(n-1).
\tag{1}
\]
Abel 恒等式
\[
 S_1(n-1)
 =nM(n-1)-\sum_{k<n}M(k)
\tag{2}
\]
以及
\[
 M(n)^2-M(n-1)^2
 =2\mu(n)M(n-1)+\mu(n)^2
\tag{3}
\]
给出
\[
\boxed{
 E_N^{(0)}
 =M(N)^2
 -2\sum_{n=1}^N\frac{\mu(n)}{n}
    \sum_{k<n}M(k).
}
\tag{4}
\]
这是完全有限的有理恒等式，没有使用 RH 或渐近估计。

再令
\[
 A(n)=\sum_{j\le n}\frac{\mu(j)}{j},
\qquad
 T(n)=\sum_{k\le n}M(k).
\]
对 (4) 中的二重项作一次离散 Abel 分部，还可写成
\[
\boxed{
 E_N^{(0)}
 =M(N)^2-2A(N)T(N-1)
 +2\sum_{n<N}A(n)M(n).
}
\tag{5}
\]

## 2. 该候选路线的精确裁决

式 (4)--(5) 没有把能量化成 \(\mu*\mathbf 1=\varepsilon\) 的望远镜。
剩余项同时含有 \(A(n)=\sum_{j\le n}\mu(j)/j\) 与 \(M(n)\) 的交叉，
而不是一个可由正性直接控制的单调量。用 \(|A(n)M(n)|\) 取绝对值会回到
\(M\) 的平方根级问题；只用 PNT 的 \(A(n)\to0\)、\(M(n)=o(n)\) 只能得到
次二次的粗界，不能得到 \(N^{1+\varepsilon}\)。

因此最简单的指数 Mellin 核并未产生新的无条件算术输入：它把固定比值
二次型压缩成一个明确的加权 Mertens 相关，但该相关仍然是 RH-strength。
这也为 note 257 的一般 log-scale 恒等式提供了一个可审计的边界样本：
即使 \(K\) 取 Green 核，零频端点仍通过 \(M(N)^2\) 与交叉项共同出现。

