> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正 periodization 只能强迫 Mellin 在 $s=1$ 有一个简单零点

日期：2026-08-16。

本 note 关闭一个看似自然的捷径：试图让正 reciprocal kernel 的逐项绝对值
和因为高阶零均值而降到平方根尺度。正性本身强迫 $s=1$ 的 Mellin 零点
恰好为一阶，因此三重全一卷积的正主项至少是 $N\log N$。

## 1. Mellin 恒等式

令

$$
K(s)=\int_0^1V(u)u^{s-1}\,du,
\qquad
P(y)=\sum_{c\le y}V(c/y),\quad y\ge1,
$$

并假设 $P(y)\ge0$、$P\not\equiv0$、以及 $P(y)=O(y^{-1-\eta})$ 对某个
$\eta>0$。在 $\Re s>1$，逐项换序并作 $u=c/y$ 得

$$
\int_1^\infty P(y)y^{-s-1}\,dy=\zeta(s)K(s).
\tag{1}
$$

若 $K(1)=0$，则左端在 $s=1$ 有有限的正极限：

$$
\lim_{s\downarrow1}\zeta(s)K(s)
=\int_1^\infty P(y)y^{-2}\,dy>0.
\tag{2}
$$

因此 $K$ 在 $s=1$ 的零点必为简单零点，并且

$$
K'(1)=\int_1^\infty P(y)y^{-2}\,dy>0.
\tag{3}
$$

特别地，任何非零正 detector 都不可能同时满足
$K(1)=K'(1)=0$。这不是某个具体多项式的偶然限制，而是正
periodization 的一般性结论。

## 2. 三重全一卷积的不可约正主项

考虑把 reciprocal 二次型的 Möbius 系数逐项取绝对值后得到的最粗上界：

$$
\mathcal S_3(N)
:=\sum_{ab\le N}P\!\left(\frac N{ab}\right)
=\sum_{abc\le N}V\!\left(\frac{abc}{N}\right).
\tag{4}
$$

由于 $P$ 在 $(1,2)$ 上非零且连续，存在
$1<y_1<y_2<2$ 与 $c_1>0$ 使 $P(y)\ge c_1$ 于
$[y_1,y_2]$。于是

$$
\begin{aligned}
\mathcal S_3(N)
&\ge c_1\#\left\{(a,b):\frac N{y_2}\le ab\le\frac N{y_1}\right\}\\
&=c_2N\log N+O(N)
\end{aligned}
\tag{5}
$$

其中 $c_2>0$；最后一步是对
$\sum_a(\lfloor N/(y_1a)\rfloor-\lfloor N/(y_2a)\rfloor)$
作初等求和。故逐项绝对值的正上界不可能由 detector 的正性本身降到
$N^{1/2+\varepsilon}$，甚至不能降到 $N^{1-\delta}$。

同一事实也可从 Dirichlet 级数看出：

$$
\sum_{n\ge1}\frac{d_3(n)V(n/N)}{n^s}
\quad\text{的算术主因子为}\quad
\zeta(s)^3K(s),
$$

而 (3) 只消去一个 $\zeta$ 极点，$s=1$ 仍留下二阶极点，对应
$N\log N$ 主项。

这个障碍并不依赖于恰好三重卷积。对整数 $q\ge2$，定义

$$
\mathcal S_q(N):=
\sum_{n_1\cdots n_{q-1}\le N}
P\!\left(\frac{N}{n_1\cdots n_{q-1}}\right).
$$

取同一个区间 $[y_1,y_2]\subset(1,2)$，则 $\mathcal S_q(N)$ 至少是满足
$N/y_2\le n_1\cdots n_{q-1}\le N/y_1$ 的 $(q-1)$-重乘积计数乘以
$c_1$。由标准的重约数求和（对 $q-1$ 做归纳的 Dirichlet 超曲面求和）

$$
\#\{(n_1,\ldots,n_{q-1}):
X<n_1\cdots n_{q-1}\le Y\}
=c_{q,y_1,y_2}N(\log N)^{q-2}
 +O_q\!\left(N(\log N)^{q-3}\right),
$$

其中 $c_{q,y_1,y_2}>0$。因此

$$
\boxed{\mathcal S_q(N)\gg_q N(\log N)^{q-2}.}
$$

这里显示的重约数误差项只用于 $q\ge3$；在 $q=2$ 时区间计数直接是
$(y_1^{-1}-y_2^{-1})N+O(1)$，结论仍为同样的正下界量级。

另一方面，$\mathcal S_q$ 的 Dirichlet 级数主因子是 $\zeta(s)^qK(s)$。
正性强迫的简单零点只消去一个极点，故剩余的 $(q-1)$ 阶极点正好对应
上式的 $(\log N)^{q-2}$；增加卷积深度只会增加正主项，不会产生平方根
节省。

## 3. 对 RH 算术门的含义

正 periodization 的 entrywise 估计至多给出
$O(N\log N)$ 量级；要达到 $N^{1/2+\varepsilon}$，必须保留
Möbius 符号，或引入跨变量 signed cancellation。试图通过增加
$K'(1),K''(1),\ldots$ 的零点来消除该正主项与 $P\ge0$ 不相容。

因此，当前真正的 RH 门不能被“更高阶正 detector + 逐项绝对值”替代；
必须处理原始 Möbius signed energy/intertwiner。本文不声称 RH。
