> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Bernstein 累积权重的反向 Bessel 闭式

日期：2026-08-15。

本 note 给出统一 Euler detector 中 (c_{m-1,k}) 的显式正公式；它把
variation-diminishing 缺口压缩为一个完全明确的 (W)-差分不等式，但本身不
关闭该不等式。

## 1. 累积系数递推

令 (D=3m+3)、(B_D=\binom D2)，并在 Bernstein 基底写

\[
G_{m,j}=
\prod_{\ell=1}^{j}(\Theta+2\ell+1)H_m
=\sum_k c_{j,k}B_{k,D},
\qquad c_{0,2}=B_D^{-1}.
\]

则

\[
c_{j+1,k}=(2j+3-k)c_{j,k}+k c_{j,k-1}.
\tag{1}
\]

令 (C_j(z)=\sum_kc_{j,k}z^k)、(t=z/(1-z))，并置

\[
D_j(t)=\frac{C_j(z)}{1+t}.
\]

由 (1) 得

\[
D_{j+1}=(2j+3)D_j-tD_j'.
\tag{2}
\]

写 (D_j=t^2E_j)，则反向 Bessel 多项式

\[
p_0(q)=1,
\qquad p_{j+1}(q)=(2j+1+q)p_j(q)-q p_j'(q)
\tag{3}
\]

满足

\[
p_j(q)=\sum_{\ell=0}^{j}
\frac{(2j-\ell)!}{2^{j-\ell}(j-\ell)!\,\ell!}\,q^\ell.
\tag{4}
\]

对 (E_j) 使用 Gamma-Laplace 表示并逐次把 (t\partial_t) 作用到
(e^{-tx}p_j(tx))，可得

\[
D_j(t)=\frac{t^2}{2B_D}
\int_0^\infty x^2e^{-(1+t)x}p_j(tx)\,dx.
\tag{5}
\]

代回 (z=t/(1+t)) 后，所有 ((1-z)) 因子精确消去：

\[
\boxed{
C_j(z)=\frac{z^2}{2B_D}
\sum_{\ell=0}^{j}
\frac{(2j-\ell)!(\ell+2)!}{2^{j-\ell}(j-\ell)!\,\ell!}
z^\ell.}
\tag{6}
\]

所以在 (j=m-1) 时

\[
\boxed{
c_{m-1,\ell+2}=
\frac{(2m-2-\ell)!(\ell+2)!}
{2^{m-\ell}(m-1-\ell)!\,\ell!\,\binom{3m+3}{2}},
\quad 0\le\ell\le m-1.}
\tag{7}
\]

这给出所有累积权重的严格正性，无需有限层计算。

## 2. 对 periodization 的含义

令 (w_k=(k+1)c_{m-1,k})、
(W_k(y)=\sum_{n\le y}B_{k,D}(n/y))。则

\[
P_m(y)=C_m^{-1}\sum_{k=2}^{m+1}w_k
\bigl(W_{k+1}(y)-W_k(y)\bigr).
\tag{8}
\]

式 (7) 只证明权重正；它不证明各 (W)-差分正。严格取
(m=3,D=12,y=223/50)，共同分母

\[
15123710539293666054338805121
\]

下

\[
\Delta W_3=-873246425526672312500000<0,
\quad
\Delta W_4=-91203315306290160187500000<0,
\]

\[
\Delta W_5=1728667930600875000000000>0,
\quad
\Delta W_7=-88536570604453125000000000<0.
\]

因此单调性、单峰性、逐差分正性以及逐项绝对值估计均不能闭合 (8)。剩余
最小命题仍是对 (7) 给定的这一串正权证明完整 signed (W)-差分和非负。
