> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius 交换子残差的 Dirichlet--Mellin 精确表示

日期：2026-08-17。

本 note 把 note 236 的 prime-lift 展开提升到双 Dirichlet 级数层面。
结果是一个完全因子化的生成函数，并给出交换子残差的
Mellin--Barnes 表示。它不是 RH 证明，但精确指出了
\(1/\zeta\) 的零点通道以及当前固定 detector 所做的平均化。

## 1. 二维算术核的 Dirichlet 级数

令
\[
 h_a(n):=\sum_{c\mid\gcd(a,n)}\mu(n/c).
\]
在 \(\Re s>1,\ \Re t>1\) 时绝对收敛，并可直接交换求和：
\[
\begin{aligned}
 \sum_{a,n\ge1}\frac{h_a(n)}{a^s n^t}
 &=\sum_{c\ge1}
 \left(\sum_{a'\ge1}\frac1{(ca')^s}\right)
 \left(\sum_{n'\ge1}\frac{\mu(n')}{(cn')^t}\right)\\
 &=\boxed{\frac{\zeta(s)\zeta(s+t)}{\zeta(t)}}.
\end{aligned}
\tag{1}
\]
这里没有使用解析延拓，(1) 首先只是绝对收敛半平面中的恒等式。

## 2. 交换子残差的 Mellin--Barnes 公式

令 \(V\) 在 \((0,1)\) 上给定，并零延拓到 \((1,\infty)\)，其 Mellin
变换为
\[
 K_V(z):=\int_0^1V(u)u^{z-1}\,du.
\]
若 \(\Re s\) 足够大，取 \(c>1\) 且 \(c<\Re s-1\)，Mellin 反演给出
\[
 V(n/a)=\frac1{2\pi i}\int_{(c)}
 K_V(z)\,n^{-z}a^z\,dz.
\]
结合 note 236 的精确式
\[
 ([A_V,D]\mu)(a)
 =-\sum_{n\le a}h_a(n)V(n/a)
\]
和 (1)，得到
\[
\boxed{
 \sum_{a\ge1}\frac{([A_V,D]\mu)(a)}{a^s}
 =-\frac{\zeta(s)}{2\pi i}
 \int_{(c)}K_V(z)\frac{\zeta(s-z)}{\zeta(z)}\,dz .
 }
\tag{2}
\]
在 \(\Re s>c+1\) 时，求和、积分和绝对收敛级数可以逐项交换；
对具有足够端点平坦性的 \(V\)，(2) 再给出其自然解析延拓的起点。

## 3. 对 RH 算术门的解释

式 (2) 有三个直接含义：

1. \(D^{-1}[A_V,D]\mu\) 之前的交换子残差确实保留了
   \(1/\zeta(z)\)；它不是纯粹的 \(-K_V\zeta'\) 通道。
2. 但固定 detector 只通过 \(K_V(z)\) 对
   \(\zeta(s-z)/\zeta(z)\) 作 Mellin--Barnes 平均，不能自动把某个
   离线零点 \(z=\rho\) 单独提取出来。
3. 若能构造一族 \(V_\lambda\)，使 \(K_{V_\lambda}\) 在临界带内形成
   可控的近似恒等核，并同时给出残差的平方根级界，则 (2) 将成为
   一个可能的 RH 入口；但“核局部化 + uniform signed bound”本身仍是
   未解决的算术命题。

因此 (2) 把 note 236 的局部 prime-lift 支持和 zeta 零点通道接起来，
同时明确了为什么有限 rank 或普通绝对值估计不足以完成 RH。
