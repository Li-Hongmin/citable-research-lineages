> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定正权 Mellin 能量是 RH 的显式等价门

日期：2026-08-16。

## 命题

设 \(w:\mathbb R\to[0,\infty)\) 满足

\[
 w\in L^1(\mathbb R),
 \qquad w(t)\ge c_0>0\quad(|t|\le\delta_0),
 \qquad \int_{\mathbb R}(1+|t|)^\kappa w(t)\,dt<\infty
\tag{1}
\]

其中 \(c_0,\delta_0,\kappa>0\)。令

\[
 F_N(t)=\sum_{n\le N}\mu(n)n^{it},
 \qquad E_N(w)=\int_{\mathbb R}w(t)|F_N(t)|^2\,dt.
\tag{2}
\]

则有两条严格蕴含：

1. 若对每个 \(\varepsilon>0\)，统一地
   \(E_N(w)\ll_{\varepsilon,w}N^{1+\varepsilon}\)，则 RH 成立；
2. 在 RH 下，结合经典的 Littlewood 型界
   \(1/|\zeta(\sigma+iu)|\ll_\delta(1+|u|)^\delta\)
   （\(\sigma\ge\frac12+\delta\)），反向有
   \(E_N(w)\ll_{\varepsilon,w}N^{1+\varepsilon}\)。

因此，在条件 (1) 下，当前正能量门不是比 RH 更弱的中间命题，而是 RH 的固定权
二次型重述。

## 正能量门推出 RH

令
\[
 A(X)=\sum_{n\le X}\mu(n),
 \qquad A^*(X)=\max_{x\le X}|A(x)|,
\]
并取 \(X_0\le X\) 使 \(|A(X_0)|=A^*(X)\)。Abel 部分求和给出
\[
 F_{X_0}(t)=A(X_0)X_0^{it}
 -it\int_1^{X_0}A(u)u^{it-1}\,du.
\]
若 \(|t|\le(16\log X_0)^{-1}\)，则
\[
 |F_{X_0}(t)-A(X_0)|
 \le 2|t|A^*(X_0)\log X_0
 \le \frac{3}{16}A^*(X_0),
\]
从而 \(|F_{X_0}(t)|\ge\frac34A^*(X_0)\)。由 (1)，对充分大的 \(X_0\)，
\[
 E_{X_0}(w)
 \ge \frac{9c_0}{128\log X_0}A^*(X_0)^2.
\]
若能量门成立，便得到
\[
 A^*(X)\ll_{\varepsilon,w}X^{1/2+\varepsilon}.
\]
标准的 Mertens--RH 等价性遂给出 RH。这一步不需要外函数、Gamma 系数或任何
预印本的 packet 结构。

## RH 反向推出能量门

用截断 Perron 公式表示 \(F_N(t)\)，并把积分线移到
\(\sigma=\frac12+\delta\)。在 \(|t|\le T=N^B\) 上，RH 与 Littlewood 界给出
\[
 |F_N(t)|
 \ll_{\delta,B}N^{1/2+\delta+B\delta}\log(2N)
       +N^{1-B}\log(2N).
\tag{3}
\]
这里第二项是截断误差，第一项来自
\(1/\zeta(\sigma+i(u-t))\) 的多项式增长。于是
\[
 \int_{|t|\le T}w(t)|F_N(t)|^2dt
 \ll_w N^{1+2\delta(1+B)}(\log(2N))^2+N^{2-2B}(\log(2N))^2.
\]
在尾部使用 \(|F_N(t)|\le N\) 以及 (1)：
\[
 \int_{|t|>T}w(t)|F_N(t)|^2dt
 \ll_w N^2T^{-\kappa}.
\]
先取 \(B\kappa>1+\varepsilon\)，再取 \(\delta>0\) 足够小，即得
\[
 E_N(w)\ll_{\varepsilon,w}N^{1+\varepsilon}.
\]

## 对当前项目的作用

当前 \(V_{15}\) detector 的
\(w(t)=|\operatorname{Re}(\zeta(it)K_{15}(it))|/(2\pi)\) 满足零频正性和足够的
频率矩条件。因此项目中真正需要解决的对象可以不再表述为未定义的 Gamma 或
packet coefficient，而可直接表述为：

\[
 \int_{\mathbb R}|h(t)|
 \left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt
 \ll_\varepsilon N^{1+\varepsilon}.
\]

这仍是未解决的 Möbius signed-energy 估计；本命题只是把它精确地钉在 RH 等价门上，
不声称已经得到 RH。
