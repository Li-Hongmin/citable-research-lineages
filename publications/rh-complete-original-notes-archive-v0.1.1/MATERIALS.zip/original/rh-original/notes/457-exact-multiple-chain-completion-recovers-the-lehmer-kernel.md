> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 倍数链的精确 completion 恢复原始 Lehmer 核

日期：2026-08-17。

note 455 只估计单条除数链的交叉项。本 note 给出一个更强的有限尺度恒等式：
对每个基准除数 (d)，把 (T_N) 的所有倍数列完整相加，Möbius 卷积恰好
恢复原始三角因子 (R_N)。再对两条倍数链求 Gram 内积，得到原始 Lehmer
核的精确 completion。

## 1. 单链 completion

沿用

\[
(T_N)_{k,d}=\frac{\sqrt{2k+1}}d
\sum_{j=\lfloor k/d\rfloor+1}^{\lfloor N/d\rfloor}\frac{\mu(j)}j,
\qquad 1\le k<N.
\]

固定 (d\le N)，对所有 (1\le a\le\lfloor N/d\rfloor) 求和。令
(n=aj)，则

\[
\begin{aligned}
\sum_{a\le N/d}(T_N)_{k,ad}
&=\frac{\sqrt{2k+1}}d
\sum_{\substack{n>k/d\\n\le N/d}}
\frac1n\sum_{a\mid n}\mu(n/a)\\
&=\frac{\sqrt{2k+1}}d\,\mathbf 1_{k<d}.
\end{aligned}
\tag{1}
\]

这里使用 (sum_{a\mid n}mu(n/a)=\mathbf1_{n=1})。因此，若
(C_d:=\sum_{a\le N/d}e_{ad})，则

\[
\boxed{T_NC_d=R_Ne_d.}
\tag{2}
\]

这也可写成矩阵恒等式 (T_ND_N=R_N)；式 (1) 是其逐行的
Möbius 解释。OMEN 用精确有理数核验了 (N=20,31,64,100) 的全部 (k,d)。

## 2. 两条倍数链的 Gram completion

令

\[
G_N=T_N^{\mathsf T}T_N=D_N^{-\mathsf T}K_ND_N^{-1}.
\]

由 (2)，对任意 (d,e\le N)，有

\[
\begin{aligned}
\sum_{a\le N/d}\sum_{b\le N/e} (G_N)_{ad,be}
&=\langle R_Ne_d,R_Ne_e\rangle\\
&=\frac1{de}\sum_{k<\min(d,e)}(2k+1)\\
&=\boxed{\frac{(\min(d,e)^2-1)_+}{de}}.
\end{aligned}
\tag{3}
\]

其中 ((x)_+=x) 对 (x>0)，而 (d=1) 或 (e=1) 时右端为零。OMEN
用精确有理数核验了 (N=20,31,64) 的全部 (d,e)。

特别地，对 (d=e\ge2)，

\[
\sum_{a,b\le N/d}(G_N)_{ad,bd}=1-d^{-2}.
\tag{4}
\]

## 3. 对 RH 门的含义

式 (3) 是完整倍数链的 exact completion，而不是一个新的正性估计。它说明：

1. 只研究一条链的局部 Cauchy 包络，必然遗漏同一 completion 中的其它倍数列；
2. 把所有倍数列补齐后，结果退化为已知的原始 Lehmer 三角 Gram，而不是产生新的
   (1/a) 收缩；
3. 任何想利用除数链求得平方根级界的方案，都必须同时控制截断 completion 误差，
   并保留链间的 Möbius 符号。逐项取绝对值会破坏式 (3) 的精确抵消。

因此，式 (3) 给出了一个可审计的“链 completion”接口，进一步明确了缺口：
不是单链的局部正性，而是截断倍数 completion 的 signed 算术控制。它不宣称
RH 证明。
