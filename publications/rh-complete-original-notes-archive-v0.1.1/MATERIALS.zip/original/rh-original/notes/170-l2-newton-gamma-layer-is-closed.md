> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# L=2 Newton 层的 gamma 正性（更正后恢复）

日期：2026-08-16。

旧版撤回是因为把 \((q+1)c_q\) 与 q-shift 所需的
\(w_q=c_q\binom Dq\) 混为同一权重。该误判已由 note 230 更正。用正确权重
重新核对后，notes 163--164 的 Beta 累计证明可以恢复，得到

\[
\boxed{\gamma_{m,h,2}\ge0\quad(m\ge1,;0\le h\le 3m+1).}
\]

## 证明边界

对 \(m\ge4\)，note 163 将 raw 累计系数写成正确 Beta 分量的和。note 164
证明每个分量的系数序列至多一次变号且总和为正：

- \(M=0\) 分支直接给出低指标符号、尾部正性和正端点；
- \(1\le M\le m-1\) 时，\(u=0,1\) 为负、\(u=2,\ldots,6\) 为正，
  \(u\ge7\) 由 \(A(7)\)、\(B(7)\)、\(B(L)\) 的显式端点多项式下界闭合；
- 端点修正由正确 \(K_q\) 的正尾和与 Abel 变换给出非负。

于是每个 Beta 分量的 raw 前缀为正，正 Beta 权重求和后仍为正。\(m=1,2,3\)
由完整 Fraction 表直接核验：

\[
\begin{aligned}
m=1 &: (0,0,0,0,0),\\
m=2 &: (3/2,3/2,5/3,2,2,5/3,3/2,3/2),\\
m=3 &: (351,747/2,1168/3,403,424,464,524,590,1931/3,1359/2,702).
\end{aligned}
\]

`computations/check_l2_beta_prefix.py` 对正确 q-shift 原式与 Beta 分解做了
精确对齐检查（\(m=4,\ldots,20\)），并检查了尾部/低指标符号模式
（\(m=4,\ldots,100\)）。这些有限运行是审计证据；全 \(m\) 结论来自
notes 163--164 中的显式不等式，而非扫描外推。

## RH 边界

该结果只闭合 detector 的一个 Newton 层，不能替代保持
\(\mu(a)\mu(b)\) 符号的 Möbius reciprocal-product 二次型估计；RH 所需的
平方根级 signed-energy / arithmetic intertwiner 仍未建立。
