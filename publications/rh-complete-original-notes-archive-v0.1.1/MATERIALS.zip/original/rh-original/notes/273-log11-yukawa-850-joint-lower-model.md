> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# a_11 = (log 11)/2 处 P_400^+ 的 256-bit 500:850 joint-Schur 证书

日期：2026-08-16。

本 note 记录一个新的有限维、可复核证书。它不声称完整算子正性、奇 sector 正性或黎曼猜想。

## 对象与下界构造

令 a_11 = (log 11)/2，A_11^+ 为 A_{a_11} 在 even sector 上的限制，P_400^+ 为前 400 维压缩。

下界模型使用：

- 统一 256-bit Arb parent/base cache；
- clean full contract base：K=400，N=500；
- verified graph：R=280，N=500；
- 完整 joint Yukawa family F_{500:850}，共 350 个 atom，保留全部 atom cross-Gram；
- sharp checker 的二次型截断参数 q_f=8000。

所有 parent、graph、family 与最终 Schur/LDL 计算均以 256-bit 输入生成；因此这次运行不再沿用 note 168 中 192-bit parent 输入导致的宽区间。

## 可复现入口

```text
generate_log10_endpoint_contract_cache.py 256 400 500 + --endpoint 11 --export-full-safe-matrix
generate_log10_endpoint_contract_cache.py 256 280 500 + --endpoint 11 --export-verified-graph
extract_log10_even_K400_full_contract_base.py --cache-prefix log11 --precision 256 --n500-clean
generate_log10_endpoint_contract_cache.py 256 400 500 + --endpoint 11 --export-yukawa-family 500 850
log10_even_K400_sharp_safe_arb.py --full400 --clean-no-yukawa \
  --family scratch/log11_even_K400_N500_yukawa_500_850_parseval_arb_256.npz 350 \
  --qf 8000 --cache-prefix log11 256 11 1
```

最终结果文件为：

```text
scratch/log11_even_K400_N500_clean_sharp_family_500_850_full393_q8000_arb_256.npz
```

## 严格输出

checker 先对补空间 H 做 Cholesky，再对核心 Schur complement 做带置换的区间 LDL。输出为：

```text
H_CHOLESKY_MIN_PIVOT
0.0388731071843266890885172591580563674143705623050536527382 +/- 7.93e-59

CORE_PIVOT_PERM
(6, 2, 5, 1, 0, 4, 3)

CORE_PIVOTS
4.4240091246e-14
1.0356722332e-18
6.1187269030e-24
8.3990623658e-29
6.1819048480e-35
9.9853895713e-42
1.86965346203867934e-50 +/- 2.75e-68
```

最后一个区间严格为正。因此本次 lower model 严格正定：

```text
L_lower(500:850, even) > 0
```

并且构造中有 Loewner 下界关系：

```text
L_lower(500:850, even) <= P_400^+ A_11^+ P_400^+.
```

由此得到有限维结论：P_400^+ A_11^+ P_400^+ 严格正定。

严格性来自补空间 Cholesky、Schur complement 和全部核心区间 pivot，而不是浮点特征值。

## 与旧结果的关系及边界

note 168 的 500:700 lower model 曾有一个未闭合的负核心区间。把 family 统一扩展到 500:850，并保留交叉 Gram 后，本次 256-bit 证书将该有限 lower model 修复为严格正定。这是对同一有限压缩的新承重证书，不是对无限维尾部的证明。

本 note 只覆盖 even P_400 compression at a_11。它没有证明：

1. 完整 A_11^+ 的无限维正性；
2. odd sector 的正性；
3. 任意 P_N 或全尺度 a 的统一正性；
4. Möbius reciprocal-product 二次型的平方根级 signed cancellation；
5. 黎曼猜想。

本证书作为 note 275 的 even 输入；结合 note 089 的 cutoff-free Loewner--Parseval 尾支付后，note 275 将其与 odd 证书升级为完整的 \(A_{a_{11}}^\pm>0\) 局部定理。继续增加同类 even 有限 family 不能替代全局算术 intertwiner。
