> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 除数列对角能量的精确递归

日期：2026-08-17。

令

\[
G_N:=T_N^{\mathsf T}T_N,
\qquad
\mathcal E_M:=\frac{I_M}{\pi}
=\sum_{q=1}^{M-1}(2q+1)
\left(\sum_{q<n\le M}\frac{\mu(n)}n\right)^2.
\]

对 \(M\ge1\) 再记

\[
S(M):=\sum_{n\le M}\frac{\mu(n)}n.
\]

## 1. 单列平方范数

令 \(M_d:=\lfloor N/d\rfloor\)。由 note 445，

\[
(T_N)_{k,d}
=\frac{\sqrt{2k+1}}d
\sum_{\lfloor k/d\rfloor<n\le M_d}\frac{\mu(n)}n.
\]

于是对固定 \(d\)，按 \(q=\lfloor k/d\rfloor\) 分组。块 \(q=0\) 对应
\(1\le k\le d-1\)，其权重和为

\[
\sum_{k=1}^{d-1}(2k+1)=d^2-1.
\]

对 \(1\le q<M_d\)，完整块
\(k=dq,\ldots,dq+d-1\) 的权重和为

\[
\sum_{k=dq}^{dq+d-1}(2k+1)=d(2q+1).
\]

最后的部分块 \(q=M_d\) 不贡献，因为其调和尾
\(\sum_{M_d<n\le M_d}\mu(n)/n\) 为零。故得到精确恒等式

\[
\boxed{
(G_N)_{d,d}
=\mathcal E_{\lfloor N/d\rfloor}
+\left(1-\frac1{d^2}\right)
S(\lfloor N/d\rfloor)^2,
\qquad 1\le d\le N.
}
\tag{1}
\]

当 \(d=1\) 时第二项为零，(1) 恢复
\((G_N)_{1,1}=I_N/\pi\)。

OMEN 用精确有理数对 \(N=10,17,30,64\) 的所有 \(d\) 核验了 (1)。

## 2. 迹的递归表达

对 \(d\) 求和得到

\[
\boxed{
\operatorname{tr}G_N
=\sum_{d=1}^{N}
\mathcal E_{\lfloor N/d\rfloor}
+\sum_{d=2}^{N}
\left(1-\frac1{d^2}\right)
S(\lfloor N/d\rfloor)^2.
}
\tag{2}
\]

因此每个非首列的对角能量都已经被精确降到更小截断的 Lehmer 能量和一个零频调和项；真正未闭合的部分不在对角递归，而在 \(G_{d,e}\)（\(d\ne e\)）的 signed cross-correlation。

## 3. 对 RH 路线的含义

结合 note 447 的 \(T_N\mathbf1_N=0\)，目标能量满足

\[
\mathcal E_N
=\mathbf1_{N-1}^{\mathsf T}
G_N[2:N,2:N]\,
\mathbf1_{N-1}.
\]

式 (1) 给出了这个正 Gram 子块的全部对角线，但仅凭对角线不能控制上式：非对角项必须保留 Möbius 符号并产生抵消。故 (1) 是一个严格的递归分解，不能被误读成 RH 证明；它把下一道问题精确限制为跨尺度非对角相关。
