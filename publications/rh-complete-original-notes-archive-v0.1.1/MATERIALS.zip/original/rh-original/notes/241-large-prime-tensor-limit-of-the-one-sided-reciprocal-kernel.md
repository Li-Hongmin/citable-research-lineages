> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 大素数分离下单侧 reciprocal 核的张量极限与指数负惯性

本 note 给出一个直接作用于实际单侧 detector 的谱结构结果。它把 squarefree
divisor complement 的负惯性从理想化的偶核模型提升到原始的单侧核，并说明
多变量 prime-jet 不能以固定秩修复该负方向族。

## 1. 单侧核与有限 divisor 格

令 \(V=V_{15}\)，并写

\[
 P(y)=\sum_{c\le y}V(c/y)\quad (y\ge1),
 \qquad p(t)=\begin{cases}P(e^t),&t\ge0,\\0,&t<0.\end{cases}
\]

在 squarefree \(X\) 的完整 divisor 格

\[
 \mathcal D_X=\{d:d\mid X\}
\]

上定义实际 reciprocal 矩阵

\[
 H_X(d,e)=p\!\left(\log\frac{X}{de}\right).
 \tag{1}
\]

这里不作偶化；当 \(de>X\) 时，(1) 直接为零。由端点平坦性和 Poisson
表示，已有严格估计

\[
 P(y)=O(y^{-2})
 \qquad (y\to\infty),
 \tag{2}
\]

故 \(p(t)=O(e^{-2t})\)（\(t\to+\infty\)）。

## 2. 大素数分离

固定一个 squarefree 核 \(Y\)，并令

\[
 Z_r=p_1\cdots p_r,
 \qquad X_r=YZ_r,
\]

其中 \(p_1,\ldots,p_r\) 取为彼此充分分离的大素数。精确地，对任意
 \(T\to\infty\)，可以递归选择素数使得每个非平凡乘积比

\[
 \frac{Z_r}{bb'},\qquad b,b'\mid Z_r,
 \qquad bb'\ne Z_r,
 \tag{3}
\]

要么不超过 \(T^{-1}\)，要么不小于 \(T\)。这是有限个指数向量
 \((1-\beta_i-\beta_i')_{i=1}^r\in\{-1,0,1\}^r\) 的支配式选择；例如可逐步
 取 \(p_{j+1}>T(\prod_{i\le j}p_i)^2\)。

把 \(\ell^2(\mathcal D_{X_r})\) 按
 \(\mathcal D_Y\times\mathcal D_{Z_r}\) 排列，并令 \(R_{Z_r}\) 为补集反射

\[
 R_{Z_r}e_b=e_{Z_r/b}.
\]

若 \(b'=Z_r/b\)，则 (1) 给出精确等式

\[
 H_{X_r}((a,b),(a',b'))
 =p\!\left(\log\frac{Y}{aa'}\right)=H_Y(a,a').
 \tag{4}
\]

若 \(bb'\ne Z_r\)，由 (2)--(3) 得该矩阵元为 \(0\) 或 \(O(T^{-2})\)。由于格是
有限的，存在常数 \(C_{Y,r}\) 使

\[
 \left\|H_{X_r}-H_Y\otimes R_{Z_r}\right\|_{\mathrm{op}}
 \le C_{Y,r}T^{-2}.
 \tag{5}
\]

这给出实际单侧核的严格张量极限

\[
 \boxed{H_{X_r}\longrightarrow H_Y\otimes R_{Z_r}}
 \tag{6}
\]

沿上述大素数分离族成立。这里的极限只用 (2) 和有限维矩阵扰动，不涉及
任何 RH 假设。

## 3. 核心 \(Y=2\) 的指数负惯性

由 \(P(1)=0\) 及 \(P(2)=473/16384>0\)，在
 \(\mathcal D_2=\{1,2\}\) 上

\[
 H_2=
 \begin{pmatrix}P(2)&P(1)\\P(1)&P(1/2)\end{pmatrix}
 =\begin{pmatrix}A&0\\0&0\end{pmatrix},
 \qquad A=\frac{473}{16384}>0.
 \tag{7}
\]

因此极限矩阵 \(H_2\otimes R_{Z_r}\) 在子空间
 \(\operatorname{span}\{e_1\}\otimes\ell^2(\mathcal D_{Z_r})\) 上就是
 \(A R_{Z_r}\)。补集反射 \(R_{Z_r}\) 无固定点，并有

\[
 \dim E_+(R_{Z_r})=\dim E_-(R_{Z_r})=2^{r-1}.
 \tag{8}
\]

所以 \(H_2\otimes R_{Z_r}\) 有 \(2^{r-1}\) 个特征值 \(-A\)。由 (5) 和 Weyl
扰动不等式，只要 \(T\) 足够大，使 \(C_{2,r}T^{-2}<A/3\)，实际矩阵
 \(H_{2Z_r}\) 至少有 \(2^{r-1}\) 个特征值满足

\[
 \lambda\le-\frac{2A}{3}=-\frac{946}{49152}.
 \tag{9}
\]

结论是一个真实单侧核的严格负惯性定理：

\[
 \boxed{
 n_-(H_{2Z_r})\ge 2^{r-1}
 }
 \tag{10}
\]

沿大素数分离族成立，而且这些负方向的大小并不趋于零。

## 4. 对 prime-jet 补偿的含义

note 240 的混合 prime jets 在完整 divisor 格上给出坐标基；对补集
 \(Y\subseteq X\) 的 jet，其向量范数平方为

\[
 \left\|\partial_YD_{\boldsymbol\sigma}^{T}c_X\big|_0\right\|^2
 =\prod_{p\mid Y}(\log p)^2.
 \tag{11}
\]

因此 prime jets 确实能逐坐标命中 (10) 中的负方向，但不能以固定数量的 jets
消除它们：任意 rank-\(q\) Hermitian 修正至多改变 \(q\) 个负惯性方向。特别地，
对每个固定 \(q\)，取 \(r>1+\log_2q\) 后，仍有未修复的负特征值。

这不是平方根级 RH 界的反证；\(2^r\) 对于由 \(r\) 个素数构成的 \(X\) 仍是
 \(X^{o(1)}\)。它严格关闭的是更窄的捷径：有限 rank 的 prime-jet/Feshbach
补偿、逐个固定维度的 PSD 化，以及把单侧 reciprocal 核当作统一正 Gram。
若要继续追求 RH 级估计，必须保留这些指数增长的 reflection parity，并在不同
 \(X\) 之间构造真正的 signed cross-scale intertwiner。

更强地，在同一大素数分离族上，PSD 锥到 \(H_{2Z_r}\) 的算子范数距离满足

\[
 \operatorname{dist}_{\mathrm{op}}\!\left(H_{2Z_r},
   \{B:B\succeq0\}\right)\ge \frac{2A}{3}.
 \tag{12}
\]

这是因为到 PSD 锥的算子范数距离至少等于
\(-\lambda_{\min}(H_{2Z_r})\)。所以不能先把单侧核作一个算子范数
 \(o(1)\) 的正化再保留其 reciprocal 信息；正化误差在这些尺度上有固定下界。

## 5. 证据边界

式 (6)--(10) 是有限维大素数分离的解析结论；它没有把有限矩阵的负惯性直接
外推到全局 Möbius 能量，也没有声称 RH 或反 RH。它提供的是当前最小、可复核的
结构性边界：多变量 jets 解决坐标化，却不能消除实际单侧 kernel 的指数反射负谱。

依赖：notes 174、177、178、240。
