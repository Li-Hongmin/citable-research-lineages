> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 平方根 completion 的 residual 含有普适 reciprocal 边界常数

日期：2026-08-17。

note 459 的边界量在最自然的平方根截断上可以进一步化简。令
$M=A^2$，$A\ge2$，则
$\lfloor M/(A+1)\rfloor=A-1$，并且式 (2) 中的 $b=A$ 项为零。因此

\[
Z_{A^2,A}
=\sum_{b=1}^{A}\frac{\mu(b)}b
\left(H_{\lfloor A^2/b\rfloor}-H_A\right).
\tag{1}
\]

## 1. 精确渐近展开

对 $1\le b\le A$，调和数估计给出

\[
H_{\lfloor A^2/b\rfloor}-H_A
=\log A-\log b+O\left(\frac1A+\frac b{A^2}\right).
\tag{2}
\]

故

\[
\boxed{
Z_{A^2,A}
=\log A\sum_{b\le A}\frac{\mu(b)}b
-\sum_{b\le A}\frac{\mu(b)\log b}{b}
+O\left(\frac{\log A}{A}\right).
}
\tag{3}
\]

## 2. 普适极限

经典零自由区给出

\[
\sum_{b\le A}\frac{\mu(b)}b
=O\!\left(\exp[-c(\log A)^{3/5}(\log\log A)^{-1/5}]\right),
\tag{4}
\]

所以第一项趋于零。相同的零自由区估计使
$\sum \mu(b)\log b/b$ 收敛；由

\[
\frac{d}{ds}\frac1{\zeta(s)}
=-\sum_{n\ge1}\frac{\mu(n)\log n}{n^s},
\qquad
\frac1{\zeta(s)}=(s-1)+O((s-1)^2),
\]

在 $s\downarrow1$ 取 Abel 极限，得到

\[
\sum_{b\ge1}\frac{\mu(b)\log b}{b}=-1.
\tag{5}
\]

因此

\[
\boxed{Z_{A^2,A}=1+o(1).}
\tag{6}
\]

结合 note 459 的 rank-one 下界，平方根截断 residual 至少含有

\[
\|\mathcal R_{d,A}\|_2^2
\ge (1-d^{-2})(1+o(1))
\]

的显式边界块。OMEN 浮点诊断 $A=4,8,\ldots,2048$ 得到
$Z=0.913467,0.988789,0.996344,1.000266,\ldots,0.999866$，与式 (6) 一致。

## 3. 含义

这不是 RH 反例：常数量级 residual 本身小于允许的 $N^{1+\varepsilon}$ 能量。
它说明的是，平方根截断不能把 completion 边界误差当成趋零项；若要得到更强的
算术桥，必须显式扣除这个 reciprocal 边界常数，并同时控制 $q>0$ 的 signed
变参数 residual。普通正性或 Cauchy 不会自动完成这一步。
