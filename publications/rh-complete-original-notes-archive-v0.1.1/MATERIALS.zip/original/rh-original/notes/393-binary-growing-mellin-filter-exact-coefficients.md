> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 对数阶二进制 Mellin 滤波器的精确系数结构

本 note 把 note 272 的复杂度门落实到最简单的候选
\[
A_q(t)=(1-2^{it})^q.
\]
它在 \(t=0\) 有恰好 \(q\) 阶零点，且系数结构可以完全写出；因此它是检验
“随尺度增长的滤波器能否绕开 RH 门”的最小算术模型。

## 1. 零频阶与归一化

由
\[
|1-e^{ix}|=2|\sin(x/2)|\ge |x|/2
\qquad (|x|\le1),
\]
对 \(|t|\le1/\log X\) 有
\[
|A_q(t)|
\ge \left(\frac{\log2}{2}\right)^q |t|^q.
\tag{1}
\]
因此 note 272 中的局部常数可取
\[
c_{X,q}=\left(\frac{\log2}{2}\right)^q.
\tag{2}
\]
若 \(q=o(\log X/\log\log X)\)，则
\[
(\log X)^q=X^{o(1)},\qquad c_{X,q}^{-1}=X^{o(1)},
\]
统一正能量门仍由 note 272 推出 RH。要真正逃逸，必须至少取
\[
q\asymp \frac{\log X}{\log\log X}.
\tag{3}
\]

## 2. 与 Möbius 系数的精确卷积

令
\[
F_X(t)=\sum_{n\le X}\mu(n)n^{it}.
\]
则
\[
A_q(t)F_X(t)
=\sum_{m\le 2^qX} b_{q,X}(m)m^{it},
\]
其中精确系数为
\[
b_{q,X}(m)
=
\sum_{\substack{0\le j\le q\\2^j\mid m\\m/2^j\le X}}
(-1)^j\binom qj\,\mu(m/2^j).
\tag{4}
\]
这是一个有限二进制差分，不是新的独立 Möbius 序列；截断只出现在
\(X<m\le2^qX\) 的边界带。

在内部区间 \(m\le X\)，写 \(m=2^v u\)、\(u\) 奇数。若 \(\mu(u)=0\)，
则所有项都为零；若 \(\mu(u)\ne0\)，则
\[
b_{q,X}(2^v u)=
\begin{cases}
\mu(u),&v=0,\\[1mm]
-(q+1)\mu(u),&v=1,\\[1mm]
(-1)^v\binom{q+1}{v}\mu(u),&2\le v\le q+1,\\[1mm]
0,&v\ge q+2.
\end{cases}
\tag{5}
\]
式 (5) 直接来自 \(\mu(2u)=-\mu(u)\) 与 Pascal 恒等式；它说明滤波器
只重新加权二进制赋值层，并没有消除 Möbius 的宏观 signed correlation。

## 3. 部分和的精确 dyadic 差分

令
\[
S_{q,X}(Y):=\sum_{m\le Y}b_{q,X}(m).
\]
直接交换有限和，得到对所有 \(X,Y\ge1\) 的恒等式
\[
S_{q,X}(Y)
=\sum_{j=0}^{q}(-1)^j\binom qj\,
M\!\left(\min\!\left(X,\left\lfloor\frac{Y}{2^j}\right\rfloor\right)\right).
\tag{6}
\]
特别地，当 \(Y\le X\) 时，
\[
S_{q,X}(Y)
=\sum_{j=0}^{q}(-1)^j\binom qj\,
M\!\left(\left\lfloor\frac{Y}{2^j}\right\rfloor\right),
\tag{7}
\]
而当 \(Y\ge2^qX\) 时 \(S_{q,X}(Y)=0\)。因此截断边界并非不可描述的误差，
而是 (6) 中 \(\min(X,\cdot)\) 造成的折点族。

式 (7) 说明：若能对临界阶
\(q\asymp\log X/\log\log X\) 的滤波和给出平方根级控制，真正需要估计的是
一组随 \(Y\) 移动的高阶 dyadic Mertens 差分；仅控制内部系数或只取每层
绝对值都没有覆盖折点族。

## 4. 复杂度判定

取临界逃逸阶
\[
q=\left\lceil c\,\frac{\log X}{\log\log X}\right\rceil .
\]
则滤波器的系数 \(\ell^1\) 范数为
\[
\sum_{j=0}^q\binom qj=2^q
=\exp\!\left(\frac{c\log2+o(1)}{\log\log X}\log X\right)
=X^{o(1)}.
\tag{8}
\]
所以该候选确实满足“系数规模次幂增长”，不能以粗糙的系数爆炸把它排除。

另一方面，(5) 表明其内部系数含有
\[
1,\quad -(q+1),\quad
\binom{q+1}{2},\ldots,\binom{q+1}{q+1}
\]
的完整二进制层。任何对 \(A_qF_X\) 的正能量估计，若逐层取绝对值，
都会支付至少一个增长的二进制层权；若保留层间符号，则剩余对象正是
\[
\sum_{v=0}^{q+1}(-1)^v\binom{q+1}{v}
\;2^{ivt}
\sum_{\substack{u\le X/2^v\\u\ {\rm odd}}}\mu(u)u^{it},
\tag{9}
\]
即二进制尺度上的高阶 signed difference；完整滤波和还要加上
\(X<m\le2^qX\) 的截断边界带。现有正 Gram 或一般 mean-value
估计不会自动给出该差分及其边界带的 \(X^{1/2+\varepsilon}\) 界。

## 结论

\(A_q(t)=(1-2^{it})^q\) 精确实现了 note 272 所需的临界零频阶，
且其系数规模只有 \(X^{o(1)}\)，因此“增长滤波器会因系数爆炸而失败”
不是有效的排除理由。真正的新算术命题被压缩为 (9) 的二进制高阶
Möbius signed difference 与相应截断边界带的联合估计；在此估计之前，
增长滤波器只是把 RH 门从零频点转移到了二进制尺度层间，而没有关闭它。
