> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius 预条件正 periodization 的 full ζ^{-2} 门

本 note 固定一个可完全计算的正 periodization 构造，说明它并没有绕开
Möbius signed cancellation：其平方根级界直接蕴含 RH。

## 构造与精确 periodization

令
\[
\phi(u)=u(1-u)\,\mathbf 1_{(0,1)}(u),
\qquad
V_\phi(u)=\sum_{n\ge1}\mu(n)\phi(nu),\quad 0<u<1.
\]
对每个固定 (u>0) 和式只有有限项。定义
\[
P_{V_\phi}(y)=\sum_{c\le y}V_\phi(c/y),\qquad y\ge1.
\]
交换有限和并使用
\(\sum_{n\mid k}\mu(n)=\mathbf 1_{k=1}\)，得到严格恒等式
\[
P_{V_\phi}(y)=\phi(1/y)=\frac1y\left(1-\frac1y\right)\ge0.
\]
端点 (c=y) 的项为零，因为 \(\phi(1)=0\)。因此这是一个真正的
非负 periodization，但它的 Möbius 系数不是正的。

## Mellin 变换

令
\[
\Phi(s)=\int_0^1\phi(u)u^{s-1}\,du
       =\frac1{(s+1)(s+2)},\qquad \Re s>-1.
\]
在绝对收敛半平面 \(\Re s>1\) 中，Mellin--Fubini 给出
\[
K_{V_\phi}(s)=\int_0^1V_\phi(u)u^{s-1}\,du
 =\frac{\Phi(s)}{\zeta(s)}.
\]
这里 \(\Phi\) 在 \(\Re s>-1\) 没有零点；因此该例不把零点信息藏进
一个人为的 Mellin 零点。

## 递归二次和与 \(\zeta^{-2}\)

令 \(a=\mu*\mu\)，并定义不截断的 full 和
\[
T_\phi^{\mathrm{full}}(x)=\sum_{n<x}a(n)\phi(n/x),\qquad x\ge1.
\]
对 \(\Re s>1\)，逐项积分（每一项从 \(x=n\) 开始）得到
\[
\begin{aligned}
\int_1^\infty T_\phi^{\mathrm{full}}(x)x^{-s-1}\,dx
 &=\sum_{n\ge1}a(n)n^{-s}
   \int_0^1\phi(u)u^{s-1}\,du\\
 &=\frac{\Phi(s)}{\zeta(s)^2}.
\end{aligned}
\tag{1}
\]
这是 exact identity，不是渐近式。它也可由去掉 individual cutoff 的 full
reciprocal-product 二次和重排得到：
\[
\sum_{ab<x}\mu(a)\mu(b)P_{V_\phi}(x/(ab))
 =\sum_{n<x}(\mu*\mu)(n)\phi(n/x),
\]
其中边界约定由 \(\phi(1)=0\) 吸收。原始
\(a,b\le\sqrt x\) 截断和还要减去 incomplete-lcm boundary；见 note 370。

## RH 门

若对每个 \(\varepsilon>0\) 都有
\[
T_\phi^{\mathrm{full}}(x)=O_\varepsilon(x^{1/2+\varepsilon}),
\tag{2}
\]
则 RH 成立。事实上，(2) 使左端 Mellin 积分在任意
\(\Re s>1/2\) 上（先选足够小的 \(\varepsilon\)）绝对收敛并定义全纯函数。
由 (1) 的恒等延拓，\(\Phi(s)/\zeta(s)^2\) 在该半平面全纯。由于
\(\Phi(s)\neq0\)（\(\Re s>-1\)），\(1/\zeta(s)^2\) 不可能在
\(\Re s>1/2\) 有极点；故 \(\zeta\) 在该半平面无零点。结合函数方程，
这正是 RH。

因此，\(P_{V_\phi}\ge0\) 并没有把问题降为一个普通正能量估计；要获得
平方根级 full 和界，仍须控制 \(\mu*\mu\) 的 signed 和，且该界
本身已是 RH-strength 输入。

## 有限有理校准

取 \(\phi(u)=u(1-u)\) 时，直接计算得到
\[
T_\phi^{\mathrm{full}}(3)=-\frac29,\qquad
T_\phi^{\mathrm{full}}(5)=-\frac{16}{25},\qquad
T_\phi^{\mathrm{full}}(10)=-\frac7{25}.
\]
所以即使 periodization 逐点非负，递归 Möbius 二次和也不逐点非负；
不能把这个构造误写成 PSD Gram 证书。上述数值均由有限有理和直接给出。

## 结论范围

本 note 的严格成果是一个可审计的 full \(\zeta^{-2}\) Mellin 门及其 RH
蕴含关系。它没有证明 (2)，也没有提供原始截断门的平方根估计；它把
“正 periodization 是否绕开 signed 算术难点”这一可能路线关闭为一个
明确的 RH-strength full 和命题，且将原始截断缺口定位为 note 370 的
incomplete-lcm boundary。

上游：notes 239、240、241、212。
