> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Full squarefree-divisor energy is subpower, but completion remains

## Full divisor energy bound

令 \(X\) squarefree，\(k=\omega(X)\)，并令

\[
\Phi_X(\xi)=\prod_{p\mid X}(1-p^{i\xi}).
\]

逐频有

\[
|\Phi_X(\xi)|^2
=\prod_{p\mid X}4\sin^2\!\left(\frac{\xi\log p}{2}\right)
\le 4^k.
\]

若 boundary symbol \(h\in L^1(\mathbb R)\)，则 note 186 的两个正通道满足

\[
\mathcal E_X^\pm
=\frac1{2\pi}\int h_\pm(\xi)|\Phi_X(\xi)|^2\,d\xi
\le \frac{4^{\omega(X)}}{2\pi}\|h_\pm\|_1.
\]

因此完整 squarefree divisor reciprocal form 有严格次幂上界

\[
|c_X^*H_Xc_X|
\le \frac{4^{\omega(X)}}{2\pi}\|h\|_1
=X^{o(1)}.
\]

这里最后一步只使用标准事实
\(\omega(X)=O(\log X/\log\log X)\)；所以对每个
\(\varepsilon>0\)，\(4^{\omega(X)}\ll_\varepsilon X^\varepsilon\)。

## 半格的同样粗界

对实际半格 \(L_X\)，若 \(g\) 有界，则

\[
|G_X|
\le |L_X|^2\|g\|_\infty
\le 4^{\omega(X)-2}\|g\|_\infty.
\]

结合 note 171 的恒等式
\(H_X=Q_X+2\mu(X)G_X\)，得到 squarefree \(X\) 上

\[
|Q_X|=X^{o(1)}.
\]

这个结论完全不使用 RH；它只说明完整 divisor orbit 的指数维数很低，相对于
\(X\) 是次幂规模。

## 为什么这还不是 RH

论文中的目标量

\[
T_P(x)=\sum_{a,b\le\sqrt x}\mu(a)\mu(b)\,
P\!\left(\frac{x}{ab}\right)
\]

包含所有 \(ab\le x\) 的整数对，而 \(Q_X\) 只包含 \(a,b\mid X\) 的 divisor
对；即使 \(X\) squarefree，也缺少绝大多数 \(ab\) 不整除 \(X\) 的项。

因此从 \(Q_X=X^{o(1)}\) 到
\(T_P(x)\ll_\varepsilon x^{1/2+\varepsilon}\) 之间仍有一个实质的
divisor-completion remainder。任何把这两个量直接等同的步骤都是循环的；
真正需要的新命题是一个对所有 common-scale 整数对的、保留 Möbius signed
cancellation 的 completion/intertwiner。

本 note 给出 squarefree divisor 子问题的严格次幂估计，并明确其不能自动
升级为 RH。

