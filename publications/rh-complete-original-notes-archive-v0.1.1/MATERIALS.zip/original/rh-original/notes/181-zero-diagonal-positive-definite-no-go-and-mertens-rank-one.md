> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Zero-diagonal positive-definite no-go and the Mertens rank-one repair

## 通用引理

令 \(k:\mathbb R\to\mathbb R\) 是连续、平移不变的 Hermitian
positive-definite kernel。其任意二阶主子式必须非负：

\[
\begin{pmatrix}
k(0)&k(t)\\
k(-t)&k(0)
\end{pmatrix}\succeq0,
\qquad
|k(t)|^2\le k(0)^2.
\]

因此

\[
k(0)=0\quad\Longrightarrow\quad k(t)=0\quad\text{对所有 }t.
\]

这也可由 Bochner 定理看出：正测度的总质量是 \(k(0)\)，质量为零时测度
只能为零。

## 对 endpoint-flat detector 的直接应用

设单侧 periodization \(P(y)\) 满足

\[
P(1)=0,\qquad P(2)>0,
\]

并令其中心对称的 log-kernel 为

\[
g(t)=\frac12P(e^{|t|}).
\]

则 \(g(0)=0\)，但

\[
g(\log2)=\frac12P(2)>0.
\]

所以 \(g\) 不可能是正定核。其最小反例就是

\[
\begin{pmatrix}
0&P(2)/2\\
P(2)/2&0
\end{pmatrix},
\qquad
\det=-\frac{P(2)^2}{4}<0.
\]

这不是 V15 的数值特例，而是所有满足上述两个端点条件的 detector 的结构性
障碍。因而任何声称“把实际单侧 kernel 直接识别为 ordinary Toeplitz PSD
Gram”的桥，在 \( \{1,2\}\) 这一层已经不成立。

## 常数 rank-one 修复恰好是 Mertens 模式

若把 kernel 加上常数 \(c>0\)，即

\[
\widetilde g(t)=g(t)+c,
\]

则有限系数向量 \(v=(v_a)\) 的二次型增加

\[
c\left|\sum_a v_a\right|^2.
\]

在 Möbius 截断向量 \(v_a=\mu(a)\mathbf 1_{a\le\sqrt x}\) 上，这一项正是

\[
c\,M(\sqrt x)^2,
\qquad
M(z)=\sum_{n\le z}\mu(n).
\]

所以“补一个中心常数使 Gram 变正”并没有消除算术困难；它把困难直接转成
Mertens 平方根界。若要求

\[
M(z)\ll_\varepsilon z^{1/2+\varepsilon},
\]

这已经是 RH-strength 的命题，而不是由局部 Weil 正性推出的弱补偿。

## 对当前路线的结论

允许 signed reflection、奇偶 cross block 或非平凡频率补偿是必要的；普通 PSD
Toeplitz 化和常数 rank-one 修复都已被严格排除。剩余的最小接口仍是：

\[
\text{保留 }R_X\text{-parity，并在同一 Möbius 状态上控制 signed boundary block}.
\]

本 note 是结构性 no-go，不是 RH 证明。

