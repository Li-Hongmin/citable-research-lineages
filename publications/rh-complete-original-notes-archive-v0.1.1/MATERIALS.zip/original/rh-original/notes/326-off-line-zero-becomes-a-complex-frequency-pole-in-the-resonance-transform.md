> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 离线零点在共振 Fourier 变换中变成复频率极点

日期：2026-08-16。

本 note 把 notes 285--286 的显式共振项再作一次复频率分析。结论是：
若 \(\zeta(\rho)=0\)、\(\rho=\beta+i\gamma\)、\(\beta>1/2\)，且窗口在
该点没有精确消零，则共振 Fourier 变换含有大小 \(B^\beta\) 的项。因此
把共振项压到 \(B^{1/2+\varepsilon}\) 已经是 RH-strength。

## 1. 复频率位置

固定 detector 的正向共振振幅可写成
\[
 Q_+(t)=
 \frac{K(it)\zeta(it)}{1+it}
 \frac{\zeta(1+2it)S(1+it,t)}{\zeta(1+it)^2},
\tag{1}
\]
忽略一个与归一化无关的常数；实 detector 还包含共轭方向。这里
\(K\) 是 detector 的 Mellin 乘子，\(S\) 是 notes 283--285 的 Euler 余因子。

若 \(\zeta(\rho)=0\)，则
\[
 1+it_\rho=\rho,
 \qquad
 t_\rho=-i(\rho-1)=\gamma+i(1-\beta).
\tag{2}
\]
所以当 \(\beta>1/2\) 时，\(Q_+\) 的潜在极点位于实轴上方且距离
\(1-\beta<1/2\)。对简单零点，来自 \(1/\zeta(1+it)^2\) 的极点通常为二阶；
重数只把后面的对数因子提高。

## 2. 轮廓移位的量级

令 \(\lambda=\log B\)，考虑
\[
 I_+(B)=B\int_{\mathbb R}Q_+(t)e^{i\lambda t}\,dt .
\tag{3}
\]
假设 \(Q_+\) 在包含 \(0\le\Im t\le a\) 的条带内亚纯、水平线上的增长
足以使轮廓移位成立，并且在 \(t_\rho\) 的主部不被窗口消掉。向上移动
到穿过 \(t_\rho\) 的轮廓时，留数贡献为
\[
 c_\rho B e^{i\lambda t_\rho}
   \quad\text{（简单极点），}
\]
或
\[
 c_\rho B e^{i\lambda t_\rho}\lambda^{m-1}
   \quad\text{（\(m\) 阶极点）。}
\tag{4}
\]
由 (2)，
\[
 B e^{i\lambda t_\rho}
 =e^\lambda e^{i\gamma\lambda-(1-\beta)\lambda}
 =B^\beta e^{i\gamma\log B}.
\tag{5}
\]
因此该项的量级正是 \(B^\beta\)（乘以相应的 \((\log B)^{m-1}\)）。

若实共振项还包含共轭频率，两个主项形成有限个不同相位的
\(B^\beta e^{\pm i\gamma\log B}\)。除非所有对应 residue 都精确为零，
否则其在某个序列 \(B\to\infty\) 上的绝对值仍为
\(\gg B^\beta(\log B)^{m-1}\)；有限相位和不可能对所有 \(B\) 一致抵消。

## 3. 对 (V_{15}) 的非消零检查范围

对 note 144 的 \(V_{15}\)，\(K(s)\) 的唯一显式零点在 \(s=1\)，而
在非平凡零点对应的 \(s=\rho-1\) 处没有由 detector 结构强制的零点。
此外 \(\zeta(\rho-1)\ne0\)（其位置落在临界带左侧而不属于平凡零点）。
在 \(t=t_\rho\) 处把 (4) 的每个 Euler 因子写成
\(a=p^{-\rho}\)、\(b=p^{-1}\)，可直接化简为
\[
 S_p(\rho,t_\rho)=
 \frac{(a^2-b)(b-1)\bigl((a-b)^2+b\bigr)}{b^2(a-1)^2}.
\tag{7}
\]
当 \(\beta>1/2\) 时，\(|a^2|<b\)，故第一因子不为零；若
\((a-b)^2+b=0\)，则 \(|a|^2=b^2+b>b\)，与
\(|a|^2=p^{-2\beta}<b\) 矛盾。其余因子显然不为零，且
\(S_p=1+O(p^{-2\beta}+p^{-1-\beta}+p^{-2})\)，所以 Euler 乘积
绝对收敛并且不为零。

因此在本振幅中，潜在的完全消零进一步缩小为显式因子
\(\zeta(2\rho-1)=0\)（或模型外的精确共振关系）。本 note 不假设该
因子不为零；它必须作为单独的 non-cancellation 条件核验，不能从
Bernstein 正性推出。

## 4. RH-strength 结论

在上述亚纯延拓、轮廓增长和 residue non-cancellation 条件下，若对所有
\(\varepsilon>0\) 有
\[
 I_+(B)+I_-(B)=O_\varepsilon(B^{1/2+\varepsilon}),
\tag{6}
\]
则不可能存在 \(\beta>1/2\) 的零点；否则 (5) 给出更大的
\(B^\beta\) 主项。反向地，积分分部只给任意固定的对数节省，不能把
\(B\) 降到平方根，正如 note 286 所示。

所以“共振项可通过 Fourier 振荡变小”与“共振项满足平方根界”是两个
完全不同的命题：前者是无条件的对数级现象，后者已经等价地触及 RH。
本 note 不声称 RH，也不把 non-cancellation 条件误报为已证事实。
