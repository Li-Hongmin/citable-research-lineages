> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(\operatorname{sgn}h\) 频率修正是无限程对数核

日期：2026-08-16。

本 note 把 note 330 中剩余的“跨频率 signed intertwiner”具体化为
\(\operatorname{sgn}h\) 乘法算子。结论：对当前 detector，它不是有限秩
或有限个 prime/Yukawa 原子，而是在 \(\log(a/b)\) 坐标上的长程核；因此
把 signed symbol 变成 \(|h|\) 的最直接修正并没有给出新的局部 Schur 门。

## 1. 符号修正的精确形式

令 \(h\) 为实偶连续函数，并假设 \(h\) 在两个开区间上分别取正、负值。
置
\[
 \sigma(\xi)=\operatorname{sgn}h(\xi)
\]
（零点处任意定义），并令 \(\Sigma_h\) 是 Fourier 乘法算子
\[
 \widehat{\Sigma_h f}(\xi)=\sigma(\xi)\widehat f(\xi).
\tag{1}
\]
若 \(g=\mathcal F^{-1}h\)，则形式上
\[
 \Sigma_h g=\mathcal F^{-1}|h|.
\tag{2}
\]
对有限 log-sample \(x_a=\log a\)，该修正的核为
\[
 R_h(a,b)=r_h(\log a-\log b),\qquad
 r_h(u)=\frac1{2\pi}\int_{\mathbb R}\sigma(\xi)e^{i\xi u}\,d\xi,
\tag{3}
\]
其中 (3) 按 tempered distribution 理解，因为 \(\sigma\) 通常不属于
\(L^1(\mathbb R)\)。这已经显示修正作用在比值 \(a/b\) 上，而不是有限个
divisor edge 上。

## 2. 一个符号跳变给出 \(1/u\) 长程尾

取符号改变处 \(\xi_0\)，并令 \(\chi\in C_c^\infty\) 在 \(\xi_0\) 邻域
恒等于 1。局部修正
\[
 r_{\chi}(u)=\frac1{2\pi}\int
       \chi(\xi)\sigma(\xi)e^{i\xi u}\,d\xi
\tag{4}
\]
是普通函数。若 \(\Delta\sigma=\sigma(\xi_0+)-\sigma(\xi_0-)\ne0\)，
对跳变两侧分部积分得到
\[
 r_{\chi}(u)
 =-\frac{\Delta\sigma}{2\pi i\,u}\,e^{i\xi_0u}
   +O_\chi(u^{-2}),\qquad |u|\to\infty .
\tag{5}
\]
因此任何局部 sign-flip correction 都包含不可积的 \(1/u\) 型对数长程尾。

对 \(V_{15}\) 的 boundary symbol
\[
 h_{15}(\xi)=\operatorname{Re}\{\zeta(i\xi)K_{15}(i\xi)\},
\]
已有严格 \(h_{15}(0)>0\) 与 \(h_{15}(2)<0\)（notes 174、180），故连续性
保证至少一个 sign transition；由于 \(h_{15}\) 在实轴上实解析，穿越零点时
\(\sigma\) 确实发生非零跳变。这里不需要把跳变位置数值化。

## 3. 为什么不是固定秩 Schur 补

若一个 translation-invariant convolution kernel \(r(x-y)\) 在每个紧区间上
都只有有限秩，那么其所有平移 \(r(\cdot-y)\) 张成有限维空间；有限维平移不变
函数空间只能由指数多项式组成，其 Fourier 变换是有限个点质量的组合。
而 \(r_\chi\) 的 Fourier 变换是具有非空区间支撑的
\(\chi(\xi)\sigma(\xi)\)，与此矛盾。因此 (4) 的卷积算子在 \(L^2\) 上为
无限秩；(5) 更直接给出其长程尺度。

在整数试验空间上，这意味着
\[
 (R_\chi)_{a,b}=r_\chi(\log a-\log b)
\]
不是固定数量的 prime/reflection 原子之和。对 \(a,b\asymp N\) 且
\(|a-b|\ll N\)，有
\[
 \log(a/b)=\frac{a-b}{N}+O\!\left(\frac{(a-b)^2}{N^2}\right),
\]
所以 (5) 产生 Hilbert-transform 型的宏观非局部块，而不是稀疏边界修正。

## 4. 对 RH 路线的精确含义

把原 signed symbol \(h\) 逐频率改成 \(|h|\) 的确给出正能量
\[
 \frac1{2\pi}\int |h(\xi)|\,|F_N(\xi)|^2\,d\xi,
\]
但实现这一改变的最直接 operator \(\Sigma_h\) 本身是上述无限程核。
若对该核在 Möbius 向量上证明平方根级界，就得到 note 212/246 的
正能量门，因而与 RH 等价；若只在有限个局部块上补偿，则不能实现全局
\(|h|\) 替换。

因此“符号修正”把缺口精确地移动到了：
\[
\boxed{\text{对数长程 sign-kernel 与 Möbius 向量之间的 signed arithmetic
intertwiner。}}
\]
它不是有限秩 PSD/Feshbach 问题。本文没有声称 RH；它排除了当前最直接的
有限局部修正，并给出剩余非局部对象的显式核和渐近尾。
