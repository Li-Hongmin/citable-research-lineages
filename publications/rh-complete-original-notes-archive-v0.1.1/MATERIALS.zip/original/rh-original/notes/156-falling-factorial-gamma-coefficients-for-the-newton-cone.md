> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Periodization Bernstein 系数的 falling-factorial γ 闭式

日期：2026-08-15。

本 note 把原始交替的 \(v_{m,n}\) 公式改写为另一组系数
\(\gamma_{m,h,L}\)。这组系数在 \(m\le36\) 的精确有理检查中全为非负，因而给出
比直接 \(v_{m,n}\) 求和更薄的全半轴正性接口；尚未证明任意 \(m\) 的
\(\gamma\)-正性。本有限检查由 `computations/verify_gamma_newton_cone.py` 的
`Fraction` 实现给出，覆盖 (0\le h\le 3m+1) 与全部可能非零的 (L)；不构成全
(m) 证明。

## 1. 记号

令

\[
D=3m+3,\qquad d=D-2,\qquad
 c_q:=c_{m-1,q},\quad 2\le q\le m+1,
\]

其中（见 note 155）

\[
c_q=
\frac{(2m-q)!\,q!}
{2^{m-q+2}(m-q+1)!\,(q-2)!\,\binom D2}.
\tag{1}
\]

对 \(p\ge0\) 记

\[
H_{p,h}^{(d)}(X)=
\sum_{s=0}^{\min(p,h)}
\frac{\binom ps\binom hs}{\binom ds}X^{p-s},
\tag{2}
\]

即 \((X+r)^p\) 的 degree-\(d\) Bernstein 第 \(h\) 项系数。

由 \(P_m=C_m^{-1}\sum_{q=2}^{m+1}(q+1)c_q(W_{q+1}-W_q)\) 的
\(B_{q,D}\) 展开，准确写成

\[
b_{m,h}(N)=\frac1{C_mN(N+1)}
\sum_{n=1}^{N}\sum_{q=2}^{m+1}c_q\binom Dq
\bigl((D-q)n^{q+1}H_{D-q-1,h}^{(d)}(N-n)
-(q+1)n^qH_{D-q,h}^{(d)}(N-n)\bigr)
\tag{3}
\]

式 (3) 是便于展开的逐项恒等式。

## 2. 完整 γ 公式

令 \(\left\{\begin{smallmatrix}r\\a\end{smallmatrix}\right\}\) 为第二类
Stirling 数，定义

\[
\mathcal F_{r,t}(M):=
\sum_{a+b=M}
\left\{\begin{matrix}r\\a\end{matrix}\right\}
\left\{\begin{matrix}t\\b\end{matrix}\right\}a!b!.
\tag{4}
\]

利用

\[
n^r=\sum_a\left\{\begin{matrix}r\\a\end{matrix}\right\}n^{\underline a},
\qquad
(N-n)^t=\sum_b\left\{\begin{matrix}t\\b\end{matrix}\right\}(N-n)^{\underline b},
\tag{5}
\]

以及 Vandermonde 恒等式

\[
\sum_{n=0}^{N}n^{\underline a}(N-n)^{\underline b}
=a!b!\binom{N+1}{a+b+1},
\tag{6}
\]

可得

\[
b_{m,h}(N)=\frac1{C_m}
\sum_{L\ge0}\gamma_{m,h,L}(N-1)^{\underline L},
\tag{7}
\]

其中（约定 \(\mathcal F_{r,t}(M)=0\) 当 \(M\) 超出范围）

\[
\boxed{
\begin{aligned}
\gamma_{m,h,L}={1\over(L+2)!}
\sum_{q=2}^{m+1}c_q\binom Dq\Bigg\{
\sum_{s=0}^{\min(D-q-1,h)}
{\binom{D-q-1}s\binom hs\over\binom ds}
\Big[(D-q)\mathcal F_{q+1,D-q-1-s}(L+1)
-(q+1){D-q\over D-q-s}
\mathcal F_{q,D-q-s}(L+1)\Big]
\\[-1mm]
-\mathbf 1_{h\ge D-q}(q+1)
{\binom h{D-q}\over\binom d{D-q}}
\mathcal F_{q,0}(L+1)\Bigg\}.
\end{aligned}}
\tag{8}
\]

这里使用了
\(\binom{D-q}{s}=\frac{D-q}{D-q-s}\binom{D-q-1}{s}\)，将两项的共同因子
提取出来。所有 \(L=-1\) 项严格为零；这是因为 \(q\ge2\) 且两端点在原始
Beta 因子中消失。

再由

\[
(N-1)^{\underline L}=L!\left[
\binom{N-2}{L}+\binom{N-2}{L-1}\right]
\quad(L\ge1),
\tag{9}
\]

\(\gamma_{m,h,L}\ge0\) 对所有 \(h,L\) 是一个强的 manifest Newton 证书：它
立即推出所有 \(a_{m,h,j}=(\Delta_N^jb_{m,h})(2)\ge0\)。

## 3. 已验证范围与剩余命题

按 (8) 用整数 Stirling 数和有理算术计算，\(m=1,\ldots,55\) 的全部
\(0\le h\le d\)、\(L\) 系数均非负；其中 \(m=44,\ldots,55\) 使用本机最多 8 个并行进程复核。计算只用于核对恒等式和有限层证书，不能外推为全 \(m\) 定理。
当前尚未找到将方括号中的两项，利用 (1) 的反向 Bessel 权重，逐项改写为
非负和的全 \(m\) 组合恒等式。逐项正化在最小层就失败：

\[
m=1,\quad D=6,\quad h=2,\quad L=1,\quad q=2,\quad s=2
\]

时，方括号中的单项为 \(-2\)，但同一层的完整 \(q,s\) 和（含边界项）仍为
非负。因此证明不能逐 \((q,s)\) 取绝对值；必须在完整 \(q\)-和中做消去/重排。

一个便于继续重排的精确化简是

\[
c_q\binom Dq
=
\frac{D!(2m-q)!}
{2^{m-q+2}(m-q+1)!(q-2)!(D-q)!\binom D2},
\]

并令

\[
A_r(x)=\sum_a\left\{\begin{smallmatrix}r\\a\end{smallmatrix}\right\}a!x^a,
\qquad
\mathcal F_{r,t}(M)=[x^M]A_r(x)A_t(x).
\]

核心差项可写为
\[
(D-q)\left[
\mathcal F_{q+1,t}(L+1)-\frac{q+1}{t+1}
\mathcal F_{q,t+1}(L+1)
\right],
\qquad t=D-q-1-s.
\]
恒等式
\(A_{r+1}=x(1+x)A_r'+xA_r\) 给出进一步重排入口，但尚未产生全系数非负式。

因此最小未闭合命题是

\[
\boxed{\gamma_{m,h,L}\ge0
\quad\text{for all }m\ge1,\;0\le h\le3m+1,\;L\ge0.}
\]

即使这个纯算术系数锥最终闭合，Möbius signed quadratic form 的平方根级
抵消仍是独立的 RH-strength 门。

## 4. q-shift 后的单和接口（仍未正化）

把 (8) 中第二个 Stirling 卷积项作 (qmapsto q-1) 平移，并把
(s=D-q) 的边界项一并保留，可得到一个更薄的精确表示。令

\[
 E_{r,h}(x):=\sum_{s\ge0}
 \frac{\binom rs\binom hs}{\binom ds}A_{r-s}(x),
 \qquad
 A_r(x):=\sum_a\left\{\begin{matrix}r\\a\end{matrix}\right\}a!x^a .
\]

若 (M=L+1)、(w_q=c_q\binom Dq)，则 (8) 的大括号总和严格等于

\[
 [x^M]\sum_{q=1}^{m+1}K_q A_{q+1}(x)E_{D-q-1,h}(x),
\tag{10}
\]

其中

\[
 K_1=-3w_2,
 \quad K_q=w_q(D-q)-w_{q+1}(q+2)\quad(2\le q\le m),
 \quad K_{m+1}=w_{m+1}(D-m-1).
\tag{11}
\]

对 \(2\le q\le m\)，还可写成

\[
 K_q=w_q(D-q)\,
 \frac{q^2+3q-6m-4}{(2m-q)(q-1)} .
\tag{12}
\]

末项 \(K_{m+1}=w_{m+1}(D-m-1)\) 单独由式 (11) 给出；特别是
\(m=1,q=m+1=2\) 时式 (12) 的分母为零。总体上 \(K_q\) 在低 \(q\)
段为负、高 \(q\) 段为正；不能逐项使用正性。
另一方面，(E) 的指数生成函数有如下精确的超几何积分表达（注意由
\(\binom rs\) 的指数生成函数产生的 \(1/s!\) 因子）：

\[
 \sum_{r\ge0}E_{r,h}(x)\frac{t^r}{r!}
 =\frac{d+1}{1-x(e^t-1)}
 \int_0^1(1-u)^d
 {}_1F_1\!\left(-h;1;-\frac{ut}{1-u}\right)du .
\tag{13}
\]

对 \(x,t\ge0\)，被积的超几何多项式系数非负；但截至目前，
尚未找到把 (10) 的完整 (q)-和重排成全系数非负形式的证明。故 (10)--(13)
只是严格接口，不改变“全 (m) gamma 正性”仍未闭合的状态。
