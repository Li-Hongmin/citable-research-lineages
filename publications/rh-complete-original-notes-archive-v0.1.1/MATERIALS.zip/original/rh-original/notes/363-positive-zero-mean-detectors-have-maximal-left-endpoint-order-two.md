> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 非负零均值 detector 的左端阶数至多为二

日期：2026-08-16。

## 定理

令 \(V\not\equiv0\) 为 \((0,1)\) 上的 piecewise-\(C^3\) detector，满足

\[
 V(u)=O(u^p)\quad(u\downarrow0),\qquad p>2,
\]

\[
 V(u)=O((1-u)^q)\quad(u\uparrow1),\qquad q>2,
\qquad \int_0^1V(u)\,du=0.
\]

定义 reciprocal periodization

\[
 P_V(y):=\sum_{n\le y}V(n/y),\qquad y\ge1.
\]

则 \(P_V\) 不可能在整个 \([1,\infty)\) 上非负。

## 证明

对当前多项式/有限端点展开类，端点广义 Euler--Maclaurin 展开给出：对任意

\[
 2<\delta<\min(3,p,q),
\]

\[
 P_V(y)=O_{V,\delta}(y^{-\delta}).
\tag{1}
\]

因此

\[
 I_V(s):=\int_1^\infty P_V(y)y^{-s-1}\,dy
\]

在 \(\Re s>-\delta\) 全纯，特别是在 \(s=-2\) 处收敛。另一方面，
\(V(u)=O(u^p)\) 且 \(p>2\) 保证 Mellin 变换

\[
 K_V(s):=\int_0^1V(u)u^{s-1}\,du
\]

在 \(s=-2\) 解析有限。

在 \(\Re s>1\) 逐项换元（零均值已用于 (1) 的衰减），得到

\[
 I_V(s)=\zeta(s)K_V(s).
\tag{2}
\]

两侧在 \(\Re s>-\delta\) 的公共解析延拓中相等，故

\[
 I_V(-2)=\zeta(-2)K_V(-2)=0.
\tag{3}
\]

若 \(P_V\ge0\)，则 \(I_V(-2)=\int_1^\infty P_V(y)y\,dy\ge0\)。而且
\(P_V\not\equiv0\)：否则 (2) 在 \(\Re s>1\) 会迫使 \(K_V\equiv0\)，由
Mellin 唯一性得到 \(V=0\)，矛盾。因此

\[
 \int_1^\infty P_V(y)y\,dy>0,
\]

与 (3) 矛盾。

## 对 detector 设计的含义

当前 \(V_m\) 的左端 \(u^2\) 不是偶然选择，而是全半轴正性与零均值
允许的最大端点阶数。任何试图通过 \(u^3\)、\(u^4\) 或更高左端 jet
把 Mellin 频率权做得更窄的 detector，若仍要求 periodization 全面非负，
都会在 zeta 的平凡零点 \(s=-2\) 处立即失败。

这也解释了 note 140 中高阶 Beta detector 的负 Mellin moment：该负性
不是 Beta 族的偶然现象，而是 endpoint order \(>2\) 的普适障碍。
