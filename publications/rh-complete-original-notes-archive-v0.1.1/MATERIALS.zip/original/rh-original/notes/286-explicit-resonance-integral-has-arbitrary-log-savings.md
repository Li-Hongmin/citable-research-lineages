> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 显式共振项的频率积分具有任意固定阶对数节省

日期：2026-08-16。

本 note 只估计 notes 284--285 中已经显式扣出的
\(s=1\pm it\) 共振项，不把它与 renormalized 余项或 half-lattice cutoff
混淆。结论是：只要频率振幅具有有限阶 \(L^1\) 导数，该共振项本身
可通过积分分部得到任意固定阶的 \((\log B)^{-r}\) 节省。

## 1. 共振项的标准形式

令
\[
R_+(t)=
\frac{\zeta(1+2it)S(1+it,t)}{\zeta(1+it)^2},
\qquad
R_-(t)=\overline{R_+(t)},
\]
并令 \(h\) 为实际 detector 的实频率核。Perron 主项的形式为
\[
\mathcal R_B
 =\frac{B}{2\pi}\int_{\mathbb R}h(t)
 \left(
 \frac{R_+(t)}{1+it}B^{it}
 +\frac{R_-(t)}{1-it}B^{-it}
 \right)dt .
\tag{1}
\]
把
\[
Q(t):=h(t)\frac{R_+(t)}{1+it},
\qquad \lambda:=\log B,
\]
则实对称性给出
\[
\mathcal R_B=\frac{B}{\pi}\Re\int_{\mathbb R}Q(t)e^{i\lambda t}\,dt.
\tag{2}
\]

注意 \(R_+(t)\) 在 \(t=0\) 的奇异性是可去的：由 zeta 的 Laurent 展开
\[
R_+(t)=\frac{it}{2}+O(t^2).
\tag{3}
\]
所以 \(Q\) 在零频连续，且 \(Q(0)=0\)（当前 detector 的 \(h(0)\) 有限）。

## 2. 一般 Fourier--Sobolev 引理

若对某个整数 \(r\ge1\)，\(Q\in W^{r,1}(\mathbb R)\)，并且
\(Q^{(j)}(t)\to0\) 于 \(|t|\to\infty\)（\(0\le j<r\)），则重复积分分部得到
\[
\int_{\mathbb R}Q(t)e^{i\lambda t}\,dt
 =(-i\lambda)^{-r}
 \int_{\mathbb R}Q^{(r)}(t)e^{i\lambda t}\,dt,
\]
从而
\[
\boxed{
 |\mathcal R_B|
 \le \frac{B}{\pi(\log B)^r}\,\|Q^{(r)}\|_{L^1}.
}
\tag{4}
\]
这里不需要使用 \(Q(0)=0\)；全实轴积分的边界项在无穷远消失。

## 3. 对当前 (V_{15}) detector 的适用性

当前 \(h(t)=\Re[\zeta(it)K_{15}(it)]\)，其中
\(K_{15}(it)=O(|t|^{-10})\)。标准垂直线估计给出，对任意固定整数
\(j,r\)，\(\partial_t^j\zeta(it)\) 至多有
\(|t|^{1/2+o(1)}(\log(2+|t|))^r\) 的增长；残余 Euler 乘积
\(S(1+it,t)\) 及其任意固定阶 \(t\)-导数在 \(\Re s=1\) 上局部一致有界，
而 \(1/\zeta(1+it)\) 只产生对数级因子。结合 (3)，对任意固定 \(r\) 有
\[
Q^{(r)}\in L^1(\mathbb R).
\tag{5}
\]
因此共振主项满足
\[
\mathcal R_B=O_r\!\left(\frac{B}{(\log B)^r}\right)
\qquad(r\text{ 任意固定整数}）。
\tag{6}
\]
这只是显式极点贡献的估计；它没有估计 Perron 余项，也没有估计
renormalized 系数 \(b_X(t)\) 的部分和。

## 4. 对剩余 RH 门的定位

结合 note 285，完整 boundary 聚合可形式地写成
\[
\text{boundary aggregate}
 =\mathcal R_B
 +\frac1{2\pi}\int h(t)\sum_{X\le B}b_X(t)\,dt.
\tag{7}
\]
式 (6) 说明显式 \(s=1\pm it\) 共振本身不会成为平方根尺度的主障碍；
它可以用频率积分分部压到任意固定对数次幂。真正承重的是第二项：

1. 需要控制 renormalized channel 在 \(t\) 上的 signed 交叉项；
2. 需要把完整 divisor blocks 与原始 half-lattice cutoff 对接；
3. 不能把 (6) 误读成整个 boundary aggregate 的平方根估计。

因此当前跨频率路线的最小新命题已经从“处理显式共振”收缩为
renormalized/cutoff intertwiner；本 note 不声称 RH。

