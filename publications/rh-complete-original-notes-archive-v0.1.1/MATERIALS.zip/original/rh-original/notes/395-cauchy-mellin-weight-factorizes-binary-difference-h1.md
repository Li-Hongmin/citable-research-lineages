> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cauchy Mellin 权下的二进制差分 \(H^1\) 因子化

本 note 给出增长二进制滤波器的一个精确正能量表示。它不估计该能量，
但把原始 Mellin 双和转成对数坐标上的高阶平移差分。

## 1. Cauchy 权与 reciprocal 核

取
\[
w_C(t)=\frac{2}{1+t^2}.
\]
由 Fourier 反演
\[
\frac1{2\pi}\int_{\mathbb R}w_C(t)e^{itu}\,dt=e^{-|u|}.
\tag{1}
\]
对任意有限实系数列 \(c_n\)，令
\[
F_c(t)=\sum_n c_n n^{it},
\qquad
Q(c):=\sum_{m,n}c_m c_n
e^{-|\log(m/n)|}.
\]
则
\[
\int_{\mathbb R}w_C(t)|F_c(t)|^2\,dt=2\pi Q(c).
\tag{2}
\]

令对数坐标中的有限测度
\[
f_c=\sum_n c_n\,\delta_{\log n},
\qquad
u_c(x)=\int e^{-|x-y|}\,df_c(y)
=\sum_n c_n e^{-|x-\log n|}.
\]
分布恒等式
\[
(1-\partial_x^2)e^{-|x-y|}=2\delta_y
\]
以及 \(u_c(\pm\infty)=0\) 给出
\[
Q(c)=\frac12\int_{\mathbb R}
\bigl(|u_c'(x)|^2+|u_c(x)|^2\bigr)\,dx.
\tag{3}
\]
因此
\[
\boxed{
\int_{\mathbb R}w_C(t)|F_c(t)|^2\,dt
=\pi\|u_c\|_{H^1(\mathbb R)}^2.}
\tag{4}
\]

## 2. 二进制滤波器是平移差分

令
\[
A_q(t)=(1-2^{it})^q,
\qquad
F_X(t)=\sum_{n\le X}\mu(n)n^{it}.
\]
其系数列 \(b_{q,X}\) 满足 note 393 式 (4)，并且
\[
f_{b_{q,X}}
=f_{\mu,X}*(\delta_0-\delta_{\log2})^{*q}.
\]
令 \(\tau_a u(x)=u(x-a)\)。卷积与 \(e^{-|\cdot|}\) 核交换，故
\[
u_{b_{q,X}}
=(I-\tau_{\log2})^q u_{\mu,X},
\tag{5}
\]
其中
\[
u_{\mu,X}(x)
=\sum_{n\le X}\mu(n)e^{-|x-\log n|}.
\]
结合 (4)，得到精确恒等式
\[
\boxed{
\int_{\mathbb R}w_C(t)
|A_q(t)F_X(t)|^2\,dt
=
\pi\left\|(I-\tau_{\log2})^q u_{\mu,X}\right\|_{H^1}^2.}
\tag{6}
\]

## 3. 与 Mertens 函数的直接表示

对 \(x\in\mathbb R\)，把 \(y=e^x\)。有限和可分成
\[
u_{\mu,X}(x)
=e^{-x}\sum_{n\le\min(X,y)}n\mu(n)
+e^x\sum_{\min(X,y)<n\le X}\frac{\mu(n)}n.
\tag{7}
\]
所以 \(u_{\mu,X}\) 是加权 Mertens 阶梯的双向指数平滑；
(5) 只是它在 log-scale 上的高阶 dyadic difference，而不是一个新的
独立算术序列。

若对某个 \(q=q(X)\) 能证明右端
\[
\left\|(I-\tau_{\log2})^q u_{\mu,X}\right\|_{H^1}^2
\ll_\varepsilon X^{1+\varepsilon},
\tag{8}
\]
则这是一个正能量门。对固定 \(q\)，它仍包含零频正质量；由 note 246
的最大点 Abel 引理，相应的统一截断估计是 RH-strength。对临界增长
\(q\asymp\log X/\log\log X\)，(8) 不再由固定阶最大点引理直接反演，
但 note 393--394 已将其剩余内容精确化为高阶 dyadic signed difference
及折点边界的联合估计。

## 结论

式 (6) 是一个可复用的跨尺度算术接口：
增长 Mellin 滤波器等价于对数坐标平滑 Mertens 阶梯的高阶平移差分。
它把“正频谱”与“保留符号的跨尺度差分”放进同一 \(H^1\) 能量中；
但当前没有无条件的 (8) 估计。该恒等式本身不构成 RH 证明。
