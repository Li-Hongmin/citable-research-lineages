> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 完整 boundary 的固定频率渐近只剩经典零自由区余项

日期：2026-08-16。

沿用 notes 283--286 的
\[
 a_X(t)=\mu(X)|\Phi_X(t)|^2,
 \qquad
 L(s,t)=\sum_Xa_X(t)X^{-s}
 =\frac{\zeta(s-it)\zeta(s+it)}{\zeta(s)^2}S(s,t),
\]
其中 \(X\) 遍历平方自由整数。此 note 只处理固定 \(t\ne0\)，不把固定频率
结果误读为实际 detector 的统一频率估计。

## 固定频率命题

对每个固定实数 \(t\ne0\)，令
\[
 R_+(t)=\frac{\zeta(1+2it)S(1+it,t)}{\zeta(1+it)^2},
 \qquad R_-(t)=\overline{R_+(t)}.
\]
则经典 zeta 零自由区与 Perron 轮廓给出
\[
\boxed{
 \sum_{X\le B}a_X(t)
 =\frac{R_+(t)}{1+it}B^{1+it}
  +\frac{R_-(t)}{1-it}B^{1-it}
  +O_t\!\left(
   B\exp\{-c_t(\log B)^{3/5}(\log\log B)^{-1/5}\}
  \right).
 }
\tag{1}
\]
这里常数和 \(c_t>0\) 允许依赖固定 \(t\)。不需要假设 RH。

## 轮廓理由

取截断高度
\[
 T=\exp\{(\log B)^{3/5}(\log\log B)^{-1/5}\}
\]
（改变常数不影响结论），并把 Perron 线移到 zeta 的经典零自由区
\[
 \Re s\ge
 1-\frac{c}{(\log(3+|\Im s|))^{2/3}
                   (\log\log(3+|\Im s|))^{1/3}}.
\]
\(1/\zeta(s)^2\) 在该区域有标准对数级上界；固定 \(t\) 时
\(\zeta(s\pm it)\) 只增加多项式/对数级垂直线因子，\(S(s,t)\) 在
\(\Re s>1/2+\eta\) 局部一致全纯。轮廓经过 \(s=1\pm it\) 时取出
相应两个 residue，分别为 (1) 中的两项。竖线、水平线和 Perron 截断误差
由上述 \(T\) 与零自由区平衡，均吸收到 (1) 的 stretched-log 余项中。

这是固定 \(t\) 的标准 Perron 推导；它不移动轮廓穿过临界带内的未知零点，
所以不能据此推出 RH 或其反命题。

## 与零频和频率积分的关系

在 \(t=0\) 时，\(|\Phi_X(0)|^2=0\)（除 \(X=1\) 外），故
\[
 \sum_{X\le B}a_X(0)=1,
\]
与 \(R_+(t)\sim it/2\) 的共振合并极限一致。对固定非零 \(t\)，(1) 说明
显式 \(B^{1\pm it}\) 主项是全部接近 \(B\) 尺度的可见贡献；note 286
已经证明它们在足够光滑的频率积分中可获得任意固定阶对数节省。

因此当前完整 boundary 聚合的剩余问题精确分成两项：

1. 将 (1) 的余项估计做成对 \(t\) 的统一估计，并与 detector 的频率尾相容；
2. 把完整 squarefree block 聚合与原始 half-lattice cutoff 的 completion
   remainder 以 signed 方式配对。

固定频率的经典零自由区本身只能给 stretched-log，而不能给
\(B^{1/2+\varepsilon}\)。故 (1) 是一个严格的路线收缩，不是 RH 证明。
