> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 首次退化下 rank-one/PF 刚性的极限

日期：2026-08-11。

本文检验首次退化、严格 crossing、约化 positivity improving、奇偶谱隙及 rank-one inertia 是否
足以强迫零模态可见且只出现于一个扇区。两个四维反例给出否定答案，并确定能一次选出唯一扇区的
最薄新增符号命题。

## 1. 不可见首次零核反例

在 (mathbb R^4) 中取正交基

\[
\varphi=\tfrac12(1,1,1,1),\quad
\psi=\tfrac12(1,1,-1,-1),
\]

\[
h=\tfrac12(1,-1,1,-1),\quad
k=\tfrac12(1,-1,-1,1).
\]

令偶空间为 (operatorname{span}\{\varphi,\psi\})，奇空间为
(operatorname{span}\{h,k\})，并定义

\[
M_*\varphi=-\varphi,
\quad M_*\psi=2\psi,
\quad M_*h=3h,
\quad M_*k=0.
\]

取 (c=\varphi)、(s=h)。在标准正锥基下，(M_*) 的非对角元非正且耦合图连通，故
\(e^{-tM_*}\) positivity improving；其唯一基态为严格正偶向量 \(\varphi\)，且

\[
\mu_1(M_*^+)=-1<0=\mu_1(M_*^-).
\]

令

\[
A_*^+=M_*^++2|c\rangle\langle c|,
\qquad
A_*^-=M_*^--2|s\rangle\langle s|.
\]

则

\[
\sigma(A_*^+)=\{1,2\},
\qquad
\sigma(A_*^-)=\{0,1\},
\]

且

\[
\boxed{
\ker A_*^-=\ker M_*^-=\operatorname{span}\{k\}\subset s^\perp.}
\tag{1}
\]

令 \(\tau=a_*-a\)，并置

\[
M_a=M_*+\tau I,
\qquad A_a=A_*+\tau I.
\]

则

\[
A_a>0\ (a<a_*),
\qquad A_{a_*}\succeq0,
\qquad \lambda_1(A_a)<0\ (a>a_*),
\]

而首次零核仍为 (1)。加标量不改变 positivity improving、基态奇偶性或严格扇区谱隙；零向量
(k) 的四个标准坐标均非零。因此，即使再加入唯一首次尺度、严格 crossing 和有限维版本的
collar 非支撑条件，完全不可见核仍然存在。

## 2. 双扇区同时可见退化反例

仍用上述基，改令

\[
M\varphi=-2\varphi,
\quad M\psi=2\psi,
\quad Mh=2h,
\quad Mk=3k,
\qquad c=\varphi,
\quad s=h.
\]

在标准基下，(M) 的非对角元严格非正且图连通，故仍 positivity improving，并有严格扇区谱隙
(-2<2)。然而

\[
\ker A^+=\operatorname{span}\{\varphi\},
\qquad
\ker A^-=\operatorname{span}\{h\}.
\tag{2}
\]

两个核都与相应 polar vector 可见。再加 \(\tau I\) 即得到在同一首次尺度双扇区同时退化、随后
立即变负的一参数族。

所以 zero-cyclicity

\[
\ker M^+\cap c^\perp=\{0\},
\qquad
\ker M^-\cap s^\perp=\{0\}
\tag{3}
\]

只能把退化压成两个 Schur 标量方程，不能选择唯一扇区。

## 3. 现有输入的最大结论

首次退化时，现有抽象结构只能推出：

1. (M^-\succeq0)，且 (ker M^-=\ker A^-\cap s^\perp)；除不可见核外至多有一个奇 Schur
   零模态。
2. (M^+) 恰有一个负方向，且 (c\perp\ker M^+)；不可见偶零模态与严格正基态正交，因而
   必须变号。除不可见核外至多有一个偶 Schur 零模态。
3. Perron--Frobenius 只控制 (M) 的全局最低本征函数，不能控制零能级的维数、节点或半区符号。

因此不能仅由这些输入推出首次零核一维、秩一可见或扇区唯一。

## 4. 一次选出唯一扇区的条件在真实尺度上不可能成立

若在首次尺度 \(a_*\) 能独立证明

\[
\boxed{\mu_1(M_{a_*}^+)\ge0,}
\tag{4}
\]

则 reduced ground-state 简单性和正性使 \(A_{a_*}^+>0\)，严格奇偶谱隙又给
\(M_{a_*}^->0\)。任何首次零模态只能来自奇扇区的可见 Schur 等号

\[
1-2\langle s,(M_{a_*}^-)^{-1}s\rangle=0,
\]

且核一维，由 \((M_{a_*}^-)^{-1}s\) 张成。

但真实算子不只缺少 (4)，而是已经严格违反它。note 028 给出任何首次尺度满足

\[
a_*>\frac12\log5>\frac18,
\]

而 note 013 已证明

\[
\mu_1(M_a^+)<0
\qquad\left(a\ge\frac18\right).
\]

因此 (4) 在真实首次尺度不可能成立，不能用来选择唯一奇扇区。项目被强制进入双扇区路线：分别
证明 (3) 的 zero-cyclicity，然后分别控制偶、奇两个 Schur 标量。不能再用抽象基态理论跳过
其中任一扇区。
