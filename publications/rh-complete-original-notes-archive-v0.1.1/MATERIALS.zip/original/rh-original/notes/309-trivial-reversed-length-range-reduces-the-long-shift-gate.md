> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 长移位的反向长度小区间可平凡闭合

日期：2026-08-16。

对平方恒等式中的长移位 \(h>X/2\)，令
\[
u=X-h<X/2,\qquad
R_U(X)=\sum_{U<u\le2U}C_{X-u}^{\rm end}(X),
\]
其中
\[
C_{X-u}^{\rm end}(X)=\sum_{n\le u}f(n)f(n+X-u),
\qquad |f(n)|\le1.
\]
逐个 \(u\) 使用绝对值即可得到
\[
\left|C_{X-u}^{\rm end}(X)\right|\le u,
\qquad
|R_U(X)|\le\sum_{U<u\le2U}u\ll U^2.
\tag{1}
\]

固定 \(\delta\in(0,1)\)，令
\[
U_0=X^{(1+\delta)/2}.
\]
对所有 \(U\le U_0\) 的 dyadic 反向长度求和，几何级数给出
\[
\sum_{U\le U_0}|R_U(X)|
\ll U_0^2
\ll X^{1+\delta}.
\tag{2}
\]
这完全不使用 Möbius/Liouville cancellation；它是平方恒等式层面的严格边界。

因此，在目标 \(S_f(X)^2\ll X^{1+\varepsilon}\) 中，长移位部分只剩下
\[
X^{(1+\delta)/2}<u<X/2
\]
的反向长度块。对这些块，需要控制
\[
\sum_{U\ {\rm dyadic}}
\left|\sum_{U<u\le2U}
\sum_{n\le u}f(n)f(n+X-u)\right|
\]
到 \(X^{1+\varepsilon}\) 量级；逐项平凡界只给 \(O(X^2)\)。

这与外部 Liouville-collar 文献的 reversed-length 条件相容，但严格指出了
其低反向长度部分并不是承重门：低于 \(X^{1/2+o(1)}\) 的反向长度可直接丢入
误差。结合 note 306，终端区的 maximal 相关假设可进一步缩短；剩余仍是
宏观反向长度上的 signed correlation/intertwiner，而非一个端点技术问题。

结论不是 RH 证明，只是对长移位门的无条件区间切分。
