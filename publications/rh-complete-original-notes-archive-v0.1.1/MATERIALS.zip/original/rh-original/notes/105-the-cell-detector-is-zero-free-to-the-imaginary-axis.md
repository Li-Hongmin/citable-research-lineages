> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 首个 cell detector 零自由直到虚轴，但有限联合滤波仍只给负阶 frame

日期：2026-08-14。

依赖：
[note 094](094-k1-a2-high-divisor-cell-has-a-zero-free-mellin-detector.md)、
[note 102](102-atom-free-scale-smoothing-has-no-bounded-mellin-l2-inverse.md)、
[note 104](104-log-dilation-gram-has-explicit-mellin-null-modes.md)。

证据等级：解析恒等式、Arb 辐角原理证书、显式 Mellin frame
上下界和有限离散共同近零族。

本文完成两个互补判定。第一，note 094 的 Mellin detector 实际在闭带
\(0\le\Re s\le1\) 上零自由。第二，这一强化虽消除了有限多个
log-dilation 滤波器的公共精确 detector 零，却不能恢复 raw \(L^2\)
coercivity；两个 badly-approximable 尺度的尖锐正结论只是一个
quotient 型 hybrid \(H^{-2}\) frame。

## 1. detector 的闭带零自由性

沿用 note 094 的

\[
F(t)=\log\frac1t
\left(\frac2{\pi t}+\sin2\pi t\right)
\mathbf1_{(2/3,1)}(t),
\tag{1}
\]

\[
K(s)=\int_{2/3}^1F(t)t^{s-1}\,dt.
\tag{2}
\]

令

\[
\alpha=-\log(3/2),\qquad
d(x)=-x\left(\frac2\pi+e^x\sin(2\pi e^x)\right).
\tag{3}
\]

则

\[
K(s)=\int_\alpha^0d(x)e^{(s-1)x}\,dx.
\tag{4}
\]

### 定理 1

\[
\boxed{
K(s)\ne0\qquad(0\le\Re s\le1).
}
\tag{5}
\]

**紧部。**
将 note 094 的 Arb contour 左边从 \(\Re s=1/2\) 移到
\(\Re s=0\)。在

\[
0\le\Re s\le1,\qquad 0\le\Im s\le75
\tag{6}
\]

上，完整闭轮廓的每个 ACB segment image 均严格避开零，最小模下界为

\[
8.6171033986810568\cdot10^{-5}.
\tag{7}
\]

总辐角的 winding ball 包含且唯一确定整数 \(0\)，所有 segment 均已解析，
没有 unresolved box。因 \(K\) 是整函数，辐角原理证明 (6) 内部无零，
而 (7) 同时排除边界零。

**尾部。**
写 \(\lambda=s-1\)，并对 (4) 作十二次分部积分。承重归一化不是单独的
\(\lambda K(s)\)，而是

\[
\lambda e^{-\lambda\alpha}K(s).
\tag{8}
\]

其首项为 \(-d(\alpha)\)。当 \(\Re s\le1\) 时，

\[
|e^{-\lambda\alpha}|\le1,\qquad
|e^{\lambda(x-\alpha)}|\le1
\quad(\alpha\le x\le0).
\tag{9}
\]

所以原 endpoint derivative 和 derivative-\(L^1\) 余项界对新增的
\(0\le\Re s<1/2\) 无需放大。又

\[
|s|\ge75\Longrightarrow|\lambda|\ge74.
\tag{10}
\]

严格区间界给出

\[
|d(\alpha)|\ge
0.0240317155135669510640097448030639621\ldots,
\tag{11}
\]

\[
\text{remainder}\le
0.0238451463867064075904144654201694542\ldots,
\tag{12}
\]

余量

\[
1.8656912686054347\cdot10^{-4}>0.
\tag{13}
\]

这排除 (5) 中 \(|s|\ge75\) 的全部零。最后
\(K(\bar s)=\overline{K(s)}\) 补全下半平面。证书、源码与重放命令见
[proof bundle](../computations/bundles/k1-a2-mellin-zero-free/README.md)。

特别地，

\[
\boxed{K(it)\ne0\quad(t\in\mathbb R).}
\tag{14}
\]

## 2. 两个不共振尺度的精确负阶 frame

令 \(L=\log R\)。log-uniform dilation 的导数滤波器在虚轴上的 Mellin
符号为

\[
m_L(t)=K(it)\frac{1-e^{itL}}{L}.
\tag{15}
\]

取

\[
L_1=1,\qquad L_2=\sqrt2,
\tag{16}
\]

并定义

\[
\mathcal M_2(t)
=\left(|m_1(t)|^2+|m_{\sqrt2}(t)|^2\right)^{1/2},
\tag{17}
\]

\[
\omega_2(t)=\frac{|t|}{(1+|t|)^3}.
\tag{18}
\]

### 定理 2

存在绝对常数 \(c>0\)，使

\[
\boxed{
\mathcal M_2(t)\ge c\,\omega_2(t)
\qquad(t\in\mathbb R).
}
\tag{19}
\]

**证明。**
在 \(t=0\) 附近，(14) 与 Taylor 展开给出

\[
\mathcal M_2(t)\asymp|K(0)|\,|t|.
\tag{20}
\]

另一方面，\(x\mapsto F(e^x)\) 在 \(x=\alpha\) 有唯一非零 jump，
其余分布导数属于 \(L^1\)。Riemann--Lebesgue 引理遂给

\[
|tK(it)|\longrightarrow |\kappa|>0
\qquad(|t|\to\infty),
\tag{21}
\]

其中 \(\kappa=F((2/3)+)\)。

\(\sqrt2\) 的 badly-approximable 性质给出

\[
\left(
|1-e^{it}|^2+
\frac12|1-e^{i\sqrt2t}|^2
\right)^{1/2}
\gg \min\{|t|,|t|^{-1}\}.
\tag{22}
\]

确切地说，若 \(t\) 不接近 \(2\pi\mathbb Z\)，第一项已有所需下界；
若 \(t=2\pi q+O(|t|^{-1})\)，则
\(\|q\sqrt2\|_{\mathbb R/\mathbb Z}\gg q^{-1}\) 控制第二项。
由 (14)，紧集 \(0<|t|\le T\) 上没有额外公共零。合并
(20)--(22) 即得 (19)。\(\square\)

由 Mellin--Plancherel，对适当测试函数 \(h\)，(19) 等价于

\[
\sum_{j=1}^2\|\mathcal T_{L_j}h\|_2^2
\ge c^2\int_{\mathbb R}
\omega_2(t)^2|\widehat h(t)|^2\,dt.
\tag{23}
\]

右端近 \(t=0\) 像一阶齐次 quotient seminorm，高频则像 \(H^{-2}\)。
它不是 raw \(L^2\) 范数，也不是非齐次 \(H^{-2}\) 范数。

## 3. 任意固定有限联合仍无 raw coercivity

更一般地，固定 \(R_1,\ldots,R_J>1\)，置

\[
R_*=\max_jR_j,\qquad
D=(2/3,2R_*).
\tag{24}
\]

对共同 log-wave

\[
q_\xi(u)=u^{i\xi}\mathbf1_D(u)
\tag{25}
\]

减去其在 \(D\) 上的均值。每个滤波器都杀死常数，所以中心化不改变输出。
又因 \(F(e^\cdot)\in BV_c(\mathbb R)\)，

\[
|K(i\xi)|\ll_F|\xi|^{-1}.
\tag{26}
\]

故

\[
\boxed{
\frac{\sum_{j=1}^J\|\mathcal T_{R_j}q_\xi\|_2^2}
{\|q_\xi-\operatorname{mean}_Dq_\xi\|_2^2}
\ll_{R_1,\ldots,R_J}\xi^{-2}.
}
\tag{27}
\]

不共振只能消灭固定频率的共同精确零，不能消灭公共高频近零族。

离散矩阵同样如此。取

\[
q_{Y,\xi}(d)=(d/Y)^{i\xi},
\qquad 2Y/3-1<d<2R_*Y.
\tag{28}
\]

逐滤波器使用 note 104 的 floor 误差，有

\[
|(B_Y^{(j)}q_{Y,\xi})_N|
\le |m_{\log R_j}(\xi)|
+\frac{3|\xi|}{N}\|G_{R_j}'\|_1.
\tag{29}
\]

因此

\[
\boxed{
\frac{\sum_j\|B_Y^{(j)}q_{Y,\xi}\|_2^2}
{\|q_{Y,\xi}-\operatorname{mean}q_{Y,\xi}\|_2^2}
\ll_{R_1,\ldots,R_J}
\left(\xi^{-1}+\frac{\xi}{Y}\right)^2.
}
\tag{30}
\]

取 \(\xi=Y^{1/2}\) 即得联合 Rayleigh 商 \(O(Y^{-1})\)。

## 4. 对 RH 路线的精确边界

(5) 是 note 094 的真实强化：该 cell detector 不仅看见
\(\Re s>1/2\) 的离线零，而且没有任何虚轴公共 null。

但 (27)--(30) 关闭了以下希望：选取任意固定有限个不共振平滑尺度，
仅靠联合正 Gram 恢复 raw \(L^2\) 谱隙。定理 2 的 \(H^{-2}\) frame
也不足以控制 note 104 中真实 Mertens shell 的 \(L^2\) 能量；有限窗口
还需要额外 leakage/observability 论证，不能由全线 Mellin multiplier
自动推出。

对真实 \(M\) 向量，剩余门仍是对共同近零频率的一致非集中：

\[
|E_M(Y,\xi)|^2
\le(1-\delta)|I_Y|Q_M(Y),
\tag{31}
\]

其中

\[
E_M(Y,\xi)=\sum_{d\in I_Y}M(d)(d/Y)^{-i\xi},
\qquad
Q_M(Y)=\sum_{d\in I_Y}|M(d)|^2.
\tag{32}
\]

PNT、经典零自由区和标准 large sieve 都允许单个异常频率达到
Cauchy--Schwarz 饱和，尚不能给 (31)。因此本文没有证明 RH；
它严格确定了有限联合 scale smoothing 的最优功能边界。
