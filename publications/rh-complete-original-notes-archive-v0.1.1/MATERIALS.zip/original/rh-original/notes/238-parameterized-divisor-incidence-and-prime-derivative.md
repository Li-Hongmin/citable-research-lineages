> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 参数化除数 incidence：Möbius 导数与 prime 边界

这是一个候选的 signed arithmetic intertwiner 接口。它本身不证明 RH，但把 Möbius 通道的导数精确连接到 \(\Lambda\) 与完整 divisor reflection。

## 1. 参数化 incidence

定义
\[
(D_\sigma f)(n)
=\sum_{d\mid n}f(d)(n/d)^{-\sigma}.
\]
在 \(\sigma=0\) 时 \(D_0=D\)。由于
\[
\sum_{d\mid n}\mu(d)=\mathbf 1_{n=1},
\]
有
\[
D_0\mu=\varepsilon.
\]
对 \(\sigma\) 求导并取零点：
\[
(D'_0\mu)(n)
=-\sum_{d\mid n}\mu(d)\log(n/d)
=-\Lambda(n).
\tag{1}
\]
最后一步是经典卷积恒等式 \(\mu*\log=\Lambda\)。

更高阶导数给出
\[
(D_0^{(k)}\mu)(n)
=(-1)^k\sum_{d\mid n}\mu(d)\log^k(n/d),
\]
即广义 von Mangoldt 型卷积，而不是新的自由序列。

## 2. 完整 squarefree divisor 格上的反射

令 \(X\) squarefree，\(R_Xe_d=e_{X/d}\) 为补集反射。直接换元得到
\[
\boxed{R_XD_\sigma R_X=D_\sigma^{\,T}.}\tag{2}
\]
因此
\[
R_XD'_0=D_0^{\prime\,T}R_X.
\tag{3}
\]
这正是把乘法除数 incidence 的方向反转为 prime/Weil 型转置通道的精确有限维恒等式。

## 3. Möbius mode 的边界支持

令 \(c_X=(\mu(d))_{d\mid X}\)，则 \(R_Xc_X=\mu(X)c_X\)。由 (3)
\[
R_X(D'_0c_X)=\mu(X)D_0^{\prime\,T}c_X.
\tag{4}
\]
右端可显式计算：
\[
(D_0^{\prime\,T}c_X)(n)
=-\sum_{\substack{e\mid X\\n\mid e}}\mu(e)\log(e/n)
=-\mu(n)\sum_{r\mid X/n}\mu(r)\log r.
\tag{5}
\]
当 \(X/n\) 是单个素数 \(p\) 时，内和为 \(-\log p\)，故该坐标为
\(\mu(n)\log p\)；当 \(X/n\) 含至少两个素因子或等于 \(1\) 时，内和为零。因此转置导数只支撑在
\[
n=X/p,\qquad p\mid X,
\]
这些 prime boundary edges 上。

## 4. 对 RH 桥的含义

式 (1) 给出了一个严格的 Möbius-to-prime 导数接口，式 (2)--(5) 说明它在完整 divisor 格上保留 complement parity，但其转置端不是整个 \(\Lambda\) 体，而是由 prime boundary edges 组成。把这个有限格接口延拓到实际 \(a,b\le\sqrt x\) 的半格，必须控制缺失的 complement blocks 与 cross terms；这正是当前 signed Weil/Feshbach intertwiner 的最薄缺口。

因此该参数化不会自动给出 RH，但提供了一个比抽象“寻找 prime intertwiner”更具体的候选：需要在半格上证明 \(D'_0\) 的 prime-edge boundary 与 \(A_V\) 的非因子交换子共同满足平方根级 signed cancellation。
