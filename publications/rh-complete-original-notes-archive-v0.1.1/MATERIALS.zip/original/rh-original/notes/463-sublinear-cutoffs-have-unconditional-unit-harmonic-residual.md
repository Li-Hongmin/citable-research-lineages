> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 多项式次线性截断的 residual 无条件趋于 1

日期：2026-08-17。

本 note 将 note 461 的固定截断结论推广到所有多项式次线性截断。所用输入只是经典零点自由区对调和 Möbius 和的标准估计，不涉及 RH。

## 1. 经典输入

记

$$
S(y)=\sum_{n\le y}\frac{\mu(n)}n.
$$

经典零点自由区与 Perron/Abel 估计给出某些 \(c,C>0\)，使得充分大 \(y\) 满足

$$
|S(y)|
\le C\exp\!\left(
-c(\log y)^{3/5}(\log\log y)^{-1/5}
\right).
\tag{1}
$$

这里只使用 \(S(y)\to0\) 的定量形式；这远弱于 RH 所需的幂次界。

## 2. 次线性截断

令 \(A_X\le X^\alpha\)，其中固定 \(0\le\alpha<1\)。由 note 461 式 (3)，

$$
\mathcal H_{A_X}(X)
=1-\sum_{a\le A_X}\frac1a
S\!\left(\left\lfloor\frac Xa\right\rfloor\right).
\tag{2}
$$

对 \(a\le A_X\)，有

$$
\left\lfloor\frac Xa\right\rfloor
\ge \frac12X^{1-\alpha}
\qquad(X\ \text{充分大}).
$$

将 (1) 代入 (2)，并使用 \(\sum_{a\le A_X}a^{-1}\le1+\log A_X\)，得到

$$
\left|1-\mathcal H_{A_X}(X)\right|
\le C(1+\log X)
\exp\!\left(-c_\alpha(\log X)^{3/5}
(\log\log X)^{-1/5}\right)
=o(1).
\tag{3}
$$

因此

$$
\boxed{\mathcal H_{A_X}(X)=1+o(1)
\qquad\left(A_X\le X^\alpha,\ \alpha<1\right).}
\tag{4}
$$

## 3. 对倍数链 completion 的直接后果

在 note 458 的 \(d=1,k=1\) 行，\(M_d=X\)、\(L_{d,k}=A_X\)，所以标量 residual 正是 \(\mathcal H_{A_X}(X)\)。由 (4)，

$$
(\mathcal R_{1,A_X})_1=1+o(1),
\qquad
\|\mathcal R_{1,A_X}\|_2\ge\sqrt3\,(1+o(1)).
\tag{5}
$$

对固定 \(d\)，只需将 \(X\) 换成 \(M_d=\lfloor N/d\rfloor\)，同样得到一个 \(d^{-1}\) 级的非消失下界。

这说明所有固定幂次次线性截断——包括 \(A=\sqrt X\)、\(A=X^{0.99}\)——都不能产生小 completion residual。要让单链 residual 进入 \(o(1)\) 区域，截断必须满足至少 \(A=X^{1-o(1)}\)；随后还要面对 note 459 的高截断同号尾。

## 4. 算术含义

“截断倍数链并把剩余项作为低阶边界”这一方案在两个方向都失败：

* \(A\le X^\alpha\)（固定 \(\alpha<1\)）时，式 (4) 给出 residual \(\to1\)；
* \(A>X/2\) 且与 \(X\) 保持固定比例时，note 459 给出同号调和尾下界。

剩余的近完整链区 \(A=X^{1-o(1)}\) 不能靠链内正性处理；必须构造跨尺度 signed intertwiner，或直接建立 RH-strength 的不完全除数相关估计。这个结论是无条件结构性 no-go，不是 RH 证明。
