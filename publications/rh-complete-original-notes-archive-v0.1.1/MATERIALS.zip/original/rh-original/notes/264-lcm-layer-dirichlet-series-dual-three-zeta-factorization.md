> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# lcm 层 Dirichlet 级数的对偶 three-zeta 因子化

日期：2026-08-16。

note 205 的实际 reciprocal-product 和按
\(X=\operatorname{lcm}(a,b)\) 分层。其完整 squarefree \(X\)-层在固定
频率上有另一组 Euler 系数；本 note 给出精确因子化，并与 note 260
的 parity 系数比较。

## 1. 完整 lcm 层的频率系数

由 note 205 式 (6)，若
\[
P(y)=\frac1{2\pi}\int_{\mathbb R}H(t)y^{it}\,dt,
\]
则完整层 \(H_X^x\) 的 \(X\)-系数为
\[
c_X(t):=\prod_{p\mid X}\bigl(p^{-2it}-2p^{-it}\bigr),
\qquad X\ {\rm squarefree}.
\tag{1}
\]
相应 Dirichlet 级数为
\[
L(s,t):=\sum_{X\ {\rm squarefree}}c_X(t)X^{-s}
=\prod_p\left[1-2p^{-s-it}+p^{-s-2it}\right].
\tag{2}
\]
写 \(x=p^{-s}\)、\(z=p^{-it}\)，局部因子就是
\[
\ell_p(s,t)=1-2xz+xz^2.
\]

## 2. 对偶因子化

定义
\[
J(s,t):=\frac{\zeta(s+2it)}{\zeta(s+it)^2},
\tag{3}
\]
其局部因子为
\[
j_p(s,t)=\frac{(1-xz)^2}{1-xz^2}.
\]
于是有精确分解
\[
L(s,t)=J(s,t)S(s,t),
\tag{4}
\]
其中
\[
S(s,t)=\prod_p s_p(s,t),\qquad
s_p(s,t)=
\frac{[1-2xz+xz^2](1-xz^2)}{(1-xz)^2}.
\tag{5}
\]
局部代数给出
\[
[1-2xz+xz^2](1-xz^2)-(1-xz)^2
=-x^2z^2(1-z)^2.
\tag{6}
\]
因此
\[
s_p(s,t)=1+O_\eta(p^{-1-2\eta})
\]
在 \(\Re s\ge\tfrac12+\eta\)、\(t\in\mathbb R\) 时成立，\(S(s,t)\)
在 \(\Re s>\tfrac12\) 局部一致绝对收敛并全纯。

这与 note 260 的
\[
\frac{\zeta(s+it)^2}{\zeta(s)\zeta(s+2it)}
\]
形成对偶：lcm 层的主因子是
\[
\boxed{
L(s,t)=
\frac{\zeta(s+2it)}{\zeta(s+it)^2}S(s,t).
}
\tag{7}
\]
在 \(t=0\) 时 \(L(s,0)=1/\zeta(s)\)，因为
\(\zeta(s)/\zeta(s)^2=1/\zeta(s)\)、\(S(s,0)=1\)。

## 3. 对实际 cutoff 的含义

完整层的部分和
\[
\sum_{X\le B}H_X^x
=\frac1{2\pi}\int_{\mathbb R}H(t)x^{it}
\sum_{X\le B}c_X(t)\,dt
\tag{8}
\]
由 (7) 控制其 Dirichlet 结构，但实际 reciprocal-product 只保留
\[
H_X^{x,\mathrm{cut}}
=\sum_{\substack{a,b\le\sqrt x\\\operatorname{lcm}(a,b)=X}}
\mu(a)\mu(b)P(x/(ab)).
\]
因此 (8) 仍不能把 lcm 完整层无误差替代为实际 cutoff 层；note 205
的宏观 remainder 对这条“先分层、后拼接”的路线仍然存在。

但这不是说原始 half-lattice 二次型本身没有直接接口。note 206 已给出
不经 lcm 分层的 common-scale Gram 压缩：
\[
|T_P(x)|
\le
\frac1\pi\int_{\mathbb R}|h(t)|
\left|\sum_{a\le\sqrt{x}}\mu(a)a^{it}\right|^2dt.
\tag{8a}
\]
所以当前真正的承重命题是该正频率 Möbius 能量的
\(x^{1/2+\varepsilon}\) 级上界；lcm completion 只是一个被关闭的替代路线，
不是原二次型额外缺失的 completion。

固定 \(t\ne0\) 时，\(J(s,t)\) 在 \(s=1-2it\) 有来自
\(\zeta(s+2it)\) 的简单极点，除非被特殊的局部因子抵消；这说明
lcm 完整层也有同尺度 shifted-zeta 共振，只是从 parity 系数的
二阶 \(s=1-it\) 共振变成了另一种单极点。\(t=0\) 的退化极限则恢复
\(1/\zeta(s)\)，不能把非零频率的极点结论直接代入零频。

## 4. 路线裁决

这一步给出实际 lcm 层的精确坐标：

* parity completion 的主因子是
  \(\zeta(s+it)^2/[\zeta(s)\zeta(s+2it)]\)；
* lcm 层的主因子是
  \(\zeta(s+2it)/\zeta(s+it)^2\)；
* 两者的残余 Euler 乘积都在 \(\Re s>\tfrac12\) 收敛；
* 但 lcm 完整层不能自动替代实际 cutoff；原 half-lattice 应直接使用
  note 206 的 Gram 接口，而不是再做 lcm 拼接。

若继续 lcm 路线，仍需额外的跨 \(X\) signed intertwiner；若回到原始
half-lattice，唯一承重的未闭合命题是 note 206 式 (4) 的正频率
Möbius 能量估计。这两条路线不能混写，且目前都不是 RH 证明。
