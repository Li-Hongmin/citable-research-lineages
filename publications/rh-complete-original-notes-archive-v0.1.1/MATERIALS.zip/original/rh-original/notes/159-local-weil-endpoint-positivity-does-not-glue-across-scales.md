> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 局部 Weil 端点正性不能由域分解自动拼接到更大尺度

日期：2026-08-15。

本 note 判断：已证端点

\[
a_*={1\over2}\log(201/20),\qquad A_{a_*}>0,
\]

不能仅凭零延拓、域嵌套、正块 Toeplitz/Gram 拼接推出 (A_b\ge0)（(b>a_*)）。

## 1. 正确的块结构

令 (H_a=L^2(-a,a))，把 (H_a) 零延拓到 (H_b)，并令 (H_{a,b}) 为其正交补。
闭形式限制给出

\[
P A_b P=A_a,
\qquad
A_b=\begin{pmatrix}A_a&C_{a,b}\\ C_{a,b}^*&D_{a,b}\end{pmatrix}.
\tag{1}
\]

当 (A_a>0) 时，(1) 正性的精确条件是
\[
A_b\ge0
\iff D_{a,b}-C_{a,b}^*A_a^{-1}C_{a,b}\ge0.
\tag{2}
\]
端点证书只给 (A_a>0)，没有给 (2) 中的跨块预算。

## 2. 最小 cross-term 反例

即使两个对角块都严格正，拼接也不保正：
\[
\begin{pmatrix}1&2\\2&1\end{pmatrix}
\quad\text{有特征值 }3,-1.
\tag{3}
\]
对 Weil 形式，新的 prime/reflection edge 的确产生同型 signed cross：
\[
B_n^\sigma=\pm {\Lambda(n)\over\sqrt n}
\begin{pmatrix}0&1\\1&0\end{pmatrix},
\tag{4}
\]
故加上正对角 (\operatorname{diag}(d_1,d_2)) 后，二维行列式为
\[
d_1d_2-\left({\Lambda(n)\over\sqrt n}\right)^2.
\tag{5}
\]
没有额外 Schur 界，(5) 的符号没有理由为正。

在 (a_*) 之后，新的阈值首先是 (n=11)，其边权
\[
\Lambda(11)/\sqrt{11}=0.7229926278581\ldots.
\]
更早已激活的 (n=2) edge 也会在扩大区间后把内区与新增外环耦合起来。

## 3. 哪些 cross 可以合法保留

正 Yukawa 原子族的 block 是真正 Gram 矩阵；note 089 的 Parseval 恒等式保留了
base--atom、atom--atom 和低--高 cross，并给出 Loewner 下算子。
但 active prime/reflection 与奇极点项是 signed blocks，不是 PSD Gram；它们不能用
“两个 Toeplitz 正块拼接”处理。必须逐新尺度建立 (2) 型 true-Schur/ resolvent 界。

## 4. 结论边界

已知 (A_{a_*}>0) 严格推出的是 (A_a>0) 对所有 (0<a\le a_*)，这由 form-domain
单调性成立。方向 (b>a_*) 没有自动延伸；全尺度正性仍需要新的 arithmetic cross-term
估计，不能由现有端点证书推出 RH。
