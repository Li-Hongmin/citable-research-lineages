> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# averaged-Chowla 直接闭合极短 dyadic 有符号块和

日期：2026-08-16。

note 306 的平方恒等式只含
\[
D_f(X,H)=\sum_{H<h\le2H}C_h^{\rm end}(X),
\qquad
C_h^{\rm end}(X)=\sum_{n\le X-h}f(n)f(n+h),
\]
而不是逐 \(h\) 的绝对值或均方。因此 note 307 的端点统一还可以直接给出
一个更弱、但对 RH 门更贴切的局部结论。

令 \(Y=X-2H\)，\(2H\le X\)。则
\[
C_h^{\rm end}(X)=\sum_{n\le Y}f(n)f(n+h)+R_h,
\qquad |R_h|\le2H,
\]
从而
\[
|D_f(X,H)|
\le
\sum_{H<h\le2H}\left|\sum_{n\le Y}f(n)f(n+h)\right|+O(H^2).
\tag{1}
\]
MRT averaged-Chowla 输入给出
\[
\sum_{1\le h\le2H}\left|\sum_{n\le Y}f(n)f(n+h)\right|
\ll YH\rho_X(H),
\tag{2}
\]
其中 \(f=\lambda\)（同一框架适用于 \(\mu\)），
\[
\rho_X(H):=\frac{\log\log(3H)}{\log(3H)}
+\frac1{\log^{1/3000}(3X)}.
\]
因此，在 \(H\le Y\rho_X(H)\) 时，
\[
|D_f(X,H)|\ll XH\rho_X(H)+H^2.
\tag{3}
\]

固定任意 \(\delta>0\)。对足够大的 \(X\)，若
\[
H\rho_X(H)\le X^\delta,
\]
则 \(H\rho_X(H)\le X^\delta\)，且 \(H^2=o(X^{1+\delta})\)（取
\(\delta<1\) 即可）。于是
\[
\boxed{|D_f(X,H)|\ll_\delta X^{1+\delta}}
\tag{4}
\]
对所有这些极短 dyadic 块成立。\(H<10\) 的有限个块由
\(|D_f(X,H)|\le HX\) 直接处理。

这比 note 307 的均方结论更贴合恒等式
\[
S_f(X)^2=\sum_{n\le X}f(n)^2+2\sum_H D_f(X,H).
\]
它说明：对每个固定的误差指数，averaged-Chowla 已经移除了
\[
H\rho_X(H)\ll X^\delta
\]
的全部小块，不需要额外的四点均方估计。终端
\(H>X^{1-\eta}\) 则由 note 306 的 \(O(X^{2\eta})\) 总贡献处理。

剩余未决区间可明确压缩为
\[
H\rho_X(H)>X^\delta,
\qquad H\le X^{1-\eta},
\]
其中必须保留跨移位符号，证明
\[
|D_f(X,H)|\ll_\varepsilon X^{1+\varepsilon}
\]
或更强的 signed spectral/intertwiner 估计。故本结果仍不是 RH 证明，
但它把均方门进一步降为中程 dyadic 有符号块和门。

来源：Matomäki--Radziwiłł--Tao, *An averaged form of Chowla's conjecture*,
arXiv:1503.05121, Theorem 1.1/1.6。
