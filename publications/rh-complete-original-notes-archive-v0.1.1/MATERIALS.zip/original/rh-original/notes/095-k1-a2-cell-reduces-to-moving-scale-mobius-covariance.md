> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 单个 \(k=1,a=2\) cell 精确化为移动尺度 Möbius 协方差

日期：2026-08-14。

依赖：[note 065](065-barban-vehov-hminus1-obstruction-and-weak-mertens-bridge.md)、
[note 070](070-sawtooth-cell-boundaries-add-instead-of-telescope.md)、
[note 084](084-fixed-mode-gram-reduces-to-high-divisor-multiplicative-near-diagonal.md)、
[note 094](094-k1-a2-high-divisor-cell-has-a-zero-free-mellin-detector.md)。

证据等级：精确有限和恒等式与解析不等式。本文不估计所得到的协方差，故不证明 RH。

## 1. 唯一未支付项

令

\[
F(t):=\log\frac1t\left(\frac2{\pi t}+\sin(2\pi t)\right)
\mathbf1_{(2/3,1)}(t),
\qquad
U_N:=\sum_{d\ge1}\mu(d)F(d/N).
\tag{1}
\]

并沿用 note 094 的 \(T_N\)。其精确分解 \(T_N=U_N+C_NV_N\) 满足

\[
C_N=O(N^{-1}),\qquad V_N=O(1),
\qquad
\boxed{\ \sum_{Y<N\le2Y}|T_N-U_N|^2=O(Y^{-1}).\ }
\tag{2}
\]

定义

\[
\begin{aligned}
W_Y(d,e)
:={}&\sum_{Y<N\le2Y}
F(d/N)F(e/N),\\
\mathcal D_F(Y)
:={}&\sum_{d\ge1}\mu(d)^2W_Y(d,d),\\
\mathcal C_F(Y)
:={}&\sum_{d\ne e}\mu(d)\mu(e)W_Y(d,e).
\end{aligned}
\tag{3}
\]

于是逐项展开给出

\[
\boxed{
\sum_{Y<N\le2Y}|U_N|^2
=\mathcal D_F(Y)+\mathcal C_F(Y).
}
\tag{4}
\]

若 \(W_Y(d,e)\ne0\)，则

\[
\frac{2Y}{3}<d,e<2Y,
\qquad
\max(d,e)<\frac32\min(d,e).
\tag{5}
\]

因而

\[
\mathcal D_F(Y)\ll_FY^2.
\tag{6}
\]

写 \(e=d-r\)，可将唯一非对角项写成

\[
\boxed{
\mathcal C_F(Y)
=\sum_{r\ne0}\sum_{d\ge1}
\mu(d)\mu(d-r)W_{Y,r}(d),
\quad
W_{Y,r}(d):=\sum_{Y<N\le2Y}
F(d/N)F((d-r)/N).
}
\tag{7}
\]

这是完整的、平滑的、随 \(N\) 共同移动的 shifted Möbius covariance；不能逐个 \(r\)
取绝对值。

**定理 1（单 cell covariance 判据）。**

\[
\boxed{
\mathrm{RH}
\Longleftrightarrow
\forall\varepsilon>0,\qquad
\mathcal C_F(Y)=O_{\varepsilon,F}(Y^{2+\varepsilon}).
}
\tag{8}
\]

这里 \(\mathcal C_F(Y)\) 为实数，\(O\)-记号取绝对值。

**证明。** 由 (2)，\(T\) 的 note 094 dyadic 均方门与 \(U\) 的同一门等价。
由 (4)、(6)，该门又等价于 (8)：若 \(U\) 的均方有界，则
\(|\mathcal C_F|\le\sum|U_N|^2+\mathcal D_F\)；反向由 (4)。最后使用
note 094 的 RH 等价式。\(\square\)

```mermaid
flowchart LR
  R["RH"] <--> T["T-cell dyadic L²"]
  T <--> U["U-cell dyadic L²"]
  U <--> C["moving-scale covariance C_F(Y)"]
  D["diagonal D_F=O(Y²)"] --> C
```

## 2. Abel 形式与直接的 Mertens 桥

令 \(M(x):=\sum_{d\le x}\mu(d)\)、\(m_N:=\lfloor2N/3\rfloor\)。由于
\(F(1)=0\)，离散 Abel 恒等式为

\[
\boxed{
U_N=
-M(m_N)F\!\left(\frac{m_N+1}{N}\right)
-\sum_{d=m_N+1}^{N-1}M(d)
\left[F\!\left(\frac{d+1}{N}\right)-F\!\left(\frac dN\right)\right].
}
\tag{9}
\]

在 \((2/3,1)\) 上 \(F'\) 有界，故

\[
|U_N|^2
\ll_F |M(m_N)|^2+
\frac1N\sum_{m_N<d<N}|M(d)|^2.
\tag{10}
\]

交换 \(N,d\) 后，每个 \(d\) 只出现于 \(d<N<3d/2\)。于是

\[
\boxed{
\sum_{Y<N\le2Y}|U_N|^2
\ll_F
\sum_{2Y/3<d\le2Y}|M(d)|^2.
}
\tag{11}
\]

因此，若有 dyadic square-root Mertens 均方

\[
\sum_{X<d\le2X}|M(d)|^2\ll_\varepsilon X^{2+\varepsilon}
\quad(\forall\varepsilon>0),
\tag{12}
\]

则 (8) 成立。反之，(12) 本身已是 RH 强度：由

\[
\frac1{\zeta(s)}=s\int_1^\infty M(x)x^{-s-1}\,dx
\tag{13}
\]

及 dyadic Cauchy--Schwarz，(12) 使右端在每个 \(\Re s>1/2\) 全纯。
故 (11) 是直接 Abel 桥，而不是一个较弱的无条件输入。

## 3. 三个不能省略的结构

### 3.1 相邻尺度不产生端点 telescope

\[
F(2/3+)=\log\frac32\left(\frac3\pi-\frac{\sqrt3}{2}\right)>0,
\qquad F(1-)=0.
\tag{14}
\]

自然的 \(3/2\)-缩放把支撑区间送为

\[
(2N/3,N)\longmapsto(N,3N/2).
\tag{15}
\]

共享边界处留下的是下一 cell 的非零下端 jump，而不是一对相反端点。
这正是 note 070 的 Stieltjes 符号机制在本 cell 中的对应边界：相邻尺度本身不把 (9)
望远镜成有限个端点 Mertens 和。

### 3.2 \(H^0\) divisor Gram 不是 (7)

若 \(a_d\) 是任意有限系数，则典型 divisor-incidence 二次型的核为

\[
\sum_{n\le X}\left|\sum_{d\mid n}a_d\right|^2
=\sum_{d,e}a_d\overline{a_e}\left\lfloor\frac{X}{[d,e]}\right\rfloor.
\tag{16}
\]

Graham--Barban--Vehov 型 \(H^0\) 控制正是此 lcm/incidence 核的特例。
(7) 则在全部 \(|r|\asymp Y\) 上保留 \(\mu(d)\mu(d-r)\)，其核只由共同移动尺度
\(d/N,(d-r)/N\) 决定，并没有整除或 lcm 条件。因此 (16) 不会直接化为 (7)。

更具体地，对 note 084 的 high-divisor incidence 和

\[
q_{N,>D}(n):=
\sum_{\substack{D<a\le N\\a\mid n}}
\mu(a)\log\frac Na,
\tag{17}
\]

取偶数 \(d\) 且 \(d/2>D\)。在 \(q_{N,>D}(2d)\) 中，cofactor \(2\) 的项

\[
\mu(d)\log\frac Nd
\tag{18}
\]

与 cofactor \(4\) 的项

\[
\mu(d/2)\log\frac{2N}{d}
\tag{19}
\]

同时出现。故单个 \(a=2\) cell 不是该 \(H^0\) 向量的一个正交坐标；从 (16) 到
(7) 的直接坐标转移并不存在。若要由这种表示估计 (7)，还须新增跨 cofactor 的 signed
covariance；仅调用既有 \(H^0\) 界并不给出该结论。

### 3.3 Dirichlet 去卷积不保 dyadic \(\ell^2\)

Mellin 主因子含 \(1/\zeta(s-1)\)。形式上乘 \(\zeta(s-1)\) 把系数 \(b_n\) 变为

\[
c_n=\sum_{a\mid n}a\,b_{n/a},
\qquad
b_n=\sum_{a\mid n}\mu(a)a\,c_{n/a}.
\tag{20}
\]

其逆在 dyadic \(\ell^2\) 上不有界：取 \(c_1=1\)、\(c_n=0\;(n>1)\)，则

\[
\sum_{Y<n\le2Y}|b_n|^2
=\sum_{Y<n\le2Y}\mu(n)^2n^2
\asymp Y^3.
\tag{21}
\]

故“先乘 \(\zeta(s-1)\) 再以 \(H^0\) 或 Mertens 均方反解”的形式路线不是 norm-stable
transfer。

## 4. 边界

本文关闭的只是下列直接转移：相邻尺度端点 telescope、把 single cofactor 当作
full divisor \(H^0\) 坐标、以及不保范数的 Dirichlet 去卷积。它没有排除未来利用
\(\mu(d)\mu(d-r)\) 的新 signed estimate；那一 estimate 正是 (8)。
