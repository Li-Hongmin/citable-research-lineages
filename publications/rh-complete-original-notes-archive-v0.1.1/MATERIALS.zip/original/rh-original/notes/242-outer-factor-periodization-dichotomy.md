> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 外因子与 Möbius 因果坍缩的 \(\zeta\)-因子二择一

本 note 精确说明：正能量的 Szegő 外因子与
\(\mu*1=\varepsilon\) 的因果坍缩不能无条件同时使用。若要求 periodization
在 Mellin 端产生目标外因子，则必然出现 \(O/\zeta\)；其临界带解析性本身就是
RH 级输入。

## 1. Mellin periodization 恒等式

令 \(\phi\) 是 \((0,1)\) 上的 Mellin 测试函数，设

\[
 K_\phi(s)=\int_0^1\phi(u)u^{s-1}\,du .
\]

定义其 multiplicative periodization

\[
 (\mathcal P\phi)(y)
 :=\sum_{m\le y}\phi(m/y),\qquad y\ge1.
\]

在 \(\operatorname{Re}s>1\) 的绝对收敛区，Mellin--Fubini 给出

\[
 \int_1^\infty(\mathcal P\phi)(y)y^{-s-1}\,dy
 =\zeta(s)K_\phi(s).
 \tag{1}
\]

相应地，Möbius periodization

\[
 (\mathcal M\mathcal P\phi)(x)
 :=\sum_{n\le x}\mu(n)(\mathcal P\phi)(x/n)
\]

满足

\[
 \int_1^\infty(\mathcal M\mathcal P\phi)(x)x^{-s-1}\,dx
 =K_\phi(s).
 \tag{2}
\]

在物理变量中，(2) 正是
\[
 \sum_{n\le x}\mu(n)\sum_{m\le x/n}\phi(mn/x)
 =\sum_{k\le x}(\mu*1)(k)\phi(k/x)
 =\phi(1/x),
 \]
故 \(\mu*1\) 的坍缩是严格的，而不是估计。

## 2. 与正能量外因子的匹配条件

设 \(w(t)\ge0\) 是当前 detector 的正频率权，并设 \(O(s)\) 是右半平面
 \(\operatorname{Re}s>0\) 的零自由外因子，满足

\[
 |O(it)|^2=w(t)
\quad\text{a.e.}
 \tag{3}
\]

这是 notes 195、212 中的 Szegő 构造。若希望用 periodization 后的核在
Mellin 意义上**精确携带同一个外因子** \(O\)，这里的“精确”是指其 Mellin
变换在 \(\operatorname{Re}s>1\) 等于 \(O(s)\)，而不只是边界模长相同。由
(1) 必须要求

\[
 \zeta(s)K_\phi(s)=O(s),
\qquad \operatorname{Re}s>1.
 \tag{4}
\]

于是 (4) 在 \(\operatorname{Re}s>1\) 上唯一给出

\[
 \boxed{K_\phi(s)=\frac{O(s)}{\zeta(s)}}.
 \tag{5}
\]

因此 \(\mu*1\) 的严格坍缩与正能量外因子的精确匹配，不是两个独立的自由
选择；它们被 (5) 锁定。

## 3. 临界带的二择一

若 \(\phi\) 是一个可用的 causal Mellin 测试函数，使 \(K_\phi\) 在
 \(\operatorname{Re}s>1/2\) 全纯且零自由，而 \(O\) 在该带零自由，则 (5) 立即推出

\[
 \frac1{\zeta(s)}=\frac{K_\phi(s)}{O(s)}
\]

在 \(\operatorname{Re}s>1/2\) 全纯。因此 \(\zeta\) 在该带无零，即 RH。

反过来，在 RH 及相应增长估计下，\(O/\zeta\) 才可能作为同一半平面中的
Mellin--Laplace 乘子实现；此时 (1)--(2) 给出真正的因果坍缩。

于是得到精确二择一：

\[
\boxed{
\begin{array}{c}
\text{无条件使用 }\mu*1=\varepsilon\text{ 的 periodization 坍缩}\\
\text{并保持目标正能量外因子 }O
\end{array}
\quad\Longrightarrow\quad
\mathrm{RH}.
}
\tag{6}
\]

如果不假设 RH，则至少有一个环节必须放弃：要么 periodization 不再精确
坍缩，要么边界因子不再是目标 \(O\)，要么引入非因果的反向卷积和相应的
 signed cross term。

## 4. Inner-factor loophole

上面的“零自由”条件不能省略。正能量只固定外因子的模长；若 \(B\) 是右半平面
上的 inner factor，则

\[
 O_B(s)=B(s)O(s),\qquad |O_B(it)|^2=w(t).
 \tag{7}
\]

若 \(B\) 在 \(\zeta\) 的右半临界带零点 \(\rho\) 处有相应零点，则

\[
 K_{\phi,B}(s)=\frac{B(s)O(s)}{\zeta(s)}
 \tag{8}
\]

可能在这些零点处可去，从而成为一个有零点的 causal Mellin 乘子；这并不推出
RH。这样的 \(B\) 至少需要零点满足右半平面 Blaschke 条件

\[
 \sum_{\rho:\,\operatorname{Re}\rho>1/2}
 \frac{\operatorname{Re}\rho-1/2}{1+|\rho|^2}<\infty.
 \tag{9}
\]

有限个离线零点当然满足 (9)；因此“存在一个因果 periodization 因子”本身不能
排除 RH 失败。要从正能量推出 RH，必须得到一个零自由的 \(K_\phi\)，或得到
足够多彼此独立的相位因子，使所有可能的 inner 消去都被排除。

## 5. 为什么只匹配模长不够

正能量只给出 \(|O(it)|^2=w(t)\)，有人可能尝试把精确恒等式 (4) 放宽为

\[
 |\zeta(it)K_\phi(it)|^2=w(t).
 \tag{10}
\]

这只确定模长，不确定相位；它不能推出 (2) 的目标坍缩所需的解析恒等式。
若
\[
 J(s)=\frac{\zeta(s)K_\phi(s)}{O(s)},
\]
则 (10) 仅说明 \(J(it)\) 的边界模为 \(1\)。\(J\) 可以携带非平凡 inner
因子、零点和反因果成分；将 \(J\) 丢掉正是把 signed cancellation 当成
PSD Gram 的错误步骤。要回到 \(\mu*1=\varepsilon\)，必须恢复 \(J\equiv1\)，
于是只有在额外要求 \(J\equiv1\) 或 \(K_\phi\) 零自由时，才重新得到 (5) 及
RH 门。

因此 outer-factorization 并没有提供一个隐藏的无条件证明；它把缺口精确定位
为一个 phase-preserving、causal 的 \(\zeta^{-1}\) 实现问题。

## 6. 对当前 RH 主线的结论

对 \(V_{15}\) 的 \(w=|h|/(2\pi)\)，notes 195、212 已给出 \(O\) 的解析
外因子；本 note 说明下一步不能同时假设一个能利用 \(\mu*1\) 的 periodization
测试函数而不支付 RH。所有看似“外因子正性 + Möbius 卷积坍缩”的方案，最终
都必须证明 \(O/\zeta\) 的零自由实现，或者明确处理其 inner/反因果 cross
term；仅有可去奇点的 inner 修正不足以推出 RH。后者正是当前全局 signed
intertwiner 的未决部分。

本 note 是严格的解析结构归约，不声称 RH，也不把 \(O/\zeta\) 的实现当作已证。

## 7. Inner loophole 不削弱正能量门本身

需要区分 periodization 路线与正能量路线。若正能量估计

\[
 E_N(w)\ll_\varepsilon N^{1+\varepsilon}
 \tag{11}
\]

成立，则 Cauchy--Schwarz 同时给出所有满足
\(\int|\Psi(it)|^2/w(t)\,dt<\infty\) 的 Mellin 测试函数的平方根估计。
此时不需要让测试函数参与 \(\mu*1\) 的 periodization。

特别地，直接取 notes 195、213 中的零自由外因子 \(O\)，令

\[
 \Psi(s)=\frac{O(s)}{(s+1)^J},\qquad J\ge1.
 \tag{12}
\]

则 \(\Psi\) 是 admissible Mellin 乘子、在 \(\operatorname{Re}s>0\) 零自由，
且 \(|\Psi(it)|^2/w(t)=(1+t^2)^{-J}\) 可积。由 (11) 得到相应
 \(S_\psi(x)\ll x^{1/2+\varepsilon}\)；Mellin--Fubini 再由
 \(K_\psi/\zeta\) 的解析性推出 RH。

因此 inner factor 的存在只说明：**单个带相位的 periodization 因子**不能
自动承担 RH 推出；它不影响“正能量门 \(\Rightarrow\) RH”的主结论，因为
主结论可以选择 canonical zero-free outer factor，而不走 periodization 坍缩。
