> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 2026 Liouville wavelet 预印本：承重命题仍是条件性的

日期：2026-08-16。

核验来源：
<https://zenodo.org/records/19504394>

该预印本的摘要声称在 \(N=4\times10^{11}\) 的有限计算中观察到
\[
\max_k |C_j(k,h)|/2^j\le j^{-2}
\]
（\(23\le j\le37\) 的有限尺度），并提出 scale-cascade 与 Poisson
smoothing 机制。直接读取 PDF 后，承重状态如下。

1. 文中 Proposition 3.3/3.4 的 conductor cascade 依赖未闭合的 transfer
   inequality
   \[
   \delta_j\le C\,\delta_{2j}\,j^{-c_0}.
   \]
   因此 Theorem 4.7 的“two-layer elimination”是条件性结论，不是无条件
   的 Liouville 相关估计。

2. Conjecture 9.1（cumulative variance transfer）被作者定义为猜想；其
   Theorem 9.2 只证明该猜想可推出 Goldbach。Proposition 10.1 又把该猜想
   证明为加权四点 Chowla 条件，因此数值比值约 \(0.98\) 不能替代算术证明。

3. Corollary 11.1 明确是 conditional Goldbach theorem：它假设所有
   \(j\ge23\) 的 pointwise wavelet bound；有限尺度 \(23\le j\le37\) 的
   计算验证不覆盖无限尺度，也不推出 RH。

4. 该框架处理的是 \(\lambda(n)\lambda(n+h)=\lambda(n(n+h))\) 的多项式
   相关与 Goldbach bridge，未给出本项目所需的
   \[
   \sum_{n\le X}\lambda(n)\ll X^{1/2+\varepsilon}
   \]
   或等价的 reciprocal-product signed bound。

因此这篇预印本提供了可研究的 polynomial-orbit 结构和数值线索，但没有
关闭 RH 门；其未证 transfer 与本项目的 signed-correlation gap 属于同一
层级的算术缺口。

