> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# pair kernel 与线性 shell coefficient 的次数不一致

日期：2026-08-16。

## 原稿中的两个定义

在 main (19).tex 的 completed-frontier-data-current-paper 中，
\[
 c_\eta=\sum_{\xi\in\mathfrak X_\eta}w_\xi e(\phi_\xi)
\tag{1}
\]
是对单个 packet/root 数据的线性求和；随后
\(x_\eta(m_\eta)=c_\eta\)，且 cellwise primal energy 明确定义为
\(\mathcal E^X_\eta=|c_\eta|^2\)。

但 same-residue-quotient-difference-correlations-current-paper 定义
\[
 \Gamma_{\eta,r,\ell}(u)
 =
 \sum_{\substack{(\xi_1,\xi_2)\ {\rm in\ the\ frozen\ pair\ class}\\
                  k_1-k_2=u}}
 W_{\xi_1,\xi_2},
\tag{2}
\]
这是有序 pair 的二重聚合。接着 Proposition
exact-same-residue-shell-decomposition-primal-macro-coefficient-current-paper
却声称
\[
 c_\eta
 =
 \sum_{r,\ell,u}
 \Gamma_{\eta,r,\ell}(u)
 e\!\left(-\frac{hC_{\eta,\ell}u}{q_\eta}\right).
\tag{3}
\]

## 自然自相关解释与 (3) 冲突

如果 \(W\) 要与 \(\mathcal E^X_\eta=|c_\eta|^2\) 兼容，唯一自然候选是
\[
 W_{\xi_1,\xi_2}
 =
 w_{\xi_1}\overline{w_{\xi_2}}
\]
（并把两端的完成相位放入差值相位）。在一个固定 residue/class 中，(2) 的右端
随后给出
\[
 \sum_u\Gamma(u)e(-\theta u)
 =
 \sum_{k_1,k_2}
 w_{k_1}\overline{w_{k_2}}e\!\left(-\theta(k_1-k_2)\right)
 =
 \left|\sum_k w_k e(-\theta k)\right|^2.
\tag{4}
\]
这是一阶 shell amplitude 的平方，而不是 (1) 的线性 amplitude。

最小一元素检验已经足够：若只有一个数据 \(\xi\)，取相位为 \(1\)、
\(w_\xi=2\)，则 (1) 给出 \(c_\eta=2\)，而自然 pair 权给出 (4) 为 \(4\)。
更一般地，把所有 \(w_\xi\) 同时乘以 \(\lambda\)，(1) 按 \(\lambda\) 缩放，
而 (2)--(4) 按 \(|\lambda|^2\) 缩放。源码对 \(w_\xi\) 没有给出会破坏这一
缩放检验的归一化约束。

## 逻辑二择一

因此原稿必须补充下列两者之一：

1. 把 Proposition (3) 改成关于 \(|c_\eta|^2\) 的恒等式，并明确 \(W\) 的
   Hermitian pair 定义、共轭约定、residue/class 交叉项和归一化；随后重新证明
   Theorem 19.216 的能量预算。
2. 若确实要保持 (3) 的线性 \(c_\eta\)，则 \(W_{\xi_1,\xi_2}\) 必须带一个未显示的
   contraction/distinguished-index 规则，使二重求和退化为单重求和；正文没有此规则，
   也没有给出对应的界或算术对称性。

不能同时把 \(\Gamma\) 当作自然自相关来取得正定性，又把它当作线性 \(c_\eta\) 的
表示式。前者只能控制平方能量，后者需要完全不同的线性 kernel。

## 对 RH 路线的影响

这个次数不一致早于低频 harmonic estimate、\(q^{-1}\) 归一化和 packet capacity
预算。即使这些后续估计全部成立，当前 Proposition (3) 仍没有从定义得到。
所以该原稿不能据此推出 packet bound，更不能据此推出 RH；首先必须修复
pair-to-linear 的精确算术接口。
