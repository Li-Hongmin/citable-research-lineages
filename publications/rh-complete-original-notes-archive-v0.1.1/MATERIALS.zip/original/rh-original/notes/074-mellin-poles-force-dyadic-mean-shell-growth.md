> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mellin 极点强迫 dyadic 平均首壳增长

日期：2026-08-13。

依赖：[note 064](064-selberg-affine-first-shell-rh-criterion.md)。

## 1. 弄清问题

note 064 由单个离线零点 \(\rho=\beta+i\gamma\) 得到点态子列下界

\[
\mathcal E_{N_j}^{\rm Sel}
\gg_\rho \frac{N_j^{2\beta-1}}{\log ^2N_j}.
\tag{1}
\]

该证明只使用

\[
R_w(X)\ne o(X^\beta),
\tag{2}
\]

因而允许极稀疏尖峰。现在问更弱、但更适合对截断参数 \(N\) 求和的目标：

\[
\overline{\mathcal E}(Y)
:=\frac1Y\sum_{Y<N\le2Y}\mathcal E_N^{\rm Sel}
=Y^{o(1)}
\quad\Longrightarrow\quad \mathrm{RH}\ ?
\tag{3}
\]

```mermaid
flowchart LR
  A["ζ-zero ρ=β+iγ"] --> B["Mellin pole of order q"]
  B --> C["dyadic L² mass of Rw"]
  C --> D["integer samples Rw(N)"]
  D --> E["average first-shell energy"]
  E --> F["subpower bound ⇒ β≤1/2"]
```

## 2. 拟定计划

\[
\boxed{
\text{pole}
\Rightarrow
\limsup_Y\frac{1}{Y^{2\beta+1}}
\int_Y^{2Y}|R_w(X)|^2dX>0
\Rightarrow
\overline{\mathcal E}(Y)
\gtrsim_\rho\frac{Y^{2\beta-1}}{\log^2Y}
}
\tag{4}
\]

第一箭头必须排除稀疏尖峰反例；第二箭头必须保留取整误差与两个端点。

## 3. 实现计划

### 3.1 边界 Mellin 极点的 dyadic \(L^2\) Tauber 型引理

**引理 1。** 设 \(\beta>1/2\)，\(\rho=\beta+i\gamma\)，且
\(R\in L^2_{\rm loc}([1,\infty))\)。假设

\[
F(s)=\int_1^\infty R(X)X^{-s-1}\,dX
\tag{5}
\]

在某个右半平面绝对收敛，并有亚纯延拓 \(G(s)\)；\(G\) 在 \(\rho\) 有
\(q\ge1\) 阶极点，最高系数 \(c_\rho\ne0\)。则

\[
\boxed{
\limsup_{Y\to\infty}
\frac{1}{Y^{2\beta+1}(\log Y)^{2q-2}}
\int_Y^{2Y}|R(X)|^2dX>0.
}
\tag{6}
\]

特别地，若 \(q\ge2\)，则删去 (6) 分母中的对数后 \(\limsup=+\infty\)。

这里仅需延拓域把原收敛半平面与
\(\{\Re s>\beta\}\) 及 \(\rho\) 的右侧穿孔邻域连通。

**证明。** 反设 (6) 左侧为零。令

\[
A_k:=\int_{2^k}^{2^{k+1}}|R(X)|^2dX,
\qquad
b_k:=\frac{A_k^{1/2}}{2^{k(\beta+1/2)}k^{q-1}};
\tag{7}
\]

则 \(b_k\to0\)。对 \(0<\varepsilon\le1\)，Cauchy--Schwarz 给出

\[
\begin{aligned}
\int_{2^k}^{2^{k+1}}|R(X)|X^{-\beta-\varepsilon-1}dX
&\le A_k^{1/2}
\left(\int_{2^k}^{2^{k+1}}X^{-2\beta-2\varepsilon-2}dX\right)^{1/2}\\
&\le C_\beta b_k k^{q-1}2^{-k\varepsilon}.
\end{aligned}
\tag{8}
\]

故 (5) 在 \(\Re s>\beta\) 绝对、局部一致收敛并全纯；恒等定理使它等于 \(G\) 的亚纯延拓。
沿 \(s=\rho+\varepsilon\)，

\[
|F(\rho+\varepsilon)|
\le O(1)+C_\beta\sum_{k\ge1}b_kk^{q-1}2^{-k\varepsilon}.
\tag{9}
\]

给定 \(\delta>0\)，尾部有 \(|b_k|\le\delta\)，而

\[
\varepsilon^q\sum_{k\ge1}k^{q-1}2^{-k\varepsilon}
\longrightarrow\frac{\Gamma(q)}{(\log2)^q}.
\tag{10}
\]

先令 \(\varepsilon\downarrow0\)，再令 \(\delta\downarrow0\)，即得

\[
\varepsilon^qF(\rho+\varepsilon)\longrightarrow0.
\tag{11}
\]

但极点给出

\[
\varepsilon^qG(\rho+\varepsilon)\longrightarrow c_\rho\ne0,
\tag{12}
\]

矛盾。\(\square\)

### 3.2 从连续质量到整数样本

引理 1 的证明已经给出一个由整数 dyadic 点
\(Y_j=2^{k_j}\) 组成的子列。对 \(X\in(N-1,N]\)，note 064 的探针满足

\[
R_w(X)-R_w(N)=O_w(\log(2N)).
\tag{13}
\]

这是 note 064 的取整估计。由

\[
|R_w(X)|^2
\le2|R_w(N)|^2+O_w(\log^2(2N))
\tag{14}
\]

以及精确分割

\[
[Y,2Y]=\bigcup_{Y<N\le2Y}(N-1,N],
\tag{14a}
\]

(6) 给出

\[
\sum_{Y_j<N\le2Y_j}|R_w(N)|^2
\gg_{\rho,w}Y_j^{2\beta+1}(\log Y_j)^{2q-2}.
\tag{15}
\]

取整误差只有

\[
O_w(Y\log^2Y)
=o\!\left(Y^{2\beta+1}(\log Y)^{2q-2}\right)
\qquad(\beta>0),
\tag{16}
\]

故不损失主尺度。

### 3.3 平均首壳零点探测定理

note 064 的精确探针与 Cauchy--Schwarz 给出

\[
|R_w(N)|^2
\le C_wN\log^2N\,\mathcal E_N^{\rm Sel}.
\tag{17}
\]

将 (15) 代入 (17)，得到：

**定理 2（离线零的 dyadic 平均放大）。** 若
\(\zeta(\rho)=0\)、\(\rho=\beta+i\gamma\)、\(\beta>1/2\)，则存在
\(c_\rho>0\) 和 \(Y_j\to\infty\)，使

\[
\boxed{
\overline{\mathcal E}(Y_j)
\ge c_\rho Y_j^{2\beta-1}(\log Y_j)^{2q-4}.
}
\tag{18}
\]

等价地，

\[
\limsup_{Y\to\infty}
\frac{(\log Y)^{4-2q}}{Y^{2\beta-1}}
\overline{\mathcal E}(Y)>0.
\tag{19}
\]

简单零点 \(q=1\) 时，(18) 正是
\(\overline{\mathcal E}(Y_j)\gg Y_j^{2\beta-1}/\log^2Y_j\)。

**推论 3（次幂平均首壳 RH 判据）。** 若对每个 \(\varepsilon>0\)，仅在 dyadic 点上已有

\[
\boxed{
\overline{\mathcal E}(2^k)\ll_\varepsilon 2^{k\varepsilon},
}
\tag{20}
\]

则 RH 成立。特别地，在全部 \(Y\) 上证明
\(\overline{\mathcal E}(Y)\ll(\log Y)^A\) 或
\(\overline{\mathcal E}(Y)=O(1)\) 均足够。

**证明。** 若有 \(\beta>1/2\)，取
\(0<\varepsilon<2\beta-1\)；(18) 与 (20) 矛盾。功能方程关于
\(\Re s=1/2\) 的对称性排除 \(\beta<1/2\)。\(\square\)

更一般地，若某个 \(\theta\ge0\) 在 \(Y=2^k\) 上满足

\[
\overline{\mathcal E}(Y)\ll Y^{\theta+o(1)},
\tag{21}
\]

则

\[
\boxed{
\zeta(\rho)=0\quad\Longrightarrow\quad
\Re\rho\le\frac{1+\theta}{2}.
}
\tag{22}
\]

## 4. 直接测量

使用 note 064 的逐 unit-cell 精确公式，流式计算
\(Y=2^k\)、\(8\le k\le20\) 的全部 \(Y<N\le2Y\)：

\[
\begin{array}{c|c|c}
Y&\overline{\mathcal E}(Y)&(\log Y)^2\overline{\mathcal E}(Y)\\ \hline
2^8&6.25029\cdot10^{-4}&0.0192190\\
2^{10}&4.61737\cdot10^{-4}&0.0221843\\
2^{12}&2.51009\cdot10^{-4}&0.0173661\\
2^{14}&2.06569\cdot10^{-4}&0.0194524\\
2^{16}&1.30576\cdot10^{-4}&0.0160603\\
2^{18}&1.27290\cdot10^{-4}&0.0198149\\
2^{20}&9.68828\cdot10^{-5}&0.0186190
\end{array}
\tag{22a}
\]

在全部 13 个块上，

\[
\operatorname{mean}\bigl((\log Y)^2\overline{\mathcal E}(Y)\bigr)=0.019591,
\qquad
\mathrm{CV}=0.0844.
\tag{22b}
\]

对 \(\overline{\mathcal E}(Y)=c(\log Y)^{-p}\) 作对数拟合得到

\[
p=2.054,
\qquad R^2=0.979.
\tag{22c}
\]

每个块内最大单项只为块均值的 \(1.08\)--\(1.60\) 倍；\(Y=2^{20}\) 时最大单项只占
块总和的 \(1.19\cdot10^{-6}\)。因此所见平均并非由稀疏尖峰制造。小尺度独立除数筛与
精确公式相对一致到 \(1.1\cdot10^{-10}\)。这些数据支持

\[
\overline{\mathcal E}(Y)\asymp\frac{1}{\log^2Y},
\tag{22d}
\]

但不构成 (20) 的一致上界。

## 5. 回顾与下一最简单元

令 note 064 的显式首壳余项为

\[
D_N(y)=A_Ny+M(\lfloor y\rfloor)-M(N)
-\frac{\Psi(\lfloor y\rfloor)+J(\lfloor y\rfloor)-J(N)}{\log N}.
\tag{23}
\]

则

\[
\mathcal E_N^{\rm Sel}
=\int_N^{2N}\frac{|D_N(y)|^2}{y^2}dy.
\tag{24}
\]

因此新目标不是逐点证明
\(\int_N^{2N}|D_N|^2=o(N^2)\)，而只是

\[
\boxed{
\sum_{Y<N\le2Y}\int_N^{2N}|D_N(y)|^2dy
\ll_\varepsilon Y^{3+\varepsilon}
\qquad(\forall\varepsilon>0).
}
\tag{25}
\]

平凡估计 \(|r_N|\le N+1\) 只给

\[
\overline{\mathcal E}(Y)\ll Y,
\tag{26}
\]

所以剩余问题是：**跨截断参数 \(N\) 平均时节省一个完整幂。**

```mermaid
flowchart TD
  A["旧目标: 每个 N 上 I_N=o(N²)"] --> B["新目标: Σ_{N∼Y} I_N≤Y^{3+o(1)}"]
  C["平凡: Σ I_N≤Y⁴"] --> B
  B --> D["需从 N-average 获得一整幂"]
```

## 6. 证据边界

- (5)--(12) 是本 note 的一般 Mellin--dyadic \(L^2\) 引理。
- (13)、(17) 及 \(R_w\) 在 \(\rho\) 的非零 \(q\) 阶极点来自 note 064 的已证恒等式。
- (18)--(25) 是本 note 的新推论；截至本次工作尚未检索到相同表述，不作绝对首创声明。
- (22a)--(22d) 是有限尺度路线判别，不是渐近证据。
- 本 note 没有证明 (20) 或 (25)，因而尚未证明 RH。
