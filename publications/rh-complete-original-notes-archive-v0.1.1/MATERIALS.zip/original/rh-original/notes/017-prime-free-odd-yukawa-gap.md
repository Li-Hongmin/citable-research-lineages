> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Prime-free 奇扇区的显式 Yukawa 谱隙

日期：2026-08-11。本文证明完整局部 Weil 算子的奇扇区在第一个 prime-power 阈值以前一致严格
为正。证明把 digamma multiplier 分解成正 Yukawa resolvent 之和，只需十五个
Dirichlet--Robin 频率的初等区间证书。

## 1. 定理

令

\[
a_*=\frac{\log2}{2}.
\]

则对全部 \(0<a\le a_*\)，

\[
\boxed{
A_a^-\succeq
0.0102973827753\,I>0.}
\]

特别地，prime-free 区间内不存在奇零模态、奇负谱或奇扇区的首次退化。

## 2. Digamma--Yukawa 分解

令

\[
b_n=n+\frac14,\qquad c_n=2b_n,
\qquad
C_\infty=\psi(1/4)-\log\pi.
\]

prime-free 约化算子的全直线 Fourier multiplier 为

\[
m(\xi)
=\operatorname{Re}\psi\!\left(\frac14+\frac{i\xi}{2}\right)-\log\pi.
\]

由 digamma 级数，

\[
\boxed{
m(\xi)
=C_\infty+
\sum_{n=0}^\infty
\frac1{b_n}\frac{\xi^2}{\xi^2+c_n^2}.}
\]

记

\[
R_c=(-\partial_x^2+c^2)^{-1},
\qquad
R_c(x,y)=\frac{e^{-c|x-y|}}{2c}.
\]

则每个 summand 对应正算子

\[
T_n
=\frac1{b_n}(I-c_n^2R_{c_n})\succeq0.
\]

对支撑于 \((-a,a)\) 的函数采用零延拓。由单调收敛，上式首先在测试函数上成立，随后延拓到
完整 logarithmic form domain。

## 3. 奇空间压缩的精确范数

把 \(R_c\) 压缩到 \(L^2(-a,a)\) 的奇子空间。其非零特征对满足

\[
(-v''+c^2v)=\lambda^{-1}v,
\qquad
v(0)=0,
\qquad
v'(a)=-cv(a).
\]

因为压缩 resolvent 的范数严格小于 \(c^{-2}\)，可写

\[
\lambda=\frac1{c^2+\mu^2},
\]

其中

\[
\mu\cot(\mu a)=-c.
\]

半区折叠核

\[
\frac{e^{-c|x-y|}-e^{-c(x+y)}}{2c}>0
\qquad(0<x,y<a)
\]

是 positivity improving 的，故最大本征值对应无内部零点的第一个 Robin 模式。又函数
\(f_c(\mu)=\mu\cot(\mu a)+c\) 在

\[
\left(\frac{\pi}{2a},\frac{\pi}{a}\right)
\]

严格递减：令 \(z=\mu a\in(\pi/2,\pi)\)，则

\[
f_c'(\mu)
=\frac{\sin z\cos z-z}{\sin^2z}<0.
\]

它从正值变到 \(-\infty\)，故有唯一根 \(\mu_c\)。因此

\[
\left\|P_{\rm odd}R_cP_{\rm odd}\right\|
=\frac1{c^2+\mu_c^2},
\]

从而

\[
\boxed{
P_{\rm odd}T_nP_{\rm odd}
\succeq
\ell_n(a)I,\qquad
\ell_n(a)=
\frac1{b_n}
\frac{\mu_{c_n}(a)^2}
{\mu_{c_n}(a)^2+c_n^2}.}
\]

## 4. 十五项证书

固定 \(a=a_*\)。对 \(n=0,\dots,14\)，取

\[
\begin{aligned}
\underline\mu_n={}&
4.829994,\ 5.721068,\ 6.318106,\ 6.745143,\ 7.064005,\\
&7.309939,\ 7.504615,\ 7.662065,\ 7.791735,\ 7.900191,\\
&7.992122,\ 8.070956,\ 8.139251,\ 8.198950,\ 8.251553.
\end{aligned}
\]

Arb 有向球算术逐项验证

\[
\frac{\pi}{2a_*}<\underline\mu_n<\frac{\pi}{a_*},
\qquad
f_{c_n}(\underline\mu_n)>0.
\]

由 \(f_{c_n}'<0\)，有 \(\mu_{c_n}>\underline\mu_n\)。又因
\(\mu\mapsto\mu^2/(\mu^2+c_n^2)\) 严格递增，

\[
\begin{aligned}
M_{a_*}^-
&\succeq
\left(
C_\infty+
\sum_{n=0}^{14}
\frac{\underline\mu_n^2}
{b_n(\underline\mu_n^2+c_n^2)}
\right)I\\
&\succeq
0.0242569834019\,I.
\end{aligned}
\]

遗漏的 \(n\ge15\) 项全部非负，所以有限截断方向正确。

## 5. 恢复极点负秩一项

由精确极点分解，

\[
A_a^-=M_a^--2|s\rangle\langle s|,
\qquad
s(x)=\sinh(x/2).
\]

在 \((-a_*,a_*)\) 上，

\[
2\|s\|_2^2
=2(\sinh a_*-a_*)
<0.0139596006267.
\]

故

\[
\begin{aligned}
A_{a_*}^-
&\succeq
\bigl(0.0242569834019
-0.0139596006267\bigr)I\\
&\succeq
\boxed{0.0102973827753\,I}.
\end{aligned}
\]

在 \(a=a_*\) 时，唯一可能激活的 \(n=2\) 平移恰等于区间直径；其内部相关项为零，而 jump
对角常数与 scalar constant 精确抵消。因此端点仍由上述纯 Archimedean multiplier 描述。

最后，由奇子空间上的零延拓域单调性，

\[
0<a\le a_*
\quad\Longrightarrow\quad
\lambda_1^-(a)\ge\lambda_1^-(a_*),
\]

定理得证。

同时 \(M_a^-=A_a^-+2|s\rangle\langle s|>0\)。严格秩一 Schur 判据进一步给出

\[
\boxed{
1-2\left\langle(M_a^-)^{-1}s,s\right\rangle>0
\qquad
\left(0<a\le\frac12\log2\right).}
\]

所以该区间内不仅没有不可见奇核，奇 Schur 标量也严格远离零。

## 6. 可复现证书

证书脚本：
[verify_prime_free_odd_yukawa_bound.py](../computations/verify_prime_free_odd_yukawa_bound.py)

运行：

~~~bash
uv run --with python-flint python \
  computations/verify_prime_free_odd_yukawa_bound.py
~~~

关键输出为

~~~text
M_odd_lower=[0.02425698340193859 ...]
polar_norm_upper=[0.01395960062660221 ...]
A_odd_lower=[0.01029738277533637 ...]
certified_positive=True
~~~

脚本不使用浮点求根。十五个十进制下界被当作精确输入，所有三角函数、digamma、双曲函数和最终
减法均使用有向球算术。

## 7. 路线含义

note 014 的条件结论

\[
A_a^-\succeq0\Longrightarrow M_a^->0
\]

现在在整个 prime-free 区间被无条件的定量结论取代。note 016 的 supersolution/Barta 路线仍是
合法接口，但在本区间已无继续认证的必要。RH 的下一主铰链因此移到第一个 prime shift 激活后的
奇扇区，以及仍未排除的偶扇区首次退化。
