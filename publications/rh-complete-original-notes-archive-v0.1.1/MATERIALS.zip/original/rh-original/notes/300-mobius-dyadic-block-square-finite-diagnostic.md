> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius dyadic block-square：有限诊断而非渐近证书

日期：2026-08-16。

## 计算对象

对

\[
C_h(N)=\sum_{n\le N-h}\mu(n)\mu(n+h),\qquad
D_H(N)=\sum_{H\le h<2H}C_h(N),
\]

逐个 dyadic (H) 计算
\[
S(N)=\sum_{H<N}|D_H(N)|^2.
\]
相关序列由零填充 FFT 得到，并对前 128 个移位逐项直接求和核对。可复现脚本为
`computations/check_mobius_dyadic_block_square.py`。

## 观测

本地运行得到：

\[
\begin{array}{c|c|c|c}
N&S(N)/N^2&\sqrt{S(N)}/N&\max_H|D_H(N)|/N\\\hline
2^{12}&0.0797732&0.282442&0.167969\\
2^{14}&0.128368&0.358284&0.219055\\
2^{16}&0.111138&0.333373&0.236862\\
2^{18}&0.0525501&0.229238&0.194569\\
2^{20}&0.105132&0.324241&0.191709\\
2^{21}&0.0556180&0.235835&0.132688\\
2^{22}&0.122434&0.349906&0.265374
\end{array}
\]

这些数值没有显示 (S(N)/N^2) 的明显幂次增长；但样本范围有限，且这里是固定端点、无权 dyadic 块，不能替代
\[
S(N)\ll_\varepsilon N^{2+\varepsilon}
\]
的全称证明，也不能替代最大部分和版本或 Mellin 加权版本。

## 裁决

有限计算只支持“固定端点 block-square 候选没有立即数值崩溃”这一弱判断。它没有减少当前主要算术缺口：必须证明跨移位的 signed cancellation；公开的 averaged-Chowla 结果和系数无关的大筛仍不足以给出该门。相关量词差异见
`notes/299-averaged-chowla-does-not-supply-the-correlation-second-moment.md`。
