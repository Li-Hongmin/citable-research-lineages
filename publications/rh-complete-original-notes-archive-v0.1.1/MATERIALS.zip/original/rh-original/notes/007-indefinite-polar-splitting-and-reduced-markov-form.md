> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 极点项的签名 \((1,1)\) 分解与约化形式的绝对值收缩

日期：2026-08-11。本文补齐 README 与 note 006 所引用但此前缺失的承重证明，并纠正“两个极点给出
正秩二”的初始猜想。真实二次型是一个具有绝对值收缩的约化形式，加上签名 \((1,1)\) 的有限秩项；
在偶扇区它是正秩一，在奇扇区它是负秩一。

## 1. 从 Suzuki 的 \(r_0\) 项开始

Suzuki 把光滑余项写成 \(r=r_0+r_1\)，其中

\[
r_0(t)=-4\bigl(e^{t/2}+e^{-t/2}-2\bigr),
\qquad
r_0''(t)=-e^{t/2}-e^{-t/2}.
\]

在 Weil 形式中该项以

\[
-\iint r_0''(x-y)v(y)\overline{v(x)}\,dy\,dx
\]

出现。定义

\[
p_+(v)=\int_{-a}^ae^{x/2}v(x)\,dx,
\qquad
p_-(v)=\int_{-a}^ae^{-x/2}v(x)\,dx.
\]

直接分离变量得到

\[
\boxed{
q_{\rm pol}(v)
=2\operatorname{Re}\bigl(p_+(v)\overline{p_-(v)}\bigr).}
\]

这不是 \(|p_+|^2+|p_-|^2\)。取新坐标

\[
c(v)=\frac{p_+(v)+p_-(v)}2
=\int_{-a}^a\cosh(x/2)v(x)\,dx,
\]

\[
s(v)=\frac{p_+(v)-p_-(v)}2
=\int_{-a}^a\sinh(x/2)v(x)\,dx,
\]

则

\[
\boxed{q_{\rm pol}(v)=2|c(v)|^2-2|s(v)|^2.}
\]

所以有限秩项的非零签名为 \((1,1)\)。

## 2. 奇偶扇区各只剩一个秩一项

完整形式和定义域都在反射 \(v(x)\mapsto v(-x)\) 下不变。若 \(v\) 为偶函数，则 \(s(v)=0\)；
若 \(v\) 为奇函数，则 \(c(v)=0\)。因此

\[
q_{\rm pol}^+(v)=2|\langle v,\cosh(x/2)\rangle|^2,
\]

\[
q_{\rm pol}^-(v)=-2|\langle v,\sinh(x/2)\rangle|^2.
\]

令

\[
q_a^{\rm red}:=Q_W^a-q_{\rm pol}.
\]

相应算子在奇偶扇区形式上写成

\[
\boxed{
A_a^+=M_a^++2|\cosh(x/2)\rangle\langle\cosh(x/2)|,}
\]

\[
\boxed{
A_a^-=M_a^--2|\sinh(x/2)\rangle\langle\sinh(x/2)|.}
\]

所有矩函数都在有限区间上属于 \(L^2\)，所以该有限秩分解从测试函数连续延拓到完整定义域
\(H((-a,a))\)。约化形式与完整形式有相同定义域、闭性和下有界性。

## 3. 约化普通核严格非正

note 005 给出完整非对角普通核

\[
h(t)=2\cosh(|t|/2)
-\frac{e^{-|t|/2}}{1-e^{-2|t|}}.
\]

减去 \(r_0\) 产生的 \(2\cosh(|t|/2)\) 后，约化普通核恰为

\[
\boxed{
h_{\rm red}(t)
=-\frac{e^{-|t|/2}}{1-e^{-2|t|}}<0
\qquad(t\ne0).}
\]

prime-power 原子在完整形式中本来就是

\[
-\sum_{n\le e^{2a}}\frac{\Lambda(n)}{\sqrt n}
\bigl(\delta_{\log n}+\delta_{-\log n}\bigr),
\]

也全部具有非正的非对角系数。其余对角/乘法项不影响绝对值比较。

## 4. 全尺度绝对值收缩

对实值或复值 \(v\)，有

\[
|v(x)||v(y)|-\operatorname{Re}(v(x)\overline{v(y)})\ge0.
\]

把它分别与严格负的 \(h_{\rm red}(x-y)\) 以及负 prime-shift 系数相乘并积分，得到

\[
\boxed{
q_a^{\rm red}(|v|)\le q_a^{\rm red}(v)
\qquad\forall v\in H((-a,a)),\ \forall a>0.}
\]

对约化形式加上足够大的常数倍 \(L^2\) 范数后，这就是第一 Beurling--Deny 判据。因此相应的
约化半群保持正性。

这里还可严格升级为 positivity improving。若可测集 \(E\subset(-a,a)\) 对约化半群不变，则标准
形式判据要求

\[
q_a^{\rm red}(\mathbf1_Eu,\mathbf1_{E^c}u)=0
\]

对允许的 \(u\) 成立。取跨越 \(E\) 与 \(E^c\) 的非负近似函数；连续交叉核
\(h_{\rm red}(x-y)<0\) 对几乎所有不同点严格为负，所以当 \(|E|,|E^c|>0\) 时交叉形式严格负，
与不变性矛盾。故约化形式不可约。于是

\[
\boxed{e^{-tM_a}\text{ positivity improving}\qquad(t>0).}
\]

紧预解式再给出：\(M_a\) 的全空间最低本征值简单，其本征函数可取严格正 a.e.；反射不变性迫使
这个本征函数为偶函数。

纯跳形式的完整常数、严格模等号刻画及由此得到的全尺度严格奇扇区谱隙，见后续的
[note 008](008-reduced-ground-state-and-odd-spectral-gap.md)。

## 5. 为什么这不恢复完整形式的正性

偶扇区的正秩一项

\[
+2|\cosh\rangle\langle\cosh|
\]

惩罚与正函数 \(\cosh(x/2)\) 的重叠，可能使最低向量通过换号来降低能量；它不保持
Beurling--Deny 收缩。奇扇区的负秩一项虽然降低沿 \(\sinh(x/2)\) 的方向，但奇函数在全区间本来
就换号。因此

\[
q_a^{\rm red}\text{ Markov}
\quad\not\Longrightarrow\quad
Q_W^a\text{ Markov 或完整基态非负}.
\]

这与 note 005 对 \(a>1/6\) 构造的完整形式反例完全相容：破坏绝对值收缩的正是已分离出的
极点有限秩项，而不是约化连续/prime 跳跃核。

## 6. 合法的 Schur 补目标

若 \(0\in\rho(M_a^+)\)，则偶扇区零模态满足标量判据

\[
1+2\langle\cosh,(M_a^+)^{-1}\cosh\rangle=0.
\]

若 \(0\in\rho(M_a^-)\)，奇扇区对应

\[
1-2\langle\sinh,(M_a^-)^{-1}\sinh\rangle=0.
\]

必须另行处理 \(M_a^\pm\) 在零点不可逆以及与秩一向量正交的不可见核。本文只建立正确的符号与
约化 Markov 结构，不宣称这些标量函数已经非零。

秩一交错还给出一个无条件的负指标预算。正秩一偶扰动只能使负指标减少至多一，负秩一奇扰动只能
使负指标增加至多一：

\[
N_-(M_a^+)-1\le N_-(A_a^+)\le N_-(M_a^+),
\]

\[
N_-(M_a^-)\le N_-(A_a^-)\le N_-(M_a^-)+1.
\]

因此完整形式与约化形式的负指标之差绝对值至多二。这个预算不能证明正性，但能在后续 Galerkin
或 crossing 计算中区分“约化谱已经为负”与“仅由极点秩一项制造的负方向”。

## 7. 来源与新结论边界

承重输入为 Masatoshi Suzuki, *Weil's quadratic form via the screw function*,
[arXiv:2606.09096](https://arxiv.org/abs/2606.09096)，公式 (2.5) 及其
\(r=r_0+r_1\) 分解。

签名 \((1,1)\) 化简、奇偶秩一公式、约化核的严格负号、全尺度绝对值收缩、约化半群的不可约性，
以及负指标预算，是本项目对 Suzuki 公式的推论。本文没有证明完整 Weil 基态定号，也没有证明
Schur 补函数全尺度非消失。
