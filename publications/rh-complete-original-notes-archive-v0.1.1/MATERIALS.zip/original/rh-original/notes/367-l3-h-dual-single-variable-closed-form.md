> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(L=3\) h-对偶系数的单变量闭式

日期：2026-08-17。

本 note 给出 note 366 的 h-对偶系数在 \(L=3\) 时的另一种精确重写。
它不声称该系数锥对全 \(m\) 正，也不触及 Möbius signed energy；作用是
把 \(L=3\) 的有限二项式平滑压成一个可直接研究的单变量有理表达式。

## 1. 定义

令
\[
D=3m+3,\qquad d=D-2,\qquad R_q=D-q-1,
\]
并沿用 note 157 的 \(K_q\)（包括 \(K_1=-3w_2\)）。令
\[
\mathcal G_{m,3}(r)=
\sum_{q=1}^{m+1}K_q\sum_{s=0}^{R_q}
\binom{R_q}{s}\binom{d-s}{r}
\mathcal F_{q+1,R_q-s}(4),
\]
\[
H_{m,3}(x)=\sum_{r=0}^{d}\mathcal G_{m,3}(r)x^r,\qquad y=1+x.
\]

由二项式定理，若
\[
U_q(y):=\sum_{r=0}^{d}y^r\sum_{s=0}^{R_q}
\binom{R_q}{s}\binom{d-s}{r}\mathcal F_{q+1,R_q-s}(4),
\]
把 \(t=R_q-s\) 换入并使用
\(\sum_r\binom{q-1+t}{r}x^r=(1+x)^{q-1+t}\)，得到
\[
U_q(y)=y^{q-1}\sum_{t=0}^{R_q}\binom{R_q}{t}y^t
\mathcal F_{q+1,t}(4).
\tag{1}
\]

## 2. 指数闭式

对 \(a,t\ge1\)，Stirling 卷积满足
\[
\mathcal F_{a,t}(4)=
2^{a+t}+3^a+3^t-5(2^a+2^t)+10,
\tag{2}
\]
而
\[
\mathcal F_{a,0}(4)=4^a-4\cdot3^a+6\cdot2^a-4.
\tag{3}
\]

把 (2) 形式地延拓到 \(t=0\)，端点修正为
\[
\Delta_a=4^a-5\cdot3^a+10\cdot2^a-10.
\tag{4}
\]
因此，记 \(a=q+1\)，由二项式定理从 (1) 得到严格恒等式
\[
\begin{aligned}
U_q(y)=y^{q-1}\bigl[&
(2^{q+1}-5)(1+2y)^{R_q}+(1+3y)^{R_q}\\
&+(3^{q+1}-5\cdot2^{q+1}+10)(1+y)^{R_q}
\Delta_{q+1}\bigr].
\end{aligned}
\tag{5}
\]

## 3. 单变量闭式

令
\[
B_1=1+y,\qquad B_2=1+2y,\qquad B_3=1+3y,
\qquad K(z)=\sum_{q=1}^{m+1}K_qz^q.
\]
将 (5) 对 \(q\) 求和，得到
\[
\boxed{
\begin{aligned}
H_{m,3}(x)=\frac1y\bigl\{&
B_2^{D-1}\,[2K(2y/B_2)-5K(y/B_2)]\\
&B_3^{D-1}K(y/B_3)\\
&B_1^{D-1}\,[3K(3y/B_1)-10K(2y/B_1)+10K(y/B_1)]\\
&4K(4y)-15K(3y)+20K(2y)-10K(y)\bigr\},
\qquad y=1+x.
\end{aligned}}
\tag{6}
\]

所有分母在 \(x\ge0\) 上严格为正，因此 (6) 是一个单变量有理函数的
精确表示。它没有消除 \(K_q\) 的符号问题；各个有限差分块仍可能变号。

## 4. 精确核对与边界

公式 (6) 只使用有限二项式恒等式和 (2)--(4)。脚本
computations/verify_l3_hdual_closed_form.py 用 Fraction 在
\(m=1,\ldots,8\) 及多个有理 \(y>0\) 上逐点比较 (1) 与 (6)，全部相等。
该核对不是无限 \(m\) 证明。

另一次独立的 Fraction 扫描直接调用 note 156 的原始 gamma 闭式，检查了
完整的 \(L=3\) 行 \(h=0,\ldots,3m+1\) 至 \(m=84\)：所有值均非负；
\(m=1,2\) 的整行严格为零，\(m=3\) 的最小值为 \(928/15\)，而
\(m\ge4\) 的扫描最小值均出现在 \(h=0\)。该运行在进入 \(m=85\) 前因
有理数规模增长而手动停止，因此它只是扩大的有限证据，不能外推为全
\(m\) 正性定理。

当前可审计的剩余问题可以写成：证明 (6) 在 \(x\ge0\) 的系数
\([x^r]\) 全非负，或构造一个精确负系数。即使 \(L=3\) 系数层最终闭合，
Möbius reciprocal-product 的平方根级 signed estimate 仍是独立的
RH-strength 算术门。
