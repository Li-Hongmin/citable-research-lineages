> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 419. 有限尺度滤波器的单位圆零点门

## 1. 抽象尺度滤波

令 \(a=\log q>0\)，\(P(z)=\sum_{j=0}^{J}c_jz^j\) 为实系数多项式。对有限
对数测度
\[
 \nu=\sum_n b_n\delta_{\log n}
\]
定义尺度滤波
\[
 T_P\nu=\sum_{j=0}^{J}c_j\,\tau_{ja}\nu ,
\]
其中 \(\tau_u\) 表示平移 \(u\)。基础 Lehmer 核是
\[
 \ell(t)=e^{-|t|},\qquad \widehat\ell(\xi)=\frac{2}{1+\xi^2}.
\]

## 2. 精确符号公式

令 \(E_0(\nu)\) 为 \(\ell\) 的二次型，令 \(E_P(\nu)\) 为
\(T_P\nu\) 的同一二次型。平移展开给出
\[
 K_P(t)=\sum_{j,k=0}^{J}c_jc_k\,\ell(t+(j-k)a),
 \tag{1}
\]
以及
\[
 \boxed{
 \widehat K_P(\xi)
 =\frac{2}{1+\xi^2}
 \left|\sum_{j=0}^{J}c_je^{ija\xi}\right|^2
 =\frac{2|P(e^{ia\xi})|^2}{1+\xi^2}.
 }
 \tag{2}
\]
因此
\[
 E_P(\nu)=\frac1{2\pi}\int_{\mathbb R}
 \widehat K_P(\xi)\,|\widehat\nu(\xi)|^2\,d\xi .
 \tag{3}
\]
这是一条有限测度恒等式，不使用 Möbius 估计。

## 3. 无单位圆根时的谱等价

若
\[
 m_P:=\min_{|z|=1}|P(z)|>0,\qquad
 M_P:=\max_{|z|=1}|P(z)|,
\]
则由 (2) 对任意有限 \(\nu\) 有
\[
 \boxed{
 m_P^2E_0(\nu)\le E_P(\nu)\le M_P^2E_0(\nu).
 }
 \tag{4}
\]
更一般地，对有限个滤波器 \(P_1,\ldots,P_r\)，若
\[
 \min_{|z|=1}\sum_{\ell=1}^{r}|P_\ell(z)|^2>0,
\]
则它们的能量和与 \(E_0\) 谱等价。故任何没有单位圆共同零点的有限尺度
正滤波族，都只是基础 Lehmer/Möbius 能量的有界重标。

## 4. 两个容易混淆的多项式

principal filter 对应 \(P_+(z)=2-z\)，满足
\[
 |P_+(e^{i\theta})|^2=5-4\cos\theta\in[1,9].
\]
常被用来消除 reciprocal 尾部常数模态的滤波器
\(P_-(z)=1-2z\) 却满足完全相同的连续频谱权：
\[
 |P_-(e^{i\theta})|^2=5-4\cos\theta\in[1,9].
\]
所以 \(P_-(1/2)=0\) 所删掉的是有限截断的边界尾模态，而不是 log-Fourier
频谱中的一个单位圆零点；它不能凭连续谱正性本身绕开 RH 门。

## 5. 路线边界

式 (4) 给出一个统一判据：若滤波多项式在单位圆上无零点，则其自然的
\(Y^{1+\varepsilon}\) 能量界与基础 Möbius Lehmer 能量界等价，因而仍是
RH-strength。唯一尚未被这个谱等价排除的有限滤波路线，是让所有使用的
多项式在同一单位圆频率有共同零点；此时必须另行控制被留下的边界或零模，
而不能从正定 Gram 结构自动恢复它。该判据是结构性归约，不是 RH 证明。

## 6. 可复核例子

verify_finite_scale_filter_symbol.py 对 \(P_+\) 和 \(P_-\) 在一组均匀实频率上
核验 (2)--(4) 的精确幅度范围；有限采样只用于检查代数归一化，不外推全频谱结论。
