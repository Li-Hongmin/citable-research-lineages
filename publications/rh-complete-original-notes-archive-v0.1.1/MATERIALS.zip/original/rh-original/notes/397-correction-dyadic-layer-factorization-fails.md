> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 二进制层分解的精确校正：绝对值折点阻止 Toeplitz 张量化

## 1. 错误来源

对 \(m=2^v u\)、\(n=2^w r\)（\(u,r\) 奇数），正确恒等式是
\[
e^{-|\log(m/n)|}
=e^{-\left|\log(u/r)+(v-w)\log2\right|}.
\tag{1}
\]
一般不能改写为
\[
2^{-|v-w|}e^{-|\log(u/r)|},
\]
因为 \(\log(u/r)\) 与 \((v-w)\log2\) 可能异号。于是 dyadic 层核依赖
奇数比值 \(u/r\)，不再是一个与奇数骨架无关的固定 Toeplitz 矩阵。

## 2. 最小精确反例

取 \(q=0\)、\(X=4\)。此时 \(A_q=1\)，非零系数为
\[
b(1)=1,\qquad b(2)=-1,\qquad b(3)=-1.
\]
实际 reciprocal 能量为
\[
\begin{aligned}
Q
&=\sum_{m,n\in\{1,2,3\}}b(m)b(n)\frac{\min(m,n)}{\max(m,n)}\\
&=1+1+1
 +2\left(-\frac12-\frac13+\frac23\right)
=\frac83.
\end{aligned}
\tag{2}
\]

若错误地使用固定层向量 \(c=(1,-1)\)、\(d=(1)\) 及
\(R_{vw}=2^{-|v-w|}\)，则
\[
c^TRc=3,\qquad c^TRd= \frac12,\qquad d^TRd=1,
\]
奇数骨架的交叉项为 \(Q_{01}=-1/3\)，从而错误张量化给出
\[
3+2\cdot\frac12\cdot\left(-\frac13\right)+1
=\frac{11}{3}\ne\frac83.
\tag{3}
\]
差异正是 \(K(1,3)=1/3\) 与 \(K(2,3)=2/3\) 不能由同一个
\(2^{-|v-w|}e^{-|\log(1/3)|}\) 表示。

## 3. 正确的剩余问题

二进制滤波器仍可按 \(2\)-进赋值分层，但每个奇数比值 \(u/r\) 都有自己的
折点位置：
\[
\log(u/r)+(v-w)\log2=0.
\]
因此任何层间谱估计必须同时控制这些 moving-kink kernels 与 Möbius 符号；
不能先把 dyadic 层与奇数骨架分离，再套用固定 AR(1) 谱界。

本校正撤回 note 396 的全部正面结论，但保留其失败诊断：跨奇数骨架的
signed cancellation 仍是必要研究对象，且绝对值折点是新的明确技术障碍。
