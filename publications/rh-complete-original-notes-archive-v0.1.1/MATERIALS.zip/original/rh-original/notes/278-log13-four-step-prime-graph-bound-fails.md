> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(\log 13/2\) 的四步 active-prime 图界不能沿用 \(\log 11/2\) 阈值

日期：2026-08-16。

## 判定的有限命题

沿用 `certify_log11_prime_four_step_degree.py` 中的 grid-free active-prime
Schur 图构造，只把端点从
\[
 a_{11}=\tfrac12\log 11
 \quad\text{改为}\quad
 a_{13}=\tfrac12\log 13.
\]
在新端点，延迟 \(\log 11\) 进入 active set；因此 active integers 为
\[
 2,3,4,5,7,8,9,11.
\]
问题是四步图主要项 \(D_4\) 的全区间上界的四次根，是否仍低于此前
\(\log 11/2\) 证书所达到的阈值。

## 可复现实验

参数化入口为
`computations/bundles/log201over20-local-weil-positivity/sources/certify_log11_prime_four_step_degree.py`。

运行：

```text
uv run --with python-flint python computations/bundles/log201over20-local-weil-positivity/sources/certify_log11_prime_four_step_degree.py 256 13
```

端点 13 的 256-bit Arb 输出为：

\[
\begin{array}{c|c}
 j & \sup D_j\text{ 的 }j\text{ 次根}\\ \hline
 1 & 4.26049544212434904695\ldots\\
 2 & 3.61862112977665131657\ldots\\
 3 & 3.49601821964700961597\ldots\\
 4 & 3.40273922674418103845\ldots
\end{array}
\]

图分割有 367 个端点、366 个开区间；四步最大区间的 Arb 中心约为
\[
[1.27142484254418339367,\,1.28093384546206431761].
\]

作为参数化回归，端点 11 的同一入口给出
\[
\sup D_4^{1/4}=2.93115773570084639789\ldots,
\]
与既有四步证书一致并低于其使用的 \(2.978071\) 上界。

## 结论范围

因此，**同一套四步 active-prime 图主要项不能直接从
\(a=\frac12\log 11\) 外推到 \(a=\frac12\log 13\)**：端点 13 的四次根
\(3.4027392\ldots\) 已高于端点 11 证书的四步根
\(2.9311577\ldots\)。

这只是一个有限图主要项的路线边界。它不证明端点
\(\frac12\log13\) 的完整 even/odd joint-Schur 算子出现负方向，也不否定
端点 13 可能存在另一种更强的尾界；完整局部 Weil 正性仍未由此判定。
下一步若继续推进该端点，必须改变尾估计或直接生成完整 joint-Schur
证书；不能把本四步图界当作全局算术桥。

## 5. 五步路径的探索性回归

在同一 366 个开区间上把路径长度从四步提高到五步，得到（128 位
Arb，作为探索性而非冻结证书）
\[
\sup D_5^{1/5}
=3.3510886010051606620\ldots .
\]
它确实低于四步值 \(3.4027392267441810384\ldots\)，但仍高于端点 11
证书所用的 \(2.978071\) 阈值。因此单纯增加一步不能修复端点 13 的
主要项缺口；还需要新的路径权、尾支付，或完整 joint--Schur 重新构造。
