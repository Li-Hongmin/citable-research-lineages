> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Reciprocal 边界平台延伸到整段截断行区间

日期：2026-08-17。

note 459 的下界只使用了 $k<d$。双曲线公式实际上给出更大的恒定平台，因而
平方根截断的 residual 能量可直接达到 $M_d=N/d$ 的量级。

## 1. 平台恒等式

令

\[
M_d=\left\lfloor\frac Nd\right\rfloor,
\qquad
q=\left\lfloor\frac kd\right\rfloor,
\qquad
Z_{M_d,A}=\sum_{b\le\lfloor M_d/(A+1)\rfloor}
\frac{\mu(b)}b\left(H_{\lfloor M_d/b\rfloor}-H_A\right).
\]

若 $q\le A$，则对所有 $b\ge1$ 都有
$\lfloor q/b\rfloor\le A$。因此 note 459 的式 (1) 中的下限恒为 A，得到

\[
\boxed{
(\mathcal R_{d,A})_k
=\frac{\sqrt{2k+1}}d Z_{M_d,A},
\qquad 1\le k<d(A+1).
}
\tag{1}
\]

令

\[
K_{d,A}=\min\{N-1,d(A+1)-1\}.
\]

则有精确范数下界

\[
\boxed{
\|\mathcal R_{d,A}\|_2^2
\ge \frac{K_{d,A}(K_{d,A}+2)}{d^2}
Z_{M_d,A}^2.
}
\tag{2}
\]

OMEN 用精确有理数核验了 $N=20,31,64$ 的全部 $(d,A)$，包括平台逐行恒等式
与式 (2)。

## 2. 平方根尺度

若 $d(A+1)\le N$，则 $K_{d,A}=d(A+1)-1$，从而

\[
\|\mathcal R_{d,A}\|_2^2
\ge \left((A+1)^2-d^{-2}\right)Z_{M_d,A}^2.
\tag{3}
\]

取 $A\asymp\sqrt{M_d}$，并使用 note 461 的内部截断结论
$Z_{M_d,A}=1+o(1)$，得到

\[
\|\mathcal R_{d,A}\|_2^2\ge (1+o(1))M_d
\]

沿每个 $M_d\to\infty$ 的尺度成立。换言之，平方根截断的 completion residual
不是一个可忽略的小向量；它在一个完整的行平台上携带与 $N/d$ 同阶的能量。

## 3. 含义

这仍不是 RH 反例，因为单个 residual 的 $M_d$ 级能量尚低于允许的
$N^{1+\varepsilon}$ 总门。但它排除了把平方根截断误当作“只剩少数边界行”的
简化：平台长度本身为 $d(A+1)$。任何 completion 方案都必须同时处理这个
平台的 reciprocal 边界常数和 $q>A$ 的非零 signed residual。
