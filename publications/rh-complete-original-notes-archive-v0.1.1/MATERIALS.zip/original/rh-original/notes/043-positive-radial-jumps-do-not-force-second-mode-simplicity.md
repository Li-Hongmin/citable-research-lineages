> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正径向 jumps 不强迫第二谱层简单或为奇

日期：2026-08-11；文献检索截止同日。

在首次退化尺度，惯性关系给出：reduced 算子 \(M_a\) 只有一个负本征值，且其基态简单、为偶；
同时 \(M_a^-\ge0\)。因此不可见零核若存在，位于全局第二谱层。本文判定能否由一维 nonlocal
Sturm 理论直接证明该谱层简单且为奇。

## 1. 一般结构反例

先取四点反射对称距离图，距离 \(1,2,3\) 的 jump weights 为

\[
w_1=\frac15,
\qquad w_2=\frac1{20},
\qquad w_3=1.
\]

所有权重严格为正，图连通，故常数 ground state 唯一且严格正。偶向量

\[
(1,-1,-1,1)
\]

的本征值为

\[
2(w_1+w_2)=\frac12,
\]

而两个奇本征值为

\[
\frac{29\pm\sqrt{265}}{20};
\]

最小者约为 \(0.636>1/2\)。所以第二本征值虽然简单，却由偶扇区取得。

还有一个连续层面的退化反例。在 \((0,4)\) 上取严格正常数 radial jump kernel，并加入距离
\(1,2,3\) 的任意正 atomic jump energies。所有均值零的一周期函数都消掉三个 atomic terms，
而常数 kernel 在该子空间上只给同一个标量能量。因此第二本征空间包含无限维的一周期均值零空间，
同时含偶、奇函数。这个例子没有目标算子的 compact resolvent，但严格说明 positivity improving
与反射对称本身只控制 ground state，不控制第二谱层。

## 2. 最接近的振荡定理不覆盖 prime atoms

Kwaśnicki 对区间 restricted fractional Laplacian \((-\Delta)^s\)、\(0<s<1\)，证明全部本征值
简单；承重输入是 fractional Pohozaev 边界恒等式，而不是 kernel 的一般正性。

Kwaśnicki--Mucha 的 complete-Bernstein extension 对第 \(n\) 个 extension eigenfunction 给出 nodal
parts 上界，但一维边界上只得到至多 \(2n-1\) 个 nodal parts；更强的 \(n\)-part 结论仍是猜想。
这不足以推出第二本征值简单或为奇。

实际 prime atom 的 Fourier multiplier 为

\[
1-\cos(\tau\xi),
\]

它不是 \(\psi(\xi^2)\) 的 complete-Bernstein subordinate-Brownian 类，并会独立移动偶、奇谱支。
因此上述 extension/oscillation 定理不能迁移。

2026 年关于 logarithmic Laplacian 的现有谱结果证明第一本征值简单、定号、孤立，并给出第二
本征值的变分表征；它们没有证明第二本征值简单或为奇，也不含 finite atomic shifts。

## 3. 路线结论

\[
\text{positive radial kernel}
+\text{positive finite atomic jumps}
+\text{reflection symmetry}
\not\Longrightarrow
\lambda_2\text{ simple and odd}.
\]

要从第二谱层路线排除不可见核，必须证明 actual prime graph 的严格 parity interlacing，例如

\[
\lambda_1(M_a^+)<\lambda_1(M_a^-)<\lambda_2(M_a^+),
\]

并另证奇扇区 ground simple；或建立目标形专属的 total-positivity/variation-diminishing 定理。
一般 positivity improving 与反射分解不足。

## 4. 直接文献边界

- M. Kwaśnicki, *Simplicity of eigenvalues of the fractional Laplace operator in an interval*,
  arXiv:2311.00713.
- M. Kwaśnicki and J. Mucha, *Extension technique for complete Bernstein functions of the Laplace
  operator*, J. Evol. Equ. 18 (2018), arXiv:1707.02475.
- R. Arora, T. Mukherjee and A. Vaishnavi, *Spectral Properties of the Logarithmic Laplacian with
  Indefinite Weights*, arXiv:2605.13513.

