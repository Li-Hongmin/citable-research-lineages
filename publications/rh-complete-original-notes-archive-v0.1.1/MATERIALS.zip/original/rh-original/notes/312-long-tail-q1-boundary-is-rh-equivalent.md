> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 长移位尾项的 \(q=1\) 边界正好是 RH 等价门

日期：2026-08-16。

沿用 note 310--311 的尾部项
\[
B_U(X)=\sum_{a=U+1}^{2U-1}\sum_{b=X-2U+a+1}^{X-1}\lambda(ab),
\]
其中 \(U\ge2\) 为整数，且 \(\lambda\) 完全乘法。

## 严格边界恒等式

取
\[
X=2U+1.
\]
此时 \(U<X/2\)，所以它仍属于长移位几何，而不是 \(X=2U\) 的退化边界。权重区域变为
\[
U<a<2U,
\qquad a+2\le b\le 2U,
\]
从而
\[
B_U(2U+1)=\sum_{U<a<2U}\lambda(a)
             \sum_{a+2\le b\le2U}\lambda(b).
\tag{1}
\]
令
\[
S_U=\sum_{U<n\le2U}\lambda(n),
\qquad
E_U=\sum_{U<n<2U}\lambda(n)\lambda(n+1).
\]
所有区间内的无序非对角对给出
\[
\sum_{U<a<b\le2U}\lambda(a)\lambda(b)
=\frac{S_U^2-U}{2},
\]
而 (1) 只删除相邻对 \(b=a+1\)。因此有完全精确的恒等式
\[
\boxed{
B_U(2U+1)=\frac{S_U^2-U}{2}-E_U,
}
\tag{2}
\]
以及
\[
S_U^2=2B_U(2U+1)+U+2E_U,
\qquad |E_U|\le U-1.
\tag{3}
\]

## 统一尾项界推出 RH

若对每个 \(\varepsilon>0\) 存在 \(C_\varepsilon\)，使得
\[
|B_U(2U+1)|\le C_\varepsilon U^{1+\varepsilon}
\qquad(U\ge2),
\tag{4}
\]
则由 (3)
\[
|S_U|\ll_\varepsilon U^{1/2+\varepsilon}.
\tag{5}
\]
对任意 \(x\)，取 \(U=\lfloor x/2\rfloor\)，递归分解
\(\sum_{n\le x}\lambda(n)\) 为这些 dyadic 区间；每一步只产生 \(O(1)\) 个端点误差。于是
\[
L(x):=\sum_{n\le x}\lambda(n)
\ll_\varepsilon x^{1/2+\varepsilon}.
\tag{6}
\]
其 Dirichlet 级数为
\[
\sum_{n\ge1}\frac{\lambda(n)}{n^s}
=\frac{\zeta(2s)}{\zeta(s)}.
\]
由 (6) 的 Abel 延拓，该函数在 \(\Re s>1/2\) 全纯。若 \(\zeta(\rho)=0\) 且 \(\Re\rho>1/2\)，则 \(\Re(2\rho)>1\)，故 \(\zeta(2\rho)\ne0\)，上式在 \(\rho\) 有极点，矛盾。因此 (4) 蕴含 RH。

## 反向：RH 给出同一边界界

RH 下的标准 Littlewood--Perron 估计给出
\[
L(x)\ll_\varepsilon x^{1/2+\varepsilon}.
\]
于是 \(S_U=O_\varepsilon(U^{1/2+\varepsilon})\)，而 \(|E_U|\le U-1\)。由 (2) 立即得到
\[
B_U(2U+1)\ll_\varepsilon U^{1+\varepsilon}.
\tag{7}
\]
所以对这条 \(q=1\) 边界，(4) 与 RH 等价。

## 对当前长移位路线的含义

note 309 将长移位剩余区间压缩到 \(U<X/2\) 的宏观反向长度。式 (1) 说明其最靠近边界的一层 \(X=2U+1\) 已经包含完整的 dyadic Liouville 平方；它不是可以由一般 \(\ell^2\) 正性自动解决的“普通尾项”。因此，若要以
\[
B_U(X)\ll X^{1+\varepsilon}
\]
统一关闭长移位门，就必须至少跨过一个 RH 等价的子族。现有 averaged-Chowla 或短区间 \(L^1\) 输入没有提供这条统一界；它们只覆盖小移位平均或尾部的局部范围。

该恒等式不证明 RH，但把 note 310--311 的“截断 divisor-window”缺口 sharpen 成了一个可审计的 RH-equivalent boundary gate。
