> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Poisson 求和的逐频率正性在高层失效

日期：2026-08-15。

一个自然的全局尝试是把 periodization 写成 Poisson 和
\[
P_m(y)=y\sum_{k\in\mathbb Z}\widehat V_m(ky),
\qquad
\widehat V_m(\xi)=\int_0^1V_m(u)e^{-2\pi i\xi u}\,du.
\]
若所有 \(\operatorname{Re}\widehat V_m(\xi)\ge0\)（足够大的 \(\xi\)），则可直接得到正性。
该逐频率路线并不成立。

对 \(m=10\)、\(\xi=2\)，精确积分给出
\[
\operatorname{Re}\widehat V_{10}(2)
=\frac{507967369312528125}{2251799813685248\,\pi^{32}}
\Bigl(
-16455613814640\pi^4-25363193856\pi^8-175055188458150
+234815488\pi^{10}+989705882880\pi^6
+105896693427525\pi^2
\Bigr)
\approx-4.9758813503\times10^{-10}<0.
\]
括号内多项式用 100 位区间算术严格落在
\([-17879.6867638135,-17879.6867638134]\)，故这里的负号不是浮点误差。

因此即使完整 Poisson 和 \(P_m(y)\) 仍可能为正，也不能依靠每个 Fourier
频率的逐项正性；必须控制频率间的 signed cancellation。这与 \(y\ge2\) 的
Bernstein/falling-factorial 缺口是同一类问题的 Fourier 表现。
