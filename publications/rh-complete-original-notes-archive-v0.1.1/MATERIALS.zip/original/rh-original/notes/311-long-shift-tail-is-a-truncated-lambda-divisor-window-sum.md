> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 长移位尾部双线性项是截断的 \(\lambda(n)d(n)\) 型单和

日期：2026-08-16。

沿用 note 310 的 \(B_U(X)\)，取 \(f=\lambda\) 并使用完全乘法性。
由
\[
B_U(X)=\sum_{1\le j<k<U}\lambda(2U-k)\lambda(X-j)
\]
令
\[
a=2U-k,\qquad b=X-j.
\]
则得到完全精确的 divisor-window 表示
\[
\boxed{
B_U(X)=
\sum_{a=U+1}^{2U-1}
\sum_{b=X-2U+a+1}^{X-1}\lambda(ab).
}
\tag{1}
\]
若定义正整数权
\[
w_{U,X}(r)=
\#\left\{(a,b):
U<a<2U,\ X-2U+a<b<X,\ ab=r\right\},
\]
则
\[
B_U(X)=\sum_r\lambda(r)w_{U,X}(r).
\tag{2}
\]
这里 \(w_{U,X}\) 是一个截断的 divisor-window 权，支持在
\(r\asymp UX\) 的乘积区间；它不是普通平滑权，因此不能直接由
PNT 或 MRT 的加法短区间定理估计。

## 未截断模型的 Dirichlet 级数

若把 divisor-window 权替换为完整的 \(d(r)\)，则
\[
\sum_{r\ge1}\frac{\lambda(r)d(r)}{r^s}
=\prod_p\left(\sum_{j\ge0}(j+1)(-p^{-s})^j\right)
=\prod_p(1+p^{-s})^{-2}
=\frac{\zeta(2s)^2}{\zeta(s)^2},
\qquad \Re s>1.
\tag{3}
\]
因此任何试图对 (2) 给出 \(X^{1+\varepsilon}\) 级统一界的方案，
若能把截断权无损提升到完整 divisor-window 模型，都会直接遇到
\(1/\zeta(s)^2\) 的临界带零点问题。这个计算不证明等价性，因为
\(w_{U,X}\) 仍是有限且依赖 \(X,U\) 的截断权；它只精确说明该尾部
双线性门的自然算术强度。

结论：完全乘法性没有把 \(B_U\) 变成普通正和。它把问题改写成
“截断 \(\lambda(n)d(n)\) 权的 uniform Perron/dispersion 估计”；现有
averaged-Chowla 只处理加法移位平均，尚不能控制这个乘法窗口。
