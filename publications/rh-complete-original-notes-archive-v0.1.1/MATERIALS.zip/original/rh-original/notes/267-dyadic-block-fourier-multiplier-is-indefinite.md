> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Dyadic 相关块的 Fourier multiplier 变号

日期：2026-08-16。

本 note 把 note 223 的滑动窗口恒等式搬到加性 Fourier 侧，精确说明
为什么短区间平方能量的正性不能自动给出 dyadic 相关块的 \(L^2\) 门。
这里的 \(\mathcal B_H\) 是 note 243 中 Mellin 加权块的加性 Fourier
surrogate；原比例核还多一个 \(\min(m,n)/X\) 的位置权。

## 1. 窗口能量的 Fourier 表示

令 \(a=(a_n)\) 是有限支撑序列，零延拓到 \(\mathbb Z\)，并记

\[
 \widehat a(\theta)=\sum_{n\in\mathbb Z}a_ne^{in\theta},\qquad
 D_L(\theta)=\left|\sum_{j=0}^{L-1}e^{ij\theta}\right|^2
 =\left(\frac{\sin(L\theta/2)}{\sin(\theta/2)}\right)^2 .
\]

由 Parseval 和 note 223 的定义，

\[
 \mathcal E_L
 :=\sum_{r\in\mathbb Z}\left|\sum_{n=r}^{r+L-1}a_n\right|^2
 =\frac1{2\pi}\int_{-\pi}^{\pi}
 |\widehat a(\theta)|^2D_L(\theta)\,d\theta .
\tag{1}
\]

而 dyadic 相关块满足精确恒等式

\[
 \mathcal B_H
 :=\sum_{H\le h<2H}\sum_n a_n\overline{a_{n+h}}
 =\frac12(\mathcal E_{2H}-\mathcal E_{2H-1}
 -\mathcal E_H+\mathcal E_{H-1}).
\tag{2}
\]

因此

\[
 \mathcal B_H
 =\frac1{2\pi}\int_{-\pi}^{\pi}
 |\widehat a(\theta)|^2\,b_H(\theta)\,d\theta ,
\quad
 b_H=\frac12(D_{2H}-D_{2H-1}-D_H+D_{H-1}).
\tag{3}
\]

## 2. \(b_H\) 不是正 multiplier

在零频处 \(b_H(0)=H\)，但它在整个频带上变号，而且这对每个
\(H\ge1\) 都成立：每个 Fejér 核 \(D_L\) 的圆周平均值都是 \(2\pi\)，
故
\[
 \int_{-\pi}^{\pi}b_H(\theta)\,d\theta=0,
\]
而 \(b_H(0)=H>0\)，所以 \(b_H\) 不可能处处非负。
最小例子
\(H=1\) 给出

\[
 b_1(\theta)=\cos\theta,
\]

故 \(\mathcal B_1\) 同时接收正、负频带贡献。对于 \(H=2,3\)，直接把
(3) 中的 Fejér 核展开即可得到

\[
 \min_\theta b_2(\theta)<-1.63,\qquad
 \min_\theta b_3(\theta)<-2.43,
\]

而 \(b_H(0)=H\)。这些数值只用于展示变号；变号本身已经由 \(H=1\)
的精确公式严格证明。

因此 \(\mathcal E_L\ge0\) 或者 Menon 型估计
\(\mathcal E_L\ll X L^2\rho(X,L)\) 只控制 \(|\widehat a|^2\) 与每个
非负 Fejér 核 \(D_L\) 的配对，不能控制与变号核 \(b_H\) 的配对。
对一般序列，令 \(|\widehat a|^2\) 集中在 \(b_H<0\) 的频带即可使
\(\mathcal B_H\) 为负且量级不小；对 Möbius 序列，排除这种集中正是新的
算术问题，而不是 Fourier 正性的形式推论。

## 3. 对 RH 能量门的含义

note 243 的加权 block-\(L^2\) 条件在这里先看其加性 surrogate：

\[
 \sum_H|\mathcal B_H|^2\ll_\varepsilon X^{2+\varepsilon}
\]

要求控制 (3) 中的 signed multiplier。Menon 的短区间定理只给出
\(|\widehat a|^2\) 与 \(D_L\) 的平均控制，不能消除 \(b_H\) 的负频带。
所以要从短区间结果继续推进，至少还需一个把 Möbius Fourier 质量限制在
\(b_H\) 正区、或在正负区之间建立抵消的 arithmetic intertwiner。

这把剩余问题从“窗口能量是否足够”具体化为：

\[
 \boxed{
 \text{对 }a_n=\mu(n)\text{，证明 }
 \int |\widehat a(\theta)|^2b_H(\theta)\,d\theta
 \text{ 在所有 dyadic }H\text{ 上具有可平方求和的 signed 界。}
 }
\]

没有这个 signed 结论，任何只使用窗口正性或 Fejér/large-sieve 正 Gram
的路线都不能关闭 \(N^{1+\varepsilon}\) 正能量门。
