> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 完整 squarefree parity completion 的精确恒等式与 twisted-Mertens 门

日期：2026-08-16。

本 note 把完整除数格上的反射 parity 与跨尺度求和精确连接起来。
结论是：若用 \(\mu(X)\) 对完整 squarefree 层做 parity 加权，层间系数
恰好变成带有限 Euler 因子的 coprime Mertens 和；这不是一个独立的
PSD 正性捷径。

## 1. 完整层

令 \(P:(0,\infty)\to\mathbb C\) 为任意函数。对 squarefree \(X\) 定义完整层
\[
 F_X^P(x)
 :=\sum_{a,b\mid X}\mu(a)\mu(b)P\!\left(\frac{x}{ab}\right).
\tag{1}
\]
给定 \(B\ge1\)，考虑 parity 加权完成
\[
 \mathcal C_B^P(x)
 :=\sum_{\substack{X\le B\\X\ {\rm squarefree}}}\mu(X)F_X^P(x).
\tag{2}
\]
把 (1) 代入 (2)，并固定一对 squarefree \(a,b\)。令
\(L=\operatorname{lcm}(a,b)\)。只有 \(X=Ld\)、\((d,L)=1\) 的项出现，且
\(\mu(Ld)=\mu(L)\mu(d)\)。因此得到完全有限的恒等式
\[
\boxed{
\mathcal C_B^P(x)
=\sum_{\substack{a,b\le B\\a,b\ {\rm squarefree}}}
\mu(a)\mu(b)\mu(\operatorname{lcm}(a,b))
P\!\left(\frac{x}{ab}\right)
M_{\operatorname{lcm}(a,b)}
\!\left(\frac{B}{\operatorname{lcm}(a,b)}\right),
}
\tag{3}
\]
其中
\[
 M_L(Y):=\sum_{\substack{d\le Y\\(d,L)=1}}\mu(d).
\tag{4}
\]
若 \(B/L<1\)，约定 \(M_L(B/L)=0\)。式 (3) 不使用任何渐近估计。

## 2. Mellin 端的同一结构

若
\[
 P(y)=\frac1{2\pi}\int_{\mathbb R}H(t)y^{it}\,dt
\]
在所需收敛意义下成立，则完整层还满足
\[
 F_X^P(x)
=\frac1{2\pi}\int_{\mathbb R}H(t)x^{it}
\prod_{p\mid X}(1-p^{-it})^2\,dt.
\tag{5}
\]
因此 parity completion 对每个频率的 \(X\)-系数是
\[
\sum_{\substack{X\le B\\X\ {\rm squarefree}}}
\mu(X)\prod_{p\mid X}(1-p^{-it})^2,
\]
而不是正交投影。回到物理端正是 (3) 中的 \(M_L\)。

带 coprime 条件的和本身有 Dirichlet 级数
\[
\sum_{(d,L)=1}\frac{\mu(d)}{d^s}
=\frac1{\zeta(s)}
\prod_{p\mid L}(1-p^{-s})^{-1},
\qquad \Re s>1.
\tag{6}
\]
所以每个 \(L\)-层仍保留同一个 \(1/\zeta(s)\) 算术门；有限 Euler 因子
只改变局部常数，不提供新的零点消除。

更具体地，展开有限 Euler 因子可得另一个精确恒等式：
\[
\boxed{
 M_L(Y)
 =\sum_{\substack{k\le Y\\\operatorname{rad}(k)\mid L}}
 M\!\left(\left\lfloor\frac{Y}{k}\right\rfloor\right).
}
\tag{7}
\]
这里 \(k\) 的所有素因子都属于 \(L\)；允许 \(k\) 漏掉 \(L\) 中的部分
素因子。证明就是把
\[
\frac1{\zeta(s)}\prod_{p\mid L}(1-p^{-s})^{-1}
\]
按 Dirichlet 级数相乘；系数中 \(k\) 恰好遍历所有
\(L\)-smooth 的倍数 \(k\)。

式 (7) 给出一个量化的条件性检查。若假设 RH 下的
\[
 |M(u)|\ll_\varepsilon u^{1/2+\varepsilon},
\]
则
\[
 |M_L(Y)|
 \ll_{\varepsilon}
 Y^{1/2+\varepsilon}
 \prod_{p\mid L}(1-p^{-1/2-\varepsilon})^{-1}
 =Y^{1/2+\varepsilon}L^{o(1)}.
\tag{8}
\]
因此有限 Euler 因子确实只产生次幂损失；但 (8) 的输入已经是 RH-strength
 的普通 Mertens 界。用当前无条件 zero-free 区估计代入 (7)，只能得到相应的
 \(Y^{1-o(1)}\) 级，而非 \(Y^{1/2+\varepsilon}\)。

## 3. 与实际半格的区别

原始 reciprocal-product 和是
\[
 T_P(x)=\sum_{a,b\le\sqrt x}\mu(a)\mu(b)P(x/(ab)).
\]
它按 \(\operatorname{lcm}(a,b)\) 分层时，宏观 \(L>\sqrt x\) 层被 cutoff
截断；而 \(F_X^P\) 是完整 divisor 层。故 (3) 不能直接替代 \(T_P(x)\)：
二者之间仍有 note 205 所述的 completion/boundary remainder。

即使暂时忽略这个 cutoff remainder，若想利用完整层的反射 parity 把
\(\mathcal C_B^P\) 变成一个正量，仍必须估计所有
\[
 M_L(B/L),\qquad L\le B,
\]
并且估计要对变化的 \(L\) 保持统一。逐项取绝对值只回到 \(B\) 量级；
平方根级的统一界是 twisted-Mertens 输入，而不是由完整格的有限维正性
自动得到。

## 4. 路线裁决

式 (3)--(6) 给出一个新的精确跨尺度接口，但没有关闭 RH。它排除了以下
捷径：

> 先在每个完整 squarefree divisor 格上利用 \(H_X=G_XR_X\) 的 parity，
> 再用 \(\mu(X)\) 跨 \(X\) 求和，便可无条件获得平方根 cancellation。

因为该跨 \(X\) 求和的系数已经是 \(M_L\)，其零自由控制正是原来的
Möbius 算术问题。下一步若继续此路线，必须直接证明统一的
twisted-Mertens/跨层 signed estimate，并同时支付 cutoff completion；普通
Schur 或 PSD parity 不足以完成这两步。
