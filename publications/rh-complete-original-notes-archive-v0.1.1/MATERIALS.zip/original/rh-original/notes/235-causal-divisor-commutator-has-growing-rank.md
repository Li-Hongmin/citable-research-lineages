> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 因果 periodization 与除数算子的交换子：非因子项与增长秩

本 note 记录一个针对 notes 233--234 因果算子路线的严格边界。它不提供 RH 证明，但排除了“把因果算子与除数 incidence 的不交换性吸收到固定秩边界项”这一捷径。

## 1. 定义与精确交换子

在有限指标集 \(1\le a,b,d\le N\) 上令

\[
(A_V)_{a,d}=\mathbf 1_{d\le a}V(d/a),\qquad
D_{d,b}=\mathbf 1_{b\mid d}.
\]

直接计算得到

\[
(A_VD)_{a,b}=\sum_{c\le a/b}V(cb/a)=P_V(a/b),
\]

而

\[
(DA_V)_{a,b}=\sum_{\substack{d\mid a\\d\ge b}}V(b/d).
\]

令 \(q=\lfloor a/b\rfloor\)。在第二式作变量替换 \(c=a/d\) 后，\(c\mid a\)、\(c\le q\)，所以交换子有逐项恒等式

\[
\boxed{
[A_V,D]_{a,b}
=\sum_{\substack{1\le c\le q\\c\nmid a}}V(cb/a).
}
\tag{1}
\]

特别地，\([A_V,D]_{a,b}=0\) 若 \(a<b\)，且整个误差不是只来自 \(a\) 或 \(b\) 的固定端点层，而是由所有非因子整数 \(c\) 组成。

## 2. V15 的严格增长秩证书

取

\[
V_{15}(u)=u^2(1-u)^9Q(u),\qquad
Q(u)=1024u^4+207u^3-57u^2-27u-3.
\]

对 \(i\ge1\)，在交换子中取行 \(a_i=2i+1\)、列 \(b_i=i\)。若 \(j>i\)，则

\[
a_i=2i+1<2j=2b_j,
\]

故由 (1) 得 \([A_{V_{15}},D]_{a_i,b_j}=0\)。当 \(j=i\) 时，\(q=3\)（\(i=1\)）或 \(q=2\)（\(i\ge2\)）；在 \(c\le q\) 中，唯一的非因子项是 \(c=2\)，从而

\[
[A_{V_{15}},D]_{2i+1,i}=V_{15}\!\left(\frac{2i}{2i+1}\right).
\tag{2}
\]

这些对角元都非零。事实上 \(u\in[2/3,1)\) 时 \((1-u)^9u^2>0\)，且 \(Q(u)>0\)：\(Q'(u)=4096u^3+621u^2-114u-27>0\) 在该区间成立，并且 \(Q(2/3)>0\)。因此，取前

\[
r=\left\lfloor\frac{N-1}{2}\right\rfloor
\]

行 \(a_i\) 与列 \(b_i\) 所得子矩阵是下三角且对角线全非零，故

\[
\boxed{
\operatorname{rank}[A_{V_{15}},D]
\ge \left\lfloor\frac{N-1}{2}\right\rfloor .
}
\tag{3}
\]

这是一条特征零的精确秩下界，不依赖浮点扫描。它说明因果 periodization 的除数因子化 \(B_V=A_VD\) 与原始 Möbius 通道之间的差异不能由固定秩 commutator、固定数量 Feshbach 模式或固定数量边界原子吸收。

这里还可以把“秩增长”和“端点衰减”严格分开。令

\[
 a_i=5\cdot3^i,\qquad b_i=2\cdot3^i,
 \qquad 0\le i<r,
\]
并取 \(5\cdot3^{r-1}\le N\)。当 \(j>i\) 时

\[
 a_i=5\cdot3^i<2\cdot3^j=b_j,
\]

故交换子子矩阵的 \((i,j)\) 项为零；而 \(a_i/b_i=5/2\)，且

\[
 [A_{V_{15}},D]_{a_i,b_i}
 =V_{15}(4/5)
 =\frac{4643344}{30517578125}\ne0,
\tag{3a}
\]

因为 \(a_i\) 为奇数，\(c=2\) 是 (1) 中唯一的非因子项。于是这给出一个下三角、对角元完全相同的子矩阵，并且

\[
 \operatorname{rank}[A_{V_{15}},D]
 \ge r
 =1+\left\lfloor\log_3(N/5)\right\rfloor .
\tag{3b}
\]

该几何证书不超过 (3) 的线性秩下界，但它避免了 \(V_{15}(2i/(2i+1))\to0\) 的端点衰减，说明内部比值通道至少以对数个尺度持续存在。需要强调：非零对角线只证明秩，不给出最小奇异值或算子范数的增长；因此 (3a)--(3b) 仍不能推出平方根级 signed 估计。

还可以把这组内部通道稳定化。取一个足够大的整数 \(S\)，并取素数
\(q_i\in(S^i,2S^i)\)（Bertrand 定理保证这样的选择）。令
\(a_i=5q_i,\ b_i=2q_i\)，并要求 \(S/2\ge R>5/2\)。于是
\(q_{i+1}/q_i\ge R\)，且 \(j>i\) 时仍有 \(a_i<b_j\)。对 \(j<i\)，令
\(y_{ij}=a_i/b_j=5q_i/(2q_j)\)。由于 \(q_i\) 是素数且 \(q_j>5\)，
\(a_i\) 的因子只有 \(1,5,q_i,5q_i\)，其中不超过 \(y_{ij}\) 的只有
\(1,5\)。因此 (1) 给出精确式

\[
 [A_{V_{15}},D]_{a_i,b_j}
 =P_{V_{15}}(y_{ij})-V_{15}(1/y_{ij})-V_{15}(5/y_{ij})
 \qquad (j<i).
\tag{3c}
\]

已有端点展开（见 note 174）\(P_{V_{15}}(y)=O(y^{-2})\)，而
\(V_{15}(u)=O(u^2)\)（\(u\to0\)）。故存在常数 \(C_*>0\)，使

\[
 \left|[A_{V_{15}},D]_{a_i,b_j}\right|
 \le C_*\left(\frac{q_j}{q_i}\right)^2
 \le C_*R^{-2(i-j)}.
\tag{3d}
\]

令 \(d_*=V_{15}(4/5)=4643344/30517578125\)。取 \(R\) 足够大，使
\(\varepsilon=C_*/(R^2-1)<d_*/2\)。在上述 \(r\) 个行列组成的子矩阵中，
交换子等于 \(d_*I+L\)，其中 \(L\) 严格下三角，并且
\[
 \|L\|_\infty\le\varepsilon,\qquad
 \|L\|_1\le\varepsilon,\qquad
 \|L\|_2\le\sqrt{\|L\|_1\|L\|_\infty}\le\varepsilon.
\]
从而

\[
 \sigma_{\min}(d_*I+L)\ge d_*-\varepsilon\ge d_*/2.
\tag{3e}
\]

由 Eckart--Young 不等式，对任意固定 \(k\)，当 \(N\) 足够大时，任何秩不超过
\(k\) 的修正都无法把该子块的算子范数压到 \(d_*/2\) 以下；需要的修正秩
至少为 \(r-k\asymp\log N\)。这是比单纯秩证书更强的稳定结论，但仍只涉及
\(\log N\) 个内部通道，尚未给出 \(\sqrt N\) 级 signed 能量估计。

## 3. 对 RH 桥的含义

有限恒等式 \(B_V=A_VD\) 仍然成立，并且 \(D\mu=e_1\)。但要从容易计算的 \(B_V\mu\) 回到未解决的 \(A_V\mu\)，必须控制 \(D^{-1}\) 在 \(A_V^*A_V\) 度量中的作用。公式 (1)--(3e) 表明，最直接的“近似交换”方案有一个随 \(N\) 线性增长的非交换通道，并且至少有对数个稳定内部模式；因此它不能被解释为固定秩的可忽略边界。

这并不排除一个真正的、增长秩且保留 Möbius 符号的算术 intertwiner；它只把该路线的最小缺口精确化为对 (1) 所定义的非因子通道建立平方根级的 signed 估计。

## 4. 精确的 Möbius 分解

从
\[
 A_VD=DA_V+[A_V,D],\qquad D\mu=e_1
\]
左右乘以 \(D^{-1}\)，得到
\[
 A_V\mu
 =D^{-1}A_Ve_1-D^{-1}[A_V,D]\mu.
\tag{4}
\]
第一项完全显式：
\[
 (D^{-1}A_Ve_1)(a)
 =\sum_{d\mid a}\mu(a/d)V(1/d).
\tag{5}
\]
若 \(V(u)=\sum_{r=2}^{D_0}v_ru^r\)，则
\[
 (D^{-1}A_Ve_1)(a)
 =\sum_{r=2}^{D_0}v_r\,a^{-r}\prod_{p\mid a}(1-p^r).
\tag{6}
\]
因此因果—除数路线并没有把困难藏在一个未知的 periodization 输出中：困难精确地集中在
\[
 D^{-1}[A_V,D]\mu,
\]
也就是 (1) 中非因子整数包的 Möbius signed cancellation。秩下界 (3) 说明该包的自由度随尺度增长；式 (4)--(6) 则给出后续任何估计必须处理的具体对象。
