> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 高精度有限筛查仍不能替代全层 periodization 正性证明

日期：2026-08-15。

## 1. 计算对象

对 note 150 的统一 detector

\[
V_m=C_m^{-1}(\Theta-1)\prod_{j=1}^{m-1}(\Theta+2j+1)
\bigl[u^2(1-u)^{3m+1}\bigr],\qquad \Theta=-u\partial_u,
\]

用正因子递推构造

\[
G_{m,m-1}=u^2(1-u)^{2m+2}R_{m,m-1}(u),
\qquad V_m=-C_m^{-1}\frac{d}{du}\bigl(uG_{m,m-1}\bigr).
\]

本次高精度脚本
[search_numeric_periodization_mp.py](../computations/search_numeric_periodization_mp.py)
用整数系数构造 \(R_{m,m-1}\)，再以 100 位精度计算

\[
P_m(y)=\sum_{1\le n\le y}V_m(n/y).
\]

## 2. 有限结果

在 OMEN 上分四段并行检查了

\[
1\le m\le100,
\qquad y=1+\frac{99k}{1000},\quad 0\le k\le1000.
\]

所有网格点均未出现负值；每个已完成层的最小值是端点
\(P_m(1)=0\)。这也与此前的精确有理 Bernstein 检查 \(m\le43\) 一致。

随后用 OMEN 的 32 个 CPU 将同一数值程序扩展到
\(m=1,\ldots,1024\)，并删去端点 \(y=1\)，在
\(y\in(1,12]\) 的 90 个网格点上复核。可解析度范围内没有发现负值；但当
\(m\) 较大时，100 位工作精度下的 periodization 发生严重消去，部分输出
落到数值零，因而这次扩展不能作为高阶符号证据，也不改变下述证据边界。

## 3. 一个可完全解析的最低层

最低层 (m=1) 还可完全解析处理。写 (y=N+r)、(0\le r<1)，有
\[
P_1(N+r)=
-\frac{N(N+1)}{42(N+r)^6}
\Bigl[N\bigl(6r^2(1-r)^2-1\bigr)+3r^4-6r^2+1\Bigr].
\]
因为 (6r^2(1-r)^2\le3/8)，且
\[
=-3r^2(1-r)^2(1+2r-2r^2)\le0,
\bigl(6r^2(1-r)^2-1\bigr)+3r^4-6r^2+1
=3r^3(3r-4)\le0,
=-3r^2(1-r)^2(1+2r-2r^2)\le0,
\]
故 (P_1(y)\ge0) 对所有 (y\ge1)。这只是单层恒等式，尚未推广到任意 (m)。

## 4. 证据边界

该结果只排除了给定有限网格上的数值反例。它没有证明任意实数 \(y\) 的
\(P_m(y)\ge0\)，更没有证明任意 \(m\) 的正性。特别是，\(y\ge2\) 时
periodization 同时包含 \(u<1/2\) 的负区间；note 151 已给出简单配对不足的明确例子。

因此这项筛查不能关闭 RH 路线的真正缺口：仍需一般
Bernstein/falling-factorial 系数证明，或绕开 detector 正性，直接给出完整
Möbius 二次型的平方根级 signed-dispersion 估计。
