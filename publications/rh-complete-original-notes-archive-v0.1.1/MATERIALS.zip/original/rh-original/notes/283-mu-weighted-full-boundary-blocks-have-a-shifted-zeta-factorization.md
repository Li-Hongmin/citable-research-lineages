> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# μ 加权完整 boundary blocks 的 shifted-zeta 因子化

日期：2026-08-16。

依赖：[note 177](177-mobius-parity-intertwiner-for-one-sided-reciprocal-boundary.md)、
[note 259](259-full-squarefree-parity-completion-is-a-twisted-mertens-sum.md)、
[note 282](282-prime-extension-difference-annihilates-tail-but-leaves-boundary-cokernel.md)。

本 note 研究所有完整 squarefree divisor blocks 的 μ 加权 boundary 聚合。
它揭示一个新的、比单个 boundary mode 更薄的 Fourier–Euler 结构：零频时
Euler 因子完全退化为 1；但非零频仍保留 shifted-zeta 比值，且实际
half-lattice cutoff 仍需另行处理。

## 1. 完整 ordinary block

令

$$
G_X:=\sum_{a,b\mid X}\mu(a)\mu(b)
g\!\left(\log\frac ab\right),
$$

其中 $X$ 为 squarefree，$g$ 为偶的实核，Fourier 变换记为 $h$：

$$
g(u)=\frac1{2\pi}\int_{\mathbb R}h(t)e^{itu}\,dt.
$$

以下沿用当前 endpoint-flat detector 的条件 $g(0)=0$（等价于 $P(1)=0$）。

定义 Möbius Euler polynomial

$$
\Phi_X(t):=\sum_{a\mid X}\mu(a)a^{it}
=\prod_{p\mid X}(1-p^{it}).
$$

有限 Fourier--Fubini 给出

$$
G_X=\frac1{2\pi}\int_{\mathbb R}h(t)|\Phi_X(t)|^2\,dt,
\qquad
|\Phi_X(t)|^2=\prod_{p\mid X}(2-p^{it}-p^{-it}).
\tag{1}
$$

考虑完整 blocks 的 μ 加权 Dirichlet 级数

$$
L(s,t):=\sum_{X\ \mathrm{squarefree}}
\mu(X)|\Phi_X(t)|^2X^{-s}.
$$

其 Euler 乘积为

$$
\boxed{
L(s,t)=\prod_p\left[1-(2-p^{it}-p^{-it})p^{-s}\right].}
\tag{2}
$$

## 2. shifted-zeta 因子化

令 $x=p^{-s}$、$z=p^{it}$。局部因子为

$$
f_p=1-(2-z-z^{-1})x.
$$

直接相乘得到精确分解

$$
\boxed{
L(s,t)=
\frac{\zeta(s-it)\zeta(s+it)}{\zeta(s)^2}
S(s,t),}
\tag{3}
$$

其中

$$
S(s,t)=\prod_p
\frac{[1-(2-p^{it}-p^{-it})p^{-s}]
      (1-p^{-s+it})(1-p^{-s-it})}
     {(1-p^{-s})^2}.
\tag{4}
$$

局部 $p^{-s}$ 一次项在 (4) 中完全抵消，因此

$$
S(s,t)=1+O\!\left(p^{-2\Re s}\right)
$$

一致于实 $t$ 的紧集；在 $Re s>1/2+\varepsilon$ 上，$S(s,t)$ 局部一致绝对收敛并全纯。

这给出一个新的 exact coordinate：完整 boundary 聚合的主算术因子不是
$1/\zeta(s)$，而是

$$
\frac{\zeta(s-it)\zeta(s+it)}{\zeta(s)^2}.
$$

## 3. 零频退化

在 $t=0$ 时，$|\Phi_X(0)|^2=0$ 对所有 squarefree $X>1$ 成立，且

$$
L(s,0)=\prod_p1=1.
\tag{5}
$$

这与 (3) 一致，因为此时 $S(s,0)=1$ 且
$\zeta(s-it)\zeta(s+it)/\zeta(s)^2=1$。

因此完整 boundary 聚合的零频 Mertens mode 被精确消掉；这不同于原始
positive Mellin energy 的 $h(0)>0$ 低频峰。这个消失是一个真实的代数事实，
不是数值近似。

但不能据此推出平方根界：对 $t\ne0$，(3) 仍含有两个 shifted zeta 因子和
$1/\zeta(s)^2$，而且从完整 block 回到实际 cutoff reciprocal sum 仍有
note 205 的宏观 completion remainder。

## 4. 与 boundary mode 的关系

note 282 中固定核心的 boundary mode 为

$$
B_q=-2\mu(q)G_q.
$$

若把完整 core $q$ 按 $\mu(q)$ 聚合，则其 Dirichlet 级数正是 (2)。所以
素数扩张差分消掉的是每个 $q$ 的常数方向，而全局 μ 加权聚合则把这些
常数方向合并成 (3) 的 shifted-zeta 对象。两种操作的顺序可交换在有限截断
上，但都不能自动处理 cutoff。

## 5. 非零频主项的形式消失

把 (3) 的主因子先形式地用于 Perron 反演。对固定 $t\ne0$，其右侧的
$\Re s=1$ 极点位于 $s=1+it$ 与 $s=1-it$。例如 $s=1+it$ 的主项振幅
（省略 $B^{1+it}$）为

$$
A_+(t)=
\frac{\zeta(1+2it)S(1+it,t)}{(1+it)\zeta(1+it)^2}.
\tag{6}
$$

由于

$$
\zeta(1+it)\sim\frac1{it},
\qquad
\zeta(1+2it)\sim\frac1{2it},
$$

且 $S(1+it,t)\to1$，有

$$
A_+(t)=\frac{it}{2}+O(t^2)\qquad(t\to0).
\tag{7}
$$

共轭极点给出相应的 $A_-(t)$。所以若能在 $t$ 的一个统一邻域内完成
Perron 截断、零自由区余项和 $S$ 的导数控制，积分

$$
B\int h(t)A_+(t)e^{it\log B}\,dt
$$

至少获得一次振荡积分的 $1/\log B$ 消去；利用 (7) 还可能获得更高阶的
低频消去。这个现象解释了为什么完整 boundary 聚合比单个
$G_q$ 更薄。

但上述只是一条明确的条件性分析接口。要把它升级为定理，仍须证明：

1. 对 $|t|$ 接近 $0$ 和 $|t|$ 远离 $0$ 的统一 Perron 余项；
2. shifted zeta 零点和 $1/\zeta(s)^2$ 的零自由区控制不被 $t$ 积分放大；
3. 将完整 block 的估计与实际 half-lattice cutoff remainder 配对。

因此 (6)--(7) 是新的低频抵消机制，但不是无条件的平方根估计，也不能
单独推出 RH。

## 6. 最小新的算术门

要把这条路线推进到 RH，需要同时证明一个统一的频率/截断估计，例如对
当前 $h$：

$$
\sum_{X\le B}\mu(X)G_X
\ll_\varepsilon B^{1/2+\varepsilon}
$$

（或证明它与实际 cutoff remainder 的 signed 和一起满足同样界），并且要在
$t$ 的积分中保持 (3) 的 shifted-zeta 结构。仅利用 $S(s,t)$ 的绝对收敛只能给
次幂级 Euler 余项，不能得到平方根界；逐 $X$ 取绝对值会丢掉 (2) 的 μ
符号。

因此本 note 的实质进展是：完整 boundary 聚合确实有一个零频消失的候选
intertwiner，但它尚未延伸到实际 half-lattice，也没有提供无条件平方根估计。
本文不声称 RH 已被证明。
