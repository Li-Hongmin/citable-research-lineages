> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Smooth-bump realization of the divisor-complement reflection

## 结论

对任意固定 \(X>1\)，令 \(d=\log X\)。在加法对数坐标中，除数补映射

\[
R_Xe_a=e_{X/a},\qquad t_a=\log a,
\]

可以由一个真实的平移反射精确实现；但这个实现所需的空间长度至少随
\(d=\log X\) 增长。因此它是一个严格的对象级 intertwiner，而不是把固定尺度
的局部 Weil 正性自动推广到全部 \(X\) 的证明。

## 精确构造

取实偶函数 \(\phi\in C_c^\infty(-\varepsilon,\varepsilon)\)，并写

\[
\phi_t(x)=\phi(x-t),\qquad T_Xe_a=\phi_{t_a}.
\]

在 \(L^2(\mathbb R)\) 上定义完整反射

\[
(J_df)(x)=f(d-x).
\]

由于 \(\phi\) 偶，直接计算得

\[
J_d\phi_t=\phi_{d-t}.
\]

于是对每个 \(a\mid X\)，有严格恒等式

\[
\boxed{J_dT_X=T_XR_X.}
\]

这正是离散 divisor complement 与 A 线 partial-reflection 的同型关系，且没有
逐除数的近似误差。

若只在一个有限区间上工作，为使所有 bump 不被截断，至少要取

\[
I_{X,\varepsilon}=[-\varepsilon,d+\varepsilon],
\qquad |I_{X,\varepsilon}|=\log X+2\varepsilon.
\]

因此固定的局部尺度区间不可能承载任意大的 \(X\) 的完整 complement orbit。

## Gram 与反射符号

令 \(C_p\) 为平移不变的卷积/乘法算子，其 Fourier multiplier 为一个偶实函数
\(\widehat p\)。则 \(C_p\) 与 \(J_d\) 对易。设

\[
g_{p,\phi}(u)=\langle\phi_0,C_p\phi_u\rangle.
\]

平移不变性给出

\[
\langle T_Xe_a,C_pT_Xe_b\rangle
=g_{p,\phi}(t_a-t_b),
\]

而反射矩阵满足

\[
T_X^*C_pJ_dT_X=G_{p,\phi}R_X,
\qquad
(G_{p,\phi})_{ab}=g_{p,\phi}(\log(a/b)).
\]

若 \(\widehat p\ge0\)，则 \(C_p\succeq0\) 且 \(G_{p,\phi}\succeq0\)，但

\[
T_X^*C_pJ_dT_X=G_{p,\phi}R_X
\]

仍在 \(R_X=-1\) sector 带负号。故这个构造保留了 note169/177 的 parity
机制；不能把 \(T_X\) 当作等距映射后删掉 \(R_X\)。

在 Fourier 侧，若采用
\(\widehat f(\xi)=\int f(x)e^{-i\xi x}\,dx\)，则 bump
只是在原符号上乘一个非负滤波：

\[
\widehat{g_{p,\phi}}(\xi)
=|\widehat\phi(\xi)|^2\widehat p(\xi).
\]

这解释了平滑化的精确作用：它可以抑制高频，却不能改变反射 parity，也不能
把一个在正测度频带取负的符号变成全局正符号。

## 对当前 Weil 路线的最小含义

这个构造给出一个可交给 A/Feshbach 的三元组

\[
T_Xe_a=\phi_{\log a},
\qquad J_{\log X}T_X=T_XR_X,
\qquad T_X^*C_pJ_{\log X}T_X=G_{p,\phi}R_X.
\]

它严格识别了“divisor complement = log-coordinate reflection”，并说明了真正
缺口：需要一个随 \(X\) 统一的区间扩展、滤波符号控制及 signed parity block
估计。固定尺度的 local Weil/true-Schur 正性只控制 \(C_p\) 的正块，不能单独
给出 \(G_{p,\phi}R_X\) 的正性或平方根级算术界。

这是一条有限、可审计的 intertwiner，不是 RH 证明。

