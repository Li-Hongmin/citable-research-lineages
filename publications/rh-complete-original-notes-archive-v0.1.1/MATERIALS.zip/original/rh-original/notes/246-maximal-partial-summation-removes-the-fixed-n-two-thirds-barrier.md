> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 最大点 Abel 部分求和消除固定 \(N\) 的 \(2/3\) 局部化障碍

日期：2026-08-16。

本 note 修正 notes 196、229 中一个容易混淆的量词：在固定 \(N\) 上只用
\(\lvert F_N'(t)\rvert\le N\log N\)，确实只能得到 \(2/3\) 指数；但若
正能量界对所有截断 \(N\) 统一成立，可以先选取 Mertens 和的最大点，再用
Abel 部分求和。这样同一个正能量门直接给出平方根级 Mertens 界。

## 引理

设 \(a_n\in\mathbb R\)，
\[
 A(x)=\sum_{n\le x}a_n,\qquad
 F_X(t)=\sum_{n\le X}a_n n^{it}.
\]
设 \(w\) 在某个 \([-\delta_0,\delta_0]\) 上连续且
\[
 w(t)\ge c_0>0.
\tag{1}
\]
若对每个 \(\eta>0\) 和所有整数 \(X\ge2\) 有
\[
 E_X(w):=\int_{\mathbb R}w(t)|F_X(t)|^2\,dt
 \le C_\eta X^{1+\eta},
\tag{2}
\]
则
\[
 \max_{x\le X}|A(x)|\ll_{\eta,w}X^{1/2+\eta}.
\tag{3}
\]

## 证明

令
\[
 A^*(X)=\max_{1\le x\le X}|A(x)|
\]
并取 \(X_0\le X\) 使 \(|A(X_0)|=A^*(X)\)。若 \(X_0\ge3\)，Abel 部分
求和给出
\[
 F_{X_0}(t)
 =A(X_0)X_0^{it}
 -it\int_1^{X_0}A(u)u^{it-1}\,du .
\tag{4}
\]
因此
\[
\begin{aligned}
 |F_{X_0}(t)-A(X_0)|
 &\le |A(X_0)|\,|X_0^{it}-1|
 +|t|\int_1^{X_0}|A(u)|\,\frac{du}{u}\\
 &\le 2|t|A^*(X_0)\log X_0 .
\end{aligned}
\tag{5}
\]
当 \(|t|\le(16\log X_0)^{-1}\) 时，由 (5) 得
\[
 |F_{X_0}(t)-A(X_0)|
 \le \left(2\cdot\frac1{16}+\frac1{16}\right)A^*(X_0)
 =\frac3{16}A^*(X_0),
\]
从而（取较弱但方便的常数）
\[
 |F_{X_0}(t)|\ge \frac34 A^*(X_0).
\tag{6}
\]
对足够大的 \(X_0\)，该区间包含在 \([-\delta_0,\delta_0]\) 中，于是
\[
 E_{X_0}(w)
 \ge \frac{9c_0}{128\log X_0}\,A^*(X_0)^2 .
\tag{7}
\]
结合 (2) 得
\[
 A^*(X)^2
 \le A^*(X_0)^2
 \ll_{\eta,w}X_0^{1+\eta}\log X_0
 \ll_{\eta,w}X^{1+\eta}\log X .
\tag{8}
\]
将 \(\eta\) 换成任意给定指数的一半，并吸收 \(\log X\) 到幂次中，得到
(3)。有限多个 \(X_0<3\) 可并入常数。\(\square\)

## 对当前 RH detector 的后果

当前正 detector 满足 \(h(0)>0\)，故
\(w(t)=|h(t)|/(2\pi)\) 满足 (1)。因此一旦证明
\[
 \int_{\mathbb R}|h(t)|
 \left|\sum_{n\le X}\mu(n)n^{it}\right|^2dt
 \ll_\varepsilon X^{1+\varepsilon}
\tag{9}
\]
对所有 \(X\) 统一成立，取 \(a_n=\mu(n)\) 即得
\[
 M(X)=\sum_{n\le X}\mu(n)\ll_\varepsilon X^{1/2+\varepsilon},
\]
再由标准的 Mertens--RH 等价性推出 RH。这个推论不需要先构造
Szegő 外函数或无零 Mellin 测试函数。

因此，notes 196、229 所述 \(2/3\) 只是“固定 \(N\)、固定 \(M(N)\) 点值”
的局部化障碍；它不是统一正能量门推出 RH 时的真正障碍。真正未解的仍是
(9) 本身的 Möbius signed-energy 估计。
