> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 局部 Weil 算子的严格正性推进到 \(\frac12\log10\)

日期：2026-08-12。

## 定理

设 \(A_a\) 为支撑于 \((-a,a)\) 的局部 Weil 算子。则

\[
\boxed{A_a>0,\qquad 0<a\le \frac12\log10.}
\tag{1}
\]

特别地，若 \(a_{\rm deg}\) 表示局部 Weil 形式的首次退化尺度，则

\[
\boxed{a_{\rm deg}>\frac12\log10.}
\tag{2}
\]

偶扇区结论已由 [note 064](064-strict-even-local-weil-positivity-to-log10-half.md)
证明。本文闭合奇扇区，并将两者合并为完整算子定理。

## 1. 奇扇区的同源 scalar 下算子

固定

\[
a=\frac12\log10,\qquad N=500,\qquad R=280,\qquad K=400.
\tag{3}
\]

令 \(B_0^-\) 包含全部 active prime blocks、\(n<500\) 的正 odd
Yukawa atoms 以及负 odd polar 项：

\[
B_0^-=P_{\rm prime}+\sum_{n<500}|r_n^-\rangle\langle r_n^-|
-|p_-\rangle\langle p_-|,
\qquad L_0^-=D^-+B_0^-.
\tag{4}
\]

负 polar 项没有被删除；它完整进入 \(PB_0^-P\)、\(P(B_0^-)^2P\)
以及以下所有 atom--base cross。仅在补空间下界中使用

\[
\|p_-\|^2=2(\sinh a-a),\qquad
\rho_-=2.978071+2(\sinh a-a).
\tag{5}
\]

取 \(P=P_{400}\)、\(Q=I-P\)。奇 Fourier 基为

\[
e_k^-(x)=\sqrt{\frac2a}\sin\frac{(k+\frac12)\pi x}{a},
\tag{6}
\]

故补空间首频为 \(400+\frac12\)。严格区间计算给出

\[
\mu_-=d_{400+1/2}-\rho_-
=1.637145485216621378315945\ldots>0.
\tag{7}
\]

保留全部 \(P\)-\(Q\) cross，只将 \(QL_0^-Q\) 降为 \(\mu_-Q\)：

\[
\underline L_0^-=
\begin{pmatrix}
PL_0^-P&PB_0^-Q\\
QB_0^-P&\mu_-Q
\end{pmatrix}
\preceq L_0^-.
\tag{8}
\]

式 (8) 是无限维 Loewner 下算子，不是把有限压缩补零。

## 2. 213 个完整 odd Yukawa atoms

令

\[
F=(r_{500}^-,r_{501}^-,\ldots,r_{712}^-),
\qquad U=PF,\qquad V=QF,
\tag{9}
\]

其中

\[
r_n^-(x)=
\frac{e^{-c_na}(e^{c_nx}-e^{-c_nx})}
     {\sqrt{1+e^{-2c_na}}},
\qquad c_n=2n+\frac12.
\tag{10}
\]

其余 \(n\ge713\) 项仍为正 Gram 和，因而

\[
\underline L_{213}^-:=\underline L_0^-+FF^*
\preceq A^-_a.
\tag{11}
\]

写 \(X=PB_0^-Q\)。消去无限补空间后，完整 family 的精确
metric--Woodbury 更新为

\[
S_{213}^-=S_0^-+E\mathcal K^{-1}E^*,
\tag{12}
\]

\[
S_0^-=PL_0^-P-\mu_-^{-1}XX^*,\qquad
E=U-\mu_-^{-1}XV,
\qquad
\mathcal K=I+\mu_-^{-1}V^*V>0.
\tag{13}
\]

所有无限补空间量由 Parseval 恒等式精确化为有限矩阵：

\[
XV=PB_0^-F-(PB_0^-P)U,
\qquad
V^*V=F^*F-U^*U.
\tag{14}
\]

因此 (12) 同时保留了 atom 的完整补空间分量、不同 atoms 间的全部
cross 以及负 polar 与每个 atom 的 cross；它不使用
\(PFF^*P\oplus0\preceq FF^*\) 这一错误关系。

## 3. \(274\to120\to6\) true-Schur 证书

在前 280 个坐标上施加权威 \(R=280,N=500\) 奇 graph 的六个
Householder 合同，得到

\[
\mathbf R^6\oplus\mathbf R^{274}\oplus\mathbf R^{120}.
\tag{15}
\]

旧 274 维补块的严格正性从 \(R=280\) 证书传递到 \(K=400\)。事实上，
若 \(C_F,C_G\succeq0\) 分别为模段 \(280\le q<400\) 与
\(q\ge400\) 的 covariance，则

\[
S_{400}|_{P_{280}}-S_{280}
=\frac{C_F}{\mu_{280}}
+\left(\frac1{\mu_{280}}-\frac1{\mu_{400}}\right)C_G
\succeq0,
\tag{16}
\]

因为 \(0<\mu_{280}<\mu_{400}\)。先消去 274 维块，再消去 120 维块；
atom coordinates 始终保留在同一个 metric 中。120 维 Schur 块的最小
interval Cholesky pivot 为

\[
3.58147764973666133205109507588779513318
\pm6.86\times10^{-39}>0,
\tag{17}
\]

最终 atom metric 的最小 interval Cholesky pivot 为

\[
1.000190821062476368932416065722544491221
\pm4.09\times10^{-40}>0.
\tag{18}
\]

最终六维 Schur 块的 pivot 排列为 \((5,2,3,0,1,4)\)，192-bit
interval pivots 依次为

\[
\begin{aligned}
&3.283604201273463244774444634996844348\times10^{-12}
 \pm8.31\times10^{-49},\\
&5.474825290264211914696347536409678\times10^{-17}
 \pm3.28\times10^{-51},\\
&6.9893122238897234997420543030\times10^{-22}
 \pm7.08\times10^{-51},\\
&3.41039129771931363535501\times10^{-27}
 \pm5.05\times10^{-51},\\
&2.92821083686116009\times10^{-33}
 \pm5.79\times10^{-51},\\
&9.79225\times10^{-43}\pm4.02\times10^{-49}.
\end{aligned}
\tag{19}
\]

全部区间下端严格为正。结合 (17)--(18) 与 Schur 惯性加法，得到

\[
\underline L_{213}^->0,
\qquad
\boxed{A^-_{\frac12\log10}>0.}
\tag{20}
\]

## 4. 固定下模型中的尖锐前缀

同一个 family 缓存中，只取前 212 个 atoms，即
\(r_{500}^-,\ldots,r_{711}^-\)，最后一个 pivot 为

\[
-2.940784\times10^{-42}\pm1.39\times10^{-49}<0.
\tag{21}
\]

加入 \(r_{712}^-\) 后变为 (19) 的严格正值。由 Schur 补对正算子增量的
单调性，更短前缀均不可能为正。因此 213 是该固定 scalar
\(K400/N500\) lift、按自然顺序加入 atoms 时的严格最小长度；它不是任意
下模型的普适秩下界。

## 5. 合并奇偶扇区

note 064 已证明

\[
A^+_{\frac12\log10}>0.
\tag{22}
\]

奇偶分解与 (20) 给出端点完整正性

\[
A_{\frac12\log10}>0.
\tag{23}
\]

由 [note 003](003-zero-extension-and-full-spectrum-monotonicity.md) 的闭形式域嵌套与
min--max 单调性，(23) 传播到全部更小尺度，得到定理 (1)。

## 6. 复现

奇扇区权威执行顺序为

```bash
uv run --with numpy --with python-flint python -u \
  scratch/generate_log10_endpoint_contract_cache.py \
  192 280 500 - --export-verified-graph

uv run --with numpy --with python-flint python -u \
  scratch/generate_log10_endpoint_contract_cache.py \
  192 400 500 - --export-full-safe-matrix

uv run --with numpy --with python-flint python -u \
  scratch/extract_log10_even_K400_full_contract_base.py \
  --n500-clean --odd --precision 192

uv run --with numpy --with python-flint python -u \
  scratch/generate_log10_endpoint_contract_cache.py \
  192 400 500 - --export-yukawa-family 500 756

uv run --with numpy --with python-flint python -u \
  scratch/log10_even_K400_N500_multiatom_scalar_gate.py --odd \
  scratch/log10_odd_K400_N500_yukawa_500_756_parseval_arb_192.npz 213
```

承重输出为

```text
scratch/log10_odd_K400_N500_yukawa_500_713_scalar_gate_arb_192.out
scratch/log10_odd_K400_N500_yukawa_500_713_scalar_gate_arb_192.npz
```

对应 212 项边界输出为同名的 `500_712` 文件。所有缓存显式记录
`parity=-, N=500, R=280, K=400, precision=192`，并串联 family、
scalar base 与 Householder 来源。

## 7. 方法边界

奇 family 的补空间 Gram 可写为 generalized Hilbert matrix 加一个
rank-400 squared-Cauchy 扰动。裸 Hilbert 矩阵虽可显式对角化，但该扰动破坏
Jacobi 交换，现有 Carleman/Hankel resolvent 定理不能把 (12) 化为有限有理核。
Hilbert 不等式给出的通用 Loewner 下界在 128 项前缀上仍严格为负。因此本文使用的
213 项 full-space Parseval--Woodbury 证书是当前对象上更直接且更尖的闭合，而不是
对孤立有限压缩的数值替代。
