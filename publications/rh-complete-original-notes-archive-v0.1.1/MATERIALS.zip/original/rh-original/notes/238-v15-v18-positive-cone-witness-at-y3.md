> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(V_{15}\)--\(V_{18}\) 正锥内低频消零的精确单点障碍

日期：2026-08-17。

note 215 构造了
\[
 V_*=V_{15}-\lambda_*V_{18},
\qquad
 \lambda_*=\frac{138567}{35},
\]
以消去 \(K_*(0)\)。本 note 给出一个不依赖扫描的正性障碍。

由 \(P_j(y)=\sum_{c\le y}V_j(c/y)\) 直接计算，在 \(y=3\)：
\[
 P_{15}(3)=\frac{16924}{1594323},
\qquad
 P_{18}(3)=\frac{4541132}{1052621468613}.
\]
因此若
\[
 V_\lambda=V_{15}-\lambda V_{18}
\]
仍满足 \(P_\lambda(3)\ge0\)，则必须有
\[
 \lambda\le\frac{P_{15}(3)}{P_{18}(3)}
 =\frac{2793437361}{1135283}
 =2460.564776\ldots .
\tag{1}
\]
而低频消零所需的
\[
 \lambda_*=\frac{138567}{35}=3959.057142\ldots
\]
严格超过 (1)，并且
\[
 P_{\lambda_*}(3)
 =-\frac{29219704}{4519905705}<0.
\tag{2}
\]

所以这条最便宜的 signed detector 组合不能同时满足
\(K_\lambda(0)=0\) 与全半轴 periodization 正性。该结果只排除
\(V_{15},V_{18}\) 的这一维组合，不排除更高维、非线性或非正锥的
arithmetic intertwiner；它也不构成 RH 证明。
