> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Endpoint-flat RH 核有两个独立 collective residues

日期：2026-08-14。

依赖：[note 125](125-the-collective-mobius-mode-is-an-rh-strength-hankel-residue.md)。

证据等级：精确周期分解、离散 Abel 反演与有限反例。

note 125 提取了 \(s=-1\) residue。本文继续剥离全部非零均值周期项，得到第二个
\(s=-3\) residue，并证明两者不能由固定代数关系互相支付。

令 \(r=\{y\}\)、\(\phi(r)=r(1-r)\)。由
\(\lfloor y\rfloor=y-r\)，精确地

\[
P_V(y)
=\frac{\phi(r)}y
+\frac{(1-2r)\phi(r)}{y^2}
-\frac{\phi(r)^2}{y^3}.
\tag{1}
\]

利用

\[
\int_0^1\phi(r)\,dr=\frac16,\qquad
\int_0^1(1-2r)\phi(r)\,dr=0,\qquad
\int_0^1\phi(r)^2\,dr=\frac1{30},
\tag{2}
\]

得到无余项分解

\[
\boxed{
P_V(y)=\frac1{6y}-\frac1{30y^3}+C_0(y),}
\tag{3}
\]

其中

\[
C_0(y)=
-\frac{B_2(r)}y
+\frac{(1-2r)\phi(r)}{y^2}
+\frac{1/30-\phi(r)^2}{y^3},
\tag{4}
\]

且三个周期系数分别均值为零。

置

\[
S_k(z)=\sum_{a\le z}a^k\mu(a),\qquad z=\sqrt x.
\tag{5}
\]

代入双 Möbius 和，得到

\[
\boxed{
T_V(x)
=\frac{S_1(z)^2}{6x}
-\frac{S_3(z)^2}{30x^3}
+T_V^{(0)}(x),}
\tag{6}
\]

其中 \(T_V^{(0)}\) 的核就是 \(C_0(x/(ab))\)。Mellin 语言中第二项来自

\[
\operatorname*{Res}_{s=-3}\widehat V(s)=-4,\qquad
\zeta(-3)=\frac1{120},
\tag{7}
\]

故 residue 系数为 \(-1/30\)。中间极点 \(s=-2\) 被 trivial zero
\(\zeta(-2)=0\) 消去。

两个 moments 分别都是 RH 强度。对任意整数 \(k\ge1\)，离散 Abel 公式与逆式为

\[
S_k(z)=z^kM(z)
-\sum_{n<z}\bigl((n+1)^k-n^k\bigr)M(n),
\tag{8}
\]

\[
M(z)=\frac{S_k(z)}{z^k}
+\sum_{n<z}S_k(n)
\left(\frac1{n^k}-\frac1{(n+1)^k}\right).
\tag{9}
\]

因此

\[
S_1(z)\ll_\varepsilon z^{3/2+\varepsilon}
\iff \mathrm{RH},
\qquad
S_3(z)\ll_\varepsilon z^{7/2+\varepsilon}
\iff \mathrm{RH}.
\tag{10}
\]

但 two-residue quadratic

\[
Q_z(c)=\frac{M_1(c)^2}{6z^2}
-\frac{M_3(c)^2}{30z^6},
\qquad
M_k(c)=\sum_{a\le z}a^kc_a,
\tag{11}
\]

具有精确惯性

\[
\boxed{\operatorname{In}(Q_z)=(1,1,z-2)\qquad(z\ge2).}
\tag{12}
\]

确实，\(c^-=(2,-1)\) 在坐标 \(1,2\) 上满足 \(M_1(c^-)=0\)、
\(M_3(c^-)=-6\)，而 \(c^+=(8,-1)\) 满足 \(M_3(c^+)=0\)、
\(M_1(c^+)=6\)。所以两个线性泛函独立。

实际 Möbius 函数也没有精确 center relation。在 \(z=10\)，

\[
S_1(10)=0,\qquad S_3(10)=714,
\tag{13}
\]

从而

\[
\boxed{
\frac{S_1(10)^2}{6\cdot10^2}
-\frac{S_3(10)^2}{30\cdot10^6}
=-\frac{42483}{2500000}<0.}
\tag{14}
\]

归一化 \(A=S_1/z\)、\(B=S_3/z^3\) 后，

\[
\frac{S_1^2}{6z^2}-\frac{S_3^2}{30z^6}
=\frac1{30}(\sqrt5A-B)(\sqrt5A+B).
\tag{15}
\]

所以仅控制 residue 差允许 \(B\approx\pm\sqrt5A\) 隐藏两个很大的
RH-strength 分量。若想从该差反推 RH，最小新增命题是一个 Möbius 加权矩角分离：

\[
|B^2-5A^2|\gtrsim A^2+B^2
\tag{16}
\]

或足以排除两条共振射线的定量替代式。部分求和、符号或有限秩 Schur 均不提供它。

结论：

\[
\boxed{
\text{endpoint-flat 核的 collective 骨架是独立的一正一负 two-residue form；
剩余核才是全均值零 Hankel boundary}.}
\tag{17}
\]

下一步应直接判断角分离 (16) 是否为假，或研究 \(T_V^{(0)}\) 是否恰在共振附近恢复
缺失控制。这不是 RH 的证明。
