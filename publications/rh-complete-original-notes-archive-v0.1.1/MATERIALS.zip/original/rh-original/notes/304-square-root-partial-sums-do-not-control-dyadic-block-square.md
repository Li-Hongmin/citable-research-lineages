> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 全局平方根级部分和仍不控制 dyadic block-square

日期：2026-08-16。

本 note 构造一个单一的无限有界序列 \(f\)，满足统一的
\[
\left|\sum_{n\le x}f(n)\right|\le \frac12\sqrt x
\]
，但在无穷多个尺度 \(N_j\) 上有
\[
\sum_H|D_H(f;N_j)|^2\gg N_j^3.
\]
因此 block-square 门不能由 Mertens 型一阶部分和界推出；它确实需要
Möbius 特有的二点/四点 signed cancellation。这个构造不是 Möbius 的反例，
而是排除“一阶界蕴含四点门”的纯分析捷径。

## 单一序列的构造

选取递增的偶数 \(m_j\)，令 \(p_j=3m_j\)，并要求
\[
p_{j+1}>3p_j^2.
\]
置 \(X_j=p_j^2\)，于是区间
\[
B_j=[X_j,X_j+p_j^2)
\]
两两不交。令 \(f=0\) 在所有 \(B_j\) 外；在 \(B_j\) 上令
\[
f(X_j+r)=
\begin{cases}
1,&r\bmod p_j<p_j/2,\\
-1,&p_j/2\le r\bmod p_j<p_j.
\end{cases}
\]
每个 \(B_j\) 恰含 \(p_j\) 个完整周期，故其总和为零。任一部分和在
\(B_j\) 内的绝对值至多 \(p_j/2\)，而 \(x\ge X_j=p_j^2\)，所以
\[
\left|\sum_{n\le x}f(n)\right|\le \frac{p_j}{2}\le\frac{\sqrt x}{2}.
\tag{1}
\]
在方块之间部分和为零，故 (1) 对所有 \(x\ge1\) 成立。

## 每个方块产生一个大的 dyadic 相关块

对第 \(j\) 个方块取
\[
H_j=2m_j=\frac{2p_j}{3},\qquad N_j=X_j+p_j^2=2p_j^2.
\]
一个周期内的相关和为
\[
c_h=\sum_{r=0}^{p_j-1}f(X_j+r)f(X_j+r+h)
=
\begin{cases}
p_j-4h,&0\le h\le p_j/2,\\
4h-3p_j,&p_j/2\le h\le p_j.
\end{cases}
\tag{2}
\]
因此
\[
\sum_{h=2m_j}^{4m_j-1}c_h=2m_j^2,
\qquad
\sum_{h=2m_j}^{3m_j-1}c_h=m_j^2-2m_j.
\tag{3}
\]

由于 \(p_{j+1}>3p_j^2\)，在壳
\(H_j\le h<2H_j\) 内：

1. 任何旧方块的长度 \(p_i^2\) 小于 \(H_j\)，所以旧方块内部没有贡献；
2. 相邻方块的间距大于 \(2H_j\)，所以跨方块项没有贡献；
3. 只有当前方块 \(B_j\) 留下贡献。

于是与单方块长度 \(p_j^2\) 的计算完全相同。余项每个至多 \(p_j\)，从而
\[
\begin{aligned}
D_{H_j}(f;N_j)
&\ge (p_j-2)\,2m_j^2+(m_j^2-2m_j)-2m_jp_j\\
&=6m_j^3-9m_j^2-2m_j.
\end{aligned}
\tag{4}
\]
因此
\[
|D_{H_j}(f;N_j)|\asymp m_j^3\asymp N_j^{3/2},
\qquad
\boxed{\sum_H|D_H(f;N_j)|^2\gg N_j^3.}
\tag{5}
\]

## 裁决

式 (1) 与 (5) 对同一个无限序列同时成立。故任何只使用
\[
M(x)=O(x^{1/2+\varepsilon})
\]
型一阶部分和信息的推导，都不能关闭本项目的 dyadic block-square 门。
需要的是真正的 Möbius-specific 二点/四点相关估计，或保留乘法结构的
算术 intertwiner；这也是当前 RH 路线的实质缺口。
