> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# V15 的 Mellin/Weil 乘子在临界线上变号

日期：2026-08-15。

本 note 给出次数十五正 detector 的另一个有限、精确边界：其 Mellin
乘子不能直接作为非负 Fourier/Weil 符号。它与 note 156 的二维 signed
Möbius 负块相互独立。

## 1. 精确乘子

对

\[
V_{15}(u)=u^2(1-u)^9(-3-27u-57u^2+207u^3+1024u^4),
\]

有

\[
K_{15}(s)=
\frac{415134720(s-1)}
{(s+2)(s+4)(s+6)(s+8)(s+9)(s+10)(s+11)(s+12)(s+13)(s+14)(s+15)}.
\]

令 $s=1/2+it$，分母的模平方严格为正。直接取
$\operatorname{Re}((s-1)\overline{D(s)})$ 得

\[
\operatorname{Re}K_{15}(1/2+it)
=415134720\,\frac{R(t)}{|D(1/2+it)|^2},
\]

其中

\[
R(t)= -t^{12}+4882t^{10}-2419833t^8+257322596t^6
-6352237616t^4+27571764672t^2-6227020800.
\]

因此分母和常数因子均为正，而

\[
R(0)=-6227020800<0,\quad
R(1)=15247413900>0,\quad
R(3)=-100612991700<0,\quad
R(10)=2387869286400>0.
\]

故 $\operatorname{Re}K_{15}(1/2+it)$ 至少发生三次符号变化。

## 2. 路线含义

这严格排除将 V15 的临界线 Mellin 乘子直接解释为非负 Fourier 符号、
普通 PSD Weil Gram 或逐频正化的捷径。它不排除保留 Möbius 符号的
Kreĭn/indefinite intertwiner；后者必须显式处理 note 156 的二维负块及
更高尺度的增长负惯性。

这仍只是路线边界，不是 RH 的否定或证明。
