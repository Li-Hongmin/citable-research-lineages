> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 直接 dilation 差商不产生 logarithmic boundary trace

日期：2026-08-11。

本文修正 [note 045](045-joint-weil-virial-stationarity-and-boundary-anomaly.md) 留下的最乐观接口：
向内 dilation 的二次型差商本身不能把端点轮廓识别为 gauge trace 的平方；active prime correlations
也不产生所需的一阶端点异常。若 renormalized Pohozaev identity 成立，它必须来自本征方程的
Green/commutator 边界配对。

## 1. Logarithmic 主形式的精确缩放

对零延拓 (u\in H((-a,a))\) 及

\[
(U_su)(x)=e^{s/2}u(e^sx),\qquad s\ge0,
\]

全线 Fourier 符号 (L_\Delta=2\log|D|) 直接给出

\[
U_s^{-1}L_\Delta U_s=L_\Delta+2sI.
\]

因此在完整 logarithmic form domain 上精确成立

\[
\boxed{
\mathcal E_L(U_su)-\mathcal E_L(u)=2s\|u\|_2^2.}
\tag{1}
\]

该恒等式不需要边界正则性。用 Chen--Weth 的 jump form 重算时，缩放后的 cutoff 从 (1) 变为
(e^{-s})，近、远场的公共部分抵消，环带

\[
e^{-s}<|h|<1
\]

恰贡献 (2s\|u\|_2^2)。所以常数 (2) 确实来自全局尺度 covariance，而不是端点 collar。

特别地，即使

\[
u(a-r)=\frac{B_+}{\sqrt{\log(1/r)}}+o\!\left(\frac1{\sqrt{\log(1/r)}}\right),
\]

式 (1) 仍只依赖 \(\|u\|_2\)。取 (u\in C_c^\infty(-a,a)\setminus\{0\}) 即有
(B_+=B_-=0)，而差商仍为 (2\|u\|_2^2>0)。反之，在固定相同边界轮廓后加入内部 bump 会改变
差商。因此不存在只从一般测试函数的 dilation 差商推出

\[
|B_+|^2+|B_-|^2=2\|u\|_2^2
\]

的论证。

## 2. Prime correlations 的端点层为低阶

令

\[
C_u(d)=\int_{\mathbf R}u(x+d)\overline{u(x)}\,dx,
\qquad 0<d<2a.
\]

精确换元为

\[
C_{U_su}(d)=C_u(e^sd).
\tag{2}
\]

设两端具有临界轮廓

\[
u(a-r)\sim\frac{B_+}{\sqrt{\log(1/r)}},
\qquad
u(-a+r)\sim\frac{B_-}{\sqrt{\log(1/r)}}.
\tag{3}
\]

对固定 (0<d<2a)，尺度变化移动的端点层宽度 \(\delta\asymp ds\)。若另一因子位于普通内点，
该层贡献为

\[
O\!\left(\frac{\delta}{\sqrt{\log(1/\delta)}}\right)=o(s).
\tag{4}
\]

在真正 activation 阈值 (d=2a)，两端同时进入，且

\[
C_u(2a-\varepsilon)
\sim B_+\overline{B_-}
\frac{\varepsilon}{\log(1/\varepsilon)},
\tag{5}
\]

仍为 (o(\varepsilon))。因此 threshold 两侧的一阶端点导数都为零。(d=a) 只是在半区表示中把
translation 与 reflection 重组；完整相关函数没有特殊边界异常。

若内部具有足够的局部 (H^1) 正则性，并满足

\[
u'(a-r)=O\!\left(\frac1{r\log(1/r)^{3/2}}\right),
\]

则 (C_u'(d)) 是普通有限导数，且移动端点项为零。仅有 (3) 时不能保证指定 delay 上的差商
收敛：可以在内部修改 (L^2) 数据而保持 (B_\pm) 不变，使 autocorrelation 不可微。但这种失败
来自内部平移正则性，不是 logarithmic boundary anomaly。

## 3. 对首次退化路线的判定

[note 044](044-renormalized-log-pohozaev-hinge-and-prime-virial.md) 的候选

\[
|\mathcal B_Ru|^2=2\|u\|_2^2
\]

仍与尺度 covariance 的常数一致，但式 (1) 不能证明它。所缺的不是更精细的一般 collar 估计，而是
一个只对本征函数成立的 Green/Pohozaev 恒等式：必须把本征方程与截断 dilation generator 配对，
再证明极限中的 boundary commutator 等于线性 gauge trace 的平方。

同时，式 (4)--(5) 说明 active prime correlations 不会由临界边界轮廓自动提供一个非零一阶异常；
它们要么具有普通 bulk 导数，要么因内部平移正则性不足而没有导数。

因此严格关闭：

\[
\boxed{
\text{直接对完整二次型做向内 dilation，凭 collar 渐近提取非零边界平方}.}
\]

保留的最小命题是 eigenfunction-specific Green identity，而不是 form-scaling identity。

