> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 两正弦 cutoff 均方与 RH 等价

日期：2026-08-13。

依赖：[note 081](081-every-offline-zero-is-visible-in-one-fixed-sine-mode.md)、
[note 086](086-first-two-sine-modes-are-a-rigorous-universal-detector.md)。

## 1. 等价定理

沿用

\[
w_k(t)=\sin\pi k(t-1),
\qquad
\mathcal R_{N,k}
=B_NS_{N,k}
-\sum_{N<n<2N}
\left[\Lambda(n)+\mu(n)\log\frac nN\right]w_k(n/N).
\tag{1}
\]

**定理。**

\[
\boxed{
\mathrm{RH}
\iff
\forall\varepsilon>0,\quad
\sum_{Y<N\le2Y}
\left(|\mathcal R_{N,1}|^2+|\mathcal R_{N,2}|^2\right)
\ll_\varepsilon Y^{2+\varepsilon}.
}
\tag{2}
\]

由 note 086，右式推出 RH。以下只证 RH 推出右式。

## 2. RH 下的 Möbius 输入

令

\[
M(x):=\sum_{n\le x}\mu(n),
\qquad
A(x):=\sum_{n\le x}\frac{\mu(n)}n.
\tag{3}
\]

使用经典 RH 等价式

\[
M(x)=O_\delta(x^{1/2+\delta})
\qquad(\forall\delta>0).
\tag{4}
\]

取 \(0<\delta<1/2\)。因 \(\sum_{n\ge1}\mu(n)/n=0\)，分部求和给

\[
A(x)
=\frac{M(x)}x-\int_x^\infty\frac{M(t)}{t^2}\,dt
=O_\delta(x^{-1/2+\delta}).
\tag{5}
\]

又

\[
B_N=\sum_{d\le N}\frac{\mu(d)}d\log\frac Nd
=\int_1^N\frac{A(t)}t\,dt.
\tag{6}
\]

常数不能只由 (5) 猜测。对 \(\eta>0\)，

\[
\int_1^\infty A(t)t^{-1-\eta}dt
=\frac1{\eta\zeta(1+\eta)}.
\tag{7}
\]

由 \(\zeta(1+\eta)\sim1/\eta\) 及 (5) 的可积控制，

\[
\int_1^\infty\frac{A(t)}t\,dt=1.
\tag{8}
\]

所以

\[
\boxed{
B_N=1-\int_N^\infty\frac{A(t)}t\,dt
=1+O_\delta(N^{-1/2+\delta}).
}
\tag{9}
\]

## 3. 两个窗口分部求和

RH 下的 von Koch 估计为

\[
\psi(x)=x+O(x^{1/2}\log^2x).
\tag{10}
\]

因 \(w_k(1)=w_k(2)=0\)，Stieltjes 分部求和给

\[
\sum_{N<n<2N}\Lambda(n)w_k(n/N)
=Nc_k+O_k(N^{1/2}\log^2N),
\tag{11}
\]

\[
c_k:=\int_1^2w_k(t)dt
=\frac{1-(-1)^k}{\pi k}.
\tag{12}
\]

再令

\[
h_k(t):=\log t\,w_k(t).
\tag{13}
\]

同样 \(h_k(1)=h_k(2)=0\)，故由 (4)

\[
\begin{aligned}
\sum_{N<n<2N}\mu(n)h_k(n/N)
&=-\frac1N\int_N^{2N}M(x)h_k'(x/N)\,dx\\
&=O_{k,\delta}(N^{1/2+\delta}).
\end{aligned}
\tag{14}
\]

最后，对固定 \(k\) 及充分大的 \(N\)，

\[
S_{N,k}
=\sum_{j=1}^{N-1}\sin\frac{\pi kj}{N}
=
\begin{cases}
\cot\left(\dfrac{\pi k}{2N}\right),&k\text{ 奇},\\
0,&k\text{ 偶},
\end{cases}
\tag{15}
\]

从而

\[
S_{N,k}=Nc_k+O_k(N^{-1}).
\tag{16}
\]

由 (9)、(11)、(14)、(16)，\(Nc_k\) 精确抵消，得到

\[
\boxed{
\mathcal R_{N,k}=O_{k,\delta}(N^{1/2+\delta})
\qquad(k\ \text{固定}).
}
\tag{17}
\]

给定 (2) 中的 \(\varepsilon>0\)，在 (17) 取
\(\delta=\varepsilon/4\)，平方并对 \(Y<N\le2Y\) 求和：

\[
\sum_{Y<N\le2Y}|\mathcal R_{N,k}|^2
\ll_{k,\varepsilon}Y^{2+\varepsilon/2}
\ll Y^{2+\varepsilon}.
\tag{18}
\]

取 \(k=1,2\) 即完成逆向。

## 4. 决策意义

~~~mermaid
flowchart LR
  RH["RH"] --> M["M(x)=x^(1/2+o(1))"]
  RH --> P["ψ(x)-x=O(x^(1/2)log²x)"]
  M --> R["R_N,k=N^(1/2+o(1))"]
  P --> R
  R --> MS["two-mode dyadic mean square"]
  MS -->|"note 086"| RH
~~~

所以 note 086 的二模条件不是已知弱于 RH 的松弛量，而是一个精确 RH 等价式。任何直接证明
(2)、note 084 的 high-divisor \(\Delta\)-Gram，或完整 \(g_N\) off-diagonal，若没有额外未证
假设，就已经完成 RH。历史大筛、弱 Mertens、PNT 均方或通用 dispersion 输入只能被接受为
证明机制，不能被误报为现成闭合定理。
