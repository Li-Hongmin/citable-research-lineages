> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(\frac12\log11\) 的 500:700 joint Yukawa 下模型仍有严格负核心

日期：2026-08-15。

本 note 记录一次完整 joint-covariance 的增量实验。它只判断一个具体有限
下模型，不能反推完整无限维 \(A_{\log11/2}^+\) 的符号。

## 1. 计算对象

在 log11 even 端点，保留同一个 \(P_{400}\)、clean base、Householder graph
和 \(q=8000\) tail gate。相对于原 \(F_{640}\)，加入完整 Yukawa 家族
\[
F_{700}=(r_{500}^+,\ldots,r_{699}^+).
\]
新增 \(640:700\) 的 \(400\times60\) coupling、\(60\times60\) full atom Gram
以及旧/新 atom 的全部交叉 Gram 均以 192-bit Arb 计算；没有逐 atom 取绝对值。

复算入口：

    uv run --with numpy==2.2.6 --with python-flint==0.9.0 \
      python computations/combine_log11_yukawa_family.py

    uv run --with numpy==2.2.6 --with python-flint==0.9.0 \
      python computations/bundles/log201over20-local-weil-positivity/sources/log10_even_K400_sharp_safe_arb.py \
      --full400 --clean-no-yukawa --cache-prefix log11 192 11 1 \
      --family scratch/log11_even_K400_N500_yukawa_500_700_parseval_arb_192.npz 200 \
      --qf 8000

## 2. 严格输出

补空间 Cholesky 的最小 pivot 为
\[
0.0388512310459539498\ldots>0.
\]
核心 pivot 排列为
\[
(6,2,5,1,0,4,3),
\]
前六个严格正，而最后一个为
\[
[-1.88,-0.12]\times10^{-48}<0.
\tag{1}
\]
因此 \(F_{700}\) 的 cutoff-free joint lower model 仍严格不定。

原 \(F_{640}\) 记录的最后核心上界约为
\(-4.6363\times10^{-48}\)；加入 60 个完整 atom 后负量级约缩小四倍。
这说明 joint Parseval 尾确实支付了部分负方向，但在该有限 rank 尚未闭合。

同一次 192-bit Arb 运行还尝试把负 pivot 转成固定的 224-bit dyadic
全空间向量，并探测 (q=8000,\ldots,9000) 的正尾。由于核心方向的
条件数很差，舍入后的 dyadic 向量所得 Rayleigh 商上界为

\[
5.58\times10^{-31}>0.
\]

因此该导出向量没有通过严格的“冻结负见证”检查，witness 文件没有写出。
这不否定 (1)：(1) 是 Schur 核心的严格负 pivot 区间，已经证明该有限
下模型的矩阵不半正定；它只说明当前尚未得到可独立分发的稳定全空间
dyadic 向量证书，也没有得到 (8000\!:\!9000) 尾对该方向的严格支付量。

## 3. 严格边界

该计算证明的是
\[
\underline L_{F_{700}}^+\not\succeq0,
\qquad
\underline L_{F_{700}}^+\preceq A_{\log11/2}^+.
\]
由于下模型是完整算子的 Loewner 下界，下模型负性不能推出
\(A_{\log11/2}^+\) 负性；未加入的正 Yukawa 尾仍可能修复该方向。
反之，有限 \(F_{700}\) 的负 pivot 也说明仅靠固定 200 个 atom 的
joint-Schur 不能完成 n=11 端点。

本文不声称完整局部 Weil 算子不定，也不涉及 RH 真伪。
