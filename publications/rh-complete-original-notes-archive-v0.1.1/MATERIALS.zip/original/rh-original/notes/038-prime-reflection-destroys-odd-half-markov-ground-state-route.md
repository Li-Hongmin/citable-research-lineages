> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Prime reflection 破坏奇半区 Markov/定号路线

日期：2026-08-11。相关 nodal 文献检索日期同为 2026-08-11。

本文精确计算单个 active prime shift 在奇半区上的绝对值差，证明任一真正的 reflection 原子都会
破坏半区 Markov 收缩。严格正的连续 Archimedean 核不能一致吸收这一原子障碍。因此首次退化时
(M^-\succeq0) 并不推出奇半区 ground state 定号，prime-free note 014 的 positivity-improving
机制不能延伸到任意 active chamber。

## 1. 单 shift 的奇半区形式

令 (0<\tau<2a)，(alpha>0)，并把奇函数酉折叠为 (f\in L^2(0,a))。单个 prime shift 的
半区贡献可写成

\[
\mathcal P_\tau^-[f]
=\alpha\bigl(2\|f\|^2-2T_\tau(f)+R_\tau(f)\bigr),
\tag{1}
\]

其中

\[
T_\tau(f)=\int_0^{a-\tau}f(x+\tau)f(x)\,dx
\quad(\tau<a),
\]

而

\[
R_\tau(f)=
\int_{\max(0,\tau-a)}^{\min(a,\tau)}
f(y)f(\tau-y)\,dy.
\]

translation 部分满足

\[
T_\tau(|f|)-T_\tau(f)\ge0,
\]

但 reflection 部分在绝对值变换下取相反方向。精确差为

\[
\mathcal P_\tau^-[|f|]-\mathcal P_\tau^-[f]
=-2\alpha\bigl(T_\tau(|f|)-T_\tau(f)\bigr)
+\alpha\bigl(R_\tau(|f|)-R_\tau(f)\bigr).
\tag{2}
\]

## 2. 窄 bump 反例

取两个内点 (y_0,z_0\in(0,a))，满足

\[
y_0+z_0=\tau,
\]

并令两个宽度为 (\varepsilon) 的归一化窄 bumps 具有相反符号；同时选择支撑避开所有其他有限
translation/reflection 配对。可令

\[
T_\tau(|f_\varepsilon|)-T_\tau(f_\varepsilon)=0,
\]

而经归一化后

\[
R_\tau(f_\varepsilon)=-1,
\qquad
R_\tau(|f_\varepsilon|)=1.
\tag{3}
\]

奇半区的连续 Archimedean jump kernel 为

\[
K_-(x,y)=k(|x-y|)-k(x+y)>0.
\]

在上述两个分离窄支撑间，它是二维绝对连续核，所以绝对值变换造成的连续能量差仅为
(O(\varepsilon))。由 (2)--(3)，完整半区形式满足

\[
q^-(f_\varepsilon)-q^-(|f_\varepsilon|)
=-2\alpha+O(\varepsilon)<0
\]

当 (\varepsilon) 足够小时成立。故

\[
\boxed{q^-(|f|)\le q^-(f)}
\]

在任何含真正 active reflection 的 chamber 中一般为假。阈值 (	au=2a) 只有零测度接触，不在
此反例范围内。

## 3. 严格连接的二点模型

连续 jump 取

\[
\varepsilon
\begin{pmatrix}1&-1\\-1&1\end{pmatrix},
\qquad 0<\varepsilon<\alpha,
\]

并加入 reflection 原子和适当对角项，可得到

\[
M=(\alpha-\varepsilon)
\begin{pmatrix}1&1\\1&1\end{pmatrix}\succeq0.
\]

其唯一零 ground state 为

\[
(1,-1),
\]

并与严格正 polar vector ((1,1)) 正交。这个模型同时具有严格连续连接和 reflection 原子，证明

\[
K_->0,quad M^-\succeq0
\]

不足以推出半区 ground state 定号或 polar overlap 非零。

## 4. 文献边界与路线结论

Kwaśnicki--Mucha 对 complete Bernstein functions 的 extension 建立的是 harmonic extension 的
Courant--Hilbert nodal-parts 界；其一维边界本征函数只得到至多 (2n-1) 个 nodal parts，并明确
指出更强的 (n)-part 结论处于猜想层级。该结果即使在无 prime reflection 的类中，也不能推出
第二本征函数在半区固定符号；本项目还多出 (1) 的原子非局部扰动。

因此以下路线正式关闭：

\[
M^-\succeq0
\Longrightarrow
\text{odd ground 在 }(0,a)\text{ 定号}
\Longrightarrow
\langle u,s\rangle\ne0.
\]

任何可行替代必须使用真实 ground equation 的额外算术结构，或直接证明 leading exterior flux
非退化；一般 polarization、半区 PF、Hopf 或 Sturm oscillation 均不足。

参考：Mateusz Kwaśnicki and Jacek Mucha, *Extension technique for complete Bernstein functions
of the Laplace operator*, J. Evol. Equ. 18 (2018), arXiv:1707.02475。
