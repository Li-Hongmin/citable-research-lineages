> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# q-shift 重排与 (L=0) Newton 层的全 (m) 正性

日期：2026-08-15。

本 note 给出 note 156 的一个完整 (q)-shift 恒等式，并关闭其
(L=0)（即 (M=L+1=1)）的 falling-factorial (gamma) 系数。
没有把有限层数值计算外推到一般 (L)。

## 1. 记号

令 (D=3m+3, d=D-2)，并置

\[
w_q=c_q\binom Dq,
\qquad 2\le q\le m+1,
\]

其中 (c_q) 如 note 156 式 (1)。令
\[
A_r(x)=\sum_{a=0}^r \left\{\begin{matrix}r\\a\end{matrix}\right\}a!x^a,
\]
以及
\[
E_{r,h}(x)=\sum_{s\ge0}
 \frac{\binom rs\binom hs}{\binom ds}A_{r-s}(x).
\tag{1}
\]
二项式系数超出范围时约定为零。

定义
\[
K_1=-3w_2,
\quad
K_q=w_q(D-q)-w_{q+1}(q+2) (2\le q\le m),
\quad
K_{m+1}=w_{m+1}(D-m-1).
\tag{2}
\]

## 2. 完整 q-shift 恒等式

在 note 156 式 (8) 的每个固定 \(s\) 中，将第二项作 \(q\mapsto q-1\)。
用
\[
\binom{D-q-2}{s}\frac{D-q-1}{D-q-1-s}
 =\binom{D-q-1}{s}
\]
合并相邻项；原式中 \(s=D-q-1\) 的未配对项恰由 note 156 的边界项
补齐。得到严格恒等式
\[
\boxed{
\gamma_{m,h,L}=\frac1{(L+2)!}
 [x^{L+1}]\sum_{q=1}^{m+1}
 K_q A_{q+1}(x)E_{D-q-1,h}(x).}
\tag{3}
\]

这把原先的 \((q,s)\) 双和压缩为单个带符号 \(K_q\) 的和；
它没有假设 \(K_q\) 逐项为正。事实上 \(K_q\) 的低 \(q\) 段一般为负。

另有
\[
\frac{K_q}{w_q(D-q)}
 =\frac{q^2+3q-6m-4}{(2m-q)(q-1)}
\quad(2\le q\le m),
\tag{4}
\]
末项 \(K_{m+1}=w_{m+1}(D-m-1)\) 单独由式 (2) 给出；
\(m=1,q=m+1=2\) 时式 (4) 不适用。

## 3. (L=0) 的全 (m) 正性

由于 \(A_r(x)=x+O(x^2)\) 对所有 \(r\ge1\)，式 (1) 的常数项只有
\(s=r\) 贡献。因此
\[
[x]A_{q+1}(x)E_{D-q-1,h}(x)
 =\frac{\binom h{D-q-1}}{\binom d{D-q-1}}=:a_q.
\tag{5}
\]
当 \(a_q\ne0\) 时必有 \(q\ge Q:=\max(1,D-1-h)\)。特别地，
\(Q=1\) 只在 \(h=d\) 时出现。\(a_q\) 随 \(q\) 单调不减：令 \(r=D-q-1\)，则
\[
\frac{a_{q+1}}{a_q}
 =\frac{d-r+1}{h-r+1}\ge1.
\tag{6}
\]

设尾和 (T_Q=\sum_{q=Q}^{m+1}K_q)，并约定 (T_{m+2}=0)。若
Q>m+1（等价于 h<2m+1），所有 a_q 均为零，结论立即成立；以下设
Q\le m+1。
从式 (2) 直接望远镜得
\[
T_Q=w_Q(D-Q)+\sum_{p=Q+1}^{m+1}w_p(D-2p-1)>0
\quad(Q\ge2),
\tag{7}
\]
而
\[
T_1=w_2(D-5)+\sum_{p=3}^{m+1}w_p(D-2p-1)>0.
\tag{8}
\]
这里使用 (w_p>0)、(D-5=3m-2>0)、以及
(D-2p-1\ge m>0) 对 (p\le m+1)。

由 (K_q=T_q-T_{q+1}) 的 Abel 变换，
\[
\sum_{q=Q}^{m+1}K_qa_q
 =T_Qa_Q+\sum_{q=Q+1}^{m+1}T_q(a_q-a_{q-1})\ge0.
\tag{9}
\]
代入 (3) 即得
\[
\boxed{\gamma_{m,h,0}\ge0
\quad\text{对所有 }m\ge1, 0\le h\le d.}
\]

## 4. 边界

式 (3) 是一般 \(L\) 的严格重排；式 (9) 只关闭 \(L=0\)。
对 \(L\ge1\)，\(A_{q+1}E_{D-q-1,h}\) 的 \(x^{L+1}\) 系数不再随
\(q\) 给出同一简单单调序列，故不能直接套用尾和 Abel 论证。
首个严格例子是 \(m=1,D=6,d=4,h=1,L=1\)：两个 \(q\)-项的
\(x^2\) 系数依次为
\[
 [x^2]A_2E_{4,1}=2,
 \qquad [x^2]A_3E_{3,1}=\frac74,
\]
已经下降；所以 \(L=0\) 的单调性机制不能形式上延伸到下一层。
一般 \(\gamma_{m,h,L}\ge0\) 仍是独立未闭合命题。

对下一层 \(L=1\)，该缺口还可压成一个单重超几何不等式。令
\(r_q=D-q-1\)，并置
\[
 a_q=\frac{\binom h{r_q}}{\binom d{r_q}},\qquad
 b_q=\sum_{s=0}^{r_q-1}
       \frac{\binom{r_q}s\binom hs}{\binom ds},
\]
其中越界二项式仍取零。由于
\(A_{q+1}(x)=x+(2^{q+1}-2)x^2+O(x^3)\)，有精确式
\[
 [x^2]A_{q+1}(x)E_{r_q,h}(x)
   =b_q+(2^{q+1}-2)a_q=:t_q .
\]
因此
\[
 \gamma_{m,h,1}=\frac1{6}\sum_{q=1}^{m+1}K_qt_q
 =\frac1{6}\sum_{q=2}^{m+1}w_q
   \bigl((D-q)t_q-(q+1)t_{q-1}\bigr).
\tag{10}
\]
第二个等号是把 \(K_1=-3w_2\) 与相邻项合并后的严格离散分部求和。
括号并不逐项为正：最小例为 \(m=2,h=5,q=3\)，其值为
\(-6/7\)；但完整加权和仍为正。故 \(L=1\) 的首个未闭合命题可明确写成
式 (10) 的全 \(q\) 加权超几何不等式，而不是再使用逐项正性假设。

## 5. 对 (h) 的精确差分：新的最薄接口

对
\[
E^{(d)}_{r,h}(x):=
\sum_s\frac{\binom rs\binom hs}{\binom ds}A_{r-s}(x)
\]
直接使用 Pascal 恒等式和
\[
\frac{\binom r{u+1}}{\binom d{u+1}}
 =\frac rd\frac{\binom{r-1}u}{\binom{d-1}u}
\]
得到严格差分式
\[
\boxed{
E^{(d)}_{r,h+1}(x)-E^{(d)}_{r,h}(x)
 =\frac rd E^{(d-1)}_{r-1,h}(x).}
\tag{14}
\]
故若令
\[
\widetilde t_q(h):=[x^2]A_{q+1}(x)E^{(d-1)}_{D-q-2,h}(x),
\qquad r_q=D-q-1,
\]
则
\[
\boxed{
\gamma_{m,h+1,1}-\gamma_{m,h,1}
 =\frac1{6d}\sum_{q=1}^{m+1}K_qr_q\widetilde t_q(h).}
\tag{15}
\]
这把“随 \(h\) 的正性”压成同一类单和。其权重尾和可以完全显式化：对
\(Q\ge2\)，
\[
\sum_{q=Q}^{m+1}K_qr_q
 =w_Q(D-Q)(D-Q-1)
 +\sum_{p=Q+1}^{m+1}w_p(D-p)(D-2p-2)\ge0,
\tag{16}
\]
而
\[
\sum_{q=1}^{m+1}K_qr_q
 =w_2(D-2)(D-6)
 +\sum_{p=3}^{m+1}w_p(D-p)(D-2p-2)\ge0.
\tag{17}
\]
（\(m=1\) 时首项为零；\(m\ge2\) 时严格为正。）
但是 \(\widetilde t_q(h)\) 通常随 \(q\) 下降，不能直接用 (16)--(17) 的 Abel
变换推出 (15)；这就是比式 (10) 更薄、仍未闭合的首个超几何不等式。

式 (10) 的首层 (L=1) 现已闭合；见 [note 162](162-l1-newton-coefficient-positivity-by-cumulative-binomial-kernel.md)。
