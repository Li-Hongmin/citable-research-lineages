> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RH 等价于平方根多个显式低频 Möbius 余弦模

日期：2026-08-14。

依赖：
[note 079](079-path-dst-reduces-the-centered-defect-to-sqrtN-low-modes.md)、
[note 112](112-the-finest-scale-rh-gate-has-an-unconditional-square-root-rank-tail.md)。

证据等级：前缀和矩阵的显式奇异向量、note 112 的谱尾估计，
以及 Mertens 向量在该正交基上的 Parseval 恒等式。

note 112 将最细尺度 RH 门压到一个未显式的 \(\sqrt Y\)-rank 移动子空间。
本文将该子空间替换为前缀和矩阵的显式低频余弦基，
并且保持 RH 的双向等价性。

## 1. 前缀和的显式 SVD

令 \(m\ge2\)，并记

\[
(C_ma)(d)=\sum_{n\le d}a(n),
\qquad1\le d\le m.
\tag{1}
\]

对 \(1\le k\le m\)，置

\[
\theta_{m,k}=\frac{(2k-1)\pi}{2m+1},
\tag{2}
\]

\[
v_{m,k}(n)=c_{m,k}
\cos\left((n-\tfrac12)\theta_{m,k}\right),
\qquad1\le n\le m,
\tag{3}
\]

其中 \(c_{m,k}>0\) 使 \(\|v_{m,k}\|_2=1\)。这些向量是 \(C_m\) 的右奇异向量，且

\[
s_{m,k}
=\frac1{2\sin(\theta_{m,k}/2)}.
\tag{4}
\]

因此

\[
\boxed{
\|C_ma\|_2^2
=\sum_{k=1}^ms_{m,k}^2
|\langle a,v_{m,k}\rangle|^2.}
\tag{5}
\]

当 \(k\le\sqrt m\) 时，

\[
s_{m,k}\asymp\frac mk,
\qquad
c_{m,k}\asymp m^{-1/2},
\tag{6}
\]

其中常数绝对。

## 2. 显式低频能量

定义

\[
K_m=\lceil\sqrt m\rceil,
\tag{7}
\]

以及

\[
\mathcal E_m^{\rm low}
=\sum_{k=1}^{K_m}s_{m,k}^2
|\langle\mu_{\le m},v_{m,k}\rangle|^2.
\tag{8}
\]

由 (3)、(6)，它等价于完全显式的加权余弦和能量

\[
\boxed{
\mathcal E_m^{\rm low}
\asymp
m\sum_{k\le\sqrt m}\frac1{k^2}
\left|
\sum_{n\le m}\mu(n)
\cos\left((n-\tfrac12)\theta_{m,k}\right)
\right|^2.}
\tag{9}
\]

特别地，\(\mathcal E_m^{\rm low}\ll m^{2+\varepsilon}\) 等价于

\[
\boxed{
\sum_{k\le\sqrt m}\frac1{k^2}
\left|
\sum_{n\le m}\mu(n)
\cos\left((n-\tfrac12)\theta_{m,k}\right)
\right|^2
\ll_\varepsilon m^{1+\varepsilon}.}
\tag{10}
\]

## 3. RH 等价性

### 定理

黎曼猜想等价于：对每个 \(\varepsilon>0\)，(10) 对所有 \(m\ge2\) 成立。

**RH \(\Rightarrow\) (10)。** 当 \(a(n)=\mu(n)\) 时，

\[
(C_m\mu)(d)=M(d).
\tag{11}
\]

由 (5) 的正交性，

\[
\mathcal E_m^{\rm low}
\le\|C_m\mu\|_2^2
=\sum_{d\le m}|M(d)|^2.
\tag{12}
\]

RH 下的经典 \(M(d)\ll_\delta d^{1/2+\delta}\) 因此给出

\[
\mathcal E_m^{\rm low}ll_\varepsilon m^{2+\varepsilon},
\tag{13}
\]

即 (10)。

**(10) \(\Rightarrow\) RH。** 对 note 112 中的尺度 \(Y\)，取

\[
m=\lfloor2eY\rfloor.
\tag{14}
\]

令 \(P_{m,K_m}\) 为 \(\{v_{m,k}:k\le K_m\}\) 上的正交投影。
由 note 112 的因子分解 \(W_Y=B_YX_YC_m\) 与 \(\|B_YX_Y\|\ll1\)，

\[
\|W_YP_{m,K_m}\mu\|_2^2
\ll\|C_mP_{m,K_m}\mu\|_2^2
=\mathcal E_m^{\rm low}.
\tag{15}
\]

另一方面，由 \(P_{m,K_m}\) 是 \(C_m\) 的前 \(K_m\) 个右奇异向量投影，

\[
\begin{aligned}
\|W_Y(I-P_{m,K_m})\mu\|_2
&\le \|B_YX_Y\|\,
\|C_m(I-P_{m,K_m})\mu\|_2\\
&\le C s_{m,K_m+1}\|\mu_{\le m}\|_2.
\end{aligned}
\]

使用 \(s_{m,K_m+1}\ll m/K_m\)、\(\|\mu_{\le m}\|_2^2\le m\) 与 \(m\asymp Y\)，得到

\[
\|W_Y(I-P_{m,K_m})\mu\|_2^2
\ll Y^2.
\tag{16}
\]

由三角不等式，

\[
\begin{aligned}
\|W_Y\mu\|_2^2
&\le2\|W_YP_{m,K_m}\mu\|_2^2
+2\|W_Y(I-P_{m,K_m})\mu\|_2^2\\
&\ll_\varepsilon Y^{2+\varepsilon}.
\end{aligned}
\tag{17}
\]

note 111 的等价定理遂给出 RH。\(\square\)

## 4. 与 note 079 及现有指数和的边界

note 079 对 Selberg--Barban--Vehov 首壳的另一个路径差分算子得到
\(\sqrt{N/\log N}\) 个 DST 低模。本文的对象不同：(10) 直接作用于裸
Möbius 系数的前缀和矩阵，基函数是 Dirichlet--Neumann 余弦，
等价性依赖 notes 110--112 的最细 log-dilation coercivity。

对 (10) 使用 Davenport 的一致对数节省

\[
\sup_\theta\left|\sum_{n\le m}\mu(n)e^{i\theta n}\right|
\ll_A\frac{m}{(\log m)^A}
\tag{18}
\]

只给出左边

\[
\ll_A\frac{m^2}{(\log m)^{2A}},
\tag{19}
\]

而目标是 \(m^{1+\varepsilon}\)。Wei Zhang 2022 在附加零自由假设下的一致
\(m^{3/4+\varepsilon}\) 上界也只给出 \(m^{3/2+\varepsilon}\)。
所以现有统一指数和结果仍缺少平方根级消去。

这个失配是实质性的，但 (10) 要求的是 \(k^{-2}\) 加权平均，
而不是每个 \(k\) 的一致平方根上界。因此下一个最小问题应是直接估计 (10) 的
weighted low-mode large sieve，而不是继续改善 \(\sup_\theta\) 界。
