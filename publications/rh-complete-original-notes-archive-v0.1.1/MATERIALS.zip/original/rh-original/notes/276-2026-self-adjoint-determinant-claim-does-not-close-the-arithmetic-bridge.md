> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 2026 自伴 Hilbert--Schmidt 行列式声称与当前算术桥的关系

日期：2026-08-16。

## 1. 触发材料

Yoshinori Shimizu 的 2026 年预印本声称从一个自伴 Hilbert--Schmidt 算子
构造正则化行列式 \(F_K\)，再证明 \(F_K\equiv\xi\)，从而把零点放到临界线。
该材料的公开 Zenodo 记录同时明确注明：稿件“contains fatal errors within the
proofs”，因此不能作为已证 RH 的来源。

## 2. 逻辑定位

自伴性本身只给出行列式模型的零点位置：

\[
F_K(s)=e^{a+b(s-\frac12)}
\det\nolimits_2\!\bigl(I+i(s-\tfrac12)K\bigr),
\qquad K=K^*,
\]

所以 \(F_K\) 的非平凡零点落在 \(\Re s=\frac12\)。但 RH 需要的是
\[
F_K(s)\equiv \xi(s).
\]
这不是由自伴性、紧预解式或 Hilbert--Schmidt 性质推出的；它要求把
算术 Euler/prime-power 贡献、边界反射、有限窗口 counterterm 与无限窗口极限
逐项识别，并证明所有剩余项在同一个测试空间上消失。

换言之，若只得到
\[
\frac{d}{ds}\log F_K(s)
=\frac{d}{ds}\log\xi(s)
\quad\text{在中心邻域成立},
\]
则必须独立证明该导数恒等式的两侧配对确实来自同一个无循环的算术 trace。
把“显式公式 ledger”本身作为 target-identification 输入，或把边界/残差投影的
极限交换留作形式操作，都会把未证明的 arithmetic intertwiner 重新藏入
\(F_K=\xi\) 这一步。

## 3. 与本项目当前缺口的对应

本项目已经把同一缺口写成可审计的固定权能量门：

\[
E_N(w)=\int_{\mathbb R}w(t)
\left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt
\ll_\varepsilon N^{1+\varepsilon}.
\]

对 \(w\ge0\)、零频正质量且有有限频率矩，这个门与 RH 双向等价（见
notes 212、246）。因此一个新的自伴模型只有在其比较恒等式无条件推出该
Möbius signed cancellation，或等价地给出完整的 prime/reflection intertwiner，
才会越过当前门；单独构造 \(K=K^*\) 不会降低算术难度。

## 4. 裁决

该预印本可作为算子语言的启发，但不能吸收为 RH 证明，也不能替代
notes 165、177、212 所标出的 signed arithmetic bridge。当前最强可审计成果
仍是 note 275 的
\[
A_a^\pm>0\quad\left(0<a\le\tfrac12\log 11\right),
\]
而全尺度 RH 门仍未闭合。

