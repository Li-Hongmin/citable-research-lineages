> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Lehmer 尾能量的指数字典

日期：2026-08-17。

本 note 把 notes 347、438、439 合并成一个参数化结论。它不声称给出
RH 的无条件证明，而是精确说明任何尾能量幂次界所能排除的零点区域。

令
\[
I_N\ge0
\]
为指数尾能量，并定义
\[
\mathfrak e_I:=\inf\left\{\theta\ge0:
  \ \forall\varepsilon>0,\quad
  I_N\ll_\varepsilon N^{\theta+\varepsilon}\right\},
\]
其中若不存在这样的 \(\theta\)，约定 \(\mathfrak e_I=+\infty\)。令
\[
\beta_*:=\sup\{\Re\rho:\zeta(\rho)=0,\ 0<\Re\rho<1\}.
\]

## 指数上界推出零点自由半平面

若对某个 \(\theta\) 有
\[
I_N\ll_\varepsilon N^{\theta+\varepsilon}
\quad(\forall\varepsilon>0),
\tag{1}
\]
则 note 347 的有限维评价不等式
\[
|M(N)-1|^2\le \frac{I_N}{\pi}Q_N,
\qquad Q_N\ll\log(2N),
\]
给出
\[
M(N)\ll_\varepsilon N^{\theta/2+\varepsilon}.
\tag{2}
\]
将其代入
\[
\frac1{\zeta(s)}=s\int_1^\infty M(x)x^{-s-1}\,dx
\]
可把 \(1/\zeta\) 延拓为 \(\Re s>\theta/2\) 的全纯函数。因此
\[
\zeta(\rho)=0\quad\Longrightarrow\quad
\Re\rho\le\theta/2,
\qquad
\beta_*\le\theta/2.
\tag{3}
\]

## 离线零点给出反向下界

若存在零点 \(\rho\) 的实部 \(\beta>1/2\)，note 439 已证明：对每个
\(\delta>0\)，有无穷多个 \(N\) 满足
\[
I_N\gg_{\rho,\delta}\frac{N^{2\beta-2\delta}}{\log(2N)}.
\tag{4}
\]
所以任意满足 (1) 的 \(\theta\) 都必须满足
\(\theta\ge2\beta\)。令 \(\delta\downarrow0\) 得
\[
\boxed{\mathfrak e_I\ge2\beta_* .}
\tag{5}
\]

## 临界指数的精确门

RH 成立时，note 342 的反向估计给出
\[
I_N\ll_\varepsilon N^{1+\varepsilon},
\]
故 \(\mathfrak e_I\le1\)。另一方面，若 RH 不成立，则存在某个
\(\beta>1/2\)，由 (5) 得 \(\mathfrak e_I>1\)。因此
\[
\boxed{
\mathrm{RH}
\quad\Longleftrightarrow\quad
\mathfrak e_I\le1
\quad\Longleftrightarrow\quad
\forall\varepsilon>0,\quad I_N\ll_\varepsilon N^{1+\varepsilon}.
}
\tag{6}
\]

在这里，\(\mathfrak e_I\le1\) 足够推出右侧：给定 \(\varepsilon>0\)，按下确界
定义选取集合中的 \(\theta<1+\varepsilon/2\)，再把该界中的小余量吸收到
新的 \(\varepsilon/2\) 中即可。

这里的第二个等价并不是把尾能量当作正核后自动得到的；它依赖
Lehmer 矩阵的显式评价常数以及 Mellin 延拓。式 (5) 还说明，任何试图
以 \(\theta<1\) 的统一幂次界绕开 RH 的路线，在存在离线零点时必然失败；
真正的未决任务仍是无条件证明临界指数不超过 1，亦即保留 Möbius 符号的
reciprocal-product signed cancellation / arithmetic intertwiner。
