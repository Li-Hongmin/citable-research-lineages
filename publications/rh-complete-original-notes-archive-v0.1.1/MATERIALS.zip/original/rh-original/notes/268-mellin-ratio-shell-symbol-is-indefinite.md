> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mellin 比值壳的精确 Fourier 符号与逐壳正化障碍

日期：2026-08-16。

本 note 把 note 267 的加性 surrogate 换回原始 reciprocal-product 核，给出
一个不依赖近似的逐壳符号恒等式。它说明：正能量的全局正性来自未截断的
log-ratio 核；任何避开对角线 \(u=0\) 的非零比值壳，在 Fourier 侧都不能被
逐壳正化。

## 1. 精确 log-ratio 表示

令

\[
 w\in L^1(\mathbb R),\qquad
 K(u)=\int_{\mathbb R}w(t)e^{itu}\,dt,
 \qquad
 F_N(t)=\sum_{n\le N}\mu(n)n^{it}.
\]

假设 \(\int_{\mathbb R}(1+t^2)w(t)\,dt<\infty\)，并取偶实测试函数
\(\eta\in C_c^2(\mathbb R)\)。定义

\[
 k_\eta(u)=\eta(u)K(u),
 \qquad
 E_{N,\eta}=\sum_{m,n\le N}\mu(m)\mu(n)
 k_\eta\!\left(\log\frac mn\right).
\tag{1}
\]

取 Fourier 变换

\[
 \widehat f(\xi)=\int_{\mathbb R}f(u)e^{-i\xi u}\,du.
\]

因 \(k_\eta\in C_c^2(\mathbb R)\)，Fourier 反演给出

\[
 \boxed{
 E_{N,\eta}=\frac1{2\pi}\int_{\mathbb R}
 \widehat{k_\eta}(\xi)|F_N(\xi)|^2\,d\xi .
 }
\tag{2}
\]

这里没有把 \(m,n\) 近似成加性变量；\(\log(m/n)\) 被完整保留。乘积定理还给出

\[
 \widehat{k_\eta}=\widehat\eta*w,
\tag{3}
\]

因为 \(\widehat K=2\pi w\)。因此比值壳的 Fourier multiplier 是正权 \(w\)
与壳窗 Fourier 变换的卷积，而不是 \(w\) 本身。

## 2. 避开对角线的壳必然变号

假设

\[
 \eta\in C_c^2(\mathbb R\setminus\{0\}),
 \qquad k_\eta\not\equiv0.
\]

则 \(k_\eta(0)=0\)。又因 \(k_\eta\in C_c^2\)，
\(\widehat{k_\eta}\in L^1(\mathbb R)\)，故 Fourier 反演在零点给出

\[
 \frac1{2\pi}\int_{\mathbb R}\widehat{k_\eta}(\xi)\,d\xi
 =k_\eta(0)=0.
\tag{4}
\]

若 \(\eta\) 与 \(K\) 均为偶实函数，则 \(\widehat{k_\eta}\) 也是连续的偶实函数。
由 (4)，它不可能处处非负或处处非正；结合
\(\widehat{k_\eta}\not\equiv0\)，得到

\[
 \boxed{
 \widehat{k_\eta}
 \text{ 在正测度邻域上同时取正值和负值。}
 }
\tag{5}
\]

这是一条纯解析结论：不使用 Möbius 的任何算术性质。对当前 detector，\(K(0)>0\)
保证取足够靠近零但仍避开零点的窄壳时 \(k_\eta\not\equiv0\)。
对远离零的某个具体壳，若 \(K\) 在该壳上恰好消失，则该壳贡献本身为零；否则
(5) 仍适用。

## 3. 与全局正能量的区别

未截断时 \(\eta\equiv1\)，\(k_\eta=K\)，且

\[
 \widehat{k_\eta}=2\pi w\ge0,
 \qquad
 k_\eta(0)=K(0)>0.
\]

所以全局能量 \(E_N(w)\) 是保留对角点 \(u=0\) 的正 Fourier Gram。
一旦按 log-ratio 把它切成对角邻域与非对角壳，非对角壳的符号必须由不同壳
之间的 cancellation 重新恢复；不能逐壳声称正性、PSD 或 Schur 补偿。

更具体地，取一个光滑分割

\[
 1=\eta_0+\sum_{j\ge1}\eta_j,
\]

其中 \(\eta_0\) 支持在零点邻域、每个 \(\eta_j\) 支持在不含零的 log-ratio
壳上，则

\[
 E_N(w)=E_{N,\eta_0}+\sum_{j\ge1}E_{N,\eta_j},
\]

而每个非零项的 Fourier 符号都具有 (5) 的正负频带。这里的“壳间 signed
intertwiner”不是技术性余项，而是恢复全局正能量所必需的结构。

## 4. 对当前 RH 门的精确含义

式 (2) 把 note 243 的 dyadic signed block 门推广到真实乘法坐标：需要控制的
不是某个逐壳正二次型，而是

\[
 \sum_j\frac1{2\pi}
 \int\widehat{k_{\eta_j}}(\xi)|F_N(\xi)|^2\,d\xi
\]

中各变号符号的联合抵消。仅使用 Menon 型短区间正窗口、Fejér 正核或 ordinary
Toeplitz PSD，均不能给出该抵消。若能证明总能量

\[
 E_N(w)\ll_\varepsilon N^{1+\varepsilon},
\]

则按 note 212 直接进入 RH；但 (5) 也说明了为什么把问题改写成“每个壳
分别正定”并不能降低原始算术难度。

这条壳符号结果是对原始 Mellin 比值核的严格补充，不是 RH 证明，也不依赖有限
数值扫描。

## 5. 固定有限秩频率修正也不能逐壳正化

由 (5) 可取一个闭区间 \(I\) 和 \(c>0\)，使
\(\widehat{k_\eta}(\xi)\le -c\) 对 \(\xi\in I\) 成立。于是乘法算子
\(M_{\widehat{k_\eta}}\) 在 \(L^2(I)\) 上有无限维负子空间。

若 \(R\) 是任意自伴有限秩算子，\(\ker R\) 在 \(L^2(I)\) 中仍为无限维。
对任意单位向量 \(f\in\ker R\cap L^2(I)\)，有

\[
 \langle (M_{\widehat{k_\eta}}+R)f,f\rangle
 =\int_I\widehat{k_\eta}(\xi)|f(\xi)|^2\,d\xi
 \le -c<0.
\]

因此

\[
 \boxed{\text{非对角壳的频率算子不能由任何固定有限秩自伴修正变成 PSD。}}
\]

这比有限维 divisor 主块的负惯性更强：即使允许带符号的有限秩 Feshbach、
Schur 或 Yukawa 补偿，壳级别仍保留无限多个负方向。可行的桥必须是增长秩或
真正的跨壳 signed intertwiner；它不能只支付固定数量的局部原子。
