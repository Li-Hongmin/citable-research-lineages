> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 非零正 Mellin 权的截断 Gram 算子范数下界

日期：2026-08-16。

本 note 给出一个与 note 269 互补的谱障碍：即使不切分非对角壳，任意非零
连续正 Mellin 权的有限截断 Gram 算子也有近线性的范数。因此不能用
对所有系数都成立的 Bessel/large-sieve 估计替代 Möbius 的算术抵消。

## 命题

令 \(w:\mathbb R\to[0,\infty)\) 连续、属于 \(L^1(\mathbb R)\) 且不恒为零，定义
\[
 G_N(m,n)=\int_{\mathbb R}w(t)(m/n)^{it}\,dt,
 \qquad 1\le m,n\le N.
\]
则存在常数 \(c_w>0\) 和 \(N_w\)，使
\[
 \boxed{\ \|G_N\|_{\mathrm{op}}\ge c_w\,\frac{N}{\log N}
 \qquad(N\ge N_w).\ }
\tag{1}
\]

## 证明

取 \(t_0\) 使 \(w(t_0)>0\)，并取 \(c,\delta>0\) 满足
\(w(t)\ge c\) 当 \(|t-t_0|\le\delta\)。令
\[
 a_n=N^{-1/2}e^{-it_0\log n},\qquad 1\le n\le N,
\]
则 \(\sum_{n\le N}|a_n|^2=1\)。当
\[
 |t-t_0|\le\frac1{4\log N},
\]
有 \(|(t-t_0)\log n|\le1/4\)，故
\[
 \left|\sum_{n\le N}a_n n^{it}\right|
 =N^{-1/2}\left|\sum_{n\le N}e^{i(t-t_0)\log n}\right|
 \ge \sqrt N\cos(1/4).
\]
于是
\[
\begin{aligned}
a^*G_Na
&=\int_{\mathbb R}w(t)
\left|\sum_{n\le N}a_n n^{it}\right|^2dt\\
&\ge
\frac{c\,\cos^2(1/4)}{2\log N}\,N,
\end{aligned}
\]
当 \(N\) 足够大使上述小区间包含于 \([t_0-\delta,t_0+\delta]\) 时成立。
由于 \(\|a\|_2=1\)，这给出 (1)。

等价地，未归一化向量 \(b_n=e^{-it_0\log n}\) 满足
\[
\int w(t)\left|\sum_{n\le N}b_n n^{it}\right|^2dt
\gg_w\frac{N^2}{\log N}.
\tag{2}
\]

## 含义

式 (2) 排除了一个常见但过强的替代路线：若试图证明
\[
\int w(t)\left|\sum_{n\le N}a_n n^{it}\right|^2dt
\ll N^{1+\varepsilon}
\]
对所有 \(|a_n|\le1\) 或所有 \(\ell^2\) 系数成立，则该命题已被
\(a_n=e^{-it_0\log n}\) 反例否定。标准 large-sieve/Bessel 估计的算子常数
至少为 \(N/\log N\)，而非 \(N^\varepsilon\)。

这不是对 Möbius 向量 \(a_n=\mu(n)\) 的反例；它精确说明剩余任务不能由
coefficient-blind 的谱范数估计完成，必须利用 Möbius 的乘法结构和 signed
correlation。与 note 212 的通用 RH 等价门结合后，任何成功证明都必须在
实际 Möbius 向量上获得额外的近 \(N^{-1}\) 级算术节省。
