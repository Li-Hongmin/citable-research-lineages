> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 两个正弦模把 universal detection 降为紧集无零性

日期：2026-08-13。

依赖：[note 081](081-every-offline-zero-is-visible-in-one-fixed-sine-mode.md)。

状态更新：本 note 提出的紧矩形任务已由
[note 086](086-first-two-sine-modes-are-a-rigorous-universal-detector.md) 的 Arb 辐角原理证书闭合；
以下第 4 节保留为发现阶段的数值证据，不再承担定理证明。

## 1. 二模行列式

令

\[
W_k(s):=\int_1^2\sin\pi k(t-1)t^{s-1}dt,
\qquad
c_k:=W_k(1)=\frac{1-(-1)^k}{\pi k},
\tag{1}
\]

\[
C_k(s):=\frac{c_k}{(s-1)^2}-W_k'(s).
\tag{2}
\]

定义

\[
\boxed{
D(s):=C_1(s)W_2(s)-C_2(s)W_1(s).
}
\tag{3}
\]

因 \(c_1=2/\pi,c_2=0\)，

\[
\boxed{
D(s)=\frac{2W_2(s)}{\pi(s-1)^2}
+W_1(s)W_2'(s)-W_1'(s)W_2(s).
}
\tag{4}
\]

除 \(s=1\) 外它解析；在 \(s=1\) 至多有边界极点。

## 2. 非零行列式推出二模 universal detector

设 \(\rho\) 是 \(\zeta\) 的 \(q\) 重零点，

\[
\zeta(s)=a_\rho(s-\rho)^q+O((s-\rho)^{q+1}),
\qquad a_\rho\ne0.
\tag{5}
\]

note 081 的固定模 Mellin 像为

\[
\widehat{\mathscr R}_k(s)
=\frac{C_k(s)}{\zeta(s)}
+W_k(s)\frac{\zeta'(s)}{\zeta(s)}+W_k'(s).
\tag{6}
\]

- \(q\ge2\)：若 \(C_k(\rho)\ne0\)，则 (6) 有 \(q\) 阶极点。若两个模都没有该
  最高阶极点，则 \(C_1(\rho)=C_2(\rho)=0\)，故 \(D(\rho)=0\)。
- \(q=1\)：若两个模都无极点，则
  \[
  C_k(\rho)+a_\rho W_k(\rho)=0\qquad(k=1,2),
  \tag{7}
  \]
  消去 \(a_\rho\) 即得 \(D(\rho)=0\)。这里不需除以任何可能为零的 \(W_k(\rho)\)。

因此：

**定理 1（二模充分条件）。** 若

\[
\boxed{
D(s)\ne0\qquad\left(\frac12<\Re s<1\right),
}
\tag{8}
\]

则每个满足 \(1/2<\Re\rho<1\) 的离线零至少被 \(k=1,2\) 中的一个模检出。进一步，若对每个
\(\varepsilon>0\)，

\[
\sum_{Y<N\le2Y}|\mathcal R_{N,k}|^2
\ll_\varepsilon Y^{2+\varepsilon}
\qquad(k=1,2),
\tag{9}
\]

则 RH 成立。

## 3. 高频无零性是解析定理

置 \(b=\log2\)、\(E=2^s\)，并作变量替换 \(t=e^u\)：

\[
W_k(s)=\int_0^b g_k(u)e^{su}du,
\qquad
g_k(u):=\sin\!\bigl(\pi k(e^u-1)\bigr).
\tag{10}
\]

因 \(g_k(0)=g_k(b)=0\)，三次分部积分在
\(1/2\le\Re s\le1\) 上一致给出

\[
W_k(s)=\frac{A_k(s)}{s^2}+O_k(|s|^{-3}),
\qquad
W_k'(s)=\frac{A_k'(s)}{s^2}+O_k(|s|^{-3}),
\tag{11}
\]

其中

\[
A_1(s)=\pi(1+2E),
\qquad
A_2(s)=2\pi(1-2E).
\tag{12}
\]

代入 (4)：

\[
\boxed{
D(s)=D_0(s)+O(|s|^{-5}),
}
\tag{13}
\]

\[
\boxed{
D_0(s):=
\frac{4(1-2E)}{s^2(s-1)^2}
-\frac{8\pi^2bE}{s^4}.
}
\tag{14}
\]

特别地，\(|\Im s|\to\infty\) 时一致有

\[
\frac{s^4D(s)}4
=1-\bigl(2+2\pi^2b\bigr)E+O(|s|^{-1}).
\tag{15}
\]

而

\[
\left|1-\bigl(2+2\pi^2b\bigr)E\right|
\ge
\bigl(2+2\pi^2b\bigr)\sqrt2-1>0.
\tag{16}
\]

故存在显式可计算的 \(T_0<\infty\)，使

\[
\boxed{
D(s)\ne0
\quad
\left(\frac12\le\Re s\le1, |\Im s|\ge T_0\right).
}
\tag{17}
\]

所以 (8) 已严格降为有限矩形上的紧集无零性。

## 4. 数值观测；尚非证书

可复现脚本
[`scratch/probe_two_sine_detector.py`](../scratch/probe_two_sine_detector.py)
以 2048 点 Gauss--Legendre、\(61\times6001\) 主网格及分片矩形辐角变化给出：

\[
0.500001\le\Re s\le0.999999,
\qquad |\Im s|\le3000
\tag{18}
\]

内数值零点计数为 \(0\)。归一化行列式

\[
\eta(s):=\frac{|D(s)|}{|C_1W_2|+|C_2W_1|}
\tag{19}
\]

的扫描最小值约为

\[
\min\eta\approx0.2006377.
\tag{20}
\]

在 \(s\approx\tfrac12+3000i\) 处，默认网格得到

\[
|D(s)|\approx1.04803\times10^{-12},
\qquad
\frac{|D(s)-D_0(s)|}{|D_0(s)|}\approx6.37\times10^{-4},
\tag{21}
\]

与 (15) 的自然 \(|s|^{-4}\) 衰减一致，不是近零迹象。全部 30 个高度 100 的分片矩形数值
winding 均为零；这仍只是浮点诊断。

## 5. 当前最简单元

```mermaid
flowchart LR
  Z["any ζ-zero in β>1/2"] --> M{"D(ρ)≠0?"}
  M --> K["k=1 or 2 has Mellin pole"]
  K --> Q["two fixed cutoff means"]
  Q --> RH((RH))
  A["IBP asymptotic"] --> H["high |t| zero-free"]
  H --> C["compact rectangle only"]
  C --> M
```

本 note 写成时尚缺两项；当前状态为：

\[
\begin{array}{ll}
(A)&D(s)\ne0\text{ 的有限矩形 interval/argument-principle 证书：已由 note 086 证明};\\
(B)&k=1,2\text{ 的联合 arithmetic cutoff 均方 }(9)：仍未解决.
\end{array}
\tag{22}
\]

(A) 已由独立 Arb 实现交叉验证；(B) 才是剩余的算术平方根消去。第 4 节的浮点扫描本身仍不
被晋级为证据，严格结论只依赖 note 086 的区间证书。
