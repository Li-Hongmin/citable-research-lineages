> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The frequency-sign channel is the minimal missing intertwiner

## Exact Fourier divisor map

令 \(d=\log X\)、\(t_a=\log a\)，在 Fourier 变量 \(\xi\) 中定义

\[
(T_Xe_a)(\xi)=e^{i\xi t_a},
\qquad
(J_df)(\xi)=e^{i\xi d}f(-\xi).
\]

这些指数可理解为任意有限频带上的 \(L^2\) 向量；若
\(h\in L^1(\mathbb R)\)，也可直接放在 \(L^2(|h(\xi)|\,d\xi)\) 中。

则 \(J_d\) 是 unitary involution，并且

\[
J_dT_Xe_a=T_Xe_{X/a},
\qquad
\boxed{J_dT_X=T_XR_X}.
\]

对任意偶实 symbol \(h(\xi)\)，令 \(M_h\) 为乘法算子。其 ordinary 与
reciprocal 压缩分别为

\[
G_X=T_X^*M_hT_X,\qquad
H_X=T_X^*M_hJ_dT_X=G_XR_X.
\]

逐 entry 计算得到

\[
(H_X)_{ab}
=\frac1{2\pi}\int_{\mathbb R}h(\xi)
e^{i\xi(d-t_a-t_b)}\,d\xi,
\]

即正是 \(g(\log(X/(ab)))\) 的 reciprocal Hankel kernel。

## 绝对值化的代价

写

\[
h(\xi)=|h(\xi)|\,S(\xi),
\qquad S(\xi)=\operatorname{sgn}h(\xi).
\]

形式上可以把 reciprocal operator 写成

\[
M_hJ_d=M_{|h|}J_h,
\qquad J_h:=M_SJ_d.
\]

若 \(S\) 是偶实 sign，则 \(J_h\) 仍是 unitary involution；但

\[
J_hT_Xe_a=S(\xi)e^{i\xi(d-t_a)}
\]

通常不再属于有限维指数空间
\(\operatorname{span}\{e^{i\xi\log b}:b\mid X\}\)。

只要 \(S\) 在两个正测度区间取不同常值，或在某处有 sign jump，
\(S(\xi)e^{i\xi t}\) 就不可能是有限个纯指数的线性组合：后者是整函数/连续
的，而前者保留了 sign 的非解析跳变。故

\[
\boxed{J_hT_X\not\subseteq\operatorname{Ran}T_X}
\]

是变号 symbol 下的最小频率通道缺口。

## 对实际 boundary symbol 的应用

note 174 已严格给出 V15 的

\[
h(\xi)=\operatorname{Re}\!\left[\zeta(i\xi)K_{15}(i\xi)\right]
\]

在 \(\xi=0\) 与 \(\xi=2\) 取相反符号。因此把 \(h\) 替换为 \(|h|\) 虽然会得到
一个正的 multiplier，却必然同时引入 \(S(\xi)\)-channel；这个 channel
不能被原有限 divisor basis 吸收。

所以真正的 A/Weil 桥必须至少包含

\[
\bigl(T_X,\; S T_X,\; J_d\bigr)
\]

或等价的增长频率通道，并保持
\(R_X\)-parity；只比较 \(G_X\) 的正性，或只把 \(h\) 取绝对值，都会丢掉
reciprocal signed cancellation。

本 note 把缺口写成精确的 finite-basis invariance 条件；它不是 RH 证明。
