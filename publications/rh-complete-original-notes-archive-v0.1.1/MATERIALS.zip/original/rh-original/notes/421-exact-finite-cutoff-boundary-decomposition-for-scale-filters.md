> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 421. 有限截断尺度滤波器的精确边界分解

## 1. 记号

令 \(q\ge2\)，\(P(z)=\sum_{j=0}^{J}c_jz^j\)，并令
\[
 \beta_j=c_jq^{-j},\qquad
 B_\infty(y)=\sum_{n\ge\lceil y\rceil}\frac{\mu(n)}n,\qquad
 A_X=\sum_{n\le X}\frac{\mu(n)}n .
\]
有限截断尾写成
\[
 B_X(y)=\sum_{\lceil y\rceil\le n\le X}\frac{\mu(n)}n .
\]
由 \(B_\infty(1)=0\)，对 \(y\le X\) 有精确关系
\[
 B_X(y)=B_\infty(y)+A_X,
 \tag{1}
\]
而 \(B_X(y)=0\) 对 \(y>X\) 成立。

## 2. 尾部的精确分解

有限滤波系数
\[
 b_{P,X}(m)=
 \sum_{\substack{0\le j\le J\\q^j\mid m\\m/q^j\le X}}
 c_j\mu(m/q^j)
\]
的 reciprocal 尾为
\[
 T_{P,X}(k)=\sum_{j=0}^{J}\beta_j B_X(k/q^j).
\]
令
\[
 I_X(k)=\{j:0\le j\le J,\ k\le q^jX\}.
\]
将 (1) 代入，得到对每个 \(k\le q^JX\) 的精确恒等式
\[
 \boxed{
 T_{P,X}(k)
 =\sum_{j\in I_X(k)}\beta_jB_\infty(k/q^j)
 +A_X\sum_{j\in I_X(k)}\beta_j .
 }
 \tag{2}
\]
与无限尾
\[
 T_P(k)=\sum_{j=0}^{J}\beta_jB_\infty(k/q^j)
\]
相减，边界余项为
\[
 \boxed{
 R_{P,X}(k):=T_{P,X}(k)-T_P(k)
 =A_X\sum_{j\in I_X(k)}\beta_j
 -\sum_{j\notin I_X(k)}\beta_jB_\infty(k/q^j).
 }
 \tag{3}
\]

## 3. 内部区间与尾部盲区

若 \(1\le k\le X\)，则 \(I_X(k)=\{0,\ldots,J\}\)，故
\[
 T_{P,X}(k)=T_P(k)+P(q^{-1})A_X.
 \tag{4}
\]
特别地 \(T_P(1)=0\)，所以
\[
 \boxed{T_{P,X}(1)=P(q^{-1})A_X.}
 \tag{5}
\]
因此 \(P(q^{-1})\ne0\) 时，任何正平方尾能量都直接包含 reciprocal
Mertens 观测：
\[
 \sum_k(2k-1)|T_{P,X}(k)|^2
 \ge |P(q^{-1})|^2|A_X|^2.
 \tag{6}
\]
这正是一般零模判据中的直接 RH-strength 门。

若 \(P(q^{-1})=0\)，则 (4) 中的常数边界项完全消失；所有截断信息只出现在
\[
 X<k\le q^JX
\]
的 moving-kink 边界带以及无限尾 \(T_P\) 的截断余项中。因而“删去
\(k=1\) 零模”并没有给出免费平方根界，而是把全部信息转移到边界带。

## 4. 二项差分的校准

对 \(P(z)=1-qz\)，有 \(\beta_0=1,\beta_1=-1\)，于是
\[
 T_{P,X}(k)=B_X(k)-B_X(k/q).
\]
在 \(k\le X\) 的内部区间，
\[
 T_{P,X}(k)=B_\infty(k)-B_\infty(k/q),
\]
而在 \(X<k\le qX\) 的边界带，
\[
 T_{P,X}(k)=-B_X(k/q).
\]
这把 note 400 的 dyadic 边界写成了 (2)--(3) 的特例，并严格显示
其未控制部分不是小误差，而是唯一剩余的低尺度信息通道。

## 5. 路线结论

式 (2)--(6) 给出有限尺度滤波器的完整二分：

1. \(P(q^{-1})\ne0\)：有限正能量直接观测 \(A_X\)，其平方根级界已经是
   RH-strength；
2. \(P(q^{-1})=0\)：内部无限尾差分不再观测 \(A_X\)，但必须证明 moving-kink
   边界带的联合 signed cancellation；这正是当前未解决的算术缺口。

所以有限截断无法把 note 420 的无限尾 RH 等价自动变成无条件估计；边界
项必须作为独立对象处理。
