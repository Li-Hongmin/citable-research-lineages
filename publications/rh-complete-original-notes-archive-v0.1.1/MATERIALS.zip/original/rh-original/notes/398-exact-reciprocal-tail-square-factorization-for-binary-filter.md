> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Reciprocal 核的精确尾部平方分解与二进制滤波 RH 门

## 1. 一个有限维恒等式

令 \(c_1,\ldots,c_M\) 为任意实数，并记
\[
K(m,n)=\frac{\min(m,n)}{\max(m,n)}.
\]
定义尾和
\[
T_k(c)=\sum_{n=k}^{M}\frac{c_n}{n}.
\]
则有精确恒等式
\[
\boxed{
\sum_{m,n\le M}c_mc_nK(m,n)
=\sum_{k=1}^{M}(2k-1)\,T_k(c)^2.}
\tag{1}
\]

证明只需展开右端：\(c_mc_n/(mn)\) 的系数为
\[
\sum_{k\le\min(m,n)}(2k-1)
=\min(m,n)^2,
\]
所以得到 \( \min(m,n)^2/(mn)=K(m,n)\)。这同时给出
reciprocal 核的显式 Cholesky 分解，不涉及任何渐近假设。

## 2. 应用于二进制 Mellin 滤波器

令
\[
b_{q,X}(m)=\sum_{\substack{0\le j\le q\\2^j\mid m\\m/2^j\le X}}
(-1)^j\binom qj\,\mu(m/2^j),
\]
即 \(A_q(t)F_X(t)=(1-2^{it})^q\sum_{n\le X}\mu(n)n^{it}
=\sum_m b_{q,X}(m)m^{it}\)。其支撑在 \(m\le M_q:=2^qX\)。

定义截断尾函数
\[
B_X(y)=\sum_{\lceil y\rceil\le n\le X}\frac{\mu(n)}n,
\]
约定 \(B_X(y)=A_X(X)\) 对 \(y\le1\)，\(B_X(y)=0\) 对 \(y>X\)，其中
\[
A_X(z)=\sum_{n\le z}\frac{\mu(n)}n.
\]
交换有限求和得到每个尾和的精确式
\[
T_k(b_{q,X})
=\sum_{j=0}^{q}(-1)^j\binom qj\,2^{-j}
B_X\!\left(\frac{k}{2^j}\right).
\tag{2}
\]
因此
\[
\sum_{m,n\le2^qX}b_{q,X}(m)b_{q,X}(n)K(m,n)
=\sum_{k\le2^qX}(2k-1)
\left[
\sum_{j=0}^{q}(-1)^j\binom qj2^{-j}
B_X\!\left(\frac{k}{2^j}\right)
\right]^2.
\tag{3}
\]
式 (3) 保留了所有 moving-kink 折点，避免了 note 396 被撤回的错误
Toeplitz 张量化。

## 3. 精确的 RH-strength 门

取 \(k=1\)。由
\[
\sum_{j=0}^{q}(-1)^j\binom qj2^{-j}=2^{-q}
\]
得到
\[
T_1(b_{q,X})=2^{-q}A_X(X).
\tag{4}
\]
由正平方分解，
\[
Q_{q,X}:=\sum_{m,n\le2^qX}b_{q,X}(m)b_{q,X}(n)K(m,n)
\ge4^{-q}|A_X(X)|^2.
\tag{5}
\]

因此，若对某个 \(q=q(X)=o(\log X)\) 能证明自然支撑尺度上的估计
\[
Q_{q,X}\ll_\varepsilon (2^qX)^{1+\varepsilon},
\tag{6}
\]
则
\[
|A_X(X)|
\ll_\varepsilon
2^q(2^qX)^{1/2+\varepsilon}
=X^{1/2+\varepsilon+o(1)}.
\tag{7}
\]
由 Abel 变换，这给出
\[
M(X)=\sum_{n\le X}\mu(n)\ll_\varepsilon X^{1/2+\varepsilon},
\]
即 RH-strength 的 Mertens 界。临界阶
\(q\asymp\log X/\log\log X\) 仍满足 \(q=o(\log X)\)，所以同一结论仍适用。

## 结论

式 (1)--(3) 是二进制滤波器的正确正能量接口：它把 reciprocal 双和精确
化成截断 Möbius 尾部的加权平方和。与此同时，式 (5)--(7) 证明了一个
严格边界：任何在自然支撑上达到 \(M_q^{1+\varepsilon}\) 的正能量估计，
本身已经蕴含 RH-strength 的 Mertens 界。因而剩余任务不是再寻找形式上的
正化，而是证明真正的 dyadic 尾部 signed cancellation。
