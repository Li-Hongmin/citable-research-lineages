> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一般 Wiener--Hopf/Toeplitz 定理不能推出 zero-cyclicity

日期：2026-08-11；文献检索截止同日。

本文承接 notes 037、039、040，判定一般 truncated convolution、Toeplitz kernel 与 analytic-kernel
唯一延拓定理能否从

\[
P_ITP_Iu=0,
\qquad \widehat u(i/2)=\widehat u(-i/2)=0
\tag{1}
\]

推出 \(u=0\)。结论是否定的；若要继续，必须使用 actual Suzuki symbol 的专属结构。

## 1. 真实压缩方程保留两个外侧源

令 \(I=(-a,a)\)，\(T=m(D)\) 为 reduced Archimedean multiplier 与有限 prime shifts 的和。
式 (1) 等价于

\[
Tu=g_-+g_+,
\qquad
\operatorname{supp}g_-\subset(-\infty,-a],
\quad
\operatorname{supp}g_+\subset[a,\infty).
\tag{2}
\]

Fourier 侧为

\[
m(\xi)\widehat u(\xi)
=\widehat g_-(\xi)+\widehat g_+(\xi).
\tag{3}
\]

polar orthogonality 只给 \(\widehat u(\pm i/2)=0\)，并不消除 (3) 中无限维的左右 Hardy 数据。

## 2. 三类现成定理的假设缺口

1. **Titchmarsh--Foiaş：** 支撑定理使用完整卷积的支撑端点，或 Volterra 单侧三角截断。式 (2)
   只说双侧卷积在中间区间为零，不能推出两个外侧源消失。
2. **Coburn--Simonenko：** 该定理作用于完整 Hardy projection 上的 classical Toeplitz operator。
   finite interval 在 Fourier 侧对应 Paley--Wiener/model-space compression；truncated Toeplitz kernels
   可以非平凡，经典 Lusin--Privalov 乘积论证不再适用。
3. **analytic-kernel UCP：** Suzuki 核在对角具有
   \(\frac12|t|\log|t|\) 主奇性，并在 active \(\log n\) 处有 kinks/atoms，不能跨这些界面作解析
   延拓。

有限 Wiener--Hopf factorization 当然可以把 (3) 写成 vector Riemann--Hilbert 问题；但 injectivity
需要预先证明实际 symbol 的 partial indices 不允许 homogeneous solution。对本题而言，这正是
zero-cyclicity 的另一种表述，而不是黑箱推论。

## 3. 匹配结构的无限维反例

note 039 的 screw function

\[
g_0(t)=\sum_{n\ge1}\frac{\log(en)}{\pi n^2}(\cos nt-1)
\tag{4}
\]

是连续、实偶、PSD，并具有与 Suzuki 相同的

\[
g_0(t)=\frac12|t|\log|t|+O(|t|)
\]

对角主奇性。当 \(a>\pi\) 时，整数指数系统在 \(L^2(-a,a)\) 中不完备，故相应 compressed
convolution kernel 为无限维。该核在反射下不变，所以至少一个奇偶分量无限维；再施加该扇区的
一个 polar 正交条件只降低至多一维，仍留下非零核向量。有限增加若干 frequency/shift 条件同样只
降低有限维。

因此不存在一个只依赖

\[
\text{compressed convolution}
+\text{Suzuki 主奇性}
+\text{有限 shifts}
+\text{一个 polar moment}
\]

的通用 injectivity 定理。该反例不声称 actual zeta kernel 存在不可见零模态；它只严格排除一般
结构黑箱。

## 4. 路线结论

截至 2026-08-11，没有现成 truncated Wiener--Hopf、Toeplitz-kernel completeness 或
analytic-kernel UCP 定理覆盖

\[
M_a^\sigma u=0,
\qquad \langle u,\phi_\sigma\rangle=0
\Longrightarrow u=0.
\]

后续若使用 factorization/completeness，必须证明 actual Suzuki symbol 的专属 partial-index 或
uniqueness-set 命题；不能再援引一般卷积唯一性作为较便宜中间步骤。

## 5. 直接文献边界

- A. Yu. Karlovich, *The Coburn--Simonenko theorem for Toeplitz operators acting between Hardy type
  subspaces of different Banach function spaces*, arXiv:1708.01475.
- A. Hartmann and M. Mitkovski, *Kernels of Toeplitz operators*, arXiv:1511.08326.
- T. Ransford, *A short complex-variable proof of the Titchmarsh convolution theorem*, J. Fourier
  Anal. Appl. 25 (2019), DOI: 10.1007/s00041-019-09679-9.
- N. Makarov and A. Poltoratski, *Beurling--Malliavin theory for Toeplitz kernels*, arXiv:math/0702497.

这些来源给出完整 Hardy/Toeplitz kernel、支撑与 completeness 理论的适用范围；它们不包含针对
Suzuki symbol 的 zero-cyclicity 定理。
