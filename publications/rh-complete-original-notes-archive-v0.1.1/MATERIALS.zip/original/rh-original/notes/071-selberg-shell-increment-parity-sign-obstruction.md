> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Selberg 首壳增量的 parity 符号障碍

日期与检索截止：2026-08-12。

依赖：[note 064](064-selberg-affine-first-shell-rh-criterion.md)、
[note 065](065-barban-vehov-hminus1-obstruction-and-weak-mertens-bridge.md)、
[note 070](070-sawtooth-cell-boundaries-add-instead-of-telescope.md)。

## 1. 弄清问题

note 070 表明全部 floor packets 只恢复 \(M\)--\(\Psi\) 联合误差。剩余最便宜判别为

\[
\boxed{
\Lambda=-\mu*\log
\quad\Longrightarrow?\quad
\text{首壳 residual 的正交换子/耗散恒等式}.
}
\tag{1}
\]

```mermaid
flowchart LR
  A["multiplicative identity Λ=−μ∗log"] --> B["shell increments q_N(n)"]
  B --> C["prime/even parity: q>0"]
  B --> D["odd squarefree parity: q<0"]
  C --> E["no positive increment measure"]
  D --> E
  E --> F["only triangular H−1 kernel remains"]
  F --> G["need additive low-frequency / bilinear input"]
```

## 2. 拟定计划

\[
\text{exact residual}
\to dR
\to \operatorname{sgn}q_N
\to \text{triangular energy}
\to \text{historical parity barrier}.
\tag{2}
\]

## 3. 实现计划

### 3.1 完整仿射 residual 的最短形式

置

\[
L:=\log N,
\qquad
a_d:=\mu(d)\log(N/d),
\tag{3}
\]

\[
\mathcal A_N(x):=\sum_{d\le x}a_d,
\qquad
B_N:=\sum_{d\le N}\frac{a_d}{d}.
\tag{4}
\]

由

\[
\sum_{d\le y}a_d\left\lfloor\frac yd\right\rfloor
=\sum_{k\le y}\sum_{d\mid k}\mu(d)\log(N/d)
=L+\Psi(y),
\tag{5}
\]

且 \(N<d\le y\le2N\Rightarrow\lfloor y/d\rfloor=1\)，得到

\[
\boxed{
L\bigl(c_N+F_N(y/N)\bigr)
=R_N(y)
:=yB_N-\Psi(y)+\mathcal A_N(y)-\mathcal A_N(N).
}
\tag{6}
\]

这是 note 065 的 (24) 在卷积坐标中的最短写法。

### 3.2 离散增量有两种符号

对 \(N<n\le2N\)，定义

\[
q_N(n):=
\sum_{\substack{d\mid n\\d\le N}}a_d.
\tag{7}
\]

此时 \(n\) 的每个真因子均不超过 \(n/2\le N\)，故

\[
\boxed{
q_N(n)=\Lambda(n)-\mu(n)\log(N/n).
}
\tag{8}
\]

于是

\[
\boxed{
R_N(y)=R_N(N)+(y-N)B_N
-\sum_{N<n\le y}q_N(n),
}
\tag{9}
\]

或以测度写成

\[
\boxed{
dR_N=B_N\,dy-sum_{N<n\le2N}q_N(n)\delta_n.
}
\tag{10}
\]

若 \(n\) 为素数，则

\[
q_N(n)=\log N>0.
\tag{11}
\]

若 \(n\) 为平方自由合数，则

\[
q_N(n)=\mu(n)\log(n/N),
\tag{12}
\]

故 \(\Omega(n)\) 偶时为正，\(\Omega(n)\) 奇时为负。显式地，取 \(N=16\)：

\[
q_{16}(17)=\log16>0,
\qquad
q_{16}(30)=-\log(30/16)<0.
\tag{13}
\]

因此 (10) 不是正测度或负测度；任何逐点 monotonicity/dissipation 立即失败。

### 3.3 剩余正性只是原 \(H^{-1}\) 能量的恒等重写

记

\[
C_N:=R_N(N),
\qquad
g_N(y):=C_N+B_N(y-N).
\tag{14}
\]

展开 (9)：

\[
\begin{aligned}
\int_N^{2N}|R_N(y)|^2dy
={}&\int_N^{2N}|g_N(y)|^2dy\\
&-2\sum_nq_N(n)\int_n^{2N}g_N(y)\,dy\\
&+\sum_{m,n}q_N(m)q_N(n)K_N(m,n),
\end{aligned}
\tag{15}
\]

其中

\[
K_N(m,n):=2N-\max(m,n)
=\int_N^{2N}\mathbf1_{m\le y}\mathbf1_{n\le y}\,dy.
\tag{16}
\]

所以 \(K_N\succeq0\)，但这只是

\[
\sum_{m,n}q_N(m)q_N(n)K_N(m,n)
=\int_N^{2N}
\left|\sum_{N<n\le y}q_N(n)\right|^2dy
\ge0.
\tag{17}
\]

它不给上界。由于 \(q_N\) 混号，(15) 的 off-diagonal 与 affine cross 均无固定符号。
Graham/Murty/Ramaré--Zuniga-Alterman 控制的是

\[
\sum_n|q_N(n)|^2
\quad(H^0),
\tag{18}
\]

而 (17) 是累计和的三角核

\[
T^*T,
\qquad
(Tq)(y)=\sum_{N<n\le y}q(n)
\quad(H^{-1}).
\tag{19}
\]

从 (18) 到 (19) 的任意系数黑箱至多支付 \(\|T\|^2\asymp N^2\)，
正是 note 065 已识别的缺失次幂；正性没有回收它。

### 3.4 历史 parity barrier 的适用范围

DHJ Polymath 2014, Section 8 以 Liouville 权扰动说明：只使用线性 sieve
discrepancy 与主项的论证不能辨认奇偶素因子结构；文中明确把 sign-sensitive
bilinear expressions 指为越过 barrier 所需的新输入。

原始来源：
[DHJ Polymath](https://arxiv.org/abs/1407.4897)。

该文讨论的是 prime-gap sieve，并不直接证明本 RH 算子不可能存在额外恒等式。
但 (12)--(13) 在当前对象内给出同一局部符号机制。因此它支持的严格路线裁决仅为

\[
\boxed{
\text{ordinary positive/linear sieve data}
\not\Rightarrow
\text{所需 additive }H^{-1}\text{ damping}.
}
\tag{20}
\]

不能把 (20) 扩大成对所有 Möbius 专属双线性方法的不可能性结论。

## 4. 回顾反思

\[
\boxed{
\begin{array}{c|c}
\text{候选}&\text{裁决}\\
\hline
dR\text{ 单号}&\text{否：parity 使 }q_N\text{ 混号}\\
K_N\succeq0&\text{是，但只是目标能量本身}\\
H^0\to H^{-1}\text{ via positivity}&\text{差 }N\text{ 次幂}\\
\Lambda=-\mu*\log\text{ 的线性耗散}&\text{不存在}\\
\text{sign-sensitive bilinear/additive input}&\text{仍开放}
\end{array}
}
\tag{21}
\]

下一最简单元是首壳增量的低频指数和

\[
Q_N(\theta):=
\sum_{N<n\le2N}q_N(n)e(n\theta)
=\sum_{d\le N}a_d
\sum_{N/d<m\le2N/d}e(dm\theta).
\tag{22}
\]

必须判别 (22) 在 \(|\theta|\asymp N^{-1}\) 到固定小频率之间，是否存在
普通 Barban--Vehov \(H^0\) 看不见的 bilinear cancellation。若只在
\(\theta=0\) 使用 (5)，则仍是 \(M\)--\(\Psi\) 的 RH 级重述。

本 note 没有证明 RH。
