> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 偶局部 Weil 算子的严格正性推进到 \(\frac12\log10\)

日期：2026-08-12。

## 定理

设 \(A_a^+\) 为局部 Weil 算子的偶扇区。则

\[
\boxed{A_a^+>0,\qquad 0<a\le \frac12\log10.}
\tag{1}
\]

这是偶扇区定理。后续 [note 068](068-strict-local-weil-positivity-to-log10-half.md)
已闭合端点处的奇扇区，并将本文结论升级为完整 \(A_a\) 的正性。

## 1. 同源 scalar 下算子

固定端点

\[
a=\frac12\log10,qquad N=500,qquad R=280,qquad K=400.
\]

令 \(B_0\) 包含全部 active prime blocks、\(n<500\) 的正 even Yukawa
atoms 与 even polar 项，并写

\[
L_0=D+B_0,qquad P=P_{400},\qquad Q=I-P.
\]

已有严格 prime norm 界给出 \(B_0\succeq-\rho I\)，而 \(D\) 在 Fourier
基中为对角算子。令

\[
\mu=d_{400}-\rho
=2.1793610668864147930024334842\ldots>0.
\tag{2}
\]

保留完整 \(P\)-\(Q\) cross，只把 \(QL_0Q\) 降为 \(\mu Q\)：

\[
\underline L_0=
\begin{pmatrix}
 PL_0P&PB_0Q\\
 QB_0P&\mu Q
\end{pmatrix}
\preceq L_0.
\tag{3}
\]

确实，二者之差只有 \(Q\)-\(Q\) 块，且

\[
QL_0Q-\mu Q
=Q(D-d_{400}I)Q+Q(B_0+\rho I)Q\succeq0.
\]

因此 (3) 不是有限压缩补零；它是保留全部 cross 的合法无限维下算子。

## 2. 完整 Yukawa 族的有限 Parseval 闭合

取连续的 40 个完整全空间 atoms

\[
F=(r_{500}^+,r_{501}^+,\ldots,r_{539}^+),
\qquad U=PF,quad V=QF.
\]

由于其余 \(n\ge540\) 项仍为正 Gram 和，

\[
\underline L_{40}:=\underline L_0+FF^*
\preceq L_0+FF^*\preceq A^+_a.
\tag{4}
\]

记 \(X=PB_0Q\)。先消去无限补空间 \(Q\)，Woodbury 恒等式给出精确
有限 Schur 块

\[
\boxed{
S_{40}=S_0+E\mathcal K^{-1}E^*,
\quad S_0=PL_0P-\mu^{-1}XX^*,}
\tag{5}
\]

其中

\[
E=U-\mu^{-1}XV,
\qquad
\mathcal K=I+\mu^{-1}V^*V>0.
\tag{6}
\]

式 (6) 所需的无限补空间量全部由 Parseval 化为有限矩阵：

\[
XV=PB_0F-(PB_0P)U,
\qquad
V^*V=F^*F-U^*U.
\tag{7}
\]

这里 \(F^*F\) 是完整 40×40 atom Gram；所有不同 atoms 间的 cross 均被
保留。因而 (5) 没有孤立加入 \(PFF^*P\oplus0\) 的 Loewner 错误。

## 3. 两层 true-Schur 证书

对前 280 个坐标施加权威 \(N=500\) graph 的七个 Householder 合同。在

\[
\mathbf R^7\oplus\mathbf R^{273}\oplus\mathbf R^{120}
\]

中，先联合消去 273 维块，再消去 120 维块，同时把 40 个 Woodbury
coordinates 放在同一个 metric \(\mathcal K\) 中。

273 维块严格正：它等于已认证的 R280/N500 complement 加上 scalar
K400 相对 R280 的 PSD recovery，再加 atom 族的 PSD 更新。第一次消元后，
120 维 Schur 块的最小 interval Cholesky residual pivot 满足

\[
p_{\min}(C_{120})
\in[2.6682195333514722428\pm2.28\times10^{-42}]>0.
\tag{8}
\]

剩余 atom metric 为

\[
\mathcal K_2=\mathcal K+E_1^*C^{-1}E_1>0,
\]

故第二次 verified solve 合法。最终七维 true-Schur 的 pivot 排列为

\[
(6,5,2,1,0,4,3),
\]

七个 192-bit interval pivots 依次为

\[
\begin{aligned}
&4.3875786663357318018\times10^{-10}\pm7.11\times10^{-49},\\
&2.5495910211673719129\times10^{-14}\pm5.11\times10^{-49},\\
&2.4838336822335492599\times10^{-19}\pm5.07\times10^{-51},\\
&1.6070102878013046157\times10^{-24}\pm7.47\times10^{-52},\\
&3.1278695083639131610\times10^{-30}\pm2.38\times10^{-51},\\
&7.188037267089\times10^{-37}\pm7.64\times10^{-50},\\
&3.473\times10^{-45}\pm3.20\times10^{-49}.
\end{aligned}
\tag{9}
\]

全部区间下端严格为正。因此 \(S_{40}>0\)；结合 \(\mu Q+VV^*>0\)
及 Schur 惯性加法，得到 \(\underline L_{40}>0\)。由 (4) 即得端点
\(A^+_{\frac12\log10}>0\)。

## 4. 有序前缀的严格阈值

同一 scalar K400/N500 模型中，前 39 个 atoms 的最后 pivot 为

\[
p_7(39)=-2.827\times10^{-45}\pm3.04\times10^{-49}<0,
\tag{10}
\]

而 (9) 给出 \(p_7(40)>0\)。又因逐 atom 更新为 PSD，所有更短有序前缀
均不可能为正。因此 40 是该固定 scalar lift、按
\(r_{500},r_{501},\ldots\) 顺序加入时的严格最小长度。它不是所有可能
下模型所必需的普适秩下界。

## 5. 复现与来源闭合

权威执行顺序为

```bash
uv run --with numpy --with python-flint python -u \
  scratch/generate_log10_endpoint_contract_cache.py \
  192 400 500 + --export-full-safe-matrix

uv run --with numpy --with python-flint python -u \
  scratch/extract_log10_even_K400_full_contract_base.py --n500-clean

uv run --with numpy --with python-flint python -u \
  scratch/generate_log10_endpoint_contract_cache.py \
  192 400 500 + --export-yukawa-family 500 540

uv run --with numpy --with python-flint python -u \
  scratch/log10_even_K400_N500_multiatom_scalar_gate.py \
  scratch/log10_even_K400_N500_yukawa_500_540_parseval_arb_192.npz 40
```

源缓存显式记录

```text
parity=+, N=500, R=400, precision=192,
a=(log 10)/2, mu=2.179361066886414793...
```

最终产物同时记录 family、base 与 N500 Householder 来源，并固定
`exact_parseval=true, scalar_lift=true`。承重输出为

```text
scratch/log10_even_K400_N500_yukawa_500_540_scalar_gate_arb_192.out
scratch/log10_even_K400_N500_yukawa_500_540_scalar_gate_arb_192.npz
```

## 6. 域单调与结论边界

由既证的零延拓闭形式域嵌套与谱底单调性，端点结论传播到所有较小尺度，
得到 (1)。本文本身把偶扇区的严格正性端点从 \(\log3\) 推进到
\(\frac12\log10\)；完整算子的后续升级见 note 068。
