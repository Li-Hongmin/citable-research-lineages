> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 418. principal 紧支撑核的 Fourier 符号处处有正下界

## 1. log 坐标中的核

令 \(a=\log 2\)，并写 \(t=\log(m/n)\)。note 417 的核满足
\[
 \kappa(e^t)=5e^{-|t|}-2e^{-|t-a|}-2e^{-|t+a|}.
 \tag{1}
\]
在 \(|t|\le a\) 内这就是
\[
 \kappa(e^t)=4e^{-|t|}-e^{|t|},
\]
在 \(|t|\ge a\) 外为零。这里的紧支撑不是额外截断，而是三个 Lehmer 核的精确抵消。

## 2. 精确 Fourier 符号

取 \(\widehat f(\xi)=\int_{\mathbb R}f(t)e^{-i\xi t}\,dt\)。因为
\[
 \widehat{e^{-|t|}}(\xi)=\frac{2}{1+\xi^2},
\]
平移公式给出
\[
 \boxed{
 \widehat\kappa(\xi)=
 \frac{2(5-4\cos(a\xi))}{1+\xi^2}
 =\frac{2|2-e^{ia\xi}|^2}{1+\xi^2}.
 }
 \tag{2}
\]
特别地，
\[
 \frac{2}{1+\xi^2}\le \widehat\kappa(\xi)
 \le \frac{18}{1+\xi^2}
 \qquad(\xi\in\mathbb R).
 \tag{3}
\]
因此 principal filter 的尺度差分没有在任何实频率上产生零点；它只把基础
Lehmer 权 \(2/(1+\xi^2)\) 乘以 \(|2-e^{ia\xi}|^2\in[1,9]\)。

## 3. Möbius 能量的精确频谱表示

令
\[
 A_Y(\xi)=\sum_{n\le Y}\mu(n)n^{i\xi}.
\]
Fourier 反演与有限求和交换，结合
\(Q_w(Y)=\frac12\sum_{m,n\le Y}\mu(m)\mu(n)\kappa(\log(m/n))\)，得到
\[
 \boxed{
 Q_w(Y)=\frac1{2\pi}\int_{\mathbb R}
 \frac{5-4\cos((\log2)\xi)}{1+\xi^2}
 \left|A_Y(\xi)\right|^2\,d\xi .
 }
 \tag{4}
\]
例如 \(Y=1\) 时右端为
\(\frac1{2\pi}\int(5-4\cos((\log2)\xi))/(1+\xi^2)\,d\xi=3/2\)，
与 \(Q_w(1)=\frac12(2,-1)L_2(2,-1)^T=3/2\) 一致。

由 (3) 立即得到谱等价
\[
 \frac1{2\pi}\int_{\mathbb R}\frac{|A_Y(\xi)|^2}{1+\xi^2}\,d\xi
 \le Q_w(Y)
 \le
 \frac9{2\pi}\int_{\mathbb R}\frac{|A_Y(\xi)|^2}{1+\xi^2}\,d\xi .
 \tag{5}
\]

## 4. 对 RH 算术门的含义

式 (4) 是 note 417 归约的频谱版本。它有两个严格后果：

1. principal filter 没有消掉零频或任何临界频带；
2. 它与未滤波的 \(1/(1+\xi^2)\) Lehmer 能量只差一个介于 \(1\) 与 \(9\) 的乘子。

所以证明 \(Q_w(Y)\ll Y^{1+\varepsilon}\) 与证明同一 Möbius Dirichlet 多项式的
基础 \(H^1\)-型能量界在幂次上等价。这个恒等式排除了“尺度滤波器的正性本身
提供额外频谱衰减”的路线；剩余仍是 RH-strength 的 Möbius 频谱估计，而不是
一个新的无条件正性桥。

## 5. 数值核验

verify_principal_kernel_fourier_symbol.py 用复合 Simpson 积分在
\([-\log2,\log2]\) 上直接计算 (1) 的 Fourier 变换，并在多组实频率核对 (2)，
同时检查 (3) 的点态上下界。它只核验解析符号的归一化，不把有限数值范围外推为 RH 结论。
