> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(P(z)=1-2z\)：删掉 \(P(1/2)\) 尾部门后的 dyadic 区间差分与零模

## 1. 精确尾部

取
\[
P(z)=1-2z.
\]
对应系数为
\[
b(m)=\mu(m)-2\,\mathbf 1_{2\mid m}\mu(m/2).
\]
由 note 399 的一般尾式，
\[
T_P(k)=B_X(k)-B_X(k/2).
\tag{1}
\]

当 \(1\le k\le X\) 时，端点约定只造成单个 \(O(1/k)\) 项，主体精确为
\[
T_P(k)
=-\sum_{k/2\le n<k}\frac{\mu(n)}n.
\tag{2}
\]
当 \(X<k\le2X\) 时，
\[
T_P(k)
=-\sum_{k/2\le n\le X}\frac{\mu(n)}n,
\tag{3}
\]
而 \(k>2X\) 时尾部为零。因此 reciprocal 能量完全分成内部 dyadic
区间差分与一个截断边界带：
\[
Q_P
=\sum_{k\le X}(2k-1)|T_P(k)|^2
 +\sum_{X<k\le2X}(2k-1)|T_P(k)|^2.
\tag{4}
\]

## 2. 为什么 \(P(1/2)=0\) 真正删掉了一个观测模态

若 \(B_X(y)\) 在 \(1\le y\le X\) 上近似一个常数 \(C\)，则
\[
B_X(y)-B_X(y/2)\approx0
\]
在内部完全消失；这正是 \(P(1/2)=0\) 对常数尾模态的消除。对应的
递推算子 \(D B(y)=B(y)-B(y/2)\) 有低尺度常数零模：
\[
D(C)=0.
\]
因此对 \(P(z)=1-2z\) 的正能量上界，不能从 (4) 单独恢复
\[
A_X(X)=B_X(1).
\]
需要额外的边界归一化、另一个 \(P(1/2)\neq0\) 观测，或能够控制低尺度
零模的独立算术输入。

## 3. 对 RH 路线的判定

这条滤波器确实把问题从全局尾部改成了 dyadic 区间的 signed sums；
但它不是免费的 RH 证明入口：

1. 若重新加入任意 \(P(1/2)\neq0\) 的观测，note 399 已说明自然能量界
   立即回到 RH-strength 门；
2. 若坚持 \(P(1/2)=0\)，内部区间能量只控制差分，常数尾零模未被观测，
   必须另证边界/归一化；
3. \(X<k\le2X\) 的边界带是唯一可能重新携带该信息的位置，其平方根级
   控制本身就是新的 signed arithmetic 命题。

所以 \(P(z)=1-2z\) 给出了一个清晰的逃逸候选和清晰的缺口：它不再是
note 399 中的直接 RH 门，但要转回 RH，必须补上低尺度零模的独立控制。
