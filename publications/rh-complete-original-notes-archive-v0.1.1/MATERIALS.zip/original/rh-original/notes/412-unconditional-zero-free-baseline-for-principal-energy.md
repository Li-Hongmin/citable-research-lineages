> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 412. 主部能量的无条件零自由区基线

本 note 把经典零自由区给出的 Mertens 余项，逐步传递到 note 409 的主部
$Q_w$。结论是严格的 stretched-log 上界，但没有产生固定幂次节省，因而
不能越过 note 410 的 RH-equivalent 门。

## 1. 输入：经典 PNT 余项

令
\[
\Lambda(x)=(\log x)^{3/5}(\log\log x)^{-1/5}
\]
（对充分大的 $x$ 定义）。经典零自由区与 Perron--Abel 论证给出某个
绝对常数 $c_0>0$，使
\[
M(x):=\sum_{n\le x}\mu(n)
  \ll x\exp\{-c_0\Lambda(x)\}.
\tag{1}
\]
这里只使用这一已知无条件输入，不使用 RH 或任何 Möbius 二点相关估计。

## 2. 传递到 $M_1$

令
\[
U(x):=M_1(x)=\sum_{n\le x}n\mu(n).
\]
Abel 分部求和给出
\[
U(x)=xM(x)-\int_1^x M(t)\,dt.
\tag{2}
\]
由于 $\Lambda(t)$ 最终单调增加，(1)--(2) 蕴含：存在 $c_1>0$ 使
\[
|U(x)|\ll x^2\exp\{-c_1\Lambda(x)\}.
\tag{3}
\]
例如把积分区间分成 $t\le\sqrt{x}$ 与 $t>\sqrt{x}$：前一段是
$O(x^{3/2})$，后一段由
$\Lambda(t)\ge(1+o(1))2^{-3/5}\Lambda(x)$
控制；减小常数即可得到 (3)。

## 3. 传递到主部平方能量

由 note 409 的精确望远镜式，令 $D_Y(n)$ 为其式 (5) 中的 moving-cutoff
差，则
\[
Q_w(\mu_{\le Y})
\ll 1+\sum_{n<2Y}\frac{|D_Y(n)|^2}{n^3}.
\tag{4}
\]
式 (3) 对 $U(n)$ 与 $U(Y)$ 同样适用，因此对 $n\asymp Y$ 有
\[
|D_Y(n)|\ll Y^2\exp\{-c_2\Lambda(Y)\}.
\]
对 $n<Y$ 分段并利用 $\Lambda(n)$ 的单调性，(4) 给出某个 $c_3>0$：
\[
Q_w(\mu_{\le Y})
  \ll Y^2\exp\{-c_3\Lambda(Y)\}.
\tag{5}
\]
同样，note 411 的离散 Abel 桥给出 reciprocal 尾
\[
E(Y)\ll Y^2\exp\{-c_4\Lambda(Y)\}.
\tag{6}
\]

## 4. 与 RH 门的距离

因为 $\Lambda(Y)=o(\log Y)$，(5)--(6) 只是
\[
Y^{2-o(1)},
\]
而不是 $Y^{1+\varepsilon}$。note 410 已证明后者与 RH 等价；因此经典
零自由区、PNT 余项和 Abel 分部本身不能完成 RH。要把指数从 $2-o(1)$
推进到 $1+\varepsilon$，必须加入新的 signed Möbius 均方估计，或等价的
算术 intertwiner；仅靠主部的 PSD 性质没有这一步。

本 note 的作用是给出当前严格的无条件基线，而不是 RH 证据。

## 5. 固定幂次改进会给出什么

同一计算还能把任何固定幂次改进精确翻译成零自由线。假设对某个
\(0<\delta<1\)，有
\[
Q_w(\mu_{\le Y})\ll_\varepsilon Y^{2-\delta+\varepsilon}.
\tag{7}
\]
由 note 409 的下界与 note 410 的递推式，得到
\[
\sum_{n\le Y}\frac{|U(n)|^2}{n^3}
\ll_\varepsilon Y^{2-\delta+\varepsilon}.
\tag{8}
\]
在 \(X\le x<2X\) 上应用 Cauchy--Schwarz：
\[
\int_X^{2X}|U(x)|x^{-\sigma-1}\,dx
\ll_{\varepsilon} X^{1-\sigma+(2-\delta+\varepsilon)/2}.
\tag{9}
\]
因此 \(s\int_1^\infty U(x)x^{-s-1}\,dx\) 在
\(\Re s>2-\delta/2\) 全纯，亦即
\(1/\zeta(s-1)\) 在该半平面无极点。于是
\[
\zeta(\rho)=0\quad\Longrightarrow\quad
\Re\rho\le1-\frac\delta2.
\tag{10}
\]
这给出一个严格的中间目标：任何真实的固定幂次节省都会改善已知零自由区；
只有把指数推进到 \(1+\varepsilon\)，才到达 RH 的完整门槛。
