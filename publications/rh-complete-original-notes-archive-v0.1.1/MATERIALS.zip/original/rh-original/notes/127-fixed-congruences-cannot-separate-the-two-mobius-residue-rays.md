> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定同余不能分离两个 Möbius residue rays

日期：2026-08-14。

依赖：[note 126](126-the-endpoint-flat-rh-kernel-has-two-independent-collective-residues.md)。

证据等级：最大 universal modulus 与显式同余逼近。

note 126 把 two-residue 共振压缩为

\[
\frac{S_3(z)}{z^3}\approx
\pm\sqrt5\,\frac{S_1(z)}z.
\tag{1}
\]

本文判断最直接的算术输入 \(S_3\equiv S_1\pmod6\) 能否排除 (1)。

由

\[
n^3-n=n(n-1)(n+1)\in6\mathbb Z
\tag{2}
\]

逐项得到

\[
\boxed{S_3(z)\equiv S_1(z)\pmod6.}
\tag{3}
\]

而 \(z=2\) 时

\[
S_3(2)-S_1(2)=\mu(2)(8-2)=-6,
\tag{4}
\]

所以 \(6\) 是差 \(S_3-S_1\) 的最大 universal fixed modulus。

但 (3) 不给任何统一角隙。对每个充分大的整数 \(z\)，置

\[
A_z=1,
\tag{5}
\]

并在算术级数 \(1+6\mathbb Z\) 中取最接近 \(\sqrt5z^2\) 的整数 \(B_z\)。
则

\[
B_z\equiv A_z\pmod6,\qquad
|B_z-\sqrt5z^2|\le3.
\tag{6}
\]

因此

\[
\begin{aligned}
\delta_z
&=
\frac{|B_z^2-5z^4A_z^2|}
{B_z^2+5z^4A_z^2}\\
&\le
\frac{3(2\sqrt5z^2+3)}{5z^4}
=O(z^{-2})\longrightarrow0.
\end{aligned}
\tag{7}
\]

故不存在仅由 integrality 与 (3) 推出的常数 \(c>0\)，使

\[
|S_3^2-5z^4S_1^2|
\ge c(S_3^2+5z^4S_1^2).
\tag{8}
\]

这里 \((A_z,B_z)\) 是对“同余信息是否足够”的抽象反例，不声称每一对都是实际
Möbius moments。它严格关闭的是固定同余证明路线，而不是实际 Möbius 非共振命题。

更强地，存在与 \(z^2\) divisibility 完全兼容的无限 Pell 族。令

\[
U=9+4\sqrt5,\qquad V=U^{20}.
\tag{9}
\]

直接模 \(864\) 计算得

\[
V\equiv1+144\sqrt5\pmod{864}.
\tag{10}
\]

取

\[
N=4^t,\qquad z=12\cdot2^t,\qquad
V^N=X_t+Y_t\sqrt5.
\tag{11}
\]

因 \(N\) 为 \(2\)-幂，二项展开与
\(j\binom Nj=N\binom{N-1}{j-1}\) 给出：对 \(j\ge2\)，

\[
\binom Nj(144E)^j\in864N\,\mathbb Z[\sqrt5],
\qquad V=1+144E.
\tag{12}
\]

所以

\[
V^N\equiv1+144NE\pmod{864N}.
\tag{13}
\]

结合 \(E\equiv\sqrt5\pmod6\) 及 \(z^2=144N\)，得到

\[
X_t^2-5Y_t^2=1,\qquad
z^2\mid Y_t,\qquad
\frac{Y_t}{z^2}\equiv X_t\pmod6.
\tag{14}
\]

令

\[
A_t=\frac{Y_t}{z^2},\qquad B_t=X_t.
\tag{15}
\]

则 \((A_t,B_t)\) 同时满足 residue moments 的整数尺度与最大 universal 同余，
但

\[
\frac{|B_t^2-5z^4A_t^2|}
{B_t^2+5z^4A_t^2}
=\frac1{X_t^2+5Y_t^2}\to0.
\tag{16}
\]

所以固定模同余与 Pell 型近共振完全兼容。

结论：

\[
\boxed{
\text{\(S_3\equiv S_1\pmod6\) 是最大固定同余，但远不足以支付 two-residue 角分离}.}
\tag{17}
\]

若实际 Möbius moments 有非共振，必须来自随 \(z\) 增长的算术信息或与
mean-zero remainder \(T_V^{(0)}\) 的联结；固定模与整数性应停止作为主路线。
这不是 RH 的证明。
