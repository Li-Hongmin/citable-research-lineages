> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 所有正 detector 层都保留固定的不定 2x2 块

日期：2026-08-15。

相关文件：[note 119](119-the-positive-reciprocal-product-rh-kernel-is-uniformly-indefinite.md)、
[note 144](144-a-positive-degree-fifteen-detector-removes-four-collective-residues.md)、
[note 146](146-a-positive-degree-eighteen-detector-removes-five-collective-residues.md)。

## 1. 一般块结构

对任一端点 detector，定义 P(y)=sum_{c<=y} V(c/y) 与
K_x(a,b)=P(x/(ab))。由于 V(1)=0，有 P(1)=0。若某个非整数点满足
P(y0)>0，取 x=9k^2、a=3k、b=2k，便得到主子块

    [[0, P(3/2)], [P(3/2), P(9/4)]].

其行列式为 -P(3/2)^2<0，与 k 无关。因此完整 reciprocal-product 核不能直接
写成正 Gram、正 Schur complement 或正 Laplace--Hankel 核。

## 2. 新 detector 层的精确实例

直接固定 floor 截断得到：

| degree | P(3/2) | P(9/4) |
|---:|---:|---:|
| 15 | 70396/14348907 | 726036720400/22876792454961 |
| 18 | 543436/1052621468613 | 290745009329104/37073374918358782887 |
| 21 | 1641635/29456354619648 | 16590369447791281/8558996483176077875904 |

三行均严格为正，故三层都含有同一尺度不衰减的负特征值。这里的负性来自矩阵
结构，不是数值误差或有限高度扫描。

## 3. 对 RH 路线的含义

增加 detector degree、消除更多 Mellin residues，只能改变 signed Möbius 二次型的
collective skeleton；它不能凭 entrywise P>=0 产生算子正性。要证明
T_V(x) = O_epsilon(x^(1/2+epsilon))，必须在这个固定不定块及其全局耦合上保留
mu(a)mu(b) 的 arithmetic cancellation。

因此下一最小桥不是继续寻找正 Gram 分解，而是给出一个作用于完整 Möbius 向量的
signed dispersion / commutator 估计；若只控制 entrywise 正性或逐项绝对值，不能改变
RH-strength 的剩余门。
