> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Squarefree primorial star 具有余维一负惯性

日期：2026-08-14。

依赖：[note 118](118-an-endpoint-flat-detector-gives-an-exact-positive-reciprocal-product-rh-gate.md)、
[note 121](121-square-primorial-induced-matchings-force-two-sided-inertia-growth.md)。

证据等级：精确半整数公式、对角合同与严格对角占优。

note 121 的平方 primorial 负块使用坐标 \(p_k^2\)，而
\(\mu(p_k^2)=0\)。这留下一个真正与 RH 二次型有关的问题：负惯性增长是否在
squarefree Möbius 支撑上消失。本文给出否定答案。不过最后也说明，仅有这一
负惯性仍不能控制实际 Möbius 向量。

## 1. Squarefree star

令

\[
x=p_m^\#=\prod_{i=1}^m p_i,\qquad p_1=2,
\tag{1}
\]

并取

\[
a_j=2p_j,\qquad 2\le j\le m.
\tag{2}
\]

所有 \(a_j\) 均 squarefree，且

\[
\mu(a_j)=1.
\tag{3}
\]

当 \(m\ge6\) 时，\(a_j\le\sqrt x\)。记核

\[
K_{jk}=P\!\left(\frac{x}{a_ja_k}\right),
\tag{4}
\]

其中

\[
P(y)=\frac{\lfloor y\rfloor(\lfloor y\rfloor+1)}{y^3}
\{y\}(1-\{y\}).
\tag{5}
\]

## 2. 非对角元的精确半整数式

若 \(j\ne k\)，则

\[
\frac{x}{a_ja_k}=\frac{x}{4p_jp_k}
\tag{6}
\]

是半整数，因为 \(x/(2p_jp_k)\) 是奇整数。直接代入 (5) 得

\[
P\!\left(n+\frac12\right)
=\frac1{4(n+1/2)}-\frac1{16(n+1/2)^3}.
\tag{7}
\]

因此

\[
K_{jk}=\frac{p_jp_k}{x}
\left(1-\frac{4p_j^2p_k^2}{x^2}\right).
\tag{8}
\]

令

\[
D_{jj}=\frac{p_j}{\sqrt x},\qquad K=DMD.
\tag{9}
\]

则对 \(j\ne k\)，

\[
M_{jk}=1-d_{jk},\qquad
d_{jk}=\frac{4p_j^2p_k^2}{x^2}.
\tag{10}
\]

## 3. 对角缺陷的严格下界

置

\[
y_j=\frac{x}{4p_j^2}=n_j+\theta_j,qquad 0\le\theta_j<1.
\tag{11}
\]

由 (5) 可直接平方配方：

\[
M_{jj}=4y_jP(y_j)=1-e_j,
\tag{12}
\]

\[
e_j=
\frac{\left[n_j(1-\theta_j)-(n_j+1)\theta_j\right]^2}{y_j^2}.
\tag{13}
\]

写

\[
\theta_j=\frac{r_j}{2p_j},
\tag{14}
\]

其中 \(r_j\) 是 \(x/(2p_j)\) 模 \(2p_j\) 的最小正剩余。它是奇数，且
\(r_j\ne p_j\)，因为 \(x/(2p_j)\) 不被 \(p_j\) 整除。故

\[
|1-2\theta_j|=\frac{|p_j-r_j|}{p_j}\ge\frac2{p_j}.
\tag{15}
\]

另一方面，

\[
n_j(1-\theta_j)-(n_j+1)\theta_j
=y_j(1-2\theta_j)-2\theta_j(1-\theta_j).
\tag{16}
\]

因 \(2\theta(1-\theta)\le1/2\)，当 \(y_j\ge p_j/2\) 时，(15)--(16)
给出

\[
\left|n_j(1-\theta_j)-(n_j+1)\theta_j\right|
\ge \frac{y_j}{p_j},
\tag{17}
\]

从而

\[
e_j\ge\frac1{p_j^2}\ge\frac1{p_m^2}.
\tag{18}
\]

## 4. 余维一负子空间

精确写成

\[
M=J-E,
\tag{19}
\]

其中 \(J\) 为全一矩阵，\(E_{jj}=e_j\)，且 \(E_{jk}=d_{jk}\)。每行满足

\[
\sum_{k\ne j}d_{jk}
\le \frac{4m p_m^4}{x^2}.
\tag{20}
\]

对 \(m\ge6\)，有

\[
x^2>4m p_m^6.
\tag{21}
\]

基例是 \(x=13^\#=30030\)；以后由 Bertrand 不等式
\(p_{m+1}<2p_m\) 及

\[
\frac{x_{m+1}^2/(4(m+1)p_{m+1}^6)}
{x_m^2/(4mp_m^6)}
=\frac{m}{m+1}\frac{p_m^6}{p_{m+1}^4}
>\frac{m}{m+1}\frac{p_m^2}{16}>1
\tag{22}
\]

可归纳保持。条件 (21) 同时蕴含前面使用的
\(y_j\ge p_j/2\) 和 \(a_j\le\sqrt x\)。结合 (18)--(20)，\(E\) 严格
对角占优，因而 \(E\succ0\)。

在

\[
\mathbf1^\perp=\left\{v:\sum_{j=2}^m v_j=0\right\}
\tag{23}
\]

上，

\[
v^TMv=-v^TEv<0.
\tag{24}
\]

由正对角合同 (9)，原坐标中的显式负子空间为

\[
\mathcal S_m=
\left\{w:\sum_{j=2}^m p_jw_j=0\right\},
\tag{25}
\]

其维数为 \(m-2\)。因此

\[
\boxed{n_-(K)\ge m-2.}
\tag{26}
\]

特别地，负惯性已经在真实 squarefree Möbius 支撑上无界；平方坐标不是
note 121 现象的必要来源。

## 5. 对实际 Möbius 向量的边界

在这些坐标上，Möbius 向量恰为

\[
\boldsymbol\mu=(1,\ldots,1).
\tag{27}
\]

由于 (4) 的每个 entry 非负，且非对角 entry 严格为正，

\[
\boldsymbol\mu^TK\boldsymbol\mu>0.
\tag{28}
\]

所以 (25) 并不产生实际 RH 二次型的负上界。相反，它揭示更精确的结构：
同一 squarefree 主子矩阵有 \(m-2\) 维负空间，而算术向量的正谱贡献仍
压过其负谱贡献。下一步必须定量研究 Möbius 向量对增长正、负谱空间的
投影及跨块抵消；仅计数负特征值不会改变 RH 门的估计。

## 6. 结论

\[
\boxed{
\text{squarefree restriction 不消除增长负惯性，
但 Möbius 向量可在同一不定矩阵上保持正能量}.}
\tag{29}
\]

因此固定秩单侧谱模型的障碍已进入 Möbius 支撑，但尚未成为对
\(\mu^TP_x\mu\) 的承重估计。这不是 RH 的证明。
