> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fixed-band Mertens mode 是 endpoint commutator，不是 bulk mode

日期：2026-08-14。

依赖：[note 132](132-mellin-separation-of-the-balanced-mode-hits-the-fixed-band-observability-barrier.md)、
[note 075](075-continuous-cutoff-average-splits-into-endpoints-and-slope-variance.md)。

证据等级：精确 Mellin symbol 与 partition-of-unity commutator telescope。

note 132 发现 balanced reciprocal mode 的 fixed Mellin band。本文进一步定位
\(t=0\) Mertens mode：微分核在 product bulk 上精确杀死它，危险量只由 cutoff
commutators 与全局 endpoints 恢复。

令

\[
E(u)=e^{2\pi i/u},\qquad D=u\partial_u.
\tag{1}
\]

若 \(y=1/u\)，则 \(y\partial_y=-D\)。note 131 的核满足

\[
\boxed{
Q(1/u)=(D+3)(D+4)E(u).}
\tag{2}
\]

记

\[
L=(D+3)(D+4)=D^2+7D+12.
\tag{3}
\]

对 \(\chi\in C_c^\infty((0,\infty))\)，乘积法则给出

\[
L(\chi E)
=\chi LE+2(D\chi)(DE)+(D^2\chi+7D\chi)E.
\tag{4}
\]

采用 Mellin 变换

\[
\mathcal M_s[f]=\int_0^\infty f(u)u^{s-1}\,du.
\tag{5}
\]

紧支撑保证

\[
\mathcal M_s[Df]=-s\mathcal M_s[f].
\tag{6}
\]

把 (4) 中 \(DE\) 再分部积分，得到精确 commutator 恒等式

\[
\boxed{
\begin{aligned}
\mathcal M_s[\chi LE]
={}&(3-s)(4-s)\mathcal M_s[\chi E]\\
&+\mathcal M_s\!\left(
\bigl[D^2\chi+(2s-7)D\chi\bigr]E
\right).
\end{aligned}}
\tag{7}
\]

在 note 132 的承重线 \(s=3+it\) 上，bulk symbol 为

\[
\boxed{(3-s)(4-s)=(-it)(1-it).}
\tag{8}
\]

所以 \(t=0\) 的 bulk Mertens mode 被精确消去；它不是一个无权重常数 mode。

再令 \(\{\chi_j\}\) 是 product variable \(u\) 上局部有限的光滑 partition of
unity。在所有内部区域，

\[
\sum_jD\chi_j=0,\qquad
\sum_jD^2\chi_j=0.
\tag{9}
\]

因此 (7) 的 commutators 满足

\[
\boxed{
\sum_j
\mathcal M_s\!\left(
\bigl[D^2\chi_j+(2s-7)D\chi_j\bigr]E
\right)=0.}
\tag{10}
\]

内部 product shells 的 cutoff errors 精确 telescope。只有完整截断域的全局 endpoints
不能由 (10) 配对。

对原 detector，

\[
u=\frac{ab}{z^2},\qquad
z^{-2}\le u\le1.
\tag{11}
\]

所以 endpoint sectors 是

\[
ab\asymp1
\quad\text{与}\quad
ab\asymp z^2.
\tag{12}
\]

前者是低乘积端；后者正是 \(a,b\asymp z\) 的 top balanced shell。note 131 的
同号饱和例位于后一个 sector，因此与 (8)--(10) 完全一致：饱和来自 endpoint
commutator，而非 product bulk。

这修正了对 note 132 的解释，但不推翻其 observability barrier。若单独截取一个
balanced box，\(\chi\) 的导数项在 (7) 中恢复 \(t=0\)；只有把全部内部 product
shells 带符号重组后，该 mode 才 telescope。

该结构与 note 075 的“endpoint energy + slope variance”机制同型，但变量不同：
note 075 沿 cutoff \(X\) 微分，本文沿 product Mellin coordinate \(u=ab/z^2\)
微分。二者都说明连续 bulk cancellation 会把承重量搬到 endpoints，而非消除。

结论：

\[
\boxed{
\text{fixed-band \(t=0\) 障碍全部局部化到 product endpoints；
内部 Mellin bulk 有一阶 symbol zero 且 commutators 精确 telescope}.}
\tag{13}
\]

下一步应分别估计低乘积 endpoint 与 top balanced endpoint，并检查两端之间是否还有
note 128 式 signed cancellation。继续对内部 dyadic product boxes 逐块收费会人为
重建已经消失的 Mertens mode。这不是 RH 的证明。
