> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RH 下有限尺度尾差分能量界成立

本 note 补充 note 402 的反向蕴含，说明有限尺度尾差分的自然能量界与 RH
确实处在同一强度，而不是一个显然更强的附加假设。

## 1. 尾部的 Abel 表示

令
\[
M(x)=\sum_{n\le x}\mu(n),\qquad
B(k)=\sum_{n\ge k}\frac{\mu(n)}n.
\]
PNT 给出 \(\sum_{n\ge1}\mu(n)/n=0\)。对 \(x=k-1\) 作 Abel 分部求和，得到
\[
B(k)=-\frac{M(x)}x+\int_x^\infty\frac{M(t)}{t^2}\,dt,
\qquad x=k-1,
\tag{1}
\]
其中有限个小 \(k\) 只贡献一个常数，可单独吸收。

## 2. RH 下的尾衰减

RH 的标准等价 Mertens 估计给出：对任意 \(\delta>0\)，
\[
M(t)\ll_\delta t^{1/2+\delta}.
\tag{2}
\]
取 \(0<\delta<1/2\)，代入 (1) 得
\[
|B(k)|\ll_\delta k^{-1/2+\delta}
 +\int_k^\infty t^{-3/2+\delta}\,dt
\ll_\delta k^{-1/2+\delta}.
\tag{3}
\]

对 note 402 中任意固定有限尺度多项式
\[
P(z)=\sum_{j=0}^J a_jz^j,
\qquad
H_P(k)=\sum_{j=0}^J a_j2^{-j}B\!\left(\left\lceil k/2^j\right\rceil\right),
\]
有限项求和及 (3) 给出
\[
|H_P(k)|\ll_{P,\delta} k^{-1/2+\delta}.
\tag{4}
\]
因此
\[
\sum_{k\le Y}k|H_P(k)|^2
\ll_{P,\delta}
\sum_{k\le Y} k^{2\delta}
\ll_{P,\delta}Y^{1+2\delta}.
\tag{5}
\]
将 \(2\delta\) 改记为任意给定的 \(\varepsilon>0\)，便得到 note 402 所用的自然能量界
\[
E_P(Y)\ll_{P,\varepsilon}Y^{1+\varepsilon}.
\tag{6}
\]

## 3. 与 note 402 的合并结论

note 402 已证明：若 (6) 成立，则
\[
\mathcal F_P(z)=
\sum_{k\ge1}H_P(k)\bigl(k^{-z}-(k-1)^{-z}\bigr)
=\frac{P(2^{-(z+1)})}{\zeta(z+1)}
\]
在 \(\Re z>-1/2\) 延拓。只要 \(P(2^{-\rho})\ne0\) 覆盖所有潜在的
\(\zeta\)-零点 \(1/2<\Re\rho<1\)，这便反推出 RH。

故对这类多项式，尾能量界在该零点覆盖条件下与 RH 等价。特别地，
\(P(z)=1-2z\) 的唯一根为 \(z=1/2\)，而
\(2^{-\rho}=1/2\) 只可能发生在 \(\Re\rho=1\)；因此
\[
E_{1-2z}(Y)\ll_\varepsilon Y^{1+\varepsilon}
\quad\Longleftrightarrow\quad
\mathrm{RH}.
\]

这是一条精确的 RH-equivalent 算术判据，不是对 RH 的无条件证明；其未解决部分
恰是能量界的无条件平方根级估计。
