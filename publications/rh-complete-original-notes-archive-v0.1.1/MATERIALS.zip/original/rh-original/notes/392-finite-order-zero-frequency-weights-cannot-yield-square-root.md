> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有限阶零频消除不能从正能量直接得到平方根 Möbius 界

设 \(w:\mathbb R\to[0,\infty)\) 连续。假定存在整数 \(r\ge0\)、
\(c_0,\delta>0\)，使得

\[
w(t)\ge c_0|t|^{2r}\qquad (|t|\le\delta).
\tag{1}
\]

令

\[
F_N(t)=\sum_{n\le N}\mu(n)n^{it},
\qquad M(N)=F_N(0),
\qquad E_w(N)=\int_{\mathbb R}w(t)|F_N(t)|^2\,dt.
\tag{2}
\]

## 局部化下界

对所有实 \(t\)，

\[
|F_N'(t)|
\le \sum_{n\le N}\log n
\le N\log N.
\tag{3}
\]

当 \(N\) 足够大时，若 \(|M(N)|\le N\)，则

\[
\eta_N:=\frac{|M(N)|}{2N\log N}\le\delta.
\]

若 \(|t|\le\eta_N\)，由均值定理有

\[
|F_N(t)|\ge\frac{|M(N)|}{2}.
\tag{4}
\]

将 (1) 和 (4) 代入 (2)，得到严格下界

\[
\begin{aligned}
E_w(N)
&\ge c_0\frac{|M(N)|^2}{4}
  \int_{-\eta_N}^{\eta_N}|t|^{2r}\,dt \\
&=\frac{c_0}{2r+1}\,2^{-2r-3}
  \frac{|M(N)|^{2r+3}}
       {N^{2r+1}(\log N)^{2r+1}}.
\end{aligned}
\tag{5}
\]

如果某个正能量估计给出

\[
E_w(N)\ll_{w,\varepsilon}N^{1+\varepsilon},
\tag{6}
\]

那么 (5) 只能推出

\[
|M(N)|
\ll_{w,\varepsilon}
N^{\frac{2r+2+\varepsilon}{2r+3}}
(\log N)^{\frac{2r+1}{2r+3}}.
\tag{7}
\]

把 \(\varepsilon\) 吸收到指数后，主幂为

\[
\frac{2r+2}{2r+3}
=\frac23,\frac45,\frac67,\ldots
\quad(r=0,1,2,\ldots).
\tag{8}
\]

因此有限阶零频消除越多，单靠一阶 Lipschitz 局部化得到的 Mertens 指数反而越接近 \(1\)，
而不是 \(1/2\)。note 215 的二阶零点情形正是 \(r=1\)，给出 \(4/5\)。

## 解释与边界

这个结论只使用 (3) 的一般导数界，不否认额外算术结构可能带来更强估计；它说明的是：
正权的有限阶零频 Taylor 消除本身没有提供这种额外结构。若希望从 (6) 得到
\(M(N)\ll N^{1/2+\varepsilon}\)，必须加入统一的跨频率 signed cancellation、
高阶导数消失条件，或直接等价于 RH 的解析输入。

特别地，任何连续正权在零频附近满足 \(w(t)\asymp |t|^{2r}\) 的有限阶 detector，
都落入同一个局部化边界；有限个非负 detector 的组合仍由其最小零阶控制，
而有符号组合若先取绝对值，则只会提高有限阶 \(r\) 并加重 (8) 的损失。

这是一条路线关闭结果，不是 RH 证明；它把 note 215 的低频诊断升级为任意有限阶的统一界。
