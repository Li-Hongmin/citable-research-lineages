> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Lehmer 尾门的通用离散对偶证书

日期：2026-08-17。

本 note 给出 \(I_N\) 对任意线性统计的精确评价常数。它把 notes 346--347
中的总和评价推广为局部、加权的对偶接口。

## 1. 三角因子化与一般线性泛函

在指标 \(2,\ldots,N\) 上令
\[
K_N=R_N^TR_N,\qquad
(R_N)_{k,n}=\frac{\sqrt{2k+1}}{n}\mathbf 1_{k<n},
\quad
1\le k<N.
\]
对任意实向量 \(\ell=(\ell_2,\ldots,\ell_N)\)，定义
\[
s_1:=0,\qquad s_n:=n\ell_n\quad(2\le n\le N).
\]
解 \(R_N^Ty=\ell\) 时，
\[
\sqrt{2k+1}\,y_k=s_{k+1}-s_k\qquad(1\le k<N).
\]
因此有精确恒等式
\[
\boxed{
\ell^TK_N^{-1}\ell
=\sum_{k=1}^{N-1}\frac{(s_{k+1}-s_k)^2}{2k+1}.}
\tag{1}
\]
对 \(x=(\mu(2),\ldots,\mu(N))^T\)，有限维 Cauchy--Schwarz 给出
\[
\boxed{
\left|\sum_{n=2}^N\ell_n\mu(n)\right|^2
\le \frac{I_N}{\pi}
\sum_{k=1}^{N-1}\frac{(s_{k+1}-s_k)^2}{2k+1}.}
\tag{2}
\]
这是纯有限维恒等式，不使用 RH 或任何渐近估计。

## 2. 三个直接特例

### 总和

取 \(\ell_n=1\)，则 \(s_1=0\)、\(s_2=2\)、\(s_n=n\)（\(n\ge2\)），
从而恢复
\[
\ell^TK_N^{-1}\ell
=\frac43+\sum_{k=2}^{N-1}\frac1{2k+1}.
\]

### 调和和

取 \(\ell_n=1/n\)，则 \(s_n=1\)（\(n\ge2\)），故
\[
\boxed{
\left|\sum_{n=2}^N\frac{\mu(n)}n\right|^2
\le\frac{I_N}{3\pi}.}
\tag{3}
\]

### 局部调和尾

给定 \(1\le K<N\)，取
\[
\ell_n=\frac1n\mathbf 1_{K<n\le N}.
\]
此时 \(s_n\) 只在 \(k=K\) 处发生一次单位跳跃，故
\[
\boxed{
\left|\sum_{K<n\le N}\frac{\mu(n)}n\right|^2
\le\frac{I_N}{\pi(2K+1)}.}
\tag{4}
\]
特别地，当 \(K\asymp N\) 时，\(I_N\) 控制的是局部调和尾的
\(N^{-1}\)-加权平方，而不是未加权短区间和。

## 3. 总和正是跨尺度尾的叠加

令
\[
A_k(N):=\sum_{k<n\le N}\frac{\mu(n)}n.
\]
逐项交换有限和得到
\[
\boxed{
M(N)-1=2A_1(N)+\sum_{k=2}^{N-1}A_k(N).}
\tag{5}
\]
因此总和的对偶系数在 \(A_k\) 坐标中是
\(c_1=2\)、\(c_k=1\ (k\ge2)\)，而其加权平方代价正是
\[
\frac{c_1^2}{3}+\sum_{k=2}^{N-1}\frac{c_k^2}{2k+1}
=\frac43+\sum_{k=2}^{N-1}\frac1{2k+1}.
\]
这解释了 note 347 中不可避免的 \(\asymp\log N\) 评价常数：它来自所有
尺度尾的线性汇总，而不是三角因子化的松弛。

## 4. 对下一步算术输入的限制

式 (1) 说明，对偶代价只取决于序列 \(s_n=n\ell_n\) 的加权离散变差。
总和 \(\ell_n=1\) 的代价是 \(\asymp\log N\)，这是 note 347 的
对数评价常数；调和尾通过把 \(s_n\) 变成阶跃，代价降为单个边界权
\((2K+1)^{-1}\)。

然而，(4) 本身仍不能给出 RH 所需的
\(\sum_{n\le N}\mu(n)=O(N^{1/2+\varepsilon})\)：从调和尾恢复未加权和
必须重新支付 \(n\) 的增长，并重新处理不同尺度之间的 signed 相关。
因此，当前最小的新算术命题可以明确写成：在保持这些阶跃对偶证书的同时，
控制跨 \(K\) 的 Möbius 调和尾相关，达到足以重建未加权 \(M(N)\) 的
\(N^{1/2+\varepsilon}\) 级别。单个局部正能量估计不能替代这一跨尺度接口。
