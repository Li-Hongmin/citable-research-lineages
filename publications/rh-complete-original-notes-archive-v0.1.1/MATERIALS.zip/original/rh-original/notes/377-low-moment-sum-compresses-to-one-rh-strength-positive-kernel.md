> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 低矩总和压缩为单个正核的 RH-strength 门

## 几何级数恒等式

对
\[
\phi_j(u)=u^j(1-u)\mathbf 1_{(0,1)}(u)
\]
有有限几何级数恒等式
\[
\sum_{j=0}^{J-1}\phi_j(u)=1-u^J
\qquad(0\le u\le1).
\tag{1}
\]
令 \(x=z^2\)，并用 note 373 的 cutoff 二次型 \(T_j(z^2)\)。逐项交换有限和得到
\[
\sum_{j=0}^{J-1}T_j(z^2)
=\sum_{a,b\le z}\mu(a)\mu(b)
 \left[1-\left(\frac{ab}{z^2}\right)^J\right].
\tag{2}
\]
右端完全因子化为
\[
\boxed{
\sum_{j=0}^{J-1}T_j(z^2)
=M(z)^2-\frac{A_J(z)^2}{z^{2J}}
=B_0(z)-B_J(z).}
\tag{3}
\]
这与逐层望远镜相同，但 (1) 说明全部低矩已压缩成一个非负核
\[
\psi_J(u)=1-u^J\ge0.
\]

## 与平方根门的等价性

由无条件包络
\[
0\le B_J(z)\le \frac{4z^2}{(J+1)^2},
\tag{4}
\]
若存在 \(J\asymp z\) 使
\[
\sum_{j=0}^{J-1}T_j(z^2)
\ll_\varepsilon z^{1+\varepsilon},
\tag{5}
\]
则 (3)--(4) 立即给出
\[
M(z)^2\ll_\varepsilon z^{1+\varepsilon},
\qquad
M(z)\ll_\varepsilon z^{1/2+\varepsilon}.
\tag{6}
\]
反过来，若 \(M(z)\ll_\varepsilon z^{1/2+\varepsilon}\)，则 (3) 的左端也满足同阶上界。故在 \(J\asymp z\) 时，(5) 与平方根级 Mertens 界只差一个无条件的 \(B_J=O(1)\) 尾项。

## 对低矩路线的结论

这说明低矩的有符号总和不是一个比 RH 弱得多的辅助命题；它本身就是一个 \(\psi_J\) 正核的 RH-strength signed 门。逐项取绝对值导致 note 376 的更强条件
\[
\sum_{j<\sqrt z}|T_j|\ll z^{1+\varepsilon}
\]
，而不取绝对值时已经直接回到 (5)。因此：

1. 增加 \(\phi_j\) 的层数只是在不同表示之间重写同一个平方根门；
2. periodization 的逐点非负性不能自动给出 (5)；
3. 若要推进 RH，必须控制 \(\psi_J\) 二次型的 Möbius signed cancellation，或构造能把它与 incomplete-lcm boundary 联立的非局部 intertwiner。

本 note 只给出精确压缩与等价性，不宣称 (5) 已被证明。

