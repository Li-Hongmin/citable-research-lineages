> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact Krein factorization of the reciprocal boundary form

## 正 Gram 与 fundamental symmetry

在 note 184 的 Fourier 模型中，令 \(h(\xi)\) 为偶实 boundary symbol，并设

\[
A=M_{|h|}^{1/2},\qquad
\Sigma=M_{\operatorname{sgn}h},\qquad
J_d f(\xi)=e^{i\xi d}f(-\xi).
\]

则 \(A\)、\(\Sigma\) 与 \(J_d\) 两两交换（除 \(J_d\) 的相位反射外，前两者
都是偶乘法算子），并且

\[
M_h=A\Sigma A.
\]

令 \(L_X=AT_X\)。原 ordinary 与 reciprocal 压缩严格分解为

\[
G_X=L_X^*L_X\succeq0,
\]

\[
\boxed{
H_X=T_X^*M_hJ_dT_X
=L_X^*(\Sigma J_d)L_X.
}
\]

这里 \(\Sigma J_d\) 是一个 self-adjoint unitary involution；因此 \(H_X\) 是
一个精确的 Krein Gram，而不是普通 PSD Gram。

## 真正的有限维闭性条件

离散 complement 只保证

\[
J_dT_X=T_XR_X.
\]

要把上面的 Krein form 压回同一个有限 divisor basis，还需要额外条件

\[
\boxed{
\Sigma\,\operatorname{Ran}L_X\subseteq\operatorname{Ran}L_X.
}
\]

等价地，必须存在有限矩阵 \(S_X\) 使

\[
\Sigma L_X=L_XS_X.
\]

此时

\[
(\Sigma J_d)L_X=L_XS_XR_X,
\]

所有 sign-channel 都可在有限维中闭合。若 \(S_X\) 还是 self-adjoint
involution，便得到一个真正的 signed finite-block Feshbach 模型。

## 为什么实际 symbol 不满足闭性

对 V15，note 174 已严格给出
\[
h(0)>0,\qquad h(2)<0.
\]

故 \(\Sigma\) 在频率上取至少两种符号。对有限指数空间
\(\operatorname{Ran}L_X\)，乘以 \(\Sigma\) 会把
\(e^{i\xi\log a}\) 变成 \(S(\xi)e^{i\xi\log a}\)；若 \(S\) 有 sign jump
或非平凡区间结构，这个函数不可能仍是有限纯指数的线性组合。因此
\(\Sigma\operatorname{Ran}L_X\subseteq\operatorname{Ran}L_X\) 一般失败。

这说明增长的 sign-channel 并非技术选择，而是 Krein factorization 的必要
闭性扩张。若只保留 \(G_X=L_X^*L_X\)，就会丢掉 \(R_X\)-parity 与 signed
reciprocal cancellation。

## 当前最薄的可证接口

未来若要把 A 线接到实际 Weil 格，最小命题可以明确写成：

\[
\text{构造 }\mathcal L_X\supset L_X
\quad\text{使}\quad
\Sigma\mathcal L_X\subseteq\mathcal L_X,\qquad
J_d\mathcal L_X\subseteq\mathcal L_X,
\]

并在该增长空间上同时保持 \(R_X\)-parity 与可控 Gram 条件。普通 local
positivity 只给 \(L_X^*L_X\succeq0\)，没有给这两个闭性条件。

本 note 是 exact Krein factorization 与最小闭性缺口，不是 RH 证明。

