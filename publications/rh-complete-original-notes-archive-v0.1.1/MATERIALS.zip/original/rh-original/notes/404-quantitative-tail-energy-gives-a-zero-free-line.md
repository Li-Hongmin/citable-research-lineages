> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 尾差分能量指数与 zeta 零点边界的精确对应

本 note 给出 note 402--403 的定量版本。它把有限尺度尾差分的任何幂次能量估计
直接翻译为一个 zeta 零点零自由半平面。

## 定理

沿用 note 402 的记号，令
\[
\mathcal F_P(z)=\sum_{k\ge1}H_P(k)\bigl(k^{-z}-(k-1)^{-z}\bigr),
\qquad
\mathcal F_P(z)=\frac{P(2^{-(z+1)})}{\zeta(z+1)}
\quad(\Re z>0).
\]
设对某个 \(\theta\ge0\)，每个 \(\varepsilon>0\) 都有
\[
E_P(Y):=\sum_{k\le Y}k|H_P(k)|^2
\ll_{P,\varepsilon}Y^{\theta+\varepsilon}.
\tag{1}
\]
若 \(P(2^{-\rho})\ne0\)，则
\[
\zeta(\rho)=0
\quad\Longrightarrow\quad
\Re\rho\le\frac{\theta}{2}.
\tag{2}
\]

## 证明

在 dyadic 块 \(Y<k\le2Y\) 上，令 \(\sigma=\Re z\)。由
\[
|k^{-z}-(k-1)^{-z}|\ll_z k^{-\sigma-1}
\]
及 Cauchy--Schwarz，得到
\[
\begin{aligned}
\sum_{Y<k\le2Y}|H_P(k)|\,|k^{-z}-(k-1)^{-z}|
&\le E_P(2Y)^{1/2}
\left(\sum_{Y<k\le2Y}k^{-2\sigma-3}\right)^{1/2}\\
&\ll_{P,\varepsilon,z}
Y^{\theta/2-\sigma-1+\varepsilon/2}.
\end{aligned}
\tag{3}
\]
当 \(\sigma>\theta/2-1\) 时，取足够小的 \(\varepsilon\)，右侧对 dyadic \(Y\) 可求和，故 \(\mathcal F_P\) 全纯延拓到
\[
\Re z>\frac\theta2-1.
\tag{4}
\]
将 \(z=\rho-1\) 代入 (4)，若 \(P(2^{-\rho})\ne0\)，右端在 \(\zeta(\rho)=0\) 处有极点，矛盾；于是得到 (2)。\(\square\)

## 解释

- \(\theta=1\)（允许任意 \(\varepsilon\)）给出 \(\Re\rho\le1/2\)，即 RH 门。
- 若只能证明 \(E_P(Y)\ll Y^{2-\delta}\)，则只能推出
  \(\Re\rho\le1-\delta/2\)。这是真实的固定幂次零自由区，但还不是 RH。
- 纯粹的 stretched-log 估计
  \(E_P(Y)\ll Y^2\exp[-c(\log Y)^{3/5}(\log\log Y)^{-1/5}]\)
  不对应任何固定 \(\delta>0\)，因此不能由此推出固定幂次的零自由线。

该定理把算术任务的目标精确化：越过 RH 的最后门槛，必须把尾能量指数从接近 \(2\) 降到 \(1+\varepsilon\)，而不是只获得任意对数节省。
