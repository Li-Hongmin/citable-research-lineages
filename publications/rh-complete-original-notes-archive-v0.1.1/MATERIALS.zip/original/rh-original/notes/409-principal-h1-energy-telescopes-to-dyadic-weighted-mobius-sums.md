> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 409. 主部 (H^1) 能量的望远镜恒等式

## 1. 逆 Mellin 核

由 note 408 的有限系数列
\[
a_m^{(Y)}=2\mu(m)\mathbf 1_{m\le Y}
-\mathbf 1_{2\mid m}\mu(m/2)\mathbf 1_{m\le 2Y},
\]
主部为
\[
Q_w(\mu_{\le Y})=\frac1{2\pi}\int_{\mathbb R}
\frac{|A_Y(i\xi)|^2}{1+\xi^2}\,d\xi,
\qquad A_Y(s)=\sum_{m\le2Y}\frac{a_m^{(Y)}}{m^s}.
\tag{1}
\]
因为
\[
\frac1{2\pi}\int_{\mathbb R}\frac{e^{i\xi t}}{1+\xi^2}\,d\xi
=\frac12e^{-|t|},
\]
有精确实空间恒等式
\[
Q_w(\mu_{\le Y})
=\frac12\sum_{m,n\le2Y}a_m^{(Y)}a_n^{(Y)}
\frac{\min(m,n)}{\max(m,n)}.
\tag{2}
\]

## 2. 完全望远镜化

令
\[
S_n^{(Y)}:=\sum_{m\le n}m a_m^{(Y)},
\qquad S_0^{(Y)}=0.
\]
按 (m<n) 与 (m=n) 分开，(2) 的每一项恰好满足
\[
\frac12\sum_{m,n\le2Y}a_ma_n\frac{\min(m,n)}{\max(m,n)}
=\sum_{n=1}^{2Y}\frac{(S_n^{(Y)})^2-(S_{n-1}^{(Y)})^2}{2n^2}.
\tag{3}
\]
分部求和后得到非负表示
\[
Q_w(\mu_{\le Y})
=\frac{(S_{2Y}^{(Y)})^2}{2(2Y)^2}
+\frac12\sum_{n=1}^{2Y-1}(S_n^{(Y)})^2
\left(\frac1{n^2}-\frac1{(n+1)^2}\right).
\tag{4}
\]

这里 (S_{2Y}^{(Y)}=0)：第一部分给出 (2\sum_{m\le Y}m\mu(m))，第二部分在 (m=2k) 上给出 (-2\sum_{k\le Y}k\mu(k))。所以 (4) 没有隐藏的边界常数。

## 3. 与加权 Möbius 和的 dyadic 差

写
\[
M_1(x):=\sum_{m\le x}m\mu(m).
\]
直接由 (a_m^{(Y)}) 的定义得到
\[
S_n^{(Y)}=
\begin{cases}
2\bigl(M_1(n)-M_1(\lfloor n/2\rfloor)\bigr),&1\le n\le Y,\\[2mm]
2\bigl(M_1(Y)-M_1(\lfloor n/2\rfloor)\bigr),&Y<n\le2Y.
\end{cases}
\tag{5}
\]
因此 note 407 的严格 PSD 主部不是一个不可见的抽象谱量，而是加权 Möbius 和在 dyadic 半尺度上的平方能量；其权为
\[
\frac12\left(n^{-2}-(n+1)^{-2}\right).
\]

## 4. 这一步推进了什么

恒等式 (4)--(5) 给出三个严格事实：

1. 主部的正性不依赖数值检验，来自显式平方和；
2. (Y)-端点 (S_{2Y}=0) 是精确抵消，而不是 (O(Y)) 误差；
3. 证明 (Q_w\ll Y^{1+\varepsilon}) 等价于控制 (M_1) 的全尺度 dyadic 差能量，而不是普通固定 shift 的 Möbius 相关。

在 RH 下，标准 Perron/Abel 估计 (M_1(x)\ll_\varepsilon x^{3/2+\varepsilon}) 代入 (4) 即给出 (Q_w\ll_\varepsilon Y^{1+\varepsilon})。反向方向仍是 note 402--405 的 RH-equivalent 门；(4) 本身没有提供新的无条件平方根估计。

对 (Y\le50) 的所有系数，(2) 与 (3)--(4) 用有理数逐项核对一致；该有限检查只验证恒等式，不外推到 RH。
