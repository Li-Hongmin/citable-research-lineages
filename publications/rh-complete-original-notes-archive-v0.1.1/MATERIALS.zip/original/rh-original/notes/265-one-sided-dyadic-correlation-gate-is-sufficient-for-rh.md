> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 单侧 dyadic 相关上界已经足以推出 RH

日期：2026-08-16。

note 222 使用了
\(|D_H(X)|\ll X^{1+\varepsilon}\) 的 signless dyadic gate。实际上，
绝对值并不是必要的；只控制每个 dyadic 块的上侧即可。这给出一个
更弱、但仍足以承载 RH 的精确算术命题。

## 1. 恒等式

令 \(f\) 取 \(\lambda\) 或 \(\mu\)，并记
\[
S_f(X):=\sum_{n\le X}f(n).
\]
并对 \(H=1,2,4,\ldots\le X\) 定义
\[
D_{H,f}(X):=
\sum_{H\le h<\min(2H,X)}
\sum_{n\le X-h}f(n)f(n+h).
\tag{1}
\]
展开平方并按正移位分组，得到
\[
S_f(X)^2=\sum_{n\le X}f(n)^2
 +2\sum_{H\ {\rm dyadic}}D_{H,f}(X).
\tag{2}
\]
对 \(f=\lambda\)，对角线为 \(X\)；对 \(f=\mu\)，
\(\sum_{n\le X}\mu(n)^2\le X\)。

## 2. 严格充分条件

假设对每个 \(\varepsilon>0\)，存在 \(C_\varepsilon\) 使所有
\(X\ge2\) 和所有 dyadic \(H\le X\) 满足
\[
D_{H,f}(X)\le C_\varepsilon X^{1+\varepsilon}.
\tag{3}
\]
注意 (3) 是单侧上界，不要求控制负的 \(D_{H,f}\)。
由 dyadic 块数 \(O(\log X)\)，(2) 给出
\[
S_f(X)^2
\le X+2C_\varepsilon X^{1+\varepsilon}(1+\log_2X)
\ll_{\varepsilon}X^{1+2\varepsilon}.
\]
于是
\[
S_f(X)\ll_\varepsilon X^{1/2+\varepsilon}.
\tag{4}
\]
对 \(f=\lambda\) 或 \(f=\mu\)，相应 Dirichlet 级数在
\(\Re s>\frac12\) 的延拓都排除 \(\zeta\) 的非临界零点，因此均推出 RH。

## 3. 与现有平均结果的关系

现有 averaged-Chowla 结果通常控制
\[
\sum_{H\le h<2H}|C_h(X)|
\]
或其额外平均，而 (3) 只需要
\(\sum_h C_{h,f}(X)\) 的上侧。形式上这确实弱于逐块绝对值界；
但当前文献结果仍没有给出固定 \(X\)、增长移位区间
\(H\asymp X\) 的统一单侧 \(O(X^{1+\varepsilon})\) 上界。

正相关块可能集中在某些 dyadic \(H\)，负相关块不能被用来抵消
(3) 的右侧上界；因此单侧化减少了目标强度，却没有自动把现有
平均定理变成所需估计。

## 4. 一个等价的“正部”表述

若只知道
\[
\sum_H D_{H,f}^+(X)\ll_\varepsilon X^{1+\varepsilon},
\qquad D_{H,f}^+:=\max(D_{H,f},0),
\tag{5}
\]
则 (2) 同样推出 (4)，因为负块可以删除：
\[
S_f(X)^2\le X+2\sum_H D_{H,f}^+(X).
\]
故一个更聚焦的新目标是控制 dyadic 相关的正部总量，而不是所有
移位的绝对相关。

这可能适合寻找保留跨移位符号的谱方法；但在没有新的 signed
intertwiner 之前，(5) 仍是未证的 RH-strength 算术门。
