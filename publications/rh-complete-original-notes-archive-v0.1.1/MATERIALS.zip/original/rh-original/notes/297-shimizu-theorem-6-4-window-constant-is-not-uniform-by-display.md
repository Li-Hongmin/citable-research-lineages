> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Shimizu v8：Theorem 6.4 的窗口常数尚未显示为一致有界

日期：2026-08-16。

## 稿件中实际给出的估计

Theorem 6.4 对每个有限窗口 \(M\) 使用有限通道集合 \(A_M\)。对每个通道，
稿件先写出形如
\[
q_\nu(r_{\alpha,M}z)\le C_{\alpha,\nu,M}\,\|z\|,
\qquad \alpha\in A_M,
\]
的连续性估计，再对 \(\alpha\in A_M\) 求和，得到
\[
\|\Lambda_T^{(M)}z\|
\le C_{\mathrm{LCI},M}\,\|T\|_{R,\mathrm{LCI}}\,\|z\|.
\tag{1}
\]
这里 \(C_{\mathrm{LCI},M}\) 明确带有窗口指标。随后文字说明通过对“所选窗口系统需要的有限个 seminorm 类型”取上确界，可得到全局 LCI 映射；但显示证明没有给出
\[
\sup_M C_{\mathrm{LCI},M}<\infty
\tag{2}
\]
或更弱的多项式界
\[
C_{\mathrm{LCI},M}\ll M^{A_0}.
\tag{3}
\]
这不是记号问题，因为 Lemma 6.118 正是用某个 \(A>A_0\) 的 weighted seminorm 来吸收窗口增长。

## “每个窗口有限”不推出一致界

有限通道数只说明 \(A_M\) 对每个固定 \(M\) 有限，不控制其随 \(M\) 的增长。例如
\[
A_M=\{1,\dots,M\},\qquad C_{\alpha,\nu,M}=1
\]
时，逐通道估计的求和常数至少为 \(M\)；若
\(C_{\alpha,\nu,M}=e^M\)，则增长甚至不是多项式。这个模型不是对 Shimizu
算子的反例，只说明“有限窗口求和”本身不能替代 (2) 或 (3)。

## 与后续桥接步骤的关系

要使 Lemma 6.116、6.118、6.119 和 Theorem 6.152/6.155 的链条可审计，
至少需要补出一个与窗口细化相容的统一命题，例如：

1. 对所有 \(M\)，通道总数、seam 变换、Gram 逆或 Moore--Penrose lift 的
   条件数共同满足 \(C_{\mathrm{LCI},M}\ll M^{A_0}\)；
2. 该界在窗口嵌套 \(M\mapsto M'\) 下保持，并且与
   Definition 6.117 的 weighted readout/lift/cyclic seminorm 相容；
3. 由此明确证明 Theorem 6.155 Step 2 所需的 pairing 连续性可以取
   \(M\)-一致常数。

Lemma 6.116 中 Moore--Penrose 范数等于 quotient norm 只是定义性等式，
不能单独给出 (2) 或 (3)；有限维性也不能排除 Gram 最小特征值随 \(M\)
超多项式衰减。

## 裁决

这不是对 Theorem 6.4 或 Theorem 6.155 的反例，也不足以判定预印本错误。
它把桥接中尚未显示的量化义务具体化为：
\[
\text{窗口通道/Gram/lift 的统一或多项式增长估计}.
\]

在该估计补齐之前，不能把“有限窗口恒等式”无条件传到 \(M\to\infty\)，
也不能把 det2 自伴性链吸收为 \(F_K=\xi\) 或 RH 的证明。Shimizu v8
截至目前仍是未同行评审的预印本；本记录只保留其可核验结构与缺失的
uniform-window 门，不宣称其结论为假。
