> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有限 Mellin 预条件即使消去零频有限阶，仍保留 RH 门

日期：2026-08-16。

本 note 处理一种常见的绕行设想：先乘一个有限 Dirichlet 多项式
\[
A(t)=\sum_{k\le L}a_k k^{it}
\]
来消去 \(t=0\) 的 Möbius 低频通道，再试图从正能量界得到一个弱于 RH 的
算术命题。结论是：只要 \(A\not\equiv0\)，它在 \(t=0\) 只有有限阶零点，
统一的 \(N^{1+\varepsilon}\) 正能量界仍然给出平方根级 Mertens 界；预条件只
改变对数因子。

## 引理

设 \(a_n\in\mathbb R\)，
\[
M(x)=\sum_{n\le x}a_n,\qquad
F_X(t)=\sum_{n\le X}a_n n^{it}.
\]
设 \(w\) 在 \([-\delta_0,\delta_0]\) 上连续并满足
\(w(t)\ge c_0>0\)。令 \(A\) 为非零有限 Dirichlet 多项式。若 \(q\) 是
其在 \(t=0\) 的零点阶数，即
\[
A(t)=\alpha_q t^q+O(t^{q+1}),qquad \alpha_q\ne0,
\]
则存在 \(c_A>0,\delta_A>0\) 使
\[
w(t)|A(t)|^2\ge c_A|t|^{2q}
\qquad (|t|\le\delta_A).
\tag{1}
\]

若对所有整数 \(X\ge2\) 和每个 \(\eta>0\) 有
\[
E_X(A):=\int_{\mathbb R}w(t)|A(t)|^2|F_X(t)|^2\,dt
\ll_{\eta,A,w}X^{1+\eta},
\tag{2}
\]
则
\[
\max_{x\le X}|M(x)|\ll_{\eta,A,w}X^{1/2+\eta}.
\tag{3}
\]

## 证明

记 \(M^*(X)=\max_{x\le X}|M(x)|\)，取 \(X_0\le X\) 达到最大值。Abel
部分求和给出
\[
F_{X_0}(t)=M(X_0)X_0^{it}
-it\int_1^{X_0}M(u)u^{it-1}\,du.
\]
因此当 \(|t|\le(16\log X_0)^{-1}\) 时，和 note 246 同样有
\[
|F_{X_0}(t)|\ge\frac34M^*(X).
\tag{4}
\]
对充分大的 \(X_0\)，该小区间包含在 (1) 的邻域内，于是
\[
\begin{aligned}
E_{X_0}(A)
&\ge \frac9{16}M^*(X)^2
 c_A\int_{-|t_0|}^{|t_0|}|t|^{2q}\,dt\\
&\gg_{A,w,q}M^*(X)^2(\log X_0)^{-(2q+1)},
\end{aligned}
\tag{5}
\]
其中 \(t_0=(16\log X_0)^{-1}\)。结合 (2) 得
\[
M^*(X)^2\ll X^{1+\eta}(\log X)^{2q+1}.
\tag{6}
\]
吸收任意固定的对数幂到 \(X^{\eta}\) 中，即得 (3)。有限多个小 \(X_0\)
并入常数。

## 对预条件路线的含义

有限 Dirichlet 多项式 \(A(t)\) 是整函数；若它在 \(t=0\) 的所有阶都为零，
则 \(A\equiv0\)。所以任何非平凡有限预条件都只产生有限 \(q\)，不能真正
移除最大点 Abel 引理看到的零频通道。

特别地，对 \(a_n=\mu(n)\)，若有人证明
\[
\int w(t)|A(t)|^2\left|\sum_{n\le X}\mu(n)n^{it}\right|^2dt
\ll_{\varepsilon}X^{1+\varepsilon}
\quad\text{对所有 }X,
\]
那么仍立即得到 \(M(X)\ll_\varepsilon X^{1/2+\varepsilon}\)，进而得到 RH。
因此有限 zeta/Dirichlet 预条件不能把问题降为弱于 RH 的正能量命题；它至多
把低频局部积分中的常数换成一个对数幂。要真正绕开此结论，必须使用随尺度
增长的非解析滤波器、允许符号的跨频率 intertwiner，或直接证明新的 Möbius
相关估计；三者都不是一般正 Gram 方法的免费后果。
