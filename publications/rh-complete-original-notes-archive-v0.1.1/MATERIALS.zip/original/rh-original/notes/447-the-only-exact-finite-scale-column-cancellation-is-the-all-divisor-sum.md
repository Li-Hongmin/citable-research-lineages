> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有限尺度上唯一的精确列消去是全除数和

日期：2026-08-17。

本 note 把 note 445 的跨尺度调和尾矩阵再推进一步：在每个固定截断 \(N\) 上，\(T_N\) 存在一个显式的、且唯一（差一个标量）的精确列消去关系。它不是平方根估计，但严格说明了最简单的尺度依赖消去必须支付增长的系数代价。

## 1. 行和恒等式

沿用 note 445 的记号

\[
(T_N)_{k,d}=\frac{\sqrt{2k+1}}{d}
\sum_{j=\lfloor k/d\rfloor+1}^{\lfloor N/d\rfloor}\frac{\mu(j)}j,
\qquad 1\le k<N,\ 1\le d\le N.
\]

把 \(d\) 求和并令 \(n=dj\)，得到

\[
\begin{aligned}
\frac1{\sqrt{2k+1}}\sum_{d=1}^{N}(T_N)_{k,d}
&=\sum_{d=1}^{N}\frac1d
\sum_{\lfloor k/d\rfloor<j\le\lfloor N/d\rfloor}\frac{\mu(j)}j\\
&=\sum_{k<n\le N}\frac1n\sum_{d\mid n}\mu(n/d).
\end{aligned}
\]

这里 \(k\ge1\)，所以每个出现的 \(n\) 都满足 \(n>1\)。由 Möbius 反演

\[
\sum_{d\mid n}\mu(n/d)=0\qquad(n>1),
\]

遂有逐行精确恒等式

\[
\boxed{T_N\mathbf 1_N=0.}
\tag{1}
\]

这不是渐近抵消，也不依赖 RH；它只是除数 incidence 与 Möbius 逆在有限截断上的唯一全尺度闭合。

## 2. 唯一性与第一列的精确表示

矩阵 \(R_N\) 有 \(N-1\) 个线性无关的行，因而秩为 \(N-1\)。\(D_N^{-1}\) 可逆，所以

\[
\operatorname{rank}T_N=N-1.
\]

结合 (1)，\(T_N\) 的右零空间恰为

\[
\ker T_N=\operatorname{span}\{\mathbf1_N\}.
\tag{2}
\]

因此第一列与其余列之间有唯一的全尺度精确关系

\[
\boxed{
T_Ne_1=-\sum_{d=2}^{N}T_Ne_d.
}
\tag{3}
\]

更一般地，若系数 \(c=(c_1,\ldots,c_N)^{\mathsf T}\) 满足

\[
T_Ne_1=\sum_{d=2}^{N}c_dT_Ne_d,
\]

则 \(c_1=1\)、且 \(c_d=-1\)（\(d\ge2\)）；因为两边相减得到的系数向量属于 (2)。换言之，有限尺度上不可能存在另一组不同的精确列消去系数。

## 3. 系数增长是不可忽略的成本

关系 (3) 的非首列系数向量为

\[
(-1,\ldots,-1)\in\mathbb R^{N-1},
\qquad \|(-1,\ldots,-1)\|_2=\sqrt{N-1}.
\tag{4}
\]

所以最直接的精确尺度消去不是有界系数的局部操作，而是把第一列摊到全部 \(N-1\) 个除数尺度上。若某个 proposed bridge 要求系数在 \(\ell^2\) 或 \(\ell^1\) 中统一有界，(2)--(4) 已经排除了其精确有限截断版本。

这个结论与 note 446 互补：固定于所有 \(N\) 的卷积系数只产生平凡 \(d=1\) 组合；允许系数随 \(N\) 变化后，有限截断唯一的精确非平凡关系就是 (3)，并且其支持和系数范数都增长。

## 4. 尚未关闭的边界

上述唯一性只排除精确的有限尺度列消去，不排除以下更强、也更困难的路线：

* 允许小余项的近似消去；
* 只在特定边界区间或特定 \(k/d\) 层上消去；
* 使用非卷积的 signed kernel；
* 同时利用非对角列相关与边界标量，而不是逐列的线性表示。

若要达到 \(\|\rho_N\|_2^2\ll_\varepsilon N^{1+\varepsilon}\)，仍需控制 note 445 中的全尺度调和尾相关；(1) 本身不提供这种估计。因此本 note 给出的是一个精确结构性边界，不是 RH 证明，也不把全除数恒等式误认为平方根级算术桥。
