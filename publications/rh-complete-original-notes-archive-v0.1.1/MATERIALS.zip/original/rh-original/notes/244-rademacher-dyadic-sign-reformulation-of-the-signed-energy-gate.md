> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Signed dyadic 能量门的 Rademacher 重写

本 note 把 note 243 的 signed dyadic \(L^2\) 条件改写成一个精确的
Rademacher 平均二次型。它没有证明该条件，但把算术缺口变成可与
Littlewood--Paley/decoupling 工具比较的形式。

## 1. 记号与精确恒等式

令

\[
 K(u)=\int_{\mathbb R}w(t)e^{itu}\,dt,\qquad
 w(t)=\frac{|h(t)|}{2\pi},
\]

并对 \(H\in\mathcal D_N=\{2^j:2^j<N\}\) 定义

\[
 B_H(N)=
 \sum_{\substack{H\le h<2H\\h<N}}
 \sum_{m\le N-h}\mu(m)\mu(m+h)
 K\!\left(\log\frac m{m+h}\right).
\tag{1}
\]

若 \((\varepsilon_H)_{H\in\mathcal D_N}\) 是独立 Rademacher 符号，
\(\mathbb P(\varepsilon_H=\pm1)=1/2\)，则有限性给出精确恒等式

\[
\boxed{
\mathbb E_\varepsilon\left|
 \sum_{H\in\mathcal D_N}\varepsilon_H B_H(N)
\right|^2
=\sum_{H\in\mathcal D_N}|B_H(N)|^2 .
}
\tag{2}
\]

因此 note 243 的 signed block 门

\[
\sum_{H\in\mathcal D_N}|B_H(N)|^2
\ll_\varepsilon N^{2+\varepsilon}
\tag{3}
\]

等价于随机 dyadic 符号二次型的 \(L^2(\varepsilon)\) 界

\[
\mathbb E_\varepsilon\left|
 \frac12\sum_{\substack{m,n\le N\\m\ne n}}
 \mu(m)\mu(n)
 K\!\left(\log\frac mn\right)
 \varepsilon_{\mathsf d(|m-n|)}
\right|^2
\ll_\varepsilon N^{2+\varepsilon},
\tag{4}
\]

其中 \(\mathsf d(r)=2^{\lfloor\log_2 r\rfloor}\) 是 \(r\) 所属的 dyadic
尺度。式 (4) 的对角线应单独取出；它只贡献
\(K(0)\sum_{n\le N}\mu(n)^2=O(N)\)。

## 2. 与正能量门的关系

由于

\[
 E_N(w)
=K(0)\sum_{n\le N}\mu(n)^2
 +2\sum_{H\in\mathcal D_N}B_H(N),
\tag{5}
\]

由 (3) 和 Cauchy--Schwarz 立即得到

\[
 E_N(w)\ll_\varepsilon N^{1+\varepsilon};
\tag{6}
\]

再结合 notes 212--213 的 canonical zero-free outer multiplier，便推出 RH。
故 (4) 是一条严格的 RH 充分门，但不应误称为已知定理。

## 3. 这条重写保留了什么

逐移位取绝对值会把 (1) 替换成
\(\sum_h |B_h|\)，从而丢掉同一 dyadic 块内部以及不同 \(m\) 之间的相消。
Rademacher 重写只对 dyadic 块加符号，保留每个块内部的全部算术结构；
它不是把正能量改成另一个 kernel，而是对同一个有限和作二阶矩重排。

但是，(4) 仍不是普通 PSD 谱范数估计：对一般向量，低频正 Gram 的算子范数
可达 \(N\) 量级（见 note 207）。因此要证明 (4)，必须利用 \(\mu\) 的
signed arithmetic cancellation；随机符号平均本身不会制造该 cancellation。

## 4. 最小后续输入

一个比 (4) 更强、但形式上适合双线性方法的充分条件是：对任意固定的
dyadic 符号组 \(\varepsilon_H\)，有

\[
\left|
 \frac12\sum_{\substack{m,n\le N\\m\ne n}}
 \mu(m)\mu(n)K\!\left(\log\frac mn\right)
 \varepsilon_{\mathsf d(|m-n|)}
\right|
\ll_\varepsilon N^{1+\varepsilon}.
\tag{7}
\]

由 (7) 平均 \(\varepsilon\) 即得 (4)。但 (7) 是 uniform signed
dyadic-multiplier 估计，仍是新的 RH-strength 算术命题；现有逐移位 Chowla
或先取绝对值的 averaged-Chowla 结果不能直接给出它。

结论：Rademacher 形式把 note 243 的缺口明确连接到“随机 dyadic
multiplier 下的 Möbius 双线性估计”，但尚未提供这一步的无条件证明。

## 5. 平方后的四点代价

把 (3) 展开，得到精确的四点相关：

\[
\begin{aligned}
 \sum_H |B_H(N)|^2
 ={}&\sum_H
 \sum_{\substack{H\le h,k<2H\\h,k<N}}
 \sum_{m\le N-h}\sum_{n\le N-k}
 \mu(m)\mu(m+h)\mu(n)\mu(n+k)\\
 &\qquad\qquad\times
 K\!\left(\log\frac m{m+h}\right)
 K\!\left(\log\frac n{n+k}\right).
\end{aligned}
\tag{10}
\]

所以 Rademacher 门虽然保留了 \(h\)-块内的符号，但其直接证明会要求
控制一个带 dyadic 条件 \(\mathsf d(h)=\mathsf d(k)\) 的四点 Möbius
相关。取绝对值会回到 \(N^2\) 量级；只使用已知的二点 Chowla 型估计也
不能直接处理 \(m,m+h,n,n+k\) 的耦合。

因此，(3) 的真正可攻版本若要避免升到四点，应该直接证明任意 dyadic
符号组的二次型界 (7)，或找到一个不平方 block 和的 bilinear
intertwiner。Rademacher 形式是精确重写和诊断工具，而不是已完成的
RH 证明路线。

## 6. 一般加法能量不能替代 Möbius 算术

即使把 dyadic 块细化到单个移位，也不能只靠 Fourier 正性闭合。对任意
\(\lvert a_n\rvert,\lvert b_n\rvert\le1\)，令
\[
 C_h(a,b)=\sum_m a_m b_{m+h}.
\]
Parseval 给出
\[
 \sum_h |C_h(a,b)|^2
 =\int_0^1\left|\sum_m a_m e(m\theta)\right|^2
             \left|\sum_n b_n e(-n\theta)\right|^2\,d\theta .
\]
对全一序列，右端为区间的加法能量 \(\asymp N^3\)，所以一般的
\(\ell^2\) 加法能量估计远不能给出 \(N^{2+\varepsilon}\)。在 Möbius
情形把它压到 \(N^{2+\varepsilon}\) 已经是带符号四点相关的额外算术
输入；再把单个移位合并成 dyadic block 还会引入
\[
 \left|\sum_{h\in[H,2H)}C_h\right|^2
 \le H\sum_{h\in[H,2H)}|C_h|^2,
\]
其宏观 \(H\) 因子正是低频 block 缺口。故普通 Parseval、PSD 或一般
加法能量不能替代 (7) 中的 Möbius-specific signed cancellation。
