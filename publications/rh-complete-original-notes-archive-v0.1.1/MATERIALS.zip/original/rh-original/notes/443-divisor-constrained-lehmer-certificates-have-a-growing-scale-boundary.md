> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 除数约束 Lehmer 证书的增长尺度边界

日期：2026-08-17。

本 note 把除数恒等式 \(D_N\mu_N=e_1\) 加入 Lehmer 尾能量，得到一个
精确的带边界标量的对偶族。它严格说明：只使用有限深度的除数修正，不能
消除对数代价；有效的 arithmetic intertwiner 必须覆盖随 \(N\) 增长的尺度。

## 1. 除数修正的精确恒等式

令 \(D_N=(\mathbf 1_{d\mid n})_{1\le n,d\le N}\) 为除数 incidence 矩阵，
\(\mu_N=(\mu(1),\ldots,\mu(N))^T\)，则
\[
D_N\mu_N=e_1.
\tag{1}
\]
令
\[
\ell=(0,1,\ldots,1)^T,\qquad
b=(0,b_2,\ldots,b_N)^T,
\]
并定义
\[
r:=\ell-D_N^Tb.
\]
由 (1) 立即得到
\[
\boxed{
M(N)-1
=-\sum_{n=2}^N b_n+\sum_{d=2}^N r_d\,\mu(d),
\qquad
r_d=1-\sum_{\substack{n\le N\\d\mid n}}b_n.}
\tag{2}
\]
这是有限维恒等式，不使用 RH。它把除数修正的代价分成一个显式边界标量
\(-\sum b_n\) 和一个仍可由 Lehmer 正能量控制的剩余线性泛函。

## 2. 精确对偶证书

在指标 \(2,\ldots,N\) 上沿用
\[
K_N=R_N^TR_N,\qquad
\ell_r=(r_2,\ldots,r_N)^T.
\]
令 \(s_1=0\)、\(s_d=d\,r_d\)（\(2\le d\le N\)）。由
\(K_N^{-1}\) 的三角差分公式，
\[
\mathcal C_N(b):=\ell_r^TK_N^{-1}\ell_r
=\sum_{k=1}^{N-1}\frac{(s_{k+1}-s_k)^2}{2k+1}.
\tag{3}
\]
因此
\[
\boxed{
\left|M(N)-1+\sum_{n=2}^Nb_n\right|^2
\le \frac{I_N}{\pi}\,\mathcal C_N(b).}
\tag{4}
\]
取 \(b=0\) 恢复 note 347 的原始对数常数；非零 \(b\) 只能在支付边界标量的
同时改变剩余对偶能量。

## 3. 有限深度修正的严格下界

设 \(b_n=0\) 对所有 \(n>B\)，其中 \(2\le B<N-1\)。则对每个
\(d>B\)，没有非零倍数 \(n\le B\) 满足 \(d\mid n\)，故 \(r_d=1\)。
于是对每个 \(k\ge B+1\)，有
\[
s_{k+1}-s_k=(k+1)-k=1.
\]
代回 (3) 得到严格下界
\[
\boxed{
\mathcal C_N(b)\ge
\sum_{k=B+1}^{N-1}\frac1{2k+1}
=\frac12\log\frac NB+O\!\left(\frac1B\right).}
\tag{5}
\]
所以任意固定 \(B\) 或 \(B=N^{o(1)}\) 的除数修正，仍保留
\(\asymp\log N\) 的对偶代价。若要把 (4) 的剩余代价降到有界，修正的
除数支撑必须延伸到 \(N^{1-o(1)}\) 甚至全尺度。

## 4. 对 RH 路线的含义

式 (2)--(5) 把“加入除数恒等式”这一候选路线的最小接口固定为：

1. 选择增长支撑的 \(b^{(N)}\)，使显式边界
   \(\sum b_n\) 可独立控制；
2. 同时控制 (3) 中跨全部尺度的差分能量；
3. 保留 \(D_N\) 与 Lehmer 核的非对角 signed 结构。

有限深度的 periodization、固定数量的 Feshbach 原子或局部除数补偿都不能
完成第 2 步。若某个全尺度构造最终给出
\(I_N\ll_\varepsilon N^{1+\varepsilon}\)，则按 notes 438--440 精确达到 RH
门；本 note 只证明增长尺度是必要条件，不宣称已经构造该 intertwiner。

## 5. 精确消去尾部只是边界转移

若某个全尺度 \(b\) 使得 \(r_d=0\) 对所有 \(2\le d\le N\)，则
\(r\) 只剩第一个坐标。另一方面，由 (1)--(2)，
\[
r^T\mu_N=\ell^T\mu_N=M(N)-1.
\]
因此
\[
\boxed{r_1=M(N)-1=-\sum_{n=2}^N b_n.}
\tag{6}
\]
换言之，精确的全尺度除数消去并没有估计 \(M(N)\)，而是把同一个未知量
搬进了显式边界标量。若只要求 \(r_d\) 很小，则 (4) 仍要求同时控制
\(-\sum b_n\) 与 \(r^TK_N^{-1}r\)；在边界标量达到
\(N^{1/2+\varepsilon}\) 的地方，已经重新输入了 RH-strength 的 Mertens
估计。真正的桥必须产生新的 signed cancellation，而不是单纯增加除数支撑。
