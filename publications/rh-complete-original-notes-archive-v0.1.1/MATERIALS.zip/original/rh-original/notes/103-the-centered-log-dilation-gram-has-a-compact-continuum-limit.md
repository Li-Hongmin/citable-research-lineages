> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 中心化对数 dilation Gram 的连续极限是紧算子

日期：2026-08-14。

依赖：
[note 097](097-continuous-log-dilation-removes-the-endpoint-without-losing-the-detector.md)、
[note 100](100-log-dilation-gives-paired-additive-differences-but-not-a-divisor-gram.md)。

证据等级：差分商的连续缩放极限与 Hilbert--Schmidt 紧性。
本文确定 note 100 中间正 Gram 的首个连续符号，并严格排除
从该符号得到统一 raw \(L^2\) coercivity 的可能性。

## 1. 离散中心化 Gram

固定 \(R>1\)，并简记 \(G=G_R\)。由 note 097，

\[
G\in W^{1,\infty}_c(0,\infty),
\tag{1}
\]

且 \(G'\) 是分段光滑的有界变差函数。对 \(Y<N\le2Y\)，置

\[
B_{N,d}:=G(d/N)-G((d+1)/N),
\tag{2}
\]

\[
K_Y(d,e):=\sum_{Y<N\le2Y}B_{N,d}B_{N,e}.
\tag{3}
\]

\(K_Y=B^*B\) 正是 note 100 的双 Abel 差分之间的中间核。

## 2. 连续缩放极限

取正数 \(u,v\)，并令整数序列满足

\[
\frac{d_Y}{Y}\to u,
\qquad
\frac{e_Y}{Y}\to v.
\tag{4}
\]

当 \(N/Y\to x\in[1,2]\) 时，Sobolev 差分商收敛给出

\[
YB_{N,d_Y}longrightarrow
-\frac1xG'(u/x)
\tag{5}
\]

对几乎处处的 \(x\)成立，且左边由只依赖 \(G\) 的常数一致控制。
\(G'\) 只有有限个跳点，因而所得有界函数在 \([1,2]\) 上 Riemann
可积。更形式地，将第 \(N\) 个网格值在
\([N/Y,(N+1)/Y)\) 上延伸为常数，则 (5) 与一致有界性给出受控
\(L^1[1,2]\) 收敛。于是 (3) 是一个 Riemann 和，并有

\[
\boxed{
YK_Y(d_Y,e_Y)
\longrightarrow
\mathcal K_R(u,v)
:=\int_1^2\frac1{x^2}
G'(u/x)G'(v/x)\,dx.
}
\tag{6}
\]

作 \(z=1/x\) 变量代换，这个极限核有更简洁的形式

\[
\boxed{
\mathcal K_R(u,v)
=\int_{1/2}^1G'(uz)G'(vz)\,dz.
}
\tag{7}
\]

特别地，\(\mathcal K_R\) 是 dilate family
\(z\mapsto G'(uz)\) 在 \(L^2[1/2,1]\) 中的正 Gram，并非 lcm 核。

## 3. 连续符号不可能有 \(L^2\) 谱隙

取任意非退化紧区间 \(J=[a,b]\subset(0,\infty)\)，并定义

\[
(\mathbf K_Jq)(u)
:=\int_J\mathcal K_R(u,v)q(v)\,dv.
\tag{8}
\]

由 \(G'\in L^\infty\)，

\[
\int_J\int_J|\mathcal K_R(u,v)|^2\,du\,dv<\infty.
\tag{9}
\]

故 \(\mathbf K_J\) 是 \(L^2(J)\) 上的正 Hilbert--Schmidt 紧算子。若存在
\(c_J>0\) 使

\[
\langle q,\mathbf K_Jq\rangle
\ge c_J\|q\|_{L^2(J)}^2
\qquad(q\in L^2(J)),
\tag{10}
\]

则 \(\mathbf K_J\) 在无限维空间上有界下，与紧性矛盾。等价地，对任意
\(L^2(J)\) 正交序列 \(q_n\)，紧性给出一个子列使
\(\|\mathbf K_Jq_n\|_2\to0\)，从而击穿 (10)。所以

\[
\boxed{
\inf_{\|q\|_2=1}
\langle q,\mathbf K_Jq\rangle=0.
}
\tag{11}
\]

## 4. 全尺度比率核与有限 shell 失配

若将 (6) 中的 \(x\)-积分人工扩张到 \((0,\infty)\)，则得到

\[
\mathcal K_R^{\rm full}(u,v)
:=\int_0^\infty x^{-2}G'(u/x)G'(v/x)\,dx
=\frac1u\int_0^\infty G'(t)G'((v/u)t)\,dt.
\tag{12}
\]

这是一个可由 Mellin 坐标对角化的 ratio kernel。但真实 dyadic shell
只保留 \(x\in[1,2]\)，即 (7) 中的有限 \(z\)-window。所以全尺度的
Mellin 对角化不能直接充当 note 100 所缺的 divisor intertwiner。

## 5. 精确边界

(6)--(7) 给出了中心化 Gram 的正连续符号，但 (11) 说明它对任意
连续活跃区间都没有统一 raw \(L^2\) gap。这不排除下列更强结构：

- 对算术子空间的非平凡限制；
- 负 Sobolev 或 covariance-difference 范数下的 coercivity；
- 新的 common-scale 到 divisor-incidence intertwiner。

它严格关闭的只是：从连续中间 Gram 的正号本身推出一个参数一致
\(L^2\) 谱隙。
