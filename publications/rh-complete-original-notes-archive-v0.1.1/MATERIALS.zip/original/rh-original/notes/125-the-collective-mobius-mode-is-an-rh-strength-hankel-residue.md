> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Collective Möbius mode 是 RH 强度的 Hankel residue

日期：2026-08-14。

依赖：[note 118](118-an-endpoint-flat-detector-gives-an-exact-positive-reciprocal-product-rh-gate.md)、
[note 124](124-even-even-collective-coupling-blocks-local-mobius-negative-energy-accumulation.md)。

证据等级：精确 Mellin--Hankel 表示、residue 计算与 Schur complement。

本文判定完整 Möbius 权重能否自动中心化 note 124 的 collective mode。答案是否定的：
该 mode 是 Mellin contour 上 \(s=-1\) 的 rank-one residue，其坐标恰为 RH 等强的
加权 Mertens 和。

令

\[
A_z(s)=\sum_{a\le z}\frac{\mu(a)}{a^s},
\qquad z=\sqrt x,
\tag{1}
\]

并沿用

\[
V(u)=-2u+6u^2-4u^3,
\qquad
\widehat V(s)=\frac{2(s-1)}{(s+1)(s+2)(s+3)}.
\tag{2}
\]

对 \(\sigma>1\)，Mellin 反演给出

\[
P_V(y)=\frac1{2\pi i}\int_{\Re s=\sigma}
\zeta(s)\widehat V(s)y^s\,ds.
\tag{3}
\]

因此完整 reciprocal-product 门精确为

\[
\boxed{
T_V(x)=\frac1{2\pi i}\int_{\Re s=\sigma}
\zeta(s)\widehat V(s)x^sA_z(s)^2\,ds.}
\tag{4}
\]

关键是 \(A_z(s)^2\)，而不是 \(A_z(s)A_z(\bar s)=|A_z(s)|^2\)。
所以 (4) 是 multiplicative Hankel square，不是 Toeplitz/Parseval 正平方。

在 \(s=-1\)，

\[
\operatorname*{Res}_{s=-1}\widehat V(s)=-2,
\qquad
\zeta(-1)=-\frac1{12}.
\tag{5}
\]

故移动 contour 穿过 \(s=-1\) 时得到

\[
\boxed{
\operatorname*{Res}_{s=-1}
\zeta(s)\widehat V(s)x^sA_z(s)^2
=\frac1{6x}\left(\sum_{a\le z}a\mu(a)\right)^2.}
\tag{6}
\]

记

\[
S(z)=\sum_{a\le z}a\mu(a),
\qquad
C_x(a,b)=P_V(x/(ab))-\frac{ab}{6x}.
\tag{7}
\]

则

\[
\boxed{
T_V(x)=\mu^TC_x\mu+\frac{S(z)^2}{6x}.}
\tag{8}
\]

这也有精确 Schur 解释。令

\[
r_a=\frac{a}{\sqrt{6x}},
\qquad
\mathbb K_x=
\begin{pmatrix}
K_x&r\\
r^T&1
\end{pmatrix},
\qquad K_x(a,b)=P_V(x/(ab)).
\tag{9}
\]

右下角 Schur complement 是 \(C_x=K_x-rr^T\)，但对真实 Möbius 向量的
极小化参数唯一为

\[
\boxed{
t_*=-r^T\mu=-\frac{S(z)}{\sqrt{6x}}.}
\tag{10}
\]

所以 Schur 条件化并未自动删除 collective mode；它要求预先知道 \(S(z)\)。
而

\[
\frac{S(z)^2}{6z^2}\ll_\varepsilon z^{1+2\varepsilon}
\iff
S(z)\ll_\varepsilon z^{3/2+\varepsilon}
\iff \mathrm{RH},
\tag{11}
\]

最后一个等价由 note 118 的部分求和及逆公式给出。

Bernoulli 展开显示首个非正断点：

\[
P_V(y)=\frac1{6y}-\frac{B_2(\{y\})}{y}+O(y^{-2}),
\tag{12}
\]

从而 centered 主项包含

\[
-\frac1x\sum_{a,b\le z}
ab\,\mu(a)\mu(b)B_2\!\left(\left\{\frac{x}{ab}\right\}\right).
\tag{13}
\]

相位依赖 \(1/(ab)\)，不能分离成单变量模平方；而 notes 119--122 的负主子式也
排除对所有系数成立的正 Gram 表示。

最后，尺度算子 \(x\partial_x+1\) 虽在每个平方间隔内部消去
\(S(\sqrt x)^2/(6x)\)，却在 \(x=N^2\) 留下跳跃质量

\[
\boxed{
\frac{\mu(N)NS(N-1)}3+\frac{N^2\mu(N)^2}{6}.}
\tag{14}
\]

它只是把 RH 等强的一维量搬到平方边界。

结论：

\[
\boxed{
\text{完整 Möbius 卷积不产生免费 centering；
collective mode 是 RH 强度的 }s=-1\text{ Hankel residue}.}
\tag{15}
\]

下一步若继续此路线，必须直接控制 Hankel centered cancellation (13)，不能再用
有限秩 Schur、尺度导数或局部负块规避 \(S(z)\)。这不是 RH 的证明。
