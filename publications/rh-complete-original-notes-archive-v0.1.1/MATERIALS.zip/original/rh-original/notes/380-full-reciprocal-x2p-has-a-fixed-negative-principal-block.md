> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(X=2p\) 的 full reciprocal 矩阵有固定负特征值

## 主块

沿用 note 379 的假设，取 \(p>2\) 素数、\(X=2p\)，并将 full reciprocal 矩阵
\[
H^\phi_{a,b}=\phi(ab/X)
\]
限制到除数 \(\{1,2,p\}\)。由于 \(\phi(u)=0\) 对 \(u\ge1\)，得到
\[
K_p^\phi=
\begin{pmatrix}
\phi(1/(2p))&\phi(1/p)&\phi(1/2)\\
\phi(1/p)&\phi(2/p)&0\\
\phi(1/2)&0&0
\end{pmatrix}.
\tag{1}
\]
这里 \((2,p)\) 与 \((p,2)\) 的条目是 \(\phi(1)=0\)，而 \((p,p)\) 的条目为
\(\phi(p/2)=0\)。

## 严格负惯性

直接展开行列式：
\[
\boxed{
\det K_p^\phi=-\phi(2/p)\,\phi(1/2)^2.}
\tag{2}
\]
若 \(\phi(2/p)>0\)，则 \(\det K_p^\phi<0\)，所以该 \(3\times3\) Hermitian 主块至少有一个负特征值。这个结论不依赖 Möbius 向量，也不依赖任何数值近似。

若 \(\phi\) 在 \(0\) 附近为正（例如所有常见的非零 beta/cutoff 核），则对充分大的 \(p\) 自动有 \(\phi(2/p)>0\)。设 \(c=\phi(1/2)>0\)，并令
\[
K_\infty=
\begin{pmatrix}0&0&c\\0&0&0\\c&0&0\end{pmatrix}.
\]
其最小特征值为 \(-c\)。由 \(\phi(u)\to0\)（\(u\downarrow0\)）和 Weyl 扰动不等式，
\[
\lambda_{\min}(K_p^\phi)\longrightarrow -c.
\tag{3}
\]
因此负方向不是趋于零的边界数值误差，而是固定大小的跨半格 reflection mode。

## 对 cutoff/Gram 路线的含义

原始 \(\sqrt X\) cutoff 在 \(p>2\sqrt{2p}\) 时只看到 \(\{1,2\}\)，完全看不到第 \(p\) 行列；其 \(2\times2\) 小块不包含 (2) 的负方向。把 full PSD Gram 矩阵先构造出来、再无误差压缩到 cutoff，必然丢失这个固定负特征值；任何声称“full positivity 自动传到 cutoff”的论证都必须显式给出跨半格 Schur 补偿。

该结果只排除 direct PSD/positive-Schur 迁移，不排除保留 reflection parity 的 Kreĭn 或 signed intertwiner；后者仍是项目的真正未解接口。

