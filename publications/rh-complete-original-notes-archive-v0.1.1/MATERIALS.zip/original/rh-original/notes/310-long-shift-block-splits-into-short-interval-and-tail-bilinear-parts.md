> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 长移位块的精确分解：短区间项加尾部双线性项

日期：2026-08-16。

取整数 dyadic 块 \(U\le u<2U\)，并令 \(h=X-u\)。定义
\[
R_U(X)=\sum_{U\le u<2U}\sum_{n\le u}f(n)f(n+X-u),
\qquad |f(n)|\le1.
\]
交换 \(u,n\) 的求和次序。对 \(1\le n\le U\)，令
\(m=n+X-u\)；对 \(U<n<2U\)，令 \(k=2U-n\)。得到精确恒等式
\[
\begin{aligned}
R_U(X)
={}&\sum_{n=1}^{U} f(n)
 \sum_{m=X+n-2U+1}^{X+n-U}f(m)\\
&+\sum_{k=1}^{U-1} f(2U-k)
 \sum_{m=X-k+1}^{X}f(m).
\end{aligned}
\tag{1}
\]
记右侧两项为 \(A_U(X)+B_U(X)\)。

## 1. 第一项：普通短区间和

\(A_U\) 是长度为 \(U\) 的短区间 Liouville 和的加权抽样：
\[
|A_U(X)|
\le \sum_{n\le U}
\left|\sum_{m=X+n-2U+1}^{X+n-U}f(m)\right|.
\tag{2}
\]
对 \(f=\lambda\)，MRT 的短区间指数和定理取频率
\(\alpha=0\)，给出全体起点的 \(L^1\) 控制
\[
\sum_{x\le X}\left|\sum_{x\le m\le x+U} \lambda(m)\right|
\ll XU\,\sigma_X(U)+O(X),
\tag{3}
\]
其中
\[
\sigma_X(U)\ll
\frac{\log\log(3U)}{\log(3U)}
+\frac1{\log^{1/700}(3X)}.
\]
因此 \(A_U\) 可由已有短区间结果控制；但 (3) 的量级在
\(U\asymp X\) 时仍为 \(X^2\) 乘对数节省，远未达到 \(X^{1+\varepsilon}\)。

## 2. 第二项：真正的新双线性门

令
\[
L_f(t)=\sum_{m\le t}f(m).
\]
则
\[
\sum_{m=X-k+1}^{X}f(m)=L_f(X)-L_f(X-k),
\]
故
\[
\boxed{
B_U(X)=\sum_{k=1}^{U-1}f(2U-k)
\bigl(L_f(X)-L_f(X-k)\bigr).
}
\tag{4}
\]
等价地，展开端点增量后
\[
B_U(X)=\sum_{1\le j<k<U}a_k b_j,\qquad
a_k=f(2U-k),\quad b_j=f(X-j).
\tag{5}
\]
这是两个相隔约 \(X-2U\) 的 Liouville 块之间的三角形双线性型。
其矩阵 \(T_U=(1_{j<k})\) 的 \(\ell^2\) 算子范数为 \(\asymp U\)；
所以仅凭 \(\ell^2\) 归一化和 \(|f|\le1\) 也只能得到 \(O(U^2)\)，
不能凭一般 Hilbert-space 正性产生平方根节省。
这不是固定端点的二点 Chowla 平均：第一因子是反向取样的
\(f(2U-k)\)，第二因子是 \(L_f\) 的端点增量，二者共享同一个 \(k\)。
对 (5) 逐项取绝对值只给 \(O(U^2)\)；用全局 PNT 的
\(L_f(t)=o(t)\) 也至多给 \(o(XU)\)，不能达到平方根级。

因此长移位门并非只有“terminal endpoint”技术问题。即使短区间部分
\(A_U\) 用 MRT 处理，仍需一个对 \(B_U\) 保留符号的 bilinear
intertwiner，或等价的端点增量相关估计。该对象正是现有 collar 文献
未提供的中程 signed 算术输入。

结论：恒等式 (1)--(5) 严格分离了可由短区间平均处理的部分和真正未决的
尾部双线性部分；没有把任何一部分升级为 RH 证明。
