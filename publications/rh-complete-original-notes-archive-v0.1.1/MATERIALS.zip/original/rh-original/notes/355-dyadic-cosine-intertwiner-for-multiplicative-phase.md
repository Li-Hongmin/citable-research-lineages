> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Dyadic cosine intertwiner for the multiplicative phase

日期：2026-08-16。

## 结论

在一个 dyadic 块上，乘法相位确实可以精确展开成加法 Fourier
block；但展开需要所有频率 \(k\)，而固定临界弧的局部矩只覆盖有限个
固定 \(k\)。因此这给出一个真实的 candidate intertwiner，同时精确暴露
剩余的全频 signed 算术门。

## 精确余弦展开

令 \(X\) 为正整数，\(X<n\le 2X\)，并写
\[
 y=\frac nX-1\in(0,1],\qquad
 f_\tau(y)=(1+y)^{i\tau}.
\]
定义余弦系数
\[
 a_0(\tau)=\int_0^1 f_\tau(y)\,dy
 =\frac{2^{1+i\tau}-1}{1+i\tau},
\]
以及
\[
 a_k(\tau)=2\int_0^1f_\tau(y)\cos(\pi ky)\,dy,\qquad k\ge1.
\]
余弦 Fourier 展开在 \([0,1]\) 上逐点收敛，故有精确有限块恒等式
\[
 \sum_{X<n\le2X}\mu(n)n^{i\tau}
 =X^{i\tau}
 \left[
 a_0(\tau)C_{X,0}
 +\sum_{k\ge1}a_k(\tau)C_{X,k}
 \right],
\tag{1}
\]
其中
\[
 C_{X,k}:=\sum_{X<n\le2X}\mu(n)
 \cos\!\left(\pi k\left(\frac nX-1\right)\right).
\tag{2}
\]
这里 \(k=0\) 的约定是 \(C_{X,0}=\sum_{X<n\le2X}\mu(n)\)。
由于 \(\cos(\pi k(n/X-1))=(-1)^k\cos(\pi kn/X)\)，(1) 正是把
\(n^{i\tau}\) 变成加法频率 \(k/(2X)\) 的展开，而不是一阶 Taylor 近似。

两次分部积分给出，对 \(k\ge1\)，
\[
 |a_k(\tau)|
 \le \frac{2}{(\pi k)^2}
 \left(
 |f_\tau'(1)-f_\tau'(0)|
 +\int_0^1|f_\tau''(y)|\,dy
 \right)
 \ll \frac{|\tau|(1+|\tau|)}{k^2}.
\tag{3}
\]
因此余弦系数在 \(k\) 上绝对可和；该估计也足以在带有正频率矩的
\(\tau\)-积分中交换求和与积分。

## 与局部矩的精确接口及其限制

若 \(X\) 为整数，则
\[
 C_{X,k}
 =(-1)^k\Re\!\left(
 \sum_{n\le2X}\mu(n)e^{\pi ikn/X}
 -\sum_{n\le X}\mu(n)e^{\pi ikn/X}
 \right).
\tag{4}
\]
所以固定 \(k\) 的 block 系数确实是两个初始 Möbius Fourier 多项式的
差。但 Verjovsky 型临界弧只给
\[
 |t|\le \frac{c}{N}.
\]
对 \(N=2X\) 而 \(t=k/(2X)\)，这只覆盖
\[
 |k|\le c.
\tag{5}
\]
固定 \(c\) 时，(5) 只控制有限个加法频率；它不控制 (1) 中的全频尾。

## Parseval 尾界给出的最小增长弧门

这个缺口不能只用逐项平凡界描述。令
\[
 E_{X,k}:=\sum_{X<n\le2X}\mu(n)e^{\pi ikn/X}.
\]
对 \(k\) 取模 \(2X\) 的离散 Fourier Parseval 给出
\[
 \sum_{k=0}^{2X-1}|E_{X,k}|^2
 =2X\sum_{X<n\le2X}\mu(n)^2\le 2X^2.
 \tag{6}
\]
因为 \(|C_{X,k}|\le |E_{X,k}|\)，以及 (3) 的
\(k^{-2}\) 衰减，对 \(K<k\le2X\) 有
\[
 \left|\sum_{K<k\le2X}a_k(\tau)C_{X,k}\right|
 \ll |\tau|(1+|\tau|)\,XK^{-3/2}.
\tag{7}
\]
而 \(k>2X\) 的周期重复部分用 \(|C_{X,k}|\le X\) 和 (3) 处理，只产生
\(O(|\tau|(1+|\tau|))\) 的尾项。于是，若对所有 \(|k|\le K\) 能有
平方根级的 block 估计
\[
 |C_{X,k}|\ll_\varepsilon X^{1/2+\varepsilon},
\tag{8}
\]
则选择 \(K\ge X^{1/3+2\varepsilon/3}\) 就能把 (7) 推到
\(O(X^{1/2+\varepsilon})\)（固定 \(\tau\)；带 \(\tau\)-权时还需相应频率矩）。

这把所需新输入精确化为“增长弧”而非任意全频估计：必须把局部矩/
加法 Möbius 控制从固定 \(|k|\le c\) 扩展到至少 \(X^{1/3+o(1)}\) 个
加法频率，并且还要对 dyadic block 的差 (4) 保持一致。Verjovsky
定理的 \(c\) 是固定常数，故目前不能提供 (8) 的增长弧版本；Parseval
本身只控制尾部，不能控制低频 block 系数。

若用平凡界 \(|C_{X,k}|\le X+1\) 处理 \(k>K\)，由 (3) 只能得到
\[
 \left|\sum_{k>K}a_k(\tau)C_{X,k}\right|
 \ll \frac{X|\tau|(1+|\tau|)}{K}.
\tag{9}
\]
要把该误差降到平方根尺度，\(K\) 至少要达到近似
\(X^{1/2}\)（还要支付 \(\tau\)-依赖）；这远超固定临界弧提供的
有限频率范围。反过来，对所有 \(k\le K\) 假设平方根级
\(C_{X,k}\) 控制，本身就是一个大范围的 shifted/additive Möbius
算术输入，不能从局部矩的正性自动推出。

因此 (1) 是一个真实但未闭合的加法—乘法 intertwiner。它把缺口从
“二次相位不能丢掉”的局部说法，sharpen 成全频条件：
\[
 \text{需要控制 }\
 \sum_{k\ge1}a_k(\tau)C_{X,k}
 \quad\text{而非只控制固定 }k.
\]
当前文献的局部矩定理没有提供这一全频、跨 dyadic block 的 signed
估计；本结果不构成 RH 证明。

## 现有均匀指数和只能给出对数级门

Davenport 的经典一致估计
\[
 \sup_{\alpha\in\mathbb R}
 \left|\sum_{n\le Y}\mu(n)e(\alpha n)\right|
 \ll_A Y(\log(2Y))^{-A}
\]
（固定 \(A\)；原始来源见
<https://doi.org/10.1093/qmath/os-8.1.313>）代入 (4) 后，只能给
\[
 \sup_k |C_{X,k}|\ll_A X(\log X)^{-A}.
\]
因为 \(\sum_{k\ge1}|a_k(\tau)|\ll|\tau|(1+|\tau|)\)，这使 (1) 的低频部分
仍为 \(X(\log X)^{-A}\) 量级，而不是平方根量级。已有的更强有理频率
估计若只达到 \(X^{3/4+\varepsilon}\)，也仍留下 \(X^{1/4}\) 的幂次缺口。
所以 Parseval 尾界把问题压到增长弧后，现有均匀指数和并没有关闭该弧；
需要新的平方根级 block 估计或等价的 signed arithmetic input。

近期的一个更强结果仍不能填上这个低频缺口。Srivastav 的
*Log-free bounds on exponential sums over primes*（含 Möbius 结论，
arXiv:2505.07803v2）允许
\(\alpha=a/q+\delta/x\)、\(q\le x^{2/5-\eta}\) 且
\(|\delta|\le x^{1/5+\eta}/q\)，其中 \(x=2X\)：
<https://arxiv.org/abs/2505.07803>。

这里需要区分两种表示。对
\(\alpha=k/(2X)=k/x\)，若 \(k\le x^{1/5+\eta}\)，可取
\(q=1,a=0,\delta=k\)，定理给出（除常数区间外）
\[
 \left|\sum_{n\le x}\mu(n)e(kn/x)\right|
 \ll_\eta x\,k^{-1/2}
 \]
的增长弧估计。但 \(k=O(1)\) 时这仍是 \(O(x)\)，而余弦系数满足
\(|a_k(\tau)|\ll_\tau k^{-2}\)，故
\[
 \sum_{1\le k\le x^{1/5+\eta}}|a_k(\tau)|\,
 x k^{-1/2}=O_\tau(x);
\]
零频 \(a_0C_{X,0}\) 也仍是同一量级。

对剩余的
\(x^{1/5+\eta}\ll k\le X^{1/3}\)，采用精确约分后的分母则有
\[
 q=\frac{2X}{\gcd(k,2X)}
 \ge \frac{2X}{k}\gg X^{2/3},
\]
超出该定理的 \(q\le x^{2/5-\eta}\) 范围。因此，Srivastav 结果确实
覆盖了一个增长的 \(q=1\) 主弧子区间，也改善了部分非零加性弧；
但它既不能压低 \(k=O(1)\) 的 Mertens 低频门，也不能覆盖其余
\(X^{1/5+\eta}\ll k\le X^{1/3}\) 的精确约分区间。该修正不改变结论：
当前仍需要增长弧上的平方根级 block 估计或等价的 signed arithmetic input。
