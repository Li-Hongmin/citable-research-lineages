> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Endpoint-flat polynomial detectors 具有非平凡正核锥

日期：2026-08-14。

依赖：[note 101](101-a-bv-mellin-detector-sees-exactly-uncancelled-zeta-multiplicity.md)、
[note 118](118-an-endpoint-flat-detector-gives-an-exact-positive-reciprocal-product-rh-gate.md)。

证据等级：一般截断卷积恒等式与四次 Faulhaber 完全分类。

note 118 的三次 detector 同时具有端点平坦、零均值和逐项非负的
reciprocal-product 核。本文分开这三种性质：截断恒等式对所有端点平坦多项式成立，
但核正性只占据一个真凸锥。到四次为止，该锥可以精确分类。

## 1. 一般多项式恒等式

令

\[
V(u)=\sum_{k=1}^d v_ku^k\qquad(0<u<1),
\tag{1}
\]

并在区间外取零，假设

\[
V(0)=V(1)=0.
\tag{2}
\]

定义

\[
P_V(y)=\sum_{c\le y}V(c/y)
=\sum_{k=1}^d\frac{v_k}{y^k}
\sum_{c=1}^{\lfloor y\rfloor}c^k,
\tag{3}
\]

以及

\[
U_V(x)=\sum_n\mu(n)V(n/x),
\qquad
\nu_x(n)=\mu(n)\mathbf1_{n\le\sqrt x}.
\tag{4}
\]

对 \(n\le x\)，精确截断卷积恒等式给出

\[
\mu(n)=2\nu_x(n)-(\nu_x*\nu_x*1)(n).
\tag{5}
\]

因此

\[
U_V(x)=2A_V(x)-T_V(x),
\tag{6}
\]

其中

\[
A_V(x)=\sum_{n\le\sqrt x}\mu(n)V(n/x),
\tag{7}
\]

\[
T_V(x)=\sum_{a,b\le\sqrt x}\mu(a)\mu(b)
P_V\!\left(\frac{x}{ab}\right).
\tag{8}
\]

因 \(V(u)=O_V(u)\) 于 \(0\)，有 \(A_V(x)=O_V(1)\)，故

\[
\boxed{T_V(x)=-U_V(x)+O_V(1).}
\tag{9}
\]

这里 (9) 不要求 \(P_V\ge0\)，也不要求 \(\int_0^1V=0\)。后一个条件只控制
Mellin numerator 在 \(s=1\) 的消零及 separated collective term。

## 2. 三次正核锥

再假设

\[
\int_0^1V(u)\,du=0.
\tag{10}
\]

若 \(d\le2\)，(2) 与 (10) 只允许 \(V=0\)。若 \(d=3\)，线性约束给出

\[
(v_1,v_2,v_3)
=\left(\frac{v_3}{2},-\frac{3v_3}{2},v_3\right).
\tag{11}
\]

写 \(y=N+r\)，其中 \(N=\lfloor y\rfloor\ge1\)、\(0\le r<1\)。
Faulhaber 公式化简为

\[
P_V(y)=
\frac{N(N+1)r(r-1)}{4(N+r)^3}v_3.
\tag{12}
\]

所以

\[
\boxed{P_V(y)\ge0\ (y\ge1)\iff v_3\le0.}
\tag{13}
\]

note 118 的 \((-2,6,-4)\) 正好位于这个射线内部。

## 3. 四次正核锥的精确分类

令 \(d=4\)。由 (2)、(10)，

\[
v_1=\frac{v_3}{2}+\frac{4v_4}{5},
\qquad
v_2=-\frac{3v_3}{2}-\frac{9v_4}{5}.
\tag{14}
\]

将前四个幂和代入 (3)，得到

\[
P_V(N+r)=\frac{N(N+1)}{60(N+r)^4}B_{v_3,v_4}(N,r),
\tag{15}
\]

其中

\[
\begin{aligned}
B_{v_3,v_4}(N,r)
={}&15Nr^2v_3+36Nr^2v_4-15Nrv_3-36Nrv_4+2Nv_4\\
&+15r^3v_3+24r^3v_4-15r^2v_3-18r^2v_4-2v_4.
\end{aligned}
\tag{16}
\]

必要性立即来自两个边界。取 \(r=0\)、\(N\ge2\)，

\[
P_V(N)=\frac{v_4(N^2-1)}{30N^3},
\tag{17}
\]

故必须 \(v_4\ge0\)。再取 \(N=1\)、\(r\downarrow0\)，由

\[
B_{v_3,v_4}(1,r)
=3r\big[(5v_3+8v_4)r^2+6v_4r-(5v_3+12v_4)\big]
\tag{18}
\]

得到 \(5v_3+12v_4\le0\)。

反之，写

\[
v_4=w\ge0,
\qquad
v_3=-\frac{12}{5}w-t,
\qquad t\ge0.
\tag{19}
\]

则 (16) 精确变成

\[
B_{v_3,v_4}(N,r)
=15tr(N+r)(1-r)
+w\big[2(N-1)+6r^2(3-2r)\big]\ge0.
\tag{20}
\]

于是

\[
\boxed{
P_V(y)\ge0\quad(y\ge1)
\iff
v_4\ge0,
\qquad
v_3\le-\frac{12}{5}v_4.}
\tag{21}
\]

## 4. Endpoint flatness 不自动给出正性

取

\[
V(u)=-\frac45u+\frac95u^2-u^4.
\tag{22}
\]

它满足

\[
V(0)=V(1)=0,
\qquad
\int_0^1V(u)\,du=0,
\qquad
V'(0)<0,
\tag{23}
\]

但由 (17)，对每个整数 \(N\ge2\)，

\[
\boxed{P_V(N)=-\frac{N^2-1}{30N^3}<0.}
\tag{24}
\]

因此 endpoint flatness 与零均值只保证结构性消去，不保证 Faulhaber 核正性。
note 118 的正核属于 (21) 的特殊系数锥。该分类扩展的是 detector-to-kernel 机制，
不是 RH 的证明。相应 Mellin numerator 的零自由性在下一节完成核验。

## 5. 四次正核锥自动 Mellin-visible

在 (14) 的参数化中，Mellin 变换精确为

\[
\boxed{
K_V(s)=-
\frac{(s-1)\big[(5v_3+12v_4)s+20v_3+36v_4\big]}
{10(s+1)(s+2)(s+3)(s+4)}.}
\tag{25}
\]

在非零正核锥 (21) 内，若 \(5v_3+12v_4<0\)，额外零点为

\[
s_0=
-\frac{20v_3+36v_4}{5v_3+12v_4}
\le-4,
\tag{26}
\]

等号只对应三次边界上的可消因子；若 \(5v_3+12v_4=0\)，(25) 的
额外线性因子退化为非零常数。因此整个非零正核锥满足

\[
\boxed{
K_V(s)\ne0\qquad(1/2<\Re s<1).}
\tag{27}
\]

所以每个非零四次正核都自动给出 note 101 意义下的 RH-visible detector。

另一方面，

\[
\operatorname*{Res}_{s=-1}K_V(s)
=v_1=\frac{v_3}{2}+\frac{4v_4}{5}.
\tag{28}
\]

由 (21)，

\[
v_1\le-\frac25v_4\le0,
\tag{29}
\]

且 \(v_1=0\) 只可能发生在 \(v_4=v_3=0\)，即零多项式。因此：

\[
\boxed{
\deg V\le4,\quad
P_V\ge0,\quad V\ne0
\Longrightarrow
\operatorname*{Res}_{s=-1}K_V<0.}
\tag{30}
\]

四次正核锥无法删除首个 collective residue；note 137 表明最小删除次数实际为六。
