> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Newton γ 的 h-对偶二项式变换

日期：2026-08-17。

本 note 给出一个比逐个 (h) 处理更薄的精确恒等式。它不宣称全 (m)
γ-正性，但把剩余问题压缩为一个有限二项式变换的系数锥。

## 1. 从 (h)-权重到倒数变量

沿用

\[
D=3m+3,\qquad d=D-2=3m+1,\qquad r=d-h,
\]

以及 note 156 的 (K_q)、
\(
\mathcal F_{a,b}(M)=
\sum_{i+j=M}\left\{\begin{smallmatrix}a\\i\end{smallmatrix}\right\}
\left\{\begin{smallmatrix}b\\j\end{smallmatrix}\right\}i!j!
\)。恒等式

\[
\frac{\binom hs}{\binom ds}
 =\frac{r!}{d^{\underline r}}\binom{d-s}{r}
\tag{1}
\]

把 γ 的 (h)-加权和变成一个二项式变换。注意式 (1) 的二项式是
\(\binom{d-s}{r}\)，不是 \(\binom{d-s}{r-s}\)。

令 (M=L+1)、(R_q=D-q-1)，并把 (q=1) 的
\(K_1=-3w_2\) 与 (q=m+1) 的末项按 note 157 约定纳入，则定义

\[
\mathcal G_{m,L}(r):=
\sum_{q=1}^{m+1}K_q
\sum_{s=0}^{R_q}
\binom{R_q}{s}\binom{d-s}{r}
\mathcal F_{q+1,R_q-s}(M).
\tag{2}
\]

直接代入 note 156 的 Stirling/Fraction 公式，得到严格恒等式

\[
\boxed{
\gamma_{m,h,L}
 =\frac{r!}{(L+2)!\,d^{\underline r}}
   \mathcal G_{m,L}(r),\qquad r=d-h .}
\tag{3}
\]

因此全体 (h) 的 γ-正性等价于
\(
\mathcal G_{m,L}(r)\ge0
\)
对 (0\le r\le d) 成立。这里的等价性是逐个固定
\((m,L,r)) 的精确有理恒等式，不是数值近似。

## 2. 生成函数形式

设

\[
A_n(z)=\sum_{a\ge0}\left\{\begin{smallmatrix}n\\a\end{smallmatrix}\right\}a!z^a,
\qquad
B_R(t,z)=\sum_{s=0}^{R}\binom Rs A_{R-s}(z)t^s.
\]

则 (\mathcal F_{q+1,R_q-s}(M)) 是
\(A_{q+1}(z)A_{R_q-s}(z)) 的 (z^M) 系数，故 (2) 等价于

\[
\mathcal G_{m,L}(r)
=[x^r z^M]
 (1+x)^d
 \sum_{q=1}^{m+1}K_q A_{q+1}(z)
 B_{R_q}\!\left(\frac1{1+x},z\right).
\tag{4}
\]

式 (4) 的每个固定 (q) 项在 (x,z) 中系数非负；唯一的符号问题是
完整 (q)-和中的 (K_q) 低段负、高段正。由 (A_n) 的指数生成函数

\[
\sum_{n\ge0}A_n(z)\frac{t^n}{n!}
 =\frac1{1-z(e^t-1)},
\tag{5}
\]

也可把 (4) 看成一个带 signed (K_q) 的二变量 Fubini 卷积。该表示
明确指出，逐 (q) 正化不可能是证明路线。

## 3. 精确核对与当前边界

用整数 Stirling 数和 Fraction 直接比较 (3) 与原始公式，
\(m\le7\)、所有测试的 (h) 和 (L=0,1,2) 均逐项相等；例如
\(m=3,L=3,d=10\) 时，

\[
\bigl(\mathcal G_{3,3}(r)\bigr)_{r=0}^{10}
=(4963464,15005520,15349320,5964480,1592640,
1870848,1592640,953280,371880,84240,8424),
\]

全部为正，且由 (3) 恢复完整的 γ 值。这个例子也说明，raw
累积系数可以有负项，而正确的 (h)-对偶变换仍然为正。

目前尚未证明 (2) 对任意 (m,L,r) 非负，也未发现精确负例。因此新的
最小纯代数缺口可以写成

\[
\boxed{\mathcal G_{m,L}(r)\ge0
\quad(m\ge1,\ 0\le L\le3m+2,\ 0\le r\le3m+1).}
\]

即使这个系数锥最终闭合，它只推进 detector 的全层级正性；Möbius
reciprocal-product 二次型的平方根级 signed cancellation 仍是独立的
RH-strength 算术门。

## 4. 一个严格的 (L)-因子化

令

\[
 H_{m,L}(x):=\sum_{r=0}^{d}\mathcal G_{m,L}(r)x^r .
\]

把式 (2) 中的二项式求和先做掉，得到

\[
 H_{m,L}(x)
 =\sum_{q=1}^{m+1}K_q\sum_{s=0}^{R_q}
 \binom{R_q}{s}\mathcal F_{q+1,R_q-s}(L+1)
 (1+x)^{d-s} .
 \tag{13}
\]

写 (y=1+x)、(n=d-s)。由于

\[
 R_q-s=(d+1-q)-s=n+1-q,
 \qquad
 (q+1)+(R_q-s)=n+2,
\]

而 \(\mathcal F_{a,b}(M)=0\) 对所有 (M>a+b)，当
 (n\le L-2) 时有
 \(L+1>n+2\)，故式 (13) 中 (y^n) 的系数逐个 \(q\)
 都为零。因而严格得到

\[
 \boxed{(1+x)^{L-1}\mid H_{m,L}(x)\qquad(L\ge1).}
 \tag{14}
\]

这一步不使用正性、有限扫描或极限交换。对 (L=0,1) 约定商就是
 (H_{m,L}) 本身；对 (L\ge2) 定义

\[
 \widehat H_{m,L}(x):=
 \frac{H_{m,L}(x)}{(1+x)^{L-1}} .
\]

若记式 (13) 中 \(y^n\) 的系数为 \(a_{m,L}(n)\)，则商系数有精确的
正二项式变换

\[
 [x^r]\widehat H_{m,L}(x)
 =\sum_{n\ge L-1}a_{m,L}(n)\binom{n-L+1}{r}.
 \tag{15}
\]

因此，任意 \(L\) 的全体 \(h\)-系数正性可由更薄的商锥条件
\([x^r]\widehat H_{m,L}\ge0\) 推出；乘回 \((1+x)^{L-1}\)
 不会引入负系数。有限精确计算中该商系数也均为非负，但对任意
\(m,L\) 的商锥仍未给出证明；式 (15) 是当前最小的纯代数缺口。

为使这个缺口成为单变量的可审计对象，令 \(L\le t\le d+1\)，定义

\[
 B_{m,L}(t):=
 \sum_{q=1}^{\min(m+1,t)}
 K_q\binom{d+1-q}{t-q}
 \mathcal F_{q+1,t-q}(L+1).
 \tag{16}
\]

将 \(n=d-s=L-1+k\) 代入式 (13)，即 \(t=L+k\)，可得严格恒等式

\[
 \widehat H_{m,L}(x)
 =\sum_{t=L}^{d+1}B_{m,L}(t)(1+x)^{t-L},
 \tag{17}
\]

以及

\[
 [x^r]\widehat H_{m,L}(x)
 =\sum_{t=L+r}^{d+1}
 \binom{t-L}{r}B_{m,L}(t).
 \tag{18}
\]

注意 \(B_{m,L}(t)\) 本身可以变号；式 (18) 的正二项式平滑才是
目前需要证明的对象。因而“逐个 \(B_{m,L}(t)\) 正化”不是必要条件，
但式 (16)--(18) 给出了寻找总正性或第一个精确负例的最小单变量接口。

还可排除一个看似自然的简化：对 \(m=4,L=4,r=0\)，在 Beta 权重
\(t^3(1-t)^6\,dt\) 下，未取公共正因子的被积多项式可化为

\[
 p(t)=96\bigl(3220672t^3-565638t^2-409545t+9620\bigr).
\]

它在 \([0,1]\) 内有两个正根（约为
\(0.02286159197\) 与 \(0.4458259056\)），所以“被积多项式至多
一次变号”并非全层级命题；但其完整积分仍为严格正数

\[
 \int_0^1t^3(1-t)^6p(t)\,dt=\frac{1880}{77}>0.
\]

因此剩余正性确实依赖 Beta 积分后的整体重排，而不是点态或单变号
估计。

## 5. 两个几何变量的严格表示

Fubini 多项式还满足形式恒等式

\[
A_n(z)=\sum_{j\ge0}\frac{j^n z^j}{(1+z)^{j+1}}.
\tag{8}
\]

令 \(X,Y\) 为同一几何权重
\[
\Pr_z(X=j)=z^j/(1+z)^{j+1}
\]
下的两个独立变量，并令 \(u=(1+x)^{-1}\)。则式 (4) 的未取
\(z^M x^r\) 系数部分严格等于

\[
(1+x)^d\,\mathbb E_z\!\left[
X(Y+u)^{D-1}K_m\!\left(\frac{X}{Y+u}\right)
\right].
\tag{9}
\]

将 note 157 的 Beta 表示

\[
K_m(\rho)=A_m\rho\int_0^1t^{m-1}(1-t)^{m+2}
 (t+2\rho)^{m-2}B_m(t,\rho)\,dt,
\]

其中
\[
B_m(t,\rho)=(3m+1)t\rho-3t+4(m+1)\rho^2-2(m+2)\rho,
\]

代入 (9)，并写 \(Q=Y+u\)，得到

\[
\begin{aligned}
&A_m(1+x)^d\int_0^1t^{m-1}(1-t)^{m+2}
 \mathbb E_z\!\left[
 X^2Q^{2m+1}(tQ+2X)^{m-2}\widetilde B_m(t;X,Q)
\right]dt,\\
&\widetilde B_m(t;X,Q)=
 (3m+1)tXQ-3tQ^2+4(m+1)X^2-2(m+2)XQ .
\end{aligned}
\tag{10}
\]

这把全 \(q\)-和的符号问题压缩成一个带 Beta 权重的二几何变量
不等式。\(\widetilde B_m\) 本身并非逐点非负，所以 (10) 不是现成证明；
它说明下一步应利用 \(X,Y\) 的交换、矩对数凸性或 \(t\)-分部积分，而不能
再假设 \(K_q\) 逐项为正。

## 6. 有限 Beta-(j) 分解

把 (10) 中的 ((tQ+2X)^{m-2}) 展开，并令

\[
\omega_{m,j}=\binom{m-2}{j}2^{m-2-j}B(m+j,m+3),
\qquad
\rho_{m,j}=\frac{m+j}{2m+j+3},
\quad 0\le j\le m-2.
\]

则除去显式正公共因子 (A_m(1+x)^d)，式 (10) 严格等于

\[
\sum_{j=0}^{m-2}\omega_{m,j}
\mathbb E_z\!\left[
 X^{m-j}Q^{2m+j+1}R_{m,j}(X,Q)
\right],
\tag{11}
\]

其中

\[
R_{m,j}(X,Q)=4(m+1)X^2
 +\bigl((3m+1)\rho_{m,j}-2(m+2)\bigr)XQ
 -3\rho_{m,j}Q^2 .
\tag{12}
\]

所有 (omega_{m,j}) 均严格为正；但 (R_{m,j}) 不是逐点正，且有限
(j)-层中可出现正负交替。因此下一步最小的可证伪命题是：利用
(A_{n+1}=z(1+z)A_n'+zA_n) 以及 (Q=Y+u) 的同一矩递推，证明
(11) 的相邻 (j)-层可重排为非负和，或给出第一个精确负例。
