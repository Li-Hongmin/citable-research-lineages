> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正能量门的 Mellin 对偶空间

沿用 note 192，记
\[
W(\xi)=|h(\xi)|,\qquad
F_N(\xi)=\sum_{n\le N}\mu(n)n^{i\xi},
\qquad
E_N=\frac1{2\pi}\int_{\mathbb R}W(\xi)|F_N(\xi)|^2d\xi .
\]
正能量门的一个精确对偶形式如下。

## 1. 加权 Mellin 测试

令 \(\psi\) 是一个支持在 \((0,1)\) 的测试函数，令
\(\Psi(\xi)=K_\psi(i\xi)\)，其中
\[
K_\psi(s)=\int_0^1\psi(u)u^{s-1}\,du .
\]
假设 \(\Psi\) 满足
\[
\|\Psi\|_{W^{-1}}^2
:=\frac1{2\pi}\int_{\mathbb R}\frac{|\Psi(\xi)|^2}{W(\xi)}\,d\xi<\infty
\tag{1}
\]
则 Mellin 反演给出
\[
S_\psi(N):=\sum_{n\le N}\mu(n)\psi(n/N)
=\frac1{2\pi}\int_{\mathbb R}
\Psi(\xi)N^{i\xi}F_N(-\xi)\,d\xi .
\tag{2}
\]
因此 Cauchy--Schwarz 产生精确界
\[
\boxed{
|S_\psi(N)|^2\le E_N\|\Psi\|_{W^{-1}}^2 .
}
\tag{3}
\]
（若 \(W=0\) 的点存在，(1) 要求 \(\Psi\) 在这些点有足够阶的消失。）

于是若 note 192 的门
\[
E_N\ll_\varepsilon N^{1+\varepsilon}
\tag{4}
\]
成立，则所有有限 \(\|\Psi\|_{W^{-1}}\) 的 Mellin 测试函数都满足
\[
S_\psi(N)\ll_{\psi,\varepsilon}N^{1/2+\varepsilon}.
\tag{5}
\]

## 2. 与 RH 的精确接口

若能在该加权测试空间中找到一个 \(K_\psi\) 在
\(1/2<\Re s<1\) 无零，则 (5) 的 Mellin 变换
\[
\int_1^\infty S_\psi(x)x^{-s-1}\,dx
=\frac{K_\psi(s)}{\zeta(s)}
\tag{6}
\]
推出 \(\zeta\) 在该带无零，即 RH。

这把 A 线所需的对象级桥压成两个明确条件：

1. \(\Psi\in L^2(W^{-1}d\xi)\)，即能支付 \(h\) 的实频零点；
2. 同一个 \(\Psi\) 的 Mellin 延拓 \(K_\psi\) 在临界带不消失。

一般的 \(\Psi\) 不满足第一个条件；直接把 \(\Psi\) 取成 boundary
\(h\) 也不自动给出一个无零的解析 Mellin multiplier（因为 \(h\) 是
\(\operatorname{Re}(\zeta K)\) 的实边界值）。反之，强行消除
\(h\) 的实频零点会使 (1) 发散。这个兼容性正是当前
positive-energy/Feshbach 路线的最薄解析缺口。

本 note 是精确的对偶恒等式与接口，不声称已经构造出这样的
\(\Psi\)，也不声称证明 RH。
