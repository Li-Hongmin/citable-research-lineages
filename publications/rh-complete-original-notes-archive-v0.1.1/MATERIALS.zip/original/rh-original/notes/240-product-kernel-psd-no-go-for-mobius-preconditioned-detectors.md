> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius-preconditioned detector 的乘积核不能直接 PSD 化

日期：2026-08-17。

note 239 给出
\[
P_{V_\phi}(y)=\phi(1/y),\qquad
K_{V_\phi}(s)=\Phi(s)/\zeta(s)
\]
的 exact collapse。这里证明：若 \(\phi\) 非零且支撑在 \((0,1)\)，
则其 reciprocal 双和核 \(\phi(ab/x)\) 不可能在所有正实数尺度上
成为半正定 Gram 核。

## 1. 指数凸性

固定 \(x>0\)，假设
\[
 \phi(ab/x)
\]
对任意有限 \(a_1,\ldots,a_r>0\) 形成半正定矩阵。令
\[
 h(t):=\phi(e^t/x),\qquad t\in\mathbb R.
\]
取 \(a_i=e^{t_i/2}\)，则假设等价于
\[
 \bigl[h(t_i+t_j)\bigr]_{i,j=1}^r\succeq0
\]
对所有有限实数集成立；也就是说 \(h\) 是指数凸函数。

由 Bernstein--Widder 指数凸定理，连续的指数凸函数在其定义区间内
具有正测度的指数表示
\[
 h(t)=\int_{\mathbb R}e^{\lambda t}\,d\nu(\lambda),
\qquad \nu\ge0,
\tag{1}
\]
并且在开区间内实解析。

但 \(\phi\) 支撑于 \((0,1)\)，所以
\[
 h(t)=0\qquad(t\ge\log x).
\]
这包含一个非空开区间。指数凸函数的解析性遂强迫
\(h\equiv0\)，从而 \(\phi\equiv0\)，矛盾。

因此得到
\[
\boxed{
\phi\not\equiv0,\ \operatorname{supp}\phi\subset(0,1)
\quad\Longrightarrow\quad
\bigl[\phi(ab/x)\bigr]_{a,b>0}
\text{ 不是全尺度 PSD 核}.
}
\tag{2}
\]

## 2. 对 RH arithmetic bridge 的含义

这个 no-go 只排除“exact \(\zeta^{-1}\) periodization
\(\Longrightarrow\) 直接 PSD product Gram”这条捷径；它不排除：

* 只在有限 divisor 集上工作的非 PSD Kreĭn 分解；
* 保留 divisor-complement parity 的 signed reflection block；
* 一个对实际 Möbius 向量而非所有向量成立的算术不等式。

但任何声称对所有有限尺度、所有系数向量都成立的普通 Gram 化，
都被 (2) 排除。因而 note 239 的 exact collapse 若要推进 RH，
必须保留 \(\mu*\mu\) 的 signed 相位或引入真正的非局部 reflection
intertwiner，不能仅凭 \(P_{V_\phi}\ge0\) 把 product kernel 正化。
