> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 局部 Weil 算子的严格正性推进到 \(\frac12\log7\)

日期：2026-08-11。

本文把 note 028 的严格正性端点从 \(\frac12\log5\) 推进到下一 prime-power activation
端点

\[
a_7=\frac12\log7=0.972955074527656\ldots .
\]

## 1. 定理

\[
\boxed{
A_a^+>0,\qquad A_a^->0,
\qquad 0<a\le\frac12\log7.}
\tag{1}
\]

因此

\[
\boxed{
A_a>0\qquad
\left(0<a\le\frac12\log7\right).}
\tag{2}
\]

若局部 Weil 谱底存在首次退化尺度，则

\[
\boxed{
a_{\rm deg}>\frac12\log7.}
\tag{3}
\]

## 2. 端点 prime 算子的精确半区形式

在 \(2a=\log7\) 时，具有正测度 overlap 的非零 von Mangoldt 项恰为

\[
n=2,3,4,5.
\]

\(n=6\) 满足 \(\Lambda(6)=0\)，而 \(n=7\) 只在区间直径处零测度接触。令

\[
d_n=\log n,\qquad
\alpha_n=\frac{\Lambda(n)}{\sqrt n}.
\]

只有 \(d_2<a\)。因此在奇偶扇区 \(\sigma=\pm1\) 上，

\[
\boxed{
P^\sigma
=-\alpha_2(S_2+S_2^*)
-\sigma\left(
\alpha_2J_2+\alpha_3J_3+\alpha_4J_4+\alpha_5J_5
\right).}
\tag{4}
\]

这里

\[
S_2:\ [0,a-d_2]\longrightarrow[d_2,a],
\]

而 \(J_n f(x)=f(d_n-x)\) 分别作用于

\[
I_2=[0,d_2],\qquad
I_n=[d_n-a,a]\quad(n=3,4,5).
\tag{5}
\]

translation 在两个扇区均为负，reflection 的符号为 \(-\sigma\)。

## 3. 两步 Schur prime 范数界

写

\[
x=\alpha_2,\qquad y=\alpha_3,\qquad
z=\alpha_4,\qquad w=\alpha_5.
\]

对 prime graph 的点 \(t\)，令 \(D(t)\) 为所有 incident edges 的绝对权重和。对
\((P^\sigma)^2\) 再作一次 Schur test，得到

\[
D_2(t)=
\sum_{t\stackrel e\longrightarrow s}|c_e|D(s).
\]

由 (5) 的 support endpoints 及其在六个 edge maps 下的逆像，把 \((0,a)\) 精确分成
14 个开放 cells。每格的 active edges 与 image degrees 都固定；逐格计算得到

\[
\boxed{
\sup_tD_2(t)
=(x+y)(2x+y)
+z(x+y+z)
+w(x+y+z+w).}
\tag{6}
\]

因为 \(P^\sigma\) 自伴，

\[
\|P^\sigma\|^2=\|(P^\sigma)^2\|
\le\sup_tD_2(t).
\]

Arb 计算给

\[
\sup_tD_2(t)
=3.902036941486399\ldots,
\]

\[
\boxed{
\|P^\sigma\|
\le1.975357421199111\ldots<1.975358.}
\tag{7}
\]

永久验证器直接以 (6) 的 Arb 表达式开平方，不依赖硬编码浮点上界。
它用 \(\log2,\log3,\log5,\log7\) 的有理线性组合表示所有断点，符号去重后再以 Arb 严格认证
相邻次序和每格不等式，因此不使用空间网格。

## 4. Yukawa 下模型与无穷补空间

沿 note 028 的 Fourier--Yukawa 分解，保留前 \(N=400\) 个正 rank-one
Yukawa atoms、完整 prime 算子 (4) 及 signed polar atom，删除其余正尾，得到严格下模型
\(L^\sigma\preceq A_{a_7}^\sigma\)。

令 \(P_R\) 为前 \(R=128\) 个 Fourier modes，\(Q_R=I-P_R\)。digamma multiplier 的严格
单调性、(7) 及奇扇区 polar norm 给出

\[
Q_RL^\sigma Q_R\succeq\mu_\sigma Q_R,
\]

其中

\[
\boxed{
\mu_+>2.21094278821791,\qquad
\mu_->1.89296474152807.}
\tag{8}
\]

若 \(B^\sigma\) 表示完整非对角下模型，则

\[
C_\sigma C_\sigma^*
=P_R(B^\sigma)^2P_R-(P_RB^\sigma P_R)^2
=P_RB^\sigma Q_RB^\sigma P_R.
\tag{9}
\]

所以 Feshbach 下界为

\[
\mathcal S_\sigma
=P_RL^\sigma P_R-\mu_\sigma^{-1}C_\sigma C_\sigma^*.
\tag{10}
\]

全部矩阵元均由有限指数积分闭式计算，不使用数值求积。

## 5. 奇扇区直接证书

在 \(256\)-bit Arb 下，\(R=128,N=400\) 的 interval LDL 全部 pivots 严格为正，最小值满足

\[
\boxed{
\min{\rm pivot}(\mathcal S_-)
>4.89755191436855\times10^{-7}.}
\tag{11}
\]

因此 \(A^-_{a_7}>0\)。

## 6. 偶扇区四维近核证书

偶扇区的普通 LDL 因四维近核簇而数值不稳定。取四次 dyadic Householder 精确正交合同，把
\(\mathcal S_+\) 写成

\[
\begin{pmatrix}
A_4&X\\
X^*&C
\end{pmatrix}.
\tag{12}
\]

对 \(C-5\times10^{-7}I\) 使用 dyadic Cholesky。其 residual infinity norm 满足

\[
\|C-5\times10^{-7}I-LL^*\|_\infty
<1.85154324260\times10^{-14},
\]

故

\[
\boxed{
C\succeq
4.99999981484567\times10^{-7}I.}
\tag{13}
\]

随后使用 Arb 的 verified solve 形成真正的四维 Schur complement

\[
S_4=A_4-XC^{-1}X^*.
\tag{14}
\]

其四个 interval LDL pivots 分别严格包含于正数邻域：

\[
\begin{aligned}
p_1&>2.71021209049\times10^{-17},\\
p_2&>1.02820996088\times10^{-20},\\
p_3&>1.21289790461\times10^{-20},\\
p_4&>1.18693913354\times10^{-19}.
\end{aligned}
\tag{15}
\]

因此 \(S_4>0\)，结合 (13)--(14) 得 \(\mathcal S_+>0\)，从而

\[
A^+_{a_7}>0.
\]

这里不能用 \(\|X\|^2/\inf C\) 的标量扣除；该估计会丢失符号。verified solve 保留了
\(C^{-1}\) 的完整方向信息。

## 7. 复现

    uv run --with python-flint python \
      computations/verify_log7_prime_two_step_degree.py 256

    uv run --with python-flint --with numpy python \
      computations/verify_second_mixed_band_endpoint_log7.py 192 128 400 +

    uv run --with python-flint --with numpy python \
      computations/verify_second_mixed_band_endpoint_log7.py 256 128 400 -

第一条输出 BLOCK4_CERTIFIED；第二条输出 CERTIFIED -。

## 8. 结论边界

由零延拓形式恒等式和全谱域单调性，端点严格正性传播到所有 \(0<a\le a_7\)，得到 (1)--(3)。
本定理仍是有限尺度结果，不证明全尺度正性或 RH。它同时显示：随着 active prime graph 增长，
统一 scalar complement bound 仍可控制高频，但低频需要保留一个小而快速增长的近核块。
