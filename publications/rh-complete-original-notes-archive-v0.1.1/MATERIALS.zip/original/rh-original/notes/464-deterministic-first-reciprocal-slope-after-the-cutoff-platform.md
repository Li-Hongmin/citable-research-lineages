> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 截断平台之后的确定性 reciprocal 斜率

日期：2026-08-17。

note 463 把 residual 写成 $q$-层 Volterra 能量。本 note 利用不完全除数和的
最初一段结构，给出一个不依赖深层 Möbius 相关的更强下界。

## 1. 第一层不完全除数和是确定的

回忆

\[
\eta_A(j)=\sum_{\substack{a\mid j\\a>A}}\mu(j/a).
\]

若 $A<j\le 2A$，则 $j$ 的任何真因子 $a$ 都满足
$a\le j/2\le A$。因此唯一满足 $a>A$ 的因子是 $a=j$，从而

\[
\boxed{\eta_A(j)=1,\qquad A<j\le2A.}
\tag{1}
\]

结合 note 463 的差分恒等式，得到

\[
Z_q=Z_0-(H_q-H_A),
\qquad A\le q\le2A.
\tag{2}
\]

这段 $q$-层不是可任意抵消的 signed 相关；它由局部因子结构强制给出。

## 2. 精确的两段下界

设 $M=\lfloor N/d\rfloor$，并假设 $M\ge2A+1$。由 note 463 的分层能量，
丢弃 $q>2A$ 的平方项并代入 (2)，得到

\[
\boxed{
\begin{aligned}
\|\mathcal R_{d,A}\|_2^2\ge{}&
\left((A+1)^2-\frac1{d^2}\right)Z_0^2\\
&+\sum_{q=A+1}^{2A}(2q+1)\bigl[Z_0-(H_q-H_A)\bigr]^2.
\end{aligned}}
\tag{3}
\]

第一项是 note 462 的恒定平台；第二项是平台之后强制的 reciprocal 斜率。
式 (3) 是有限量的精确不等式，不使用正性假设或渐近估计。

## 3. 内部截断的渐近常数

在 $A\to\infty$ 且 $M/(A+1)\to\infty$ 的内部截断范围，note 461 给出
$Z_0=1+o(1)$。并且在 $A<q\le2A$ 上

\[
H_q-H_A=\log(q/A)+O(A^{-1})
\]

一致成立。因此 (3) 给出

\[
\frac{\|\mathcal R_{d,A}\|_2^2}{A^2}
\ge 1+2\int_1^2 x\bigl(1-\log x\bigr)^2\,dx+o(1).
\]

积分可显式化为

\[
\boxed{
\|\mathcal R_{d,A}\|_2^2
\ge\left(\frac{17}{2}+4(\log2)^2-12\log2+o(1)\right)A^2,
}
\tag{4}
\]

其中常数约为 $2.103\)。这里的第一项 $1$ 来自 $q\le A$ 的平台，第二项
来自 $A<q\le2A$ 的确定性斜率。

## 4. OMEN 核验与路线含义

OMEN 用整数 Möbius 递推精确核验了全部 $1\le A<j\le2A\le78$，式 (1)
全部成立；未使用浮点或抽样。

这进一步收紧了截断链路线的设计空间：只要 $A$ 是真正的内部截断，residual
不仅在平台上携带 reciprocal 边界常数，而且在下一段长度 $A$ 上携带固定的
harmonic 斜率。任何试图以正 Gram 尾支付 completion 的方案，必须显式处理这
一段确定项与后续 signed 除数层之间的交叉；不能把所有 $q>A$ 统一视为可抵消噪声。

这仍不是 RH 证明，也没有把渐近下界误读成全局 Möbius 能量定理。
