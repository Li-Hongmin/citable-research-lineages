> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一个最小九次正 detector 同时消去两个 collective residues

日期：2026-08-14。

依赖：
[note 126](126-the-endpoint-flat-rh-kernel-has-two-independent-collective-residues.md)、
[note 137](137-a-positive-degree-six-detector-removes-the-first-collective-residue.md)。

证据等级：精确九次 Faulhaber 恒等式、Bernstein 正证书、shifted
Euler--Faulhaber 最小次数论证与有理 Mellin 变换。

note 137 用最小六次正核删除了 \(s=-1\) residue。本文同时令
\(s=-1,-3\) residues 消失，仍保持全半轴逐项非负，并证明次数九最小。

## 1. 九次 detector

令

\[
\boxed{
V(u)=u^2(1-u)^5(20u^2-5u-1)}
\qquad(0<u<1),
\tag{1}
\]

并在区间外取零。展开为

\[
V(u)
=-u^2+35u^4-140u^5+245u^6-224u^7+105u^8-20u^9.
\tag{2}
\]

所以

\[
V(0+)=V(1-)=0,\qquad
\int_0^1V(u)\,du=0,
\tag{3}
\]

并且

\[
\boxed{v_1=v_3=0.}
\tag{4}
\]

直接积分得到

\[
\boxed{
K_V(s)=
\frac{1680(s-1)}
{(s+2)(s+4)(s+5)(s+6)(s+7)(s+8)(s+9)}.}
\tag{5}
\]

故 \(K_V\) 在 \(1/2<\Re s<1\) 零自由。

## 2. 精确 Faulhaber 核

定义

\[
P_V(y)=\sum_{c\le y}V(c/y).
\tag{6}
\]

写

\[
y=N+r,\qquad N=\lfloor y\rfloor\ge1,\qquad
0\le r<1,\qquad m=N-1.
\tag{7}
\]

前九个幂和精确给出

\[
\boxed{
P_V(N+r)
=\frac{N(N+1)}{6(N+r)^9}Q_N(r),}
\tag{8}
\]

其中

\[
\begin{aligned}
Q_N(r)=-\big[&
14N^2r^6-42N^2r^5+35N^2r^4-7N^2r^2-3N^2\\
&+2Nr^7+7Nr^6-7Nr^5-35Nr^4+35Nr^3
+7Nr^2-21Nr+3N\\
&+r^7+7r^5-35r^3+21r\big].
\end{aligned}
\tag{9}
\]

## 3. Bernstein 正证书

令

\[
\beta_{k,7}(r)=\binom7k r^k(1-r)^{7-k}.
\tag{10}
\]

则 (9) 具有精确 Bernstein 展开

\[
\boxed{
Q_N(r)=
\sum_{k=0}^7
\big(c_k^{(0)}+m c_k^{(1)}+m^2c_k^{(2)}\big)
\beta_{k,7}(r),}
\tag{11}
\]

其中

\[
c^{(0)}=(0,0,0,0,0,2,9,18),
\tag{12}
\]

\[
c^{(1)}
=\left(3,6,\frac{28}{3},12,12,\frac{32}{3},12,15\right),
\tag{13}
\]

\[
c^{(2)}
=\left(3,3,\frac{10}{3},4,4,\frac{10}{3},3,3\right).
\tag{14}
\]

所有 Bernstein basis functions 与所有系数均非负，且 \(m\ge0\)。因此

\[
\boxed{P_V(y)\ge0\qquad(y\ge1).}
\tag{15}
\]

除 \(y=1\) 外，(11) 还给出严格正性。

## 4. 第二层正 reciprocal-product RH 门

置

\[
U_V(x)=\sum_n\mu(n)V(n/x),
\tag{16}
\]

\[
T_V(x)=
\sum_{a,b\le\sqrt x}\mu(a)\mu(b)
P_V\!\left(\frac{x}{ab}\right).
\tag{17}
\]

由精确截断卷积，

\[
U_V(x)=2A_V(x)-T_V(x).
\tag{18}
\]

因 \(V(u)=O(u^2)\) 于零，

\[
A_V(x)=O(x^{-1/2}),
\tag{19}
\]

故

\[
\boxed{T_V(x)=-U_V(x)+O(x^{-1/2}).}
\tag{20}
\]

结合 (5) 与 Mellin detector 定理，

\[
\boxed{
\mathrm{RH}
\iff
\forall\varepsilon>0,\quad
T_V(x)\ll_\varepsilon x^{1/2+\varepsilon},}
\tag{21}
\]

并且点态门可等价替换为 dyadic \(L^2\) 门。

## 5. 同时删除 \(s=-1,-3\)

由 (2)，

\[
\operatorname*{Res}_{s=-1}K_V(s)=v_1=0,
\qquad
\operatorname*{Res}_{s=-3}K_V(s)=v_3=0.
\tag{22}
\]

负偶数极点被 zeta trivial zeros 消去。剩余 odd residues 为

\[
v_5\zeta(-5)=(-140)\left(-\frac1{252}\right)=\frac59,
\tag{23}
\]

\[
v_7\zeta(-7)=(-224)\left(\frac1{240}\right)=-\frac{14}{15},
\tag{24}
\]

\[
v_9\zeta(-9)=(-20)\left(-\frac1{132}\right)=\frac5{33}.
\tag{25}
\]

若

\[
S_k(z)=\sum_{a\le z}a^k\mu(a),\qquad z=\sqrt x,
\tag{26}
\]

则完整 collective 分解为

\[
\boxed{
T_V(x)
=\frac{5S_5(z)^2}{9x^5}
-\frac{14S_7(z)^2}{15x^7}
+\frac{5S_9(z)^2}{33x^9}
+T_V^{(0)}(x),}
\tag{27}
\]

其中 \(T_V^{(0)}\) 的所有周期系数均值为零。collective skeleton 因而从
note 126 的 \((S_1,S_3)\) 和 note 137 的 \((S_3,S_5)\) 继续移到
\((S_5,S_7,S_9)\)。

## 6. 次数九的最小性

设多项式 \(V\) 满足

\[
V(0)=V(1)=\int_0^1V=0,
\qquad
v_1=v_3=0,
\qquad
P_V(y)\ge0\quad(y\ge1).
\tag{28}
\]

对固定 \(0\le r<1\)，shifted Euler--Faulhaber 展开为

\[
P_V(N+r)=
\sum_{k\ge1}
\frac{
B_k(1-r)V^{(k-1)}(1)
-B_kV^{(k-1)}(0)}
{k!(N+r)^{k-1}},
\tag{29}
\]

其中 \(B_k(t)\) 为 Bernoulli polynomial，\(B_k=B_k(1)\)。

逐次考察 \(k=2,3,4,5\)。下端项分别由于

\[
V'(0)=v_1=0,\qquad
B_3=0,\qquad
V'''(0)=6v_3=0,\qquad
B_5=0
\tag{30}
\]

而消失。每个 \(B_k(1-r)\) 都非零且均值为零，因而在
\([0,1]\) 上变号。若相应上端 jet 非零，则 (29) 的首个非零项会对某些
固定 \(r\) 为负，与 (28) 矛盾。因此

\[
V'(1)=V''(1)=V'''(1)=V''''(1)=0.
\tag{31}
\]

结合 \(V(0)=V'(0)=0\)，得到

\[
\boxed{u^2(1-u)^5\mid V(u).}
\tag{32}
\]

若 \(\deg V\le7\)，条件 \(v_3=0\) 已迫使 \(V=0\)。若 \(\deg V=8\)，写

\[
V=u^2(1-u)^5(a+bu).
\tag{33}
\]

\(v_3=0\) 给出 \(b=5a\)，而零均值给出

\[
0=a\big[B(3,6)+5B(4,6)\big]
=\frac{a}{63}.
\tag{34}
\]

故 \(a=b=0\)。于是

\[
\boxed{
\deg V\le8,\quad
P_V\ge0,\quad
v_1=v_3=0
\Longrightarrow V=0.}
\tag{35}
\]

(1) 在次数九达到非零情形，所以次数九严格最小。

## 7. 边界

对每个固定奇数 \(k\)，平方根强度的 \(S_k\) 界仍与 RH 等价。
因此 (27) 没有证明 RH；它证明非负 reciprocal-product detector 可以逐层
删除前两个 RH-strength collective residues，而且给出这一层的精确最小次数。
下一问题是能否继续删除 \(s=-5\)，或是否存在最终阻止无限 residue 移位的正性障碍。
