> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Weil 形式的绝对值收缩失败：标准基态正性路线关闭

日期：2026-08-11。本文完成 M2-R2 的一个决定性否定判别：对任意 \(a>1/6\)，局部 Weil
闭形式不满足第一 Beurling--Deny 绝对值收缩不等式。因此不能借助 positivity-preserving semigroup
或标准 Perron--Frobenius 基态理论，直接断言最低本征函数可取非负。

## 1. 非对角规则核

Suzuki 的分布公式 (2.11) 写成

\[
-g''(t)
=-\frac12\operatorname{Pf}\frac1{|t|}
-(2A+1)\delta_0
-\sum_{n\ge2}\frac{\Lambda(n)}{\sqrt n}
\bigl(\delta_{\log n}+\delta_{-\log n}\bigr)
-r''(t).
\]

其余项分解为

\[
\begin{aligned}
r_0(t)&=-4\bigl(e^{t/2}+e^{-t/2}-2\bigr),\\
r_1''(t)&=\frac{e^{-|t|/2}}{1-e^{-2|t|}}-\frac1{2|t|}.
\end{aligned}
\]

因此离开 \(t=0\) 和 prime-power 位移 \(t=\pm\log n\) 后，\(-g''\) 的普通函数核为

\[
\begin{aligned}
h(t)
&=-\frac1{2|t|}-r''(t)\\
&=2\cosh\frac{|t|}{2}
-\frac{e^{-|t|/2}}{1-e^{-2|t|}}.
\end{aligned}
\]

这个核不是固定符号。特别地，

\[
h(1/3)>0.
\]

事实上，对 \(t>0\)，初等化简给出

\[
h(t)>0
\quad\Longleftrightarrow\quad
e^{3t}>e^t+1.
\]

令 \(t=1/3\)，所需不等式为 \(e>e^{1/3}+1\)，它成立。例如
\(e>8/3\)，而 \(e<27/8\) 蕴含 \(e^{1/3}<3/2\)，故右端小于 \(5/2<8/3\)。
由连续性，存在 \(\varepsilon_0>0\)，使 \(h(t)>0\) 在
\((1/3-\varepsilon_0,1/3+\varepsilon_0)\) 上成立。

## 2. 两个 bump 给出严格反例

固定 \(a>1/6\)。取足够小的 \(\varepsilon>0\)，并选择非零非负函数

\[
\phi,\psi\in C_c^\infty(-a,a)
\]

分别支撑在 \(-1/6\) 与 \(1/6\) 的 \(\varepsilon\)-邻域。可同时保证：

- 两个支撑不相交；
- 对 \(x\in\operatorname{supp}\psi\)、\(y\in\operatorname{supp}\phi\)，
  \(x-y\in(1/3-\varepsilon_0,1/3+\varepsilon_0)\)；
- 该差集不含任何 \(\log n\)，因为最小的正 prime-power 位移是
  \(\log2>1/3\)。

于是分布核在两个支撑的直积上就是严格正的普通函数 \(h(x-y)\)，从而

\[
q_a(\phi,\psi)
=\int\!\!\int h(x-y)\phi(y)\psi(x)\,dy\,dx>0.
\]

令 \(u=\phi-\psi\)。由于支撑不交，\(|u|=\phi+\psi\)。因此

\[
\begin{aligned}
q_a(|u|)-q_a(u)
&=q_a(\phi+\psi)-q_a(\phi-\psi)\\
&=4q_a(\phi,\psi)>0.
\end{aligned}
\]

故

\[
\boxed{\exists\,u\in C_c^\infty(-a,a;\mathbb R):
\quad q_a(|u|)>q_a(u)\qquad(a>1/6).}
\]

为使形式非负而添加常数 \(c\lVert u\rVert_2^2\) 不改变这个差，因为
\(\lVert |u|\rVert_2=\lVert u\rVert_2\)。所以该反例对任意下界平移后的闭形式仍成立。

## 3. 算子论后果

对实的下有界闭形式，第一 Beurling--Deny 判据

\[
q(|u|)\le q(u)
\]

是相应自伴半群保持正性的标准判据。上面的严格反例说明，对 \(a>1/6\)，

\[
\boxed{e^{-tA_a}\ \text{不是 positivity-preserving semigroup}.}
\]

因此以下推理链在本项目中不可用：

\[
\text{“最低本征值”}
\Longrightarrow
\text{“可取非负本征函数”}
\Longrightarrow
\text{“再验证 }L_\Delta\text{ 超解符号后套用 Hopf 引理”}.
\]

这里的结论是关闭一个证明机制，而不是证明每个 ground state 都变号。某个特定尺度的最低
本征空间仍可能偶然包含非负向量；若要使用 Hopf 引理，必须从首次退化、特殊算术结构或另一个
比较原理单独证明这一点，并另行验证 \(\mathcal E_L(v,\phi)\ge0\) 对所有非负试验函数成立。

## 4. 对 M2-R 的路线修正

M2-R0 已把零模态写成标准 \(L_\Delta\) 加有限平移和光滑积分扰动的弱方程。本文进一步说明，
光滑余项不能被当作无害的 positivity-preserving 低阶项：它与主核合并后产生正的非对角区间，
足以破坏绝对值收缩。

note 007 随后已证明特定零模态有界、连续并满足最优 logarithmic 阶上界。因此后续优先级缩为：

1. 若要得到边界下界，发展适用于变号解的 boundary coefficient，或从第一次退化额外导出单符号；
2. 标准非负 Hopf 引理只能作为条件性工具，不能作为无条件主桥。

## 5. 来源与新旧结论边界

承重公式来自 Masatoshi Suzuki, *Weil's quadratic form via the screw function*,
[arXiv:2606.09096](https://arxiv.org/abs/2606.09096)，公式 (2.2)、(2.11) 及 \(r=r_0+r_1\) 后的
\(r_1''\) 计算。

核 \(h\) 的化简、\(h(1/3)>0\) 及双 bump 的 Beurling--Deny 反例是本项目的新推论。它尚未判定
首次退化尺度是否大于 \(1/6\)，也未判定首次退化零模态本身的符号。
