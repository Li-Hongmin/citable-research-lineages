> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 前两个正弦模构成严格的 universal detector

日期：2026-08-13。

依赖：[note 081](081-every-offline-zero-is-visible-in-one-fixed-sine-mode.md)、
[note 083](083-two-sine-modes-reduce-universal-detection-to-compact-nonvanishing.md)、
[note 084](084-fixed-mode-gram-reduces-to-high-divisor-multiplicative-near-diagonal.md)。

证据等级：解析推导 + Arb 区间算术的计算机辅助定理。它严格闭合 detector 端；它不证明剩余
cutoff 均方，故不证明 RH。

状态更新：[note 087](087-two-sine-cutoff-mean-square-is-equivalent-to-rh.md) 进一步证明下述二模
均方条件与 RH 等价，而不只是充分。

## 1. 定理

令

\[
W_k(s):=\int_1^2\sin \pi k(t-1)t^{s-1}\,dt,
\qquad
c_k:=\frac{1-(-1)^k}{\pi k},
\tag{1}
\]

\[
C_k(s):=\frac{c_k}{(s-1)^2}-W_k'(s),
\qquad
D(s):=C_1(s)W_2(s)-C_2(s)W_1(s).
\tag{2}
\]

**定理 1（二正弦无零定理）。**

\[
\boxed{
D(s)\ne0,\qquad \frac12\le\Re s\le1,\quad s\ne1.
}
\tag{3}
\]

在 (s=1)，(D) 有一阶极点，而

\[
F(s):=(s-1)D(s)
\tag{4}
\]

延拓为整函数并满足 (F(1)\ne0)。

**推论 2（有限 detector RH 判据）。** 若对每个 \(\varepsilon>0\)，

\[
\boxed{
\sum_{Y<N\le2Y}
\left(|\mathcal R_{N,1}|^2+|\mathcal R_{N,2}|^2\right)
\ll_\varepsilon Y^{2+\varepsilon},
}
\tag{5}
\]

则 RH 成立。

## 2. 极点消去与整函数

因 (c_1=2/\pi,c_2=0)，

\[
D(s)=\frac{2W_2(s)}{\pi(s-1)^2}
 +W_1(s)W_2'(s)-W_1'(s)W_2(s).
\tag{6}
\]

又 (W_2(1)=0)，故

\[
\boxed{
F(s)=\frac2\pi\frac{W_2(s)}{s-1}
 +(s-1)(W_1W_2'-W_1'W_2)
}
\tag{7}
\]

为整函数。为避免 (s=1) 的数值消去，证书使用精确恒等式

\[
\frac{W_2(s)}{s-1}
=\int_1^2\sin 2\pi(t-1)\log t\,
{}_1F_1\!\left(1;2;(s-1)\log t\right)dt.
\tag{8}
\]

特别地，Arb 给出

\[
F(1)\in
[-0.068564364937547814254035991452354\pm2.21\times10^{-34}].
\tag{9}
\]

## 3. 高频严格排零

置 (x=\log t)、(L=\log2)、(f_k(x)=\sin(\pi k(e^x-1)))。对

\[
W_k(s)=\int_0^L f_k(x)e^{sx}dx
\tag{10}
\]

作 (14) 次端点分部积分。(W_k,W_k') 保留 (s^{-2},\ldots,s^{-15})；第 (15) 阶
导数控制积分余项，((s-1)^{-2}) 的几何余项从 (s^{-16}) 起。行列式主项为

\[
d_4(2^s)s^{-4},
\qquad
d_4(E)=4-8(1+\pi^2L)E.
\tag{11}
\]

在

\[
\frac12\le\Re s\le1,\qquad |\Im s|\ge28
\tag{12}
\]

上，(sqrt2\le|2^s|\le2)。脚本把机器生成的 (s^{-4}) 系数与 (11) 的全部 Arb
差值也计入修正项，严格得到

\[
\begin{aligned}
L_0&>84.7117891948316,\\
E_{\rm finite}&<47.6504153405310,\\
E_{\rm rem}&<34.8070880291462,\\
L_0-E_{\rm finite}-E_{\rm rem}&>2.2542858251545>0.
\end{aligned}
\tag{13}
\]

故 (3) 在高频成立。

## 4. 紧矩形严格排零

取

\[
\Omega=\left\{s:\frac12\le\Re s\le1, |\Im s|\le28\right\}.
\tag{14}
\]

边界按精确有理端点自适应分成 (1812) 段。对每个完整线段 (I)，参数球积分产生包含
(F(I)) 的凸复矩形 (B_I)，并逐段验证

\[
0\notin B_I.
\tag{15}
\]

凸性与 (15) 保证该段存在跨度 (<\pi) 的连续辐角支，故端点主辐角增量等于真实增量。
区间求和给出

\[
\frac1{2\pi}\Delta_{\partial\Omega}\arg F
\in[-6.85\times10^{-27},6.85\times10^{-27}].
\tag{16}
\]

绕数是整数，故为 (0)。(F) 整且边界无零；辐角原理推出

\[
N_\Omega(F)=0.
\tag{17}
\]

(12)、(17)、共轭对称与 (9) 合并即证定理 1。

## 5. 可复现证书

主证书：

- [`certify_two_sine_detector_recurrence.sage.py`](../scratch/certify_two_sine_detector_recurrence.sage.py)
- [`certify_two_sine_detector_recurrence.log`](../scratch/certify_two_sine_detector_recurrence.log)

运行：

```bash
.venv-math/bin/python -B scratch/certify_two_sine_detector_recurrence.sage.py \
  --output scratch/certify_two_sine_detector_recurrence.log
```

当前哈希：

\[
\begin{array}{ll}
\text{source SHA256}&=
\mathtt{f065893cfb36f66f7995258ca6d97c85bc4acf95d0ee802695e241808080b814},\\
\text{log SHA256}&=
\mathtt{84b2b5e401c8d21b4faef63eb1e82f620f850b74ab39ef690407486b1b158300}.
\end{array}
\tag{18}
\]

独立实现 [`certify_two_sine_detector_arb.py`](../scratch/certify_two_sine_detector_arb.py) 使用不同分割：
(|\Im s|\le20) 的二维 direct cover、至 (64) 的边界辐角原理、以及
(|s|\ge64) 的独立 IBP 余项。它同样返回零绕数与正高频余量；此实现是交叉检查，不替代
上述可归档主证书。

可信计算基：python-flint 0.9.0、Arb/FLINT 的外向舍入、`acb.integral` 与
`hypgeom_1f1`。任何非有限球、含零球、分割失败或非零/不确定绕数均 fail closed。

## 6. 推论 2 的证明

设 (\rho) 是 (1/2<\Re\rho<1) 内的任意 (q) 重零点。note 083 已证明：

\[
D(\rho)\ne0
\Longrightarrow
\widehat{\mathscr R}_1\text{ 或 }\widehat{\mathscr R}_2
\text{ 在 }\rho\text{ 有极点}.
\tag{19}
\]

定理 1 保证左式。note 081 的 dyadic Mellin-pole 引理于是给某个 (k\in\{1,2\}) 与
dyadic 子列

\[
\sum_{Y<N\le2Y}|\mathcal R_{N,k}|^2
\gg_\rho Y^{2\Re\rho+1}(\log Y)^{2m_\rho-2}.
\tag{20}
\]

取 (0<\varepsilon<2\Re\rho-1)，则 (20) 与 (5) 矛盾。功能方程排除左半边离线零，故 RH。

## 7. 历史位置与剩余最简单元

截至 2026-08-13 的 `paper-lib` 检索中，Pólya 的变换零点理论、Schoenberg 的
Pólya-frequency/全正性、Wiener 的共同 Fourier 零点 Tauberian 思想及
Delsarte--Lions 的有限半径探测只提供结构先例；尚未找到直接陈述或推出 (3) 的历史定理。
因此本结论标作“项目内新定理”；正式新颖性仍需投稿级全面检索。

解析端现已闭合：

```mermaid
flowchart LR
  Z["ζ(ρ)=0, Reρ>1/2"] --> D["D(ρ)≠0"]
  D --> K["k=1 or 2 has Mellin pole"]
  K --> M["supercritical dyadic mass"]
  A["two arithmetic mean-square bounds"] --> X{"contradiction"}
  M --> X
  X --> RH((RH))
```

唯一剩余前提是 (5)。note 084 给出两个不可拼接、但各自充分的算术坐标。对 \(k=1,2\)，
可任选其一：

\[
\boxed{
\begin{array}{ll}
(A)&\displaystyle
\sum_{N\asymp Y}|H_{N,k}^{>Y^{3/4}}|^2
\ll_\varepsilon Y^{2+\varepsilon};\\[2mm]
(B)&\displaystyle
|\mathcal O_k(Y)|\ll_\varepsilon Y^{2+\varepsilon}.
\end{array}}
\tag{21}
\]

(A) 是 divisor--\(\Delta\) 坐标，模态在 high-divisor 块中分叉：

\[
S_{N,2}=0,\qquad
S_{N,1}=\cot\frac{\pi}{2N}\asymp N.
\tag{22}
\]

故 \(k=2\) 是纯短-cofactor 乘法和；\(k=1\) 仍含
\(B_{N,>D}S_{N,1}\) 与局部 divisor 和的联合抵消。(B) 是 product 坐标：
\(\mathcal O_k\) 必须保留完整 \(g_N=B_N-\Lambda-\mu\log(n/N)\)，不能再施加
\(d,e>Y^{3/4}\) 的共同支撑。

因此旧的“两个模都只剩同一个高除数乘法近对角”描述已撤回。普通大筛、双大筛及分开估计
\(\Lambda\) 与 \(\mu\) 对两个正确原子仍不足一幂。
