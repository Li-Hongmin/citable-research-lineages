> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius 分布与频率反射的精确 reciprocal-Hankel 因子化

日期：2026-08-16。

本 note 给出一个有限截断下完全精确的算术--频率因子化。它把
reciprocal-product Hankel 核中的两个不可替代部件分开：

* \(C_\mu\)：保留 \(1/\zeta\) 的 arithmetic distribution；
* \(R\)：把 ratio/Toeplitz 核变成 product/Hankel 核的频率反射。

因此，真正的非正则 arithmetic intertwiner 必须同时处理这两个部件；仅把
\(C_\mu\) 换成正 Gram，或仅把 \(R\) 丢掉，都会改变原 RH 门。

## 1. 有限 Mellin 采样算子

令 \(h\in L^1(\mathbb R)\) 为实偶函数，定义
\[
 P(y)=\frac1{2\pi}\int_{\mathbb R}h(\xi)y^{i\xi}\,d\xi
 \qquad (y>0).
\]
对 \(N\ge1\)，令
\[
 (\mathcal F_Nx)(\xi)=\sum_{n\le N}x_n n^{i\xi},
 \qquad
 (Rf)(\xi)=f(-\xi).
\]
在 \(L^2(\mathbb R,d\xi/(2\pi))\) 配对
\(\langle f,g\rangle=(2\pi)^{-1}\int f(\xi)\overline{g(\xi)}\,d\xi\)
下，直接计算得到
\[
 \boxed{
 \bigl(\mathcal F_N^*M_hR\mathcal F_N\bigr)_{a,b}
 =\frac1{2\pi}\int h(\xi)(ab)^{i\xi}\,d\xi
 =P(ab).
 }
\tag{1}
\]
没有 \(R\) 时则是 ratio/Toeplitz 核：
\[
 \boxed{
 \bigl(\mathcal F_N^*M_h\mathcal F_N\bigr)_{a,b}
 =P(a/b).
 }
\tag{2}
\]
所以 \(R\) 不是记号选择，而是 \(a/b\to ab\) 的唯一频率反射步骤。

## 2. \(C_\mu\) 精确产生有限 Möbius 向量

令 \(C_\mu^{(N)}\) 为截断 Dirichlet 卷积矩阵
\[
 (C_\mu^{(N)}x)(a)
 =\sum_{d\mid a}\mu(a/d)x(d),\qquad a\le N.
\]
因 \(1\mid a\)，有
\[
 C_\mu^{(N)}e_1=(\mu(1),\ldots,\mu(N))^T=:\mu_N.
\tag{3}
\]
于是将 (1) 夹在 \(C_\mu^{(N)}e_1\) 上，得到原始 reciprocal-product
二次型的精确表示：
\[
 \boxed{
 \mu_N^T H_N\mu_N
 =e_1^*(C_\mu^{(N)})^*
 \mathcal F_N^*M_hR\mathcal F_N
 C_\mu^{(N)}e_1
 =\frac1{2\pi}\int_{\mathbb R}h(\xi)F_N(\xi)^2\,d\xi,
 }
\tag{4}
\]
其中
\[
 F_N(\xi)=\sum_{n\le N}\mu(n)n^{i\xi},
\qquad
 (H_N)_{a,b}=P(ab).
\]
最后一个等式使用了 \(F_N(-\xi)=\overline{F_N(\xi)}\)，因而
\(\overline{(RF_N)(\xi)}=F_N(\xi)\)。

同样，若去掉反射并把 \(h\) 换成 \(|h|\ge0\)，则
\[
 \boxed{
 e_1^*(C_\mu^{(N)})^*\mathcal F_N^*M_{|h|}
 \mathcal F_NC_\mu^{(N)}e_1
 =\frac1{2\pi}\int_{\mathbb R}|h(\xi)|\,|F_N(\xi)|^2\,d\xi.
 }
\tag{5}
\]
这正是当前正能量门；由 notes 212、246，它的 \(N^{1+\varepsilon}\)
上界与 RH 等价。

## 3. 精确的二择一

式 (4)--(5) 给出一个不依赖数值实验的结构性分叉：

1. 保留 \(R\)：得到原始 \(ab\)-Hankel signed square，但
   \(M_hR\) 一般不正；
2. 去掉 \(R\) 并取 \(|h|\)：得到正的 ratio/Toeplitz energy，但
   \(N^{1+\varepsilon}\) 界已经是 RH-equivalent；
3. 修改 \(R\) 为某个跨频率算子 \(J\)，同时保持 (4) 的原始矩阵与
   (5) 的正性：这正是尚未构造的 arithmetic intertwiner。

若 \(h\) 变号，任何逐频率替换 \(R\mapsto \operatorname{sgn}(h)R\)
都会产生 note 331 的 \(1/u\) 型无限程 log-kernel；它不是有限 rank
Schur 补。若只使用 \(C_\mu^*M C_\mu\) 而不实现反射，则自动回到
ratio/Toeplitz 门，失去原 reciprocal-product 结构。

## 4. 对 RH 路线的最小目标

一个真正有内容的下一步不应再寻找普通平滑 \(W(d/a)\)，而应构造有限截断
的算术算子 \(J_N\)，使得
\[
 \mathcal F_N^*M_hJ_N\mathcal F_N
 =\mathcal F_N^*M_hR\mathcal F_N
 \quad\text{在 Möbius mode }C_\mu^{(N)}e_1\text{ 上成立},
\tag{6}
\]
同时 \(J_N\) 的正部分具有可控范数，并且其误差在 \(N\to\infty\) 时
不重新支付整个 \(|h|\,|F_N|^2\) 能量。

式 (6) 是一个明确的 signed arithmetic intertwiner 命题；它比“寻找正
periodization”更接近 RH，但本文不声称该 \(J_N\) 已构造。
