> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A negative frequency band forbids fixed-rank Feshbach repair

## 乘法算子的严格惯性引理

设 \(h\in L^\infty(\mathbb R;\mathbb R)\)，并存在可测集合
\(E\subset\mathbb R\) 与 \(\eta>0\)，使得

\[
h(\xi)\le-\eta\qquad(\xi\in E),\qquad |E|>0.
\]

令 \(M_h\) 是 \(L^2(\mathbb R)\) 上的乘法算子。对任意有限秩
self-adjoint 算子 \(F\)，\(M_h+F\) 仍有无限维负子空间，因而不可能
positive semidefinite。

证明很直接：取 \(E\) 内任意 \(N\) 个正交归一函数，所得 \(N\) 维空间
\(S_N\) 满足

\[
\langle f,M_hf\rangle\le-\eta\|f\|^2
\qquad(f\in S_N).
\]

若 \(\operatorname{rank}F=r\)，则
\(\dim(S_N\cap\ker F)\ge N-r\)。在这个交空间上
\(\langle f,(M_h+F)f\rangle=\langle f,M_hf\rangle<0\)。
令 \(N\to\infty\) 即得无限负惯性。

## 对 boundary Weil symbol 的应用

对单侧 detector 的偶 boundary kernel，Fourier symbol 为

\[
\widehat g_m(\xi)=\operatorname{Re}\!\left[\zeta(i\xi)K_m(i\xi)\right].
\]

note 174 已对 V15 严格验证 \(\widehat g_{15}(2)<0\)，由连续性可取一个
包含 \(\xi=2\) 的正测度区间 \(E\) 与 \(\eta>0\)，使上面的条件成立。
因此相应的连续 boundary multiplier 不能通过固定数量的 Yukawa atom、
固定 rank 的 Feshbach complement 或任何其他有限秩 self-adjoint 修补变成
全局 PSD。

## 算术边界

这个连续结论本身不等于 arithmetic divisor 子空间上的无穷负惯性：固定 \(X\)
的 divisor 空间仍是有限维。它严格说明的是：若 A 线要把 boundary multiplier
统一映到所有尺度 \(X\)，修补秩必须随可见频率/尺度增长，或者必须保留
Möbius 的 signed parity 与非对角 cross block；固定 rank 的 local positivity
不能完成这一步。

因此，当前最小可检验桥不再是“再找一个 scalar complement”，而是：

\[
\text{构造随 }X\text{ 增长且保持 }R_X\text{-parity 的 signed intertwiner}.
\]

本 note 是有限秩 no-go，不是 RH 证明。

