> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 指数外函数模型的 Möbius 尾核：无条件与 RH 条件估计

日期：2026-08-16。

note 341 的模型外函数密度取
\[
o(\xi)=e^{-\xi}{\bf 1}_{\xi\ge 0}.
\]
其对偶核满足
\[
\mathcal K_{N,o}(\eta)=\frac{e^\eta}{2\pi}
\sum_{e^\eta<n\le N}\frac{\mu(n)}n,
\qquad
4\pi^2\|\mathcal K_{N,o}\|_2^2
=\sum_{k=1}^{N-1}\left(k+\frac12\right)|A_N-A_k|^2,
\tag{1}
\]
其中
\[
A_x:=\sum_{n\le x}\frac{\mu(n)}n.
\]
本 note 给出 (1) 的两个严格尺度估计。

## 1. 一个由零自由区给出的无条件上界

记
\[
L(x)=(\log x)^{3/5}(\log\log x)^{-1/5}.
\]
经典零自由区与 Perron--Abel 估计给出某个 \(c>0\) 使
\[
M(x):=\sum_{n\le x}\mu(n)\ll x e^{-cL(x)}.
\tag{2}
\]
由素数定理 \(A_x\to0\)，部分求和给出精确式
\[
A_x=\frac{M(x)}x-\int_x^\infty\frac{M(t)}{t^2}\,dt.
\tag{3}
\]
将 (2) 代入 (3)，并令 \(u=\log t\)，可得：对任意
\(0<c_1<c\)，存在常数 \(C_{c_1}\) 使
\[
|A_x|\le C_{c_1}e^{-c_1L(x)}\qquad(x\ge3).
\tag{4}
\]
这里仅使用 \(L'(e^u)\asymp u^{-2/5}(\log u)^{-1/5}\)；该导数产生的多项式
因子可吸收到指数常数从 \(c\) 降至任意 \(c_1<c\)。

将 (4) 代入 (1)。对 \(k\le\sqrt N\) 使用平凡估计
\(|A_k|\ll\log(2k)\)，得到贡献 \(O(N\log^2 N)\)。对
\(\sqrt N<k<N\)，有 \(L(k)\ge c_2L(N)\)（某个固定 \(c_2>0\)，当
\(N\) 足够大），故
\[
\sum_{k>\sqrt N}k|A_N-A_k|^2
\ll N^2e^{-c_3L(N)}.
\]
由于 \(L(N)=o(\log N)\)，前一项可吸收到同一个 stretched-log 项中。因此
对某个 \(c_4>0\)，有
\[
\boxed{\|\mathcal K_{N,o}\|_2
\ll N e^{-c_4L(N)}.}
\tag{5}
\]
这是无条件的，但仍为 \(N^{1-o(1)}\)，不能支付平方根级局部反射缺口。

## 2. RH 下的平方根上界

若假设 RH，则经典 Mertens 等价性给出，对任意 \(\varepsilon>0\)，
\[
M(x)\ll_\varepsilon x^{1/2+\varepsilon}.
\]
将其代入 (3) 得
\[
|A_x|\ll_\varepsilon x^{-1/2+\varepsilon}.
\tag{6}
\]
于是 (1) 中 \(k>\sqrt N\) 的部分为 \(O_\varepsilon(N^{1+2\varepsilon})\)，
而 \(k\le\sqrt N\) 的平凡部分为 \(O(N\log^2N)\)。故
\[
\boxed{\mathrm{RH}\Longrightarrow
\|\mathcal K_{N,o}\|_2\ll_\varepsilon N^{1/2+\varepsilon}.}
\tag{7}
\]

## 3. 逻辑边界

(5) 只是一条无条件的零自由区基线；(7) 是 RH 条件估计。与先前容易混淆
的“中心化”说法相反，模型 Laplace 变换在零频取
\(M(N)-A_N\)，而 \(A_N\to0\)。因此若 (7) 作为对所有截断 \(N\) 的统一
估计成立，最大点 Abel 引理可直接推出
\(M(X)\ll_\varepsilon X^{1/2+\varepsilon}\)；这一双向关系在 note 345
中逐常数写出。本模型因而是一个真正的 RH-equivalent 对偶门，而不是
只对 \(A_N\) 的平移不变范数。

因此，最薄而准确的结论是：外函数对偶没有消除算术难题，而是把它压缩为
一个带明确权的尾和二次范数；经典零自由区只能给 (5)，平方根估计仍是
RH-strength 的新输入。
