> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 422. \(P(z)=1-qz\) 的 q-进制链重构被删零模

> **更正（见 note 425）**：本 note 的有限链恒等式和 Cauchy 下界有效；末节把
> (E_{q,X}\ll X^{1+\varepsilon}) 推成 RH 的结论不成立，因为此处
> (A_X=\sum_{n\le X}\mu(n)/n)。

## 1. 有限截断尾

令 \(q\ge2\)，
\[
 b_{q,X}(m)=\mathbf1_{m\le X}\mu(m)-q\,\mathbf1_{q\mid m}\mathbf1_{m/q\le X}\mu(m/q),
 \qquad 1\le m\le qX,
\]
并定义
\[
 B_X(k)=\sum_{k\le n\le X}\frac{\mu(n)}n,\qquad
 T_{q,X}(k)=\sum_{m\ge k}\frac{b_{q,X}(m)}m .
\]
有限交换给出精确式
\[
 T_{q,X}(k)=B_X(k)-B_X(k/q),
 \tag{1}
\]
其中 \(B_X(y)\) 采用 \(\lceil y\rceil\) 约定，并令 \(B_X(y)=0\) 对 \(y>X\)。

## 2. q-进制链

令 \(J\) 满足 \(q^{J-1}\le X<q^J\)。于是 \(q^J\le qX\)，且
\(B_X(q^J)=0\)。在幂次点上，(1) 给出
\[
 T_{q,X}(q^j)=B_X(q^j)-B_X(q^{j-1}),
 \qquad 1\le j\le J.
\]
沿链求和得到
\[
 \boxed{
 A_X:=\sum_{n\le X}\frac{\mu(n)}n=B_X(1)
 =-\sum_{j=1}^{J}T_{q,X}(q^j).
 }
 \tag{2}
\]
这正是 \(P(q^{-1})=1-q\cdot q^{-1}=0\) 时被删除的 \(k=1\) 模态，
由边界链重新恢复的方式。

## 3. 能量下界

定义
\[
 E_{q,X}:=\sum_{k\le qX}(2k-1)|T_{q,X}(k)|^2.
\]
由 Cauchy--Schwarz 和 (2)，
\[
 |A_X|^2
 \le
 \left(\sum_{j=1}^{J}\frac1{2q^j-1}\right)
 \left(\sum_{j=1}^{J}(2q^j-1)|T_{q,X}(q^j)|^2\right).
\]
因此
\[
 \boxed{
 E_{q,X}\ge c_q^{-1}|A_X|^2,
 \qquad
 c_q:=\sum_{j\ge1}\frac1{2q^j-1}<\infty .
 }
 \tag{3}
\]
例如 \(c_2<1\)。所以若某个固定 \(q\) 的删零模能量满足
\(E_{q,X}\ll_\varepsilon X^{1+\varepsilon}\)，则
\(A_X\ll_{q,\varepsilon}X^{1/2+\varepsilon/2}\)，不能由 Abel 变换推出 RH。
正确的固定-\(q\) 接口是：因为 \(P(q^{-1})=0\)，对 \(k\le X\) 有
\(T_{q,X}(k)=T_{q,\infty}(k)\)。所以有限能量界直接给无限尾的部分能量界，
再用 note 420 的 Mellin 延拓（\(P(q^{-s})\) 的零点在 \(\Re s=1\)，而 ζ 在该线无零点）推出 RH。

## 4. 对边界分支的裁决

式 (3) 是有限截断的直接不等式，不依赖无限尾、外函数或 moving-kink
极限。因此 \(P(z)=1-qz\) 虽然删掉了 \(k=1\) 的常数尾观测，但 q-进制
边界链仍以有界 Poincare 常数重构同一个 reciprocal Mertens 量。

结论是：对最小的一阶零模滤波器，边界带并非 RH 逃逸口；**若**其自然
\(X^{1+\varepsilon}\) 能量界成立，则由固定滤波器的无限尾 Mellin 延拓严格
推出 RH。这里的能量上界本身仍是待证明的算术输入，不是本 note 已得到的结果。
更高阶 \((1-qz)^r\) 仍需处理 \(r\) 阶边界链；固定阶可沿同一内部抵消接口，变化阶数则未闭合。
