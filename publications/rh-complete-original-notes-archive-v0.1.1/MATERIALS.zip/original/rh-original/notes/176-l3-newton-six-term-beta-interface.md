> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(L=3\) Newton 层：六项 Beta 接口与首个 raw-cumulative 断点

日期：2026-08-15。

本 note 把固定 falling-factorial 层 \(L=3\) 写成可审计的六项
Beta 组合，并记录一个重要边界：前一层 \(L=2\) 的逐分量 Abel
前缀证明不能直接推广。有限有理扫描仍显示完整
\(\gamma_{m,h,3}\) 在 \(m\le60\) 内非负，但这不是全 \(m\) 定理。

## 1. 精确 raw 生成式

沿用
\[
D=3m+3,\qquad d=D-2,\qquad r_q=D-q-1,
\qquad a_s=\frac{\binom hs}{\binom ds},
\]
以及 note 156 的 \(K_q\) 与
\[
T_a(y)=y^{D-1}K(a/y),\qquad
K(z)=DW(z)-(z+1)W'(z)-W(z)/z .
\]

由
\[
A_{q+1}(x)=x+(2^{q+1}-2)x^2+
 (3^{q+1}-3\cdot2^{q+1}+3)x^3+
 (4^{q+1}-4\cdot3^{q+1}+6\cdot2^{q+1}-4)x^4+\cdots
\]
与 \(E_{r,h}\) 的卷积，\(L=3\) 的 raw cumulative 系数
\(\widetilde C_s=\sum_{j\le s}\widetilde J_j\) 满足
\[
\sum_{s\ge0}\widetilde C_sx^s
=\frac{
T_1(x+3)+2T_2(x+2)-5T_1(x+2)
+3T_3(x+1)-10T_2(x+1)+10T_1(x+1)}
{1-x}.
\tag{1}
\]

同一计算也给出 \(L=3\) 所需 Stirling 卷积的简化式：当 \(r,t\ge1\) 时，
\[
\mathcal F_{r,t}(4)
=2^{r+t}+3^r+3^t-5(2^r+2^t)+10,
\tag{1a}
\]
而 \(t=0\) 时
\[
\mathcal F_{r,0}(4)=4^r-4\cdot3^r+6\cdot2^r-4.
\tag{1b}
\]
因此每个 \(q,s\) 括号都能化为有限个指数项；困难确实只剩完整
\(q,s\) 和的 signed 重排，而不是高阶 Stirling 数本身。

等价地，令
\[
\Delta_q=3^{q+1}-5\cdot2^{q+1}+10,
\qquad
F_{\rm raw}(q,t)=3^t+(2^{q+1}-5)2^t+\Delta_q,
\]
则
\[
\widetilde J_s=
\sum_{q:r_q\ge s}K_q\binom{r_q}{s}
F_{\rm raw}(q,r_q-s).
\]
（该式使用 raw 延拓的端点值。）实际端点值与 raw 延拓的差为
\[
\delta_q=4^{q+1}-6\cdot3^{q+1}
 +10\cdot2^{q+1}-10,
\qquad
C_s-\widetilde C_s
=\sum_{q\ge D-1-s}K_q\delta_q .
\tag{2}
\]
与 \(L=2\) 不同，\(\delta_q\) 在低 \(q\) 段不具备同样简单的单调
Abel 正性，故端点项本身也需要单独处理。

## 2. 严格的首断点

直接用有理数计算 raw cumulative 系数，\(m=3\) 给出
\[
\widetilde C_1=8424,\qquad
\widetilde C_6=-23976,\qquad
\widetilde C_d=\widetilde C_{10}=-77157.
\]
因此不能把 \(L=2\) 的“每个 Beta 分量前缀非负”模板原样用于
\(L=3\)。这不是完整 \(\gamma\) 的反例：端点修正与 \(a_s\) 加权后，
\(m=3\) 的完整 \(\gamma_{m,h,3}\) 仍严格为正。

## 3. 有限有理证据边界

脚本 verify_l3_gamma_scan.py 直接调用 note 156 的精确 Stirling/Fraction
公式，逐个检查
\[
0\le h\le3m+1,\qquad L=3,\qquad 1\le m\le M .
\]
运行 \(M=60\) 时全部通过；\(m=1,2\) 全部为零，\(m=3\) 的最小值为
\(928/15\)，\(m\ge4\) 在扫描范围内均为正。这个结果只证明有限算术
核验，不能外推到任意 \(m\)。

因此当前严格最小缺口是：证明式 (1)--(2) 的六项 Beta 组合及其端点
修正具有全 \(m,h\) 的 Newton 系数正性，或找到一个不同于 \(L=2\)
的 manifest-positive 重排。即便所有 \(L\) 层最终闭合，Möbius
signed Hankel 的平方根级估计仍是独立的 RH-strength 算术门。
