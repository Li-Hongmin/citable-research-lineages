> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 420. 有限尺度 reciprocal 尾能量的 RH 等价判据

## 1. 无限尾与有限尺度滤波器

令 \(q\ge2\) 为整数，\(P(z)=\sum_{j=0}^{J}c_jz^j\) 为固定多项式。定义
\[
 b_P(m)=\sum_{\substack{0\le j\le J\\q^j\mid m}}
 c_j\,\mu(m/q^j),
 \qquad
 B(x)=\sum_{n\ge\lceil x\rceil}\frac{\mu(n)}n .
\]
PNT 给出 \(B(1)=0\)，并保证这些尾和按通常的极限解释。交换有限尺度和，
\[
 T_P(k):=\sum_{m\ge k}\frac{b_P(m)}m
 =\sum_{j=0}^{J}c_jq^{-j}B(k/q^j).
 \tag{1}
\]

## 2. 精确 Mellin 变换

对 \(\Re z>0\) 定义离散 Mellin 变换
\[
 \mathcal F_P(z)
 :=\sum_{k\ge1}T_P(k)\bigl(k^{-z}-(k-1)^{-z}\bigr),
 \qquad 0^{-z}:=0.
\]
由 \(\lceil k/q^j\rceil\le n\Longleftrightarrow k\le q^jn\)，有限交换求和得到
\[
\begin{aligned}
 \mathcal F_P(z)
 &=\sum_{j=0}^{J}c_jq^{-j}
 \sum_{n\ge1}\frac{\mu(n)}n(q^jn)^{-z}\\
 &=\boxed{\frac{P(q^{-(z+1)})}{\zeta(z+1)}}.
\end{aligned}
\tag{2}
\]
写 \(s=z+1\)，右端就是 \(P(q^{-s})/\zeta(s)\)。

## 3. 尾平方能量推出的零点排除

设
\[
 E_P(Y):=\sum_{k\le Y} k\,|T_P(k)|^2.
\]
若对每个 \(\varepsilon>0\)
\[
 E_P(Y)\ll_{P,\varepsilon}Y^{1+\varepsilon},
 \tag{3}
\]
则在 dyadic 块 \(Y<k\le2Y\) 上 Cauchy--Schwarz 给出
\[
 \sum_{Y<k\le2Y}|T_P(k)|\,|k^{-z}-(k-1)^{-z}|
 \ll_{P,z,\varepsilon}
 Y^{-\Re z-\frac12+\varepsilon/2}.
\tag{4}
\]
故 \(\mathcal F_P\) 全纯延拓到 \(\Re z>-1/2\)。如果
\[
 P(q^{-s})\ne0\qquad(1/2<\Re s<1),
\tag{5}
\]
那么任何非平凡 \(\zeta(\rho)=0\) 且 \(\Re\rho>1/2\) 都会使 (2) 在
\(z=\rho-1\) 处出现极点，和 (4) 矛盾。这里不要求在 \(s=1\)
非零：\(1/\zeta(s)\) 在 \(s=1\) 本身有一个零点，且该点不属于 RH
所需排除的非平凡零点条带。函数方程再排除左侧后得到 RH。

一个简单的系数条件保证 (5)：若 \(P\) 没有根落在开环带
\[
 q^{-1}<|\alpha|<q^{-1/2},
\tag{6}
\]
则 \(q^{-s}\) 不会命中任何根 \(\alpha\)（开环带恰对应
\(1/2<\Re s<1\)）。因此允许零模滤波器在 \(s=1\) 的根，例如
\(P(z)=(1-qz)^r\)；该根位于环带边界 \(|\alpha|=q^{-1}\)，不影响 RH 门。

## 4. 反向蕴含

在 RH 下，经典 Mertens 界给出
\[
 B(x)\ll_\varepsilon x^{-1/2+\varepsilon}.
\]
由 (1)，固定 \(P\) 时 \(T_P(k)\ll_{P,\varepsilon}k^{-1/2+\varepsilon}\)，从而
\[
 E_P(Y)\ll_{P,\varepsilon}Y^{1+\varepsilon}.
\tag{7}
\]
因此，在上述开条带条件 (5) 下，固定有限尺度 reciprocal 尾满足
\[
\boxed{
 \mathrm{RH}
 \quad\Longleftrightarrow\quad
 \forall\varepsilon>0,\ E_P(Y)\ll_{P,\varepsilon}Y^{1+\varepsilon}.
 }
\tag{8}
\]

## 5. 边界截断必须单独支付

实际 principal filter 使用的是 \(m\le X\) 的截断系数。其 reciprocal 尾为
\[
 T_{P,X}(k)=\sum_j c_jq^{-j}B_X(k/q^j),
\]
其中 \(B_X\) 在 \(x\approx X\) 处有 moving kink。式 (2)--(8) 直接适用于
无限尾；要从有限截断能量推出 (3)，必须另行控制这组边界带。
这正是有限滤波路线的最薄算术缺口，而不是可以省略的 \(O(1)\) 误差。

所以共同单位圆零点只提供一个明确的盲区候选；在没有边界控制之前，它
既不是 RH 证明，也不是一个已知的弱于 RH 的估计。
