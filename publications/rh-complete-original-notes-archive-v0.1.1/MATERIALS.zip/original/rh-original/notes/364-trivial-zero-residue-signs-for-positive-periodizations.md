> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 平凡零点强迫正 periodization 的偶端点残数符号

日期：2026-08-16。

本 note 给出 notes 363 的一个精确补充。端点阶数大于二会被
(s=-2) 的平凡零点排除；端点恰为二时，(K_V) 在 (s=-2) 留下的
极点正好抵消 (zeta(-2)=0)。同一机制在更高的可积平凡零点处强迫
所有偶端点系数交替变号。这是正 detector 的必要条件，不是 RH 证明。

## 定理（有限阶版本）

设 (V) 支持于 ([0,1])，在 (0) 的一侧有展开

\[
 V(u)=\sum_{n=2}^{L}v_nu^n+O(u^{L+1}),
 \qquad u\downarrow0,
\tag{1}
\]

并在 (1) 端足够光滑，使其 periodization

\[
 P_V(y)=\sum_{1\le c\le y}V(c/y)
\tag{2}
\]

满足 (P_V(y)=O(y^{-\delta}))；假设 (delta>2K)。再假设

\[
 P_V(y)\ge0\quad(y\ge1),
 \qquad P_V\not\equiv0.
\tag{3}
\]

若 (int_0^1V=0)，则对每个 (1\le k\le K)，均有

\[
 v_{2k}\ne0,
 \qquad
 \operatorname{sgn}(v_{2k})=(-1)^k.
\tag{4}
\]

更精确地，若

\[
 I_V(s):=\int_1^\infty P_V(y)y^{-s-1}\,dy,
\tag{5}
\]

则

\[
 I_V(-2k)=\int_1^\infty P_V(y)y^{2k-1}\,dy
 =\zeta'(-2k)v_{2k},
\tag{6}
\]

其中

\[
 \zeta'(-2k)=
 \frac{(-1)^k(2k)!}{2(2\pi)^{2k}}\zeta(2k+1).
\tag{7}
\]

因而还可反解

\[
 v_{2k}=
 \frac{2(-1)^k(2\pi)^{2k}}
 {(2k)!\,\zeta(2k+1)}
 \int_1^\infty P_V(y)y^{2k-1}\,dy.
\tag{8}
\]

## 证明

在 (operatorname{Re}s>1) 中逐项换元给出 Mellin 恒等式

\[
 I_V(s)=\zeta(s)K_V(s),
 \qquad
 K_V(s)=\int_0^1V(u)u^{s-1}\,du.
\tag{9}
\]

由 (1)，(K_V) 在 (s=-2k) 附近的主部为

\[
 K_V(s)=\frac{v_{2k}}{s+2k}+O(1).
\tag{10}
\]

右端 (5) 因 (delta>2k) 在 (s=-2k) 绝对收敛且连续；故由解析延拓，

\[
 I_V(-2k)=
 \lim_{s\to-2k}\zeta(s)K_V(s)
 =\zeta'(-2k)v_{2k}.
\tag{11}
\]

若 (v_{2k}=0)，则 (11) 给出 (I_V(-2k)=0)，与 (3) 及正权
(y^{2k-1}) 的积分严格为正矛盾。因此 (v_{2k}\ne0)。最后使用函数方程
在平凡零点处的导数公式 (7)，即得 (4) 和 (8)。

这里 (P_V\not\equiv0) 也可由 (V\not\equiv0) 推出：若 (P_V) 恒为零，
(9) 在 (operatorname{Re}s>1) 迫使 (K_Vequiv0)，从而 (V=0)（Mellin
唯一性）。

## 对当前 detectors 的核验

degree-15 detector 的 Bernstein--Faulhaber 形式为

\[
 P_{15}(N+r)=\frac{N(N+1)}{(N+r)^{15}}Q_N(r),
\]

且 (Q_N) 的 Bernstein 系数关于 (N-1) 的次数至多四。因此

\[
 P_{15}(y)=O(y^{-9}),
\]

可在定理中取 (K=4)。其偶端点系数为

\[
 (v_2,v_4,v_6,v_8)=(-3,78,-1001,15444),
\]

恰好具有 ((- ,+,-,+)) 的强制符号。

同理 degree-18 的 (Q_N) 关于 (N-2) 的次数至多五，故
(P_{18}(y)=O(y^{-11}))，可取 (K=5)，并得到

\[
 (v_2,v_4,v_6,v_8,v_{10})
 =\left(-\frac7{8151},\frac{200}{8151},-rac{196}{627},
 \frac{56}{19},-\frac{770}{19}\right).
\]

这说明现有正 detector 层级并非偶然满足端点符号：这些符号是平凡零点与
非负 periodization 共同强迫的。它也解释了为什么提高左端阶数会立即触发
notes 363 的 (s=-2) 矛盾：一旦 (v_2=0)，第一个可积的 (I_V(-2))
就被平凡零点置为零。

## 能推出什么、不能推出什么

该定理把 detector 设计空间从“任意零均值多项式”缩到一组由偶端点残数
交替符号约束的锥；它可用于快速排除候选或核验符号。它没有控制
(P_V) 在 (y\ge2) 的 Möbius signed quadratic form，也没有提供
(sum\mu(n)V(n/x)) 的平方根界。因此它是一个严格的结构性必要条件，
不是 RH 的新证明。
