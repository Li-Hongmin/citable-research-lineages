> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 423. 高阶 q-进制差分仍重构 reciprocal 零模

> **更正（见 note 425）**：高阶 Newton 反演和 (C_{r,q}) 估计有效；但有限能量
> (E_{r,q,X}\ll X^{1+\varepsilon}) 只给 reciprocal 和的正半幂上界，不能据此推出 RH。

## 1. 高阶有限滤波器

令 \(q\ge2\)、\(r\ge1\)，取
\[
 P_r(z)=(1-qz)^r.
\]
有限截断系数为
\[
 b_{r,q,X}(m)=
 \sum_{\substack{0\le \ell\le r\\q^\ell\mid m\\m/q^\ell\le X}}
 (-1)^\ell\binom r\ell q^\ell\mu(m/q^\ell),
 \qquad m\le q^rX.
\]
其 reciprocal 尾满足
\[
 T_{r,q,X}(k)
 =\sum_{\ell=0}^{r}(-1)^\ell\binom r\ell B_X(k/q^\ell).
 \tag{1}
\]

## 2. q-进制差分反演

令 \(J\) 满足 \(q^{J-1}\le X<q^J\)，并设
\[
 f_j=B_X(q^j),\qquad
 f_j=A_X\ (j\le0),\qquad
 f_j=0\ (j\ge J).
\]
若 \(\Delta f_j=f_j-f_{j-1}\)，则
\[
 T_{r,q,X}(q^j)=\Delta^r f_j.
\]
有限支撑的离散 Newton 反演给出
\[
 \boxed{
 A_X=f_0=(-1)^r\sum_{j=1}^{J+r-1}
 \binom{j}{r-1}T_{r,q,X}(q^j).
 }
 \tag{2}
\]
证明是把 \(\Delta^r\) 的卷积核与
\(\binom{j}{r-1}\) 的累积核相卷积；右端对每个 \(f_\ell\) 的系数在
\(\ell\ne0\) 时望远镜消失，在 \(\ell=0\) 时等于 \(1\)。

## 3. 高阶能量下界

定义自然 reciprocal 能量
\[
 E_{r,q,X}
 =\sum_{k\le q^rX}(2k-1)|T_{r,q,X}(k)|^2.
\]
由 (2) 和 Cauchy--Schwarz，
\[
 |A_X|^2
 \le C_{r,q}\,E_{r,q,X},
 \qquad
 C_{r,q}:=
 \sum_{j\ge1}\frac{\binom{j}{r-1}^2}{2q^j-1}<\infty.
 \tag{3}
\]
因此对每个固定 \(r,q\)，若
\[
 E_{r,q,X}\ll_{r,q,\varepsilon}X^{1+\varepsilon},
\]
则 Cauchy 只给出 reciprocal 和的正半幂上界，不能直接经 Abel 变换推出 RH。
但 \(P_r(q^{-1})=0\) 使有限尾在 \(k\le X\) 与无限尾精确相等；故该能量界
转给无限尾后，再由 note 420 的 Mellin 延拓推出 RH。这里的逻辑不经过
\(A_X\) 的 Cauchy 上界。

## 4. 解释

\(P_r(q^{-1})=(1-1)^r=0\) 消除了 \(k=1\) 的直接尾观测，但 (2) 显示
高阶差分在完整 q-进制边界链上仍保留同一 reciprocal 零模。损失只进入
固定常数 \(C_{r,q}\)，而不是一个随 \(X\) 增长的幂次损失。

所以所有固定阶 \((1-qz)^r\) 正能量路线都已经被严格归约为一个 RH 等价的
能量估计：若该估计成立，则 RH；本 note 并未证明估计本身。若要继续寻找
逃逸，只能进入阶数随 \(X\) 增长、或同时改变尺度与边界归一化的 genuinely
growing filter；固定阶高阶差分本身不能绕开 RH 门。
