> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 统一 Yukawa 高频 coercivity 与无谱逃逸定理

日期：2026-08-11。

本文利用 Robin--Yukawa 算子的序结构，证明 note 033 所需的负方向 collective compactness，并
由此得到 Yukawa 单调下模型谱底的真实收敛。结论关闭了原 A3 frame 路线：在本项目的真实模型中，
frame 余量消失与完整局部 Weil 算子非负严格等价，不能作为更便宜的独立证明机制。

## 1. 公共参考算子

固定 \(a>0\) 和一个奇偶扇区 \(\sigma\)。在 \(L^2(0,a)\) 上令

\[
H_0^\sigma=-\partial_x^2,
\]

偶扇区在 \(x=0\) 取 Neumann 条件，奇扇区取 Dirichlet 条件，并在 \(x=a\) 取 Neumann 条件。
令 \(H_b^\sigma\) 只把 \(x=a\) 改为 Robin 条件

\[
u'(a)+2bu(a)=0.
\]

其闭形式比 \(H_0^\sigma\) 多出 \(2b|u(a)|^2\)，故

\[
H_b^\sigma\succeq H_0^\sigma.
\tag{1}
\]

定义

\[
h_b(t)=\frac{t}{b(4b^2+t)}
=\frac1b\left(1-\frac{4b^2}{4b^2+t}\right).
\]

\(h_b\) 是 operator-monotone increasing，因此第 \(n\) 个 Yukawa 算子满足

\[
Y_n^\sigma=h_{b_n}(H_{b_n}^\sigma)
\succeq h_{b_n}(H_0^\sigma),
\qquad b_n=n+\frac14.
\tag{2}
\]

## 2. 截断 Yukawa 项的公共 multiplier 下界

令

\[
\ell_{n,M}=h_{b_n}(\mu_{n,M}^2),
\qquad
L_{n,M}=\min(Y_n,\ell_{n,M}I)
\]

为 note 024 的 mode-\(M\) 下模型。对
\(0\le y,\ell\le b_n^{-1}\)，有

\[
\min(y,\ell)\ge b_n\ell y.
\]

结合 (2) 得

\[
\boxed{
L_{n,M}^\sigma
\succeq b_n\ell_{n,M}h_{b_n}(H_0^\sigma).}
\tag{3}
\]

所以

\[
\sum_{n\ge0}L_{n,M}^\sigma
\succeq G_M^\sigma(H_0^\sigma),
\]

其中

\[
G_M^\sigma(\lambda)
=\sum_{n\ge0}
\frac{\lambda\mu_{n,M}^2}
{b_n(4b_n^2+\lambda)(4b_n^2+\mu_{n,M}^2)}.
\tag{4}
\]

Robin 根区间给出 \(\mu_{n,M}\ge c_aM\)。若

\[
b_n\le c_a'\min\{M,\sqrt\lambda\},
\]

则 (4) 的第 \(n\) 项至少为 \(c_a''/b_n\)。对这些 \(n\) 求和，得到统一下界

\[
\boxed{
G_M^\sigma(\lambda)
\ge c_a\log\bigl(1+\min\{M,\sqrt\lambda\}\bigr).}
\tag{5}
\]

所有常数只依赖固定尺度 \(a\) 和扇区。

## 3. 负方向的 collective compactness

写

\[
B_M^\sigma=F_a^\sigma+\sum_nL_{n,M}^\sigma.
\]

固定尺度只有有限多个 active prime shifts；它们、常数项和极点秩一项均为有界算子。因此存在
\(C_a<\infty\) 使

\[
F_a^\sigma\succeq-C_aI.
\]

令

\[
P_R^\sigma={\bf1}_{[0,R^2]}(H_0^\sigma),
\qquad Q_R^\sigma=I-P_R^\sigma.
\]

由 (5)，对 \(M\ge R\ge2\)，

\[
\boxed{
q_{B_M^\sigma}[f]
\ge
\bigl(c_a\log(1+R)-C_a\bigr)\|Q_R^\sigma f\|^2
-C_a\|P_R^\sigma f\|^2.}
\tag{6}
\]

若 \(\|f\|=1\) 且 \(q_{B_M^\sigma}[f]\le0\)，则在增大固定常数后

\[
\|Q_R^\sigma f\|^2
\le\frac{C_a'}{\log(1+R)},
\qquad M\ge R.
\tag{7}
\]

由于每个 \(P_R^\sigma\) 有限秩，(7) 严格给出

\[
\boxed{
\lim_{R\to\infty}
\sup_{M\ge R}
\sup_{\substack{\|f\|=1\\q_{B_M^\sigma}[f]\le0}}
\|Q_R^\sigma f\|=0.}
\tag{8}
\]

这排除了 note 033 抽象反例中的高频逃逸。

## 4. 谱底无污染

记

\[
\lambda_M=\inf\sigma(B_M^\sigma),
\qquad
\lambda=\inf\sigma(A_a^\sigma).
\]

note 024 给出 \(B_M^\sigma\uparrow A_a^\sigma\)，故

\[
\lambda_M\uparrow L\le\lambda.
\]

若 \(L<0\)，取归一化近极小向量 \(f_M\)，使
\(q_{B_M}[f_M]=\lambda_M+o(1)<0\)。由 (8)，\((f_M)\) 在 \(L^2\) 中相对紧；取强收敛
子列 \(f_M\to f\)，则 \(\|f\|=1\)。对任意固定 \(K\) 和所有充分大的 \(M\ge K\)，

\[
q_{B_K}[f_M]\le q_{B_M}[f_M].
\]

\(B_K\) 是有界算子，因此令 \(M\to\infty\) 得

\[
q_{B_K}[f]\le L.
\]

再令 \(K\to\infty\)，形式单调收敛给出

\[
q_A[f]\le L.
\]

由 \(\lambda\le q_A[f]\) 与 \(L\le\lambda\)，得到 \(L=\lambda\)。特别地，若
\(\lambda\ge0\) 而 \(\lambda_M\) 不趋于非负数，则同一论证产生 \(q_A[f]<0\) 的矛盾。因此

\[
\boxed{
(-\lambda_M)_+\longrightarrow(-\lambda)_+.}
\tag{9}
\]

在 \(\lambda<0\) 时还得到完整的 \(\lambda_M\uparrow\lambda\)；在本项目所需的非负判定上，(9)
已是精确结论。

## 5. A3 路线关闭

note 033 证明，若

\[
\widetilde S_M=E_M^{-1/2}B_ME_M^{-1/2},
\]

并令 \(\eta_M=(-\inf\sigma\widetilde S_M)_+\)，则

\[
(-\lambda_M)_+
\le\eta_M\|E_M\|
\le(1+o(1))(-\lambda_M)_+.
\]

结合 (9)，得到真实 Robin--Yukawa 模型中的等价式

\[
\boxed{
\eta_M\|E_M\|\to0
\iff
A_a^\sigma\succeq0.}
\tag{10}
\]

所以原“uniform Robin-frame theorem”不是独立于局部 Weil 正性的桥梁，而是同一命题的
normalized lower-model 表述。继续只估 frame 常数不能降低 RH 铰链的难度。

新的最小问题必须直接利用完整低频极限中的额外结构，例如首次退化方程、prime-orbit 延迟刚性、
不可见核排除，或一个可独立证明 \(A_a^\sigma\succeq0\) 的显式低频恒等式。
