> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 单素数扩张中的 prime-edge 导数与最小 rank-one 补偿

本 note 把 note 238 的 prime boundary 接口在 \(X=qp\) 上具体化。它给出一个可计算的局部补偿，但也显示全局求和仍需要跨素数 cancellation。

## 1. 半格上的导数只剩一个坐标

令 \(q\) 为固定 squarefree 整数，\(p>q\) 为不整除 \(q\) 的素数，\(X=qp\)，并令
\[
L_X=\{d\mid X:d<\sqrt X\}=D(q).
\]
令 \(c_X=(\mu(d))_{d\mid X}\)，并置
\[
v_X=D_0^{\prime\,T}c_X.
\]
由 note 238 的公式
\[
(v_X)(n)=-\mu(n)\sum_{r\mid X/n}\mu(r)\log r.
\]
若 \(n\mid q\)，则 \(X/n=(q/n)p\)。当 \(n=q\) 时，内和为 \(-\log p\)；当 \(q/n\) 仍含素因子时，内和为零。因此
\[
\boxed{P_{L_X}v_X=\mu(q)\log p\,e_q.}\tag{1}
\]
同时 \(c_X(q)=\mu(q)\)，所以
\[
\boxed{c_{L_X}^{\,T}P_{L_X}v_X=\log p.}\tag{2}
\]

## 2. 单个 Möbius mode 的精确补偿门

沿用 half-lattice identity
\[
H_{qp}=Q_{qp}-2\mu(q)G_q,
\]
其中 \(Q_{qp}=O_{P,q}(p^{-2})\)，而 \(G_q\) 是固定核心的 ordinary boundary quadratic form。对 rank-one 修正
\[
F_{qp}=\alpha_{q,p}
(P_{L_X}v_X)(P_{L_X}v_X)^T
\]
有
\[
c_{L_X}^{\,T}F_{qp}c_{L_X}
=\alpha_{q,p}(\log p)^2.
\]
因此，在这个单一 Möbius mode 上，补偿 \(H_{qp}+F_{qp}\ge0\) 的充要标量条件是
\[
\boxed{
\alpha_{q,p}\ge
\frac{\bigl(2\mu(q)G_q-Q_{qp}\bigr)_+}{(\log p)^2}.
}\tag{3}
\]
这是真正可审计的 prime-edge Schur 门；它没有把 \(G_q\) 替换成绝对值，也没有假设完整算子 PSD。

## 3. 全局障碍

若 \(\mu(q)G_q>0\)，则 (3) 的右端渐近为
\[
\frac{2\mu(q)G_q}{(\log p)^2}.
\]
虽然单个 rank-one 修正的 mode 值是常数级，但其 trace/平方范数成本
\[
\alpha_{q,p}\|P_{L_X}v_X\|^2
\asymp 2\mu(q)G_q
\]
并不随 \(p\) 衰减。因而对所有 \(p\) 逐层相加会产生线性数量级的成本；要达到平方根级，必须利用不同 prime layers 之间的 signed cross cancellation，不能逐层 Schur 化。

这把 note 238 的半格缺口进一步缩成一个明确问题：构造同时耦合多个 \(p\)-edge 的非对角 intertwiner，使其在 Möbius mode 上支付 (3) 的缺口，而整体 trace/energy 仍低于 \(x^{1/2+\varepsilon}\)。
