> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 截断倍数链 residual 的精确 Volterra 能量恒等式

日期：2026-08-17。

本 note 把 notes 458--462 中的逐行 residual 进一步压成一个有限维的
Volterra Gram 二次型。它不提供 RH 证明，但把平台常数与 $q>0$ 的 signed
变化放进同一个精确恒等式，因而明确了截断链路线还缺什么算术输入。

## 1. $q$-层的精确差分

令

\[
M=\left\lfloor\frac Nd\right\rfloor,
\qquad
B=\left\lfloor\frac{M}{A+1}\right\rfloor,
\qquad
Z_q=\sum_{b\le B}\frac{\mu(b)}b
 \left(H_{\lfloor M/b\rfloor}-H_{\max(A,\lfloor q/b\rfloor)}\right),
\]

其中 $0\le q\le M$，并约定 $H_0=0$。当 $q=M$ 时 $Z_M=0$。定义

\[
\eta_A(j)=\sum_{\substack{a\mid j\\a>A}}\mu(j/a),
\qquad
u_j=\frac{\eta_A(j)}j.
\]

对 $1\le j\le M-1$，只有 $b\mid j$ 的项会在
$\lfloor(j-1)/b\rfloor$ 到 $\lfloor j/b\rfloor$ 之间改变，而且
$j/b>A$ 时自动有 $b\le B$。因此有严格差分恒等式

\[
\boxed{Z_{j-1}-Z_j=u_j.}
\tag{1}
\]

这正是 notes 458--459 中不完全 Möbius 除数和的离散导数，而不是估计式。

## 2. residual 能量的分层

由 note 462，若 $q=\lfloor k/d\rfloor\)，则 residual 的第 $k$ 行为

\[
(\mathcal R_{d,A})_k=\frac{\sqrt{2k+1}}d Z_q
\quad (q\le M-1),
\]

其中 $q=M$ 的最后部分行 residual 为零。把 $k$ 按 $q$ 分层：$q=0$ 的行是
$1\le k<d$，其权重为 $(d^2-1)/d^2$；对 $1\le q\le M-1$，完整块
$qd\le k<(q+1)d$ 的权重为 $2q+1$。所以得到精确恒等式

\[
\boxed{
\|\mathcal R_{d,A}\|_2^2
 =\left(1-\frac1{d^2}\right)Z_0^2
 +\sum_{q=1}^{M-1}(2q+1)Z_q^2.
}
\tag{2}
\]

## 3. Volterra/Gram 形式

由 (1)，$Z_q=Z_0-\sum_{j=1}^q u_j$。令

\[
W=M^2-\frac1{d^2},
\qquad
T_j=M^2-j^2,
\qquad
K_{ij}=M^2-\max(i,j)^2.
\]

对 (2) 展开并交换有限求和，得到

\[
\boxed{
\begin{aligned}
\|\mathcal R_{d,A}\|_2^2
={}&WZ_0^2-2Z_0\sum_{j=1}^{M-1}T_j u_j\\
&+\sum_{i,j=1}^{M-1}K_{ij}u_i u_j.
\end{aligned}}
\tag{3}
\]

最后一项是显式正半定 Volterra Gram：

\[
K_{ij}=\sum_{q=\max(i,j)}^{M-1}(2q+1)
 =\int_{\max(i,j)}^{M}2t\,dt.
\tag{4}
\]

因此 $K\succeq0$，但式 (3) 的决定性部分是 $Z_0$ 与 $u_j$ 的交叉项；
仅对最后一项取正性会丢掉恰好可能抵消 reciprocal 边界常数的 signed 信息。

## 4. OMEN 精确核验与路线裁决

在 OMEN 上用有理数直接检查了全部 $2\le N\le15$、所有
$1\le d\le N$、$1\le A\le\lfloor N/d\rfloor$，共 313 个参数组：

* (1) 的 $Z$ 一阶差分恒等式全部成立；
* (2) 的逐 $q$ 分层能量与 (3) 完全相等；
* 未使用浮点、抽样或渐近假设。

这给出一个严格的新接口：截断倍数链的 completion 缺口等价于控制
$(Z_0,u_1,\ldots,u_{M-1})$ 在 Volterra Gram (3) 下的 signed 交叉项。
notes 460--462 已说明内部截断通常有 $Z_0\to1$；本式进一步说明，任何
声称“残差由正 Gram 尾自动支付”的论证都不完整，必须同时给出
对 $Z_0T_j u_j$ 的统一算术抵消，或构造保留该交叉项的真实 Möbius intertwiner。

本结果仍不是 RH，也没有把有限核验外推为全称估计。
