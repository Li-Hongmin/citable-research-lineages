> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 因果算子的 $K$／$\zeta K$ 二择一

日期：2026-08-16。

本 note 把 note 233 的三角坍缩写成两个因果算子之间的精确分叉。它说明：
“容易坍缩”的算子恰好含有 $\zeta$ 因子而失去 RH 检测能力；保留零自由
Mellin 乘子的算子，其 Möbius 输出就是尚未解决的 RH-strength 对象。

## 1. 两个因果算子

令 $V$ 支持于 $(0,1)$，并定义其 periodization

\[
P_V(y)=\sum_{c\le y}V(c/y),\qquad y\ge1.
\]

在有限序列 $c=(c_b)_{b\le N}$ 上定义

\[
(A_Vc)(a)=\sum_{b\le a}c_bV(b/a),
\qquad
(B_Vc)(a)=\sum_{b\le a}c_bP_V(a/b).
\]

二者的 Mellin 符号分别是

\[
K_V(s)=\int_0^1V(u)u^{s-1}\,du,
\qquad
I_V(s)=\int_1^\infty P_V(y)y^{-s-1}\,dy=\zeta(s)K_V(s)
\tag{1}
\]

（先在 $\operatorname{Re}s>1$ 做绝对收敛的 Mellin--Fubini，再延拓）。

## 2. 对 Möbius 向量的精确输出

取 $c_b=\mu(b)$。第一个算子给出

\[
(A_V\mu)(a)=\sum_{b\le a}\mu(b)V(b/a),
\tag{2}
\]

这正是连续函数
\[
U_V(x)=\sum_{n\le x}\mu(n)V(n/x)
\]
在整数点的取值；连续 Mellin 变换满足
\[
\int_1^\infty U_V(x)x^{-s-1}\,dx=K_V(s)/\zeta(s).
\]
所以若能获得平方根级控制并且 $K_V$ 在临界带无零，就会推出 RH。

第二个算子却精确坍缩：

\[
\begin{aligned}
(B_V\mu)(a)
&=\sum_{b\le a}\mu(b)\sum_{d\le a/b}V(db/a)\\
&=\sum_{k\le a}V(k/a)\sum_{b\mid k}\mu(b)
=V(1/a).
\end{aligned}
\tag{3}
\]

因此当 $V(u)=O(u^2)$ 于零点时，$B_V\mu$ 在 $\ell^2$ 中一致有界，
但这只是因为 $B_V$ 的 Mellin 符号是 $\zeta K_V$，其 $1/\zeta$
因子已经被相消。

## 3. 正 Gram 路线的精确裁决

因果算子 $B_V^*B_V$ 可以产生一个真正的正 Gram，并且在 Möbius 向量上
有小输出；但它检测的是 $\zeta(s)K_V(s)$，不是临界带无零的 $K_V(s)$。
所以它不能推出 RH。反过来，对 $A_V^*A_V$ 使用正 Gram，虽然保留了
$K_V$ 的 zero-free 接口，但其 Möbius 输出 $A_V\mu$ 正是尚未证明的
平方根级 signed estimate。

这给出一个严格的二择一：

\[
\boxed{
\begin{array}{c}
\text{periodization 因果 Gram：输出易，但符号为 }\zeta K;\\
\text{原始因果 Gram：符号为 }K/\zeta\text{，但输出即 RH 门。}
\end{array}}
\]

任何声称从 (3) 的小输出直接得到 RH 的论证，必须额外构造一个不引入
\(\zeta\) 因子的 intertwiner；这正是当前项目尚未找到的 arithmetic bridge。

## 4. 与 note 233 的关系

把 $B_V\mu$ 再与 $\mu(a)$ 做内积，便恢复 note 233 的三角坍缩：

\[
\sum_{a,b\le N}\mu(a)\mu(b)g_V(\log(a/b))
=\sum_{a\le N}\mu(a)V(1/a).
\]

因此该恒等式是一个真实的有限算术证书，但它关闭的是 $\zeta$-已相消的
因果通道，而不是 RH 所需的零自由通道。本 note 不声称 RH。

## 5. 有限矩阵的最短写法

在 ({1,\ldots,N}) 上令

\[
A_{a,d}=1_{d\le a}V(d/a),
\qquad
D_{d,b}=1_{b\mid d}.
\]

则逐项有

\[
(AD)_{a,b}=\sum_{c\le a/b}V(cb/a)=P_V(a/b).
\tag{4}
\]

而除数关联矩阵 (D) 是单位下三角矩阵，且

\[
(D\mu)_d=\sum_{b\mid d}\mu(b)=1_{d=1}.
\tag{5}
\]

于是 (B_V=AD)、(B_V\mu=Ae_1)，这正是式 (3) 的有限线性代数版本；
原始 RH 门则是 (A\mu=A D^{-1}e_1)。因此从容易控制的 (B_V\mu)
回到 (A\mu)，必须控制 (D^{-1}) 在 (A^*A) 度量下的作用。这个
divisor-incidence intertwiner 正是尚未闭合的算术桥，而不是一个可以由
普通正 Gram 自动得到的矩阵不等式。

## 6. 有限下三角反演的末端爆炸

把第二个因果算子限制到 \(1\le a,q\le N\)，写成
\[
 (B_N)_{q,a}=1_{a\le q}P_V(q/a).
\]
式 (3) 是精确的有限矩阵恒等式
\[
 B_N\boldsymbol\mu_N
 =\bigl(V(1),V(1/2),\ldots,V(1/N)\bigr)^{\mathsf T}.
\tag{6}
\]
若 \(V(1)=0\)，则 \(B_N\) 严格下三角。即使只尝试表示
\(\boldsymbol 1-e_N\)（把最后一个 Möbius 系数作为 \(O(1)\) 残差），
令 \(B_N^{\mathsf T}r=\boldsymbol 1-e_N\)，其第 \(N-1\) 个坐标只有
\(q=N\) 一项，故
\[
 r_N=\frac1{P_V(N/(N-1))}.
\tag{7}
\]
对 V15，\(1\le N/(N-1)<2\)，所以
\[
 P_{15}\!\left(\frac N{N-1}\right)
 =V_{15}\!\left(\frac{N-1}{N}\right)
 =\frac{1144}{N^9}+O(N^{-10}),
\qquad
 r_N=\frac{N^9}{1144}+O(N^8).
\tag{8}
\]
因此直接用因果正 Gram 输出
\(B_N\boldsymbol\mu_N=O_{\ell^2}(1)\) 再作 Cauchy--Schwarz，
会支付至少 \(N^9\) 量级的末端反演系数；它不能给出平方根级
Möbius 界。任何有效的桥必须先消除这个末端边界（例如采用有足够
端点消失阶的平滑目标），并同时控制内部反演；后者在 Mellin 端正是
\(1/\zeta\) 的未决因子。

## 7. 一个确切但只含 \(\zeta K_V\) 的平滑部分和

在 (6) 的有限矩阵恒等式上取行权 \(r_q=1/q\)，交换有限求和得到
\[
 \sum_{a\le N}\mu(a)\,b_N(a)
 =\sum_{q\le N}\frac{V(1/q)}q,
\qquad
 b_N(a):=\sum_{q=a}^{N}\frac1qP_V(q/a).
\tag{9}
\]
当 \(V(u)=O(u^2)\) 于零点时，右端一致有界。若 \(P_V\ge0\)，则
\(b_N(a)\ge0\)；在 \(a/N\) 固定且 \(N\to\infty\) 时，\(b_N(a)\) 是
\[
 \int_1^{N/a}P_V(y)\,\frac{dy}{y}
\]
的 Riemann 和，因此形成一个从常数平台逐渐降到零的平滑截断。
这看似接近 \(M(N)\)，但其 Mellin 乘子是
\(\zeta(s)K_V(s)/s\)，仍属于容易坍缩的 \(\zeta K_V\) 通道；
它没有提供 \(K_V(s)/\zeta(s)\) 的零自由信息。故 (9) 是一个严格的
PNT 级平滑恒等式，而不是 RH 证明的隐藏步骤。

## 8. 基准核的正确转置次序仍显式含 Mertens 和

为检验转置次序，取基准函数 \(V(u)=u^2\)，包括端点 \(V(1)=1\)。
此时 \(A_{q,a}=1_{a\le q}(a/q)^2\)、\(B=AD\)，且
\(B_N\boldsymbol\mu=(q^{-2})_{q\le N}\)。若解
\[
 B_N^{\mathsf T}r=\boldsymbol1,
\]
必须先令 \(t=A^{\mathsf T}r\)，再解
\(D^{\mathsf T}t=\boldsymbol1\)。倍数 Möbius 反演给出
\[
 t_b=\sum_{k\le N/b}\mu(k)=M(\lfloor N/b\rfloor).
\tag{10}
\]
另一方面 \(A^{\mathsf T}r=t\) 等价于
\[
 a^2\sum_{q=a}^{N}\frac{r_q}{q^2}=t_a,
\]
从而（置 \(t_{N+1}=0\)）
\[
 r_a=t_a-\frac{a^2}{(a+1)^2}t_{a+1}.
\tag{11}
\]
所以内部对偶系数 \(r_a\) 不是一个独立、可轻易估计的序列，而是由
不同尺度的 Mertens 和组成；此前若把 \(D^{\mathsf T}\) 与
\(A^{\mathsf T}\) 顺序交换，会错误地制造出一个“无条件 RH 证明”。

## 9. 普适的因果对偶公式

上述现象并非 \(V(u)=u^2\) 的特例。对任意 \(V\) 满足
\(V(1)\ne0\)，矩阵 \(A\) 是下三角可逆矩阵。若某个对偶向量 \(r\)
满足
\[
 B_N^{\mathsf T}r=\mathbf1,\qquad B_N= A D,
\]
置 \(t=A^{\mathsf T}r\)，则必有
\[
 D^{\mathsf T}t=\mathbf1,
\qquad
 t_b=\sum_{k\le N/b}\mu(k)
 =M(\lfloor N/b\rfloor).
\tag{12}
\]
因此一般地
\[
 r=A^{-\mathsf T}
\bigl(M(N),M(\lfloor N/2\rfloor),\ldots,M(1)\bigr)^{\mathsf T}.
\tag{13}
\]
选择 \(V\) 只能改变这个多尺度 Mertens 向量所经过的三角滤波器
\(A^{-\mathsf T}\)，不能删除 \(1/\zeta\) 的算术内容。若 \(V(1)=0\)，
则 \(A\) 不可逆，代价转为第 6 节的末端边界；两种情形分别对应
“内部 Mertens 反演”与“端点奇异反演”。

## 10. 任意端点消失阶的末端下界

第 6 节的 \(N^9/1144\) 不是 V15 的偶然数值。设 \(V\) 在 \(u=1\)
的左邻域满足
\[
 V(1)=0,\qquad
 V(1-\delta)=c\,\delta^{\beta}+O(\delta^{\beta+\eta})
 \quad(\delta\downarrow0),
 \tag{14}
\]
其中 \(c\ne0\)、\(\beta>0\)、\(\eta>0\)。对 \(N\ge3\)，因
\(N/(N-1)<2\)，periodization 在该点只有 \(c=1\) 一项：
\[
 P_V\!\left(\frac N{N-1}\right)
 =V\!\left(\frac{N-1}{N}\right).
 \tag{15}
\]
令 \(B_N=(\mathbf 1_{a\le q}P_V(q/a))_{1\le q,a\le N}\)。若某个对偶向量
\(r\) 满足
\[
 B_N^{\mathsf T}r=b,\qquad b_{N-1}=b_*\ne0,
 \tag{16}
\]
则第 \(N-1\) 个坐标只有 \(q=N-1,N\) 两项，而
\(P_V(1)=V(1)=0\)。故有精确末端恒等式
\[
 r_N=\frac{b_*}{V((N-1)/N)}.
 \tag{17}
\]
由 (14) 得
\[
 r_N=\frac{b_*}{c}N^{\beta}
       \bigl(1+O(N^{-\min\{1,\eta\}})\bigr),
 \qquad \|r\|_2\ge |r_N|.
 \tag{18}
\]
因此任何试图用 \(B_N\mu_N\) 的小输出、再以
Cauchy--Schwarz 生成一个在 \(N-1\) 坐标仍有固定质量的目标时，至少要支付
\(N^{\beta}\) 的对偶系数；若代价进入 Gram 范数，则相应出现
\(N^{2\beta}\)。这条结论不依赖 \(P_V(y)\) 的全半轴正性。

对当前 detector，
\[
 V_{15}(u)=u^2(1-u)^9Q(u),\qquad Q(1)=1144,
\]
所以 \((\beta,c)=(9,1144)\)，(18) 恢复
\[
 r_N=N^9/1144+O(N^8).
\]
若把 \(b_{N-1}\) 人为压到 \(O(N^{-\gamma})\)，末端代价才会降为
\(N^{\beta-\gamma}\)；但此时目标本身已不再是常数平台在该末端的对偶表示。
因而“提高端点消失阶即可免费绕开 \(1/\zeta\)”并不是一个无条件的捷径：
它只是在端点系数与内部多尺度 Mertens 反演之间重新分配代价。

## 11. Canonical hierarchy: the endpoint coefficient is explicit

The preceding obstruction can be evaluated for the entire Euler--beta hierarchy,
not only for (V_{15}). Write (delta=1-u) and

\[
H_m(u)=u^2delta^{3m+1},
\qquad
\mathcal D_m=(\Theta-1)\prod_{j=1}^{m-1}(\Theta+2j+1),
\qquad
V_m=C_m^{-1}\mathcal D_mH_m.
\]

For every fixed constant (a) and integer (n\ge1),

\[
(\Theta+a)\bigl(\delta^n(1+O(\delta))\bigr)
   =n\,\delta^{n-1}+O(\delta^n),
\]

because (Theta=-u\partial_u) and (u=1+O(\delta)). Applying the (m)
commuting factors in (mathcal D_m) therefore gives

\[
V_m(u)=c_m(1-u)^{2m+1}+O\bigl((1-u)^{2m+2}\bigr),
\qquad
c_m=\frac{(3m+1)!}{(2m+1)!\,C_m}.
\tag{19}
\]

Here (c_m>0), since (C_m>0). For (m=4),

\[
c_4=\frac{13!}{9!\,15360}=\frac{143}{128}=Q_{15}(1),
\]

agreeing with the direct V15 polynomial. Combining (19) with (17)--(18)
shows that any solution of (B_N^{\mathsf T}r=b) with
(b_{N-1}=b_*\ne0) must satisfy

\[
r_N=\frac{b_*}{c_m}N^{2m+1}
       \bigl(1+O(N^{-1})\bigr),
\qquad
\|r\|_2\ge |r_N|.
\tag{20}
\]

Thus the canonical detector of level (m) carries an endpoint-dual cost of order
(N^{2m+1}). This is independent of the unresolved all-(m) periodization
positivity question: it is a purely local consequence of the endpoint jet and the
triangular incidence geometry. Increasing the flatness order improves residue
annihilation but worsens this causal dual boundary by exactly the same hierarchy
parameter.
