> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 撤回：二进制层 Toeplitz 张量化下界不成立

本文件原先试图把
\[
e^{-|\log(2^v u/2^w r)|}
\]
拆成
\[
2^{-|v-w|}e^{-|\log(u/r)|}.
\]
该等式一般错误，因为正确的指数是
\[
-\left|\log(u/r)+(v-w)\log2\right|,
\]
两个项的符号可能相反，不能把绝对值拆开。

因此原 note 396 中关于 Kronecker 张量化、谱区间
\(\frac13I\preceq R\preceq3I\)、以及归一化滤波器 \(q^{-1/2}\) 衰减的
全部结论均撤回，不得作为 RH 项目的数学证据。精确反例与后续正确边界见
note 397。
