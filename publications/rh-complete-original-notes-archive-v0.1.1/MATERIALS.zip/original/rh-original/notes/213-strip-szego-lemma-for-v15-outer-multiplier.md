> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(V_{15}\) 的条带 Szegő 引理：解析乘子接口的条件核验

日期：2026-08-15。

本 note 把 note 195 留下的唯一解析技术点压缩为一个明确的标准条带因子化引理。
在接受该引理（包括长矩形 Carleman 边界项）的前提下，当前
\[
H(z)=\frac12\{\zeta(iz)K_{15}(iz)+\zeta(-iz)K_{15}(-iz)\}
\]
满足
\[
\int_{\mathbb R}\frac{\log^-|H(x)|}{1+x^2}\,dx<\infty .
\tag{1}
\]
因此 \(w(x)=|H(x)|/(2\pi)\) 具有右半平面 Szegő 外函数；正能量平方根界
一旦成立，就可无循环地推出 RH。本 note 给出零点计数、Blaschke--Green
估计和外函数构造的可审计框架，但不把尚未逐行写出的长矩形边界引理冒充为
新的独立定理。

## 1. 两条平移线的多项式下界

取 \(b<1/4\)。由于 \(K_{15}\) 的极点在负整数处，\(H\) 在
\(|\operatorname{Im}z|<b\) 全纯；凸性估计给出每个闭子带上的多项式上界。

固定 \(0<a<b/8\)，避开 \(H\) 的可数个零点虚部。令
\[
F(z)=\zeta(iz)K_{15}(iz),\qquad
F^\#(z)=\zeta(-iz)K_{15}(-iz).
\]
在 \(z=x+ia\) 上，函数方程把 \(F\) 的 zeta 因子移到
\(\zeta(1+a-ix)\)，故
\[
 |F(x+ia)|\asymp_a (1+|x|)^{-19/2+a}.
\tag{2}
\]
另一方面凸性估计给出
\[
 |F^\#(x+ia)|
\ll_{a,\varepsilon}(1+|x|)^{-19/2-a/2+\varepsilon}.
\tag{3}
\]
取 \(\varepsilon<a/4\)，则 \(F^\#/F\to0\)。因此充分大的
\(|x|\) 上
\[
 |H(x+ia)|\ge\tfrac12|F(x+ia)|
\gg_a(1+|x|)^{-C_a}.
\tag{4}
\]
紧区间上因所选 \(a\) 不经过零点，最小值仍为正。共轭对称
\(H(\bar z)=\overline{H(z)}\) 给出同一结论于 \(x-ia\)。

## 2. 条带零点计数与因子化引理

这里所用的解析输入可单独表述为如下条带因子化引理：若 \(G\) 在
\(\lvert\operatorname{Im}z\rvert<b\) 全纯，在每个闭子带上有多项式上界，且在
\(\operatorname{Im}z=\pm a\) 上有多项式下界（\(0<a<b\)），则在窄条带
\(\Omega_a=\{\lvert\operatorname{Im}z\rvert<a\}\) 中，\(G\) 的零点 Blaschke
因子与零自由因子的商满足条带 Poisson--Green 下界；特别地
\(\int_{\mathbb R}\log^-|G(x)|(1+x^2)^{-1}\,dx<\infty\)。
下述三步给出该引理在本 \(H\) 上的可审计证明框架。关键是使用更宽条带的
多项式上界；它排除了把无界域 Poisson 解中隐藏的“无穷远奇异内因子”误当作
普通 Blaschke 因子。

更具体地，取 \(M\) 大到使
\(G_M(z)=G(z)/(z+i)^M\) 在 \(\Omega_a\) 上有界，并用
\(q=\exp(\pi z/(2a))\) 把 \(\Omega_a\) 映到右半平面。右半平面的标准
\(H^\infty\) 因子化给出 Blaschke、奇异内因子和外因子三部分。两条平移线的
多项式下界使边界 \(\log|G_M|\) 的负部对
\(dt/(1+t^2)\) 可积；而 \(G\) 在更宽条带上全纯且多项式有界，排除了有限
边界点的奇异测度以及 \(q=0,\infty\) 的奇异因子（非平凡端点因子
\(\exp(-cq)\) 或 \(\exp(-c/q)\) 会在更宽扇区内指数增长）。因此只剩
Blaschke 因子和外因子，拉回条带即得到下述 Green 表示与 (1)。

下面使用一个标准的局部 Jensen 论证，并写出覆盖参数以避免隐含的
“矩形 Jensen”跳步。取半径 \(4a\) 的圆盘，圆心为
\(x_j+ia\)，其中 \(x_j\) 组成间距 \(a/2\) 的网格。因 \(a<b/8\)，
这些圆盘落在 \(H\) 的全纯条带内；(4) 与闭子带多项式上界给出 Jensen
\[
 \#\{\rho:\ |\rho-(x_j+ia)|<3a\}
 \ll_a \log(2+|x_j|).
\tag{5}
\]
这些半径 \(3a\) 的圆盘覆盖窄条带 \(|\operatorname{Im}z|<a\)，故
\[
 N_H(R):=\#\{\rho:\ |\operatorname{Re}\rho|\le R,\ 
 |\operatorname{Im}\rho|<a\}
 \ll_a R\log(2+R).
\tag{6}
\]

## 3. Blaschke--Green 因子化

在 \(\Omega_a=\{|\operatorname{Im}z|<a\}\) 中取 \(H\) 的带重数
Blaschke 乘积 \(B\)。由 (6) 及条带 Green 核的指数水平衰减，
该乘积满足
\[
\log|B(z)|=-\sum_{\rho\in\Omega_a}G_{\Omega_a}(z,\rho)\le0,
\tag{7}
\]
并在两条边界线上有 \(|B|=1\)。令 \(U=H/B\)，则 \(U\) 无零，
\(v=\log|U|\) 调和。由更宽条带上的多项式上界，先在有限矩形上对
\(v\) 加标准线性屏障，再令矩形宽度趋于无穷；边界下界 (4) 通过条带
Poisson 不等式给出
\[
 v(x,0)\ge-C_a\log(2+|x|).
\tag{8}
\]
从而
\[
 \log^-|H(x)|
 \le C_a\log(2+|x|)
 +\sum_{\rho\in\Omega_a}G_{\Omega_a}(x,\rho).
\tag{9}
\]

对条带 Green 核，直接由其镜像级数得到
\[
 \int_{\mathbb R}\frac{G_{\Omega_a}(x,\rho)}{1+x^2}\,dx
 \ll_a (1+|\operatorname{Re}\rho|)^{-2}.
\tag{10}
\]
将零点按 \(k\le|\operatorname{Re}\rho|<k+1\) 分箱，(6) 与 (10) 给出
\[
 \sum_{\rho\in\Omega_a}
 \int_{\mathbb R}\frac{G_{\Omega_a}(x,\rho)}{1+x^2}\,dx
 \ll_a \sum_{k\ge0}\frac{\log(2+k)}{(1+k)^2}<\infty .
\tag{11}
\]
对 (9) 积分即得 (1)。

## 4. 对 RH 接口的严格后果

由 (1) 及 \(H(x)=O_\varepsilon(|x|^{-19/2+\varepsilon})\)，
\(w=|H|/(2\pi)\) 满足外函数定理的 \(L^1\) 与对数可积条件。于是存在
右半平面零自由的 \(O\in H^2\) 使
\[
 |O(it)|^2=|H(t)|.
\]
取 \(\Psi(s)=O(s)/(s+1)^J\)，\(J\ge1\)，则
\[
 \int_{\mathbb R}\frac{|\Psi(it)|^2}{w(t)}\,dt<\infty,
\]
且 \(\Psi\) 在 \(\operatorname{Re}s>0\) 无零。其逆 Laplace 变换经一次
平移可支撑于 \((0,1)\)，所以它是 admissible Mellin 测试函数。

因此 note 192 的全整数正能量命题
\[
\int_{\mathbb R}|H(t)|
\left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt
\ll_\varepsilon N^{1+\varepsilon}
\]
在上述条带因子化引理成立时，正能量门严格推出 RH；本 note 不提供该
算术平方根界本身，也不宣称已经独立证明长矩形边界项。
