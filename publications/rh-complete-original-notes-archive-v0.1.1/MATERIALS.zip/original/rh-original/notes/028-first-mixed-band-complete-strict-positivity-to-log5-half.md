> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 首个 mixed translation--reflection chamber 的完整严格正性

日期：2026-08-11。

本文使用 note 026 的精确半区压缩和 note 025 的 Fourier--Yukawa--Feshbach 接口，证明首个
mixed chamber 的右端点严格为正。

## 1. 定理

令

\[
a_5=\frac12\log5.
\]

则

\[
\boxed{
A_a^+>0,\qquad A_a^->0,
\qquad 0<a\le a_5.}
\tag{1}
\]

从而

\[
\boxed{A_a>0\qquad(0<a\le\tfrac12\log5).}
\tag{2}
\]

若首次退化尺度存在，则

\[
\boxed{a_{\rm deg}>\tfrac12\log5
=0.804718956217050\ldots .}
\tag{3}
\]

这是本项目在建立统一 prime-graph/frame 定理前允许的最后一个逐 chamber 证书。

## 2. 端点的完整 prime 算子

在 \(a=a_5\) 时，正测度活跃的 prime powers 恰为 \(n=2,3,4\)；\(n=5\) 只有零测度端点接触。
置

\[
d_2=\log2,\quad d_3=\log3,\quad d_4=2\log2,
\]

\[
\alpha_2=\frac{\log2}{\sqrt2},\qquad
\alpha_3=\frac{\log3}{\sqrt3},\qquad
\alpha_4=\frac{\log2}{2}.
\]

由 note 026，奇偶扇区 \(\sigma=\pm1\) 的 prime 算子为

\[
\boxed{
P^\sigma
=-\alpha_2(S_2+S_2^*)-\sigma\alpha_2J_2
-\sigma\alpha_3J_3-\sigma\alpha_4J_4.}
\tag{4}
\]

这里 \(S_2\) 的两个方向分别作用于 \([0,a-d_2]\) 与 \([d_2,a]\)，而

\[
J_2:\ [0,d_2],\qquad
J_3:\ [d_3-a,a],\qquad
J_4:\ [d_4-a,a].
\]

保守但严格的补空间范数界为

\[
\|P^\sigma\|
\le 2\alpha_2+\alpha_3+\alpha_4.
\tag{5}
\]

## 3. 有限正下模型与 Feshbach 归约

在相应 Neumann 或 Dirichlet--Neumann Fourier 基中，把 Archimedean 部分写成对角算子
\(D^\sigma\) 加正 Yukawa atoms。只保留前 \(N\) 个正 atoms，并精确保留 (4) 和极点秩一项：

\[
L^\sigma
=D^\sigma+\sum_{n<N}|f_n^\sigma\rangle\langle f_n^\sigma|
+P^\sigma+\sigma|w_\sigma\rangle\langle w_\sigma|,
\tag{6}
\]

其中

\[
w_+(x)=2\cosh(x/2),\qquad
w_-(x)=2\sinh(x/2).
\]

最后一项的 \(\sigma\) 正是 note 007 的极点 signature \((1,1)\)。删除的 Yukawa 尾为正，故

\[
A_{a_5}^\sigma\succeq L^\sigma.
\tag{7}
\]

令 \(P_R\) 为前 \(R\) 个 Fourier modes，\(Q_R=I-P_R\)，并把非对角部分记为 \(B^\sigma\)。
digamma multiplier 的严格单调性、(5) 以及奇扇区负极点的精确范数给出

\[
Q_RL^\sigma Q_R\succeq\mu_\sigma Q_R,
\qquad \mu_\sigma>0.
\tag{8}
\]

交叉块无需截断。精确恒等式

\[
C_\sigma C_\sigma^*
=P_R(B^\sigma)^2P_R-(P_RB^\sigma P_R)^2,
\qquad C_\sigma=P_RB^\sigma Q_R,
\tag{9}
\]

把无穷补空间压成有限矩阵

\[
\mathcal S_\sigma
=P_RL^\sigma P_R-\mu_\sigma^{-1}C_\sigma C_\sigma^*.
\tag{10}
\]

完成平方即得

\[
\mathcal S_\sigma>0\Longrightarrow L^\sigma>0
\Longrightarrow A_{a_5}^\sigma>0.
\tag{11}
\]

所有矩阵元均由有限指数积分闭式计算，不使用数值求积。

## 4. Arb 证书

使用 python-flint 的 Arb ball arithmetic。

偶扇区取

\[
(\mathrm{prec},R,N)=(256,64,160),
\]

得到

\[
\mu_+>1.72188158623646,
\qquad
\min{\rm pivot}(\mathcal S_+)
>1.85615599199315\times10^{-5}.
\tag{12}
\]

奇扇区取

\[
(\mathrm{prec},R,N)=(256,60,120),
\]

得到

\[
\mu_->1.48622531888818,
\qquad
\min{\rm pivot}(\mathcal S_-)
>3.55913071622361\times10^{-5}.
\tag{13}
\]

全部 interval LDL pivots 均严格为正。独立较大参数

\[
(320,72,200,+),\qquad (320,68,160,-)
\]

也分别给出严格正 pivot 下界

\[
1.87008064088604\times10^{-5},
\qquad
3.63170975203809\times10^{-5}.
\tag{14}
\]

这些 pivot 只认证有限 Feshbach 矩阵正定，不是原算子的谱隙。

复现命令：

    uv run --with python-flint python computations/verify_first_mixed_band_endpoint_log5.py 256 64 160 +
    uv run --with python-flint python computations/verify_first_mixed_band_endpoint_log5.py 256 60 120 -

## 5. 结论边界

尺度单调性把端点结论传播到全部较小区间，得到 (1)--(3)。普通 Galerkin 在该端点显示最低值已接近
双精度分辨率，因此不能用来宣称数值谱隙；严格结论只来自上述 Feshbach--Arb 下模型。

本结果验证了 mixed translation--reflection 接口可以闭合一个完整 chamber，但不提供全尺度机制。
依照既定停止规则，后续不继续逐端点推进；主问题转为 note 027 揭示的无限 orbit graph 上的统一
resolvent，以及 note 024 的 Robin-frame 不等式。

