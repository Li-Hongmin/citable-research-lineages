> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mean-zero RH remainder 是带平方跳跃的单一 reciprocal-phase 场

日期：2026-08-14。

依赖：[note 126](126-the-endpoint-flat-rh-kernel-has-two-independent-collective-residues.md)、
[note 127](127-fixed-congruences-cannot-separate-the-two-mobius-residue-rays.md)。

证据等级：绝对收敛 Bernoulli Fourier 级数、固定支撑微分恒等式与精确跳跃计算。

本文把 note 126 的三个 mean-zero Bernoulli modes 压成一个 reciprocal-phase
Hankel 场，并确定该压缩在平方边界的精确缺陷。

令 \(z=\lfloor\sqrt x\rfloor\)，并定义

\[
F_{k,z}(n,x)=
\sum_{a,b\le z}(ab)^k\mu(a)\mu(b)
e^{2\pi i n x/(ab)}.
\tag{1}
\]

Bernoulli Fourier 级数为

\[
B_2(r)=\frac1{\pi^2}\sum_{n\ge1}\frac{\cos(2\pi nr)}{n^2},
\tag{2}
\]

\[
B_3(r)=\frac3{2\pi^3}\sum_{n\ge1}\frac{\sin(2\pi nr)}{n^3},
\tag{3}
\]

\[
B_4(r)=-\frac3{\pi^4}\sum_{n\ge1}\frac{\cos(2\pi nr)}{n^4}.
\tag{4}
\]

它们绝对收敛，故 note 126 的 remainder 精确成为

\[
\boxed{
\begin{aligned}
T_V^{(0)}(x)
={}&-\frac1{\pi^2x}\sum_{n\ge1}\frac{\Re F_{1,z}(n,x)}{n^2}\\
&+\frac3{\pi^3x^2}\sum_{n\ge1}\frac{\Im F_{2,z}(n,x)}{n^3}\\
&+\frac3{\pi^4x^3}\sum_{n\ge1}\frac{\Re F_{3,z}(n,x)}{n^4}.
\end{aligned}}
\tag{5}
\]

在任一开平方单元

\[
z^2<x<(z+1)^2,
\tag{6}
\]

支撑固定，故逐项微分给出

\[
\partial_xF_{3,z}=2\pi inF_{2,z},
\qquad
\partial_x^2F_{3,z}=(2\pi in)^2F_{1,z}.
\tag{7}
\]

记 \(D=x\partial_x\)。代入 (5) 后三项精确合并为

\[
\boxed{
T_V^{(0)}(x)=
\frac1{4\pi^4x^3}
\sum_{n\ge1}\frac1{n^4}
\Re\!\left[(D-3)(D-4)F_{3,z}(n,x)\right].}
\tag{8}
\]

等价地，若

\[
G_z(x)=\sum_{n\ge1}\frac{F_{3,z}(n,x)}{n^4},
\tag{9}
\]

则开单元内部

\[
T_V^{(0)}(x)
=\frac1{4\pi^4x^3}
\Re\!\left[(D-3)(D-4)G_z(x)\right].
\tag{10}
\]

这是真正的单场压缩，但不是全局光滑表示。完整门

\[
T_V(x)=\sum_{a,b\le\sqrt x}\mu(a)\mu(b)P_V(x/(ab))
\tag{11}
\]

在 \(x=N^2\) 新增第 \(N\) 行与列。因 \(P_V(1)=0\)，

\[
\Delta T_V(N^2)
=2\mu(N)\sum_{b<N}\mu(b)P_V(N/b).
\tag{12}
\]

展开 \(P_V(N/b)=\sum_{c\le N/b}V(bc/N)\)，再用
\(\sum_{b\mid n}\mu(b)=\mathbf1_{n=1}\)，以及 \(V(1)=0\)，得到

\[
\boxed{\Delta T_V(N^2)=2\mu(N)V(1/N).}
\tag{13}
\]

另一方面，置 \(S_k^-=S_k(N-1)\)。two-residue 骨架

\[
R_2(x)=\frac{S_1(\sqrt x)^2}{6x}
-\frac{S_3(\sqrt x)^2}{30x^3}
\tag{14}
\]

的跳跃为

\[
\boxed{
\Delta R_2(N^2)=
\mu(N)\left(\frac{S_1^-}{3N}
-\frac{S_3^-}{15N^3}\right)
+\frac{2}{15}\mu(N)^2.}
\tag{15}
\]

因此 mean-zero remainder 的平方跳跃精确为

\[
\boxed{
\Delta T_V^{(0)}(N^2)
=2\mu(N)V(1/N)
-\mu(N)\left(\frac{S_1^-}{3N}
-\frac{S_3^-}{15N^3}\right)
-\frac{2}{15}\mu(N)^2.}
\tag{16}
\]

式 (16) 重新含有两个 RH-strength moments。故对 (10) 作逐单元 Sobolev、
能量或 resolvent 控制，若不同时支付平方跳跃，就不能推出全局 RH 门。

结论：

\[
\boxed{
\text{三个 mean-zero Bernoulli modes 在平方单元内是一个四阶加权
reciprocal-phase 场；跨单元缺陷精确恢复 two-residue moments}.}
\tag{17}
\]

下一步的最薄接口不是继续增加 Fourier modes，而是寻找同时控制 \(G_z\) 的单元内
变化和跳跃 (16) 的离散 trace inequality。仅逐单元微分会再次把 RH 强度搬到边界。
这不是 RH 的证明。
