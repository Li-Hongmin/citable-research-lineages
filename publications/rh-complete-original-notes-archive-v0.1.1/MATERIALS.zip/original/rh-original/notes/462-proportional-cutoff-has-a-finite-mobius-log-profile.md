> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 比例截断的 residual 收敛到有限 Möbius–对数 profile

日期：2026-08-17。

本 note 继续 note 461，研究 \(A\) 与完整链长度 \(X\) 保持固定比例时的 residual。结果把这一尺度区间压缩成一个有限的 Möbius–对数和。

## 1. 比例截断的精确重排

令

$$A_X=\lfloor\theta X\rfloor,\qquad 0<\theta<1.$$

按 \(n=aj\) 交换求和，note 461 的 \(\mathcal H_A\) 满足

$$\mathcal H_{A_X}(X)=\sum_{j\le X/(A_X+1)}\frac{\mu(j)}j\left(H_{\lfloor X/j\rfloor}-H_{A_X}\right).$$

只有有限多个 \(j\) 出现，因为 \(X/(A_X+1)\to\theta^{-1}\)。对每个固定的 \(j<\theta^{-1}\)，

$$H_{\lfloor X/j\rfloor}-H_{A_X}=\log\frac1{\theta j}+O_\theta(X^{-1}).$$

若 \(j=\theta^{-1}\) 恰为整数，该项的主项为零，故包含或删去它不影响极限。于是

$$\boxed{\mathcal H_{A_X}(X)\longrightarrow\mathfrak F(\theta):=\sum_{1\le j\le\theta^{-1}}\frac{\mu(j)}j\log\frac1{\theta j}.}$$

这是一个有限和；没有使用 RH，也没有使用数值外推。

## 2. 前几个区间

当 \(1/2<\theta<1\) 时只有 \(j=1\)，因此

$$\mathfrak F(\theta)=\log(1/\theta)>0,$$

这与 note 459 的同号调和尾完全一致。

当 \(1/3<\theta\le1/2\) 时，

$$\mathfrak F(\theta)=\log(1/\theta)-\frac12\log\frac1{2\theta}=\frac12\log(2/\theta)>0.$$

更小的 \(\theta\) 逐步引入 \(j=3,4,\ldots\) 的 Möbius 修正；式 (3) 给出每个区间的精确 profile，而不应把其符号未经证明地统一宣称为正。

## 3. 对中间截断的含义

对 \(d=1\)、\(k=1\)，note 458 的 residual 正是 \(\mathcal H_A(N)\)。因此若 \(A/N\to\theta\in(0,1)\)，其 \(k=1\) 行趋向明确的 \(\mathfrak F(\theta)\)，不会由抽象“边界小量”自动消失。

结合 note 461：

* \(A\) 固定时，\(\mathcal H_A(X)\to1\)；
* \(A/X\to\theta>1/2\) 时，\(\mathfrak F(\theta)=\log(1/\theta)>0\)；
* \(A/X\to\theta\le1/2\) 时，残差由 (3) 的有限 Möbius–对数 profile 决定，可能的抵消已被压缩为一个具体的有限算术问题。

所以真正可能产生小 residual 的，不是任意“中间区间”本身，而只能是 \(\theta\) 变化、profile 接近零，或不同 \(d,k\) 行之间的额外跨尺度 signed cancellation。单条链的正估计仍不足以给出 RH 所需的平方根门。

本 note 给出的是严格渐近重写，不是 RH 证明；下一步应研究 \(\mathfrak F(\theta)\) 的零点与跨 \(d,k\) 的相消，而不是继续枚举局部 detector 正性。
