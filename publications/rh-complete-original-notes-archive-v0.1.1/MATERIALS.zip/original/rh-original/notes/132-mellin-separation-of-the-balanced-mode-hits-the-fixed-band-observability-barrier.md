> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Balanced mode 的 Mellin 分离撞上 fixed-band observability barrier

日期：2026-08-14。

依赖：[note 131](131-the-lowest-reciprocal-mode-saturates-the-full-width-gram.md)。

证据等级：精确 Mellin inversion 与定量局部观测下界。

本文把 note 131 的真实 Möbius balanced box 分离成一维 Dirichlet polynomials，
并判断所得 fixed-band mean 是否弱于 RH。

取 \(\psi\in C_c^\infty((0,\infty))\)，其支撑包含在固定紧区间
\([\alpha,\beta]\subset(0,\infty)\)。令

\[
K(u)=Q(1/u),
\tag{1}
\]

其中 \(Q\) 是 note 131 的核。再取
\(\chi\in C_c^\infty((0,\infty))\)，在
\([\alpha^2,\beta^2]\) 上恒等于 \(1\)，并置

\[
K_\chi(u)=\chi(u)K(u),
\qquad
\widetilde K_\chi(s)
=\int_0^\infty K_\chi(u)u^{s-1}\,du.
\tag{2}
\]

Mellin inversion 给出

\[
K_\chi(u)
=\frac1{2\pi}\int_{\mathbb R}
\widetilde K_\chi(3+it)u^{-3-it}\,dt.
\tag{3}
\]

定义归一化 Möbius exponential polynomial

\[
B_{\psi,z}(t)
=\sum_{a\ge1}\mu(a)\psi(a/z)(a/z)^{-it}.
\tag{4}
\]

则有精确恒等式

\[
\boxed{
\begin{aligned}
&z^{-6}\sum_{a,b\ge1}
(ab)^3\mu(a)\mu(b)
\psi(a/z)\psi(b/z)
Q\!\left(\frac{z^2}{ab}\right)\\
&\qquad=
\frac1{2\pi}\int_{\mathbb R}
\widetilde K_\chi(3+it)
B_{\psi,z}(t)^2\,dt.
\end{aligned}}
\tag{5}
\]

这里仍是 Hankel square \(B(t)^2\)，不是 \(|B(t)|^2\)。由于
\(\widetilde K_\chi(3+it)\) Schwartz，承重 Mellin 频带是

\[
|t|=O(1).
\tag{6}
\]

在该尺度，归一频率

\[
-\log(a/z)\in[-\log\beta,-\log\alpha]
\tag{7}
\]

落在固定紧区间；项数却为 \(\asymp z\)。所以 ordinary long-\(t\)
Dirichlet-polynomial mean value orthogonality并未出现。

若逐 \(t\) 取绝对值，RH-strength 输入是

\[
\boxed{
B_{\psi,z}(t)\ll_{\psi,T,\varepsilon}
z^{1/2+\varepsilon}
\qquad(|t|\le T),}
\tag{8}
\]

它由 \(M(x)\ll x^{1/2+\varepsilon}\) 经部分求和得到。反过来，包含 \(t=0\)
且覆盖 dyadic partition 的一族 (8) 也给出 Mertens 的平方根界。因此 modewise
pointwise 估计本身没有弱化 RH。

固定频带的 \(L^2\) 平均也不能由软观测升级到 (8)。事实上

\[
|B_{\psi,z}'(t)|
\le C_\psi z.
\tag{9}
\]

若 \(H=|B_{\psi,z}(0)|\)，则在长度

\[
|t|\le \frac{H}{2C_\psi z}
\tag{10}
\]

的区间上有 \(|B_{\psi,z}(t)|\ge H/2\)。故只要非负权 \(W\) 在零点邻域有
固定正下界，

\[
\int W(t)|B_{\psi,z}(t)|^2dt
\gg_\psi \frac{H^3}{z}.
\tag{11}
\]

即使得到目标尺度

\[
\int W(t)|B_{\psi,z}(t)|^2dt
\ll_\varepsilon z^{1+\varepsilon},
\tag{12}
\]

(11) 也只推出

\[
\boxed{B_{\psi,z}(0)\ll_\varepsilon z^{2/3+\varepsilon},}
\tag{13}
\]

而非平方根界。这与此前 detector 点值恢复的 \(2/3\) barrier 相同。

截至 2026-08-14 的 paper-lib 记录中，Nazarov 的 fixed-band exponential-polynomial
local observability 具有随项数指数恶化的常数；它不能为当前 \(\asymp z\) 项提供
uniform point evaluation。该文献边界与 (11)--(13) 一致，没有可直接迁移的
dimension-free theorem。

结论：

\[
\boxed{
\text{Mellin 分离把 balanced reciprocal mode 变成 fixed-band Möbius
exponential polynomial；pointwise 是 RH 强度，局部 \(L^2\) 软恢复只到 \(2/3\)}.}
\tag{14}
\]

因此 Mellin separation 本身没有产生严格弱于 RH 的可用门。下一步若继续，必须利用
真实 Möbius 系数改善 fixed-band observability，或寻找不需要从平均恢复点值的直接
Hankel signed estimate。这不是 RH 的证明。
