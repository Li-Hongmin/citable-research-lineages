> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 平均 logarithmic boundary trace 的存在定理

日期：2026-08-11。

本文闭合 [note 049](049-averaged-boundary-trace-and-dyadic-packet-coercivity.md) 的 signed Mellin
tail 条件：对实际边界模型中所有满足临界上界和 bounded forcing 的解，该 tail 作为普通 improper
integral 收敛。因此 Cesàro/Mellin 意义的边界系数无条件存在。

## 1. 抽象边界方程

设 \(T>1\)，

\[
|U(t)|\le Ct^{-1/2},\qquad t\ge T,
\tag{1}
\]

并在分布意义满足

\[
(\mathcal V+\mathcal M)U=F,\qquad F\in L^\infty(T,\infty),
\tag{2}
\]

其中

\[
\mathcal VU(t)=2tU(t)-\int_T^tU(\tau)\,d\tau
\]

而 \(\mathcal M\) 是 [note 048](048-mellin-local-symbol-and-whitney-dini-boundary-gap.md) 的固定宽度
Mellin-local 算子。

## 2. Signed tail 定理

由 (1) 直接有

\[
|\mathcal VU(t)|\le C\sqrt t.
\]

方程 (2) 因而把 \(\mathcal MU=F-\mathcal VU\) 识别为局部有界函数，并给出

\[
|\mathcal MU(t)|\le C\sqrt t.
\tag{3}
\]

另一方面，\(\mathcal M^*\) 消去常数，且其固定宽度差分核满足

\[
\boxed{
\|\mathcal M^*\phi\|_\infty
\le C_L\|\phi'\|_\infty.}
\tag{4}
\]

取 dyadic cutoff

\[
\phi_k(t)=t^{-3/2}\psi(t/2^k),
\]

其中 \(\psi\) 支撑于一个固定紧区间。则

\[
\|\phi_k'\|_\infty=O(2^{-5k/2}),
\]

而在其长度 \(O(2^k)\) 的支撑上，\(|U|=O(2^{-k/2})\)。由形式对偶与 (4)，

\[
\boxed{
|\langle\mathcal MU,\phi_k\rangle|
=|\langle U,\mathcal M^*\phi_k\rangle|
\le C\,2^{-2k}.}
\tag{5}
\]

右端可求和，所以 smooth dyadic partition 给出绝对收敛的 signed tail。再用固定宽度 smooth cutoff
逼近 sharp cutoff；由 (3)，在 \([R,R+1]\) 上的差为

\[
O(R^{-3/2}\sqrt R)=O(R^{-1})\to0.
\]

因此得到普通 improper integral，而不只是 Abel 极限：

\[
\boxed{
\int_T^\infty t^{-3/2}\mathcal MU(t)\,dt
\quad\text{收敛}.}
\tag{6}
\]

## 3. Averaged gauge trace

令

\[
A(t)=\int_T^tU(\tau)\,d\tau,\qquad
Z(t)=\frac{A(t)}{\sqrt t}.
\]

由精确恒等式

\[
2t^{3/2}Z'(t)=F(t)-\mathcal MU(t)
\]

及 \(F/t^{3/2}\in L^1\)、式 (6)，存在 \(B\in\mathbf C\) 使

\[
\boxed{
\frac1{\sqrt t}\int_T^tU(\tau)\,d\tau\longrightarrow2B.}
\tag{7}
\]

回到 \(r=e^{-t}\)，这定义了端点的 averaged logarithmic boundary coefficient。有限 prime shifts、
smooth convolution、polar 与本征值项都只进入 \(F\in L^\infty\)，所以不改变定理。

## 4. 离散交叉核验

固定 log-grid 与任意有限程 Toeplitz difference \(\mathcal M_R\) 下，离散方程

\[
2jU_j-\sum_{\ell\le j}U_\ell+\mathcal M_RU_j=F_j
\]

有精确递推。若 \(|U_j|\le Cj^{-1/2}\)、\(F_j\) 有界，则

\[
U_j=\frac{B}{\sqrt j}+O(j^{-1}).
\]

这严格排除 fixed-mesh sharp-cutoff leakage，并与连续 signed-tail 定理一致；连续证明不依赖
mesh limit。

## 5. 尚未推出的点态 trace

式 (7) 是平均 trace，不自动推出

\[
\sqrt t\,U(t)\to B.
\]

由

\[
\sqrt t\,U(t)
=\frac{Z(t)}2+\frac{F(t)-\mathcal MU(t)}{2\sqrt t}
\]

可见点态升级还需

\[
\mathcal MU(t)=o(\sqrt t)
\tag{8}
\]

或其他 Tauberian 正则性。当前定理没有证明 (8)，也没有证明截断 Green identity 只需要平均 trace。

因此新的精确分叉是：若 exterior flux 与 Pohozaev boundary pairing 只依赖式 (7)，则 boundary
trace 链已经越过主要正则性障碍；若必须使用点态/conormal trace，则 (8) 是下一唯一接口。

