> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 统一 Euler detector：半区间正性与首个未闭合的系数锥

日期：2026-08-15。

本 note 只记录一个严格的局部引理。它不声称
\(P_m(y)=\sum_{c\le y}V_m(c/y)\ge0\) 对所有 \(m,y\) 成立。

## 1. Euler 算子在中心坐标中的递推

令
\[
 H_m(u)=u^2(1-u)^{3m+1},\qquad
 \Theta=-u\partial_u,
\]
并令
\(\mathcal D_m=(\Theta-1)\prod_{j=1}^{m-1}(\Theta+2j+1)\)。
取 \(x=2u-1\)。逐次提出正因子后有精确恒等式
\[
 \mathcal D_mH_m(u)
 =2^{-(3m+3)}(1+x)^2(1-x)^{2m+1}q_{m,m}(x),
 \tag{1}
\]
其中
\[
 q_{m,1}(x)=(3m-2)+(3m+4)x,
 \tag{2}
\]
且对 \(1\le j<m\)
\[
 q_{m,j+1}
 =\bigl(A_{m,j}+B_{m,j}x\bigr)q_{m,j}
 -(1-x^2)q'_{m,j},
 \tag{3}
\]
\[
 A_{m,j}=3m+j,\qquad B_{m,j}=3m+2-3j\ge5.
 \tag{4}
\]
归一化常数 \(C_m>0\) 不影响下面的符号结论。

## 2. 严格的系数锥引理

对实系数多项式写 \(p\preceq q\)，表示每个幂级数系数逐项满足
\(p_k\le q_k\)。若在某一步满足
\[
 q'_{m,j}\preceq A_{m,j}q_{m,j},
 \tag{5}
\]
则由 (3) 精确改写为
\[
 q_{m,j+1}
 =\underbrace{(A_{m,j}q_{m,j}-q'_{m,j})}_{\succeq0}
 +x\underbrace{(B_{m,j}q_{m,j}+xq'_{m,j})}_{\succeq0}.
 \tag{6}
\]
因此 \(q_{m,j+1}\) 的幂级数系数全非负；特别地
\[
 q_{m,m}(x)\ge0\quad(0\le x\le1),
 \qquad V_m(u)\ge0\quad(1/2\le u\le1),
 \tag{7}
\]
只要条件 (5) 沿整条链成立。

首步条件是无条件成立的：当 \(m\ge2\) 时，
\[
 q'_{m,1}=3m+4\le(3m+1)(3m-2),
 \tag{8}
\]
而 \(x\)-系数一侧显然非负。因此若坚持这条系数锥路线，缺口是证明 (5) 对后续步骤的传播。

## 3. 半区间可由对数导数直接闭合

条件 (5) 的传播不是处理半区间的最短办法。note 150 的另一条严格递推给出
\[
G_{m,m-1}=u^2(1-u)^{2m+2}R_m(u),
\]
其中 (R_m) 的所有系数均为正。令
\(F_m=uG_{m,m-1}=u^3(1-u)^{2m+2}R_m\)，则
\[
V_m=-C_m^{-1}F_m'.
\]
对 (0<u<1)，正系数性给出
\[
\frac{R_m'(u)}{R_m(u)}
 =\frac1u\frac{\sum k r_k u^k}{\sum r_k u^k}
 \le\frac{m-1}{u}.
\]
因此
\[
\frac{F_m'}{F_m}
\le \frac{m+2}{u}-\frac{2m+2}{1-u}
 =\frac{m+2-(3m+4)u}{u(1-u)}\le0
 \qquad (u\ge1/2).
\]
这严格推出
\[
V_m(u)\ge0\quad(1/2\le u\le1),
\qquad P_m(y)=V_m(1/y)\ge0\quad(1\le y\le2).
\]
所以条件 (5) 的传播不是半区间结论所必需的；它只是一条更强的系数锥路线。

条件 (5) 不能仅由前一步的非负系数推出。即使 \(A=7,B=5\)，取
\(q(x)=1+7x\) 时有 \(q'\preceq Aq\)，但 (3) 给出
\[
 (7+5x)(1+7x)-(1-x^2)7=61x+42x^2,
\]
其常数项为零，故下一步的严格导数锥条件失败。这个例子不是 detector 链本身的反例，只说明 (5) 的传播需要额外不变量（例如归一化系数序列的对数凹性或更强的 Bernstein 锥估计）。

对实际递推，用有理整数算术检查到有限层时 (5) 均成立；这只是计算证据，不是任意 \(m\) 的证明。

## 4. 与全局 periodization 的首断点

即便 (7) 对所有 \(m\) 成立，也只能处理 \(1\le y<2\)，因为此时 periodization 只有 \(c=1\)。对 \(y\ge2\)，求和同时包含 \(u<1/2\) 的负部分；简单配对也不够：例如 \(m=1,u=1/4\) 时
\[
 V_1(u)+V_1(1-u)<0.
\]
精确值为
\[
V_1(1/4)+V_1(3/4)=-\frac{27}{14336}<0.
\]
所以全 \(m\) 的 \(P_m(y)\ge0\) 仍需对
\(N=\lfloor y\rfloor\ge2\) 和余数 \(r=y-N\) 给出一般 Bernstein/falling-factorial 系数证明。当前有限扫描不能替代该证明。
