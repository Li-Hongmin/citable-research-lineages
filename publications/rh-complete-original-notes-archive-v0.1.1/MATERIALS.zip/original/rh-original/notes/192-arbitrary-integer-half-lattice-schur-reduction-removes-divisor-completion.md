> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 任意整数半格上的反射 Schur 压缩：消除 divisor completion 缺口

本 note 修正 note 189--190 的适用范围。反射
\(a\mapsto X/a\) 不要求 \(a\mid X\)；只要把反射后的 \(X/a\) 作为
Hilbert 空间中的实数标签，半格压缩就可以直接作用于全部
\(1\le a\le\sqrt X\)。

## 1. 两个核

令
\[
p(t)=\mathbf 1_{t\ge0}P(e^t),\qquad
g(t)=\frac{p(t)+p(-t)}2,
\]
并令 \(h=\widehat g\) 为 Fourier 变换。假设 \(h\) 为实偶且
\(h\in L^1(\mathbb R)\)；当前 \(V_{15}\) 层满足这一条件，因为
\(K_{15}(i\xi)=O(|\xi|^{-10})\)。定义
\[
\widetilde g(t)=\frac1{2\pi}\int_{\mathbb R}|h(\xi)|e^{i\xi t}\,d\xi .
\]
对任意有限的正实标签集 \(S\)，令
\[
A_S(a,b)=\widetilde g(\log(a/b)),\qquad
B_S(a,b)=g(\log(a/b)).
\]
在 \(L^2(|h(\xi)|\,d\xi/(2\pi))\) 中，\(A_S\) 是指数向量
\(e^{i\xi\log a}\) 的 Gram，而 \(B_S\) 是插入
\(\Sigma=\operatorname{sgn}(h)\) 后的交叉 Gram。因此
\[
\begin{pmatrix}A_S&B_S\\ B_S&A_S\end{pmatrix}\succeq0,
\qquad
A_S-B_SA_S^{-1}B_S\succeq0
\tag{1}
\]
（奇异情形使用 Moore--Penrose 逆及相应 range 条件）。

## 2. 任意 \(X\) 的反射集合

固定 \(X>1\)，令
\[
L_X=\{1,\ldots,\lfloor\sqrt X\rfloor\},\qquad
R_X(L_X)=\{X/a:a\in L_X\},
\]
并令 \(S_X=L_X\cup R_X(L_X)\)，对重复标签只保留一个副本。
反射算子 \(\mathcal R_X\) 在标签上满足
\[
\mathcal R_X e_a=e_{X/a},\qquad \mathcal R_X^2=I.
\]
因为 \(A_S,B_S\) 只依赖差 \(\log(a/b)\)，且 \(\widetilde g,g\) 都是偶函数，
\[
\mathcal R_XA_{S_X}=A_{S_X}\mathcal R_X,\qquad
\mathcal R_XB_{S_X}=B_{S_X}\mathcal R_X .
\]
令 \(H_{S_X}=B_{S_X}\mathcal R_X\)。由 (1) 得
\[
A_{S_X}-H_{S_X}A_{S_X}^{-1}H_{S_X}\succeq0.
\tag{2}
\]
对 \(L_X\) 做主压缩仍保留 relative contraction。记
\[
A_X=A_{L_X},\qquad H_X=E_{L_X}^*H_{S_X}E_{L_X}.
\]
则
\[
A_X-H_XA_X^{-1}H_X\succeq0.
\tag{3}
\]
这里完全没有使用 \(a\mid X\)。

## 3. 原始 reciprocal Möbius 形式的精确出现

若 \(a,b\in L_X\)，则 \(ab\le X\)，从而
\[
(H_X)_{ab}
=g\!\left(\log\frac{ab}{X}\right)
=g\!\left(\log\frac X{ab}\right)
=\frac12P\!\left(\frac X{ab}\right).
\]
因此令 \(c_a=\mu(a)\)，有精确恒等式
\[
Q_P(X):=\sum_{a,b\le\sqrt X}\mu(a)\mu(b)
P\!\left(\frac X{ab}\right)=2c^*H_Xc.
\]
由 (3) 及 Cauchy--Schwarz，
\[
\boxed{|Q_P(X)|\le 2c^*A_Xc}
\tag{4}
\]
其中右端正是全整数半格的正能量：
\[
\boxed{
c^*A_Xc
=\frac1{2\pi}\int_{\mathbb R}|h(\xi)|
\left|\sum_{a\le\sqrt X}\mu(a)a^{i\xi}\right|^2d\xi .
}
\tag{5}
\]
由于 \(Q_P(X)\) 就是原 reciprocal-product 二次型 \(T_P(X)\)，
(4) 已经消除了从 divisor lattice 到 common-scale 整数对的 completion
误差；此前把这一步列为缺口是范围过窄。

## 4. 剩余的真实承重命题

当前路线因此精确归约为一个单一命题：
\[
\frac1{2\pi}\int_{\mathbb R}|h(\xi)|
\left|\sum_{a\le\sqrt X}\mu(a)a^{i\xi}\right|^2d\xi
\ll_\varepsilon X^{1/2+\varepsilon}.
\tag{6}
\]
若 (6) 成立，则由 (4) 得
\(T_P(X)\ll_\varepsilon X^{1/2+\varepsilon}\)，再用既有 Mellin 等价
（notes 155--166）推出 RH。

式 (6) 不是由正性自动给出的：其无条件三角估计只有 \(O(X)\)；
它仍是一个全整数 Möbius Dirichlet-polynomial 的平方根级估计。
所以本 note 消除了“divisor completion”这一伪缺口，但没有声称已经证明
(6) 或 RH。
