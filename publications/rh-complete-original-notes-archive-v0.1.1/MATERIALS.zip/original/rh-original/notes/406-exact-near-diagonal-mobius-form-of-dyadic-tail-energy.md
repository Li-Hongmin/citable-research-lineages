> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 二进制尾能量的精确近对角 Möbius 双相关形式

令
\[
B(k)=\sum_{n\ge k}\frac{\mu(n)}n,
\qquad
H(k)=B(k)-B\!\left(\left\lceil\frac k2\right\rceil\right).
\]
由尾部相减的有限区间恒等式，
\[
H(k)=-\sum_{k/2\le n<k}\frac{\mu(n)}n.
\tag{1}
\]
定义截断能量
\[
E(Y)=\sum_{k\le Y}k|H(k)|^2.
\]

## 精确交换求和

将 (1) 代入并交换有限和。对一对整数 \(m,n\)，令
\[
r=\max(m,n),\qquad s=\min(m,n),\qquad L_Y(m,n)=\min(Y,2s).
\]
条件 \(m,n\in[k/2,k)\) 对整数 \(k\) 等价于
\[
r<k\le L_Y(m,n).
\]
因此得到完全精确的恒等式
\[
\boxed{
E(Y)=\sum_{m,n\le Y}\frac{\mu(m)\mu(n)}{mn}\,K_Y(m,n),
}
\tag{2}
\]
其中
\[
K_Y(m,n)=
\begin{cases}
\displaystyle
\frac{L_Y(L_Y+1)-r(r+1)}2,&r<L_Y,\\[6pt]
0,&r\ge L_Y.
\end{cases}
\tag{3}
\]
特别地，核的支撑满足
\[
\max(m,n)<2\min(m,n),
\tag{4}
\]
除去右端 \(Y\) 的截断边界；它只连接乘法比小于 2 的近对角点。

## 算术含义

对角项为
\[
\sum_{m\le Y}\frac{\mu(m)^2}{m^2}
\sum_{k=m+1}^{\min(Y,2m)}k,
\tag{5}
\]
其自然量级为 \(Y\)。真正未解的部分是 (2) 中同一乘法窗口内的带符号
off-diagonal 相关。逐项取绝对值会回到 \(Y^2\) 量级；而把它压到
\(Y^{1+\varepsilon}\) 正是 notes 402--405 中的 RH-equivalent 门。

这个恒等式还解释了为什么一般的固定加法位移 Chowla 平均不能直接闭合：
这里的权重随 \(m/n\) 移动，并且所有 \(m,n\) 满足 \(1/2<m/n<2\) 的位移同时出现。
需要的是该乘法近对角核的联合 signed cancellation，而不是单个固定 shift 的估计。

## 按加法位移的精确重写

令 \(n=m+h\)，并设
\[
L_Y(m)=\min(Y,2m).
\]
则 (2) 等价于
\[
E(Y)=E_{\rm diag}(Y)+2\sum_{m=1}^{Y-1}
\sum_{1\le h<\min(m,Y-m)}
\mu(m)\mu(m+h)W_Y(m,h),
\tag{6}
\]
其中
\[
E_{\rm diag}(Y)=\sum_{m\le Y}\frac{\mu(m)^2}{m^2}
\sum_{k=m+1}^{L_Y(m)}k,
\tag{7}
\]
并且
\[
W_Y(m,h)=
\frac{L_Y(m)(L_Y(m)+1)-(m+h)(m+h+1)}{2m(m+h)}.
\tag{8}
\]
式 (6) 的内层位移范围达到 \(h\asymp m\)，而权重同时依赖于
\(h/m\) 与右端截断 \(Y/m\)。因此即使掌握每个固定 \(h\) 的相关估计，仍不能直接对 (6) 求和。

一个足以推出 \(E(Y)\ll Y^{1+\varepsilon}\) 的新算术输入是：对所有固定光滑
\(\Phi\)（及其有限个边界变体），都有统一的乘法比率相关界
\[
\sum_{m\le Y}\sum_{h<m}
\mu(m)\mu(m+h)\Phi(h/m)\,\mathbf 1_{m+h\le Y}
\ll_{\Phi,\varepsilon}Y^{1+\varepsilon}.
\tag{9}
\]
当前已知的固定 shift 或仅对 \(h\) 平均的结果并不提供 (9) 的这种全尺度、移动权版本。
