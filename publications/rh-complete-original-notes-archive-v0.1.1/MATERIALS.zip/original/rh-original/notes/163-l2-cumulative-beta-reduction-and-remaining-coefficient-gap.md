> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# L=2 Newton 层：累计 Beta 归约

日期：2026-08-15。

本 note 将 (L=2) 的系数精确归约为一个 raw cumulative Beta 核，并关闭
端点修正项的正性。raw 核的累计系数正性由 note 164 的尾部/低指标变号
引理补足；与小层的有限精确表合并后，结论见 note 170。

## 1. 精确的 (x^3) 系数

沿用 note 157 的 (D=3m+3)、(d=D-2)、(r_q=D-q-1) 和 (K_q)，
并固定 q-shift 权重 w_q=c_{m-1,q}*binom(D,q)（不是 (q+1)c_{m-1,q}）。由
\[
A_{q+1}(x)=x+(2^{q+1}-2)x^2+
 (3^{q+1}-3\,2^{q+1}+3)x^3+O(x^4)
\]
以及 (E_{r,h}^{(d)}) 的定义，
\[
[x^3]A_{q+1}E_{r_q,h}^{(d)}
=\sum_{s<r_q}\binom{r_q}{s}a_s
  \bigl(2^{r_q-s}+2^{q+1}-4\bigr)
 +a_{r_q}\bigl(3^{q+1}-3\,2^{q+1}+3\bigr),
\]
其中 (a_s=\binom hs/\binom ds)。因此令 (J_s) 为上式中 (a_s) 的系数，
并置 (C_s=\sum_{j\le s}J_j)，则
\[
6!\,\gamma_{m,h,2}=\sum_sJ_sa_s.
\]

## 2. Raw cumulative 生成式

暂把端点值替换为普通二项式公式在 (s=r_q) 的延拓值
(2^{q+1}-3)。相应的 raw 累计核 \(\widetilde C_s\) 的生成函数为
\[
\sum_{s\ge0}\widetilde C_sx^s
=\frac{T_1(x+2)+2T_2(x+1)-4T_1(x+1)}{1-x},
\qquad T_a(y):=y^{D-1}K(a/y).
\tag{1}
\]
这是由二项式累计恒等式和
(K(z)=DW(z)-(z+1)W'(z)-W(z)/z) 得到的严格恒等式。

## 3. Beta 核形式与当前缺口

使用 note 162 的 Beta 表示
\[
W(z)=A_mz^2\int_0^1t^{m-1}(1-t)^{m+2}(t+2z)^{m-1}\,dt,
\qquad A_m>0,
\]
并令 (u=ty+2a)，直接代入 (T_a(y)=y^{D-1}K(a/y))，得到被积因子
\[
\mathcal S_a(y,t)=a y^{2m+1}u^{m-2}
\Bigl[a(D-2)u-3yu-2a(m-1)y-2a^2(m-1)\Bigr].
\tag{2}
\]
因此 (1) 的分子在 Beta 积分下对应
\[
\mathcal S_1(x+2,t)+2\mathcal S_2(x+1,t)-4\mathcal S_1(x+1,t).
\tag{3}
\]
单独从 (2)--(3) 的点值正性不能推出 Taylor 系数正性；note 164 改用
离散系数的单变号、端点总和与显式多项式下界，补足了这一逻辑缺口。

## 4. 端点修正严格为非负

实际端点值与 raw 延拓值之差为
\[
\delta_q=3^{q+1}-4\,2^{q+1}+6.
\]
因此
\[
C_s-\widetilde C_s
=\sum_{q\ge Q_s}\delta_qK_q,
\qquad Q_s=\max(1,D-1-s).
\tag{4}
\]
当 (s<d) 时 (Q_s\ge2)，且
(delta_2=1)、(delta_{q+1}>delta_q>0)；结合 note 157 的
(T_Q=\sum_{q\ge Q}K_q>0)，Abel 变换给出 (4) 非负。
当 (s=d) 时 (Q_s=1)。此时
(delta_1=-1)、(K_1=-3w_2)，故首项
(delta_1K_1=3w_2>0)；其余 (q\ge2) 的尾仍由同一 Abel 变换非负。

综上，端点修正不构成障碍；raw cumulative Beta 核的正性由 note 164
闭合（m>=4），m=1,2,3 由 note 170 的完整 Fraction 表处理。
这只给出 detector 的 L=2 系数层，仍需独立处理 Möbius signed Hankel
二次型，不能将本 note 解释为 RH 证明。
