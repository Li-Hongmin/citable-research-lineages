> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(B_N^{-1}\) 的显式末行给出不可避免的平方根尺度增长

日期：2026-08-17。

note 449 给出了 \(B_N^{-1}\) 的差分—除数和公式。本 note 只利用它的最后一行，证明原始 Lehmer 行权下的逆算子不可能在 \(N\) 上一致有界。

## 1. 末行系数

记

\[
S_N:=\operatorname{diag}\bigl(\sqrt{2k+1}\bigr)_{k=1}^{N-1},
\qquad
B_N^{-1}
=D^{(2)}_N\operatorname{diag}(e)\,U_N^{-1}S_N^{-1}.
\]

当 \(d=N\) 时，\(D^{(2)}_N\) 的最后一行只在 \(e\mid N\) 的位置取 \(1\)。因此 \(B_N^{-1}\) 的最后一行作用在归一化残差 \(z_k=\rho_k/\sqrt{2k+1}\) 上，其非零系数来自

\[
e\bigl(z_{e-1}-z_e\bigr),\qquad e\mid N,\quad 2\le e<N,
\]

以及末端项 \(Nz_{N-1}\)。等价地，若按 \(z_1,\ldots,z_{N-1}\) 排列，最后一行在 \(e\mid N\) 处出现

\[
\frac{e}{\sqrt{2e-1}}
\quad\text{和}\quad
-\frac{e}{\sqrt{2e+1}},
\]

末端 \(e=N\) 只保留正项 \(N/\sqrt{2N-1}\)。

## 2. \(N=2^m\) 的精确平方范数

当 \(N=2^m\) 时，不同幂 \(e=2^j\) 的这些位置不重合，故最后一行 \(r_N\) 满足

\[
\boxed{
\|r_N\|_2^2
=\frac{N^2}{2N-1}
+\sum_{j=1}^{m-1}
\left(
\frac{4^j}{2^{j+1}-1}
+\frac{4^j}{2^{j+1}+1}
\right).
}
\tag{1}
\]

对每个 \(e\ge2\)，

\[
\frac{e^2}{2e-1}+\frac{e^2}{2e+1}>e,
\qquad
\frac{N^2}{2N-1}>\frac N2.
\]

而 \(\sum_{j=1}^{m-1}2^j=N-2\)，所以有严格下界

\[
\boxed{
\|B_N^{-1}\|_{2\to2}
\ge \|r_N\|_2
>\sqrt{\frac{3N}{2}-2},
\qquad N=2^m.
}
\tag{2}
\]

OMEN 用精确有理数核验了 (1) 及严格不等式 \(N=8,16,32,64,128,256\)。

## 3. 含义与边界

式 (2) 排除了把 \(B_N^{-1}\) 当作 \(N\)-一致有界算子的路线。若近似桥写成

\[
\alpha-\mathbf1=B_N^{-1}\rho,
\]

则一般方向的残差必须至少支付平方根尺度的逆算子代价。注意这只是算子级障碍：它没有说明真实 Möbius 边界余项恰好落在最后一行的放大方向上。

因此仍需证明特定 signed 余项 \(\rho_N\) 在 \(B_N^{-1}\) 的放大方向上发生额外抵消；没有这种算术输入，式 (2) 不能转化为 RH 证明。当前新结论是一个严格的谱边界，而不是对 RH 的否定或完成。
