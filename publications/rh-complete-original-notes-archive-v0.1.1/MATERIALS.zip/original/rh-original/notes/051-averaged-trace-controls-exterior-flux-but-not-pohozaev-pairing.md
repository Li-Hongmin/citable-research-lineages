> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Averaged trace 控制外侧 flux，但不决定 Pohozaev pairing

日期：2026-08-11。

本文确定 [note 050](050-existence-of-the-averaged-logarithmic-boundary-trace.md) 的精确用途：平均
boundary coefficient 已足够计算 exterior logarithmic flux，因而可用于 collar/platform 排除；但它
不足以决定 dilation Green pairing，后者还含一个独立的 conormal variance。

## 1. Averaged trace 到 Stieltjes flux

在右端点令

\[
r=e^{-t},\qquad U(t)=u(a-e^{-t}),\qquad
A(T)=\int_{t_0}^{T}U(t)\,dt.
\]

假设

\[
|U(t)|\le Ct^{-1/2},\qquad
\frac{A(T)}{\sqrt T}\longrightarrow2B_+.
\tag{1}
\]

局部外侧 Stieltjes transform 为

\[
J(\varepsilon)
=\int_0^\delta\frac{u(a-s)}{\varepsilon+s}\,ds.
\]

取 \(\varepsilon=e^{-T}\)，换元得到

\[
J(e^{-T})
=\int_{t_0}^{\infty}
\frac{U(t)}{1+e^{t-T}}\,dt.
\tag{2}
\]

式 (2) 与 \(A(T)\) 的右尾及左 soft-cutoff 误差都为 \(O(T^{-1/2})\)，更精确地可由
\(\int_0^\infty(1+e^h)^{-1}dh=\log2\) 控制。因此

\[
\boxed{
J(e^{-T})=A(T)+O(T^{-1/2}),}
\tag{3}
\]

并由 (1)

\[
\boxed{
\frac{J(e^{-T})}{\sqrt T}\longrightarrow2B_+.}
\tag{4}
\]

标准一维 exterior-zero logarithmic Laplacian 的局部系数为 \(1\)，故

\[
\boxed{
\frac{L_\Delta u(a+e^{-T})}{\sqrt T}\longrightarrow-2B_+.}
\tag{5}
\]

左端同理：

\[
\frac{L_\Delta u(-a-e^{-T})}{\sqrt T}\longrightarrow-2B_-.
\tag{6}
\]

所以 [note 009](009-exterior-log-boundary-flux-obstruction.md) 中的点态 trace 假设可严格替换为
note 050 的 averaged trace。任一 \(B_\pm\ne0\) 都产生无界外侧 flux，从而排除相应 collar/platform。

## 2. Averaged trace 不决定 Green boundary pairing

令

\[
Z(t)=\frac{A(t)}{\sqrt t}.
\]

因为 \(A'=U\)，

\[
\sqrt t\,U(t)=\frac{Z(t)}2+q(t),
\qquad q(t)=tZ'(t).
\tag{7}
\]

边界二次量含

\[
t|U(t)|^2
=\frac{|Z(t)|^2}{4}
+\operatorname{Re}(\overline{Z(t)}q(t))
+|q(t)|^2.
\tag{8}
\]

若 \(Z(t)\to2B\)，混合项可经 Stieltjes/分部处理，但非负的 \(|q|^2\) 不由 averaged trace 控制。
例如

\[
U_1(t)=\frac{B}{\sqrt t},
\qquad
U_2(t)=\frac{B}{\sqrt t}
+c\,t^{-1/2}\sin t
\]

具有相同的 averaged coefficient，而 smooth dyadic boundary pairing 相差一个非零的
\(|c|^2/2\) variance。该例只反驳“平均 trace 自动决定 pairing”，不声称满足实际零模态方程。

## 3. 最薄 conormal 条件

从 averaged trace 升级到目标 Green identity 不必先证明完整点态 trace。一个更薄的充分条件是

\[
\boxed{
\frac1T\int_T^{2T}|tZ'(t)|^2\,dt\longrightarrow0.}
\tag{9}
\]

式 (9) 正是 dyadic conormal variance 消失。点态条件

\[
\mathcal MU(t)=o(\sqrt t)
\]

通过边界方程足以推出更强结论，但不是必要的。

因此首次退化边界路线现已分成两层：

\[
\begin{array}{ccl}
\text{averaged trace} &\Longrightarrow& \text{exterior flux / collar 排除},\\
\text{averaged trace + (9)} &\Longrightarrow& \text{Pohozaev boundary pairing 候选}.
\end{array}
\]

当前唯一未闭合的正则性量是 (9)，而不是 signed trace 的存在。

