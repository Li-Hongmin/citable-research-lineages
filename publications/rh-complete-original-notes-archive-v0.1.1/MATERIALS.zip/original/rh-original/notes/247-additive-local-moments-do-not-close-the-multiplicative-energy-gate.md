> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 加法局部 Möbius 矩不直接关闭乘法正能量门

日期：2026-08-16。

## 结论

近期的局部 Möbius Fourier 结果研究
\[
 P_N(t)=N^{-1/2}\sum_{n\le N}\mu(n)e^{2\pi int}
\]
在半径 \(O(N^{-1})\) 的加法频率弧上的局部矩。该类结果给出的是
\(P_N(0)=M(N)/\sqrt N\) 的加法局部判据；它不提供本项目所需的无条件乘法能量界
\[
 E_N(w)=\int_{\mathbb R}w(\tau)
 \left|\sum_{n\le N}\mu(n)n^{i\tau}\right|^2\,d\tau
 \ll N^{1+\varepsilon}.
\]

## 尺度计算

在一个 dyadic 块 \(n=X+r\) 中，
\[
\tau\log(n/X)
=\tau\left(\frac rX-\frac{r^2}{2X^2}
 +O\!\left(\frac{|r|^3}{X^3}\right)\right).
\tag{1}
\]
因此（在 \(|r|\le X/2\) 内）
\[
\sum_{X<n\le 2X}\mu(n)n^{i\tau}
=X^{i\tau}\sum_{0<r\le X}\mu(X+r)
 \,e^{i\tau r/X}
 e^{-i\tau r^2/(2X^2)+O(|\tau| |r|^3/X^3)}.
\tag{2}
\]
只有在 \(|r|\le H=o(X)\) 时，乘法相位才可由加法相位
\(\tau r/X\) 以一致小误差替代。覆盖完整 dyadic 块需要 \(H\asymp X\)，
此时二次相位项在整个块上为 \(O(1)\)，不能作为误差丢弃。

若把块切成 \(X/H\) 个短区间，局部加法矩只控制每个区间的对角能量；
重组完整乘法能量还需要区间之间的交叉项。那些交叉项正是当前
Möbius signed-energy 门中的未控部分，不能由正 Gram 或局部矩自动消去。

## 文献边界

2026 年 arXiv 预印本 *Local Moments of Möbius Fourier Polynomials and the
Riemann Hypothesis* 的 Theorem 1.3 明确把其对象定义为加法 Fourier 多项式
\(e^{2\pi int}\)，并把半径 \(c/N\) 弧上的任意高阶局部矩表述为 RH 的等价
条件；作者在引言中明确说明这不是新的 RH 证明路线：
<https://arxiv.org/abs/2607.25002>。
它不是当前固定 Mellin 频率权 \(w(\tau)\) 的无条件估计。即使把 dyadic
块局部化到该弧，式 (1) 的二次相位在完整 \(r\asymp X\) 区间仍为 \(O(1)\)，
所以跨短块的交叉项没有被该定理控制。

## \(q=2\) 的精确有限核：sinc 差核而非 Lehmer 比值核

把文献中的定义在 \(q=2\) 展开，可以得到一个不依赖渐近的有限恒等式。令

\[
 S_N(t)=\sum_{n\le N}\mu(n)e^{2\pi int},
 \qquad
 \mathcal M_{2,c}(N)^2
 =\frac{N}{2c}\int_{-c/N}^{c/N}
 \left|N^{-1/2}S_N(t)\right|^2dt.
\]

则

\[
 \boxed{\quad
 \mathcal M_{2,c}(N)^2
 =\frac1N\sum_{m,n\le N}\mu(m)\mu(n)
 \operatorname{sinc}\!\left(\frac{2\pi c(m-n)}N\right),
 \quad
 \operatorname{sinc}(z)=\frac{\sin z}{z},\quad \operatorname{sinc}(0)=1.
 \quad}
 \tag{3}
\]

确实，展开平方后只需使用
\[
 \frac1{2c}\int_{-c/N}^{c/N}e^{2\pi i(m-n)t}dt
 =\frac1N\operatorname{sinc}\!\left(\frac{2\pi c(m-n)}N\right).
\]
因此 \(q=2\) 局部矩是一个平移不变的加法差核。

本项目的 Lehmer 门则是
\[
 \boldsymbol\mu_N^{T}L_N\boldsymbol\mu_N,
 \qquad
 (L_N)_{m,n}=\frac{\min(m,n)}{\max(m,n)}
 =e^{-\lvert\log m-\log n\rvert},
 \tag{4}
\]
它是乘法比值核。两者甚至不能通过对角共轭直接互相转换：若
 \(L_{m,n}=d_md_nS_{m-n}\)，则由 \(L_{n,n}=1\) 可知
\(d_n^2S_0=1\)，从而 \(d_n\) 只能差一个符号；但
\(L_{n,n+1}=n/(n+1)\) 随 \(n\) 变化，而右侧的 \(S_{-1}\) 不变。这排除了
“只做逐点归一化/短块缩放即可把局部矩变成 Lehmer 能量”的捷径。

这不是一般算术 intertwiner 不存在的证明；它精确说明若要把 (3) 用于
\(4\)，必须额外构造把加法差变量 \(m-n\) 变成乘法对数差
\(\log(m/n)\) 的跨尺度 signed 映射。现有局部矩定理没有提供这个映射，
而短块展开 (1) 在完整 \(r\asymp X\) 区间留下的二次相位正是该缺口的有限核表现。

因此，本项目不把该结果升级为乘法能量界；剩余承重问题仍是
\(E_N(w)\ll N^{1+\varepsilon}\)，而该界本身与 RH 等价。

## 5. Jacobian 的定量损失

即使暂时忽略式 (2) 的二次相位，并把一个完整 dyadic 块
\(n=X+r\) 线性化为
\[
n^{i\tau}\approx X^{i\tau}e^{i\tau r/X},
\]
令
\[
\theta=\frac{\tau}{2\pi X},
\qquad d\tau=2\pi X\,d\theta,
\]
也有精确的尺度关系
\[
\int_{|\tau|\le T}
\left|\sum_{r\le X}a_r e^{i\tau r/X}\right|^2d\tau
=2\pi X
\int_{|\theta|\le T/(2\pi X)}
\left|\sum_{r\le X}a_r e^{2\pi i r\theta}\right|^2d\theta.
\tag{5}
\]
因此，若加法局部矩的自然未归一化规模是
\[
\int_{|\theta|\le c/X}
\left|\sum_{r\le X}a_r e^{2\pi i r\theta}\right|^2d\theta
\ll X\,\rho(X),
\]
其中 \(\rho(X)=X^{o(1)}\)（例如来自当前 averaged-Chowla 的对数节省），
那么对应的乘法块能量至多是
\[
\ll X^2\rho(X),
\]
而不是 \(X^{1+\varepsilon}\)。这一个 \(X\) 的损失不是估计粗糙造成的，
而是固定 \(\tau\)-窗口与半径 \(1/X\) 的加法弧之间的测度 Jacobian。

所以即使把加法局部矩结果与当前最强的移位平均输入无损拼接，得到的仍是
\(X^{2-o(1)}\) 级别；要达到本项目的 RH 门，必须额外消除这个 Jacobian
尺度，亦即构造真正的乘法比值 signed intertwiner。该补充不声称存在
一般性 no-go，只排除了“直接变量替换即可得到平方根能量”的具体捷径。

## 6. MRT 短区间指数和的量纲检查

MRT Theorem 1.7 还给出短区间加法指数和的平均绝对值界
\[
 \sup_{\alpha\in\mathbb T}\int_0^X
 \left|\sum_{x\le n\le x+H}\mu(n)e(\alpha n)\right|\,dx
 \ll XH\,\rho_7(X,H),
\tag{6}
\]
其中
\[
 \rho_7(X,H)=e^{-M/20}
 +\frac{\log\log H}{\log H}
 +\frac1{\log^{1/700}X},
\]
且 \(M\) 由同一 pretentious 距离定义；对 \(\mu\) 的零自由区下界可将
首项吸收到最后一个对数项中。来源为
<https://arxiv.org/html/1503.05121>，Theorem 1.7。

即使暂时假设 Mellin 相位在线性化短块上无误差，并且把 (6) 无损地采样到
\(X/H\) 个不交块，仍只能得到量纲
\[
 \sum_{\text{blocks}} |S_j(\alpha)|^2
 \le H\sum_{\text{blocks}}|S_j(\alpha)|
 \lesssim H\cdot X\rho_7(X,H).
\]
对全块和使用 Cauchy--Schwarz 后，
\[
 \left|\sum_{\text{blocks}}S_j(\alpha)\right|^2
 \le \frac XH\sum_{\text{blocks}}|S_j(\alpha)|^2
 \lesssim X^2\rho_7(X,H).
\tag{7}
\]
因此 Theorem 1.7 本身即使与一阶 Taylor transfer 完美拼接，也只恢复
\(X^{2-o(1)}\)；它没有产生 \(X^{1+\varepsilon}\) 的平方根门。要改善
(7)，必须控制不同短块之间的 signed cross terms，而这正是原始 Mellin
比值核的未闭合算术桥，不能由该定理的平均绝对值输入自动提供。
