> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 未滤波 Lehmer 能量界与 RH 的精确等价

日期：2026-08-17。

本 note 只讨论未滤波 Lehmer 核的正二次型，不把它误写成真正的指数尾门。
令
\[
L_N(m,n)=\frac{\min(m,n)}{\max(m,n)},\qquad
E_N^L:=\sum_{m,n\le N}\mu(m)\mu(n)L_N(m,n),
\]
以及
\[
B(x):=\sum_{n\le x}n\mu(n),\qquad
M(x):=\sum_{n\le x}\mu(n).
\]

## 定理

以下两条命题等价：

1. 黎曼猜想成立；
2. 对每个 \(\varepsilon>0\)，
   \[
   E_N^L\ll_\varepsilon N^{1+\varepsilon}\qquad(N\ge2).
   \tag{1}
   \]

## 望远镜恒等式

note 346 的有限恒等式给出
\[
E_N^L
=\frac{B(N)^2}{N^2}
+\sum_{n<N}B(n)^2
  \left(\frac1{n^2}-\frac1{(n+1)^2}\right).
\tag{2}
\]
两项均非负，因此
\[
|B(N)|\le N\sqrt{E_N^L}.
\tag{3}
\]

## (1) 蕴含 RH

假设 (1)。由 (3)，对任意固定 \(\eta>0\)，取 (1) 中的
\(\varepsilon=2\eta\)，得到
\[
B(N)\ll_\eta N^{3/2+\eta}.
\tag{4}
\]
对任意序列 \(b_n=n\mu(n)\)，其部分和 \(B(n)\) 的离散 Abel 反演是
\[
M(N)=\sum_{n\le N}\frac{b_n}{n}
=\frac{B(N)}N
+\sum_{n<N}B(n)\left(\frac1n-\frac1{n+1}\right).
\tag{5}
\]
将 (4) 代入 (5) 得
\[
M(N)\ll_\eta N^{1/2+\eta}.
\tag{6}
\]
于是部分和公式
\[
\frac1{\zeta(s)}
=s\int_1^\infty M(x)x^{-s-1}\,dx
\tag{7}
\]
可由 \(\Re s>1\) 延拓为 \(\Re s>1/2\) 的全纯函数。故 \(\zeta\) 在
\(\Re s>1/2\) 无非平凡零点；由函数方程的对称性，RH 成立。

## RH 蕴含 (1)

在 RH 下，经典部分和估计给出对任意 \(\eta>0\)
\[
M(x)\ll_\eta x^{1/2+\eta}.
\tag{8}
\]
另一个 Abel 恒等式为
\[
B(N)=N M(N)-\sum_{n<N}M(n),
\tag{9}
\]
从而 \(B(N)\ll_\eta N^{3/2+\eta}\)。代入 (2)，并使用
\(n^{-2}-(n+1)^{-2}\le2n^{-3}\)，得到
\[
E_N^L\ll_\eta N^{1+2\eta}.
\]
将 \(\eta\) 换成 \(\varepsilon/2\)，即得 (1)。

## 与真正指数尾门的区别

指数尾门不是 \(E_N^L\)，而是
\[
\frac{I_N}{\pi}
=E_N^L-
\left(\sum_{n\le N}\frac{\mu(n)}n\right)^2.
\tag{10}
\]
因此 (1) 是一个更强的正能量界；它与 RH 等价，但不能由
\(I_N\ll N^{1+\varepsilon}\) 自动反推出，因为 (10) 中的 rank-one 项可能发生抵消。
反过来，note 347 已给出真正尾门的平方根级界本身与 RH 等价。

结论是：Lehmer 矩阵的未滤波正能量已经完全可以用一个 RH 等价的
\(M_1(x)=B(x)\) 加权平方均方来刻画；尚未解决的不是望远镜代数，而是无条件证明
该均方界，或直接控制 (10) 中保留 rank-one 抵消的 signed 二次型。
