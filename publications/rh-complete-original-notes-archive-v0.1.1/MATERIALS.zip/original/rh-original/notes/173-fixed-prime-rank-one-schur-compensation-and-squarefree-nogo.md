> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定 prime 的 rank-one Schur 补偿与 squarefree 反射 no-go

日期：2026-08-15。

本 note 只处理一个固定 prime/reflection edge，以及一个固定 squarefree divisor
格。目的不是给出无限维正性，而是把“archimedean/prime signed Schur 补偿”
压缩为可检验的最小不等式，并说明 rank-one 的适用边界。

## 1. 固定 prime 的二维判据

设 ℓ 为固定 prime，记

\[
p_\ell=\frac{\Lambda(\ell)}{\sqrt\ell}
\]

（对 prime 即 \(\log\ell/\sqrt\ell\)）。在一个 reflected pair
\(\{e_1,e_2\}\) 上，prime block 的 signed 部分写成

\[
\sigma p_\ell J,
\qquad
J=\begin{pmatrix}0&1\\1&0\end{pmatrix},
\qquad \sigma\in\{+1,-1\}.
\]

假设旧 archimedean/prime 块已经通过 true Schur 消元给出正对角
\(D=\operatorname{diag}(d_1,d_2)\)，其中 \(d_1,d_2>0\)。向该块加入一个
archimedean rank-one counterterm \(\alpha uu^*\)，\(\alpha\ge0\)，
\(u=(u_1,u_2)^T\)，则

\[
M_\alpha=D+\sigma p_\ell J+\alpha uu^*.
\]

其两个对角元始终为正，因而 \(M_\alpha\succeq0\) 当且仅当行列式非负：

\[
\det M_\alpha
 =d_1d_2-p_\ell^2+\alpha\,\kappa_\sigma(u),
\tag{1}
\]

其中

\[
\boxed{\kappa_\sigma(u)=d_2|u_1|^2+d_1|u_2|^2
       -2\sigma p_\ell\operatorname{Re}(u_1\overline{u_2}).}
\tag{2}
\]

因此当 \(p_\ell^2>d_1d_2\) 时，存在 rank-one 正补偿的充要条件是

\[
\kappa_\sigma(u)>0,
\qquad
\boxed{\alpha\ge
\frac{p_\ell^2-d_1d_2}{\kappa_\sigma(u)}}.
\tag{3}
\]

若 \(\kappa_\sigma(u)\le0\)，沿该方向增加任意正的 \(\alpha\) 都不能
修复负行列式。这是固定 prime 最薄的可证 rank-one 判据；不能以
\(\|\sigma p_\ell J\|=p_\ell\) 的标量范数替代 (2)。

特别地，当 \(d_1=d_2=d<p_\ell\) 时，负 eigendirection 是
\(u=e_-=(1,-\sigma)^T/\sqrt2\)，并且 (3) 简化为

\[
\alpha\ge p_\ell-d.
\tag{4}
\]

相反，取正 eigendirection \(e_+=(1,\sigma)^T/\sqrt2\) 时
\(\kappa_\sigma(e_+)=d-p_\ell<0\)，任何正 rank-one 都不能补偿负方向。
这给出了“必须识别 signed reflection mode”的精确要求。

若直接使用 note 171 的单侧 detector，而不是给两个 reflected pair 都保留
正对角底，取两个不同 primes \(\ell<r\) 并令 \(X=\ell r\)。在 divisor
pair \(\{1,r\}\) 上，单侧矩阵的 principal block 是

\[
H_{X;\{1,r\}}=
\begin{pmatrix}P(X)&P(\ell)\\P(\ell)&0\end{pmatrix}.
\tag{4a}
\]

因此对一个 rank-one archimedean counterterm \(\alpha uu^*\)，半正定的充要
条件（假设 \(P(X)\ge0\)）为

\[
u_2\ne0,\qquad
\kappa_{X,\ell}(u):=P(X)|u_2|^2
 -2P(\ell)\operatorname{Re}(u_1\overline{u_2})>0,
\qquad
\alpha\ge\frac{P(\ell)^2}{\kappa_{X,\ell}(u)}.
\tag{4b}
\]

若 \(P(X)\) 或 \(P(\ell)\) 的符号不预先固定，则还需把两个对角元
\(P(X)+\alpha|u_1|^2\) 与 \(\alpha|u_2|^2\) 一并检查；(4b) 是 detector
常见的非负取值情形。它把 note 171 的严格负子式精确转成了一个可证的
rank-one 补偿门，同时显示补偿向量必须在边界 divisor 方向 \(e_2\) 上有
非零分量。对常见 detector 的 \(P(1)=0\)，单独的 \(X=\ell\) 两点矩阵
并不产生这个负子式；真正的单侧边界障碍从至少两个 prime 的
\(X=\ell r\) principal block 开始。

注意 (4a)--(4b) 只是在完整矩阵中的一个二维必要局部门；即使该 principal
block 被一个 rank-one 项修好，\(k=2\) 的完整正 Fourier-symbol 反射格仍有
两个负方向，不能由同一个 rank-one 项整体正化。这正是局部可补偿与全格
Schur no-go 的区别。

对 \(\ell=11\)，

\[
p_{11}=\frac{\log11}{\sqrt{11}}
=0.7229926278581\ldots.
\]

因此 note 165 的 \(n=11\) 新环带若只留下标量底 \(dI\)，所需的负 parity
补偿至少是 \(p_{11}-d\)；已有端点正性并不提供这个 \(d\)，也没有给出
补偿向量与负 parity 的重叠。

## 2. 一般 true-Schur 的 resolvent 形式

把旧尺度和所有已处理的 signed blocks 记为 \(B\)，新 prime pair 加入后，
再把一个可能的 rank-one archimedean counterterm 单独留出：

\[
M=B+\sigma p_\ell J+\alpha uu^*.
\]

若 \(M_0:=B+\sigma p_\ell J\) 可逆且恰有一个负方向，则 rank-one 更新公式给出

\[
\boxed{
M\succeq0
\iff
u^*M_0^{-1}u<0
\quad\text{and}\quad
\alpha\ge -\frac1{u^*M_0^{-1}u}.}
\tag{5}
\]

这与 (1)--(3) 完全等价（在二维情形可直接用 determinant lemma 验证）。
式 (5) 才是 infinite/large block 中应认证的最小接口：需要计算同一个
signed residual 上的 boundary resolvent quadratic form，而不是分别估计
\(B\) 与 \(p_\ell J\) 的范数。若 \(u^*M_0^{-1}u\ge0\)，rank-one
正项无法消掉负 inertia；若 \(M_0\) 有至少两个负方向，则一条 rank-one
更新也不可能使其半正定。

在尺度块记号下，若

\[
M_0=D_b^\sigma-(C_b^\sigma)^*(A_*^\sigma)^{-1}C_b^\sigma,
\]

则 (5) 正是所需的 signed Schur 补偿条件。note 165 目前只知道
\(A_*^\sigma>0\)，并未给出 \(M_0^{-1}\) 的负方向或 (5) 的严格下界。

## 3. 固定 squarefree divisor 格的严格 no-go

令 \(X\) 为非平方 squarefree 整数，\(k=\omega(X)\)，\(D(X)\) 为其 divisor
格，且 \(G_{a,b}=p(\log(a/b))\) 的 Fourier symbol 非负并在正测度集上严格
为正。complement reflection \(R_X(a)=X/a\) 给出

\[
H_X=G_XR_X,
\qquad
\operatorname{inertia}(H_X)=
\bigl(2^{k-1},2^{k-1},0\bigr).
\tag{6}
\]

若用任意 Hermitian 修正 \(F\) 令 \(H_X+F\succeq0\)，惯性扰动定理给出

\[
\boxed{\operatorname{rank}F\ge 2^{k-1}.}
\tag{7}
\]

这里没有要求 (F\succeq0)：对任意 Hermitian rank-(r) 扰动，负惯性至多
改变 (r)；因此 (7) 也排除用一个带符号的 rank-one Schur 项来同时支付
多个反射负 parity。

所以：

* \(k=1\)（一个固定 prime，\(X=\ell\)）时只有一个负方向，rank-one
  补偿在代数上可能，且由 (3) 或 (5) 精确决定；
* \(k\ge2\) 时，任何单个 archimedean rank-one、固定 rank-
  \(r<2^{k-1}\) 的 Feshbach 修正都不可能把完整 reciprocal divisor block
  变成 PSD。

这不是数值反例，而是有限矩阵的严格惯性 no-go。它只针对保留完整 reciprocal
Hankel 核与所有 divisor modes 的正化尝试；若目标只控制一个 Möbius 向量，
则可以牺牲其余负 parity，但那已经不是完整 Weil block 的半正定命题。

## 4. 结论

固定 prime 的最小可转移桥是

\[
\text{signed residual }M_0
\longrightarrow
u^*M_0^{-1}u<0,
\quad
\alpha\ge-1/(u^*M_0^{-1}u),
\]

二维时即 (2)--(3)。现有端点证书没有计算这一 boundary-resolvent quantity，
故不能声称已经完成 n=11 的补偿。对固定 squarefree \(X\) 的完整 divisor 格，
负惯性则给出 rank-one 的严格 no-go（除单 prime 情形外）。
