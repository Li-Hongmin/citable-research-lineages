> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 全 Fourier 包形成有限 Ramanujan 原函数框架

日期与检索截止：2026-08-13。

依赖：[note 065](065-barban-vehov-hminus1-obstruction-and-weak-mertens-bridge.md)、
[note 069](069-gcd-completion-cancels-the-fixed-slice-antidiagonal.md)、
[note 076](076-cutoff-fourier-average-leaves-farey-near-collisions.md)、
[note 077](077-reciprocal-packet-bound-is-rh-strength-but-fixed-band-observability-fails.md)。

## 1. 弄清问题

逐 \(h\) 正估计已被 note 077 压到 RH 等强原子。现在不固定 \(h\)，而先把所有相同
约分频率

\[
\frac hd=\frac aq,
\qquad(a,q)=1
\tag{1}
\]

完全聚合。本 note 的目标是保留全部跨 \(h\) 抵消，并判定有限 Ramanujan 正交是否控制
所得对象。

## 2. 拟定计划

\[
\text{约分 Fourier 系数}
\to
\text{primitive numerator 包}
\to
\text{Ramanujan 跳跃}
\to
\text{精确单位格能量}
\to
\text{frame defect}.
\tag{2}
\]

## 3. 实现计划

置

\[
L:=\log N,
\qquad
\lambda_{d,N}:=\frac{\mu(d)}L\log\frac Nd,
\tag{3}
\]

\[
\beta(x):=\{x\}-\frac12
\quad(x\notin\mathbb Z),
\qquad
\beta(n):=0,
\tag{4}
\]

并定义 Alterman 型 Möbius 均值

\[
\check m_q(U):=
\sum_{\substack{r\le U\\(r,q)=1}}
\frac{\mu(r)}r\log\frac Ur,
\qquad
A_{q,N}:=\frac{\mu(q)}L\check m_q(N/q).
\tag{5}
\]

### 3.1 约分频率的精确系数

令

\[
S_N(y):=\sum_{d\le N}\lambda_{d,N}\beta(y/d).
\tag{6}
\]

在 \(L^2_{\mathrm{loc}}\) 中，

\[
\beta(x)=-\sum_{h\ne0}\frac{e(hx)}{2\pi ih}.
\tag{7}
\]

若 \(h/d=a/q\) 已约分，则唯一地

\[
d=qr,
\qquad h=ar.
\tag{8}
\]

故频率 \(a/q\) 的全部表示之和为

\[
\begin{aligned}
\widehat S_N(a/q)
&=-\frac1{2\pi ia}
\sum_{r\le N/q}\frac{\lambda_{qr,N}}r\\
&=\boxed{
-\frac{\mu(q)}{2\pi iaL}\check m_q(N/q)}.
\end{aligned}
\tag{9}
\]

当 \(q\) 非平方自由时两边均为 \(0\)；当 \(q\) 平方自由时用

\[
\mu(qr)=\mu(q)\mu(r)\mathbf1_{(q,r)=1}
\tag{10}
\]

即得。

### 3.2 primitive sawtooth 是 Ramanujan sum 的原函数

定义

\[
\mathfrak B_q(y):=
-\sum_{\substack{a\ne0\\(a,q)=1}}
\frac{e(ay/q)}{2\pi ia}.
\tag{11}
\]

由 (9)，

\[
\boxed{
S_N(y)=\sum_{q\le N}A_{q,N}\mathfrak B_q(y).
}
\tag{12}
\]

对 numerator 的互素条件作 Möbius 投影：

\[
\boxed{
\mathfrak B_q(y)=
\sum_{\ell\mid q}\frac{\mu(\ell)}\ell
\beta\!\left(\frac{\ell y}{q}\right).
}
\tag{13}
\]

令

\[
c_q(n):=\sum_{a\bmod q}^{*}e(an/q)
\tag{14}
\]

为 Ramanujan sum。Poisson 求和给出分布恒等式

\[
\boxed{
\mathfrak B_q'
=\mathbf1_{q=1}\,dy
-\frac1q\sum_{n\in\mathbb Z}c_q(n)\delta_n.
}
\tag{15}
\]

因此 \(q>1\) 时，\(\mathfrak B_q\) 在每个单位格上为常数。定义

\[
P_q(n):=\mathfrak B_q(n+u),
\qquad0<u<1.
\tag{16}
\]

则

\[
\boxed{
P_q(n)-P_q(n-1)=-\frac{c_q(n)}q.
}
\tag{17}
\]

若 \(0\le n<q\)，还可写成

\[
P_q(n)
=-\frac{\varphi(q)}{2q}
-\frac1q\sum_{m=1}^{n}c_q(m),
\tag{18}
\]

再以 \(q\) 为周期延拓。

### 3.3 首壳能量的最短有限恒等式

令

\[
D_N(y):=1+\sum_{d\le N}\lambda_{d,N}\{y/d\},
\qquad
\gamma_N:=1+\frac12\sum_{d\le N}\lambda_{d,N}.
\tag{19}
\]

在 \(y=n+u,\ 0<u<1\) 上，

\[
\boxed{
D_N(n+u)=
\gamma_N+A_{1,N}\left(u-\frac12\right)
+\sum_{q=2}^{N}A_{q,N}P_q(n).
}
\tag{20}
\]

由于 \(u-1/2\) 在 \((0,1)\) 上均值为零，

\[
\boxed{
I_N:=\int_N^{2N}|D_N(y)|^2dy
=\frac N{12}A_{1,N}^2
+\sum_{n=N}^{2N-1}
\left|\gamma_N+\sum_{q=2}^{N}A_{q,N}P_q(n)\right|^2.
}
\tag{21}
\]

这是一条只含有限和的精确恒等式，并已经包含所有不同 \(h\)-packet 之间的抵消。

### 3.4 它恰是 Barban--Vehov 有限 Ramanujan 展开的离散原函数

定义

\[
V_N(n):=\sum_{\substack{d\mid n\\d\le N}}\lambda_{d,N}.
\tag{22}
\]

由

\[
\sum_{q\mid d}c_q(n)=d\mathbf1_{d\mid n}
\tag{23}
\]

得到 Coppola--Murty 型有限 Ramanujan 展开

\[
\boxed{
V_N(n)=\sum_{q\le N}\frac{A_{q,N}}q c_q(n).
}
\tag{24}
\]

更直接地，系数满足 Möbius 三角化

\[
\boxed{
\frac{A_{q,N}}q
=\sum_{\substack{d\le N\\q\mid d}}\frac{\lambda_{d,N}}d.
}
\tag{25}
\]

若

\[
G_N(n):=\sum_{q=2}^{N}A_{q,N}P_q(n),
\tag{26}
\]

则 (17)、(24) 给出

\[
\boxed{
G_N(n)-G_N(n-1)=A_{1,N}-V_N(n).
}
\tag{27}
\]

故全 \(h\) 合包并未消去旧障碍，而是给出了它的自然算术坐标：

\[
\boxed{
\text{finite Ramanujan }H^0
\xrightarrow{\ \Delta^{-1}\ }
\text{primitive }H^{-1}.
}
\tag{28}
\]

### 3.5 Alterman 的 \(\varphi(q)\) 权与 primitive 的 \(J_2(q)\) 权

有限 Ramanujan 正交给

\[
Q_1(N)
:=\sum_{q\le N}\varphi(q)
\left|\frac{A_{q,N}}q\right|^2
=\frac{\Sigma_1(N)}{L^2}
=\frac1L+O(L^{-2}).
\tag{29}
\]

但 primitive 原函数的完整周期范数为

\[
\boxed{
\frac1q\sum_{n\bmod q}|P_q(n)|^2
=\frac{J_2(q)}{12q^2},
}
\tag{30}
\]

其中

\[
J_2(q)=q^2\prod_{p\mid q}(1-p^{-2}).
\tag{31}
\]

因此

\[
\boxed{
Q_2(N)
:=\sum_{q\le N}J_2(q)
\left|\frac{A_{q,N}}q\right|^2.
}
\tag{32}
\]

两种权相差 Dedekind psi：

\[
\frac{J_2(q)}{\varphi(q)}
=q\prod_{p\mid q}\left(1+\frac1p\right)
=\psi(q).
\tag{33}
\]

所以 Alterman 的 \(H^0\) 恒等式不能直接控制 primitive \(H^{-1}\) 能量。

不过对角项可比 note 069 再加强。由

\[
|\check m_q(x)|
\le\sum_{r\le x}\frac{\log(x/r)}r
\ll1+\log^2x
\tag{34}
\]

及 \(J_2(q)/q^2\le1\)，

\[
\begin{aligned}
Q_2(N)
&\ll\frac1{L^2}\sum_{q\le N}
\left(1+\log^4\frac Nq\right)\\
&\ll\boxed{\frac N{L^2}}.
\end{aligned}
\tag{35}
\]

故

\[
\boxed{
\frac N{12}Q_2(N)\ll\frac{N^2}{\log^2N}=o(N^2).
}
\tag{36}
\]

完整周期对角严格安全。

### 3.6 精确零模与 incomplete-frame defect

令

\[
m_{q,N}:=\frac1N\sum_{n=N}^{2N-1}P_q(n),
\qquad
\Gamma_N:=\gamma_N+\sum_{q=2}^{N}A_{q,N}m_{q,N},
\tag{37}
\]

\[
\widetilde K_N(q,r):=
\sum_{n=N}^{2N-1}
(P_q(n)-m_{q,N})(P_r(n)-m_{r,N}),
\tag{38}
\]

\[
\widetilde E_N(q,r):=
\widetilde K_N(q,r)
-N\delta_{q,r}\frac{J_2(q)}{12q^2}.
\tag{39}
\]

由常数与中心化向量正交，(21) 化为

\[
\boxed{
I_N
=N|\Gamma_N|^2
+\frac N{12}Q_2(N)
+\sum_{q,r=2}^{N}
A_{q,N}A_{r,N}\widetilde E_N(q,r).
}
\tag{40}
\]

因此不能把 \(\gamma_N\) 单独支付后忽略；正确零模是 \(\Gamma_N\)，它已包含所有
primitive packet 在当前不完整壳上的均值。

若不作壳中心化，则

\[
K_N(q,r):=\sum_{n=N}^{2N-1}P_q(n)P_r(n)
\tag{41}
\]

有精确 Farey--cotangent 表示

\[
\boxed{
K_N(q,r)=\frac1{qr}
\sum_{a\bmod q}^{*}\sum_{b\bmod r}^{*}
\frac{\mathcal D_N(a/q-b/r)}
{(1-e(-a/q))(1-e(b/r))},
}
\tag{42}
\]

\[
\mathcal D_N(\theta):=\sum_{n=N}^{2N-1}e(n\theta).
\tag{43}
\]

故全部 numerator 合包允许抵消，却没有自动删除 note 076 的 Farey near-collisions。

### 3.7 不存在通用 primitive-frame 上界

对素数 \(p\)，(18) 简化为

\[
\boxed{
P_p(n)=\frac{n\bmod p}{p}-\frac12+\frac1{2p}.
}
\tag{44}
\]

取所有 \(p\in[7N/8,N]\)。若

\[
N\le n\le17N/16,
\tag{45}
\]

则 \(p<n<2p\)，从而 \(P_p(n)\le-c\) 对某个绝对 \(c>0\) 一致成立。由素数定理，

\[
\sum_{n=N}^{17N/16}
\left|\sum_{7N/8\le p\le N}P_p(n)\right|^2
\gg\frac{N^3}{\log^2N}.
\tag{46}
\]

而相应完整周期对角只有

\[
N\sum_{7N/8\le p\le N}\frac{J_2(p)}{12p^2}
\asymp\frac{N^2}{\log N}.
\tag{47}
\]

故 incomplete Gram 比对角至少放大 \(N/\log N\)。任何对任意系数成立的普通
frame/large-sieve 上界仍损失近一整幂；必须使用 \(A_{q,N}\) 的 Möbius 符号。

### 3.8 最低频的精确离散谱形式

令

\[
v_j:=G_N(N+j),
\qquad0\le j<N,
\tag{48}
\]

并记

\[
r_j:=v_j-v_{j-1}
=A_{1,N}-V_N(N+j)
\qquad(1\le j<N).
\tag{49}
\]

离散一阶差分在常数正交补上的奇异值为

\[
\sigma_k=2\sin\frac{\pi k}{2N},
\qquad1\le k<N.
\tag{50}
\]

故对相应正交基 \(u_k\)，

\[
\boxed{
\sum_{j=0}^{N-1}|v_j|^2
=N|\bar v|^2
+\sum_{k=1}^{N-1}
\frac{|\langle r,u_k\rangle|^2}
{4\sin^2(\pi k/(2N))}.
}
\tag{51}
\]

困难严格位于 \(k\ll N\)，因为

\[
4\sin^2\frac{\pi k}{2N}\asymp\frac{k^2}{N^2}.
\tag{52}
\]

普通 \(H^0\) 界

\[
\|r\|_2^2\ll\frac N{\log N}
\tag{53}
\]

经 Poincaré 只给

\[
\|v-\bar v\|_2^2\ll\frac{N^3}{\log N},
\tag{54}
\]

比目标 \(N^2\) 差 \(N/\log N\)。

## 4. 回顾与下一原子

由 (36)、(40)，新的严格目标为

\[
\boxed{
\sum_{Y<N\le2Y}
\left[
N|\Gamma_N|^2
+\sum_{q,r=2}^{N}
A_{q,N}A_{r,N}\widetilde E_N(q,r)
\right]
\ll_\varepsilon Y^{3+\varepsilon}.
}
\tag{55}
\]

这里第二项有符号；若逐项取绝对值，(46) 再现所缺的一整幂。下一步必须寻找

\[
\boxed{
\text{Möbius finite-Ramanujan coefficients}
\quad\text{与}\quad
\text{centered primitive defect}
\quad\text{之间的联合消去}.
}
\tag{56}
\]

历史边界：

- Coppola--Murty 2018 的 (12)--(13) 直接支持有限 Ramanujan 系数公式，并在
  Section 6 明确量化普通 Farey spacing 的 level-\(1/2\) barrier；
- Zuniga--Alterman 2022 控制 (29)，不控制乘上 \(\psi(q)\) 后的 (32) 或原函数 defect；
- Davenport 1937 是 Möbius--Bernoulli 乘法 dilation 的历史锚点；当前 reciprocal dilation
  在约分后保留 \(\check m_q(N/q)\)，不能直接塌缩；
- Bettin--Conrey 的 cotangent reciprocity 是 (42) 的自然语言，但现有完整模周期互反式
  不直接估计两模数 incomplete Gram。
- Motohashi 1977 的 Ramanujan-sensitive large sieve 仍保留 length-plus-modulus-square
  尺度；Ramaré 2007 的 Farey 矩阵谱矩处理等权频率，并明确指出非均匀权更困难。二者在
  \(Q=N\) 的当前 dense regime 均不控制特殊向量 \(A_{q,N}\)。

本 note 新增 (9)、(12)--(21)、(30)--(40) 的完整 numerator 聚合、加强对角界与精确
零模分解，以及 (44)--(47) 的通用 primitive-frame 反例。它没有证明 (55)，因而尚未证明
RH。
