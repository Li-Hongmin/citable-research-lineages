> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 单侧边界 ordinary Toeplitz 的二维负子式

日期：2026-08-15。

本 note 给出一个不依赖 Fourier 数值的有限障碍。它补充
[note 171](171-one-sided-detector-half-lattice-boundary-identity.md) 的半格恒等式和
[note 174](174-signed-boundary-toeplitz-has-mellin-symbol-and-unavoidable-negative-edge.md)
的符号分析：只要 \(X=2p\)（\(p>2\) 为奇素数），实际 boundary Toeplitz
块在指标 \(\{1,2\}\) 上已经严格不定。

## 1. 两点主块

令 \(P_m(y)=\sum_{c\le y}V_m(c/y)\)，并作 note 171 的单侧延拓

\[
 p_m(t)=\begin{cases}P_m(e^t),&t\ge0,\\0,&t<0,\end{cases}
 \qquad
 g_m(t)=\frac{p_m(t)+p_m(-t)}2 .
\]

对 \(X=2p\)，有

\[
 L_X=\{d:d\mid X,\ d<\sqrt X\}=\{1,2\}.
\]

在完整 divisor 格或其半格上，ordinary（差坐标）Toeplitz 矩阵是

\[
 T_X(a,b)=g_m(\log(a/b)).
\]

detector 的端点平坦性给出 \(P_m(1)=V_m(1)=0\)。而已严格证明的局部结论
\(P_m(y)=V_m(1/y)>0\)（\(1\le y\le2\)）给出

\[
 P_m(2)=V_m(1/2)>0.
\]

因此

\[
 g_m(0)=P_m(1)=0,
 \qquad
 g_m(\log2)=\frac{P_m(2)}2>0,
\]

从而两点主块精确为

\[
 \boxed{
 T_X|_{\{1,2\}}
 =\begin{pmatrix}
 0&A_m\\ A_m&0
 \end{pmatrix},
 \qquad A_m:=\frac{P_m(2)}2>0 .}
 \tag{1}
\]

特别地，

\[
 \det T_X|_{\{1,2\}}=-A_m^2=-\frac{P_m(2)^2}{4}<0.
 \tag{2}
\]

故 ordinary boundary kernel 既不是 PSD，也不能直接解释为一个正 Gram。这个
结论只使用 \(P_m(1)=0\) 和 \(P_m(2)>0\)，没有使用 Mellin/Fourier 变换、数值
频率扫描或 RH 假设。

若把 Möbius 符号吸收到基底中，半格二次型对应的矩阵是

\[
 \operatorname{diag}(1,-1)T_X|_{\{1,2\}}
 \operatorname{diag}(1,-1)
 =\begin{pmatrix}0&-A_m\\-A_m&0\end{pmatrix},
\]

其惯性仍为 \((1,1,0)\)，且

\[
 G_X=\sum_{a,b\in L_X}\mu(a)\mu(b)g_m(\log(a/b))=-P_m(2)<0.
 \tag{3}
\]

这把 note 174 中 \(X=2p\) 的负边界值提升为一个显式的二维负方向。

## 2. 奇异二维块的 rank-one 补偿门

该边界块的两个对角元为零，故不能直接套用带正对角假设的普通二维
determinant 公式。令 \(u=(u_1,u_2)^T\)，
\(\alpha\ge0\)，考虑一个正 rank-one 补偿

\[
 M_\alpha=T_X|_{\{1,2\}}+\alpha uu^* .
\]

记 \(A=A_m>0\)。其对角元非负，而行列式精确为

\[
 \det M_\alpha
 =-A^2-2A\alpha\,\operatorname{Re}(u_1\overline{u_2}).
 \tag{4}
\]

因此

\[
 \boxed{
 M_\alpha\succeq0
 \iff
 \operatorname{Re}(u_1\overline{u_2})<0,
 \quad
 \alpha\ge
 \frac{A}{-2\operatorname{Re}(u_1\overline{u_2})}.}
 \tag{5}
\]

若 \(u\) 归一化，则 \(-2\operatorname{Re}(u_1\overline{u_2})\le1\)，所以任何
二维 rank-one 修复都满足

\[
 \alpha\ge A=\frac{P_m(2)}2,
 \tag{6}
\]

等号由负 parity 向量
\(u=(1,-1)/\sqrt2\)（或其相位等价物）达到。若补偿向量与该负方向正交，
即 \(\operatorname{Re}(u_1\overline{u_2})\ge0\)，任意大小的正 rank-one
项都不能修复该块。

## 3. 对 intertwiner 的最小含义

这不是说一个完整 Weil 算子不能有其它 signed/archimedean 块；它只排除
以下未经证明的替代：把单侧 ordinary boundary kernel 本身当作 PSD Toeplitz
Gram，或用一个没有负 parity 重叠的正 rank-one 标量项替代真实的
prime--archimedean cross block。

因此若 A 线要把该边界块嵌入 true-Schur/Feshbach 结构，至少需要证明下列其中
一个有限命题：

1. 映射后的补偿向量在 \(\{1,2\}\) 块满足
   \(\operatorname{Re}(u_1\overline{u_2})<0\)，并给出 (5) 的 resolvent 大小；或
2. 其它 signed cross block 在同一二维压缩上产生等价的负-parity Schur 项。

仅有 ordinary Toeplitz 的频率符号、\(P_m(y)\ge0\) 的点态信息，或一个未识别
方向的正 rank-one 更新，都不足以闭合该接口。

本文只证明有限二维负子式及其补偿条件，不声称 RH。

