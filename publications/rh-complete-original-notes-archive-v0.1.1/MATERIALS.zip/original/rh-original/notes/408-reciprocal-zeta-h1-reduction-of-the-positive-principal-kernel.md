> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 408. 齐次正主核的 reciprocal-$\zeta$ Mellin-$H^1$ 精确化

## 1. 从主核因子化到显式系数列

note 407 给出齐次主核的严格符号

$$
\widehat w(\xi)=\frac{|2-2^{i\xi}|^2}{1+\xi^2}.
$$

因此，对截断 Möbius 系数 $c_n=\mu(n)\mathbf 1_{n\le Y}$，主部二次型为

$$
Q_w(\mu_{\le Y})=\frac{1}{2\pi}\int_{\mathbb R}
\frac{\left|(2-2^{i\xi})\sum_{n\le Y}\mu(n)n^{i\xi}\right|^2}{1+\xi^2}\,d\xi.
\tag{1}
$$

把第二项重新编号：

$$
2^{i\xi}\sum_{n\le Y}\mu(n)n^{i\xi}
=\sum_{2\mid m\le 2Y}\mu(m/2)m^{i\xi}.
$$

定义

$$
a_m^{(Y)}=2\mu(m)\mathbf 1_{m\le Y}
-\mathbf 1_{2\mid m}\mu(m/2)\mathbf 1_{m\le 2Y},
\qquad 1\le m\le 2Y,
\tag{2}
$$

便有精确恒等式

$$
(2-2^{i\xi})\sum_{n\le Y}\mu(n)n^{i\xi}
=\sum_{m\le 2Y}a_m^{(Y)} m^{i\xi}.
\tag{3}
$$

故

$$
Q_w(\mu_{\le Y})=\frac{1}{2\pi}\int_{\mathbb R}
\frac{\left|\sum_{m\le 2Y}a_m^{(Y)} m^{i\xi}\right|^2}{1+\xi^2}\,d\xi.
\tag{4}
$$

## 2. Dirichlet 级数的精确乘子

相应的无限系数列 $a_m=2\mu(m)-\mathbf 1_{2\mid m}\mu(m/2)$ 的 Dirichlet 生成函数在 $\Re s>1$ 为

$$
A(s):=\sum_{m\ge1}\frac{a_m}{m^s}
=\frac{2-2^{-s}}{\zeta(s)}.
\tag{5}
$$

这不是一般的正系数均方问题，而是一个带显式 dyadic 高通因子的 reciprocal-$\zeta$ Dirichlet 多项式。式 (4) 使用的是其有限、带共同上限 $Y$ 的 dyadic 截断，而不是把无限级数逐项截到 $2Y$。

这一步把 note 407 的剩余问题精确压缩为：证明

$$
\int_{\mathbb R}\frac{|A_Y(i\xi)|^2}{1+\xi^2}\,d\xi
\ll_\varepsilon Y^{1+\varepsilon},
\qquad A_Y(s):=\sum_{m\le 2Y}\frac{a_m^{(Y)}}{m^s},
\tag{6}
$$

并同时控制 note 407 的 $O(Y)$ 齐次核误差及 (5) 的 moving-cutoff 端点尾。

## 3. 算术含义与当前边界

式 (5) 说明主核的正性已经完全解决；真正未解的是 reciprocal-$\zeta$ 截断多项式的 signed cancellation。普通的 Dirichlet 多项式均方或逐项绝对值估计只能给 $Y^2$ 量级，不能产生 (6) 所需的平方根级 $Y^{1+\varepsilon}$。

另一方面，note 402--405 已给出：对 $P(z)=1-2z$，这种 $Y^{1+\varepsilon}$ 尾能量界与 RH 等价，并且由 Hardy 的临界线零点无穷性知幂次不能低于 $Y^1$。因此 (6) 不是一个可由主核 PSD 自动推出的技术性估计，而是同一 RH-strength 算术门的显式 reciprocal-$\zeta$ 版本。

## 4. 可复核的小规模恒等式

式 (3) 只使用偶数指标的重编号，不含渐近或数值假设。直接展开 $Y=1,2,3$ 即得

$$
(a_1,a_2,a_3,a_4,a_5,a_6)=(2,-3,-2,1,-2,3).
$$

其中超出 $2Y$ 的项按定义截断。该有限系数列可作为后续任何均方/谱估计的固定输入；不能把 $a_m^{(Y)}$ 当作独立 Möbius 样本，也不能从 $\sum|a_m^{(Y)}|^2\asymp Y$ 反推出 (6)。

**结论。** note 407 的齐次主核给出严格 PSD 与显式乘子

$$
\frac{2-2^{-s}}{\zeta(s)}.
$$

当前唯一未闭合的实质门，是该 reciprocal-$\zeta$ 有限多项式的 $H^1$ 平方根级估计，以及它与 moving-cutoff 端点尾的 signed 耦合。
