> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Jacobian 伸缩在 \(1<a<4/3\) 对整个 detector 层级产生负尾

日期：2026-08-16。

## 命题

令 \(V_m\) 为统一 Euler--beta detector 层级，取 orientation 使
\(V_m(u)\ge0\) 于局部正区间。定义测度保持的 Jacobian 伸缩

\[
 \widetilde V_{m,a}(u):=a\,u^{a-1}V_m(u^a),\qquad a>0.
\]

则对每个 \(m\ge1\) 和每个

\[
 1<a<\frac43,
\]

存在任意大的整数 \(N\) 使

\[
 \sum_{n=1}^{N}\widetilde V_{m,a}(n/N)<0.
\]

所以这一区间的伸缩不可能保持全半轴 periodization 正性。

## 左端首项

由统一算子表示

\[
 V_m=C_m^{-1}(\Theta-1)
 \prod_{j=1}^{m-1}(\Theta+2j+1)
 \bigl[u^2(1-u)^{3m+1}\bigr],
 \qquad \Theta=-u\partial_u,
\]

得到

\[
 V_m(u)=v_{m,2}u^2+O(u^3),\qquad
 v_{m,2}
 =-\frac{3\prod_{j=1}^{m-1}(2j-1)}{C_m}<0.
\tag{1}
\]

因此若 \(\lambda:=3a-1\)，则

\[
 \widetilde V_{m,a}(u)
 =a v_{m,2}u^\lambda+O(u^{\lambda+a})
 \qquad(u\downarrow0).
\tag{2}
\]

在 \(1<a<4/3\) 时 \(2<\lambda<3\)。另一方面，\(V_m\) 在 \(u=1\)
至少有 \(2m+1\ge3\) 阶零点，故 \(\widetilde V_{m,a}\) 在右端的
Euler--Maclaurin 边界项从 \(N^{-3}\) 才开始出现。

## 广义 Euler--Maclaurin 项

对满足 (2)、右端三阶平坦且
\(\int_0^1\widetilde V_{m,a}(u)\,du=0\) 的函数，整数点 Riemann 和的
广义 Euler--Maclaurin 展开给出

\[
 \sum_{n=1}^{N}\widetilde V_{m,a}(n/N)
 =a v_{m,2}\zeta(-\lambda)N^{-\lambda}
 +o(N^{-\lambda}).
\tag{3}
\]

这里零均值消掉了 \(N\int_0^1\widetilde V_{m,a}\)，右端的普通
Euler--Maclaurin 项为 \(O(N^{-3})=o(N^{-\lambda})\)，而左端的
非整数幂 \(u^\lambda\) 产生 \( \zeta(-\lambda)N^{-\lambda}\)。
公式 (3) 也可由先减去一个在零点附近等于
\(a v_{m,2}u^\lambda\) 的 cutoff，再对余项作普通 Euler--Maclaurin
得到。

伸缩的 Mellin 公式为

\[
 K_{\widetilde V_{m,a}}(s)
 =K_{V_m}\!\left(1+\frac{s-1}{a}\right),
\]

故 \(K_{\widetilde V_{m,a}}(1)=K_{V_m}(1)=0\)，确实满足 (3) 所需的
零均值。

最后，由 zeta 函数的功能方程，在 \(2<\lambda<3\) 上

\[
 \zeta(-\lambda)>0.
\]

结合 (1) 得 \(a v_{m,2}\zeta(-\lambda)<0\)，于是 (3) 对充分大的
\(N\) 严格为负。

## 结论

这不是 \(V_{15}\) 或某个固定层的数值反例，而是整个现有
Euler--beta detector 层级的统一尾部 obstruction：任何试图从
\(a=1\) 向右做小 Jacobian 伸缩的方案，都会立刻破坏
全半轴 periodization 正性。较大的 \(a\) 不被本命题覆盖，但必须
重新解决有限尺度负块；例如 note 360 已给出 \(V_{15},a=2,y=2\) 的
精确负值。
