> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 缩放 detector 的尺度对齐最终坍缩为 Mertens 尾

日期：2026-08-16。

## 命题

令 \(V\) 支持于 \((0,1)\)，并定义
\[
V_R(u):=V(Ru),\qquad R\ge1.
\]
记 \(P_R,U_R,A_R,T_R\) 为 \(V_R\) 对应的 periodization、线性 Möbius
和、half-lattice 线性截断与二次型。对任意 \(X\ge1\)，令 \(x=RX\)，则

\[
P_R(y)=
\begin{cases}
0,&y<R,\\
P_V(y/R),&y\ge R,
\end{cases}
\tag{1}
\]

\[
U_R(RX)=U_V(X),
\tag{2}
\]

\[
A_R(RX)
=\sum_{n\le \min(X,\sqrt{RX})}\mu(n)V(n/X),
\tag{3}
\]

\[
T_R(RX)
=\sum_{\substack{a,b\le\sqrt{RX}\\ab\le X}}
\mu(a)\mu(b)P_V\!\left(\frac{X}{ab}\right).
\tag{4}
\]

这些式子只用变量替换，不涉及估计。

## 精确坍缩

截断卷积恒等式给出

\[
U_V(X)=2A_R(RX)-T_R(RX).
\tag{5}
\]

若 \(1\le R<X\)，置 \(L=\sqrt{RX}\)。由于 \(V(n/X)=0\) 对 \(n>X\)，
(3)--(5) 化为

\[
\boxed{
U_V(X)-T_R(RX)
=2\sum_{L<n\le X}\mu(n)V(n/X).
}
\tag{6}
\]

因此只要二次型仍然与线性和不同，差额就是一个未控制的 Mertens 尾；
缩放没有生成新的正性通道。

若 \(R\ge X\)，则 \(L\ge X\)，于是 \(A_R(RX)=U_V(X)\)，从而

\[
\boxed{T_R(RX)=U_V(X).}
\tag{7}
\]

也可以直接验证：此时 (4) 包含全部 \(a,b\ge1\) 且 \(ab\le X\)，故

\[
\begin{aligned}
T_R(RX)
&=\sum_{abc\le X}\mu(a)\mu(b)V(abc/X)\\
&=\sum_{n\le X}(\mu*\mu*1)(n)V(n/X)\\
&=\sum_{n\le X}\mu(n)V(n/X)=U_V(X),
\end{aligned}
\tag{8}
\]

因为 \(\mu*1=\varepsilon\)。

## 对 RH 路线的含义

尺度缩放有两个互斥区域：

* \(R\ge X\)：half-lattice 二次型失去独立性，精确变成线性 Möbius 和；
* \(R<X\)：二次型与线性和的差额是式 (6) 的 Mertens 尾，任何平方根级
  控制都重新包含 RH-strength 的部分和估计。

所以把 detector 的 support 缩到 \(1/R\)，试图把
\(a,b\le\sqrt{RX}\) 推到 \(a,b\) 接近 \(X\)，不能绕过
\(T_V\) 与 RH 的双向等价；它只是在 \(R\ge X\) 时把 reciprocal
periodization 的 Möbius cancellation 直接恢复出来。

本 note 是一个精确路线关闭，不是 RH 证明。
