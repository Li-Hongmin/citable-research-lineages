> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 428. 增长阶滤波器的统一 pole-extraction 门

## 1. 设置

固定 \(q\ge2\)，令
\[
H_r(k)=T_{r,q,\infty}(k),
\qquad P_r(z)=(1-qz)^r,
\]
并设 \(r=r(X)=o(\log X)\)。由 note 420，离散 Mellin 变换为
\[
\mathcal F_r(z)=\frac{P_r(q^{-(z+1)})}{\zeta(z+1)}.
\tag{1}
\]

由于 \(P_r(q^{-1})=0\)，有限截断尾在 \(k\le X\) 与 \(H_{r(X)}(k)\)
逐项相等。因此有限能量假设
\[
\sum_{k\le X}k|T_{r(X),q,X}(k)|^2
\ll X^{\theta+\varepsilon}
\tag{2}
\]
也给出同一 \(H_{r(X)}\) 在 \(k\le X\) 上的能量界。

## 2. 需要验证的统一显式公式

设 \(\rho\) 是 \(\zeta\) 的零点，\(\beta=\Re\rho>1/2\)。对某个固定
\(w\in C_c^\infty((1/2,1))\)，定义
\[
S_{r,w}(X)=\sum_{k\ge1}H_r(k)w(k/X).
\]
增长阶路线所需的最小新算术输入可以明确写成：存在
\(\delta>0\)、非零常数 \(c_{\rho,w}\) 和 \(C_\rho>1\)，使得对
所有 \(r=o(\log X)\)，沿某个无穷序列 \(X\to\infty\)，
\[
S_{r,w}(X)
=c_{\rho,w}P_r(q^{-\rho})X^\rho
+O_{\rho,w}\!\left(C_\rho^rX^{\beta-\delta}\right).
\tag{3}
\]
这里 \(w\) 应选为隔离该零点的 Mellin 测试函数；若 \(\rho\) 有重数，主项
替换为相应的 \(X^\rho\) 乘以非零对数多项式。

## 3. 该输入一旦成立就足够

由 note 427，
\[
|P_{r(X)}(q^{-\rho})|=X^{o(1)},
\qquad C_\rho^{r(X)}=X^{o(1)}.
\tag{4}
\]
所以 (3) 的主项为 \(X^{\beta-o(1)}\)，误差为
\(X^{\beta-\delta+o(1)}\)，不会抵消主项。另一方面，Cauchy--Schwarz 和
\(\operatorname{supp}w\subset(1/2,1)\) 给出
\[
|S_{r(X),w}(X)|
\le
\left(\sum_{k\le X}k|H_{r(X)}(k)|^2\right)^{1/2}
\left(\sum_{k\le X}\frac{|w(k/X)|^2}{k}\right)^{1/2}
\ll_{w,\varepsilon}X^{\theta/2+\varepsilon}.
\tag{5}
\]
若 \(\beta>\theta/2\)，(3)--(5) 矛盾。因此在统一显式公式 (3) 下，
\[
E_{r(X),q,X}\ll X^{\theta+\varepsilon}
\quad\Longrightarrow\quad
\Re\rho\le\theta/2.
\tag{6}
\]
特别地，\(\theta=1\) 给出 RH。

## 4. 裁决

这不是已完成的 RH 证明：当前缺少的是 (3) 的统一 pole-isolation 估计，
即在 \(r=o(\log X)\) 时同时控制零点间的残差、垂直线积分和 \(C^r\) 因子。
它比“寻找一个更小的 Cauchy 常数”强得多，也比直接声称增长阶能量门等价
RH 精确得多。固定 \(r\) 时，note 420 已不需要该统一接口；只有变化阶族
需要 (3)。
