> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 任意非平凡端点平坦正核的 \(X=2p\) 负块

## 命题

设 \(\phi:[0,\infty)\to\mathbb R\) 满足：

1. \(\phi(u)=0\) 对 \(u\ge1\)；
2. \(\phi(1)=0\)，且 \(\phi(u)=O(u^\alpha)\)（\(u\downarrow0\)）对某个 \(\alpha>0\)；
3. \(\phi\ge0\) 且 \(\phi(1/2)>0\)。

令 \(p>2\) 为素数，\(X=2p\)，在完整平方自由除数格
\[
D_X=\{1,2,p,2p\}
\]
上取 Möbius 向量
\[
c=(\mu(1),\mu(2),\mu(p),\mu(2p))=(1,-1,-1,1).
\]
定义 reciprocal 矩阵
\[
H^\phi_{a,b}=\phi(ab/X).
\]
则有精确恒等式
\[
c^\top H^\phi c
=\phi(1/(2p))-2\phi(1/p)+\phi(2/p)-2\phi(1/2)+2\phi(1).
\tag{1}
\]
由假设 \(\phi(1)=0\) 及 \(u\downarrow0\) 的消失性，
\[
\boxed{
c^\top H^\phi c\longrightarrow -2\phi(1/2)<0
\qquad(p\to\infty).}
\tag{2}
\]

## 推导

四个除数按 \(1,2,p,2p\) 排列。含 \(p\) 的交叉项中，只有
\((1,p)\) 与 \((p,1)\) 的乘积给出 \(ab/X=1/2\)；其系数各为
\(\mu(1)\mu(p)=-1\)，合计 \(-2\phi(1/2)\)。小端的
\((1,1),(1,2),(2,1),(2,2)\) 给出前后四项
\[
\phi(1/(2p))-2\phi(1/p)+\phi(2/p),
\]
其余项的参数为 \(1\) 或大于 \(1\)，由端点平坦与零延拓消失。这得到 (1)。

## cutoff 与完整格的差异

当 \(p>2\sqrt{2p}\) 时，原始 \(a,b\le\sqrt X\) cutoff 只保留
\(\{1,2\}\)，其 Möbius 二次型为
\[
Q^\phi_{2p}
=\phi(1/(2p))-2\phi(1/p)+\phi(2/p)
\longrightarrow0.
\tag{3}
\]
因此 (2) 的负常数完全来自跨半格的 \(p\)-除数交叉项，而不是小 cutoff 块本身。任何试图先在完整 divisor lattice 上建立正 Gram、再无误差投影回 cutoff 的路线，都必须显式支付这项固定负边界。

该命题不声称 RH；它是一个普适的 full-vs-cutoff 负块证书，适用于所有满足上述三条件的非零正核。

