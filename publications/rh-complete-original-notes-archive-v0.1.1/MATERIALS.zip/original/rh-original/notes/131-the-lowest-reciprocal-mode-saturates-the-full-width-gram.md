> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 最低 reciprocal mode 饱和 full-width Gram

日期：2026-08-14。

依赖：[note 130](130-the-reciprocal-phase-l2-gram-is-not-the-fully-centered-prime-type-ii-tensor.md)。

证据等级：显式同号 balanced box 与针对性文献边界。

note 130 表明当前 dyadic Gram 是全宽 reciprocal determinant 问题。本文判断现成
arbitrary-coefficient/Kloosterman-fraction 估计能否提供所需平方根节省。

沿 note 128，固定 \(n=1\) 并令

\[
F_{3,z}(1,x)=
\sum_{a,b\le z}(ab)^3c_ac_b e^{2\pi i x/(ab)}
\tag{1}
\]

暂取一般实系数 \(c_a\)。记 \(D=x\partial_x\)。逐项计算得

\[
(D-3)(D-4)e^{2\pi i x/(ab)}
=Q\!\left(\frac{x}{ab}\right),
\tag{2}
\]

其中

\[
Q(y)=
\left(12-12\pi i y-4\pi^2y^2\right)e^{2\pi iy}.
\tag{3}
\]

在 \(y=1\)，

\[
\Re Q(1)=12-4\pi^2<0.
\tag{4}
\]

由连续性，可取固定 \(\eta>0\)，使对

\[
1\le y\le(1-\eta)^{-2}
\tag{5}
\]

恒有

\[
\Re Q(y)\le-c_0<0.
\tag{6}
\]

现在令 \(x=z^2\)，并取

\[
c_a=\mathbf1_{(1-\eta)z\le a\le z}.
\tag{7}
\]

则每个活动 pair 均满足 (5)，所以

\[
\begin{aligned}
\Re (D-3)(D-4)F_{3,z}(1,z^2)
&\le-c_0
\sum_{a,b\in[(1-\eta)z,z]}(ab)^3\\
&\le-c_1z^8.
\end{aligned}
\tag{8}
\]

乘 note 128 的归一因子 \(x^{-3}=z^{-6}\) 后，单个 \(n=1\) mode 已有

\[
\boxed{
x^{-3}\left|
\Re (D-3)(D-4)F_{3,z}(1,x)
\right|\gg z^2=x.}
\tag{9}
\]

而 RH 门要求的尺度只有

\[
x^{1/2+\varepsilon}=z^{1+2\varepsilon}.
\tag{10}
\]

所以任何对 Fourier modes 分别取绝对值、只使用 \(|c_a|\le1\)，或声称 full-width
reciprocal phase 自动振荡的估计，都至少损失一整幂 \(z\)。

其原因在 balanced box 上已经可见：

\[
\frac{x}{ab}
=\frac1{(a/z)(b/z)}
\tag{11}
\]

只在固定紧区间内变化；每个变量方向的总相位变化均为 \(O(1)\)。这里没有随 \(z\)
增长的 Archimedean oscillation parameter。

截至 2026-08-14 的 paper-lib 定向核对中：

- Bettin--Chandee 的 trilinear Kloosterman-fraction theorem 依赖真正的
  modular reciprocal oscillation；在此前 incomplete-lcm balanced 应用中也只比任意系数
  trivial bound 节省 \(1/8\) 幂，远少于当前所需整幂；
- Wright 2026 改善的是 partially fixed denominator 与 unbalanced convolution；
- Dong--Robles--Zeindler 2026 的 claimed balanced bilinear improvement 已撤稿，
  不能作为输入。

这些定理均不覆盖 (11) 的固定频率、variable-product、Möbius 双线性 box。没有新增
可迁移结果需要进入文献库。

对真实 \(c_a=\mu(a)\)，式 (8) 的同号论证不再适用；所需节省必须来自

\[
\sum_{a,b\asymp z}
(ab)^3\mu(a)\mu(b)
Q\!\left(\frac{z^2}{ab}\right),
\tag{12}
\]

的 signed cancellation。普通 PNT 型 \(M(t)=o(t)\) 经二维部分求和至多给相对
\(o(1)\)，即归一后 \(o(z^2)\)；目标 \(O(z^{1+\varepsilon})\) 需要平方根级
Möbius cancellation，正是 RH 强度而非现成指数和黑箱。

结论：

\[
\boxed{
\text{full-width Gram 的最低 reciprocal mode 已饱和；
所有可用节省必须是 Möbius-specific，不能来自相位几何}.}
\tag{13}
\]

下一步不应继续寻找 coefficient-uniform Kloosterman 界，而应判断 (12) 是否能通过
Mellin 分离精确还原为一族一维 Möbius Dirichlet polynomial norms，并识别其中是否有
严格弱于 RH 的平均门。这不是 RH 的证明。
