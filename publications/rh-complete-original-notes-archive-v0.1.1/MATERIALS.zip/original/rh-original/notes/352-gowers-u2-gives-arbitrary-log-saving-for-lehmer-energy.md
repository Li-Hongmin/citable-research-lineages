> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius \(U^2\) 控制给出 Lehmer 能量的任意固定对数节省

日期：2026-08-16。

note 350 用 MRT 的单移位平均得到 \(N^2\rho_N\)。还可以使用
Tao--Teräväinen 的定量 \(U^2\) 统一性：
\[
 \|\mu\|_{U^2[X]}\ll_A^{\mathrm{ineff}}(\log X)^{-A}
\qquad(A>0\ \text{fixed}),
\tag{1}
\]
见其 Theorem 1.3(ii)，来源：
<https://arxiv.org/html/2107.02158>。
结合 Abel 分部，这给出完整 Lehmer 上三角的任意固定对数幂节省。

## 1. 四点盒范数给相关的 \(\ell^2\) 界

令
\[
 A_h(t)=\sum_{m\le t}\mu(m)\mu(m+h),
\]
并将 \(\mu(m+h)\) 在 \(m+h>N\) 时零延拓。取
\(f_t=\mu\,1_{[t]}\)、\(g_N=\mu\,1_{[N]}\)，在一个长度大于
\(4N\) 的循环群上做 Fourier 变换。取
\(\widehat f(\xi)=\sum_x f(x)e(-x\xi/P)\)。则无卷绕地有
\[
\sum_h\left|\sum_x f_t(x)g_N(x+h)\right|^2
=P^{-1}\sum_\xi|\widehat f_t(\xi)|^2|\widehat g_N(\xi)|^2.
\]
按 Tao--Teräväinen 的未归一化盒范数约定，
\(\sum_\xi|\widehat f(\xi)|^4=P\widetilde U^2(f)^4\)。因此
Parseval 与 Cauchy--Schwarz 给出
\[
 \sum_h |A_h(t)|^2
 \le
 \bigl(\widetilde U^2(f_t)^4\,
       \widetilde U^2(g_N)^4\bigr)^{1/2}.
\tag{2}
\]
由 (1) 及局部 \(U^2\) 的归一化定义
\(\widetilde U^2(\mu1_{[X]})\asymp X^{3/4}\|\mu\|_{U^2[X]}\)，对任意固定 \(A_0>0\)
\[
 \|A(t)\|_{\ell^2(h)}
 \ll_{A_0}^{\mathrm{ineff}}
 t^{3/4}N^{3/4}
 (\log(2t))^{-A_0}(\log N)^{-A_0}.
\tag{3}
\]
这里的循环群只是避免边界；所有支持都在 \([1,N]\)，所以盒范数展开
与区间上的 \(U^2\) 完全一致。

## 2. Lehmer 权的 Abel 转移

令
\[
 C_h=\sum_{m+h\le N}\mu(m)\mu(m+h)\frac{m}{m+h}.
\]
对固定 \(h\)，设 \(w_h(m)=m/(m+h)\)。Abel 分部写成
\[
 C_h=w_h(N)A_h(N)
 +\sum_{t<N}A_h(t)\bigl(w_h(t)-w_h(t+1)\bigr),
\tag{4}
\]
其中零延拓处理了 \(m+h>N\) 的边界。由于
\[
 0\le w_h(t+1)-w_h(t)
 =\frac{h}{(t+h)(t+h+1)}
 \le \frac1{4t},
\tag{5}
\]
Minkowski、(3) 给出
\[
 \|C\|_{\ell^2(h)}
 \ll
 \|A(N)\|_2+\frac14\sum_{t<N}\frac{\|A(t)\|_2}{t}
 \ll_{A}^{\mathrm{ineff}}N^{3/2}(\log N)^{-A}.
\tag{6}
\]
最后一步先对 \(t\le N^{1/2}\) 用平凡界，再对
\(t>N^{1/2}\) 使用 (3)，并把 \(A_0\) 取得足够大。

## 3. 完整 Lehmer 二次型

Cauchy--Schwarz 给
\[
 \left|\sum_{h=1}^{N-1}C_h\right|
 \le \sqrt N\,\|C\|_{\ell^2(h)}
 \ll_A^{\mathrm{ineff}}N^2(\log N)^{-A}.
\tag{7}
\]
下三角与上三角相同，对角线为 \(O(N)\)，故
\[
 \boxed{
 \boldsymbol\mu_N^T L_N\boldsymbol\mu_N
 \ll_A^{\mathrm{ineff}}N^2(\log N)^{-A}+N.}
\tag{8}
\]
于是 note 346 的指数模型也满足
\[
 I_N\ll_A^{\mathrm{ineff}}N^2(\log N)^{-A}.
\tag{9}
\]

## 4. 这仍不是平方根门

式 (8) 对每个固定 \(A\) 成立，但隐含常数依赖 \(A\)，不能令
\(A\) 随 \(N\) 增长。因此它仍是 \(N^{2-o(1)}\)，并不意味着
\(N^{2-\delta}\)，更不意味着 \(N^{1+\varepsilon}\)。

这一步把 MRT 的单对数节省改进为任意固定对数幂节省，同时精确暴露了
最后的缺口：需要 \(U^2\) 的固定幂次（或等价的四点 Möbius 能量）
估计，现有定量 \(U^2\) 定理仍只有对数级衰减。
