> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 单侧 product-kernel 在超分离平方自由格上的指数负惯性

## 命题

设 \(\phi:[0,\infty)\to\mathbb R\) 满足
\[
\phi(u)=0\quad(u\ge1),\qquad
\phi(0)=0,\qquad
c:=\phi(1/2)>0,
\]
并假设 \(\phi\) 在 \(0\) 处连续。对任意固定 \(k\ge1\)，存在一列
\[
X_t=2Y_t,\qquad Y_t=\prod_{i=1}^k q_i(t)
\]
（\(q_i(t)\) 为互异奇素数），使得在指标集
\[
D_{Y_t}=\{a:a\mid Y_t\}
\]
上的矩阵
\[
H_t(a,b)=\phi\!\left(\frac{ab}{X_t}\right)
\]
满足
\[
H_t\longrightarrow cR_k
\quad\text{逐项及算子范数收敛},
\tag{1}
\]
其中 \(R_k e_a=e_{Y_t/a}\) 是除数补集反射。因此对充分大的 \(t\)，
\[
\boxed{n_-(H_t)\ge 2^{k-1}.}
\tag{2}
\]

## 超分离素因子构造

令 \(q_1(t)\to\infty\)，并递归选取素数
\[
q_{i+1}(t)>\bigl(q_1(t)\cdots q_i(t)\bigr)^t.
\tag{3}
\]
若 \(a=\prod_{i\in A}q_i\)、\(b=\prod_{i\in B}q_i\)，则
\[
\frac{ab}{Y_t}
=\frac{\prod_{i\in A\cap B}q_i}
       {\prod_{i\notin A\cup B}q_i}.
\tag{4}
\]
若 \(B=A^c\)，式 (4) 等于 \(1\)，故 \(ab/X_t=1/2\)。若
\(B\ne A^c\)，取同时出现在分子或分母中的最大指标；由 (3)，该因子压倒所有更小因子的乘积，因而 (4) 沿 \(t\to\infty\) 趋于 \(0\) 或 \(+\infty\)。所以
\[
H_t(a,b)\to
\begin{cases}
c,&b=Y_t/a,\\
0,&b\ne Y_t/a.
\end{cases}
\tag{5}
\]
指标维数 \(2^k\) 固定，逐项收敛即为算子范数收敛，得到 (1)。

## 负惯性与秩修正

补集反射 \(R_k\) 无固定点，故其 \(+1\)、\(-1\) 特征子空间维数各为 \(2^{k-1}\)。矩阵 \(cR_k\) 的负惯性正好为 \(2^{k-1}\)。由 Weyl 扰动不等式，(1) 蕴含 \(H_t\) 对充分大的 \(t\) 具有至少 \(2^{k-1}\) 个负特征值。

若 \(F\) 是任意 Hermitian 秩 \(r\) 修正且 \(H_t+F\succeq0\)，则惯性扰动不等式给出
\[
0=n_-(H_t+F)\ge n_-(H_t)-r,
\]
从而
\[
r\ge2^{k-1}.
\tag{6}
\]
因此 direct full-PSD、固定秩 Feshbach 或有限个 rank-one Yukawa atom 不可能在所有平方自由尺度上修复该单侧 product-kernel；所需修正秩至少随素因子数指数增长。

## Möbius parity 模式本身

在同一 \(D_{Y_t}\) 上取
\[
v_t(a)=\mu(a),\qquad a\mid Y_t .
\]
补集反射满足
\[
(R_kv_t)(a)=v_t(Y_t/a)=(-1)^k v_t(a),
\tag{7}
\]
而 \(\|v_t\|_2^2=2^k\)。因此由 (1) 直接得到
\[
\boxed{
v_t^\top H_t v_t\longrightarrow (-1)^k\,2^k\phi(1/2).}
\tag{8}
\]
当 \(k\) 为奇数时，负值不只是某个抽象特征向量造成的，而是由除数 Möbius parity
模式本身实现，且负标量的绝对值随 \(k\) 指数增长。这里的 \(v_t\) 是 full
\(X_t=2Y_t\) Möbius 向量在 \(D_{Y_t}\) 上的自然限制；将其零延拓到完整指标集仍给出同一负测试向量。

事实上可以直接使用完整 \(X_t=2Y_t\) 的 Möbius 向量
\[
c_{X_t}(a)=\mu(a),\qquad a\mid X_t .
\]
将 \(D_{X_t}=D_{Y_t}\sqcup2D_{Y_t}\) 分成两块：不含 2 的补集条目趋于
\(\phi(1/2)\)，只含一个 2 的互补条目给出 \(\phi(1)=0\)，含两个 2 的互补条目给出
\(\phi(2)=0\)，其余条目由超分离性趋于 0。故
\[
c_{X_t}^{\top}H_t c_{X_t}
\longrightarrow (-1)^k\,2^k\phi(1/2).
\tag{9}
\]
所以奇数 \(k\) 时负性直接发生在完整 reciprocal 门的实际 Möbius 向量上，而不只是
某个零延拓的辅助测试向量。

该结果不声称 RH。它严格说明：若要保留 full divisor lattice，必须保留完整 reflection/Kreĭn parity；若只取原始 \(\sqrt X\) cutoff，则必须另行构造跨半格 signed intertwiner，不能把 full PSD 结构无损压缩下来。
