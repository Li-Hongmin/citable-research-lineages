> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Weil 闭形式与 Dirichlet logarithmic Laplacian 的精确归一化

日期：2026-08-11。本文完成 M2-R0：对齐 Suzuki 的 Archimedean 形式与一维标准 logarithmic
Laplacian 的常数、零延拓和闭形式定义域，并写出对完整零模态合法的弱方程。

## 1. 两种 Fourier 约定

Suzuki 使用未归一化 Fourier 变换

\[
\widehat v_S(z)=\int_{\mathbb R}v(x)e^{izx}\,dx,
\qquad
\lVert v\rVert_2^2=\frac1{2\pi}\int_{\mathbb R}|\widehat v_S(z)|^2\,dz.
\]

Chen--Weth 的标准 logarithmic Laplacian \(L_\Delta\) 的 Fourier 符号为

\[
2\log|\xi|=\log(|\xi|^2).
\]

记其 Dirichlet 闭形式为 \(\mathcal E_L\)。换算 Fourier 归一化后，对
\(v\in C_c^\infty(-a,a)\) 有

\[
\mathcal E_L(v,v)
=\frac1{2\pi}\int_{\mathbb R}2\log|z|\,|\widehat v_S(z)|^2\,dz.
\]

Suzuki 的公式 (2.6) 则是

\[
L_a(v)=\frac1{2\pi}\int_{\mathbb R}
\bigl(\log|z|+C_0\bigr)|\widehat v_S(z)|^2\,dz,
\]

其中 \(C_0\) 是 Euler--Mascheroni 常数。因此精确地

\[
\boxed{L_a(v)=\tfrac12\mathcal E_L(v,v)+C_0\lVert v\rVert_2^2.}
\]

## 2. 常数项完全消去

Suzuki 的局部展开常数为

\[
A=\tfrac12\bigl(\log(2\pi)+C_0-1\bigr),
\]

所以 \(2A+1=\log(2\pi)+C_0\)。于是

\[
\boxed{
L_a(v)-(2A+1)\lVert v\rVert_2^2
=\tfrac12\mathcal E_L(v,v)-\log(2\pi)\lVert v\rVert_2^2.}
\]

这给出了此前“对数阶主算子”的无歧义归一化：Weil Archimedean 主部是
\(\tfrac12L_\Delta-\log(2\pi)I\)，不是只在主符号意义下相似。

## 3. 有限平移与光滑余项都是 \(L^2\)-有界形式

将 \(v\) 在区间外延为零，定义

\[
\begin{aligned}
\mathcal P_a(v,v)
:={}&\sum_{n\le e^{2a}}\frac{\Lambda(n)}{\sqrt n}
\int_{\mathbb R}
\bigl(v(x+\log n)+v(x-\log n)\bigr)\overline{v(x)}\,dx,\\
\mathcal R_a(v,v)
:={}&\int_{-a}^a\int_{-a}^a
r''(x-y)v(y)\overline{v(x)}\,dx\,dy.
\end{aligned}
\]

固定 \(a\) 时 \(\mathcal P_a\) 只有有限项；每个零延拓平移在 \(L^2(\mathbb R)\) 上是等距算子。
因此

\[
|\mathcal P_a(v,v)|
\le 2\sum_{n\le e^{2a}}\frac{\Lambda(n)}{\sqrt n}\lVert v\rVert_2^2.
\]

由于 \(r''\) 在 \([-2a,2a]\) 上连续，\(\mathcal R_a\) 是 Hilbert--Schmidt 型有界形式。二者都不改变
主闭形式的定义域。

## 4. 完整闭形式的精确恒等式与定义域

Suzuki 的公式 (2.5) 与上面的常数换算给出，在 \(C_c^\infty(-a,a)\) 上

\[
\boxed{
Q_W^a(v,v)
=\tfrac12\mathcal E_L(v,v)
-\log(2\pi)\lVert v\rVert_2^2
-\mathcal P_a(v,v)-\mathcal R_a(v,v).}
\]

令

\[
\Omega_a=(-a,a),
\]

并记 Chen--Weth 的 exterior-zero 能量空间为

\[
H(\Omega_a)
=\left\{v\in L^2(\mathbb R):v=0\ \text{a.e. on }\mathbb R\setminus\Omega_a,
\ \iint_{|x-y|\le1}\frac{|v(x)-v(y)|^2}{|x-y|}\,dx\,dy<\infty\right\}.
\]

Chen--Weth 的 Theorem 3.1 证明 \(C_c^\infty(\Omega_a)\) 在 \(H(\Omega_a)\) 中稠密。其近场能量
控制 \(L^2\)，而 \(\mathcal E_L\) 与该能量只差 \(L^2\)-有界远场和常数项。另一方面，Suzuki 的
Theorem 1.1 证明 \(D(Q_W^a)\) 正是 \(C_c^\infty(\Omega_a)\) 的 Weil form-norm 完备化。由于
\(\mathcal P_a,\mathcal R_a\) 也都是 \(L^2\)-有界形式，三种相应的平移后形式范数等价。因此

\[
\boxed{D(Q_W^a)=H((-a,a))}
\]

作为零延拓 \(L^2(\mathbb R)\) 中的集合，且上面的闭形式恒等式通过极化延拓到整个定义域。

这严格解决了 note 001 的“二选一”接口中的第二条：不必证明 ground state 属于
\(H_0^1(-a,a)\)，有限 prime-shift 公式已经在完整 form domain 上有合法的弱形式。

## 5. 首次退化零模态的标准弱方程

若 \(v_*\in D(A_{a_*})\) 且 \(A_{a_*}v_*=0\)，则对每个
\(w\in H((-a_*,a_*))\)，

\[
\boxed{
\tfrac12\mathcal E_L(v_*,w)
=\log(2\pi)\langle v_*,w\rangle
+\mathcal P_{a_*}(v_*,w)+\mathcal R_{a_*}(v_*,w).}
\]

等价地，在 \((-a_*,a_*)\) 内的分布意义下，

\[
L_\Delta v_*
=2\log(2\pi)v_*+2K_{a_*}v_*,
\qquad
v_*=0\quad\text{a.e. on }\mathbb R\setminus(-a_*,a_*),
\]

其中 \(K_a\) 是由有限零延拓平移和光滑积分核组成的有界自伴算子，满足
\(\langle K_av,w\rangle=\mathcal P_a(v,w)+\mathcal R_a(v,w)\)。

这个方程在 form domain 上成立；它不赋予 \(v_*(\pm a_*)\) 经典点值，也不自动给出普通
Dirichlet 端点条件。

## 6. M2-R0 完成后剩下的真实断点

精确归一化和定义域已不再是障碍。本文写作时仍有三个接口；后续进展如下：

1. note 007 已通过 Kato 不等式和正离散跳跃改写证明 \(v_*\in L^\infty\)，并接通
   \(\ell(d)^{1/2}\) 边界阶上界；
2. Hopf 型引理还要求解连续、非负且非平凡。Weil ground state 是否可以选为单一符号，尚未由形式
   的 Markov 性或 positivity-improving 性证明；note 005 反而证明 \(a>1/6\) 时标准绝对值收缩失效；
3. Chen--Hauer--Weth 的弱唯一延拓针对 \(u=L_\Delta u=0\) 于同一开集。对
   \(L_\Delta u=(2\log(2\pi)I+2K_a)u\)，即使 \(u\) 在开集消失，平移项 \(K_au\) 也未必在该
   开集消失，所以其证明不能直接移植。

因此 M2-R1 已完成，M2-R2 的标准半群机制已被否决。剩余问题是从首次退化另行导出单符号，
或为变号零模态建立 signed boundary coefficient；M2-R3 的 finite-shift UCP 仍待处理。

## 7. 来源与证据边界

- Masatoshi Suzuki, *Weil's quadratic form via the screw function*,
  [arXiv:2606.09096](https://arxiv.org/abs/2606.09096)，尤其是公式 (2.3)、(2.5)、(2.6) 与
  Theorem 1.1。
- Huyuan Chen and Tobias Weth, *The Dirichlet Problem for the Logarithmic Laplacian*,
  [arXiv:1710.03416](https://arxiv.org/abs/1710.03416)，尤其是 Theorem 1.1、Theorem 3.1 及其
  Dirichlet 能量空间。
- Víctor Hernández-Santamaría, Luis Fernando López Ríos and Alberto Saldaña,
  *Optimal boundary regularity and a Hopf-type lemma for Dirichlet problems involving the logarithmic
  Laplacian*, [arXiv:2401.18033](https://arxiv.org/abs/2401.18033)，Theorem 1.1 与 Theorem 1.4。
- Huyuan Chen, Daniel Hauer and Tobias Weth, *An extension problem for the logarithmic Laplacian*,
  [arXiv:2312.15689](https://arxiv.org/abs/2312.15689)，其弱唯一延拓定理只直接覆盖未扰动方程。

本文的精确常数换算、定义域等同和扰动后弱方程是对这些原始结果的本项目推论；边界正则性、
Hopf 引理和唯一延拓对 finite shifts 的稳定性仍是待证命题。
