> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一个十五次正 detector 同时消去四个 collective residues

日期：2026-08-15。

依赖：[note 141](141-a-minimal-degree-twelve-positive-detector-removes-three-collective-residues.md)、
[note 142](142-correction-noninteger-faulhaber-summation.md)。

证据等级：精确 Mellin 变换与 Bernstein--falling-factorial 正证书。

本 note 构造一个全半轴逐项非负的十五次 detector，同时消去
\(s=-1,-3,-5,-7\) 四个 odd Mellin residues。此前的错误 no-go 草稿已由 note 142
更正；本结果把正 detector 层级从次数十二推进到次数十五。

## 1. Detector 与 Mellin numerator

令

\[
\boxed{
V_{15}(u)=u^2(1-u)^9
\bigl(1024u^4+207u^3-57u^2-27u-3\bigr)}
\tag{1}
\]

于区间外作零延拓。直接展开或 Beta 积分给出

\[
V_{15}(0)=V_{15}(1)=0,qquad
\int_0^1V_{15}(u)\,du=0,
\tag{2}
\]

\[
v_1=v_3=v_5=v_7=0,
\tag{3}
\]

其中 \(v_j=[u^j]V_{15}\)。其 Mellin 变换为

\[
\boxed{
K_{15}(s)=
\frac{415134720(s-1)}{
(s+2)(s+4)(s+6)(s+8)(s+9)(s+10)(s+11)(s+12)
(s+13)(s+14)(s+15)}.}
\tag{4}
\]

故 \(K_{15}\) 在 \(1/2<\Re s<1\) 无零点。

## 2. 全半轴正性

定义

\[
P_{15}(y)=\sum_{c\le y}V_{15}(c/y),qquad y\ge1.
\tag{5}
\]

写 \(y=N+r\)，其中 \(N=\lfloor y\rfloor\ge1\)、\(0\le r<1\)，并令
\(m=N-1\)。精确 Faulhaber 求和可写成

\[
P_{15}(N+r)=
\frac{N(N+1)}{(N+r)^{15}}Q_N(r),
\tag{6}
\]

其中 \(Q_N\) 是十三次多项式。令

\[
\beta_{k,13}(r)=\binom{13}{k}r^k(1-r)^{13-k},
\qquad
m^{\underline j}=m(m-1)\cdots(m-j+1).
\tag{7}
\]

则有精确展开

\[
Q_N(r)=\sum_{k=0}^{13}b_k(m)\beta_{k,13}(r),
\qquad
b_k(m)=\frac1{L_k}\sum_{j=0}^{4}c_{k,j}m^{\underline j},
\tag{8}
\]

其中下表给出 \((L_k;c_{k,0},\ldots,c_{k,4})\)：

\[
\begin{array}{c|r|rrrrr}
k&L_k&c_{k,0}&c_{k,1}&c_{k,2}&c_{k,3}&c_{k,4}\\ \hline
0&6&0&946&37133&21996&2444\\
1&6&0&1567&43973&23364&2444\\
2&15&0&6425&128005&62127&6143\\
3&15&0&10420&146420&66015&6209\\
4&15&0&16684&164492&69840&6296\\
5&3&0&5264&36336&14660&1276\\
6&5&0&13600&65960&25376&2144\\
7&5&0&20640&71240&26080&2144\\
8&3&0&18304&46116&15964&1276\\
9&15&12&130932&250172&81264&6296\\
10&15&120&180360&273815&83001&6209\\
11&15&645&238635&301840&85305&6143\\
12&6&975&121497&133433&35292&2444\\
13&6&2838&149478&147113&36660&2444
\end{array}
\tag{9}
\]

每个 \(L_k>0\)，表中所有 \(c_{k,j}\ge0\)，且 \(m^{\underline j}\ge0\) 对整数
\(m\ge0\) 成立。因此 \(b_k(m)\ge0\)，再由 Bernstein 基函数非负得到

\[
\boxed{P_{15}(y)\ge0\qquad(y\ge1).}
\tag{10}
\]

这是一份纯有理、无数值采样的全半轴证书。

## 3. 正 reciprocal-product RH 门

令

\[
U_{15}(x)=\sum_{n\ge1}\mu(n)V_{15}(n/x),
\]

\[
T_{15}(x)=
\sum_{a,b\le\sqrt x}
\mu(a)\mu(b)P_{15}\!\left(\frac{x}{ab}\right).
\tag{11}
\]

精确截断卷积恒等式与 \(V_{15}(u)=O(u^2)\) 给出

\[
T_{15}(x)=-U_{15}(x)+O(x^{-1/2}).
\tag{12}
\]

结合 (4) 的 Mellin detector 定理，得到

\[
\boxed{
\mathrm{RH}\iff
\forall\varepsilon>0,
\quad T_{15}(x)\ll_{\varepsilon}x^{1/2+\varepsilon}.}
\tag{13}
\]

同样可替换为对应 dyadic \(L^2\) 门。

## 4. 四个 residue 的移位

首批非零 odd 系数为

\[
v_9=-54912,\quad v_{11}=-109824,\quad
v_{13}=-34944,\quad v_{15}=-1024.
\tag{14}
\]

若 \(S_k(z)=\sum_{a\le z}a^k\mu(a)\)，则 collective 分解为

\[
\boxed{
T_{15}(x)=
416\frac{S_9(\sqrt x)^2}{x^9}
-\frac{243232}{105}\frac{S_{11}(\sqrt x)^2}{x^{11}}
+2912\frac{S_{13}(\sqrt x)^2}{x^{13}}
-\frac{115744}{255}\frac{S_{15}(\sqrt x)^2}{x^{15}}
+T_{15}^{(0)}(x),}
\tag{15}
\]

其中 \(T_{15}^{(0)}\) 的周期系数均值为零。正性已把四个 RH-strength collective
residues 逐项移除，但完整 signed Möbius cancellation 仍未估计。

## 5. 边界

本结果不是 RH 的证明。它把下一步精确压成对完整 signed form \(T_{15}\) 的
平方根尺度估计；不能分别对 (15) 的四个平方项或 \(T_{15}^{(0)}\) 取绝对值。
