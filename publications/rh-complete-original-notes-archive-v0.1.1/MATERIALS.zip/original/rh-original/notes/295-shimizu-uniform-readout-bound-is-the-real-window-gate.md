> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Shimizu v8：统一 readout bound 才是窗口极限的真正门

日期：2026-08-16。

## 已核验的部分

稿件 Lemma 6.109 对
\[
h_w(u)=\frac{e^{wu}-1}{u}
\]
作带权指数尾估计。对紧集 \(B\) 和 \(\sigma>\sup_{w\in B}|\operatorname{Re}w|\)，
其证明给出
\[
\sup_{|u|\ge M}(1+|u|)^A e^{-(\sigma-\beta_B)|u|}
\longrightarrow0.
\]
这确实说明原始 cutoff 与 finite-jet counterterm 在其定义的
\(C_{\mathrm{cen}}\) seminorm 中形成 Cauchy 族；这一局部核的尾估计本身没有
涉及 RH 或 Möbius pairing。

## 真正承重的下一步

Lemma 6.116 将 finite-readout quotient 的范数定义为
\[
\|\eta\|_{\mathrm{rd},M}
:=\inf\{\|u\|_{K_R}:G_Mu=\eta\},
\]
然后 Moore--Penrose 最小范数重构满足等式
\[
\|G_M^\dagger\eta\|_{K_R}=\|\eta\|_{\mathrm{rd},M}.
\]
这一步是 quotient norm 的定义性事实，不是窗口一致估计。

同一 lemma 后半部以及 Lemma 6.118 的真正要求是：对由 central
Cauchy--Laplace 家族产生的 readout \(\eta_M(\Phi)\)，存在与 \(M\) 无关的
常数，或至多一个已明确支付的多项式因子，
\[
\|\eta_M(\Phi)\|_{\mathrm{rd},M}
\le C_{B,m} \sum_\nu p_\nu(\Phi).
\tag{1}
\]
稿件的文字理由是：finite-dimensional \(R\)-side lift、有限个代表元、cutoff
导数与 support 长度“至多多项式增长”；随后用加权 seminorm 吸收 \(M^{A_0}\)。
但若没有对 \(G_M\)、seam transpose、LCI 和所选代表元给出独立的量化下界，
这只是待证明的 uniform geometric estimate，而不是由有限维性自动推出的事实。

## 为什么“有限维”不够

有限维 Moore--Penrose 逆的范数可以随窗口超多项式增长。最小模型取
\(K_R=\mathbb R\)、\(G_Mu=e^{-M}u\)、\(\eta_M=1\)。则每个窗口都有精确
重构
\[
u_M=G_M^\dagger\eta_M=e^M,
\qquad
\|\eta_M\|_{\mathrm{rd},M}=e^M.
\]
所有有限窗口恒等式都成立，但不存在 (1) 所需的多项式统一界。若把
\(e^{-M}\) 换成 \(e^{-M^2}\)，增长甚至超过任意固定多项式。这个例子不声称
对应 Shimizu 的具体算子，只说明“finite-dimensional + pseudoinverse +
intrinsic quotient norm”本身不能证明窗口一致性。

## 对外部主张的精确裁决

因此，Lemma 6.109 的局部指数尾估计可以暂时视为独立的分析步骤；但
Theorem 6.155 仍依赖 Lemma 6.116/6.118 中的 (1)。要使该桥成为可复核证明，
至少需要公开并验证：

1. \(G_M\) 的 readout quotient 与 \(K_R\) 范数之间的窗口一致 coercivity；
2. seam transpose、LCI 和 finite-window section 的显式算子范数上界；
3. 这些上界与新增 weighted seminorm 的定义不循环；
4. 代表元兼容性在 \(M\to\infty\) 时不把目标 pairing 值预先编码进去。

在这些估计成立前，不能把 det2 自伴结构升级为 \(F_K=\xi\)，也不能称为 RH
证明。这个门与本项目的 signed arithmetic intertwiner 在逻辑上相同：都需要
一个跨窗口、保留交叉项符号的统一量化估计。

## 来源定位

上述判断对应预印本 v8 的 Lemma 6.109、6.116、6.118、6.119 与
Theorem 6.155；稿件仍标为未同行评审。参见
[Preprints.org v8](https://www.preprints.org/manuscript/202505.2110)
及 [PREreview](https://prereview.org/reviews/17143549)。

