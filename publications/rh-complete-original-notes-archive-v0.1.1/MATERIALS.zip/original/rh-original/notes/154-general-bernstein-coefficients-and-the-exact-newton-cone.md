> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一般 detector periodization 的 Bernstein 系数与最小 Newton 缺口

日期：2026-08-15。

本 note 给出统一 (V_m) 的全半轴 Bernstein 系数闭式，并准确标出尚未证明的
全 (m) 命题。它不把有限层的有理计算升级为一般定理。

## 1. 系数与参数

令

\[
D=3m+3,\qquad d=D-2=3m+1,
\]

并写

\[
V_m(u)=\sum_{n=2}^{D}v_{m,n}u^n.
\]

由
\(H_m=\sum_{q=0}^{3m+1}(-1)^q\binom{3m+1}{q}u^{q+2}\)
以及 \(\Theta u^n=-nu^n\)，得到精确系数

\[
\boxed{
v_{m,n}=\frac{(-1)^{n-1}}{C_m}\binom{3m+1}{n-2}(n+1)
\prod_{j=1}^{m-1}(2j+1-n).}
\tag{1}
\]

零因子自动消去 \(n=3,5,\ldots,2m-1\)。记

\[
S_n(N)=\sum_{c=1}^{N}c^n,
\qquad A_n(N)=\frac{S_n(N)}{N(N+1)}.
\tag{2}
\]

对 \(y=N+r\)、\(0\le r<1\)，定义

\[
P_m(y)=\sum_{c\le y}V_m(c/y),
\qquad
Q_{m,N}(r)=\frac{(N+r)^D}{N(N+1)}P_m(N+r).
\tag{3}
\]

## 2. 精确 Bernstein 闭式

令

\[
H^{(d)}_{p,k}(N):=
\sum_{j=0}^{\min(p,k)}
\frac{\binom pj\binom kj}{\binom dj}N^{p-j}.
\tag{4}
\]

这是 \((N+r)^p\) 在 degree-\(d\) Bernstein 基底中的第 \(k\) 个系数。
于是

\[
\boxed{
b_{m,k}(N)=
\sum_{n=2}^{D}v_{m,n}
A_n(N)H^{(d)}_{D-n,k}(N),
\qquad 0\le k\le d.}
\tag{5}
\]

即

\[
Q_{m,N}(r)=\sum_{k=0}^{d}b_{m,k}(N)
\binom dk r^k(1-r)^{d-k}.
\tag{6}
\]

等价的生成函数形式更适合检查变换：

\[
\boxed{
\sum_{k=0}^{d}b_{m,k}(N)x^k
=\frac{[N+(N+1)x]^D}{N(N+1)(1+x)^2}
P_m\!\left(\frac{N+(N+1)x}{1+x}\right).}
\tag{7}
\]

证明只用 \((1-r)^d(N+r)^p\) 的 Bernstein 变换；(7) 则由
\(r=x/(1+x)\) 直接得到。

## 3. Newton 系数的最小缺口

由 Faulhaber 恒等式和 (1)，每个 \(b_{m,k}(N)\) 中高于 \(m\) 次的
\(N\)-项精确消去。因而它是次数至多 \(m\) 的多项式。令

\[
\boxed{
a_{m,k,j}:=(\Delta_N^j b_{m,k})(2)
=\sum_{q=0}^{j}(-1)^{j-q}\binom jq b_{m,k}(q+2),
\quad 0\le j\le m.}
\tag{8}
\]

则

\[
b_{m,k}(N)=\sum_{j=0}^{m}a_{m,k,j}\binom{N-2}{j}.
\tag{9}
\]

因此，固定 \(m\) 的一个统一全半轴 Bernstein 系数证书可由下列更强的
Newton 系数锥推出：

\[
a_{m,k,j}\ge0
\quad(0\le k\le d,\;0\le j\le m),
\tag{10}
\]

这是一条充分条件，不声称对 (b_{m,k}(N)ge0) 的整数半轴正性是必要条件。
式 (8) 是严格的有限和，但其各项并不逐项为正；
它仍是待证明的系数锥命题，而不是显式正和。

特别地，式 (10) 不能从单点 \(V_m\) 的半区间正性推出。对每个单项
写 \(q_m=C_mV_m/[u^2(1-u)^{2m+1}]\)，令

\[
A=N+(N+1)x,\quad B=1+x,\quad d_c=N-c,
\]

则 (7) 的第 \(c\) 个 atom 为

\[
\frac{c^2}{C_m}(d_c+(d_c+1)x)^{2m+1}
A^m q_m(cB/A).
\tag{11}
\]

即使 \(m=4,N=3,c=1\)，(11) 的 \(x\)-系数仍有负项；正性必须在完整
\(c\)-和中产生，不能逐 source 取绝对值或逐 atom 正化。

## 4. 证据边界

式 (1)、(5)、(7)、(8) 是一般 \(m\) 的精确恒等式。有限层的
Bernstein/Newton 有理表（包括已记录的次数十五、十八证书）证明的是固定层，
不能替代
\[
\boxed{a_{m,k,j}\ge0\text{ 对所有 }m,k,j}
\]
的统一证明。这个系数锥是当前 periodization 路线的最小未闭合命题；即便它
最终闭合，仍需另行处理带符号 Möbius 双和的平方根级抵消。
