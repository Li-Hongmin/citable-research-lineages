> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正矩核族的望远镜恒等式与 \(2/3\) Mertens 障碍

本 note 给出一族完全正的 cutoff kernels，精确说明为什么“逐个正核
给出近平方根级二次界”仍不足以推出 RH。

## 正核族与精确望远镜

令 \(z\ge1\) 为整数，\(x=z^2\)，并对 \(j\ge0\) 定义
\[
\phi_j(u)=u^j(1-u)\mathbf1_{(0,1)}(u),
\qquad
A_j(z)=\sum_{n\le z}\mu(n)n^j.
\]
每个 \(\phi_j\) 在 \([0,1]\) 上非负。原始 cutoff 二次型为
\[
T_j(z^2)=\sum_{a,b\le z}\mu(a)\mu(b)\phi_j(ab/z^2).
\]
由于
\[
\phi_j(ab/z^2)=\frac{a^jb^j}{z^{2j}}
 -\frac{a^{j+1}b^{j+1}}{z^{2j+2}},
\]
逐项分离给出严格恒等式
\[
\boxed{
T_j(z^2)=\frac{A_j(z)^2}{z^{2j}}
        -\frac{A_{j+1}(z)^2}{z^{2j+2}}.}
\tag{1}
\]
因此对任意 \(J\ge0\)，
\[
\boxed{
M(z)^2=\sum_{j=0}^{J}T_j(z^2)
       +\frac{A_{J+1}(z)^2}{z^{2J+2}},}
\tag{2}
\]
其中 \(M(z)=A_0(z)\)。这是有限代数恒等式，不涉及 RH 或渐近假设。

## 无条件高阶尾与优化

由 \(|\mu(n)|\le1\)，
\[
|A_{J+1}(z)|\le\sum_{n\le z}n^{J+1}
 \le \frac{2z^{J+2}}{J+2}
\quad(z\ge2),
\]
从而 (2) 的尾满足
\[
\frac{A_{J+1}(z)^2}{z^{2J+2}}
 \le \frac{4z^2}{(J+2)^2}.
\tag{3}
\]
若另行假设一个对所有 \(0\le j\le J\) 一致的二次型界
\[
|T_j(z^2)|\le C_\varepsilon z^{1+\varepsilon},
\tag{4}
\]
则由 (2)--(3)
\[
M(z)^2\le C_\varepsilon(J+1)z^{1+\varepsilon}
       +\frac{4z^2}{(J+2)^2}.
\tag{5}
\]
取 \(J\asymp z^{1/3}\)（吸收 \(z^\varepsilon\)）得到
\[
M(z)\ll_\varepsilon z^{2/3+\varepsilon}.
\tag{6}
\]
所以即使一整族正 kernel 都有近平方根级的二次型界，单靠有限望远镜
与无条件高阶尾也只越过了平凡界，仍停在经典 \(2/3\) 门；要得到
\(z^{1/2+\varepsilon}\)，必须额外控制最高阶尾或建立跨 \(j\) 的
signed/coercive 关系。

## 范围与意义

本结果不是对 (4) 的无条件证明，也不是 RH 证明；它精确给出一个
“正 kernel 家族 \(\to\) Mertens”路线的最薄损失。它说明继续增加正矩
kernel 的数量本身不会自动提供平方根节省，真正需要的是跨矩阶的
非局部 arithmetic intertwiner。

上游：notes 372、214、229。
