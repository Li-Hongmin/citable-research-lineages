> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 平均边界 trace 与 dyadic packet coercivity

日期：2026-08-11。

本文继续 [notes 047--048](047-volterra-boundary-indicial-root-and-mellin-local-hinge.md) 的
Volterra--Mellin 边界模型。它给出平均 trace 的精确必要充分尾条件，证明权重 commutator 不是
障碍，并严格排除一大类多频 dyadic packet pseudomodes。

## 1. 平均 trace 的精确尾条件

设

\[
(\mathcal V+\mathcal M)U=F,\qquad
\mathcal VU=2tU-\int_T^tU,
\qquad |U(t)|\le Ct^{-1/2},
\]

并令

\[
A(t)=\int_T^tU(\tau)\,d\tau,\qquad
Z(t)=\frac{A(t)}{\sqrt t}.
\]

则代数上精确有

\[
\boxed{
2t^{3/2}Z'(t)=F(t)-\mathcal MU(t).}
\tag{1}
\]

因此在 \(F\in L^\infty\) 下，\(Z(t)\) 存在有限极限的唯一非平凡尾条件是

\[
\boxed{
\int_T^\infty t^{-3/2}\mathcal MU(t)\,dt
\quad\text{收敛}.}
\tag{2}
\]

这里 \(F/t^{3/2}\) 自动可积。若 (2) 成立，则得到 averaged gauge trace

\[
\frac1{\sqrt t}\int_T^tU(\tau)\,d\tau\longrightarrow 2B.
\]

另一方面，

\[
\sqrt t\,U(t)
=\frac{Z(t)}2+\frac{F(t)-\mathcal MU(t)}{2\sqrt t},
\tag{3}
\]

所以从平均 trace 升级为点态 trace 还需要

\[
\mathcal MU(t)=o(\sqrt t)
\tag{4}
\]

或等价的 Tauberian 正则性。

## 2. 权重 commutator 不是障碍

\(\mathcal M\) 的核只连接 \(|t-s|\le\log2\)。在 commutator

\[
[\sqrt t,\mathcal M]U
\]

中，权重差 \(\sqrt t-\sqrt s\) 消去核的 \(1/|t-s|\) 奇性。由
\(|U(s)|\le Cs^{-1/2}\) 可得

\[
\boxed{
[\sqrt t,\mathcal M]U=O(t^{-1}).}
\tag{5}
\]

因此 weighted coercivity 的主要困难不是非交换性，而是把形式级正性转化为每个移动右端点上的
signed tail cancellation。

## 3. Dyadic packet pseudomode 排除

取相互距离大于 \(2\log2\) 的区间

\[
I_k=[T_k,T_k+L_k],
\]

并令 \(U_k\) 支撑于 \(I_k\)、\(\int_{I_k}U_k=0\)。零均值使 Volterra primitive 在 packet
两端相同，从而

\[
\operatorname{Re}\int_{I_k}\overline{U_k(t)}
\left(\int_T^tU_k\right)dt=0.
\]

又由 \(\operatorname{Re}m(\xi)\ge0\)，Mellin-local 二次型非负，故

\[
\boxed{
2T_k\|U_k\|_2^2
\le
\operatorname{Re}\langle U_k,(\mathcal V+\mathcal M)U\rangle.}
\tag{6}
\]

若右端 \(F=(\mathcal V+\mathcal M)U\) pointwise bounded，则

\[
\|U_k\|_2\le\frac{\|F\|_\infty\sqrt{L_k}}{2T_k}.
\tag{7}
\]

所以固定占空比 packet 的振幅至多 \(O(T_k^{-1})\)，严格小于临界
\(T_k^{-1/2}\)。高频 packet 在减去 \(O(a_k/(|\xi_k|L_k))\) 的均值校正后仍满足同一结论。

非零均值 packet 只能进入 Volterra slow mode。相邻 dyadic block 的系数满足

\[
|B_{k+1}-B_k|\lesssim T_k^{-1/2},
\]

右端沿 dyadic \(T_k\) 可求和，故 \(B_k\) 收敛。于是分离 packet、频率级联与近零均值 cutoff
都不能构造无 trace pseudomode。

## 4. 唯一剩余 leakage

尝试用形式对偶把 (2) 写为

\[
\int U\,\mathcal M^*(t^{-3/2})
\]

时，bulk 中

\[
\mathcal M^*(t^{-3/2})=O(t^{-5/2})
\]

完全可积。但在截断 \([T,R]\) 的移动右端点，仍出现固定宽度
\([R-\log2,R+\log2]\) 的 leakage。仅用 \(|U|\le Ct^{-1/2}\) 做绝对值上界会重新遇到
\(\int dh/h\) 的临界发散；形式正性也不自动保证该 leakage 对每个 \(R\) 消失。

因此当前最窄目标是先证明 signed tail cancellation (2)，得到平均 trace；点态 trace (4) 是下一层
独立 Tauberian 问题。任意一般 weighted coercivity 定理并非必要。

