> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 加入大素数会翻转完整 Möbius reciprocal 门的符号

## 精确恒等式

设 \(\phi:[0,\infty)\to\mathbb R\) 连续，满足
\(\phi(0)=0\) 且 \(\phi(u)=0\)（\(u\ge1\)）。固定平方自由整数
\(Y\)，取不整除 \(Y\) 的素数 \(p>Y\)，定义
\[
Q_\phi(X):=\sum_{a,b\mid X}\mu(a)\mu(b)\phi(ab/X).
\]
把 \(Yp\) 的除数写成 \(d\) 或 \(dp\)，其中 \(d\mid Y\)。逐项展开得
\[
\boxed{
Q_\phi(Yp)
=-2Q_\phi(Y)
+\sum_{d,e\mid Y}\mu(d)\mu(e)\,
\phi\!\left(\frac{de}{Yp}\right).
}
\tag{1}
\]
这里没有渐近近似：由于 \(p>Y\)，所有项
\(\phi(pde/Y)\) 已因其自变量 \(\ge1\) 而精确为零。

因 \(D_Y\) 是有限集、\(\phi\) 在零点连续，令 \(p\to\infty\) 得
\[
\boxed{
Q_\phi(Yp)=-2Q_\phi(Y)+o_Y(1).
}
\tag{2}
\]

## 迭代与 parity

若 \(p_1,\ldots,p_k\) 依次趋于无穷且互异于此前的基底，则对每个固定
\(k\)
\[
Q_\phi(Yp_1\cdots p_k)
=(-2)^kQ_\phi(Y)+o_Y(1),
\tag{3}
\]
其中极限按逐个素数的对角方式取得。符号翻转正是新素因子补集反射
\(R_p:d\mapsto Yp/d\) 在 Möbius 向量上的特征值 \(-1\)；因子 \(2\)
来自两个互补 half-block 的相同贡献。

## 与 universal PSD 的关系

note 384 用两素数尺度先找到一个 \(Y\) 使 \(Q_\phi(Y)>0\)，再用 (2)
立即产生 \(Q_\phi(Yp)<0\)。因此其超分离序列不是偶然的特殊构造：
任何非零正值 reciprocal 门都能通过加入一个足够大的新素数翻成负值。
这给出了 full Möbius signed intertwiner 必须保留的最小跨尺度关系。

反过来，若试图逐尺度取绝对值或把 \(Q_\phi(Yp)\) 替换成一个正 Gram，
式 (2) 的 parity 信息会被直接丢失；这正是普通 PSD/Feshbach 修正不能
代表原始 Möbius 门的原因。

本 note 不声称 RH；它把跨素数尺度的 signed 结构压缩为精确的一步
反射恒等式。
