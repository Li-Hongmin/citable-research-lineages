> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 完整 Yukawa atom 的精确 rank-one true-Schur 更新

## 1. 问题

note 060 的 clean K400 模型整体删除了 \(n\ge500\) 的正 Yukawa 尾。
不能把一个 atom 的有限 Fourier 压缩孤立补回，因为一般

\[
 P|r\rangle\langle r|P\oplus0
 \not\preceq |r\rangle\langle r|.
\]

本文给出保留完整补空间分量时的精确有限维更新。

## 2. 一次消去无限补空间

令 \(P=P_{400}\)、\(Q=I-P\)，并设合法的未消去下算子为

\[
 \mathcal L_0=
 \begin{pmatrix}A&X\\X^*&T\end{pmatrix},
 \qquad T>0.
\]

对一个真实全空间 Yukawa atom 写

\[
 r=\binom uv,qquad u=Pr,quad v=Qr.
\]

则

\[
 \mathcal L_0+|r\rangle\langle r|
 \preceq L_0+|r\rangle\langle r|,
\]

且消去 \(Q\) 后的 Schur 块精确为

\[
 \boxed{
 S_r=S_0+\frac{ee^*}{\eta},
 \qquad
 e=u-XT^{-1}v,quad
 \eta=1+v^*T^{-1}v,}
 \tag{1}
\]

其中 \(S_0=A-XT^{-1}X^*\)。因此一个完整 atom 只产生一个合法的
rank-one 正增益；直接加入 \(uu^*\) 会遗漏 graph correction 和分母。

有限 atom 族 \(F=U\oplus V\) 同理给出

\[
 \boxed{
 S_F=S_0+E(I+V^*T^{-1}V)^{-1}E^*,
 \qquad E=U-XT^{-1}V.}
 \tag{2}
\]

## 3. K400 的第二次 true-Schur

在 K400 的 \(7\oplus393\) 坐标中，将 (1) 的向量分为
\(e=(e_0,e_1)\)，并写 clean Schur 前的有限矩阵为

\[
 G=
 \begin{pmatrix}A_7&B\\B^*&C\end{pmatrix},
 \qquad C>0.
\]

再次消去 393 维补块后，七维增益仍为 rank one：

\[
 \boxed{
 \Delta_7=
 \frac{u_{\rm eff}u_{\rm eff}^*}
 {\eta+e_1^*C^{-1}e_1},
 \qquad
 u_{\rm eff}=e_0-BC^{-1}e_1.}
 \tag{3}
\]

故对任意七维见证 \(z\)，其精确修复量为

\[
 \boxed{
 \Delta_z=
 \frac{|z^*u_{\rm eff}|^2}
 {\eta+e_1^*C^{-1}e_1}.}
 \tag{4}
\]

式 (4) 是判断单 atom 能否修复 note 060 唯一负方向的最小标量门。

## 4. Scalar complement 下的 Parseval 闭合

取粗但合法的 \(T=t_{400}I_Q\)。对 even atom \(r_{500}\)，令

\[
 b=Pr_{500},\qquad g=Qr_{500},\qquad h=PB_0r_{500}.
\]

则无需枚举无限 Fourier 尾：

\[
 \boxed{
 PB_0g=h-(PB_0P)b,}
 \tag{5}
\]

以及

\[
 \boxed{
 \|g\|^2=\|r_{500}\|^2-\|b\|^2.}
 \tag{6}
\]

若

\[
 r_c(x)=
 \frac{e^{-c(a-x)}+e^{-c(a+x)}}{\sqrt{1-e^{-2ca}}},
 \qquad s=e^{-2ca},
\]

则

\[
 \boxed{
 \|r_c\|^2=\frac{1+s}{2c}+\frac{2as}{1-s}.}
 \tag{7}
\]

而 \(h\) 只需有限计算：active prime piecewise blocks、\(n<500\) atom
Gram 和 polar rank-one 项。于是 (1)--(4) 完全化为一个有限矩阵和两个
标量，不需要无限尾估计。

## 5. \(r_{500}\) 的严格区间门

固定

\[
 a=\frac12\log10,\qquad N=500,\qquad R=280,\qquad K=400,
\]

并从同一 \(N=500\) finite base 构造 scalar K400 下模型。这里

\[
 T=t_{400}I_Q,
 \qquad
 t_{400}=2.1793610668864147930\ldots .
\]

对完整 even atom \(r_{500}\)，有限 Parseval 计算严格得到

\[
 \|Qr_{500}\|^2
 =7.7750889318426851208\ldots\times10^{-5},
\]

以及

\[
 \eta
 =1+\frac{\|Qr_{500}\|^2}{t_{400}}
 =1.0000356760017877658\ldots .
 \tag{8}
\]

把 \(ee^*/\eta\) 加到完整

\[
 \mathbf R^7\oplus\mathbf R^{273}\oplus\mathbf R^{120}
\]

合同块，而不是孤立加入 \(P|r_{500}\rangle\langle r_{500}|P\)。先消去
273 维块，再消去 120 维块；第一次 verified solve 后的 120 维 Schur
补有严格 Cholesky 下界

\[
 p_{\min}>2.6682197026429414.
\]

最后七维 true-Schur 的 pivot 排列为

\[
 (6,5,2,1,0,4,3),
\]

前六个 pivot 严格为正，而最后一个满足

\[
 p_7\in
 [-4.2930133100000089,-4.2930066899999911]\times10^{-43}<0.
 \tag{9}
\]

因此完整 400 维 scalar K400/N500 加单个 full \(r_{500}\) atom 后仍有

\[
 \boxed{\operatorname{inertia}=(399,1,0).}
 \tag{10}
\]

承重运行入口与区间产物为

```text
scratch/log10_even_K400_N500_r500_scalar_gate.py
scratch/log10_even_K400_N500_r500_scalar_gate_arb_192.npz
```

输入 metadata 固定 `even, N=500, R=280, K=400, atom=500,
precision=192`；运行不读取 sharp cache、`Rcov` 或任何孤立 Yukawa
compression。

## 6. 决策含义

该归约给出了 note 060 后第一个合法的正恢复接口。但必须保持 base 同源：
若 \(S_{\rm scalar}\preceq G_J\preceq S_{\rm diag}\)，由 scalar lift 得到的
\(\Delta_{\rm scalar}\) 只能直接加到 \(S_{\rm scalar}\)，不能事后加到
更尖锐的 \(G_J\)。保留 sharp 优势需要把 atom 与 diagonal tail 作联合
covariance 消去。

因此最先执行的严格门是

\[
 S_{\rm scalar}+\Delta_{500}^{\rm scalar},
\]

而不是 \(G_J+\Delta_{500}^{\rm scalar}\)。流程为：

```mermaid
flowchart LR
  A["clean K400 下模型"] --> B["加入完整 r_n r_n*"]
  B --> C["Parseval 消去 Q 尾"]
  C --> D["rank-one true-Schur 增益"]
  D --> E["7×7 interval LDL"]
```

严格证书 (10) 说明单个完整 \(r_{500}\) 仍不足以恢复 scalar K400/N500
下模型。下一最小对象是同一 scalar lift 中的有限 atom 族 (2)，而不是换用
sharp base 后再叠加 scalar gain。由于该模型只是原算子的 Loewner 下界，
(10) 只关闭这一单 atom 路线，不能推出 \(A^+_{\frac12\log10}\) 或完整
算子不定。

这一有限族门已在 [note 064](064-strict-even-local-weil-positivity-to-log10-half.md)
闭合：有序前缀 39 项仍严格不定，而加入 \(r_{500},\ldots,r_{539}\) 后
同一 scalar 下算子严格正，从而推出偶扇区端点正性。
