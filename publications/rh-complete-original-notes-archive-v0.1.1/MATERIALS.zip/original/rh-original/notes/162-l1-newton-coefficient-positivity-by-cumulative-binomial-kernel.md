> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# L=1 Newton 系数的全 m 正性

日期：2026-08-15。

本 note 闭合 note 157 中首个未完成层：
\[
\gamma_{m,h,1}\ge 0\qquad(m\ge1,\;0\le h\le 3m+1).
\]
这不是所有 \(L\) 的正性证明，也不提供 Möbius signed quadratic form 的平方根界。

## 1. 化为一个累计核

令 \(D=3m+3\)、\(d=D-2\)、\(r_q=D-q-1\)，并取 note 157 的
\(K_q\)（\(1\le q\le m+1\)）。这里始终使用 q-shift 权重
\(w_q=c_{m-1,q}\binom Dq\)；不能替换为 \((q+1)c_{m-1,q}\)。由
\[
A_{q+1}(x)=x+(2^{q+1}-2)x^2+O(x^3)
\]
及 \(E_{r,h}^{(d)}\) 的定义，置
\[
a_s=\frac{\binom hs}{\binom ds},
\qquad
t_q=[x^2]A_{q+1}(x)E_{r_q,h}^{(d)}(x).
\]
则
\[
t_q=\sum_{s<r_q}\binom{r_q}{s}a_s
 +(2^{q+1}-2)a_{r_q},
\qquad
6\gamma_{m,h,1}=\sum_qK_qt_q.
\tag{1}
\]
定义
\[
J_s=\sum_{r_q>s}K_q\binom{r_q}{s}
 +\sum_{r_q=s}K_q(2^{q+1}-2),
\qquad C_s=\sum_{j=0}^sJ_j.
\tag{2}
\]
于是 \(6\gamma_{m,h,1}=\sum_sJ_sa_s\)。关键是证明所有 \(C_s\ge0\)。

## 2. 原始累计和的 Beta 正表示

先把端点替换暂时改回普通二项式系数，记
\[
\widetilde C_s=\sum_qK_q\sum_{j=0}^{\min(s,r_q)}\binom{r_q}{j}.
\]
反向 Bessel 权重的 Beta 表示给出严格恒等式
\[
\widetilde C_s=\sum_{k=0}^{m-2}\omega_{m,k}R_{k,s},
\qquad \omega_{m,k}>0,
\tag{3}
\]
其中
\[
W(z)=A_m z^2\int_0^1t^{m-1}(1-t)^{m+2}(t+2z)^{m-1}\,dt,
\quad
A_m=\frac{(3m+3)!}{2^m\binom{3m+3}{2}(m-1)!(m+2)!},
\]
\[
\omega_{m,k}=A_m\binom{m-2}{k}2^{m-2-k}B(m+k,m+3)>0.
\tag{3a}
\]
式 (3) 背后的生成恒等式为
\[
\sum_{s\ge0}\widetilde C_sx^s
 =\frac{(1+x)^{D-1}K((1+x)^{-1})}{1-x}.
\tag{3b}
\]
其中
\[
N_k=2m+1+k,
\quad \mu_k=\frac{m+k}{2m+k+3},
\quad H_j(N)=\sum_{i=0}^j\binom Ni,
\]
\[
R_{k,s}=B_0H_s(N_k)+B_1H_{s-1}(N_k)+B_2H_{s-2}(N_k),
\tag{4}
\]
\[
B_0=2m+(3m-2)\mu_k,quad
B_1=-2m-4+(3m-5)\mu_k,quad
B_2=-3\mu_k.
\]
（\(H_j=0\) 对 \(j<0\) 约定。）将 (4) 重排为
\[
R_{k,s}=(B_0+B_1+B_2)H_{s-2}(N_k)
 +(B_0+B_1)\binom{N_k}{s-1}
 +B_0\binom{N_k}{s}.
\tag{5}
\]

当 \(m\ge4\) 时 \(\mu_k\ge m/(2m+3)\)，从而
\[
B_0>0,
\]
\[
B_0+B_1\ge
\frac{6m^2-19m-18}{2m+3}>0,
\]
\[
B_0+B_1+B_2\ge
\frac{6(m^2-3m-2)}{2m+3}>0.
\tag{6}
\]
因此 (5) 的每一项非负，故 \(\widetilde C_s\ge0\)。

## 3. 端点替换仍保持累计正性

实际的 \(J_s\) 只在 \(s\ge r_q\) 时把 \(1\) 换成
\(2^{q+1}-2\)，所以
\[
C_s-\widetilde C_s=E_s
 =\sum_{q=Q_s}^{m+1}K_q(2^{q+1}-3),
\qquad Q_s=\max(1,D-1-s),
\tag{7}
\]
（若 \(Q_s>m+1\)，则为空和）。令
\(T_Q=\sum_{q=Q}^{m+1}K_q\)。note 157 已给出 \(T_Q>0\)，包括
\(Q=1\) 的边界项。因为 \(b_q=2^{q+1}-3>0\) 严格递增，Abel 变换给出
\[
E_s=T_{Q_s}b_{Q_s}
 +\sum_{q>Q_s}T_q(b_q-b_{q-1})\ge0.
\tag{8}
\]
结合 (3)--(8)，得到 \(C_s\ge0\) 对所有 \(m\ge4\)。

## 4. 对递减超几何权重作 Abel 变换

对固定 \(h\)，\(a_s=\binom hs/\binom ds\) 满足
\[
\frac{a_{s+1}}{a_s}=\frac{h-s}{d-s}\le1,
\]
并在 \(s>h\) 后为零。因此
\[
\sum_sJ_sa_s
 =C_da_d+\sum_{s=0}^{d-1}C_s(a_s-a_{s+1})\ge0.
\tag{9}
\]
这证明了 \(m\ge4\) 的 \(\gamma_{m,h,1}\ge0\)。

## 5. 小层

直接代入 (1) 得到 \(m=1,2,3\) 的所有 \(h\) 值分别为
\[
\begin{array}{c|l}
m&\gamma_{m,h,1}\ (h=0,\ldots,3m+1)\\ \hline
1&1/6,1/6,0,1/6,1/6\\
2&3,9/2,19/3,8,8,7,15/2,9\\
3&147/2,237/2,562/3,289,432,1856/3,832,1037,3614/3,2685/2,2955/2.
\end{array}
\]
均非负，完成全 \(m\) 的 \(L=1\) 层。

## 6. 边界

该结果只处理 \(L=1\)。\(L\ge2\) 仍需要控制完整的
\([x^{L+1}]A_{q+1}E_{r_q,h}\) 加权和；现有逐项正化在最小层已经失败。
即使所有 Newton 系数最终均正，仍需独立建立 Möbius signed Hankel
二次型的平方根级 arithmetic intertwiner；正 detector 或普通 PSD Gram
本身不能提供 RH 证明。
