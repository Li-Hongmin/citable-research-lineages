> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 次数十五是四个 odd residue 正 detector 的自然最小次数

日期：2026-08-15。

相关文件：[note 144](144-a-positive-degree-fifteen-detector-removes-four-collective-residues.md)。

本 note 给出次数下界；正性本身由 note 144 的完整 Bernstein 证书承担。

## 1. 条件与移位 Euler--Faulhaber 强制因子

令 (V) 为实多项式，区间外零延拓，并定义

\[
P_V(y)=\sum_{c\le y}V(c/y),\qquad y\ge1.
\]

假设

\[
V(0)=V(1)=0,qquad \int_0^1V=0,qquad
v_1=v_3=v_5=v_7=0,qquad P_V(y)\ge0.
\tag{1}
\]

写 y=N+r，N=floor(y)，0<=r<1。固定 r 后的移位
Euler--Faulhaber 展开为

\[
P_V(N+r)=
\sum_{k\ge1}
\frac{B_k(1-r)V^{(k-1)}(1)-B_kV^{(k-1)}(0)}
{k!(N+r)^{k-1}}.
\tag{2}
\]

考察 k=2,...,9。下端项依次因

\[
V'(0)=0,\; B_3=0,\; V'''(0)=0,\; B_5=0,\;
V^{(5)}(0)=0,\; B_7=0,\; V^{(7)}(0)=0,\; B_9=0
\tag{3}
\]

消失。每个 B_k(1-r) 在 0<r<1 取正负两值。若相应的
V^(k-1)(1) 首个不为零，则 (2) 对某个固定 r 在充分大 N 时为负，
与 (1) 矛盾。因此

\[
V^{(j)}(1)=0\quad(1\le j\le8).
\tag{4}
\]

结合 V(0)=V'(0)=0 与 V(1)=0，得到

\[
\boxed{u^2(1-u)^9\mid V(u).}
\tag{5}
\]

## 2. 次数不超过十四时只有零解

若 \(\deg V\le14\)，写

\[
V=u^2(1-u)^9(a_0+a_1u+a_2u^2+a_3u^3).
\tag{6}
\]

将 (6) 代入 v3=v5=v7=0 及零均值，得到

\[
\begin{aligned}
v_3&=-9a_0+a_1,\\
v_5&=-84a_0+36a_1-9a_2+a_3,\\
v_7&=-6(21a_0-21a_1+14a_2-6a_3),\\
\int_0^1V&=(91a_0+21a_1+6a_2+2a_3)/60060.
\end{aligned}
\tag{7}
\]

该有理线性系统的精确解为

\[
a_0=a_1=a_2=a_3=0.
\tag{8}
\]

例如用符号展开，前三个系数条件与 Beta 积分组成的矩阵满秩；等价地，
其唯一解为零。故在条件 (1) 下

\[
\boxed{\deg V\le14\Longrightarrow V=0.}
\tag{9}
\]

次数十五时商为四次，多出一维解空间。取

\[
a_0=-3,\quad a_1=-27,\quad a_2=-57,\quad a_3=207,\quad a_4=1024
\tag{10}
\]

即得到 note 144 的

\[
V_{15}=u^2(1-u)^9(1024u^4+207u^3-57u^2-27u-3),
\]

其全半轴正性由固定 N=floor(y) 的 Bernstein--falling-factorial
证书严格验证。因此次数十五是该自然 detector 类中同时消去
\(s=-1,-3,-5,-7\) 的最小次数。

这只是 detector 层级的最小性，不是 RH 证明；仍需控制 note 144 中完整的
signed Möbius quadratic form。
