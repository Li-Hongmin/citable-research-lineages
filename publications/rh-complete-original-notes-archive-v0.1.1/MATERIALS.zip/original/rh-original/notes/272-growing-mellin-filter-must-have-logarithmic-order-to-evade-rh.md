> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 随尺度增长的 Mellin 滤波器：绕开 RH 门所需的最小零点阶

日期：2026-08-16。

note 271 处理固定有限 Dirichlet 预条件。这里允许预条件器随截断 \(X\)
变化，给出一个定量边界：只要其零频零点阶增长慢于
\(\log X/\log\log X\)，并且局部归一化不退化，统一的
\(N^{1+\varepsilon}\) 正能量界仍然推出 Mertens 平方根界。

## 命题

令
\[
F_X(t)=\sum_{n\le X}a_n n^{it},\qquad
M(x)=\sum_{n\le x}a_n,
\]
并设 \(w(t)\ge c_0>0\) 于某个固定邻域 \(|t|\le\delta_0\)。对每个 \(X\)，
令 \(A_X\) 为一个实轴附近定义的滤波器。假设存在整数 \(q_X\ge0\)、常数
\(c_X>0\) 及固定 \(\delta>0\)，使
\[
|A_X(t)|\ge c_X|t|^{q_X}
\qquad (|t|\le \delta/\log X).
\tag{1}
\]
若对每个 \(\eta>0\)
\[
\int_{\mathbb R}w(t)|A_X(t)|^2|F_X(t)|^2\,dt
\ll_\eta X^{1+\eta},
\tag{2}
\]
且
\[
q_X=o\!\left(\frac{\log X}{\log\log X}\right),
\qquad c_X^{-1}=X^{o(1)},
\tag{3}
\]
则
\[
M^*(X):=\max_{x\le X}|M(x)|
\ll_{\varepsilon}X^{1/2+\varepsilon}.
\tag{4}
\]

## 证明

取 \(X_0\le X\) 使 \(|M(X_0)|=M^*(X)\)。令
\(\kappa=\min(\delta,1/16)\)。Abel 部分求和与 note 246
相同，给出
\[
|F_{X_0}(t)|\ge \frac34M^*(X)
\qquad \left(|t|\le\frac{\kappa}{\log X_0}\right).
\tag{5}
\]
将 (1) 用于 \(X_0\)，得到
\[
\begin{aligned}
\int w(t)|A_{X_0}(t)|^2|F_{X_0}(t)|^2\,dt
&\ge \frac9{16}c_0c_{X_0}^2M^*(X)^2
\int_{-\kappa/\log X_0}^{\kappa/\log X_0}|t|^{2q_{X_0}}dt\\
&\gg c_{X_0}^2M^*(X)^2
(\kappa/\log X_0)^{2q_{X_0}+1}.
\end{aligned}
\tag{6}
\]
结合 (2) 得
\[
M^*(X)^2
\ll_\eta X^{1+\eta}c_{X_0}^{-2}
\left(\frac{\log X_0}{\kappa}\right)^{2q_{X_0}+1}.
\tag{7}
\]
由 (3)，
\[
c_{X_0}^{-2}\left(\frac{\log X_0}{\kappa}\right)^{2q_{X_0}+1}=X_0^{o(1)},
\]
故 (7) 对任意给定 \(\varepsilon>0\) 给出
\(M^*(X)\ll_\varepsilon X^{1/2+\varepsilon}\)。有限多个小 \(X_0\) 并入常数。
\(\square\)

## 复杂度含义

若 \(A_X\) 是次数为 \(L_X\) 的非零有限 Dirichlet 多项式，则其在
\(t=0\) 的零点阶满足 \(q_X\le L_X\)。因此在局部归一化
\(c_X^{-1}=X^{o(1)}\) 下，任何满足
\[
L_X=o\!\left(\frac{\log X}{\log\log X}\right)
\]
的有限预条件器都不能绕开 RH-strength 门。真正可能逃逸的滤波器至少需要：

1. 零频零点阶达到 \(\Omega(\log X/\log\log X)\)；或
2. 在 \(1/\log X\) 的窗口内出现 \(X^{\Omega(1)}\) 级的归一化退化；或
3. 放弃逐频率正能量，改用保留符号的跨频率算术 intertwiner。

这把“允许滤波器随尺度增长”从一个模糊设想压缩为明确的复杂度门；它没有
声称存在满足这些条件的滤波器，也没有给出 RH 证明。
