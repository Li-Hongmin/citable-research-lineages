> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 局部 Weil 算子的严格正性推进到 \(\frac12\log8\)

日期：2026-08-12。

本文把 note 054 的严格正性端点推进到

\[
a_8=\frac12\log8=\frac32\log2.
\]

## 定理

\[
\boxed{
A_a^+>0,\qquad A_a^->0,
\qquad 0<a\le\frac12\log8.}
\tag{1}
\]

因此

\[
\boxed{A_a>0\quad(0<a\le\tfrac12\log8),}
\qquad
\boxed{a_{\rm deg}>\tfrac12\log8.}
\tag{2}
\]

## Prime 压缩与两步范数界

在 \(2a=\log8\) 时，正测度 overlap 的非零 von Mangoldt 项恰为

\[
n=2,3,4,5,7.
\]

其中 \(n=8\) 只在区间直径处零测度接触。令
\(\alpha_n=\Lambda(n)/\sqrt n\)，\(\sigma=+1\) 表示偶扇区，
\(\sigma=-1\) 表示奇扇区。半区 prime 算子为

\[
P^\sigma
=-\alpha_2(S_2+S_2^*)
-\sigma\sum_{n\in\{2,3,4,5,7\}}\alpha_nJ_n.
\tag{3}
\]

无网格的 17-cell Arb 枚举给出

\[
\sup D_2
=(x+y)(2x+y)+z(x+y+z)+w(x+y+z+w)
+v(x+y+z+w+v),
\tag{4}
\]

其中 \((x,y,z,w,v)=(\alpha_2,\alpha_3,\alpha_4,\alpha_5,\alpha_7)\)。数值为

\[
\sup D_2=6.0542380080781177008\ldots,
\]

故两个扇区同时满足

\[
\boxed{\|P^\sigma\|\le2.46053612208358317<2.460537.}
\tag{5}
\]

## 偶扇区

保留前 \(N=400\) 个正 Yukawa atoms，取前 \(R=200\) 个 Fourier modes，并以
(5) 控制补空间。完整五维 Householder--Schur 证书给出

\[
\mu_+>2.105680884367627,
\qquad
C_+\succeq4.9999996744\times10^{-7}I.
\tag{6}
\]

最终五维 Schur 块的 interval pivots 全部严格为正；最小承重 pivot 约为
\(1.49\times10^{-27}\)。因此

\[
A_{a_8}^+>0.
\tag{7}
\]

## 奇扇区：有限正尾的完整 Feshbach 更新

仅使用 \(N=400\) 的标量补空间下模型会留下一个严格微负 pivot。关键修正不是继续增加
Fourier 维数，而是显式加入 Yukawa atoms \(400\le n<500\)，并在旧 Householder 合同坐标中
更新全部三个分块：

\[
\Delta=
\begin{pmatrix}
\Delta_{11}&\Delta_{12}\\
\Delta_{21}&\Delta_{22}
\end{pmatrix}.
\tag{8}
\]

若旧分块为 \((A,X,C)\)，则严格形成

\[
A_{\rm new}=A+\Delta_{11},\qquad
X_{\rm new}=X+\Delta_{12},\qquad
C_{\rm new}=C+\Delta_{22}.
\tag{9}
\]

这里不能只检查旧 Schur 图上的 \(Z^*\Delta Z\)：因为 \(\Delta\) 一般不半正定，必须重新控制
补块和交叉块。低内存 Arb 证书直接计算 (9)，得到

\[
\boxed{C_{\rm new}\succeq4.3623426978527551\times10^{-5}I.}
\tag{10}
\]

随后用 verified solve 形成真正的 Schur 补

\[
K_{\rm new}
=A_{\rm new}-X_{\rm new}C_{\rm new}^{-1}X_{\rm new}^*.
\tag{11}
\]

对称选主元 LDL 的排列为 \((4,3,1,0,2)\)，五个 pivots 为

\[
\begin{aligned}
p_1&>1.9280589\times10^{-8},\\
p_2&>5.8780733\times10^{-13},\\
p_3&>5.7155932\times10^{-18},\\
p_4&>1.6132024\times10^{-23},\\
p_5&>2.7636450\times10^{-30}.
\end{aligned}
\tag{12}
\]

最后一个区间半径小于 \(8.62\times10^{-42}\)。结合
\(\mu_->1.712745572661\ldots\)，得到

\[
A_{a_8}^->0.
\tag{13}
\]

## 复现

以下命令从头生成临时 Arb 缓存并验证全部承重不等式：

```bash
uv run --with python-flint python \
  computations/verify_log8_prime_two_step_degree.py 256

uv run --with python-flint --with numpy python \
  computations/verify_log8_endpoint_base.py 192 200 400 +

uv run --with python-flint --with numpy python \
  computations/verify_log8_endpoint_base.py 192 200 400 - --export-small-map-only

uv run --with python-flint --with numpy python \
  computations/verify_log8_odd_tail_update_stage1.py 128 --export-update-factors

uv run --with python-flint --with numpy python \
  computations/verify_log8_odd_tail_update_stage2.py 128 --export-delta-blocks

uv run --with python-flint --with numpy python \
  computations/verify_log8_odd_tail_update_stage3.py 128
```

最后一阶段用纯 Arb 逐元残差认证 \(195\times195\) 补块；浮点 Cholesky 只选择 dyadic
见证，不承重。

## 结论边界

由零延拓的形式域嵌套和谱底单调性，端点结果传播到全部较小尺度，得到 (1)--(2)。本定理仍是
有限尺度严格正性，不证明全尺度 Weil 正性或 RH。它给出的可迁移机制是：当标量补空间界在近核
方向损失符号时，保留有限正 Yukawa 尾并对完整合同分块作低秩 Feshbach 更新，而不是只检查旧
Schur 图或盲目扩大有限矩阵。
