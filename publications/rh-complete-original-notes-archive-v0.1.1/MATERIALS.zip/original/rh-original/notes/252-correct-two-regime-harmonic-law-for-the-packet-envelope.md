> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 19.216 harmonic envelope 的正确两区量级

日期：2026-08-16。

## 定义

令 (q\ge 16)、(1\le L\le q/8)，并对 (1\le H\le q/4) 定义

\[
  \mathscr H_{q,L}(H)
  :=\frac1q\sum_{H<|h|\le2H}
       \min\!\left(L,\frac q{|h|}\right)^2.
\]

这是 Theorem 19.216 在离散 summation-by-parts 后实际需要控制的 harmonic
包络；在该范围内 (|h/q|=|h|/q)。

## 正确的两区估计

若 (2H\le q/L)，则 (q/|h|\ge L) 对块中每个 (h) 成立，所以

\[
  \mathscr H_{q,L}(H)\asymp \frac{HL^2}{q}.
\tag{1}
\]

若 (H\ge q/L)，则 (q/|h|\le L)，并且

\[
  \mathscr H_{q,L}(H)
  =2q\sum_{H<h\le2H}\frac1{h^2}
  \asymp \frac qH.
\tag{2}
\]

在过渡区 (q/(2L)<H<q/L) 两式均给出量级 (L)，直接分拆块中
\(h\le q/L\) 与 (h>q/L) 的部分即可得到同阶上下界。因此可写成

\[
  \mathscr H_{q,L}(H)asymp
  \frac Hq\min\!\left(L^2,\frac{q^2}{H^2}\right)
\]

在两端区间成立，并在过渡区取 (asymp L)。常数是绝对的。

证明只用块中正整数个数 (asymp H) 以及
\(sum_{H<h\le2H}h^{-2}asymp H^{-1})。

## 与原稿显示式的比较

Theorem 19.216 的证明把同一包络写成

\[
  \frac{LH}{q}+O\!\left(\frac{\log(2q)}q\right).
\tag{3}
\]

在低频区 (2H\le q/L)，(1) 与 (3) 相差一个因子 (L)；在
\(L\asymp q^{1/2})、(H=1) 时，真实包络为 (asymp1)，而 (3) 只有
\(O(q^{-1/2}\operatorname{polylog}q))。这不是常数或端点项可以吸收的误差。

若去掉前面的 (q^{-1}) 以匹配 Definition 20.12 的 raw energy，正确低频量级
变为 (HL^2)，而将 (3) 同乘 (q) 只得到 (LH+O(\log q))，缺失的 (L)
因子仍然存在。

## 全 dyadic 和的微妙之处

把所有 (H)（按二进制块）相加，正确的包络满足

\[
  \sum_{H\ {m dyadic}\le q/4}\mathscr H_{q,L}(H)asymp L.
\tag{4}
\]

低频块的几何级数由最大 (H\asymp q/L) 控制，贡献 (asymp L)；高频块
由最小 (H\asymp q/L) 控制，也贡献 (asymp L)。所以全频 Parseval 式的
粗总量可能仍是 (O(L))，但这不能恢复原稿所需的逐 (H) Cauchy--Schwarz：
后者正是利用每个块分别与 dual energy 配对，而低频块的缺失因子会改变配对预算。

## 裁决

因此，19.216 的 harmonic estimate 应先替换为 (1)--(2) 的两区形式。若作者
改为全频一次性聚合，需重新证明新的 spectral/capacity 配对；若保留逐 dyadic
块策略，则必须补充实际 (Gamma) 的零频消失或额外 (ell^2) 抵消，不能仅依赖
(ell^1)、sup 和总变差。这个引理独立于模乘 residue 置换错误和 shell 归一化缺口。
