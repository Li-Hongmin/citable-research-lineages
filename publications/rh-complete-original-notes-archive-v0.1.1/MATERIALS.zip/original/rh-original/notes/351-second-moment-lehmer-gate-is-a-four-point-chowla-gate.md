> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Lehmer 差值二阶平均的最小新门是四点 Möbius 相关

日期：2026-08-16。

note 350 已把精确 Lehmer 上三角写成差值 \(h=q-m\) 的 dyadic 段，并用
MRT 的一阶移位平均得到 \(N^2\rho_N\) 对数节省。一个自然的下一步是对
各差值相关使用 Cauchy--Schwarz；本 note 说明该路线的真正算术输入不是
另一个二点平均，而是四点平行四边形相关。

## 1. 未加权模型

令
\[
 C_H(h)=\sum_{n\le N-h}\mu(n)\mu(n+h),\qquad 1\le h\le H.
\]
其二阶总量精确展开为
\[
 \sum_{h\le H}|C_H(h)|^2
 =
 \sum_{\substack{1\le h\le H\\n_1,n_2\ge1\\n_i+h\le N}}
 \mu(n_1)\mu(n_1+h)\mu(n_2)\mu(n_2+h).
\tag{1}
\]
令 \(d=n_2-n_1\)，并按 \(n=n_1\) 重排，则每个非零项成为
\[
 \mu(n)\mu(n+h)\mu(n+d)\mu(n+d+h),
\tag{2}
\]
其中 \(n,n+h,n+d,n+d+h\le N\)。这就是四点平行四边形
\((n,n+h,n+d,n+d+h)\) 的 Möbius 相关。

## 2. 加入 Lehmer 权

在 note 350 的一个 dyadic 差值段 \(H<h\le2H\) 中，权
\(m/(m+h)\) 和截断只产生有界系数。若写
\[
 C_H^{(w)}(h)=\sum_n
 \mu(n)\mu(n+h)w_{N,H}(n,h),\qquad |w_{N,H}|\le 2,
\]
则
\[
 \sum_h|C_H^{(w)}(h)|^2
 =
 \sum_{h}\sum_{n_1,n_2}
 \mu(n_1)\mu(n_1+h)\mu(n_2)\mu(n_2+h)
 w(n_1,h)\overline{w(n_2,h)}.
\tag{3}
\]
因此权只给一个平滑振幅，核心仍是 (2)。任何目标
\[
 \sum_{h\asymp H}|C_H^{(w)}(h)|^2
 \ll_\varepsilon N^{2+\varepsilon}
\tag{4}
\]
都已经是一个带平滑振幅的四点 Chowla 型命题。

## 3. Cauchy 所能给出的量级

对一个差值段，
\[
 \left|\sum_{h\asymp H}C_H^{(w)}(h)\right|^2
 \le H\sum_{h\asymp H}|C_H^{(w)}(h)|^2.
\tag{5}
\]
即使假设理想的四点界 (4)，在 \(H\asymp N\) 时也至多得到
\(O_\varepsilon(N^{3+\varepsilon})\) 的平方，亦即
\[
 \left|\sum_{h\asymp N}C_H^{(w)}(h)\right|
 \ll_\varepsilon N^{3/2+\varepsilon}.
\tag{6}
\]
这会是一个真正的固定幂次改进，但 (4) 本身不是现有 MRT Theorem 1.6
的结论。MRT 论文明确指出其二点平均方法的节省量级约为
\(\log\log H/\log H\)，并不能直接提供固定幂次的四点相关。

## 4. 结论

“对差值相关再做一次 Cauchy”不是已完成的突破；它把问题从二点
Möbius 平均提升为四点平行四边形 Möbius 相关。若能证明 (4)（更弱的
平滑版本也足够），便可把 note 350 的 \(N^{2-o(1)}\) 推进到
\(N^{3/2+\varepsilon}\)，但距离 note 347 的 \(N^{1+\varepsilon}\)
平方根门仍有半个幂次。继续推进仍需真正的四点/更高阶 Möbius 算术输入，
不能由现有二点 MRT 结果自动推出。
