> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# dyadic 正相关部的加性 Fourier 正核与低频障碍

日期：2026-08-16。

依赖：[note 265](265-one-sided-dyadic-correlation-gate-is-sufficient-for-rh.md)、
[note 267](267-dyadic-block-fourier-multiplier-is-indefinite.md)、
[note 279](279-mertens-excess-forces-a-macroscopic-positive-dyadic-correlation.md)。

本 note 给出一个精确的坐标转换：dyadic 相关块的正部总量可以被一个
显式的非负加性 Fourier 权控制。该权在零频有线性高峰，因此转换本身不产生
新的平方根 cancellation；它把剩余命题明确成低频加性 Möbius 多项式的加权能量。

## 1. 精确 Fourier 恒等式

令

$$
F_N(\theta)=\sum_{n\le N}\mu(n)e^{2\pi i n\theta},
\qquad 0\le\theta\le1,
$$

并令

$$
b_H(\theta)=\sum_{H\le h<\min(2H,N)}
\cos(2\pi h\theta),
\qquad H=1,2,4,\ldots<N.
$$

由 Fourier 正交性，若

$$
C_h(N)=\sum_{n\le N-h}\mu(n)\mu(n+h),
$$

则

$$
C_h(N)=\int_0^1|F_N(\theta)|^2\cos(2\pi h\theta)\,d\theta.
$$

因此 note 279 的 dyadic 块满足精确恒等式

$$
\boxed{
D_H(N)=\int_0^1b_H(\theta)|F_N(\theta)|^2\,d\theta.}
\tag{1}
$$

这里 $b_H$ 本身不是非负函数；这正是 note 267 中的 signed multiplier
障碍。

## 2. 正部的直接正化

定义

$$
W_N(\theta)=\sum_{H<N}b_H(\theta)^+.
$$

因为 $|F_N|^2\ge0$，对每个 $H$ 有

$$
D_H(N)^+
\le \int_0^1 b_H(\theta)^+|F_N(\theta)|^2\,d\theta.
$$

求和得到严格上界

$$
\boxed{
\sum_{H<N}D_H(N)^+
\le \int_0^1W_N(\theta)|F_N(\theta)|^2\,d\theta.}
\tag{2}
$$

这不是对 $D_H$ 的等价重写，而是把每个 signed 块逐块取正部后的
最直接非负 majorant；任何由 (2) 得到的 RH 结论都必须支付该正化损失。

## 3. 显式低频包络

写

$$
\delta=\|\theta\|_{\mathbb R/\mathbb Z}\in[0,1/2].
$$

几何级数给出统一估计

$$
|b_H(\theta)|
\le \min\!\left(H,\frac{1}{2|\sin(\pi\theta)|}\right)
\ll \min(H,\delta^{-1}).
\tag{3}
$$

将 dyadic $H$ 在 $\delta^{-1}$ 处分成两段，得到

$$
W_N(\theta)
\ll
\begin{cases}
N,&0\le\delta\le N^{-1},\\[2mm]
\delta^{-1}\bigl(1+\log(2N\delta)\bigr),&N^{-1}<\delta\le1/2.
\end{cases}
\tag{4}
$$

同时

$$
W_N(0)=\sum_{H<N}H\asymp N,
\qquad
\int_0^1W_N(\theta)\,d\theta\ll (\log(2N))^2.
\tag{5}
$$

所以正部 majorant 的总质量只有对数平方量级，但其点态算子峰值在零频
是 $\asymp N$。这两项事实并不矛盾：该权把质量集中在宽度约 $N^{-1}$
的低频窗内。

## 4. 为什么普通 Fourier 正性仍不够

Parseval 只给

$$
\int_0^1|F_N(\theta)|^2d\theta
=\sum_{n\le N}\mu(n)^2\le N.
$$

把它与 (4) 结合只能使用 $\|W_N\|_\infty\asymp N$，从而回到
$O(N^2)$ 量级；使用 $\|W_N\|_1$ 则需要一个尚未证明的
$L^\infty$ 控制 $F_N(\theta)$。更高的 Hölder/Parseval 估计会引入
$\|F_N\|_4$ 及四点 Möbius 相关，正是 note 244 的另一个算术门。

特别地，在零频点

$$
F_N(0)=M(N),
$$

故 (4) 的高峰直接保留 Mertens 和。任何能把右端 (2) 压到
$N^{1+\varepsilon}$ 的统一估计，至少必须在宽度约 $N^{-1}$ 的低频窗
控制 $F_N$，从而重新包含 RH-strength 的 Mertens 门；它不能由一般 Fourier
正算子或 coefficient-blind large sieve 自动产生。

## 5. 对跨尺度 signed intertwiner 的精确要求

要避免 (2) 的正化损失，必须直接利用

$$
\int_0^1 b_H(\theta)|F_N(\theta)|^2d\theta
$$

在不同 $H$ 之间的 signed cancellation，或者构造一个把 dyadic multiplier
族同时映射到 Möbius 乘法结构的算术 intertwiner。只对每个 $b_H$ 做 PSD
化会丢失其零均值/变号结构；只做一般 Fourier 谱估计则在零频峰处停在
$N^2$ 量级。

因此当前最薄的等价目标仍是 note 265 的

$$
\sum_H D_H(N)^+\ll_\varepsilon N^{1+\varepsilon}
$$

或 note 243 的 block-$L^2$ signed 门；本 note 只是给出它们的显式
加性 Fourier 正核包络，不声称已证明 RH。

