> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 约化 Weil 算子的严格正基态与奇扇区谱隙

日期：2026-08-11。本文以 note 007 的极点删除形式为输入，证明其半群不可约、谱底简单且基态
几乎处处严格正，并由反射对称性得到全尺度严格奇扇区谱隙。

## 1. 纯跳 Dirichlet 形式

固定 \(a>0\)，令 \(M_a\) 为

\[
q_a^{\mathrm{red}}=Q_W^a-q_{\mathrm{pol}}
\]

所对应的自伴算子，其中 \(q_{\mathrm{pol}}\) 是 note 007 的签名 \((1,1)\) 极点项；这里没有减去
prime-shift 算子 \(P_a\)。记

\[
\Omega_a=(-a,a),\qquad
k(t)=\frac{e^{-t/2}}{1-e^{-2t}},\qquad
\alpha_n=\frac{\Lambda(n)}{\sqrt n},\qquad \tau_n=\log n.
\]

由 Suzuki 的 Archimedean 乘子与 digamma 积分表示，零延拓后有

\[
\boxed{q_a^{\mathrm{red}}(v)=\mathcal E_a(v)+C_a\|v\|_2^2,}
\]

其中

\[
\begin{aligned}
\mathcal E_a(v)
={}&\int_0^\infty k(t)
\int_{\mathbb R}|v(x+t)-v(x)|^2\,dx\,dt\\
&+\sum_{2\le n\le e^{2a}}\alpha_n
\int_{\mathbb R}|v(x+\tau_n)-v(x)|^2\,dx,
\end{aligned}
\]

以及

\[
C_a=\psi(1/4)-\log\pi
-2\sum_{2\le n\le e^{2a}}\frac{\Lambda(n)}{\sqrt n}.
\]

这里 \(\mathcal E_a\) 是稠密、闭、对称的纯跳 Dirichlet form，且

\[
D(\mathcal E_a)=D(q_a^{\mathrm{red}})=H((-a,a)).
\]

标量 \(C_aI\) 不改变半群的正性、不可约性、本征函数或扇区谱隙。

## 2. 严格模等号刻画

对 \(v\in D(\mathcal E_a)\)，令

\[
\Delta_v(x,y)
=|v(x)||v(y)|-\Re(v(x)\overline{v(y)})\ge0.
\]

note 007 的差公式给出

\[
q_a^{\mathrm{red}}(v)-q_a^{\mathrm{red}}(|v|)\ge0.
\]

由于

\[
k(t)>0\qquad\forall t>0,
\]

等号当且仅当 \(v\) 在其非零集上具有同一复相位。特别地，对实值函数，

\[
\boxed{
v_+\ne0, v_-\ne0
\Longrightarrow
q_a^{\mathrm{red}}(|v|)<q_a^{\mathrm{red}}(v).}
\]

这已经说明任一 ground-state 向量具有常相位并可取非负。它也直接给出简单性的一个变分证明：若
存在两个正交的非负 ground states \(u,v\)，则 \(u\perp v\) 强迫其支撑几乎处处不交；于是
\(u-v\) 仍为 ground state 却变号，与严格模不等式矛盾。

该论证本身尚不能排除非负基态在正测度集上为零；严格正性来自下一节的不可约性。

## 3. 不可约性

首先，\(1_{\Omega_a}\in D(\mathcal E_a)\)。事实上

\[
\int_{\mathbb R}
|1_{\Omega_a}(x+t)-1_{\Omega_a}(x)|^2\,dx
=
\begin{cases}
2t,&0<t<2a,\\
4a,&t\ge2a,
\end{cases}
\]

而

\[
k(t)\sim\frac1{2t}\quad(t\downarrow0),
\qquad
k(t)=O(e^{-t/2})\quad(t\to\infty).
\]

反设可测集 \(E\subset\Omega_a\) 是半群的非平凡不变集。Dirichlet-form 的 invariant-set criterion
应用于 \(1_{\Omega_a}\) 给出

\[
1_E,1_{E^c}\in D(\mathcal E_a),
\qquad
\mathcal E_a(1_E,1_{E^c})=0.
\]

但连续跳跃部分满足

\[
\mathcal E_a(1_E,1_{E^c})
\le
-\int_E\int_{E^c}k(|x-y|)\,dx\,dy.
\]

若 \(|E|>0\) 且 \(|E^c|>0\)，右端严格为负；若积分发散，则 \(1_E\) 不属于定义域，同样矛盾。
因此

\[
|E|=0\quad\text{或}\quad|E^c|=0.
\]

故 \(\mathcal E_a\) 不可约。对称 Dirichlet form 的不可约性等价于半群与预解式 positivity
improving，因而

\[
0\ne f\ge0
\Longrightarrow
e^{-tM_a}f>0\quad\text{a.e.},\qquad t>0.
\]

## 4. 简单严格正基态

由 note 001 与有界有限秩扰动，\(M_a\) 具有紧预解式，所以其谱底

\[
\mu_1(a):=\inf\sigma(M_a)
\]

是本征值。positivity-improving 自伴半群的 Perron--Frobenius--Faris 定理给出

\[
\boxed{
\dim\ker(M_a-\mu_1(a))=1,}
\]

并存在唯一的归一化实基态 \(\varphi_a\) 满足

\[
\boxed{\varphi_a>0\quad\text{a.e. on }(-a,a).}
\]

这里的严格正性是 Lebesgue 几乎处处意义；本文没有证明连续代表、逐点正性或端点轮廓。

## 5. 偶基态与严格奇扇区谱隙

反射

\[
(Jv)(x)=v(-x)
\]

与 \(M_a\) 对易。因此 \(J\varphi_a\) 也是严格正的归一化 ground state。简单性给出

\[
J\varphi_a=\varphi_a,
\]

故基态为偶函数，并且

\[
\mu_1(a)=\mu_1(M_a^+).
\]

奇子空间上的限制 \(M_a^-\) 仍有紧预解式，故其谱底 \(\mu_1(M_a^-)\) 被某个奇本征函数达到。
若它等于 \(\mu_1(a)\)，该奇本征函数也是全空间 ground state，与一维偶 ground eigenspace 矛盾。
因此

\[
\boxed{
\mu_1(M_a^+)=\mu_1(M_a)<\mu_1(M_a^-)
\qquad\forall a>0.}
\]

这是一个定性的严格谱隙；尚无显式下界

\[
\mu_1(M_a^-)-\mu_1(M_a)\ge\delta(a)>0.
\]

## 6. 对首次退化问题的影响

结合 note 007，

\[
A_a^+=M_a^++2|c\rangle\langle c|,
\qquad
A_a^-=M_a^--2|s\rangle\langle s|.
\]

约化算子的唯一全局基态位于偶扇区；完整 Weil 算子的奇扇区则由负秩一项向下拉动。因此首次退化
不能再由“完整算子 ground state 必定为正”处理。下一项决定性问题是比较负秩一强度与约化奇扇区
的正余量，例如在 \(0\in\rho(M_a^-)\) 时判断

\[
D_a^-(0)
=1-2\langle(M_a^-)^{-1}s,s\rangle
\]

的符号。本文的谱隙只给出扇区排序，尚未控制该 Schur 量。

## 7. 来源与证据边界

- Masatoshi Suzuki, *Weil's quadratic form via the screw function*,
  [arXiv:2606.09096](https://arxiv.org/abs/2606.09096)：p.11 的 Archimedean Fourier 乘子、
  p.19--20 对极限 Dirichlet form 使用的 invariant-set 方法，以及局部算子的紧预解式。
- DLMF 5.9.16：digamma 积分表示，用于从乘子得到 \(k(t)\) 的纯跳表示。
- Lenz--Stollmann--Veselić, *The Allegretto--Piepenbrink theorem for strongly local Dirichlet
  forms*, Doc. Math. 14 (2009), Theorem 1.4：不可约性、半群 positivity improving 与预解式
  positivity improving 的等价接口。
- Reed--Simon IV, Theorem XIII.44：positivity improving 与 ground-state 简单性、严格正性的接口。

本文证明的是约化算子 \(M_a\) 的性质，不是完整 Weil 算子 \(A_a\) 的基态定号定理，也不推出 RH。
