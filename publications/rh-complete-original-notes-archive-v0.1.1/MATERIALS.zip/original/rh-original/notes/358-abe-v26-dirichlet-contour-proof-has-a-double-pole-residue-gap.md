> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Abe v26 RH 工作稿：Dirichlet 轮廓论证遗漏复极点项

日期：2026-08-16。

## 来源与范围

核对对象是 Yukitaka Abe 的 Cambridge Open Engage 工作稿
“A rigorous proof of the Riemann hypothesis”，Version 26（2026-07-17，
DOI 10.33774/coe-2022-d3nj5-v26）：

<https://www.cambridge.org/engage/coe/article-details/6a52f0d3810b9dcc82011b00>

该页面明确标注为尚未同行评审的 working paper。本文只审计其第 8 节
Proposition 2 的轮廓积分步骤，不对其前面的渐近估计作更强判断。

## 关键局部展开

工作稿假设 \(\rho_j\) 是 \(\zeta\) 在 \(\Re s=B\) 上的零点，并定义
\[
g(s)=\prod_j(s-\rho_j)(s-\overline{\rho_j}).
\]
于是 \(g\) 在每个 \(\rho_j\) 有一个简单零点，而 \(\zeta\) 在 \(\rho_j\)
至少有一个零点。因此
\[
\frac1{\zeta(z)g(z)}
 =\frac{c_{j,-2}}{(z-\rho_j)^2}
  +\frac{c_{j,-1}}{z-\rho_j}+O(1),
\qquad c_{j,-2}\ne0
\]
在 \(z=\rho_j\) 至少是二阶极点（若 \(\zeta\) 的零点重数为 \(m\)，
极点阶数至少 \(m+1\)，结论更强）。

轮廓积分中的被积函数是
\[
\frac{x^w}{w\,\zeta(s+w)g(s+w)}.
\]
令 \(w_j=\rho_j-s\)。二阶部分的留数贡献不是工作稿中写出的单一
\[
a_j\frac{x^{\rho_j-s}}{\rho_j-s}.
\]
直接展开得到至少还包括
\[
c_{j,-2}x^{\rho_j-s}
\left(
 \frac{\log x}{\rho_j-s}
 -\frac1{(\rho_j-s)^2}
\right)
 +c_{j,-1}\frac{x^{\rho_j-s}}{\rho_j-s}.
\tag{1}
\]
特别是 (1) 含有 \((\rho_j-s)^{-2}\) 的复极点项。若零点重数更高，
还会出现更高阶的 \((\rho_j-s)^{-r}\) 与 \((\log x)^k\) 项。

## 对工作稿矛盾步骤的影响

工作稿在其式 (8.2)--(8.4) 中把所有 \(\rho_j,\overline{\rho_j}\)
贡献收集成
\[
Q(s)=\sum_j\left(
 a_j\frac{x^{\rho_j-s}}{\rho_j-s}
 +b_j\frac{x^{\overline{\rho_j}-s}}{\overline{\rho_j}-s}
\right),
\]
并据此声称 \(Q\) 只有简单极点；随后将左侧的
\(g(s)^{-1}\) 与 \(h_n(s)\) 也都视为至多简单极点，而把
\(1/(\zeta(s)g(s))\) 的至少二阶极点作为矛盾。

但正确留数公式必须包含上述复极点项。它们正好具有与
\(1/(\zeta(s)g(s))\) 同阶的二阶（或更高阶）极性，因此不能被丢进
“有界的 \(P,R_n,Q_n\)”余项。没有先补全这些项，就不能推出所声称的
极点阶数矛盾；Proposition 2 及其后的 RH 结论因此尚未成立。

这是一个局部、代数性的审计结论，不依赖任何关于 RH 真假的假设，也不
等同于证明 RH 反命题。它说明该工作稿不能作为本项目的 RH 证明输入。
