> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 小平方跳跃与尺度正则性不能控制低频漂移

日期：2026-08-14。

依赖：[note 128](128-the-mean-zero-rh-remainder-is-one-reciprocal-phase-field-with-square-jumps.md)。

证据等级：显式光滑反例与范围明确的路线关闭。

note 128 表明完整 RH 门的平方跳跃只有 \(O(N^{-1})\)，而单元内部具有任意固定阶
的自然尺度正则性。本文判断这些软数据是否足以推出平方根级 pointwise bound。

考虑抽象函数

\[
f(x)=\frac{x}{\log(x+2)},\qquad x\ge1.
\tag{1}
\]

它连续，因而在所有平方点的跳跃恒为零：

\[
\Delta f(N^2)=0=O(N^{-1}).
\tag{2}
\]

对每个固定 \(k\ge0\)，反复微分给出

\[
f^{(k)}(x)
=O_k\!\left(\frac{x^{1-k}}{\log x}\right)
=O_k(x^{1-k}).
\tag{3}
\]

此外

\[
f(x)=o(x).
\tag{4}
\]

然而对任意固定 \(0<\varepsilon<1/2\)，

\[
\frac{f(x)}{x^{1/2+\varepsilon}}
=\frac{x^{1/2-\varepsilon}}{\log(x+2)}
\longrightarrow\infty.
\tag{5}
\]

所以不存在只依赖下列三类假设的一般 trace inequality：

\[
\begin{cases}
\Delta f(N^2)=O(N^{-1}),\\
f^{(k)}(x)=O_k(x^{1-k})\quad\text{每个固定 }k,\\
f(x)=o(x),
\end{cases}
\quad\Longrightarrow\quad
f(x)=O_\varepsilon(x^{1/2+\varepsilon}).
\tag{6}
\]

这些条件只控制局部形状、高频正则性与定性的零斜率极限；它们不排除跨 dyadic
尺度缓慢变化的低频漂移。函数 \(x/L(x)\) 对许多缓慢增长的 \(L(x)\to\infty\)
给出同类反例。

对 note 128 的对象，这意味着

\[
\Delta T_V(N^2)=O(N^{-1})
\tag{7}
\]

与单元内 reciprocal-phase 场的微分恒等式本身不能产生 RH 界。任何有效的 hybrid
trace theorem 必须再输入一个定量低频条件，例如真正的 dyadic cancellation norm；
该输入必须独立排除 (1)，而不能只是 \(o(x)\)、固定阶导数界或跳跃可和性。

本文不声称某个特定 \(L^2\) 条件已足够；从平均量升级到 pointwise 的指数取决于可用
导数阶数与插值方式，不能把 signed mean、\(L^2\) 和 pointwise bound 混为一谈。

结论：

\[
\boxed{
\text{完整门的小平方跳跃是结构性互消，但不是平方根 cancellation；
最低缺口仍是定量低频控制}.}
\tag{8}
\]

因此仅靠 note 128 的局部微分/trace 路线应停止。下一步应直接寻找
reciprocal-phase 场的 dyadic mean-square 或 Mellin low-frequency estimate。
这不是 RH 的证明。
