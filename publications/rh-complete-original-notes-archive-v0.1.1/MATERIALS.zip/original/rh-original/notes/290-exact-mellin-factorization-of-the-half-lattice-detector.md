> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Sharp half-lattice detector 的精确 Mellin 因子化

日期：2026-08-16。

本 note 把截断卷积恒等式与 Mellin--Fubini 合并，得到 sharp half-lattice
二次型的完整 Dirichlet 表达式。它比“\(T_V=-U_V+O(\cdot)\)”更强：
对多项式 detector，cutoff 修正是一个显式的
\(1/\zeta(2s+k)\) 线性组合。

## 1. 截断恒等式

令 \(V(u)=\sum_{k=1}^d v_k u^k\) 于 \(0<u<1\) 定义，并在区间外零。
设

$$
P_V(y)=\sum_{c\le y}V(c/y),\qquad
U_V(x)=\sum_{n\ge1}\mu(n)V(n/x),
$$

以及

$$
A_V(x)=\sum_{n\le\sqrt x}\mu(n)V(n/x),\qquad
T_V(x)=\sum_{a,b\le\sqrt x}\mu(a)\mu(b)
P_V\!\left(\frac{x}{ab}\right).
$$

对 \(n\le x\)，令 \(\nu_x(n)=\mu(n)\mathbf1_{n\le\sqrt x}\)。精确的
截断卷积恒等式

$$
\mu(n)=2\nu_x(n)-(\nu_x*\nu_x*1)(n)
$$

给出

$$
\boxed{U_V(x)=2A_V(x)-T_V(x).}
\tag{1}
$$

## 2. Mellin 变换

对 \(\operatorname{Re}s>1\)，逐项换序并作 \(u=n/x\)，有

$$
\int_1^\infty U_V(x)x^{-s-1}\,dx
=K_V(s)\sum_{n\ge1}\mu(n)n^{-s}
=\frac{K_V(s)}{\zeta(s)},
\tag{2}
$$

其中

$$
K_V(s)=\int_0^1V(u)u^{s-1}\,du.
$$

另一方面，固定 \(n\) 并在 \(A_V\) 中令 \(x\ge n^2\)，得到

$$
\begin{aligned}
\int_1^\infty A_V(x)x^{-s-1}\,dx
&=\sum_{n\ge1}\mu(n)n^{-s}
\int_0^{1/n}V(u)u^{s-1}\,du\\
&=\sum_{k=1}^d
\frac{v_k}{s+k}\sum_{n\ge1}\mu(n)n^{-2s-k}.
\end{aligned}
\tag{3}
$$

故在初始绝对收敛区

$$
\boxed{
\mathcal A_V(s):=
\int_1^\infty A_V(x)x^{-s-1}\,dx
=\sum_{k=1}^d
\frac{v_k}{(s+k)\zeta(2s+k)}.}
\tag{4}
$$

将 (1)--(4) 合并，得到 sharp half-lattice 的 exact factorization

$$
\boxed{
\mathcal T_V(s):=
\int_1^\infty T_V(x)x^{-s-1}\,dx
=2\sum_{k=1}^d
\frac{v_k}{(s+k)\zeta(2s+k)}
-\frac{K_V(s)}{\zeta(s)}.}
\tag{5}
$$

该恒等式先在 \(\operatorname{Re}s>1\) 成立，再按右端解析延拓理解。

## 3. 对当前 \(V_{15}\) 的解析区域

当前 detector 满足 \(v_1=0\)，且首个可能幂次为 \(k=2\)。因此对
\(\operatorname{Re}s>-1/2\)，所有
\(2s+k\)（\(v_k\ne0\)）都落在 \(\operatorname{Re}(2s+k)>1\)，从而
\(1/\zeta(2s+k)\) 在该区域全纯。第一项是一个完全显式的 holomorphic
correction，且不含临界带的 zeta 零点。

直接由
\[
|A_V(x)|\le\sum_k|v_k|x^{-k}\sum_{n\le\sqrt x}n^k
\]
还得到
\[
A_V(x)=O_V(x^{-1/2})
\qquad(V_{15}).
\tag{6}
\]
这解释了旧笔记中的 \(T_{15}(x)=-U_{15}(x)+O(x^{-1/2})\)，但 (5) 给出
了其完整 Mellin 结构，而不仅是大小估计。

## 4. RH 门的精确形式

由于式 (5) 的第一项在 \(\operatorname{Re}s>-1/2\) 已无临界带奇点，
\(\mathcal T_V(s)\) 在
\(1/2<\operatorname{Re}s<1\) 的任何 zeta 零点处具有
\(-K_V(s)/\zeta(s)\) 留下的极点（除非发生可检查的偶然消去）。
因此

$$
T_V(x)\ll_\varepsilon x^{1/2+\varepsilon}
$$

会通过 Mellin--Abel 延拓排除临界带右侧的 zeta 零点；对 zero-free 的
\(K_V\) detector，这就是 RH-equivalent bound。

反过来，RH 下 \(1/\zeta(s)\) 的标准临界带增长估计与式 (5) 的显式修正
给出相应的平方根级 Mellin 门。故 sharp cutoff 并没有产生一个新的
较弱命题：它只是把原来的 RH 门改写成了精确的
\(-K_V(s)/\zeta(s)\) 加显式校正。

本文不声称 RH；式 (5) 的价值在于把 cutoff intertwiner 的未知部分从
“未写出的尾项”压缩成了一个完全显式、在临界带无奇点的 correction。
