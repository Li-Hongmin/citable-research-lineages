> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius parity intertwiner for the one-sided reciprocal boundary

日期：2026-08-15。

本 note 把单侧核的非偶性、divisor-complement 反射和 Möbius parity 放进同一个
有限维恒等式。它不是把 boundary kernel 当成正 Gram；相反，它严格识别了
arithmetic complement $R_X$ 在哪一个 parity sector 产生负号，并给出可交给
Weil/Feshbach 块的频率表示。

## 1. 有限 divisor 格与 even/odd 分解

令 $X$ 为非平方 squarefree 整数，$D_X={a:a|X}$，并令
$R_X e_a=e_{X/a}$，所以 $R_X^2=I$。取任意实单侧核 $p$，满足 $p(t)=0$
（$t<0$）。写

$$
g(t)=(p(t)+p(-t))/2,\qquad o(t)=(p(t)-p(-t))/2.
$$

于是 $g$ 偶、$o$ 奇，且 $p=g+o$。在 $C^{D_X}$ 上定义

$$
A_{ab}=g(\log(a/b)),\qquad B_{ab}=o(\log(a/b)).
$$

逐项检查得到

$$
A^*=A,\qquad B^*=-B,\qquad R_XA=AR_X,\qquad R_XB=-BR_X. \tag{1}
$$

定义单侧 reciprocal 矩阵

$$
H^p_{ab}=p(\log(X/(ab))).
$$

因为 $\log(ab/X)=-\log(X/(ab))$，有精确矩阵恒等式

$$
\boxed{H^p=(A-B)R_X=R_X(A+B).} \tag{2}
$$

注意 $(A-B)R_X$ 仍为实对称矩阵：$B^*=-B$ 与 $R_XB=-BR_X$ 正好相消。
这就是单侧 reciprocal kernel 的 signed arithmetic intertwiner；若只保留 $A$
而丢掉 $B$，就会把一侧边界信息误当成 ordinary PSD Gram。

## 2. Parity 压缩的精确公式

令 $P_ε=(I+εR_X)/2$，其中 $ε∈{+1,-1}$。由 (1)--(2) 及
$P_εBP_ε=0$，得到两个 sector 的严格压缩

$$
\boxed{P_ε H^p P_ε=ε P_ε A P_ε.} \tag{3}
$$

因此对任意满足 $R_Xv=εv$ 的 $v$，奇核 $B$ 在二次型中完全消失，且

$$
v^*H^pv=ε v^*Av. \tag{4}
$$

式 (3) 是比单个二维负子式更强的有限 arithmetic parity 识别：单侧 reciprocal
核在 $R_X=-1$ sector 自动带一个负号，而不是一个待由标量 norm 推断的符号。

## 3. Möbius 向量与频率空间的 exact bridge

取 Möbius divisor 向量 $c_X(a)=μ(a)$（$a|X$）。因为 $X$ squarefree，

$$
μ(X/a)=μ(X)μ(a),\qquad R_Xc_X=μ(X)c_X. \tag{5}
$$

故 (4) 给出单侧 reciprocal 二次型的严格恒等式

$$
\boxed{
\sum_{a,b|X}μ(a)μ(b)p(\log(X/(ab)))
=μ(X)\sum_{a,b|X}μ(a)μ(b)g(\log(a/b)).}
\tag{6}
$$

若 $g∈L^1(R)$，采用 Fourier 对
$\widehat g(ξ)=∫g(t)e^{-iξt}dt$ 与
$g(t)=(2π)^{-1}∫\widehat g(ξ)e^{iξt}dξ$，并定义 Möbius Euler polynomial

$$
Φ_X(ξ)=\sum_{a|X}μ(a)(a/\sqrt X)^{iξ}
=X^{-iξ/2}\prod_{ℓ|X}(1-ℓ^{iξ}),
$$

则 $|Φ_X|^2=|\sum_{a|X}μ(a)a^{iξ}|^2$，从 (6) 得到

$$
\boxed{
H_X^p:=\sum_{a,b|X}μ(a)μ(b)p(\log(X/(ab)))
=\frac{μ(X)}{2π}\int_R\widehat g(ξ)|Φ_X(ξ)|^2dξ.}
\tag{7}
$$

若 $\widehat g=\widehat g_+-\widehat g_-$，则 (7) 精确分成

$$
H_X^p=\frac{μ(X)}{2π}\left(\int\widehat g_+|Φ_X|^2-
\int\widehat g_-|Φ_X|^2\right). \tag{8}
$$

所以要控制 reciprocal 门，真正需要的是同一 Möbius mode 上的
frequency-weighted signed Schur estimate；只证明 $g$ 的点态正性，或把
$|Φ_X|^2$ 替成普通 $|M|^2$ 而忘记 $μ(X)$，都会丢掉 arithmetic parity。

## 4. 与半格 boundary 恒等式的校准

令 $L_X={a|X:a<\sqrt X}$。由于 $X$ 非平方，$D_X=L_X\sqcup X/L_X$。将
(6) 按这两个反射半格分块，记

$$
G_X=\sum_{a,b∈L_X}μ(a)μ(b)g(\log(a/b)),\qquad
Q_X=\sum_{a,b∈L_X}μ(a)μ(b)p(\log(X/(ab))),
$$

则逐项而非渐近地得到

$$
\boxed{H_X^p=Q_X+2μ(X)G_X.} \tag{9}
$$

这说明 (9) 并不是一个孤立的 half-lattice 经验式：它正是完整 Möbius parity
intertwiner (7) 在 $L_X⊕R_XL_X$ 上的 block expansion。尤其当 $X=2p$ 时，
$c_X$ 的 $R_X$-parity 为 $+1$，而 ordinary half-block 仍可有 $G_X<0$；负号
来自 $\widehat g$ 的 signed frequency weight，不能由 parity 符号单独消除。

## 5. 对真实 Weil/Feshbach 映射的最小要求

若 $K$ 是候选 archimedean/prime 修正，(3) 给出一个可检验的最小接口：在
divisor basis 上必须同时保留

$$
R_X\longleftrightarrow J_X,\qquad A\longleftrightarrow M_{\widehat g},
\qquad B\longleftrightarrow\text{反射反对易的 signed cross block}.
$$

只映射 $A$ 而杀掉 $B$ 会得到 ordinary Toeplitz 近似，不能复原 (2)；只映射
一个未带 parity 的 rank-one 向量，则无法验证 (7) 的 $μ(X)$ 因子。最薄的可
转移命题是：对每个 squarefree $X$，候选 intertwiner 在 $c_X$ 上满足

$$
T_Xc_X∈E_{μ(X)}(J_X),\qquad
\langle T_Xc_X,M_{\widehat g}T_Xc_X\rangle=c_X^*Ac_X. \tag{10}
$$

然后由 $J_XT_X=T_XR_X$ 自动推出 (7)。这是一个明确的 signed-parity
intertwiner 条件，比“边界块应当有某个正 rank-one 补偿”更薄，也更接近完整
Weil 公式。

本文只证明有限 divisor 格上的 (1)--(10)，以及它们对补偿接口的必要形式；没有
把任何有限格恒等式外推为 RH 证明。

## 9. 按 squarefree 尺度平均并不能消除 signed 频带

式 (7) 还允许对所有 squarefree \(X\) 做一个完全显式的 Dirichlet
加权检验。对 \(\Re\sigma>1\)，绝对收敛性给出
\[
\begin{aligned}
\sum_{X\ {\rm squarefree}}X^{-\sigma}\mu(X)H_X^p
&=\frac1{2\pi}\int_{\mathbb R}\widehat g(\xi)
  \prod_{\ell}\left(1+\ell^{-\sigma}
  |1-\ell^{i\xi}|^2\right)\,d\xi,\\
\sum_{X\ {\rm squarefree}}X^{-\sigma}H_X^p
&=\frac1{2\pi}\int_{\mathbb R}\widehat g(\xi)
  \prod_{\ell}\left(1-\ell^{-\sigma}
  |1-\ell^{i\xi}|^2\right)\,d\xi.
\end{aligned}
\tag{13}
\]
这里使用
\[
|\Phi_X(\xi)|^2=\prod_{\ell\mid X}|1-\ell^{i\xi}|^2
\]
以及逐素数展开。第一式确实消除了 \(X\)-parity 号，并产生正的
Euler 因子；但它仍带有同一个 \(\widehat g(\xi)\)。对本项目的
endpoint-flat detector，\(g(0)=0\) 且 \(g\not\equiv0\)，note 180
已证明 \(\widehat g\) 不可能全频非负。因此尺度平均不能把 signed
frequency channel 变成 PSD channel。第二式连 \(X\)-parity 也保留为
signed Euler 因子。

这排除了一个具体的补偿捷径：先在完整 divisor lattice 上按
\(\mu(X)\) 平均，再试图用 Euler 乘积正性替代 signed
intertwiner。若要继续沿该方向，必须同时控制
\(\widehat g_-\) 在上述正乘积权下的贡献；这仍是原来的频率加权算术门，
不是一个已闭合的 RH 证明。

## 6. 最小校准：$X=2p$

若 $p>2$ 为奇素数，按基底 $(1,2,p,2p)$ 排列，单侧矩阵的非零位置直接给出

$$
H^p_{2p}=
\begin{pmatrix}
P(2p)&P(p)&P(2)&0\\
P(p)&P(p/2)&0&0\\
P(2)&0&0&0\\
0&0&0&0
\end{pmatrix}. \tag{11}
$$

这里 $P(y)=p(\log y)$（$y\ge1$），而 $P(y)=0$（$0<y<1$）。Möbius 向量
$c=(1,-1,-1,1)^T$ 满足 $R_{2p}c=c$，故 (4) 对它给出

$$
c^TH^p_{2p}c=P(2p)-2P(p)-2P(2)+P(p/2)
=Q_{2p}+2G_{2p}. \tag{12}
$$

式 (11)--(12) 把 note 175 的半格负边界 $G_{2p}=-P(2)$ 嵌回完整 reciprocal
矩阵，并显示它并非一个可独立删除的二维误差：它是完整 $R_{2p}=+1$ Möbius
sector 的 signed Fourier energy。

## 7. 奇核是 parity 间的完整频率 cross block

为明确说明 (2) 中不能丢掉的 $B$，对实向量 $x,y$ 定义
$M_x(ξ)=\sum_{a|X}x_a a^{iξ}$。Fourier 反演逐项给出

$$
x^TBy=\frac1{2π}\int_R\widehat o(ξ)
M_x(ξ)\overline{M_y(ξ)}\,dξ. \tag{13}
$$

若 $R_Xx=εx$、$R_Xy=ηy$，则
$M_y(-ξ)=ηX^{-iξ}M_y(ξ)$，从而同一 cross block 也可写成

$$
x^TBy=\frac{η}{2π}\int_R\widehat o(ξ)X^{-iξ}
M_x(ξ)M_y(ξ)\,dξ. \tag{14}
$$

由于 $\widehat o$ 是纯虚奇函数，(14) 是保留 signed cancellation 的双线性
积分，而非两个 sourcewise 绝对值的和；并且 $B$ 只连接 $E_+(R_X)$ 与
$E_-(R_X)$。所以真实 Feshbach 映射至少要把 (14) 的反射反对易 cross block
与 (7) 的 parity diagonal block 同时实现。只给出 $A$ 的正 Gram 或单独估计
$|\widehat o|$，会丢掉正是 note 058/059 所警告的 signed cancellation。

## 8. Möbius mode 是一个显式 prime-frequency sieve

Euler 乘积还把 (7) 写成完全实的乘积权：

$$
|Φ_X(ξ)|^2=\prod_{\ell|X}4\sin^2\!\left(\frac{ξ\log\ell}{2}\right). \tag{15}
$$

例如 $X=2p$ 时，严格有

$$
H^p_{2p}=\frac1{2π}\int_R\widehat g(ξ)
16\sin^2\!\left(\frac{ξ\log2}{2}\right)
\sin^2\!\left(\frac{ξ\log p}{2}\right)dξ. \tag{16}
$$

因此随素数 $p$ 改变的边界二次型并不是任意 sourcewise 的 prime 和，而是
同一个 archimedean signed symbol $\widehat g$ 经过乘法角色
$(1-p^{iξ})$ 的频率筛选。一个可检验的全局桥是：在某个 $X$-族上把真实
Feshbach cross block 映射到 (15) 的乘积权，并保持 $R_X$ parity；否则即使每个
固定 prime 的二维块都通过，也没有控制完整 Möbius mode 的 signed integral。

## 10. 非负 Euler 因子不能逐点正化 endpoint-flat symbol

note 180 证明：对非零 endpoint-flat detector，偶核的 Fourier symbol
\(\widehat g\) 必在某个频率区间严格为负。另一方面，任取有限素数集
\(\mathcal P\) 与非负权 \(\alpha_\ell\ge0\)，对完整 squarefree divisor 格
做 parity 加权时，Fourier 乘子只能具有形式

\[
 W_{\mathcal P}(\xi)=
 \prod_{\ell\in\mathcal P}
 \left(1+\alpha_\ell|1-\ell^{i\xi}|^2\right)>0.
\tag{17}
\]

因此在 \(\widehat g(\xi_0)<0\) 的连续性邻域内仍有
\(W_{\mathcal P}(\xi)\widehat g(\xi)<0\)。任何只增加非负 Euler 因子的
divisor/parity 平均，都不能把 endpoint-flat symbol 变成逐点非负的 Fourier
multiplier；它至多改变负频带的权重。

这排除的是“Euler 乘积正性 \(\Rightarrow\) PSD”这一逐频率捷径，并不排除
保留 \(\widehat g_-\) 与不同 divisor modes 之间的真正 signed
cross-cancellation。后者仍是需要证明的算术 intertwiner，不能由 (17) 的
因子正性代替。
