> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 两素数 Möbius 频率筛的普适负边界

日期：2026-08-15。

本 note 把 note 177 的 \(X=2p\) 频率乘积化为一个不依赖
V15 特殊公式的精确恒等式。它说明：只要单侧 boundary 的偶化核在
\(\log 2\) 处为正，完整 reciprocal 二次型沿 \(X=2p\) 就必然出现
负值；因此普通正频率 Gram 不能成为全局桥。

## 1. 一般偶核恒等式

令 \(g\in L^1(\mathbb R)\) 为实偶函数，\(\widehat g\in L^1(\mathbb R)\)，
并定义 \(a=\log2\)、\(b=\log p\)。令
\[
\mathcal H(a,b)
=\frac1{2\pi}\int_{\mathbb R}\widehat g(\xi)\,
16\sin^2(a\xi/2)\sin^2(b\xi/2)\,d\xi .
\]
由 \(16\sin^2(a\xi/2)\sin^2(b\xi/2)
=4(1-\cos(a\xi))(1-\cos(b\xi))\) 和 Fourier 反演，
\[
\boxed{
\mathcal H(a,b)
=4\left[g(0)-g(a)-g(b)
+\frac{g(a+b)+g(a-b)}2\right].}
\tag{1}
\]
这是真正的有限恒等式，不需要 \(\widehat g\) 的符号。

## 2. 单侧 detector 的校准

对 \(g(t)=(p(t)+p(-t))/2\)、\(p(t)=P(e^t)\mathbf1_{t\ge0}\)，有
\[
g(0)=P(1),\quad g(a)=\frac{P(2)}2,\quad
g(b)=\frac{P(p)}2,\quad
g(a+b)=\frac{P(2p)}2,\quad
g(a-b)=\frac{P(p/2)}2.
\]
因此
\[
\boxed{
\mathcal H(\log2,\log p)
=P(2p)-2P(p)-2P(2)+P(p/2).}
\tag{2}
\]
这正是完整 Möbius reciprocal 二次型
\(H^p_{2p}=Q_{2p}+2G_{2p}\)，与 note 177 式 (12) 一致。

## 3. 普适负极限

若 \(g(t)\to0\) 当 \(|t|\to\infty\)，则由 (1)
\[
\boxed{\lim_{p\to\infty}\mathcal H(\log2,\log p)
=4\bigl(g(0)-g(\log2)\bigr).}
\tag{3}
\]
特别地，endpoint-flat detector 满足 \(g(0)=P(1)=0\)。若其局部正性给出
\(P(2)>0\)，则 \(g(\log2)=P(2)/2>0\)，从而
\[
\mathcal H(\log2,\log p)\longrightarrow-2P(2)<0.
\tag{4}
\]
所以沿任意足够大的奇素数 \(p\)，完整 two-prime reciprocal 门必有负值。
这个结论不依赖 V15 的 Mellin 符号，也不依赖数值 Fourier 扫描。

## 4. 对全局桥的含义

式 (4) 排除的只是把完整 one-sided reciprocal kernel 直接视为正 Gram，
或只用一个统一的非负 Fourier symbol 处理它。可行的 Weil/Feshbach 桥仍可
保留 signed \(B\) cross block 与 \(R_X\)-parity；但它必须解释
\(P(2p)-2P(p)-2P(2)+P(p/2)\) 中的抵消，不能逐 prime 取绝对值。
本文只给出普适有限恒等式和负极限，不声称 RH。

## 5. 固定 squarefree 基底后再加入一个大素数

上面的两素数计算不是孤立现象。令 \(Y\) 为固定 squarefree 整数，
\(p\nmid Y\) 为素数，写
\[
W_Y(\xi)=|\Phi_Y(\xi)|^2
 =\left|\prod_{\ell\mid Y}(1-\ell^{i\xi})\right|^2,\qquad
I_Y=\frac1{2\pi}\int_{\mathbb R}\widehat g(\xi)W_Y(\xi)\,d\xi .
\]

定义
\[
J_Y(t)=\frac1{2\pi}\int_{\mathbb R}
\widehat g(\xi)W_Y(\xi)e^{i\xi t}\,d\xi .
\]

由 \(|1-p^{i\xi}|^2=2(1-\cos(\xi\log p))\)，只要 Fourier 反演适用，
就有精确恒等式
\[
\boxed{I_{Yp}=2I_Y-J_Y(\log p)-J_Y(-\log p).}
\tag{5}
\]
有限 Euler 展开还给出
\[
J_Y(t)=\sum_{a,b\mid Y}\mu(a)\mu(b)\,
g\!\left(t+\log\frac ab\right).
\tag{6}
\]
若 \(g(t)\to0\) 当 \(|t|\to\infty\)，则对固定 \(Y\)
\[
\boxed{I_{Yp}\longrightarrow 2I_Y\qquad(p\to\infty).}
\tag{7}
\]
等价地，在 \(\widehat g W_Y\in L^1\) 时也可直接用
Riemann--Lebesgue 引理得到 (7)。对于当前 detector 的
\(P(y)=O(y^{-2})\)，式 (6) 给出 \(J_Y(\log p)=O_Y(p^{-2})\)。

因此只要某个固定基底满足 \(I_Y<0\)，加入任意足够大的新素数后仍严格有
\(I_{Yp}<0\)；新的 sine 因子在频率上只趋于其平均值 2，并不会把既有负积分
变成正值。取 \(Y=2\)，且 \(g(0)=0\)，有 \(I_2=-P(2)<0\)，式 (7) 恢复
(4)，说明该负边界沿无限素数族持续存在。

所以可以被 product-sine 权抵消的只能是额外的 signed
archimedean/prime cross block；单独乘上更多非负的
\(4\sin^2(\xi\log p/2)\) 因子没有这种补偿能力。本文仍只建立有限频率恒等式，
不把它外推为 RH 结论。

## 6. 负频部分所要求的最小补偿量

把符号分解为
\[
\widehat g=\widehat g_+-\widehat g_-,
\qquad
A_Y^\pm=\frac1{2\pi}\int_{\mathbb R}
\widehat g_\pm(\xi)W_Y(\xi)\,d\xi .
\]
在相同的可积性条件下，\(A_{Yp}^\pm\to2A_Y^\pm\)。因此若
\(I_Y=A_Y^+-A_Y^-<0\)，任何附加块 \(C_{Yp}\) 若要使
\(I_{Yp}+C_{Yp}\ge0\) 沿所有充分大的 \(p\) 成立，必须满足严格的必要条件
\[
\boxed{\liminf_{p\to\infty}C_{Yp}\ge
2(A_Y^--A_Y^+)=-2I_Y.}
\tag{8}
\]

式 (8) 不是构造充分条件，而是 signed
archimedean/prime cross block 必须支付的最小渐近缺口。特别是，单纯增加
新的 product-sine 因子只把 \(I_Y\) 渐近乘以 2，不能支付该缺口；补偿必须在
同一 \(W_Y\)-加权状态上出现真正的非对角或反射项。

若进一步有显式界 \(|P(y)|\le C y^{-2}\)，则 \(q=2\) 时直接由
\[
|Q_{2p}|\le \frac{25C}{4p^2}
\]
得到
\[
H_{2p}\le -2P(2)+\frac{25C}{4p^2}.
\tag{9}
\]
因此 \(p^2>25C/(8P(2))\) 就严格强制 \(H_{2p}<0\)。更一般地，固定
squarefree \(Y\) 时可取
\[
C_Y=\frac C2\left(\sum_{a\mid Y}a^{-2}\right)
\left(\sum_{b\mid Y}b^2\right),
\qquad
I_{Yp}\le 2I_Y+\frac{2C_Y}{p^2}.
\]
当 \(I_Y<0\) 时，这给出完全显式的负号阈值，而非仅有
Riemann--Lebesgue 极限。

## 7. 一个完全有限的负号阈值

若对某个 detector 存在常数 \(C\) 使
\[
|P(y)|\le C y^{-2}\qquad(y\ge1),
\tag{9}
\]
则 (2) 给出对每个奇素数 \(p\ge2\)
\[
\mathcal H(\log2,\log p)
\le -2P(2)+\frac{25C}{4p^2}.
\tag{10}
\]
因为
\[
2|P(p)|+|P(p/2)|+|P(2p)|
\le\left(2+4+\frac14\right)\frac{C}{p^2}.
\]
所以只要
\[
\boxed{p^2>\frac{25C}{8P(2)},}
\tag{11}
\]
该 product-sine 加权二次型就严格为负。这里的 \(C\) 只来自 detector 的
全局二阶尾界；不需要频率扫描或数值猜测。

更一般地，固定 squarefree \(Y\)，令
\[
C_Y=\frac C2
\left(\sum_{a\mid Y}a^{-2}\right)
\left(\sum_{b\mid Y}b^2\right).
\]
对充分大的 \(p\) 由 (6) 有
\(|J_Y(\log p)|\le C_Yp^{-2}\)，从而
\[
I_{Yp}\le 2I_Y+\frac{2C_Y}{p^2}.
\tag{12}
\]
若 \(I_Y<0\)，则 \(p^2>C_Y/(-I_Y)\) 已足以强制
\(I_{Yp}<0\)。式 (11) 是 \(Y=2\) 的显式化版本。
