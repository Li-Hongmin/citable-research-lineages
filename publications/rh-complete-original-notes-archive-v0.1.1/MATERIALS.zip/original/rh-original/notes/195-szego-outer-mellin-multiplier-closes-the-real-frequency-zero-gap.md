> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Szegő 外函数压平实频零点：正能量门的解析乘子接口

日期：2026-08-15。

本 note 处理 note 194 留下的解析兼容性问题。逐个列出 h 的实频零点并手工加因子不是必要的；只要满足 strip–Szegő 条件，就有一个零自由的 Hardy 外函数，其边界模平方为 |h|。note 213 已补足并证明当前 \(V_{15}\) 所需的条带引理。因此正能量门若能给出，RH 的 Mellin 推出只剩一个标准的 Hardy–Laplace 实现步骤。

## 1. 当前 detector 的 boundary analytic function

令

    F(z) = ζ(i z) K₁₅(i z),
    F#(z) = ζ(−i z) K₁₅(−i z),
    H(z) = (F(z) + F#(z))/2.

K₁₅ 的系数为实数，所以在实轴上

    H(ξ) = Re(ζ(iξ) K₁₅(iξ)) = h(ξ).

取 0 < a < 1/4。在闭带 |Im z| ≤ a 内，H 全纯：两项 zeta 的实部均小于 1/4，而 K₁₅ 的极点在负整数处。凸性估计和函数方程给出闭子带上的多项式增长。

在平移线 z = x + ia 上，第一项取值于 s = −a + ix；函数方程把它移到 1+a−ix，从而

    |F(x+ia)| ≍ₐ |x|^(−19/2+a).

第二项位于 s = a−ix，由凸性估计

    |F#(x+ia)| ≪ₐ,ε |x|^(−19/2−a/2+ε).

所以 H(x+ia) 在充分大的 |x| 上具有多项式下界，不会出现 exp(−x²) 型的无穷远奇异内因子。

## 2. strip–Szegő 条件

使用如下条带引理。设 \(H\) 在 \(|\operatorname{Im}z|<b\) 全纯，
闭子带上有多项式上界，并存在 \(0<a<b\) 使两条线分别满足
\[
 |H(x\pm ia)|\ge C(1+|x|)^{-C}.
\]
则
\[
 N_H(R)=O(R\log(2+R)),\qquad
 \int_{\mathbb R}\frac{\log^-|H(x)|}{1+x^2}\,dx<\infty. \tag{S}
\]

这里给出所需的证明框架，以固定权重而非指数调和测度为目标。先取
\(a<b/6\)。对每个整数 \(k\)，以 \(z_k=k+ia\) 为圆心取半径 \(4a\)
的固定 Jensen 圆；由平移线下界和闭子带多项式上界，
\[
 \log|H(z_k)|\ge-C\log(2+|k|),\qquad
 \sup_{|z-z_k|\le4a}\log^+|H(z)|
 \le C\log(2+|k|).
\]
该圆盘覆盖 \(\{|\operatorname{Im}z|\le a,\,
|\operatorname{Re}z-k|\le a\}\)，故每个单位实部区间内的零点数为
\(O(\log(2+|k|))\)，从而
\(N_H(R)=O(R\log(2+R))\)。把这些零点代入
\(S_a\) 的 Blaschke 乘积 \(B\)：映射
\(\zeta=\exp(\pi z/(2a))\) 后，零点满足
\[
 \sum_\rho \frac{\operatorname{Re}\zeta_\rho}{1+|\zeta_\rho|^2}<\infty,
\]
因为远离中心的零点按 \(\exp(-\pi|\operatorname{Re}\rho|/(2a))\)
加权，而紧条带内只有有限个零点。于是
\(|B|=1\) 在两条水平边界上，且
\(\log|B(z)|=-\sum_\rho G_{S_a}(z,\rho)\le0\)。
对 \(U=H/B\) 取 \(v=\log|U|\)。平移线下界和多项式上界给出
\(v(t,\pm a)=O(\log(2+|t|))\) 的双边界控制；条带 Poisson 公式从而给出
\(v(x,0)\ge-C\log(2+|x|)\)。因此
\[
 \log^-|H(x)|
 \le C\log(2+|x|)+\sum_\rho G_{S_a}(x,\rho).
\]
最后，条带 Green 核满足
\[
 \int_{\mathbb R}\frac{G_{S_a}(x,\rho)}{1+x^2}\,dx
 \ll_a (1+|\operatorname{Re}\rho|)^{-2}
\]
其证明是 Green 核的指数衰减与 \(|\operatorname{Re}\rho|\) 分箱。结合
每箱 \(O(\log(2+|k|))\) 个零点，级数
\(\sum_k\log(2+|k|)/(1+k^2)\) 收敛，得到 (S)。这一步是标准的
Blaschke--Green 条带证明，且明确保留了 \(1/(1+x^2)\) 权重。

对当前 \(H\)，取避开 \(H\) 的可数个零点虚部的 generic
\(a\in(0,1/4)\)。第 1 节的函数方程/凸性估计使
\(|F^\#(x+ia)|/|F(x+ia)|\to0\)，故在充分大的 \(|x|\) 上
\(|H(x+ia)|\ge\tfrac12|F(x+ia)|\)；紧区间上因避开零点而有正最小值。
又 \(H(\bar z)=\overline{H(z)}\)，所以 \(-a\) 线也有同一下界，(S) 可用。

## 3. 外函数构造

令 \(W(\xi)=|h(\xi)|\)。这里还要记录外函数定理的 \(L^1\) 假设：
凸性估计与 \(K_{15}(i\xi)=O(|\xi|^{-10})\) 给出
\(h(\xi)=O_\varepsilon(|\xi|^{-19/2+\varepsilon})\)，故 \(W\in L^1(\mathbb R)\)；
于是 \(\log^+W/(1+\xi^2)\) 也可积。由 (S) 和半平面 Szegő 外函数定理，
存在右半平面零自由的 \(O\in H^2(\operatorname{Re}s>0)\)，满足几乎处处

    |O(iξ)|² = W(ξ).

取整数 J≥1，令 Ψ(s)=O(s)/(s+1)^J。则 Ψ 仍在右半平面零自由，且

    (1/(2π)) ∫ |Ψ(iξ)|²/W(ξ) dξ
      = (1/(2π)) ∫ (1+ξ²)⁻ᴶ dξ < ∞.          (1)

Paley–Wiener–Laplace 定理给出 O(s)=∫₀∞ φ₀(t)e^(−st)dt，其中 φ₀∈L²(0,∞)。Ψ 的逆变换是
φ=φ₀*k_J，k_J(t)=1_{t≥0}t^(J−1)e^(−t)/(J−1)!。因 k_J∈L²（J≥1），卷积满足 φ∈C₀∩L∞。于是 ψ(u)=φ(−log u), 0<u<1，是一个有界 Mellin 测试函数，并且 Kψ(s)=Ψ(s)。特别地，Kψ 在 Re s>0 无零，故在临界带无零；(1) 正好是 note 194 的 W⁻¹ 可积性条件。该构造自动支付所有实频零点，不需要知道零点位置或重数。

若需要 support 严格落在开区间内部，取任意 T>0，把 Ψ 替换为
e^(−Ts)Ψ(s)。其边界模不变、仍零自由，而逆 Laplace 函数平移到
t≥T；对应 ψ 支持在 (0,e^(−T)]，并不改变 Mellin 估计。

## 4. 对正能量门的精确后果

若 note 192 的全整数正能量门

    E_N = (1/(2π)) ∫ |h(ξ)| |Σ_{n≤N} μ(n)n^(iξ)|² dξ
          ≪ε N^(1+ε),                         (2)

成立，则 note 194 的 Cauchy 不等式给出

    Sψ(N) = Σ_{n≤N} μ(n) ψ(n/N) ≪ψ,ε N^(1/2+ε).

对 Re s>1 做 Mellin–Fubini：

    ∫₁∞ Sψ(x)x^(−s−1) dx = Kψ(s)/ζ(s).

左端的平方根估计把它解析延拓到 Re s>1/2，而 Kψ 在该带无零，故 ζ 在该带无零，即 RH。

因此，解析接口已压缩为上述 Blaschke--Green 条带引理；其长矩形
Carleman--Jensen 边界项仍应在正式证明中独立写出。该引理成立后，
正能量路线的唯一承重缺口才是 note 192 的算术门 (2)。本 note 不声称
(2) 或该边界引理已经完成，也不把有限频率数值实验外推为 RH。
