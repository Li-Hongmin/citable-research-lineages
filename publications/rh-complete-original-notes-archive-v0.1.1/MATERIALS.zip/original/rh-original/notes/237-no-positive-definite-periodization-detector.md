> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 端点平坦 periodization detector 不可能产生正半定 log-kernel

本 note 给出一个不依赖 Fourier 符号扫描的结构性 no-go。它排除把 signed 三角坍缩直接改造成 PSD Gram 的路线。

## 定理

设 \(V\) 在 \([0,1]\) 上连续，\(V(u)=O(u^\alpha)\)（某个 \(\alpha>0\)），并令
\[
P_V(y)=\sum_{c\le y}V(c/y),\qquad
g_V(t)=\frac12P_V(e^{|t|})\quad(t\in\mathbb R).
\]
假设 \(P_V(y)\) 对 \(y\ge1\) 有定义且有限。若 \(g_V\) 在整数对数格点
\(\{\log n:n\in\mathbb N\}\) 上给出正半定核，则 \(V\equiv0\) 是唯一可能情形。

## 证明

对任意 \(N\)，三角分解和除数坍缩给出精确恒等式
\[
\sum_{a,b\le N}\mu(a)\mu(b)g_V(\log(a/b))
=\sum_{a\le N}\mu(a)V(1/a)
-\frac{V(1)}2\sum_{a\le N}\mu(a)^2.
\tag{1}
\]
第一项满足
\[
\left|\sum_{a\le N}\mu(a)V(1/a)\right|
\le \sum_{a\le N}|V(1/a)|
=o(N),
\tag{2}
\]
因为 \(V(1/a)=O(a^{-\alpha})\)。另一方面
\[
\sum_{a\le N}\mu(a)^2\sim \frac6{\pi^2}N.
\tag{3}
\]

若 \(V(1)>0\)，由 (1)--(3) 可知左端对充分大的 \(N\) 严格为负，与正半定性矛盾。

若 \(V(1)<0\)，则 \(g_V(0)=V(1)/2<0\)，单点主对角元已经违反正半定性。

最后若 \(V(1)=0\)，则 \(g_V(0)=0\)。正半定核满足
\[
|g_V(\log(a/b))|^2\le g_V(0)^2=0,
\]
故它在所有整数比值上恒为零。由于有理正数比值稠密且 \(g_V\) 连续，得到 \(g_V\equiv0\)，从而 \(P_V\equiv0\)，并由三角坍缩的 Möbius 反演得到 \(V\equiv0\)。

## 对 RH 路线的含义

这一定理比“某个频率点符号为负”更强：它排除所有端点平坦 detector 的直接 PSD 化，不依赖具体 \(V_{15}\) 或数值频率。要保留 RH 信息，必须允许 indefinite/Krein 结构或真正的 signed arithmetic intertwiner；单纯把 periodization 核做成正 Gram 不可能成功。

