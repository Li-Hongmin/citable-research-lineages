> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Shimizu v8：基础 \(C_{\mathrm{cen}}\) 拓扑与 weighted-window 拓扑的升级门

日期：2026-08-16。

## 两套 seminorm

稿件 Definition 6.104 把 \(CCL(r)\) 描述为 finite-window
Cauchy--Laplace 家族在 \(C_{\mathrm{cen}}\) 中的闭包；Lemma 6.109 的显示估计
使用的是
\[
p_{B,N,m,\sigma},
\qquad
e^{-\sigma |u|}(1+|u|)^N
\partial_w^j\partial_u^\ell
\]
这一类基础 weighted-exponential seminorm。

随后 Definition 6.117 又引入
\[
p^{\mathrm{rd}}_{B,m,A},\quad
p^{\mathrm{lift}}_{B,m,A},\quad
p^{\mathrm{cyc}}_{B,m,A},
\]
它们含有
\[
\sup_{M\ge1}M^{-A}
\]
乘以窗口 \(M\) 的 readout、lift 或 cyclic-channel 范数。它们测量的是
窗口族的统一增长，而不是单个 \(u\)-函数的指数尾。

## 逻辑关系必须明确

Lemma 6.109 的证明逐项控制了 \(p_{B,N,m,\sigma}\)，因而给出基础
\(C_{\mathrm{cen}}\) 拓扑中的 Cauchy 性。Lemma 6.118 则给出 finite-window
实现映射相对于 weighted seminorm 的多项式增长控制。两者并不自动推出
\[
p^{\mathrm{rd/lift/cyc}}_{B,m,A}
\bigl(\Psi^{\mathrm{fw}}_{\cdot,M}
-\Psi^{\mathrm{cen}}_{\cdot}\bigr)\to0.
\tag{1}
\]

因此 Theorem 6.155 必须明确采用下列两种解释之一：

1. **基础拓扑解释：** \(CCL(r)\) 只用 \(p_{B,N,m,\sigma}\) 完成；则
   weighted seminorm 只作为 Lemma 6.119 的辅助估计，并需明确证明 pairing
   的连续性只依赖基础 seminorm；
2. **强化拓扑解释：** weighted seminorm 被纳入 \(CCL(r)\) 的定义；则必须
   额外证明 (1)，因为 Lemma 6.109 的指数尾估计本身没有控制
   \(M\)-indexed readout/lift/cyclic 范数。

稿件在 Definition 6.117 称 weighted seminorm 被“加入 comparison topology”，
而 Theorem 6.155 Step 2 的显示收敛仍只写 \(p_{B,N,m,\sigma}\)。这留下一个
需要作者明确的拓扑升级点；它不是由“局部一致收敛”自动解决的。

## 基础收敛不蕴含窗口加权收敛

抽象地，令 \(f_M\) 是集中在 \(u=M\) 的光滑 bump，幅度为 \(1\)。对任意固定
\(\sigma>0\)，基础 seminorm
\[
\sup_u e^{-\sigma|u|}|f_M(u)|
\]
趋于零；但若一个窗口 readout 在该 bump 上取值为 \(e^{M}\)，则
\[
\sup_{M\ge1}M^{-A}|e^M|
\]
对任意固定 \(A\) 都发散。这个模型不对应具体 Shimizu 算子，只说明
“基础 tail 收敛”与“窗口 readout 的统一增长”是不同命题。

## 裁决

本记录不判定稿件的 Theorem 6.155 错误；它要求把 \(CCL(r)\) 的实际拓扑、
weighted seminorm 的角色，以及 Lemma 6.109 到 Lemma 6.152 所需的收敛路径写成
一个无歧义的命题。若采用强化拓扑，必须补 (1)；若采用基础拓扑，则必须证明
Lemma 6.119/6.152 的 pairing 连续性不暗含强化拓扑。

在该升级门明确并验证之前，det2 自伴性仍不能转化为 \(F_K=\xi\)，更不能称为
RH 证明。来源为预印本 v8 的 Definitions 6.104/6.117、Lemmas 6.109/6.118
和 Theorem 6.155；稿件仍未同行评审。

