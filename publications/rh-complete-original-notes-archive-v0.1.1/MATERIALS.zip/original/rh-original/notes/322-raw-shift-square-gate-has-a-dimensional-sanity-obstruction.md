> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 原始移位相关平方门的尺度诊断

日期：2026-08-16。

## 1. 被审查的门

外部 Liouville-collar 路线把

\[
C_h(N)=\sum_{n\le N-h}\lambda(n)\lambda(n+h)
\]

代入一个很强的 dyadic 均方条件

\[
E(N,H):=\sum_{H<h\le 2H}|C_h(N)|^2
\ll_\varepsilon N^{2+\varepsilon}H^{-1}.
\tag{1}
\]

这个条件确实足以通过 Cauchy--Schwarz 给每个 dyadic 块
\(\sum_h C_h(N)\ll N^{1+\varepsilon}\)，但它对原始相关向量的要求必须先做
尺度检查。

## 2. 可复核诊断

`computations/check_raw_shift_square_gate.py` 用零填充 FFT 计算原始相关，并对小
移位逐项直接求和核对方向。为避免把终端区 \(H\asymp N\) 与中短移位门混在一起，
取 \(H=\lfloor N^{3/4}\rfloor\)；这属于命题中任意固定
\(\eta<1/4\) 所允许的范围。得到：

| 序列 | \(N\) | \(E(N,H)/N^2\) |
|---|---:|---:|
| \(\lambda\) | \(2^{10}\) | 0.10598 |
| \(\lambda\) | \(2^{14}\) | 0.07335 |
| \(\lambda\) | \(2^{18}\) | 0.03991 |
| \(\mu\) | \(2^{10}\) | 0.08240 |
| \(\mu\) | \(2^{14}\) | 0.03023 |
| \(\mu\) | \(2^{18}\) | 0.01469 |

相应的 \(E(N,H)H/N^2\) 在该范围约为
\(19,106,462\)（\(\lambda\)）和 \(15,44,170\)（\(\mu\)），明显高于
常数或缓慢的 \(N^{\varepsilon}\) 量级。该表只是有限数值诊断，不能作为渐近反例；但它明确说明
原始 \(C_h\) 的 (1) 不是一个可以无条件默认的“自然四点门”，并且很可能比 RH
本身强得多，或遗漏了论文中应有的归一化、端点权或 signed cross-term。外部来源
实际使用的 \(C_h^*(X)=\sup_Y|C_h(Y)|\) 只会使左端更大，所以不能用
“最大端点”解释掉这个尺度差异。

## 3. 与来源定义的核对及主线决定

外部来源的公开正文明确写出
\[
C_h(Y)=\sum_{n\le Y}\lambda(n)\lambda(n+h),\qquad
C_h^*(X)=\sup_{Y\le X-h}|C_h(Y)|,
\]
并将
\[
\sum_{H<h\le2H}C_h^*(X)^2\ll_\varepsilon X^{2+\varepsilon}H^{-1}
\]
列为 Open Problem 6.1，而不是已证定理。故这里没有可通过重解释消除的归一化
歧义：该门应标成一个独立的、显著强于“固定移位 Chowla”的新算术假设，
不再称其为由现有 U² / averaged-Chowla 路线自然产生的 RH 最小门。

本 note 不声称数值计算反驳 (1)，也不把它升级为 RH 反证；它只阻止在量纲未核验
前继续堆叠局部均匀性工具。
