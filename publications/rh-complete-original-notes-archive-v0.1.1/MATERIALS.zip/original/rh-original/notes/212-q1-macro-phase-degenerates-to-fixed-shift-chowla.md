> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(q=1\) 宏观连续轨道的相位退化：固定移位 Chowla 门

日期：2026-08-15。

本 note 对 note 211 的连续分母子结构作严格尺度化。若
\(n\asymp N^\alpha\)、\(\alpha>1/2\)，则 \(N/(n(n+1))\to0\)，因此 Fourier
积分因子没有可用的 van der Corput 振荡；连续轨道退化为固定移位
\(\mu(n)\mu(n+1)\) 的短区间相关。

## 1. 宏观块约化

记
\[
 L=\log N,\quad
 \lambda_{m,N}=\mu(m)\frac{\log(N/m)}{L},\quad
 J_N(n)=\mathcal I_N\!\left(\frac1{n(n+1)}\right),
\]
其中 \(\mathcal I_N(\alpha)=\int_N^{2N}e^{2\pi i\alpha y}\,dy\)。固定
\(\alpha\in(1/2,1)\)，置 \(X=N^\alpha\)，\(I_{N,\alpha}=[X,2X]\cap\mathbb Z\)。
将有序对 \((n,n+1)\)、\((n+1,n)\) 合并，定义
\[
 \mathscr C_{N,\alpha}:=
 2\sum_{n\in I_{N,\alpha}}
 \lambda_{n,N}\lambda_{n+1,N}C_{n,n+1}(1)J_N(n).
\tag{1}
\]
由 note 211
\[
 C_{n,n+1}(1)=\frac1{4\pi}\left(\cot\frac\pi{n+1}-\cot\frac\pi n\right)
 =\frac1{4\pi^2}+O(n^{-2}),\tag{2}
\]
且
\[
 |J_N(n)-N|\le\int_N^{2N}\frac{2\pi y}{n(n+1)}\,dy
 \ll N^2/X^2.\tag{3}
\]
此外 \(\lambda_{n,N}\lambda_{n+1,N}
=\mu(n)\mu(n+1)((1-\alpha)^2+O_\alpha((\log N)^{-1}))\) 一致成立。因此
\[
 \boxed{\mathscr C_{N,\alpha}
 =\frac{N(1-\alpha)^2}{2\pi^2}
 \sum_{n\in I_{N,\alpha}}\mu(n)\mu(n+1)
 +O_\alpha\!\left(\frac{NX}{\log N}+\frac{N^2}{X}\right).}\tag{4}
\]
相位误差相对主尺度 \(NX\) 为 \(N^{1-2\alpha}\to0\)。故在此宏观块上
\(e^{2\pi iN/(n(n+1))}=1+o(1)\)；该相位不提供独立振荡。

## 2. 分部求和的严格边界

令
\[
 A_X(t)=\sum_{X<n\le t}\mu(n)\mu(n+1),\qquad
 u_N(t)=\frac{\log^2(N/t)}{(\log N)^2}.
\]
Abel 变换给出
\[
 \sum_{X<n\le2X}\mu(n)\mu(n+1)u_N(n)
 =A_X(2X)u_N(2X)-\int_X^{2X}A_X(t)u_N'(t)\,dt+O(1),\tag{5}
\]
且 \(\int_X^{2X}|u_N'(t)|dt\ll_\alpha1\)。所以分部求和至多给出
\[
 \left|\sum_{X<n\le2X}\lambda_{n,N}\lambda_{n+1,N}\right|
 \ll_\alpha\sup_{X\le t\le2X}|A_X(t)|+O(1),\tag{6}
\]
并不绕开固定移位相关；绝对值仍为 \(O(X)\)。

## 3. Chowla/Estermann 输入的实际缺口

固定移位断言
\[
 \sum_{n\le Y}\mu(n)\mu(n+1)=o(Y)\tag{7}
\]
仍是两点 Möbius--Chowla 型开放问题。Matomäki--Radziwiłł--Tao
(arXiv:1503.05121) 给出的是对移位的平均；Tao 的两点结果是对 \(n\) 的对数
平均，均不提供 (7) 在固定 dyadic 区间上的平方根级界。因此 (4) 不能由
现有 averaged-Chowla 黑箱直接关闭。

完整 \(q=1\) 层按 \(h=de\) 重排时，\(\mu(d)\mu(e)\ne0\)、\((d,e)=1\) 蕴含
\(h\) 平方自由且 \(\mu(d)\mu(e)=\mu(h)\)，形式上成为
\[
 \sum_{\substack{h\le N^2\\h\ {\rm squarefree}}}
 \mu(h)e^{2\pi iN/h}\mathfrak A_N(h),\quad
 \mathfrak A_N(h)=\sum_{\substack{d\mid h\\1<d<h}}
 \frac{\log(N/d)\log(Nd/h)}{(\log N)^2}C_{d,h/d}(1).\tag{8}
\]
其中 \(\mathfrak A_N(h)\) 含 \(d,h/d\) 的 modular-inverse cotangent。标准
Estermann/cotangent reciprocity 针对固定模数的完整 residue 和；(8) 的模数同时
变化，而且 \(h\gg N\) 时 \(e^{2\pi iN/h}=1+O(N/h)\)，没有可 completion 的加法
振荡。因此直接套 Estermann/Kloosterman 会退化到绝对值尺度，需要新的
squarefree-\(h\) inverse-cotangent divisor-sum 双线性估计。

## 4. 结论

(4) 不是完整 \(q=1\) 双和的下界，其他 Bezout 轨道可能抵消它；但它严格证明：
任何逐轨道、绝对值或仅依赖相位导数的证明，在 \(\alpha>1/2\) 宏观块上都必须
处理固定移位 Chowla 相关。下一步只有两条路：取得固定 \(h=1\) 的新幂次节省，
或在完整 cotangent--Möbius 双和中显式证明跨轨道抵消。本 note 不把该子问题
误作 RH 等价命题，也不声称已得到平方根估计。

