> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius 预条件器的 cutoff 边界是双曲 signed 尾

本 note 专门展开 note 370 的 incomplete-lcm boundary，固定
\(P(y)=\phi(1/y)\)，即 \(V=V_\phi\) 为 Möbius-preconditioned detector。

## Full 与 cutoff 的精确分解

令 \(z=\sqrt x\)，并记
\[
T^{\mathrm{full}}_\phi(x)=
\sum_{ab<x}\mu(a)\mu(b)\phi(ab/x),
\qquad
T^{\mathrm{cut}}_\phi(x)=
\sum_{a,b\le z}\mu(a)\mu(b)\phi(ab/x).
\]
由于 \(ab<x=z^2\) 时不可能同时有 \(a>z\) 与 \(b>z\)，所有 full
但不在 cutoff 中的有序因子对恰好分成两份互换的半格。因此有严格恒等式
\[
T^{\mathrm{full}}_\phi(x)=T^{\mathrm{cut}}_\phi(x)+2R_\phi(x),
\tag{1}
\]
其中
\[
R_\phi(x)=
\sum_{a\le z}\mu(a)
\sum_{z<b<x/a}\mu(b)\phi(ab/x).
\tag{2}
\]
端点约定不影响恒等式：\(\phi(1)=0\) 吸收 \(ab=x\) 的项。

因此 full 和的 \(\zeta^{-2}\) Mellin 恒等式不能直接传给原始 cutoff
门；必须额外控制这个双曲尾 \(R_\phi\)。

## 二阶多项式核的显式 Mertens 尾

取 \(\phi(u)=u(1-u)\mathbf1_{(0,1)}(u)\)，并写
\[
M_j(t)=\sum_{n\le t}\mu(n)n^j\qquad(j=1,2).
\]
由 (2) 逐项展开，得到
\[
\begin{aligned}
R_\phi(x)=2\sum_{a\le z}\mu(a)\Bigg[&
 \frac{a}{x}\sum_{z<b<x/a}\mu(b)b\\
 &-\frac{a^2}{x^2}\sum_{z<b<x/a}\mu(b)b^2
\Bigg].
\end{aligned}
\tag{3}
\]
每个内层和都是加权 Mertens 尾
\(M_j((x/a)^-)-M_j(z)\)。这不是由
\(P(y)=O(y^{-2})\) 或 periodization 正性自动控制的量。

## 最小有理校准

在 \(x=3\) 时 \(z=\sqrt3\)，只有 \((a,b)=(1,2)\) 落入 (2)，故
\[
R_\phi(3)=\mu(1)\mu(2)\phi(2/3)=-\frac29.
\]
结合
\(T^{\mathrm{cut}}_\phi(3)=2/9\) 与
\(T^{\mathrm{full}}_\phi(3)=-2/9\)，严格验证 (1)：
\[
-\frac29=\frac29+2\left(-\frac29\right).
\]

## 算术含义

若试图由 full 对象的 Mellin 表示推出原始 cutoff 对象的平方根界，
必须同时证明 \(R_\phi(x)\) 具有相同量级的 signed cancellation；否则
full 的 \(\zeta^{-2}\) 解析信号会被 incomplete-lcm 尾改变。逐项取绝对值
把 (2) 上界推回 \(x\) 量级，正是原始 reciprocal-product 门的已知障碍。

所以最薄的未闭合命题不是“再证明一次 periodization 正性”，而是对
(2) 或 (3) 建立跨 \(a\)、\(b\) 的 signed intertwiner；这与 lcm 分层
note 205 的宏观 cutoff 层完全一致。

上游：notes 205、239、368、370。
