> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 所有短区间的 \(U^2\) 均匀性仍缺少四点门所需的多项式速率

日期：2026-08-16。

Matomäki--Shao--Tao--Teräväinen 的 *Higher uniformity of arithmetic functions in short intervals I. All intervals*（arXiv:2204.03754，Forum Math. Pi 2023）证明：当
\[
X^{5/8+\varepsilon}\le H\le X^{1-\varepsilon}
\]
时，\(\mu\) 在**每个**区间 \((X,X+H]\) 上对固定阶 nilsequence（因此包括 \(U^2\) 结构）的相关可获得任意对数级衰减。原文 Theorem 1.1(i) 给出
\[
\left|\sum_{X<n\le X+H}
\mu(n)F(g(n)\Gamma)\right|^*
\ll_{A,\varepsilon}H(\log X)^{-A}. \tag{1}
\]
论文明确说明这导致所有短区间的 Gowers 均匀性。来源：
<https://arxiv.org/html/2204.03754>。

## 换算到四点均方

考虑 Möbius 版本的中程门
\[
\mathcal E(Y,H)=
\sum_{H<h\le2H}
\left|\sum_{n\le Y}\mu(n)\mu(n+h)\right|^2. \tag{2}
\]
把 \([1,Y]\) 的主尺度部分分成长度 \(L\asymp H\)（取 \(L\ge 2H\)）
的互不相交区间 \(I_j\)，记
\[
C_j(h)=\sum_{n\in I_j}\mu(n)\mu(n+h),
\qquad C(h)=\sum_j C_j(h).
\]
若区间数为 \(J\asymp Y/L\)，Cauchy--Schwarz 给出
\[
\sum_h|C(h)|^2
\le J\sum_j\sum_h|C_j(h)|^2. \tag{3}
\]
对零延拓到整数的区间函数，局部 \(U^2\) 恒等式为
\[
\sum_{h\in\mathbb Z}|C_j(h)|^2
=L^3\|\mu 1_{I_j}\|_{U^2(\mathbb Z)}^4. \tag{4}
\]
因此若把 (1) 所给的归一化局部 \(U^2\) 界记为
\(\|\mu\|_{U^2(I_j)}\le\delta_Y\)，则
\[
\mathcal E(Y,H)\ll Y^2L\,\delta_Y^4
\asymp Y^2H\,\delta_Y^4. \tag{5}
\]

而当前定理只给
\[
\delta_Y\ll_A(\log Y)^{-A}
\]
（任意固定 \(A\)），于是 (5) 至多为
\[
\mathcal E(Y,H)\ll_A Y^2H(\log Y)^{-4A}, \tag{6}
\]
仍远大于 RH 门所需的
\[
\mathcal E(Y,H)\ll_{\varepsilon}Y^{2+\varepsilon}H^{-1}. \tag{7}
\]
要由这个区间拼接方案得到 (7)，至少需要
\[
\delta_Y\ll H^{-1/2}Y^{\varepsilon/4}, \tag{8}
\]
即随区间长度衰减的多项式 \(U^2\) 速率，而不是任意固定的对数幂。

## 裁决

“所有短区间”高阶均匀性确实消除了早期路线中“只知道几乎所有区间”的量词障碍，但它没有消除四点均方的尺度障碍：从局部 \(U^2\) 到全局端点相关需要跨区间 Cauchy--Schwarz，额外产生 \(Y^2H\) 因子。当前文献的对数级 \(\delta_Y\) 不足以支付 \(H^{-1}\) 目标。

因此，最小新输入被进一步精确为：在相关区间尺度上获得 (8) 型多项式 \(U^2\) 速率，或直接证明带端点的全局四点均方 (7)。这仍不是现有“所有短区间”定理的直接推论。

## 当前文献交叉核对

较早的 Liouville 高阶均匀性定理确实给出短区间上的定性
\(o(1)\) 平均结果，但其结论形式是对区间起点的平均，而不是本门所需的
固定端点、移位平方和以及 \(H^{-1}\) 多项式衰减；见
[Annals of Mathematics 197 (2023)](https://annals.math.princeton.edu/2023/197-2/p03)。
较新的 “Higher uniformity II” 摘要虽然研究 \(\mu\) 的短区间结构，但其明确展示的
应用是 \(\Lambda\) 与除数函数的几乎所有区间估计，并没有给出本项目所需的
\(\lambda\) 固定端点四点门；见
[arXiv:2411.05770](https://arxiv.org/abs/2411.05770)。
因此这些结果改善了量词范围，却没有改变式 (8) 的多项式速率缺口。
