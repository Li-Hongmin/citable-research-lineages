> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 增长倍数链截断的全局列能量障碍

日期：2026-08-17。

notes 462--464 给出单个除数列的 residual 平台与第一段确定性斜率。本 note
把它们对 $d$ 聚合，得到对“用增长长度的倍数链逐列近似 completion”的全局下界。

## 1. 参数范围

令 $A=A(N)$、$B_0=B_0(N)$ 为整数，并假设

\[
A\to\infty,
\qquad \frac{A}{\log N}\to\infty,
\qquad B_0\to\infty,
\qquad AB_0=o(N).
\tag{1}
\]

设

\[
D_N=\left\lfloor\frac{N}{2AB_0}\right\rfloor,
\qquad
M_d=\left\lfloor\frac Nd\right\rfloor,
\qquad
B_d=\left\lfloor\frac{M_d}{A+1}\right\rfloor.
\]

对 $1\le d\le D_N$，有 $M_d\ge2AB_0$，从而

\[
B_d\ge B_0,
\qquad M_d\ge2A+1.
\tag{2}
\]

## 2. 单列下界的一致化

由 note 461 的双曲线展开，且 $B_d\ge B_0$，得到

\[
Z_{M_d,A}
=\log(M_d/A)S(B_d)-L(B_d)
+O\!\left(\frac{\log(2B_d)}A\right).
\tag{3}
\]

经典零自由区给出
$\sup_{B\ge B_0}|\log B\,S(B)|\to0$，而
$\sup_{B\ge B_0}|L(B)+1|\to0$。由
$\log(M_d/A)=\log B_d+O(A^{-1})$ 以及
$\log B_d\le\log N$，条件 (1) 使误差在 $d\le D_N$ 上一致趋于零。因此

\[
\boxed{Z_{M_d,A}=1+o(1)\quad\text{uniformly for }1\le d\le D_N.}
\tag{4}
\]

将 note 464 的确定性斜率下界应用于每个这样的 $d$，并记

\[
c_*:=\frac{17}{2}+4(\log2)^2-12\log2>0,
\tag{5}
\]

得到一致估计

\[
\boxed{
\|\mathcal R_{d,A}\|_2^2\ge(c_*+o(1))A^2,
\qquad 1\le d\le D_N.
}
\tag{6}
\]

## 3. 全局列能量下界

对 (6) 求和，利用 $D_N=N/(2AB_0)+o(N/(AB_0))$，得到

\[
\boxed{
\sum_{d\le D_N}\|\mathcal R_{d,A}\|_2^2
\ge\left(\frac{c_*}{2}+o(1)\right)\frac{NA}{B_0}.
}
\tag{7}
\]

特别地，取 $B_0=\lceil\log N\rceil$，并令 $A=N^\alpha$，其中
$0<\alpha<1$，则

\[
\boxed{
\sum_{d\le D_N}\|\mathcal R_{d,A}\|_2^2
\gg_\alpha \frac{N^{1+\alpha}}{\log N}.
}
\tag{8}
\]

这里隐含常数只来自 $c_*$；条件 (1) 对该选择成立。

## 4. 算术含义与边界

式 (8) 严格排除了一个具体路线：若试图用长度 $A=N^\alpha$ 的截断倍数
链逐列近似完整 completion，并希望所有列 residual 的 Hilbert--Schmidt 总能量
达到 $O(N^{1+\varepsilon})$，那么任何 $\varepsilon<\alpha$ 都不可能。障碍
不是深层的四点 Möbius 相关，而是每列最初两段由因子序结构强制产生的 reciprocal
平台与斜率。

这不排除保留列间 signed 交叉的全局 intertwiner，也不等于 RH；它只说明“增长
链长度 + 逐列正 Gram/低秩 completion”不能作为平方根级算术桥。
