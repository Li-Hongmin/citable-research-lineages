> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 两素数反射带的完整严格正性：推进至 \(a=\log 2\)

**日期：** 2026-08-11  
**状态：** 项目级严格证书完成；依赖 notes 003、017、018、021、022、023 的归一化、定义域与尺度单调性。原始导入稿编号为 024；因项目已有 note 024，合并时顺延为 025。  
**核心结论：** 首次退化若存在，必须严格晚于 \(a=\log2\)。

---

## 1. 定理

令 \(A_a=A_a^+\oplus A_a^-\) 为 Suzuki 局部 Weil 形式对应的奇偶自伴算子。则

\[
\boxed{
A_a^+>0,\qquad A_a^->0,
\qquad 0<a\le \log2 .}
\]

从而

\[
\boxed{A_a>0\qquad(0<a\le\log2).}
\]

特别地，若 RH 为假并存在首次退化尺度 \(a_{\rm deg}\)，则

\[
\boxed{a_{\rm deg}>\log2=0.6931471805599453\ldots .}
\]

这把 note 022 的

\[
a_{\rm deg}>\tfrac12\log3
\]

推进到第二个完整 activation band 的右端点。

---

## 2. 为什么只需认证端点

note 003 已证明零延拓下的 form-domain 嵌套与全谱 min--max 单调性；奇偶子空间分别保持。因此

\[
0<a<b\quad\Longrightarrow\quad
\lambda_1^\pm(a)\ge \lambda_1^\pm(b).
\]

故只需证明

\[
A_{\log2}^+>0,\qquad A_{\log2}^->0.
\]

在端点 \(a=\log2=\frac12\log4\) 上：

- \(n=2,3\) 的 prime-power shifts 有正测度重叠；
- \(n=4\) 的 shift 长度等于区间直径，只发生零测度端点接触，其 jump 对角项与 scalar correction 精确抵消。

所以真正活跃的 prime 结构恰为 note 023 的两个部分反射。

---

## 3. 两个 prime reflections 的精确范数

在半区间 \(L^2(0,a)\) 上令

\[
d_2=\log2=a,\qquad d_3=\log3,
\]

\[
p_2=\frac{\log2}{\sqrt2},\qquad
p_3=\frac{\log3}{\sqrt3},
\]

并记

\[
(J_i f)(x)=
\mathbf1_{[d_i-a,\,\min(a,d_i)]}(x)f(d_i-x).
\]

在本端点 \(d_2=a<d_3<2a\)。note 023 的联合轨道分解表明，每个非平凡 fiber 至多四维；四点 fiber 的 weighted adjacency matrix 为

\[
B_4=
\begin{pmatrix}
0&p_2&0&0\\
p_2&0&p_3&0\\
0&p_3&0&p_2\\
0&0&p_2&0
\end{pmatrix}.
\]

其谱半径为

\[
\boxed{
\rho=\frac{p_3+\sqrt{p_3^2+4p_2^2}}2
=0.900927616261846\ldots .}
\]

二点 fiber 的范数为 \(p_2<\rho\)，故

\[
\boxed{\|p_2J_2+p_3J_3\|=\rho.}
\]

偶扇区 prime 项为 \(-p_2J_2-p_3J_3\)，奇扇区为其相反数。

---

## 4. Fourier--Yukawa 精确分解

令

\[
m(\xi)=\operatorname{Re}\psi\!\left(\frac14+\frac{i\xi}{2}\right)-\log\pi,
\qquad c_n=2\left(n+\frac14\right).
\]

### 4.1 偶空间

取 Neumann Fourier 基

\[
e_0=a^{-1/2},\qquad
e_k=(2/a)^{1/2}\cos(k\pi x/a)\quad(k\ge1),
\]

并记 \(\kappa_k^+=k\pi/a\)。由 note 018 的 Yukawa--Neumann 分解，Archimedean 部分精确写成

\[
D^++\sum_{n\ge0}|f_n^+\rangle\langle f_n^+|,
\qquad D^+e_k=m(\kappa_k^+)e_k,
\]

其中可用稳定指数形式写

\[
\boxed{
f_n^+(x)=
\frac{e^{-c_n(a-x)}+e^{-c_n(a+x)}}
{\sqrt{1-e^{-2c_na}}}.}
\]

恢复极点项与 prime reflections 后，

\[
\boxed{
A_a^+=D^++\sum_{n\ge0}|f_n^+\rangle\langle f_n^+|
-(p_2J_2+p_3J_3)+|u\rangle\langle u|,}
\]

\[
u(x)=2\cosh(x/2).
\]

### 4.2 奇空间

取 Dirichlet--Neumann Fourier 基

\[
o_k=(2/a)^{1/2}\sin((k+\tfrac12)\pi x/a),\qquad k\ge0,
\]

并记 \(\kappa_k^-=(k+\tfrac12)\pi/a\)。同理，

\[
\boxed{
A_a^-=D^-+\sum_{n\ge0}|f_n^-\rangle\langle f_n^-|
+(p_2J_2+p_3J_3)-|v\rangle\langle v|,}
\]

其中

\[
D^-o_k=m(\kappa_k^-)o_k,
\]

\[
\boxed{
f_n^-(x)=
\frac{e^{-c_n(a-x)}-e^{-c_n(a+x)}}
{\sqrt{1+e^{-2c_na}}},}
\]

\[
v(x)=2\sinh(x/2),
\qquad
\|v\|_2^2=2(\sinh a-a).
\]

每个省略的 Yukawa 项均为正秩一形式。

---

## 5. 有限正下模型

固定

\[
R=30,\qquad N=80.
\]

以 \(P_R\) 表示前 \(R\) 个相应 Fourier modes 的正交投影，\(Q_R=I-P_R\)。仅保留前 \(N\) 个正 Yukawa atoms：

\[
L^+=D^++\sum_{n<N}|f_n^+\rangle\langle f_n^+|
-(p_2J_2+p_3J_3)+|u\rangle\langle u|,
\]

\[
L^-=D^-+\sum_{n<N}|f_n^-\rangle\langle f_n^-|
+(p_2J_2+p_3J_3)-|v\rangle\langle v|.
\]

于是

\[
A_a^\pm\succeq L^\pm.
\]

写

\[
L^\pm=D^\pm+B^\pm.
\]

因为 \(D^\pm\) 在所选 Fourier 基中对角，交叉块满足

\[
P_RL^\pm Q_R=P_RB^\pm Q_R.
\]

### 5.1 补空间的统一下界

利用 \(m(\xi)\) 在 \(\xi>0\) 上严格递增、prime operator 的精确范数以及正 Yukawa atoms 可丢弃，得到

\[
Q_RL^+Q_R\succeq\mu_+Q_R,
\]

\[
\mu_+=m(R\pi/a)-\rho
=2.1736332516938399983\ldots>0,
\]

以及

\[
Q_RL^-Q_R\succeq\mu_-Q_R,
\]

\[
\mu_-=m((R+\tfrac12)\pi/a)-\rho-2(\sinh a-a)
=2.0764569880526617267\ldots>0.
\]

---

## 6. 无穷补空间被压成一个 \(30\times30\) 矩阵

令

\[
C_\pm=P_RB^\pm Q_R.
\]

关键恒等式为

\[
\boxed{
C_\pm C_\pm^*
=P_R(B^\pm)^2P_R-(P_RB^\pm P_R)^2.}
\]

因此不必截断高 Fourier modes，也不必估计一个慢收敛的 cross tail。

定义有限 Feshbach 下矩阵

\[
\boxed{
S_\pm
=P_RL^\pm P_R
-\frac1{\mu_\pm}C_\pm C_\pm^*.}
\]

对任意 \(x\in P_RL^2\)、\(y\in Q_RL^2\)，完成平方给出

\[
\begin{aligned}
\langle L^\pm(x+y),x+y\rangle
&\ge
\langle S_\pm x,x\rangle
+\mu_\pm\left\|y+\mu_\pm^{-1}C_\pm^*x\right\|^2.
\end{aligned}
\]

故

\[
S_\pm>0\quad\Longrightarrow\quad L^\pm>0.
\]

### 6.1 所有有限矩阵元均为闭式

把有限秩函数记为 \(F_\alpha\)，符号矩阵为 \(\Sigma\)。令

\[
H_{i\alpha}=\langle e_i,F_\alpha\rangle,
\quad
K_{\alpha\beta}=\langle F_\alpha,F_\beta\rangle,
\]

\[
G_{i\alpha}=\langle e_i,P_{\rm prime}F_\alpha\rangle,
\quad
P_{ij}=\langle e_i,P_{\rm prime}e_j\rangle,
\]

\[
P^{(2)}_{ij}=\langle P_{\rm prime}e_i,P_{\rm prime}e_j\rangle.
\]

则

\[
P_RBP_R=P+H\Sigma H^*,
\]

\[
P_RB^2P_R
=P^{(2)}+G\Sigma H^*+H\Sigma G^*
+H\Sigma K\Sigma H^*.
\]

所有积分只含

\[
\int_l^u e^{\alpha x}\,dx,
\]

其中 \(\alpha\) 是实指数或实指数加 Fourier 频率；代码不使用数值求积。

---

## 7. Arb 严格证书

使用 `python-flint 0.9.0`，在 320-bit 精度下计算全部：

- \(\log2,\log3,\pi\)、digamma 与双曲函数；
- prime reflection 矩阵与其平方；
- 前 80 个 Yukawa atoms 的全部 Gram/cross Gram；
- \(S_\pm\) 的 interval LDL 分解。

### 7.1 主证书：\((R,N)=(30,80)\)

偶扇区的全部 interval LDL pivots 严格为正，最小 pivot 下界为

\[
\boxed{
7.4220758295731509474\times10^{-5}>0.}
\]

奇扇区对应下界为

\[
\boxed{
4.1619990664059653897\times10^{-4}>0.}
\]

因此

\[
S_+>0,\qquad S_->0.
\]

进而

\[
L^+>0,\qquad L^->0,
\]

最终

\[
A_{\log2}^+>0,
\qquad
A_{\log2}^->0.
\]

### 7.2 独立冗余参数

同一证明用

\[
(R,N)=(40,100)
\]

再次通过：

\[
\min\operatorname{pivot}(S_+)
>7.5578943391103178\times10^{-5},
\]

\[
\min\operatorname{pivot}(S_-)
>4.3103358795100942\times10^{-4}.
\]

主证书还分别在 220、320、480-bit 下重放，符号与下界稳定。

> 这些 LDL pivots 是有限 Feshbach 矩阵的正定证书，不应误报为原算子的实际最低本征值。非认证 Galerkin 诊断提示端点真实谱隙极小，约为 \(8\times10^{-13}\)（偶）和 \(5\times10^{-10}\)（奇）；本定理只使用严格正号。

---

## 8. 结论与下一边界

本结果完整闭合

\[
\frac{\log3}{2}<a\le\log2
\]

这一两素数反射带。结合 notes 017、018、022：

\[
\boxed{A_a>0\qquad0<a\le\log2.}
\]

它还给出一个比 note 022 更短的认证接口：

\[
\boxed{
\text{Fourier diagonal}
+\text{有限正 Yukawa atoms}
+\text{精确 prime-reflection operator}
+\text{极点 rank one}
\longrightarrow
30\times30\text{ Feshbach matrix}.}
\]

下一个区间 \(a>\log2\) 出现新的几何：\(d_2=\log2<a\) 后，prime shift 不再只有跨中心反射，还产生同半区 translation 分支。故 note 023 的纯反射 fiber 结构不能未经修改直接外推；下一步必须先推导“translation + reflection”的精确半区算子。

---

## 9. 可复现材料

脚本：

- `computations/verify_two_prime_band_endpoint_log2.py`

冻结输出与原始哈希表：

- `computations/bundles/log2-two-prime-positivity/`

主命令：

```bash
python verify_two_prime_band_endpoint_log2.py 320 30 80 +
python verify_two_prime_band_endpoint_log2.py 320 30 80 -
```

冗余命令：

```bash
python verify_two_prime_band_endpoint_log2.py 320 40 100 +
python verify_two_prime_band_endpoint_log2.py 320 40 100 -
```

脚本 SHA-256：

```text
bf08b2395487fb734ce459b601cd237dd1635ff10b50ebd26a67ee620766282e
```

本 note 的结论是项目内部严格证明，尚未经过外部解析数论专家独立审稿；它不等同于 RH，也不应在外部表述为已解决黎曼猜想。
