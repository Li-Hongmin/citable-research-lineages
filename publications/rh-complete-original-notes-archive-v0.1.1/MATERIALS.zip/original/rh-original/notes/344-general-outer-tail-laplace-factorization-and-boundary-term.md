> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一般正频外函数尾核的 Laplace 因子化与边界项

日期：2026-08-16。

note 343 的指数模型显示，外函数尾核可能把零频模式中心化。下面给出一般
正频密度的精确公式，以区分真正保留 \(1/\zeta\) 信号的情形。

## 1. 精确 Laplace 公式

令 \(o\) 支持于 \([0,\infty)\)，并假设在某个右半平面有足够指数矩。定义
\[
\mathcal K_{N,o}(\eta)=\frac1{2\pi}
\sum_{n\le N}\mu(n){\bf 1}_{0<\eta<\log n}
o(\log n-\eta).
\]
对
\[
\mathscr L\mathcal K(s)=\int_0^\infty\mathcal K(\eta)e^{-s\eta}\,d\eta
\]
逐项换序并置 \(\xi=\log n-\eta\)，得到
\[
\mathscr L\mathcal K_{N,o}(s)
=\frac1{2\pi}\sum_{n\le N}\mu(n)n^{-s}
\int_0^{\log n}o(\xi)e^{s\xi}\,d\xi.
\tag{1}
\]
若记完整外函数变换
\[
O(s)=\int_0^\infty o(\xi)e^{s\xi}\,d\xi,
\]
则 (1) 等于
\[
\boxed{
\mathscr L\mathcal K_{N,o}(s)
=\frac{O(s)}{2\pi}D_N(s)-\frac1{2\pi}R_{N,o}(s),}
\tag{2}
\]
其中
\[
D_N(s)=\sum_{n\le N}\mu(n)n^{-s},
\qquad
R_{N,o}(s)=\sum_{n\le N}\mu(n)n^{-s}
\int_{\log n}^\infty o(\xi)e^{s\xi}\,d\xi.
\tag{3}
\]
公式 (2) 是有限和恒等式，不涉及 RH。

## 2. 两种边界情形

若 \(o(\xi)=e^{-\xi}{\bf1}_{\xi\ge0}\)，则
\[
O(s)=\frac1{1-s},
\qquad
R_{N,o}(s)=\frac{A_N}{1-s},
\]
从而恢复 note 343 的中心化因子
\[
\mathscr L\mathcal K_{N,o}(s)=
\frac{D_N(s)-A_N}{2\pi(1-s)}.
\]

相反，若 \(o\) 紧支撑于 \([0,L]\)，则 \(R_{N,o}\) 只含
\(n\le e^L\) 的有限项，与 \(N\) 无关（当 \(N>e^L\)）。此时
\[
\mathscr L\mathcal K_{N,o}(s)=\frac{O(s)}{2\pi}D_N(s)+C_o(s),
\tag{4}
\]
其中 \(C_o\) 是固定有限和。也就是说，紧支撑正频外函数不会精确消掉
零频 Möbius 模式；它保留一个 \(D_N(s)\) 主项，只支付有限边界修正。

## 3. 对 RH 桥的设计意义

式 (4) 给出一个清晰的候选设计：若某个 detector 的 Szegő 外函数能产生
紧支撑（或足够快衰减、且边界余项可作有限秩控制）的 \(o\)，其局部对偶
证书将直接携带 \(D_N(s)\) 的 reciprocal-zeta 信号。指数模型虽有显式
边界项，但其零频值为 \(M(N)-A_N\)，并未消失；note 345 证明其统一平方根
界同样与 RH 等价。

当前 \(V_{15}\) 的实际权 \(w=|h|/(2\pi)\) 已固定，不能任意替换成这样的
理想权；同时，若对一个紧支撑模型证明平方根能量界，按 notes 212、246
仍会得到 RH，而不是一个较弱的替代命题。故本 note 提供的是可检验的
外函数选择准则，不是无条件算术估计。
