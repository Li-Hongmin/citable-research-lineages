> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 更正：Beta 表示与 q-shift 权重的对齐

日期：2026-08-16。

此前的“Beta 表示反例”把两种不同的权重序列作了比较，结论应撤回。
q-shift 公式中的权重是

\[
w_q=c_q\binom{D}{q},
\qquad D=3m+3,
\]

而不是递推系数 \((q+1)c_q\)。后者出现在另一种未完成的展开中，不能用来
检验 q-shift 的 \(W(z)\)。

## 精确对齐

令

\[
c_q=\frac{(2m-q)!q!}
 {2^{m-q+2}(m-q+1)!(q-2)!\binom D2},
\qquad 2\le q\le m+1.
\]

由反向 Bessel 递推得到的 \(W(z)=\sum_qw_qz^q\) 满足精确 Beta 表示

\[
W(z)=A_m z^2\int_0^1 t^{m-1}(1-t)^{m+2}(t+2z)^{m-1}\,dt,
\]

其中

\[
A_m=\frac{(3m+3)!}
 {2^m\binom{3m+3}{2}(m-1)!(m+2)!}.
\]

展开 \((t+2z)^{m-1}\) 后，\(z^{\ell+2}\) 的系数为

\[
A_m\binom{m-1}{\ell}2^\ell
B(2m-1-\ell,m+3),
\qquad 0\le\ell\le m-1,
\]

并与 \(c_{\ell+2}\binom D{\ell+2}\) 逐项相等。精确 Fraction 检查
`computations/check_reverse_bessel_beta_representation.py` 已验证 \(m=1,\ldots,30\)。

例如 \(m=4\)：

\[
c_q\binom{12}{q}=(15,195,936,1716)_{q=2}^5,
\]

而错误审计比较的 \((q+1)c_q\) 是
\[
(3/7,12/7,24/7,24/7)_{q=2}^5.
\]

两者不同并不构成反例；它们本来就不是同一对象。

## 当前裁决

因此，旧 note 105 中“Beta 表示已被 m=4 反例否定”的状态失效。note 162--164
中使用正确 \(w_q=c_q\binom Dq\) 的 Beta 归约可以继续作为候选证明，仍需
逐式审阅其正性论证；有限算术检查不能自动升级为全 \(m\) 定理。该更正只涉及
detector 系数层，完全不触及 Möbius signed-energy 的 RH-strength 缺口。
