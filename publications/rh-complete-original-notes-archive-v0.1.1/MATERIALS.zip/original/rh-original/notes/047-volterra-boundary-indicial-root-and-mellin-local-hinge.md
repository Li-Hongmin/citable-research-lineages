> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Logarithmic 边界的 Volterra indicial root 与 Mellin-local 铰链

日期：2026-08-11。

本文把 [notes 044--046](044-renormalized-log-pohozaev-hinge-and-prime-virial.md) 中未证明的
boundary gauge trace 压缩为一个局部 Mellin 正则性命题。主要结论是：边界主算子只有一个慢模
\(t^{-1/2}\)；finite prime shifts 与 smooth remainder 不改变该 indicial root。唯一未闭合项是同尺度
环上的 Mellin-local singular integral。

## 1. 边界坐标与主 Volterra 算子

在右端点写

\[
r=a-x=e^{-t},\qquad U(t)=u(a-e^{-t}),\qquad t\to\infty.
\]

把 exterior-zero logarithmic jump operator 按 \(s\ll r\)、\(s\asymp r\)、\(s\gg r\) 分解。
外侧 killing 的 leading term 为 \(tU(t)\)，远内侧部分给出

\[
tU(t)-\int^{t}U(\tau)\,d\tau.
\]

因此边界 leading operator 是

\[
\boxed{
(\mathcal VU)(t)=2tU(t)-\int_{t_0}^{t}U(\tau)\,d\tau.}
\tag{1}
\]

同尺度环 \(s\in[r/2,2r]\) 留下

\[
\mathcal M u(r)
=\int_{r/2}^{2r}
\frac{u(a-r)-u(a-s)}{|r-s|}\,ds,
\tag{2}
\]

以及有界核修正。

## 2. 唯一慢 indicial root

若

\[
\mathcal VU=F,\qquad F\in L^\infty(t_0,\infty),
\tag{3}
\]

令

\[
A(t)=\int_{t_0}^{t}U(\tau)\,d\tau.
\]

由 \(2tA'-A=F\) 得

\[
\left(\frac{A(t)}{\sqrt t}\right)'
=\frac{F(t)}{2t^{3/2}}.
\tag{4}
\]

右端可积，故存在 \(B\in\mathbf C\) 使

\[
A(t)=2B\sqrt t+O(1),
\]

进而

\[
\boxed{
U(t)=\frac{B}{\sqrt t}+O(t^{-1}).}
\tag{5}
\]

所以主模型只有一个慢 root。典型振荡轮廓

\[
t^{-1/2}\sin(\log\log t)
\]

会使 \(\mathcal VU\) 产生约 \(\sqrt t/\log t\) 的无界项，不能与有界 forcing 相容。

## 3. Prime 与 smooth 项不改变 indicial equation

固定 active delay \(d>0\)。当 \(r\downarrow0\) 时，零延拓 shift 要么为零，要么采样距端点正距离的
内部值；在已经得到的 \(L^\infty\) 正则性下，它只贡献有界 forcing。\(d=a\) 只改变采样来自哪一侧，
不产生新的慢边界模。有限个 active prime shifts 的总和仍有界。

smooth convolution、polar rank-one 与本征值乘法项也都是有界 forcing。因此实际 Weil 零模态若能
证明

\[
\mathcal M u\in L^\infty(0,r_0),
\tag{6}
\]

则式 (3)--(5) 严格给出右端 gauge trace；左端同理。

## 4. 当前唯一缺口

现有最优边界上界

\[
|U(t)|\le Ct^{-1/2}
\]

不控制 \(U\) 在长度 \(O(1)\) 的 log-scale 区间上的模连续性，因而不能单独推出 (6)。弱方程只控制

\[
\mathcal VU+\mathcal M u,
\]

直接把两项分别估计为有界会循环使用待证结论。

因此 boundary-trace 路线的最小正则性命题是一个 Mellin-local Dini/Besov 估计，例如足以推出

\[
\sup_{0<r<r_0}
\int_{r/2}^{2r}
\frac{|u(a-r)-u(a-s)|}{|r-s|}\,ds<\infty.
\tag{7}
\]

这比一般 Hölder 正则性窄，也与 finite prime shifts 无关。现有材料尚未证明 (7)，但主模型已经排除
了“多个慢 indicial modes”这一结构障碍。

## 5. Pohozaev 常数的几何归一化

若进一步存在截断 dilation Green identity，则对标准生成元

\[
X=x\partial_x+\frac12
\]

在对称区间 \((-a,a)\) 上，候选边界项的正确几何归一化是

\[
\boxed{
a\bigl(|B_+|^2+|B_-|^2\bigr)=2\|u\|_2^2.}
\tag{8}
\]

bulk commutator 常数 \(2\) 与质量项极限可以严格核准；但仅有
\(u(a-r)=B_+t^{-1/2}+o(t^{-1/2})\) 还不足以控制 \(Xu\) 中的 \(r\partial_ru\) 及 collar--bulk
交叉项。式 (5) 给出的 \(O(t^{-1})\) 余项仍需相应 conormal/Dini 控制，才能把 (8) 晋级为定理。

故当前严格成果是 (1)--(7) 的条件归约；式 (8) 仍是待证 Green identity。

