> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正矩望远镜的纯信息论 (2/3) 障碍

## 命题

记

\[
B_j(z):=\frac{A_j(z)^2}{z^{2j}},
\qquad A_j(z)=\sum_{n\le z}\mu(n)n^j .
\]

则

\[
B_j\ge0,
\qquad B_j\le \frac{4z^2}{(j+1)^2},
\qquad T_j(z^2)=B_j-B_{j+1}.
\tag{1}
\]

若一个证明只使用 (1) 中的上包络和相邻差界

\[
|T_j(z^2)|\le C z
\quad (0\le j\le J),
\tag{2}
\]

那么它不能从这类资料推出
\(B_0=o(z^{4/3})\)，更不能推出
\(M(z)=o(z^{2/3})\)。换言之，notes 373 的 (2/3) 指数不是等权求和造成的排版损失，而是这组局部不等式本身的最优信息论指数。

## 上界的唯一局部推导

对任意 (J\ge0)，望远镜和三角不等式给出

\[
B_0\le \sum_{j=0}^{J}|B_j-B_{j+1}|+B_{J+1}
\le C(J+1)z+\frac{4z^2}{(J+2)^2}.
\tag{3}
\]

优化 (J\asymp z^{1/3}) 得

\[
B_0\ll z^{4/3},
\qquad M(z)=\sqrt{B_0}\ll z^{2/3}.
\tag{4}
\]

这一步不依赖 (T_j) 的来源，只依赖 (1)--(2)。

## 近似饱和的抽象序列

下面构造满足同样约束、且达到 (B_0\asymp z^{4/3}) 的非负序列。令

\[
J=\lfloor z^{1/3}\rfloor,
\qquad E_j=\frac{4z^2}{(j+1)^2}.
\]

定义

\[
\widetilde B_j=
\begin{cases}
E_J+\dfrac z4(J-j),&0\le j\le J,\\[4pt]
E_j,&j>J.
\end{cases}
\tag{5}
\]

显然 \(\widetilde B_J=E_J\)，且 \(\widetilde B_j\le E_j\) 对 (j\le J) 成立：事实上

\[
E_j-E_J
=\frac{4z^2(J-j)(J+j+2)}{(j+1)^2(J+1)^2}
\ge \frac{4z^2(J-j)}{J^2(J+1)}
\ge \frac z2(J-j)
\tag{6}
\]

（取 (z) 足够大）。因此 \(0\le\widetilde B_j\le E_j\)。另外，(j<J) 时相邻差为 (z/4)，而 (j\ge J) 时

\[
|E_j-E_{j+1}|
=4z^2\frac{2j+3}{(j+1)^2(j+2)^2}
\ll z
\tag{7}
\]

因为 (J\asymp z^{1/3})。故存在绝对常数 (C_0) 使
\(|\widetilde B_j-\widetilde B_{j+1}|\le C_0z) 对所有 (j) 成立，但

\[
\widetilde B_0
=E_J+\frac z4J
\asymp z^{4/3}.
\tag{8}
\]

所以任何只把 (B_j) 当作满足 (1)--(2) 的黑箱的线性组合、加权望远镜或 Abel 变换，都不能在逻辑上排除 (z^{4/3}) 量级的 (B_0)。

## 对研究路线的含义

这不是说真实的 Möbius 矩列可以任意取为 (5)，也不是 RH 的反例。它精确说明：要越过 (2/3) 门，必须使用尚未进入 (1)--(2) 的额外结构，例如

* 不同 (j) 之间的联合正定/反射关系；
* 对最高阶尾 (A_{J+1}) 的独立 signed cancellation；或
* 把不完整 lcm 边界 (R_\phi) 与各 (T_j) 联立的算术 intertwiner。

单独增加更多非负核、或把每个 (T_j) 都估到 (O(z^{1+\varepsilon}))，不会自动提供这些信息。

