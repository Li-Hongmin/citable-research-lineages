> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有限尺度尾差分的统一 Mellin--RH 判据

## 1. 无限尾与尺度多项式

由 PNT，定义
\[
B(k)=\sum_{n\ge k}\frac{\mu(n)}n.
\]
给定有限多项式
\[
P(z)=\sum_{j=0}^{J}a_jz^j,
\]
定义其尾差分
\[
H_P(k)=\sum_{j=0}^{J}a_j2^{-j}
B\!\left(\left\lceil\frac{k}{2^j}\right\rceil\right).
\tag{1}
\]
这正是有限尺度 Möbius 滤波器的 reciprocal 尾部；\(j\) 的尺度因子
来自 \(m=2^jn\) 时的 \(1/m=2^{-j}/n\)。

## 2. 精确离散 Mellin 恒等式

令 \(w_k(z)=k^{-z}\)、\(w_0(z)=0\)，并定义
\[
\mathcal F_P(z)
=\sum_{k\ge1}H_P(k)\bigl(w_k(z)-w_{k-1}(z)\bigr).
\]
对 \(\Re z>0\)，可绝对交换求和。由于
\[
\left\lceil\frac{k}{2^j}\right\rceil\le n
\quad\Longleftrightarrow\quad
k\le2^jn,
\]
有
\[
\begin{aligned}
\mathcal F_P(z)
&=\sum_{j=0}^{J}a_j2^{-j}
\sum_{n\ge1}\frac{\mu(n)}n
\sum_{k\le2^jn}(w_k-w_{k-1})\\
&=\sum_{j=0}^{J}a_j2^{-j}2^{-jz}
\sum_{n\ge1}\frac{\mu(n)}{n^{z+1}}\\
&=\boxed{\frac{P(2^{-(z+1)})}{\zeta(z+1)}}.
\end{aligned}
\tag{2}
\]
这把尾差分的尺度多项式与 reciprocal zeta 响应完全分离。

## 3. 能量界的解析延拓

假设对每个 \(\varepsilon>0\)，
\[
E_P(Y):=\sum_{k\le Y}k|H_P(k)|^2
\ll_{\varepsilon,P}Y^{1+\varepsilon}.
\tag{3}
\]
在 \(Y<k\le2Y\) 上，
\[
|w_k(z)-w_{k-1}(z)|\ll_{z}k^{-\Re z-1}.
\]
Cauchy--Schwarz 给出
\[
\sum_{Y<k\le2Y}|H_P(k)|\,|w_k-w_{k-1}|
\ll_{\varepsilon,z,P}
Y^{-\Re z-\frac12+\frac{\varepsilon}{2}}.
\tag{4}
\]
故 \(\mathcal F_P\) 在 \(\Re z>-1/2\) 全纯，(2) 在该半平面给出解析
延拓。

因此，若存在 \(\zeta(\rho)=0\)、\(\Re\rho>1/2\)，且
\[
P(2^{-\rho})\ne0,
\tag{5}
\]
则 \(z=\rho-1\) 是右侧的极点，与 (3) 矛盾。

## 4. 统一判据

若 \(P\) 满足
\[
P(2^{-\rho})\ne0
\quad\text{对所有 }1/2<\Re\rho<1,
\tag{6}
\]
则其尾能量界 (3) 严格推出 RH。对 \(P(z)=1-2z\)，唯一根为
\(z=1/2\)，而 \(2^{-\rho}=1/2\) 只可能有 \(\Re\rho=1\)，故 (6) 自动成立。

更一般地，若单个 \(P\) 在临界带有有限个变换根，则取有限个多项式
\(P_1,\ldots,P_r\)，只要它们的变换根集合在
\(\{2^{-\rho}:1/2<\Re\rho<1\}\) 上无公共点，所有对应的能量界仍联合
推出 RH。

## 结论

有限尺度滤波器的真正逃逸条件不是简单地令 \(P(1/2)=0\)，而是让
\(P(2^{-\rho})\) 在潜在离线零点处消失。除非发生这种精确频率消除，
自然的 \(Y^{1+\varepsilon}\) 尾能量仍是 RH-equivalent 算术命题。

