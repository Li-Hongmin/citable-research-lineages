> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Centered RH 核具有增长正惯性与无限 cusp

日期：2026-08-14。

依赖：
[note 118](118-an-endpoint-flat-detector-gives-an-exact-positive-reciprocal-product-rh-gate.md)、
[note 119](119-the-positive-reciprocal-product-rh-kernel-is-uniformly-indefinite.md)。

证据等级：精确 \(2\times2\) 块、primorial 主子式惯性及整数点导数跳跃。

note 118 将正 reciprocal-product 核的首个 Bernoulli mean 分离为
\(1/(6y)\)。本文减去该 Mellin rank-one，检查剩余 centered 核。
结果是：centered 核仍有尺度不衰减的双侧谱；沿 primorial 子序列其
正惯性至少为 \(\gg\log x/\log\log x\)；任何保持 Mellin--Hankel
结构的固定有限指数 deflation 都不能使连续核单侧化。

## 1. Centered 核

沿用 note 118 的

\[
P(y)=
\frac{\lfloor y\rfloor(\lfloor y\rfloor+1)}{y^3}
\{y\}(1-\{y\}),
\tag{1}
\]

定义

\[
C(y)=P(y)-\frac1{6y},
\qquad
C_x(a,b)=C\left(\frac{x}{ab}\right).
\tag{2}
\]

在 Möbius 二次型中，被减去的恰是

\[
\frac1{6x}\left(\sum_{a\le\sqrt x}a\mu(a)\right)^2.
\tag{3}
\]

## 2. Rank-one centering 后仍统一不定

取

\[
x=9k^2,\qquad a=3k,\qquad b=2k.
\tag{4}
\]

由

\[
C(1)=-\frac16,\qquad
C(3/2)=\frac1{27},\qquad
C(9/4)=\frac2{81},
\tag{5}
\]

对应主子式恒为

\[
\boxed{
\begin{pmatrix}
-1/6&1/27\\
1/27&2/81
\end{pmatrix}.}
\tag{6}
\]

其行列式为

\[
\boxed{-\frac4{729}<0,}
\tag{7}
\]

两个特征值为

\[
\boxed{
\lambda_\pm=\frac{-23\pm\sqrt{1105}}{324}.}
\tag{8}
\]

所以 centered 核对所有 \(k\ge1\) 都同时含有大小不随尺度衰减的
正、负方向。减去 (3) 没有产生 PSD 或 NSD 核。

## 3. Primorial 主子式

令

\[
x=p_1p_2\cdots p_m
\tag{9}
\]

为前 \(m\) 个素数的 primorial。对充分大的 \(m\)，以下指标均不超过
\(\sqrt x\)：

\[
a_i=p_i,\qquad1\le i\le m.
\tag{10}
\]

当 \(i\ne j\) 时，

\[
\frac{x}{p_ip_j}\in\mathbb N,
\tag{11}
\]

故

\[
P\left(\frac{x}{p_ip_j}\right)=0.
\tag{12}
\]

另一方面，

\[
y_i=\frac{x}{p_i^2}\notin\mathbb N,
\qquad P(y_i)>0.
\tag{13}
\]

因此该主子式精确为

\[
\boxed{
C^{(m)}=D-\frac1{6x}pp^*,}
\tag{14}
\]

其中

\[
D=\operatorname{diag}(P(y_1),\ldots,P(y_m))>0,
\qquad
p=(p_1,\ldots,p_m)^T.
\tag{15}
\]

正对角矩阵减秩一矩阵至多损失一个正特征值，所以

\[
n_+(C^{(m)})\ge m-1.
\tag{16}
\]

事实上它恰有一个负特征值。由
\(\{y\}(1-\{y\})\le1/4\)，

\[
\frac{p_i^2/(6x)}{P(y_i)}
=\frac{1/(6y_i)}{P(y_i)}
\ge\frac23+o(1).
\tag{17}
\]

故对充分大的 \(m\)，

\[
\frac1{6x}p^*D^{-1}p>1.
\tag{18}
\]

秩一更新的惯性公式于是给出

\[
\boxed{(n_+,n_-)=(m-1,1).}
\tag{19}
\]

由 primorial 渐近

\[
\log x=(1+o(1))m\log m,
\tag{20}
\]

得到沿该无限子序列

\[
\boxed{
n_+(C_x)\gg\frac{\log x}{\log\log x}.}
\tag{21}
\]

这个构造没有证明 \(n_-(C_x)\to\infty\)：所有负性可能被 (14)
中的共同 rank-one 方向吸收。有限数值中约一半特征值为负，不能据此
外推为一般惯性定理。

## 4. 无限整数 cusp

对整数 \(n\ge2\)，由 (1) 的左右展开，

\[
P'(n+)=\frac{n+1}{n^2},
\qquad
P'(n-)=-\frac{n-1}{n^2}.
\tag{22}
\]

因此

\[
\boxed{P'(n+)-P'(n-)=\frac2n\ne0.}
\tag{23}
\]

减去任意固定有限指数和

\[
R_r(y)=\sum_{\ell=1}^rc_\ell y^{-\lambda_\ell}
\tag{24}
\]

不会改变这些 cusp，因为 \(R_r\) 在 \(y>0\) 上解析。

令

\[
h_r(u)=P(e^u)-R_r(e^u).
\tag{25}
\]

若连续 Hankel 核

\[
h_r(s+t)
\tag{26}
\]

在一个包含任意大 \(u\) 的开区间上 PSD，则 Bernstein--Widder
指数凸表示使 \(h_r\) 在区间内部成为双边 Laplace 变换，因而实解析。
NSD 情形对 \(-h_r\) 同理。这与 \(u=\log n\) 处无限多个非零 cusp
矛盾。

所以：

\[
\boxed{
\text{任何固定有限个 Mellin powers 都不能使连续核最终 PSD 或 NSD}.}
\tag{27}
\]

这里必须保留“保持 Mellin--Hankel 结构”的限定。若允许完全任意的
有限秩项
\(\sum_{\ell=1}^rf_\ell(a)g_\ell(b)\)，则 cusp 论证不足；要排除那种
最宽 deflation，仍需证明正、负惯性指标都无界。

## 5. 结论

自然 centering 后的严格边界为

\[
\begin{array}{c|c}
\text{性质}&\text{已证结论}\\ \hline
\text{单侧谱}&\text{失败，存在统一 }2\times2\text{ 双侧块}\\
\text{正惯性}&\gg\log x/\log\log x\text{ 沿 primorial}\\
\text{负惯性}&\ge1,\text{ 是否增长未知}\\
\text{固定 Mellin-power deflation}&\text{被无限 cusp 排除}
\end{array}
\tag{28}
\]

因此下一项决定性问题已经压成：构造彼此独立的负方向，或证明负谱
实际上由有限个算术 mode 承担。只有这个惯性分类能判断一般有限秩
deflation 是否仍可能。这是谱结构定理与明确剩余边界，不是 RH 的证明。
