> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# MRT 双移位三角门与 Lehmer 核的完成缺口

日期：2026-08-16。

本 note 把 Matomäki--Radziwiłł--Tao 的双移位平均定理具体化到
Lehmer 型 Möbius 二次型的一个可审计子块。结果不是 RH 证明；它给出一个
真实的对数级加权门，并精确定位从该门到完整
\(\min(m,n)/\max(m,n)\) 核仍缺的 completion。

## 1. 可用的双移位平均

MRT 的 Theorem 1.6（取其式 (1.10)，\(k=2\)）允许
\(g_1,g_2\) 为 \(1\)-bounded 函数，只要求其中一个是乘法函数。对
\(10\le H\le Y\)、\(a_i\le A\)、\(b_i\ll_A Y\)，有
\[
 \sum_{1\le r,s\le H}
 \left|\sum_{1\le n\le Y}
 g_1(a_1n+b_1+r)g_2(a_2n+b_2+s)\right|
 \ll_A YH^2\rho(Y,H),
\tag{1}
\]
其中
\[
 \rho(Y,H)=\frac{\log\log H}{\log H}+\frac1{\log^{1/3000}Y}
\]
（对 \(\mu\) 的版本由原文第 1.1 节末明确说明）。来源：
<https://arxiv.org/html/1503.05121>，Theorem 1.6。

## 2. 精确三角权恒等式

固定整数 \(Y\le b\le A_0Y\)、\(Y\ge H\ge10\)，并取一个任意的
\(1\)-bounded 截止函数 \(\chi\)（它只依赖第二个整数变量）。定义
并约定
\(\beta_b(q)=\min(1,b/q)\chi(q)\)，这是全体正整数上的
\(1\)-bounded 函数；在下式实际出现的 \(q>b\) 区域它等于
\((b/q)\chi(q)\)。
\[
\begin{aligned}
 T^{(0)}&=\frac1H\sum_{r,s=1}^H\sum_{n=1}^Y
 \mu(b+n+r)\,\mu(b+n+H+s)\,\chi(b+n+H+s),\\
 T^{(1)}&=\frac1H\sum_{r,s=1}^H\frac{H+s-r}{b}
 \sum_{n=1}^Y\mu(b+n+r)\,
 \mu(b+n+H+s)\beta_b(b+n+H+s).
\end{aligned}
\tag{2}
\]
第二个函数在 \(T^{(0)}\) 中是 \(\mu\chi\)，在 \(T^{(1)}\) 中是
\(\mu\beta_b\)，均为 \(1\)-bounded；第一个函数是乘法函数
\(\mu\)，所以 (1) 适用。

令
\[
 \omega_{b,Y,H}(m,q)=\frac1H\#\{(r,s,n):
 1\le r,s\le H,\ 1\le n\le Y,\
 m=b+n+r,\ q=b+n+H+s\}.
\tag{3}
\]
则有限重排给出精确恒等式
\[
 \boxed{
 T^{(0)}-T^{(1)}=
 \sum_{m,q}\mu(m)\mu(q)\frac mq\,
 \chi(q)\,\omega_{b,Y,H}(m,q).}
\tag{4}
\]
因为 \(q-m=H+s-r\)，式 (4) 只是
\(m/q=1-(q-m)/q\) 的逐项代入，没有近似或极限。

在内区
\[
 b+H+1\le m\le b+Y+1,
 \qquad 1\le q-m\le2H-1,
\]
权重完全显式为
\[
 \omega_{b,Y,H}(m,q)
 =\left(1-\frac{|q-m-H|}{H}\right)_+.
\tag{5}
\]
区间边界仍由 (3) 精确记录，不应被当作零。

## 3. 由 MRT 得到的对数级加权门

对 (2) 应用 (1)。在 \(q\ge b+H+2\) 时
\(0<b/q\le1\)，且 \(0\le(H+s-r)/b\le2H/b\le2\)。因此
\[
 |T^{(0)}|+|T^{(1)}|
 \ll_A YH\rho(Y,H),
\]
从而
\[
 \boxed{
 \left|\sum_{m,q}\mu(m)\mu(q)\frac mq\,
 \chi(q)\,\omega_{b,Y,H}(m,q)\right|
 \ll_A YH\rho(Y,H).}
\tag{6}
\]
这是真正带有 \(m/q\) 比值权的 signed 相关估计，而不是把权逐项取绝对值。
它在 \(H\asymp Y\) 时给 \(Y^2\rho(Y,Y)=Y^{2-o(1)}\) 的对数节省。

## 4. 为什么这还不是 Lehmer 能量估计

完整同尺度 Lehmer 块需要控制
\[
 \sum_{b<m<q\le2b}\mu(m)\mu(q)\frac mq
\tag{7}
\]
及其所有 dyadic 比值块。式 (6) 只控制卷积产生的三角权
\(\omega_{b,Y,H}\)，并且有以下两个未解决接口：

1. 需要把 (7) 的差值指示函数和所有 \(m\)-边界，写成三角权的线性组合，且组合系数的总变差至少要保持在可吸收的对数范围内；
2. 不同比值尺度的块共享同一端点，完成这些边界时会重新出现移动的
   \(m\)-依赖权，不能只对每个 \(H\) 独立取绝对值。

因此 (6) 不能被外推成
\(\boldsymbol\mu^T(L_N-v_Nv_N^T)\boldsymbol\mu\ll N^{1+\varepsilon}\)。
它给出的最小新事实是：MRT 的双移位平均确实能承载一个精确的
Lehmer 比值子核；剩余缺口是一个跨三角权的 signed completion，而不是
“文献定理完全没有作用”。

## 5. 有限精确核验

脚本
`computations/verify_mrt_triangle_weight_identity.py`
逐项枚举了 \((b,Y,H)=(10,8,3),(0,5,2)\) 的全部三元组，并验证：在
内区 (5) 的每个 \((m,q)\) 上，出现次数恰为
\(H-|q-m-H|\)。该检查只验证代数恒等式，不把 MRT 的渐近估计数值化。
