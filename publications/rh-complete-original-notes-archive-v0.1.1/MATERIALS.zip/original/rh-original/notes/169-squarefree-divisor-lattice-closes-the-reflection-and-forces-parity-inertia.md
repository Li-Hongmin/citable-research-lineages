> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Squarefree divisor 格点闭合反射并强制成对惯性

日期：2026-08-15。

本 note 给出 reciprocal Hankel/reflection 与真实 Möbius divisor 子空间的一个严格有限
intertwiner。它比一般正整数采样更干净：当 \(X\) squarefree 时，\(a\mapsto X/a\)
在 \(D(X)=\{a:a\mid X\}\) 上闭合，而且 Möbius 向量本身是这个反射的特征向量。
代价是反射 Gram 天生具有大规模负惯性；因此不能把这个闭合识别误读为普通 PSD
Gram 化。

## 1. 有限 divisor 反射恒等式

先注意：以下 \(H=GR\) 与惯性分解只需 \(X\) 不是平方；令 \(X\) 为 squarefree
则还可得到后面的 Möbius 特征向量。设 \(D=D(X)\)，并令 \(p:\mathbb R\to\mathbb R\) 为
偶函数，其 Fourier 变换 \(\widehat p\in L^1(\mathbb R)\) 满足 \(\widehat p\ge0\)，且 \(\widehat p>0\) 在某个正测度
区间上。定义两个 \(D\times D\) 矩阵

\[
 G_{a,b}=p\!\left(\log\frac ab\right),
 \qquad
 H_{a,b}=p\!\left(\log\frac X{ab}\right).
\]

令 \(R\) 为 divisor-complement permutation，
\[
 R_{a,b}=\mathbf 1_{ab=X}.
\]
由偶性及 \(D\) 对 \(a\mapsto X/a\) 闭合，逐项有
\[
 H=GR=RG.
\tag{1}
\]
确切地，
\[
 (GR)_{a,b}=G_{a,X/b}=p\!\left(\log\frac{ab}{X}\right)
 =p\!\left(\log\frac X{ab}\right).
\]

若采用连续 Fourier 向量
\(\phi_a(\xi)=(a/\sqrt X)^{i\xi}\)，则 \(R\phi_a=\phi_{X/a}\)，而
\(G\) 是 \(M_{\widehat p}\) 下的 ordinary Fourier Gram；(1) 正是
\(H=GR\) 的有限算术版本：
\[
 \sum_{a,b\mid X}c_ac_b\,p\!\left(\log\frac X{ab}\right)
 =\langle\Phi_c,M_{\widehat p}J\Phi_c\rangle,
 \qquad \Phi_c=\sum_{a\mid X}c_a\phi_a.
\tag{2}
\]
式 (2) 对实系数 \(c_a\) 直接成立；复系数时应将左侧写为相应的双线性配对，
或在矩阵记号中保留 \(c^{*}Hc\) 的共轭约定。

若把 \(T_X:\mathbb C^{D}\to\{\text{有限指数和}\}\) 定义为
\(T_X e_a=\phi_a\)，则上述关系可压缩成真正的 intertwiner 三元组
\[
 J T_X=T_XR,\qquad
 T_X^{*}M_{\widehat p}T_X=G,\qquad
 T_X^{*}M_{\widehat p}JT_X=H.
\tag{2'}
\]
这里 \(T_X\) 一般不是等距映射；其 Gram \(G\) 恰好记录了算术 divisor 基底的
非正交性。因而 (2') 是可直接交给 Weil/Feshbach 块的有限接口，但不能把
\(T_X\) 当作普通 unitary 而删除 \(R/J\) 的符号。

## 2. 精确惯性与 Möbius 模式

当 \(X\) 不是平方时，\(R^2=I\) 没有固定点。因此
\[
 \dim E_+(R)=\dim E_-(R)=2^{\omega(X)-1}.
\tag{3}
\]
条件 \(\widehat p>0\) 在正测度集上使 \(G\) 严格正定：若 \(c^*Gc=0\)，则
有限指数和 \(\sum_{a\mid X}c_a a^{i\xi}\) 在一个区间上恒为零，解析性迫使
所有 \(c_a=0\)。由于 \(G\) 与 \(R\) 对易，(1) 在 \(R=\pm1\) 子空间上分别为
\(H=+G\) 与 \(H=-G\)。故
\[
 \boxed{\operatorname{inertia}(H)=
 \bigl(2^{\omega(X)-1},\,2^{\omega(X)-1},\,0\bigr).}
\tag{4}
\]

特别地，Möbius divisor 向量
\[
 c_a=\mu(a)\mathbf 1_{a\mid X}
\]
满足
\[
 \mu(X/a)=\mu(X)\mu(a),
 \qquad R c=\mu(X)c,
\tag{5}
\]
从而其 reciprocal 二次型精确简化为
\[
 \sum_{a,b\mid X}\mu(a)\mu(b)
 p\!\left(\log\frac X{ab}\right)
 =\mu(X)\,c^*Gc.
\tag{6}
\]
若 \(\widehat p\ge0\)，右侧的符号由 \(\mu(X)=(-1)^{\omega(X)}\) 决定；这不是
普通 PSD 结论，而是 Weil 型反射符号。式 (6) 只对完整 divisor lattice 成立；把
支撑截成 \(a\le\sqrt X\) 或任意非反射闭合集合后，(5) 立即失效。

在 Fourier 坐标中，同一个特征向量可写成显式 Euler 乘积
\[
 \Phi_X(\xi)=\sum_{a\mid X}\mu(a)(a/\sqrt X)^{i\xi}
 =X^{-i\xi/2}\prod_{p\mid X}(1-p^{i\xi}).
\tag{7}
\]
逐项反射直接给出
\[
 \Phi_X(-\xi)=(-1)^{\omega(X)}\Phi_X(\xi)=\mu(X)\Phi_X(\xi),
\tag{8}
\]
这是 (5) 的 Fourier 版本：Möbius divisor mode 并非一般向量，而是一个确定
parity 的反射 mode。因而任何试图用 ordinary modulus-square 取代 reciprocal
二次型的步骤，都会把这个 \(\mu(X)\) parity sign 丢掉。

## 3. 对固定秩正化的严格下界

在 (4) 的假设下，任意 Hermitian 修正 \(F\) 若令 \(H+F\succeq0\)，惯性扰动给出
\[
 \operatorname{rank}F\ge n_-(H)=2^{\omega(X)-1}.
\tag{9}
\]
因此沿 squarefree primorial \(X_k=\prod_{j\le k}p_j\)，任何保持 reciprocal
Hankel 核而试图用固定 rank-one/rank-\(r\) Feshbach 或普通 PSD Gram 修正的方案，
都被严格排除；所需修正秩至少 \(2^{k-1}\)。这比只在一条 prime star 上得到的
线性负惯性下界更强，但它针对的是完整 divisor 格点与正 Fourier symbol 的
理想化 detector。

## 4. 最小桥接式及其边界

因此真实 Möbius/Weil 子空间上的最薄闭合识别是
\[
 \boxed{\text{divisor complement }R_X\quad\leftrightarrow\quad
 \text{log-Fourier reflection }J,\qquad H=G R_X.}
\]
它同时揭示两个边界：

1. 反射闭合要求 \(a\mid X\)，不能直接替代原 detector 的全整数尺度壳；
2. 即使闭合，结果是 \(J\)-signed (Krein) 型而非 PSD，且负惯性随
\(\omega(X)\) 增长。

要从该有限格点走向 RH，仍需一个把全整数/common-scale 壳映到这些 divisor
格点、并控制截断边界误差的 signed intertwiner。本文只给出闭合 divisor 子空间
中的精确恒等式与 no-go，不声称 RH 已被证明。

## 5. 一个直接的符号 corollary

若 \(p\not\equiv0\) 且 \(\widehat p\ge0\)，则对每个 squarefree \(X\) 都有
\(c^*Gc>0\)。因此 (6) 随 \(\omega(X)\) 奇偶交替变号：奇数个 prime 因子时严格
为负，偶数个时严格为正。于是不存在一个非零、偶、正定的 log-kernel \(p\)，使
\[
 \sum_{a,b\mid X}\mu(a)\mu(b)\,p\!\left(\log\frac X{ab}\right)\ge0
\]
对所有 squarefree \(X\) 同时成立。任何声称把此 reciprocal 门直接改写成 ordinary
PSD Gram 并保留全部 Möbius divisor 模式的证明，必然在这里丢掉了
\(\mu(X)\) 的反射 parity，或已偷偷改变了 detector。

补充：若一个实值平移核 \(p(\log(a/b))\) 真能对所有有限尺度集产生 PSD Gram，
则 Bochner 正定性本身迫使 \(p(-t)=p(t)\)。所以“先用非偶 \(p\) 规避上述奇偶
障碍、再声称普通 PSD”并不是合法绕路；非偶选择会先失去 Hermitian/PSD Gram
结构。
