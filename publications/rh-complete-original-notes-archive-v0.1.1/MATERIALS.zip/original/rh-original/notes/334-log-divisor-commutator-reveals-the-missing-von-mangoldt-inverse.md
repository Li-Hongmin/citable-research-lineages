> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 对数--除数交换子与缺失的 von Mangoldt 反演

日期：2026-08-16。

本 note 给出一个把 periodization 算子与 Weil 素数项连接起来的精确
算术恒等式。它同时说明：交换子本身只产生 \(-K\zeta'\)，而真正的
von Mangoldt/Weil 通道是 \(-K\zeta'/\zeta\)，所以仍必须支付一次
除数逆 \(D^{-1}\)。

## 1. 除数算子与对数交换子

令
\[
 (Dx)(n)=\sum_{d\mid n}x(d),\qquad
 (Lx)(n)=(\log n)x(n).
\]
在有限截断上直接计算：
\[
 \begin{aligned}
 ([L,D]x)(n)
 &=\sum_{d\mid n}\bigl(\log n-\log d\bigr)x(d)\\
 &=\sum_{d\mid n}\log(n/d)x(d)
 = (C_{\log}x)(n),
 \end{aligned}
\tag{1}
\]
其中 \(C_f\) 表示 Dirichlet 卷积算子。由于
\[
 \log n=\sum_{d\mid n}\Lambda(d)=(\mathbf1*\Lambda)(n),
\]
得到精确恒等式
\[
 \boxed{[L,D]=C_{\log}=D\,C_\Lambda=C_\Lambda D.}
\tag{2}
\]
因此
\[
 C_\Lambda=D^{-1}[L,D].
\tag{3}
\]
这就是系数层面的 \(-\zeta'/\zeta\) 分解。

## 2. 与 causal detector 的交换子

令 \(A_V\) 为 ratio-causal detector 算子，
\[
 (A_Vx)(a)=\sum_{d\le a}x(d)V(d/a),
\]
并令 \(B_V=A_VD\) 为 periodization 算子。对任意有限矩阵恒等有
\[
 [L,B_V]-[L,A_V]D=A_V[L,D]
 =A_VD\,C_\Lambda
 =B_VC_\Lambda.
\tag{4}
\]
因此交换子确实引入了 \(\Lambda\)，但它作用在 \(B_V\) 上时仍保留了一个
右侧 \(D\)。

若要得到真正的 Weil/prime 通道，不能简单地只左乘 \(D^{-1}\)，因为
\(A_V\) 与 \(D\) 一般不交换。精确地，
\[
 \boxed{
 D^{-1}\bigl([L,B_V]-[L,A_V]D\bigr)
 =D^{-1}A_VD\,C_\Lambda
 =\bigl(A_V+D^{-1}[A_V,D]\bigr)C_\Lambda.
 }
\tag{5}
\]
因此恢复 \(A_VC_\Lambda\) 还必须同时消除
\(D^{-1}[A_V,D]C_\Lambda\)。已有 note 235 证明 \([A_V,D]\) 在自然
截断上的秩随 \(N\) 增长；note 335 更进一步证明没有非零连续 \(V\)
能使该交换子恒等为零。它不是可忽略的固定边界项。式 (5) 在有限
截断中完全成立，所有逆均指相应的下三角逆。

## 3. Mellin 端的零点差别

在忽略有限截断边界、采用理想化 Mellin 乘法模型时，\(D\) 的乘子为
\(\zeta(s)\)，\(L\) 为 \(-\partial_s\)，而 \(A_V\) 的乘子为
\(K_V(s)\)。于是
\[
 \mathcal M\bigl(B_VC_\Lambda\bigr)
 =-K_V(s)\zeta'(s),
\tag{6}
\]
理想化的 prime detector 则为
\[
 \mathcal M\bigl(A_VC_\Lambda\bigr)
 =-K_V(s)\frac{\zeta'(s)}{\zeta(s)}.
\tag{7}
\]
在 zeta 零点 \(\rho\) 处，(6) 通常是正则的，而 (7) 保留
\(\zeta'/\zeta\) 的极点。有限截断中还要支付式 (5) 的 growing-rank
commutator；故直接对 \(B_V\) 做正 Gram、交换子或 periodization 坍缩，
会把 RH 的零点信号精确消去，恢复它必须同时处理 \(D^{-1}\) 与
\([A_V,D]\)。

## 4. 对 RH 路线的裁决

式 (2)--(7) 提供了一个真实的 arithmetic intertwiner 候选，但其最薄
缺口被完全定位：

1. periodization 与对数交换子可无条件构造，并得到 \(-K\zeta'\)；
2. 理想化 Weil 所需的 \(-K\zeta'/\zeta\) 需要除数逆；
3. 有限截断还出现 \(D^{-1}[A_V,D]C_\Lambda\)，而
   \([A_V,D]\) 具有 growing rank；
4. 在临界线权重下，\(D^{-1}\) 至少支付 note 333 的
   \(\sqrt{\log N}\) 第一列代价；若要 uniform \(N^{1/2+\varepsilon}\)
   级控制，则仍需 Möbius signed cancellation。

因此该交换子恒等式不是 RH 证明，但比“正 periodization 可能自动产生
素数项”的说法更精确：它说明素数算术确实出现，却在可控制的通道中
丢掉了 zeta 零点；缺失的恰是一个保留 \(\zeta^{-1}\) 的 signed
arithmetic intertwiner。
