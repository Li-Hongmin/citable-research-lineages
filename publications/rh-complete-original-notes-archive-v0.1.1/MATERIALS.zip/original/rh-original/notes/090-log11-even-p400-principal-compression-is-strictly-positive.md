> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(\frac12\log11\) 处 even \(P_{400}\) 主压缩严格正定

日期：2026-08-14。

本 note 沿用 [note 089](089-strict-local-weil-positivity-to-log201over20-half.md) 的局部 Weil
归一化、active-prime 块和 full-space Yukawa 分解，但判断的是一个不同的、严格有限维的 \(a_{11}\)
主压缩。

## 命题

令 \(a_{11}=\frac12\log11\)，而 \(P_{400}^+\) 是 \((-a_{11},a_{11})\) even cosine
Fourier 空间前 \(400\) 个坐标上的正交投影。则

\[
\boxed{P_{400}^+A_{a_{11}}^+P_{400}^+>0.}
\tag{1}

因此不存在支撑在这个固定 \(400\)-维子空间内的负 even Weil 向量。

这不推出 \(A_{a_{11}}^+\succeq0\)，不涉及 odd 扇区，也不推出 RH。

## 证明

令 \(L_0^+\) 是含完整 active-prime/reflection 块、前 \(500\) 个 Yukawa atoms 和正 polar
的 even 基准算子，令

\[
U=(u_{500},\ldots,u_{563}).
\]

设 \(H_1,\ldots,H_7\) 是权威 \(R=280,N=500\) graph 的 Householder reflections，并令

\[
Q=H_1\cdots H_7.
\]

它们作用于前 \(280\) 个坐标，对余下 \(120\) 个坐标为恒等。由
[`export_log10_even_yukawa_family_parseval_data.py`](../computations/bundles/log201over20-local-weil-positivity/sources/export_log10_even_yukawa_family_parseval_data.py)
的定义，`b` 是物理坐标的 \(P_{400}U\)。由 safe-base 生成式及同一 \(Q\) 的缓存合同，

\[
S=Q^T\left(P_{400}L_0^+P_{400}-\frac{R_{\rm cov}}\mu\right)Q,
\qquad
R=Q^TR_{\rm cov}Q,
\qquad
\mu=t_{400}>0.
\tag{2}
\]

故认证器的矩阵满足精确的有限维恒等式

\[
\begin{aligned}
M
&=S+\frac R\mu+(Q^TP_{400}U)(Q^TP_{400}U)^T\\
&=Q^TP_{400}(L_0^++UU^T)P_{400}Q.
\end{aligned}
\tag{3}

按 \(7\oplus393\) 分块 \(M=\begin{psmallmatrix}A&B^T\\B&C\end{psmallmatrix}\)。
在 256-bit Arb 上，以 dyadic Cholesky factor \(L\) 选择的 interval residual 给出

\[
C-10^{-11}I=LL^T+E,
\qquad
\|E\|_\infty
\le3.2367025521961987\ldots\times10^{-15},
\tag{4}
\]

从而

\[
C\succeq9.9967632974478\ldots\times10^{-12}I>0.
\tag{5}

verified solve 形成 \(A-B^TC^{-1}B\)。其对称选主元排列

\[
(6,2,3,4,5,1,0)
\]

下的 pivots 为

\[
\begin{aligned}
&4.744335606780749\ldots\times10^{-14},\\
&1.359924874627920\ldots\times10^{-18},\\
&1.098726808705109\ldots\times10^{-23},\\
&6.243381808668003\ldots\times10^{-29},\\
&3.681007093068927\ldots\times10^{-35},\\
&1.752959847566464\ldots\times10^{-41},\\
&[1.6282644075998989764\pm7.99\cdot10^{-20}]\times10^{-48}>0.
\end{aligned}
\tag{6}

故 Schur complement 严格正，连同 (5) 得 \(M>0\)。由 (3) 和 \(Q^TQ=I\)，

\[
P_{400}(L_0^++UU^T)P_{400}>0.
\tag{7}

余下 full-space Yukawa atoms 的每项主压缩皆正半定。因此

\[
P_{400}A_{a_{11}}^+P_{400}
\succeq P_{400}(L_0^++UU^T)P_{400}>0,
\]

即得 (1)。

## 边界

此前的假设性 \(\mu=10^6\) scalar-complement core 仅用于选取候选向量；它不在 (2)--(7)
中，因而不承载任何谱符号结论。本结果关闭的是“固定 even \(P_{400}\) 内找 \(a_{11}\) 负见证”
这一路线；并未排除负方向逃逸到 \(P_{400}^\perp\)。

完整冻结输出、源码和重放入口见
[`log11-even-p400-principal-positivity`](../computations/bundles/log11-even-p400-principal-positivity/README.md)。
