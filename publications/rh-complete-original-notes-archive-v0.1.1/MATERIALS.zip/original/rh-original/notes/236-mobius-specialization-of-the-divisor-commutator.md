> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 除数交换子在 Möbius 向量上的稀疏 prime-lift 展开

日期：2026-08-17。

本 note 把 note 235 的交换子 \(C_V=[A_V,D]\) 直接作用到 Möbius
向量上，得到一个显式的稀疏 prime-lift 展开。它不提供 RH 证明，
但把后续 signed 估计的算术对象进一步压缩到了明确支持集。

## 1. 从非因子和到单变量系数

有限截断上
\[
 C_V(a,b)=\sum_{\substack{1\le c\le a/b\\c\nmid a}}V(cb/a).
\]
因此
\[
 (C_V\mu)(a)
 =\sum_{b\le a}\mu(b)\sum_{\substack{c\le a/b\\c\nmid a}}V(bc/a).
\]
令 \(n=bc\)，得到
\[
 (C_V\mu)(a)
 =\sum_{n\le a}V(n/a)
 \sum_{\substack{c\mid n\\c\nmid a}}\mu(n/c).
\tag{1}
\]

定义
\[
 h_a(n):=\sum_{c\mid\gcd(a,n)}\mu(n/c).
\tag{2}
\]
利用 \(\sum_{c\mid n}\mu(n/c)=\mathbf1_{n=1}\)，并注意 \(h_a(1)=1\)，可得
\[
 \boxed{
 (C_V\mu)(a)=-\sum_{2\le n\le a}h_a(n)V(n/a).
 }
\tag{3}
\]

## 2. \(h_a\) 的局部化

写 \(\alpha_p=v_p(a)\)、\(\beta_p=v_p(n)\)。式 (2) 是乘性的，其
\(p\)-局部因子为
\[
 h_{a,p}(p^\beta)
 =\sum_{j=0}^{\min(\alpha_p,\beta)}
 \mu\!\left(p^{\beta-j}\right).
\]
直接枚举 \(\mu(p^r)\) 得
\[
 h_{a,p}(p^\beta)=
\begin{cases}
 1,&\beta=0,\\
 -1,&\beta=\alpha_p+1,\\
 0,&\text{其他情形}.
\end{cases}
\tag{4}
\]

令 \(m\) 为平方自由数，并定义
\[
 n_a(m):=m\prod_{p\mid m}p^{v_p(a)}.
\tag{5}
\]
则
\[
 h_a(n)=
\begin{cases}
 \mu(m),& n=n_a(m)\ \text{对某个平方自由 }m,\\
 0,&\text{否则}.
\end{cases}
\tag{6}
\]
所以
\[
 \boxed{
 (C_V\mu)(a)
 =-\!\!\sum_{\substack{m\ge2,\ m\ {\rm squarefree}\\ n_a(m)\le a}}
 \mu(m)\,V\!\left(\frac{n_a(m)}a\right).
 }
\tag{7}
\]

## 3. 与 \(D^{-1}\) 的组合

结合 \(A_V\mu=D^{-1}A_Ve_1-D^{-1}C_V\mu\)，式 (7) 给出
\[
 \boxed{
 (D^{-1}C_V\mu)(a)
 =-\sum_{d\mid a}\mu(a/d)
 \!\!\sum_{\substack{m\ge2,\ m\ {\rm squarefree}\\ n_d(m)\le d}}
 \mu(m)V\!\left(\frac{n_d(m)}d\right).
 }
\tag{8}
\]
这是有限三角矩阵中的精确恒等式，没有连续化或未说明的交换极限。

## 4. 对 RH 算术门的含义

式 (7)--(8) 说明交换子残差不是任意二维非因子误差，而是由
\(n_a(m)\) 支持的稀疏 prime-lift 通道组成；因此可尝试对平方自由
\(m\) 作 signed 分组。

但稀疏性本身不产生平方根估计。对 \(a=p\) 为素数时，式 (7) 已退化为
大量 \(m\le p\) 的 Möbius 加权和。若要把式 (8) 在临界权重下压到
\(N^{1/2+\varepsilon}\)，仍需新的 Möbius correlation/intertwiner，
不能由局部乘法结构或普通绝对值估计推出。

因此 (7)--(8) 是把“因果 periodization 与 Möbius 符号如何失配”具体化
的严格接口，而不是 RH 证明。下一步最小目标是研究它在 note 235 的
稳定几何子块上是否存在带实际 \(\mu\) 权的 dual functional。

## 5. 素数切片的精确校准

若 \(a=p\) 是素数，则 \(m\) 若含 \(p\)，有
\(n_p(m)\ge p^2>p\)；所以 (7) 中只留下 \(2\le m<p\) 的平方自由项。
由于 \(V(1)=0\)，得到精确恒等式
\[
 \boxed{
 ([A_V,D]\mu)(p)
 =V(1/p)-(A_V\mu)(p).
 }
\tag{9}
\]
同时 \(C_V(1)=0\)，故
\[
 (D^{-1}C_V\mu)(p)=([A_V,D]\mu)(p).
\tag{10}
\]
因此 prime-lift 残差在素数切片上并没有把原始 Möbius detector 变成
一个更容易的量；它只差一个显式端点项 \(V(1/p)\)。任何声称从该
交换子获得平方根级估计的方案，至少必须在素数切片上重新控制
\((A_V\mu)(p)\)，所以不能把该路线当作低于 RH 难度的黑箱。
