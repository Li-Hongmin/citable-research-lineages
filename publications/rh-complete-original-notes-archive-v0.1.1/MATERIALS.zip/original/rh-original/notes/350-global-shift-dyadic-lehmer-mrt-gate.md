> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 按差值 dyadic 分块的全局 Lehmer--MRT 对数门

日期：2026-08-16。

本 note 给出比 note 349 更直接的分块。对
\[
 T_N=\sum_{1\le m<q\le N}\mu(m)\mu(q)\frac mq
\]
按 \(h=q-m\) 做 dyadic 分段，而不是按 \(m,q\) 的尺度分段。对
\(h\asymp H\)，恒等式
\[
 \frac mq=1-\frac hq
 =1-\frac Hq-\frac{h-H}{H}\frac Hq
\]
把所有系数放入 \([0,2]\)，而 \(H/q\) 在该段内是 \(1\)-bounded。
因此 MRT Theorem 1.6 的单移位强化式可以直接控制整个段。

## 1. MRT 输入（量词与误差项）

MRT Theorem 1.6 的式 (1.11) 说：若 \(g_1\) 是 \(1\)-bounded
乘法函数、\(g_2\) 是任意 \(1\)-bounded 函数，且
\(a_i\le A,\ b_i\le AX\)，则
\[
 \sum_{1\le r\le H}
 \left|\sum_{1\le n\le X}
 g_1(a_1n+b_1)g_2(a_2n+b_2+r)\right|
 \ll A^2 XH\rho(X,H),
\tag{1}
\]
\[
 \rho(X,H)=e^{-M/80}+\frac{\log\log H}{\log H}
 +\frac1{\log^{1/3000}X},
 \qquad
 M=M(g_{j_0};10AX,Q),\quad
 Q=\min\{\log^{1/125}X,\log^{20}H\}.
\]
这里的量词是 \(10\le H\le X\)、\(A\ge1\)、\(a_i\le A\)、
\(b_i\le AX\)，并且至少一个 \(g_{j_0}\) 是乘法函数；对 \(\mu\) 的
版本由原文第 1.1 节末说明。原文式 (1.12) 给出
\(M(\mu;X,Q)\ge(1/3-\varepsilon)\log\log X+O(1)\)，故在本应用中
\(e^{-M/80}\ll(\log X)^{-(1/3-\varepsilon)/80}\)；例如取
\(\varepsilon<1/4\)，便有
\((1/3-\varepsilon)/80>1/3000\)，所以该项确实可吸收到
\(\log^{-1/3000}X\) 中。来源：
<https://arxiv.org/html/1503.05121>，Theorem 1.6，式 (1.11)。

## 2. 一个差值 dyadic 段

令 \(N\ge 20\)、\(X=N-1\)，取
\[
 H=2^j,\qquad 10\le H\le N-2,
\]
并令 \(h=H+r\)、\(1\le r\le H\)。令
\[
 m=n+1,\qquad q=n+H+1+r,\qquad 1\le n\le X.
\]
用截断函数
\[
 \chi_N(q)={\bf1}_{q\le N},\qquad
 \beta_{H,N}(q)=\min(1,H/q)\chi_N(q).
\]
则二者均 \(1\)-bounded；在所有非零项上 \(q>H\)，故
\(\beta_{H,N}(q)=H/q\)。定义
\[
 S_0(r)=\sum_{n\le X}\mu(n+1)\mu(q)\chi_N(q),
\]
\[
 S_1(r)=\sum_{n\le X}\mu(n+1)\mu(q)\beta_{H,N}(q).
\]
于是该差值段（暂时省去 \(m=1\)）严格满足
\[
 \sum_{r=1}^{H}\sum_{n\le X}
 \mu(n+1)\mu(q)\frac{n+1}{q}
 =
 \sum_{r=1}^{H}S_0(r)
 -\sum_{r=1}^{H}S_1(r)
 -\sum_{r=1}^{H}\frac rH S_1(r).
\tag{2}
\]
取绝对值并使用 \(0\le r/H\le1\)，得到
\[
 |T_{N,H}|
 \le \sum_{r\le H}|S_0(r)|+2\sum_{r\le H}|S_1(r)|.
\tag{3}
\]

在 (1) 中取 \(a_1=a_2=1\)、\(b_1=1\)、\(b_2=H+1\)、
\(g_1=\mu\)，分别取 \(g_2=\mu\chi_N\) 和
\(g_2=\mu\beta_{H,N}\)。当 \(H\le N-2\) 时 \(b_i\le X\)，
可取 \(A=1\)。因此
\[
 \boxed{|T_{N,H}|\ll N H\rho(N,H).}
\tag{4}
\]
不需要 \(m\)-依赖的 Abel 分部，也不需要最大部分和。

## 3. 求和与边界

将 \(h=1\) 单独处理，再把 \(2\le h\le N-1\) 分为
\(H=1,2,4,\ldots\) 的 dyadic 段（段为 \(H<h\le2H\)，末段由
\(\chi_N\) 自动截断）。\(H<10\) 的有限段用绝对值估计，总计 \(O(N)\)。
对 \(H\ge10\)，由 (4)
\[
 \sum_H |T_{N,H}|
 \ll N\sum_{10\le H\le N-2}^{\rm dyadic}H\rho(N-1,H).
\tag{5}
\]
函数 \(H\mapsto H\log\log H/\log H\) 在 \(H\ge10\) 后可按固定常数
分组比较，故右侧为
\[
 \ll N^2\left(
 \frac{\log\log N}{\log N}
 +\frac1{\log^{1/3000}N}\right).
\tag{6}
\]
缺少 \(m=1\) 的上三角边界只有
\[
 \left|\sum_{q=2}^{N}\frac{\mu(q)}q\right|
 \le \sum_{q\le N}\frac1q=O(\log N),
\]
对角线贡献为 \(O(N)\)。因此
\[
 \boxed{
 \boldsymbol\mu_N^T L_N\boldsymbol\mu_N
 \ll N^2\rho_N+N\log N,}
\qquad
 \rho_N=\frac{\log\log N}{\log N}
 +\frac1{\log^{1/3000}N}.
\tag{7}
\]
由 \(I_N\le\pi\,\boldsymbol\mu_N^TL_N\boldsymbol\mu_N\)，指数尾模型满足
\[
 \boxed{I_N\ll N^2\rho_N+N\log N.}
\tag{8}
\]

## 4. 结论边界

这是比 note 349 的 \(N^2\rho_N^{1/2}\) 更强的无条件对数节省，
但仍然只是 \(N^{2-o(1)}\)。要达到 \(I_N\ll N^{1+\varepsilon}\)，
仍需固定幂次或平方根级的 Möbius 相关估计；note 347 说明该门本身
与 RH 等价。MRT 结果的原始来源仍是上述 Theorem 1.6。

## 5. 当前精确核验

下列三个有限恒等式核验在 2026-08-18 于 OMEN
（\([unbundled local reference])）重新运行并通过：

- computations/verify_global_shift_lehmer_partition.py：差值 dyadic
  分块覆盖不重不漏；
- computations/verify_mrt_dyadic_lehmer_partition.py：窗口参数化与
  比值权分解一致；
- computations/verify_lehmer_abel_weight.py：Abel 转移的端点项与权重
  符号一致。

这些脚本只核对有限代数重排，不加强式 (7)--(8) 的解析估计，也不把
\(N^{2-o(1)}\) 外推为平方根级界。
