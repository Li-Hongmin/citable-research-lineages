> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 平衡物理块的精确缩放与反对角 Möbius 零点

日期与检索截止：2026-08-12。

依赖：[note 066](066-balanced-bernoulli-dedekind-dispersion-hinge.md)。

> 路线修正：本 note 的固定-\(g\) 恒等式与 Euler 分解保持正确；但
> [note 069](069-gcd-completion-cancels-the-fixed-slice-antidiagonal.md)
> 证明完整 gcd 求和逐素数补回 \(+p^{-(s+t)}\)，从而把
> \(1-p^{-s}-p^{-t}\) 重组为 \((1-p^{-s})(1-p^{-t})\)。
> 因此 anti-diagonal no-pinch 只是固定 gcd 切片的过强充分路线，不是完整边界的必要机制。

## 1. 弄清问题

note 066 把主质量压到

\[
d=gb,\qquad e=ga,\qquad (a,b)=1,\qquad a\asymp b.
\tag{1}
\]

本轮只判别两条路线：

\[
\begin{array}{c|c}
\text{路线}&\text{会改变决策的观测}\\
\hline
\text{cotangent}\to\text{Kloosterman Type II}
&\text{现有 BC/DFI 是否达到 }gH^2\\
\text{物理尺度}\to\text{双 Mellin}
&\text{Euler product 是否含额外结构}
\end{array}
\tag{2}
\]

```mermaid
flowchart LR
  A["balanced E(gb,ga;N)"] --> B["exact scaling: g E(b,a;N/g)"]
  B --> C["fixed physical kernel W(a/X,b/X)"]
  C --> D["double Möbius Mellin series"]
  D --> E["1/(ζ(s)ζ(t)ζ(s+t))"]
  E --> F["anti-diagonal zero at s+t=1"]
  A --> G["cotangent finite Fourier"]
  G --> H["variable-product Type II"]
  H --> I["BC black box: H^(31/8), target H^2"]
  I -. "power gap" .-> F
```

## 2. 拟定计划

\[
\begin{array}{c|c}
\text{原子}&\text{操作}\\
\hline
g&\text{完全提出 gcd 与 Selberg taper}\\
E&\text{缩放到 }X=N/g\\
(a,b)&\text{写成固定紧支撑二维核}\\
F_g(s,t)&\text{逐素数分解至不可再分的 zeta 因子}\\
\text{Type II}&\text{保留全部 prefactor 作幂计数}\\
\rho,\bar\rho&\text{比较 }\Re\rho=1/2\text{ 与 }>1/2
\end{array}
\tag{3}
\]

## 3. 实现计划

### 3.1 gcd 完全提出后，边界严格自相似

对任意实数 \(x>0\)，定义

\[
E_{m,n}(x):=
\int_x^{2x}\beta(y/m)\beta(y/n)\,dy
-\frac{x(m,n)^2}{12mn},
\qquad
\beta(u)=\{u\}-\frac12.
\tag{4}
\]

令

\[
X:=\frac Ng,\qquad L:=\log N.
\tag{5}
\]

**定理 1（精确 gcd 缩放）。** 若 \((a,b)=1\)，则

\[
\boxed{
E_{gb,ga}(N)=gE_{b,a}(X).
}
\tag{6}
\]

而且

\[
\boxed{
\lambda_{gb}\lambda_{ga}
=
\mu(a)\mu(b)\mu^2(gab)
\frac{\log(X/a)\log(X/b)}{L^2}.
}
\tag{7}
\]

**证明。** 在积分中置 \(y=gx\)：

\[
\int_N^{2N}\beta(y/gb)\beta(y/ga)\,dy
=g\int_X^{2X}\beta(x/b)\beta(x/a)\,dx.
\tag{8}
\]

又

\[
\frac{N(gb,ga)^2}{12g^2ab}
=\frac{N}{12ab}
=g\frac{X}{12ab}.
\tag{9}
\]

故得 (6)。若 \(\mu(gb)\mu(ga)\ne0\)，则 \(g,a,b\) 两两互素且均无平方因子，

\[
\mu(gb)\mu(ga)=\mu^2(g)\mu(a)\mu(b).
\tag{10}
\]

其余情形由 \(\mu^2(gab)=0\) 同时消失；再用
\(\log(N/gb)=\log(X/b)\)、\(\log(N/ga)=\log(X/a)\)，得 (7)。\(\square\)

这一步同时说明：

\[
\boxed{\text{gcd 变量没有 Möbius 符号；全部符号只在 }a,b.}
\tag{11}
\]

### 3.2 主块是固定二维核，不需要先展开 cotangent

置

\[
u:=\frac aX,\qquad v:=\frac bX,
\tag{12}
\]

\[
\mathscr K(u,v):=
\int_1^2\beta(t/u)\beta(t/v)\,dt.
\tag{13}
\]

由 \(x=Xt\)：

\[
\boxed{
E_{b,a}(X)
=X\mathscr K(u,v)-\frac{1}{12Xuv}.
}
\tag{14}
\]

令 \(I,J\Subset(0,1)\) 为固定 physical blocks，并定义

\[
\phi_I(u):=\mathbf1_I(u)\log(1/u),
\tag{15}
\]

\[
W_{I,J}(u,v):=
\phi_I(u)\phi_J(v)\mathscr K(u,v),
\tag{16}
\]

\[
S_{W,g}(X):=
\sum_{\substack{(a,b)=1\\(ab,g)=1}}
\mu(a)\mu(b)
W(a/X,b/X).
\tag{17}
\]

则平方自由 \(g\) 的该物理块贡献满足

\[
\boxed{
\mathcal C_{g;I,J}(N)
=\frac{gX}{L^2}S_{W,g}(X)
+O_{I,J}\!\left(\frac{gX}{L^2}\right).
}
\tag{18}
\]

误差正是 (14) 的 \(1/(12Xuv)\) 项；逐项取绝对值已足够。

因此一个干净的充分输入是

\[
\boxed{
S_{W,g}(X)\ll_{I,J}X
\qquad\text{uniformly in squarefree }g.
}
\tag{DM}
\]

因为 \(gX=N\)，有限个高物理块在 (DM) 下至多贡献

\[
\frac1{L^2}\sum_{g\ll N}gX^2
\ll
\frac{N^2}{L^2}\sum_{g\ll N}\frac1g
\ll\frac{N^2}{L}
=o(N^2).
\tag{19}
\]

故缺失量不是任意正幂节省，而是把 \(X^2\) 个 Möbius 对压到临界尺度 \(X\)。

### 3.3 双 Mellin 级数含一个被遗漏的反对角因子

先令 \(W\in C_c^\infty((0,\infty)^2)\)，

\[
\widehat W(s,t):=
\int_0^\infty\!\!\int_0^\infty
W(u,v)u^{s-1}v^{t-1}\,du\,dv.
\tag{20}
\]

对 \(\Re s,\Re t>1\)，Mellin 反演给出

\[
\boxed{
S_{W,g}(X)
=\frac1{(2\pi i)^2}
\int_{(c_s)}\int_{(c_t)}
\widehat W(s,t)X^{s+t}F_g(s,t)\,dt\,ds,
}
\tag{21}
\]

\[
F_g(s,t):=
\sum_{\substack{(a,b)=1\\(ab,g)=1}}
\frac{\mu(a)\mu(b)}{a^sb^t}
=\prod_{p\nmid g}(1-p^{-s}-p^{-t}).
\tag{22}
\]

写 \(x=p^{-s},y=p^{-t}\)。第一次提出 zeta 因子：

\[
F_g(s,t)=\frac{\mathcal H_g(s,t)}{\zeta(s)\zeta(t)},
\tag{23}
\]

\[
\mathcal H_p(s,t)=
\frac{1-x-y}{(1-x)(1-y)}
=1-\frac{xy}{(1-x)(1-y)}.
\tag{24}
\]

这里 (24) 对应 \(p\nmid g\)；\(p\mid g\) 只改变有限个局部因子。
\(\mathcal H_g\) 在

\[
\Re s>0,\qquad \Re t>0,\qquad \Re(s+t)>1
\tag{25}
\]

绝对局部一致收敛，但 (25) 的边界仍隐藏一阶结构。再提出一次：

\[
\boxed{
F_g(s,t)
=\frac{\mathcal A_g(s,t)}
{\zeta(s)\zeta(t)\zeta(s+t)}.
}
\tag{26}
\]

对 \(p\nmid g\)，

\[
\mathcal A_{g,p}(s,t)
=
\frac{1-x-y}{(1-x)(1-y)(1-xy)}
=1+O(x^2y+xy^2),
\tag{27}
\]

而对 \(p\mid g\)，局部因子为

\[
\mathcal A_{g,p}(s,t)
=\frac1{(1-x)(1-y)(1-xy)}.
\tag{28}
\]

故无限乘积部分绝对局部一致收敛于

\[
\boxed{
\Re s,\Re t>0,\qquad
2\Re s+\Re t>1,\qquad
\Re s+2\Re t>1.
}
\tag{29}
\]

公式 (26) 的新信息是

\[
\boxed{
\frac1{\zeta(s+t)}=0
\quad\text{at}\quad s+t=1.
}
\tag{30}
\]

它不是装饰因子。设 \(\rho=\beta+i\gamma\) 为简单非平凡零点。若
\(\beta>1/2\)，则在非退化局部因子下

\[
F_g(s,t)
\sim
\frac{\mathcal A_g(\rho,\bar\rho)}
{\zeta'(\rho)\zeta'(\bar\rho)\zeta(2\beta)}
\frac1{(s-\rho)(t-\bar\rho)}.
\tag{31}
\]

这是一个真实双极点，双 Mellin 反演产生候选尺度

\[
X^{\rho+\bar\rho}=X^{2\beta}>X.
\tag{32}
\]

若 \(\beta=1/2\)，置 \(u=s-\rho,v=t-\bar\rho\)。由
\(1/\zeta(1+u+v)\sim u+v\)，

\[
\boxed{
F_g(s,t)
\sim C_{\rho,g}\frac{u+v}{uv}
=C_{\rho,g}\left(\frac1u+\frac1v\right).
}
\tag{33}
\]

共轭零点对的双极点被精确降为两个单极点。即

\[
\boxed{
\Re\rho=\frac12
\iff
\rho+\bar\rho=1
\iff
\text{反对角 Möbius 零点命中共轭零点对}.
}
\tag{34}
\]

对 \(I=J\)，物理核还给出

\[
\widehat W(\rho,\bar\rho)
=
\int_1^2
\left|
\int_I\phi_I(u)\beta(t/u)u^{\rho-1}\,du
\right|^2dt
\ge0.
\tag{35}
\]

非负还可升级为严格正。

**定理 2（dyadic 物理核不消去共轭零点）。** 令

\[
I_j=[2^{-j-1},2^{-j}),\qquad j\ge1,
\tag{35a}
\]

并令 \(W_j=W_{I_j,I_j}\)。则对任意

\[
\Re\rho>0,\qquad \rho\ne1,
\tag{35b}
\]

有

\[
\boxed{\widehat W_j(\rho,\bar\rho)>0.}
\tag{35c}
\]

**证明。** 置

\[
A_\rho(t):=
\int_{I_j}\log(1/u)u^{\rho-1}\beta(t/u)\,du.
\tag{35d}
\]

若 (35c) 失败，则由 (35) 得 \(A_\rho(t)=0\) a.e. 于 \([1,2]\)。
在不经过断点的开区间上，分布求导给出

\[
A_\rho'(t)
=C_\rho-
\sum_{\substack{n\ge1\\t/n\in I_j}}
\frac{\log(n/t)(t/n)^{\rho-1}}n,
\tag{35e}
\]

\[
C_\rho:=\int_{I_j}\log(1/u)u^{\rho-2}\,du.
\tag{35f}
\]

令

\[
\mathcal N(t):=\{n:2^jt<n\le2^{j+1}t\},
\tag{35g}
\]

\[
P_{\mathcal N}:=\sum_{n\in\mathcal N}n^{-\rho},
\qquad
Q_{\mathcal N}:=\sum_{n\in\mathcal N}n^{-\rho}\log n.
\tag{35h}
\]

则 \(A_\rho'=0\) 强制

\[
C_\rho
=t^{\rho-1}
\left(Q_{\mathcal N}-P_{\mathcal N}\log t\right)
\tag{35i}
\]

在每个固定 \(\mathcal N\) 的开区间恒等成立。因 \(\rho\ne1\)，对
\(\log t\) 求导并比较系数，必有

\[
P_{\mathcal N}=Q_{\mathcal N}=C_\rho=0.
\tag{35j}
\]

当 \(t\) 穿过内部断点 \(t=n/2^j\) 时，\(\mathcal N\) 把 \(n\) 替换为 \(2n\)，故

\[
P_{\mathcal N_+}-P_{\mathcal N_-}
=(2n)^{-\rho}-n^{-\rho}
=n^{-\rho}(2^{-\rho}-1)\ne0,
\tag{35k}
\]

与断点两侧的 (35j) 矛盾。\(\square\)

对离线零点 \(\rho=\beta+i\gamma\)、\(\beta>1/2\)，再固定

\[
\boxed{g=6.}
\tag{35l}
\]

若 \(p\ge5\)，则

\[
1-p^{-\rho}-p^{-\bar\rho}
=1-2p^{-\beta}\cos(\gamma\log p)
\ge1-2p^{-\beta}>0.
\tag{35m}
\]

\(p=2,3\) 已由 \(p\mid g\) 改成 (28) 的非零局部因子。因此

\[
\boxed{
\mathcal A_6(\rho,\bar\rho)>0.
}
\tag{35n}
\]

若 \(\rho\) 为简单零点，则 (31) 在 dyadic \(g=6\) 块中的双留数系数严格为

\[
\boxed{
\frac{
\widehat W_j(\rho,\bar\rho)\mathcal A_6(\rho,\bar\rho)
}{
|\zeta'(\rho)|^2\zeta(2\beta)
}>0.
}
\tag{35o}
\]

所以 exact physical kernel 的“偶然 Mellin 消失”逃逸口已关闭：
每个离线共轭零点都产生一个正的 \(X^{2\beta}\) diagonal pinch 系数。
多重零点给出相同结论并附加对数幂；把该局部系数升级为无条件全局
\(\Omega\)-项仍需截断与不同零点频率的平均分离。

历史上，de la Vallée Poussin / Vinogradov--Korobov 零自由区对固定平滑 \(W,g\) 只给

\[
S_{W,g}(X)
\ll_{W,g}
X^2\exp\!\left[
-c(\log X)^{3/5}(\log\log X)^{-1/5}
\right]
=o(X^2),
\tag{36}
\]

仍差 (DM) 的一个完整 \(X\) 因子。另一方面，RH 允许把两条轮廓移到
\(\Re s=\Re t=1/2+\varepsilon\)，给出标准的
\(X^{1+\varepsilon}\) 双平方根尺度。故任意核族上的这种定理是 RH 级输入；
不能把它当作现成的较弱引理。

硬块核 \(\mathscr K\) 是有限分片解析函数：断点来自
\(nu=mv\)、\(nu=1,2\)、\(mv=1,2\)。因此可先作有限 cell 分解与平滑 partition；
cell 边界产生低维项，不改变 (22)--(34) 的主极点结构。

### 3.4 cotangent 路线到达显式 Type II，但现有黑箱严重失配

note 066 的第一 cotangent 分支可写成

\[
\begin{aligned}
E^{(a)}_{g,a,b}(N)
={}&-\frac{gab}{4\pi^2}
\sum_{\tau=1}^2\varepsilon_\tau
\sum_{k\ne0}\frac1{k^2}
\sum_{1\le h<a}\widetilde B_1(h/a)\\
&\times
\mathrm e\!\left(
\frac{kh\bar b}{a}
+\frac{\tau Xk}{ab}
\right),
\qquad
\varepsilon_2=1,\quad\varepsilon_1=-1,
\end{aligned}
\tag{37}
\]

因为

\[
\cot^*(\pi r/a)
=2i\sum_{1\le h<a}\widetilde B_1(h/a)\mathrm e(rh/a).
\tag{38}
\]

加法互反律给出

\[
\boxed{
\mathrm e\!\left(
\frac{kh\bar b}{a}+\frac{\tau Xk}{ab}
\right)
=
\mathrm e\!\left(-\frac{kh\bar a}{b}\right)
\mathrm e\!\left(\frac{k(h+\tau X)}{ab}\right).
}
\tag{39}
\]

第二因子是 reciprocal phase 的平滑扰动；因 \(X,a,b,h\asymp H\)，其 conductor
在 Bettin--Chandee Remark 1 中为

\[
1+\frac{|k|}{H}.
\tag{40}
\]

若 \(b=mn\)、\(ML\asymp H\)，第一个真正 balanced Type II 核为

\[
\boxed{
\sum_{\substack{a\asymp H\\m\asymp M,n\asymp L\\h\asymp R}}
\alpha_a u_m v_n\rho_h\,
\mathrm e\!\left(-\frac{kh\bar a}{mn}\right)
\mathrm e\!\left(\frac{k(h+\tau X)}{amn}\right),
\qquad
M,L\asymp H^{1/2}.
}
\tag{41}
\]

把 \(q=mn\) 合并为一个模数可见 Bettin--Chandee，但会抹去唯一剩余的
\(u_mv_n\) Type II 结构；保留 \(m,n\) 则成为 variable-product modulus 四线性型。

更致命的是直接幂计数。由

\[
ab\,\widetilde B_1(h/a)=bh-\frac{ab}{2},
\tag{42}
\]

权可分成两个 rank-one 项，且

\[
\|\alpha\|_2\|\beta\|_2\|\nu\|_2
\asymp gH^{7/2}.
\tag{43}
\]

Bettin--Chandee Theorem 1 在 \(A=M=N=H\) 的大项为

\[
H^{11/8+\varepsilon}.
\tag{44}
\]

未使用 endpoint 差时得到 \(gH^{39/8+\varepsilon}\)。即使乐观地假设可经二维
partial summation 无损提出 endpoint 增益

\[
\left|
\mathrm e\!\left(\frac{2Xk}{ab}\right)
-\mathrm e\!\left(\frac{Xk}{ab}\right)
\right|
\ll\min\!\left(1,\frac{|k|}{H}\right),
\tag{45}
\]

这是合法而非形式上的抽取：当 \(|k|\le H\) 时可用

\[
\mathrm e(2\delta)-\mathrm e(\delta)
=2\pi i\delta\int_1^2\mathrm e(t\delta)\,dt,
\qquad
\delta=\frac{Xk}{ab},
\tag{45a}
\]

再调用 Bettin--Chandee 的 smooth perturbation 版本；当 \(|k|>H\) 时拆成两个相位。
求和 \(k^{-2}\) 后，所得黑箱界仍只有

\[
\boxed{
\mathcal T_{\rm BC}
\ll gH^{31/8+\varepsilon}.
}
\tag{46}
\]

这里仅包含两个 cotangent 分支。note 066 的 divisibility 修正另为

\[
E^{\rm div}_{gb,ga}(N)
=
\frac{ga^2b^2}{8\pi^3i}
\sum_{k\ne0}
\frac{\mathbf1_{a\mid k}+\mathbf1_{b\mid k}}{k^3}
\left[
\mathrm e\!\left(\frac{2Xk}{ab}\right)
-\mathrm e\!\left(\frac{Xk}{ab}\right)
\right],
\tag{Div}
\]

它不属于 Bettin--Chandee 黑箱；所以 (46) 甚至不是完整 \(E\) 的估计。
物理缩放 (14) 则一次保留 cotangent 与 divisibility 两部分。

而

\[
\sum_{a,b\asymp H}|E_{gb,ga}(N)|
\asymp gH^3
\tag{47}
\]

是直接 physical pointwise 尺度，所需 Möbius 尺度为

\[
gH^2\operatorname{polylog}H.
\tag{48}
\]

所以 BC 黑箱不仅距目标尚差

\[
H^{15/8},
\tag{49}
\]

还劣于先对每对 \((a,b)\) 使用 (14) 的 \(gH^3\)。该表示中的普通
arbitrary-coefficient Kloosterman 节省不是有效下一步。

Wright 2026 改进的是分母含 fixed factor 的 unbalanced convolution；
它不覆盖 (41) 的 balanced variable-product modulus。更直接的负证据是
Dong--Robles--Zeindler 2026 的 balanced bilinear 预印本已撤回：式 (2.53)
漏掉 \(L^2\)，使 \(L^5\) 变为 \(L^7\)，从而不再改进旧界。

原始入口：
[Bettin--Chandee](https://arxiv.org/abs/1502.00769)、
[Wright](https://arxiv.org/abs/2604.25177)、
[Dong--Robles--Zeindler（withdrawn）](https://arxiv.org/abs/2601.00292)。

### 3.5 最小有限观测

在

\[
a,b\in[X/8,X/4),\qquad (a,b)=1,
\tag{50}
\]

对 \(X=2^8,\ldots,2^{15}\) 的 exact-cell 计算显示

\[
\frac1{X^3}\sum_{a,b}|E_{a,b}(X)|
\longrightarrow 5.42\times10^{-5},
\tag{51}
\]

而

\[
\frac1{X^2}
\sum_{a,b}\mu(a)\mu(b)E_{a,b}(X)
\tag{52}
\]

在 \(10^{-3}\) 尺度内振荡，\(X=2^{15}\) 时为
\(1.47\times10^{-4}\)。它只说明：

\[
\boxed{
\text{绝对质量确为 }X^3;\quad
\text{所需机制必须保存全部 Möbius 符号并节省一个 }X.
}
\tag{53}
\]

有限数据不证明 (DM)。

## 4. 回顾反思

### 4.1 本轮严格新归约

\[
\boxed{
\text{balanced coupled Dedekind dispersion}
\Longrightarrow
\text{fixed-kernel coprime double Möbius transform}.
}
\tag{54}
\]

其不可再忽略的 Euler 结构为

\[
\boxed{
\prod_p(1-p^{-s}-p^{-t})
=
\frac{\text{regular}}
{\zeta(s)\zeta(t)\zeta(s+t)}.
}
\tag{55}
\]

\(1/\zeta(s+t)\) 在 RH 共轭反对角上消去双极点，却不消去任何
\(\Re\rho>1/2\) 的共轭双极点。这比“再找一个 Kloosterman 幂节省”更接近问题本身。

### 4.2 关闭与保留

\[
\begin{array}{c|c}
\text{路线}&\text{状态}\\
\hline
\text{Bettin--Chandee 直接黑箱}&
gH^{31/8}\gg gH^3\gg gH^2\\
\text{Wright fixed-factor 改进}&
\text{变量制度不匹配}\\
\text{撤稿 balanced bilinear claim}&
\text{漏 }L^2,\ \text{不可用}\\
\text{一般双 Möbius }X^{1+\varepsilon}&
\text{RH 级，不是已知弱输入}\\
\text{反对角 }1/\zeta(s+t)&
\text{保留；给出零点选择机制}
\end{array}
\tag{56}
\]

### 4.3 下一最简单元：反对角 no-pinch

令 \(z=s+t\)。形式上把 (21)、(26) 写成

\[
S_{W,g}(X)
=\frac1{2\pi i}\int
\frac{X^z}{\zeta(z)}\mathcal J_{W,g}(z)\,dz,
\tag{57}
\]

\[
\mathcal J_{W,g}(z)
:=
\frac1{2\pi i}\int_{\Gamma_z}
\frac{
\widehat W(s,z-s)\mathcal A_g(s,z-s)
}{
\zeta(s)\zeta(z-s)
}\,ds.
\tag{58}
\]

离线零点 \(\rho\) 与 \(\bar\rho\) 在

\[
z=\rho+\bar\rho=2\Re\rho>1
\tag{59}
\]

产生 contour pinch；RH 零点只在 \(z=1\) 相遇，并被 \(1/\zeta(z)\) 命中。

这可由一个真正的一变量 Mellin 变换严格实现。置

\[
\mathfrak M_{W,g}(z):=
\int_0^\infty S_{W,g}(X)X^{-z-1}\,dX.
\tag{60}
\]

因紧支撑 \(W\) 的平凡计数为 \(S_{W,g}(X)=O_W(X^2)\)，(60) 在
\(\Re z>2\) 绝对收敛。若

\[
1<c<\Re z-1,
\tag{61}
\]

则 scale-Mellin convolution 给出

\[
\boxed{
\mathfrak M_{W,g}(z)
=\frac1{2\pi i}\int_{(c)}
\widehat W(s,z-s)F_g(s,z-s)\,ds
=\frac{\mathcal J_{W,g}(z)}{\zeta(z)}.
}
\tag{62}
\]

对一个与其他 pinch 暂时隔离的简单零点对
\((\rho,\bar\rho)\)，Barnes 局部模型为

\[
\frac1{2\pi i}
\int_{\Gamma_z}
\frac{ds}{(s-\rho)(z-s-\bar\rho)}
=\frac1{z-2\beta}.
\tag{63}
\]

故 \(g=6,W=W_j\) 时该 isolated pinch 对 (60) 的局部贡献为

\[
\boxed{
\frac{
\widehat W_j(\rho,\bar\rho)\mathcal A_6(\rho,\bar\rho)
}{
|\zeta'(\rho)|^2\zeta(2\beta)
}
\frac1{z-2\beta},
}
\tag{64}
\]

其系数由 (35o) 严格为正。

因此下一原子不再是泛化 Type II，而是 exact physical kernel 的

\[
\boxed{
\text{anti-diagonal no-pinch theorem: }
\mathcal J_{W,g}(z)
\text{ 在实轴 }z>1\text{ 无未消极点}.
}
\tag{AP}
\]

定理 2 与 (60)--(64) 已完成局部判别：dyadic exact kernel 的 isolated pinch
系数对 \(g=6\) 严格为正。下一步只需严化一个全局 residue-extraction 引理：

\[
\boxed{
\exists\rho,\ \Re\rho>1/2
\Longrightarrow
S_{W_j,6}(X)\not\ll X(\log X)^A
\quad(\text{任意固定 }A).
}
\tag{AP0}
\]

工具应限于 truncated double Perron 与 \(\log X\) 上的频率平均；不再引入新的
Kloosterman 分解。唯一尚须排除的局部漏洞，是同一 \(z=2\beta\) 上其他零点对的
simultaneous pinch 留数恰好抵消 (64)；单个 diagonal 系数为正尚不足以形式上排除
这种全局抵消。完成 (AP0) 后，再检查历史 Wiener--Hopf、Mellin convolution
或 zero-detecting Tauberian 技术能否从 physical kernel 的额外正性证明反向上界
\(S_{W_j,6}(X)\ll X\operatorname{polylog}X\)。若上界只能通过预设
\(\Re\rho\le1/2\) 获得，则该分支只是新的 RH 等价判据，而不是证明。

本轮没有证明 (DM)、(AP) 或 RH。
