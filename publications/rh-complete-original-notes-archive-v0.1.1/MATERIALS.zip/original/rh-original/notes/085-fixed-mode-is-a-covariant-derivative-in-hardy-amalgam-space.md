> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定模是 Hardy-amalgam 空间中的协变导数

日期：2026-08-13。

依赖：[note 081](081-every-offline-zero-is-visible-in-one-fixed-sine-mode.md)。

## 1. 精确函数空间

记

\[
f_k(X):=\mathscr R_k(X),
\qquad
F_k(s):=\int_1^\infty f_k(X)X^{-s-1}dX.
\tag{1}
\]

令

\[
u=\log X,
\qquad
h_k(u):=e^{-u/2}f_k(e^u).
\tag{2}
\]

则 \(F_k(1/2+z)\) 是 \(h_k\) 的 Laplace 变换。对 \(\delta>0\)，
Mellin--Plancherel 给出

\[
\boxed{
\frac1{2\pi}\int_{\mathbb R}
\left|F_k\left(\frac12+\delta+it\right)\right|^2dt
=\int_1^\infty\frac{|f_k(X)|^2}{X^{2+2\delta}}dX.
}
\tag{3}
\]

定义 dyadic 对数能量

\[
E_{k,j}:=int_{2^j}^{2^{j+1}}\frac{|f_k(X)|^2}{X^2}dX.
\tag{4}
\]

于是

\[
\int_{2^j}^{2^{j+1}}|f_k(X)|^2dX\asymp2^{2j}E_{k,j}.
\tag{5}
\]

因此精确临界界对应

\[
\boxed{
\int_Y^{2Y}|f_k|^2\ll Y^2
\Longleftrightarrow
\sup_jE_{k,j}<\infty
\Longleftrightarrow
h_k\in W(L^2,\ell^\infty).
}
\tag{6}
\]

它是 uniformly-local/Hardy-amalgam 条件，不是一个标准全局 \(H^2\) 范数。带任意
\(\varepsilon\) 的 RH-sufficient 尺度则精确等价于

\[
\boxed{
\forall\varepsilon>0,quad
\int_Y^{2Y}|f_k|^2\ll_\varepsilon Y^{2+\varepsilon}
\Longleftrightarrow
F_k\in\bigcap_{\delta>0}H^2
\left(\Re s>\frac12+\delta\right).
}
\tag{7}
\]

式 (7) 是等价重编码，不降低问题强度。

## 2. 隐藏的整函数导数

note 081 的 Mellin 像可写为

\[
F_k(s)=\frac{G_k(s)}{\zeta(s)},
\tag{8}
\]

\[
G_k(s)=\frac{c_k}{(s-1)^2}
+W_k(s)\zeta'(s)+(\zeta(s)-1)W_k'(s).
\tag{9}
\]

定义

\[
\boxed{
H_k(s):=W_k(s)(\zeta(s)-1)-\frac{c_k}{s-1}.
}
\tag{10}
\]

因 \(W_k(1)=c_k\)，\(s=1\) 的极点可去，故 \(H_k\) 是整函数，且

\[
\boxed{G_k=H_k',\qquad F_k=H_k'/\zeta.}
\tag{11}
\]

再令 \(Q_k=H_k/\zeta\)，得到协变导数形式

\[
\boxed{
F_k=Q_k'+\frac{\zeta'}\zeta Q_k.
}
\tag{12}
\]

## 3. Ground-state 能量恒等式

在一条不经过零点的竖线 \(s=\sigma+it\) 上，令

\[
v(t):=\log|\zeta(\sigma+it)|,
\qquad
p(t):=\frac{H_k(\sigma+it)}{|\zeta(\sigma+it)|}.
\tag{13}
\]

消去 \(\zeta\) 相位后，

\[
|F_k|^2=|p_t+v_tp|^2.
\tag{14}
\]

所以

\[
\boxed{
\int_{-T}^T|F_k|^2dt
=\int_{-T}^T|p_t|^2dt
+\int_{-T}^T(v_t^2-v_{tt})|p|^2dt
+[v_t|p|^2]_{-T}^T.
}
\tag{15}
\]

势 \(v_t^2-v_{tt}\) 没有确定符号；其尖峰正编码 \(\zeta\) 零点。因此 (15) 是诊断恒等式，
不是现成上界。

二维版本更干净。若 \(\Omega\) 的闭包无 \(\zeta\)-零点，置

\[
v(s)=\log|\zeta(s)|,
\qquad p(s)=H_k(s)e^{-v(s)}.
\]

则 Green 公式给出

\[
\boxed{
2\iint_\Omega|F_k|^2dA
=\iint_\Omega|\nabla p|^2dA
+\iint_\Omega|\nabla v|^2|p|^2dA
+\int_{\partial\Omega}|p|^2\partial_nv\,ds.
}
\tag{16}
\]

两个体积分非负，困难只在边界项。

## 4. 正性与尺度错配

对半平面加权 Bergman 范数，\(\alpha>-1\)，

\[
\|F_k\|_{A^2_\alpha}^2
\asymp\sum_{j\ge1}\frac{E_{k,j}}{j^{\alpha+1}}.
\tag{17}
\]

- (16) 最自然对应无权 \(A^2_0\)，要求 \(\sum_jE_{k,j}/j<\infty\)；
- 临界逐壳界只给 \(E_{k,j}=O(1)\)，恰差一个调和对数；
- 引入能容纳临界尺度的权后，Green 展开新增
  \(-\iint\omega'(\sigma)v_\sigma|p|^2\)，重新失去符号。

所以

\[
\boxed{
\text{标准 Hardy/Bergman 正性}
\quad\text{与}\quad
\text{临界 dyadic 尺度}
\quad\text{错配一个对数。}
}
\tag{18}
\]

这关闭了把 fixed-mode 目标直接作为普通 \(H^2/A^2\) 范数后套正性公式的捷径；可存活的
解析路线必须控制 (16) 的边界项，或直接处理 Hardy-amalgam 的逐窗能量。
