> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 全部非链交叉能量的 lcm 残类分解

日期：2026-08-17。

note 453 只处理 \(e=ad\) 的除数链。本 note 对任意 \(d,e\) 给出统一的
\(\operatorname{lcm}(d,e)\) 残类分解，把非链项压缩为有限个二维调和尾抽样和。

## 1. 记号

令

\[
g=\gcd(d,e),\qquad d=ga,\qquad e=gb,\qquad (a,b)=1,
\qquad L=\operatorname{lcm}(d,e)=gab.
\]

写

\[
M_d=\left\lfloor\frac Nd\right\rfloor,\qquad
M_e=\left\lfloor\frac Ne\right\rfloor,
\]

以及

\[
A_q^{(d)}=\sum_{q<n\le M_d}\frac{\mu(n)}n,\qquad
A_q^{(e)}=\sum_{q<n\le M_e}\frac{\mu(n)}n.
\]

## 2. 精确残类公式

由 note 445，

\[
(G_N)_{d,e}
=\frac1{de}\sum_{k=1}^{N-1}(2k+1)
A_{\lfloor k/d\rfloor}^{(d)}
A_{\lfloor k/e\rfloor}^{(e)}.
\tag{1}
\]

将 \(k\) 唯一写成 \(k=Lq+r\)，其中 \(0\le r<L\)，并令

\[
q_0(r)=
\begin{cases}
1,&r=0,\\
0,&1\le r<L,
\end{cases}
\qquad
q_1(r)=\left\lfloor\frac{N-1-r}{L}\right\rfloor.
\]

则

\[
\left\lfloor\frac{Lq+r}{d}\right\rfloor
=bq+\left\lfloor\frac rd\right\rfloor,
\qquad
\left\lfloor\frac{Lq+r}{e}\right\rfloor
=aq+\left\lfloor\frac re\right\rfloor.
\]

代回 (1) 得

\[
\boxed{
(G_N)_{d,e}
=\frac1{de}
\sum_{r=0}^{L-1}
\sum_{q=q_0(r)}^{q_1(r)}
\bigl(2Lq+2r+1\bigr)
A_{\,bq+\lfloor r/d\rfloor}^{(d)}
A_{\,aq+\lfloor r/e\rfloor}^{(e)}.
}
\tag{2}
\]

公式完全保留 Möbius 符号；末端超出 \(M_d\) 或 \(M_e\) 的尾自动为零。
OMEN 已用精确有理数对 \(N=23,37,64\) 的所有 \(d,e\) 核验 (2)。

## 3. 与除数链的相容性

当 \(d\mid e\) 时，\(L=e\)，残类分解可重新按
\(k=dq+r\) 合并，(2) 退化为 note 453 的链公式。因而 (2) 不是另一种近似，
而是链公式的统一 lcm 版本。

## 4. 当前算术缺口

式 (2) 把非链项明确化为 \(L\) 个残类上的二维 signed 抽样和；它没有提供
正性或平方根级估计。要闭合 RH-strength 门，需要对这些随
\(d,e,L\) 变化的抽样相关取得统一抵消，或者找到把它们重新组织成可控的
跨残类算术 intertwiner。逐项绝对值会回到 \(N^2\) 量级，因此不能替代该
signed 估计。
