> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 非首列方阵的精确三角分解与最大子式

日期：2026-08-17。

note 447 给出了 \(T_N\) 的唯一右零关系。本 note 再把非首列组成的方阵写成显式三角乘积，从而得到精确行列式、全部最大子式的大小，以及近似列消去的精确坐标公式。

## 1. 非首列方阵

令

\[
B_N:=T_N[:,2:N],
\]

即取 \(T_N\) 的第 \(2,\ldots,N\) 列。把 \(R_N\) 的相应列记为

\[
R_N^{(2)}=R_N[:,2:N].
\]

由于 \(D_N^{-1}\) 的第 \(1\) 行在第 \(2,\ldots,N\) 列上全为零，\(B_N\) 只使用 \(D_N^{-1}\) 的右下方块：

\[
B_N=R_N^{(2)}\,\bigl(D_N^{-1}\bigr)_{2:N,\,2:N}.
\tag{1}
\]

右下方块是单位下三角矩阵的逆，行列式为 \(1\)。

再定义 \(U_N\in\mathbb R^{(N-1)\times(N-1)}\)（列指标 \(j=1,\ldots,N-1\) 对应原指标 \(n=j+1\)）：

\[
(U_N)_{k,j}=\mathbf 1_{j\ge k}.
\]

\[
R_N^{(2)}
=\operatorname{diag}\bigl(\sqrt{2k+1}\bigr)_{k=1}^{N-1}
\,U_N\,
\operatorname{diag}\bigl((j+1)^{-1}\bigr)_{j=1}^{N-1}.
\tag{2}
\]

\(U_N\) 是上三角矩阵，且对角线全为 \(1\)。因此 \(B_N\) 可逆，并且

\[
\boxed{
\det B_N
=\frac{\displaystyle\prod_{k=1}^{N-1}\sqrt{2k+1}}{N!}.
}
\tag{3}
\]

更方便的行归一化矩阵 \(\widetilde B_N\)，其第 \(k\) 行除以 \(\sqrt{2k+1}\)，满足

\[
\boxed{\det\widetilde B_N=\frac1{N!}.}
\tag{4}
\]

OMEN 上对 \(N=4,8,16,32,64\) 的数值核验与 (3) 一致；这只是三角恒等式的计算复核，不是数值证据外推。

## 2. 显式逆与唯一近似坐标

因为

\[
(U_N^{-1})_{k,j}
=\mathbf 1_{j=k}-\mathbf 1_{j=k+1},
\]

由 (1)--(2) 得到

\[
B_N^{-1}
=\bigl(D_N\bigr)_{2:N,\,2:N}
\operatorname{diag}(j+1)\,
U_N^{-1}\,
\operatorname{diag}\bigl((2k+1)^{-1/2}\bigr).
\tag{5}
\]

现在考虑任意系数 \(\alpha\in\mathbb R^{N-1}\) 的近似列消去

\[
T_Ne_1+B_N\alpha=\rho.
\tag{6}
\]

note 447 的精确关系对应 \(\alpha_*=\mathbf1_{N-1}\)。由于 \(T_Ne_1+B_N\mathbf1_{N-1}=0\)，(6) 等价于

\[
\boxed{
\alpha-\mathbf1_{N-1}=B_N^{-1}\rho.
}
\tag{7}
\]

所以近似桥的全部自由度被压缩为一个明确的 \(B_N^{-1}\) 作用：若要同时要求小余项和有界系数，必须证明 \(B_N^{-1}\rho\) 的定量约束。正性或行列式非零本身不提供这个谱估计。

## 3. 全部最大子式

由 note 447 的零空间

\[
\ker T_N=\operatorname{span}\{\mathbf1_N\}
\]

和 \(B_N\) 可逆，\(T_N\) 的所有 \((N-1)\times(N-1)\) 最大子式具有相同绝对值：

\[
\boxed{
\left|\det T_N[:,\{1,\ldots,N\}\setminus\{d\}]\right|
=\frac{\displaystyle\prod_{k=1}^{N-1}\sqrt{2k+1}}{N!},
\qquad 1\le d\le N.
}
\tag{8}
\]

符号按删除列的奇偶交替。这是余子式向量属于右零空间的直接结果；它进一步说明全除数列消去不是某一个特殊列的偶然退化，而是 \(T_N\) 的统一有限尺度结构。

## 4. 边界

式 (7) 没有给出 RH 证明：\(B_N^{-1}\) 的范数可能随 \(N\) 增长，而要证明平方根级余项，正是要控制这个逆作用在特定 signed 边界向量上的行为。当前可审计结论是：

1. 非首列确实构成可逆方阵；
2. 精确消去系数唯一且为全 \(-1\)；
3. 任意近似消去都必须通过显式的 \(B_N^{-1}\rho\) 支付系数—余项权衡。

因此下一道真实问题不是继续寻找另一组精确有限系数，而是估计 \(B_N^{-1}\) 在 Möbius 边界余项上的作用；这仍是 RH-strength 的 signed 算术接口。
