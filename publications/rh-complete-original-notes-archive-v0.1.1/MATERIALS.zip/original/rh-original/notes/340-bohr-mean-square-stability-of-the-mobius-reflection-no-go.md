> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius 频率反射的 Bohr 均方稳定性障碍

日期：2026-08-16。

note 339 排除了绝对可和 Dirichlet 系数的 exact reflection。本 note 给出
相应的定量稳定性：若只要求在整条实轴上做绝对可和的正频率近似，则误差的
Bohr 均方不能小于目标中所有非零 Möbius 频率的总质量。

## 命题

令 \(N\ge2\)，

\[
 G_N(t)=\sum_{2\le n\le N}\mu(n)e^{-it\log n}
\]

（去掉零频率 \(n=1\) 只为把常数项单独写出）。令

\[
 A(t)=\sum_{m\ge1}c_m e^{it\log m},
 \qquad c\in\ell^1(\mathbb N),
\]

并设 \(E(t)=A(t)-G_N(t)\)。则 \(E\) 是一致收敛的 Bohr almost-periodic
函数，且

\[
 \mathcal M(|E|^2)
 :=\lim_{T\to\infty}\frac1{2T}\int_{-T}^T|E(t)|^2\,dt
 =|c_1|^2+\sum_{m\ge2}|c_m|^2+
   \sum_{2\le n\le N}\mu(n)^2.
\tag{1}
\]

若近似目标保留零频率 \(1\)，即改取

\[
 G_N^{\rm full}(t)=1+G_N(t),
\]

则式 (1) 的第一项替换为 \(|c_1-1|^2\)。特别地，对任意 \(c\)，

\[
 \mathcal M\!\left(\left|A-G_N^{\rm full}\right|^2\right)
 \ge \sum_{2\le n\le N}\mu(n)^2
 =\frac{6}{\pi^2}N+O(\sqrt N).
\tag{2}
\]

因此全局 Bohr 均方误差至少为

\[
 \left(\frac{6}{\pi^2}N+O(\sqrt N)\right)^{1/2}.
\]

## 证明

对有限 Dirichlet 多项式，指数正交恒等式

\[
 \lim_{T\to\infty}\frac1{2T}\int_{-T}^T e^{i\lambda t}\,dt
 =\begin{cases}1,&\lambda=0,\\0,&\lambda\ne0,\end{cases}
\]

直接给出 (1)：正频率 \(\log m\) 与目标的负频率 \(-\log n\) 在
\(m,n>1\) 时互不相交；唯一可能重合的频率是零频率 \(m=n=1\)。

对一般 \(c\in\ell^1\)，先以有限截断一致逼近 \(A\)。因为
\(\ell^1\) 保证 \(\|A-A_M\|_\infty\to0\)，其 Bohr 均方也趋于零，有限情形的恒等式
即可取极限，得到 (1)。最后使用平方自由数计数
\[
\sum_{n\le N}\mu(n)^2=\frac{6}{\pi^2}N+O(\sqrt N)
\]
得到 (2)。

还有一个更弱但常用的均匀版本。对任意平方自由 \(k\in[2,N]\)，
\[
 \lim_{T\to\infty}\frac1{2T}\int_{-T}^T
 E(t)e^{it\log k}\,dt=-\mu(k),
\tag{3}
\]
故全实轴上的均匀误差必满足
\(\|E\|_{L^\infty(\mathbb R)}\ge1\)。

## 对 arithmetic intertwiner 的边界

这个命题只排除“在整条实轴上全局小误差”的正频率反射。当前 detector
使用的是固定的局部/衰减权 \(h(t)\) 或 \(|h(t)|\)，不是 Bohr 均值；因此不能把
(2) 直接替换成对
\[
\int_{\mathbb R}|h(t)|\,|E(t)|^2\,dt
\]
的同样下界。要继续推进，仍须在局部权下构造一条带系数范数的稳定性不等式，
或证明任何可用的局部反射都必支付完整的正能量门。这个区别保留了 note 337
所留下的真实缺口，而没有把全局 no-go 误报成 RH 证明。
