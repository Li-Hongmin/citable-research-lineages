> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 高阶 periodization 的负号输出必须先通过精度审计

日期：2026-08-15。

## 1. 触发的假阳性

`computations/search_numeric_periodization_mp.py` 在默认 100 位精度下扫描
高层 (m=101,ldots,200) 时，曾报告

\[
m=107, y=100: -7.64\times10^{-159},qquad
m=108, y=100: -1.96\times10^{-159},
\]

以及 (m=110,y\approx99.505) 的负值。这个量的真实尺度约为
(10^{-159})，因此这些符号不能直接视为反例。

## 2. 精确复核

递推得到的 (R_{m,m-1}) 系数为整数；在整数 (y=100) 处，直接以
`Fraction` 计算
\[
\sum_{1\le n\le100}-\frac{d}{du}
\left[u^3(1-u)^{2m+2}R_{m,m-1}(u)\right]_{u=n/100}
\]
得到严格正值（正的归一化常数不影响符号）：

\[
m=106,107,108,109,110:quad P_m(100)>0.
\]

以 300 位 `mpmath` 复算，归一化值分别为

\[
m=107: 1.9389763420\ldots\times10^{-158},qquad
m=108: 4.2273077112\ldots\times10^{-159}.
\]

因此此前的 100 位负号是灾难性消去造成的数值伪象，不是已证的
periodization 反例。

## 3. 证据边界

这次复核只撤销了错误的数值反例；它没有证明 (P_m(y)\ge0) 对所有
(m,y)。任何高阶负输出都必须提高工作精度，并优先在有理 (y) 上使用
精确算术或区间算术复核。
