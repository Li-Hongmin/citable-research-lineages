> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Zero-cyclicity 的指数矩归约与外侧方程障碍

日期：2026-08-11。文献决策检索日期同为 2026-08-11；检索范围限于 truncated
Wiener--Hopf/convolution kernel 的零核、cyclic vector 与指数矩唯一性。现有检索结果主要处理
Fredholm 性、谱表示或迹渐近，没有发现可直接把本项目的内点压缩方程传播成外侧齐次方程的定理。

本文判断 polar orthogonality 给出的两个首指数矩能否递推为全部矩。结论是：外侧
Archimedean 势一旦在开区间消失，zero-cyclicity 立即成立；但现有内点方程、有限 prime shifts
和 logarithmic 边界正则性均不足以推出该外侧消失。

## 1. 外侧 Dirichlet 级数

固定 (a>0)，把 (u) 零延拓到 (mathbb R)，并令

\[
\rho_m=2m+\frac12,
\qquad
U_m^pm=\int_{-a}^a u(y)e^{\pm\rho_my}\,dy.
\]

奇偶性和相应 polar vector 正交共同给出

\[
U_0^+=U_0^-=0.
\tag{1}
\]

约化普通核为

\[
k(t)=\frac{e^{-t/2}}{1-e^{-2t}}
=\sum_{m\ge0}e^{-\rho_mt},
\qquad t>0.
\]

定义外侧绝对收敛的势

\[
(\mathcal Ku)(x)=\int_{-a}^ak(|x-y|)u(y)\,dy.
\]

则

\[
(\mathcal Ku)(x)
=\sum_{m\ge0}e^{-\rho_mx}U_m^+,
\qquad x>a,
\tag{2}
\]

\[
(\mathcal Ku)(x)
=\sum_{m\ge0}e^{\rho_mx}U_m^-,
\qquad x<-a.
\tag{3}
\]

令 (z=e^{-2x})，式 (2) 成为

\[
e^{-x/2}\sum_{m\ge0}U_m^+z^m.
\]

解析唯一性因此给出

\[
\boxed{
\mathcal Ku=0\ \text{于某个非空右外侧开区间}
\iff U_m^+=0\quad\forall m.}
\tag{4}
\]

左侧完全类似。一旦一侧全部指数矩消失，作变量替换 (w=e^{2y})，再用紧区间上多项式稠密性，
即可推出 (u=0)。

## 2. 内点方程不产生有限递推

对单个指数核，(x\in(-a,a)) 时

\[
K_mu(x)=e^{-\rho_mx}\int_{-a}^xe^{\rho_my}u(y)\,dy
+e^{\rho_mx}\int_x^ae^{-\rho_my}u(y)\,dy,
\tag{5}
\]

并有

\[
(\partial_x^2-\rho_m^2)K_mu=-2\rho_mu.
\tag{6}
\]

约化零模态方程同时含全部不同的 \(\rho_m\)、有限 shifts 和对角项。不存在一个有限阶微分算子
能同时消去 (6) 中的全部指数尺度；逐项施加
((\partial_x^2-\rho_m^2)) 只会把其余无限项变成新的非零项，不能形成关于 (U_m^pm) 的三角递推。

单项内侧边界值为

\[
K_mu(a-)=e^{-\rho_ma}U_m^+,
\qquad
K_mu(-a+)=e^{-\rho_ma}U_m^-.
\tag{7}
\]

即使允许逐项取 trace，完整势在端点也只给一个加权矩和。恢复全部矩需要无限边界 jet

\[
\partial_x^r(\mathcal Ku)(a-)
=\sum_m(-\rho_m)^re^{-\rho_ma}U_m^+,
\qquad r=0,1,\ldots,
\tag{8}
\]

及相应增长控制。当前仅有 logarithmic 边界上界，既不给 (8)，也不能证明势在端点无限阶消失。

## 3. 有限 prime shifts 不补无限边界数据

固定尺度上的 prime 部分只含有限多个 (u(x\pm\log n))。在端点 collar 中，它们给出有限延迟
关系，不产生 (8) 所需的无限组独立条件，也不改变外侧展开 (2)--(3) 的系数。因此

\[
U_0^pm=0\not\Longrightarrow U_1^pm=0
\]

不能由奇偶性、核级数或有限 shifts 单独推出。

事实上，在任一奇偶扇区可取两个支撑分离的光滑 bumps (f_1,f_2)，令

\[
u=f_1-
\frac{\langle f_1,\phi_0\rangle}
{\langle f_2,\phi_0\rangle}f_2,
\]

其中偶侧 (phi_m=\cosh(\rho_mx))，奇侧 (phi_m=\sinh(\rho_mx))。选择两个中心使
(phi_1/\phi_0) 取不同值，即得到

\[
U_0^+=U_0^-=0,
\qquad U_1^+\ne0.
\tag{9}
\]

这不是 (M_a^sigma u=0) 的反例；它严格说明任何矩传播都必须使用额外的零模态边界信息。

## 4. 缺失的单一命题

压缩方程 (M_a^sigma u=0) 只在 ((-a,a)) 的测试函数意义下成立。零延拓后，Dirichlet
logarithmic 算子在外侧一般不为零；因此不能把内点方程解析延拓为外侧齐次式。

指数矩路线的最小充分命题是

\[
\boxed{
u\in\ker M_a^sigma,
\quad U_0^+=U_0^-=0
\Longrightarrow
\mathcal Ku=0
\quad\text{于某个非空外侧开区间}.}
\tag{10}
\]

由 (4) 和多项式稠密性，(10) 立即推出 (u=0)。一个等价的局部版本是证明完整零边界 jet
(8) 及足够的解析增长界。

所以 zero-cyclicity 的真正障碍不是缺少有限差分技巧，而是缺少 exterior-potential UCP 或无限
边界数据。未先证明 (10) 时，不得从两个 polar moments 宣称全部指数矩消失。
