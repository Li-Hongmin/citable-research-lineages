> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一般有限尺度滤波器的尾部门：保留观测或消掉观测

## 1. 一般尺度多项式

令
\[
P(z)=\sum_{j=0}^{J}a_jz^j
\]
为任意有限多项式，并定义
\[
F_{P,X}(t)=P(2^{it})\sum_{n\le X}\mu(n)n^{it}
=\sum_{m\le2^JX}b_{P,X}(m)m^{it},
\]
其中
\[
b_{P,X}(m)=
\sum_{\substack{0\le j\le J\\2^j\mid m\\m/2^j\le X}}
a_j\mu(m/2^j).
\]

仍令
\[
B_X(y)=\sum_{\lceil y\rceil\le n\le X}\frac{\mu(n)}n.
\]
对 reciprocal 核的尾和直接交换有限求和，得到
\[
T_{P,X}(k):=\sum_{m\ge k}\frac{b_{P,X}(m)}m
=\sum_{j=0}^{J}a_j2^{-j}B_X(k/2^j).
\tag{1}
\]

## 2. \(k=1\) 的精确观测系数

因为 \(B_X(2^{-j})=A_X(X)\)，其中
\[
A_X(X)=\sum_{n\le X}\frac{\mu(n)}n,
\]
式 (1) 给出
\[
\boxed{T_{P,X}(1)=P(1/2)\,A_X(X).}
\tag{2}
\]
结合 note 398 的正平方分解，
\[
Q_{P,X}:=
\sum_{m,n\le2^JX}b_{P,X}(m)b_{P,X}(n)
\frac{\min(m,n)}{\max(m,n)}
\ge |P(1/2)|^2|A_X(X)|^2.
\tag{3}
\]

因此，只要 \(P(1/2)\neq0\)，且
\[
|P(1/2)|^{-1}=(2^JX)^{o(1)},
\]
任何自然支撑尺度上的估计
\[
Q_{P,X}\ll_\varepsilon(2^JX)^{1+\varepsilon}
\tag{4}
\]
都会推出
\[
A_X(X)\ll X^{1/2+\varepsilon},
\]
进而由 Abel 变换推出 RH-strength 的
\(M(X)\ll X^{1/2+\varepsilon}\)。

## 3. 逃逸条件及其代价

若要让正平方能量不再直接观测 \(A_X(X)\)，必须满足
\[
P(1/2)=0
\tag{5}
\]
或至少使 \(|P(1/2)|\) 小到抵消滤波器复杂度。条件 (5) 不是普通的
零频条件 \(P(1)=0\)，而是 reciprocal 尾部在尺度变量 \(2^{-j}\) 下的
精确零点。

这形成一个严格的设计二分：

1. \(P(1/2)\neq0\)：尾部平方门保留 Mertens 观测，因此自然能量上界已经
   是 RH-strength；
2. \(P(1/2)=0\)：可以删掉 \(k=1\) 的直接门，但同时删掉了从该门恢复
   \(A_X(X)\) 的信息，必须另造一个新的观测算子。

特别地，增加滤波器阶数本身不能同时实现“消掉尾部常数模态”和“保留
同一模态的 RH 观测”。逃逸滤波器必须依靠 \(k\ge2\) 的 moving-kink
尾部结构或新的跨尺度算术输入。

## 结论

式 (2)--(5) 给出任意有限二进制尺度滤波器的统一零模判据。它不是 RH
证明，但排除了一个常见的循环路线：先构造一个仍满足 \(P(1/2)\neq0\)
的正能量滤波器，再把其自然 \(X^{1+\varepsilon}\) 界称作低于 RH 的新输入。
