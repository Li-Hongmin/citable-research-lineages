> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一个 Mellin 频点的零不能消除 RH-strength bulk

日期：2026-08-14。

修正：[note 133](133-the-fixed-band-mertens-mode-is-an-endpoint-commutator-not-a-bulk-mode.md)。

证据等级：固定 Mellin twist 与 Mertens 界的双向部分求和。

note 133 正确证明 \(t=0\) 的 bulk symbol 为零，且该频点的 cutoff commutators
局部化到 product endpoints。但“承重量因此只剩 endpoints”的路线解释过强：
任意固定非零 Mellin twist 仍与 RH 等强。

对固定 \(\tau\in\mathbb R\)，定义

\[
M_\tau(x)=\sum_{n\le x}\mu(n)n^{-i\tau}.
\tag{1}
\]

由部分求和，

\[
\boxed{
M_\tau(x)
=x^{-i\tau}M_0(x)
+i\tau\int_1^xM_0(u)u^{-i\tau-1}\,du.}
\tag{2}
\]

反向把 \(n^{i\tau}\) 乘回去，得到

\[
\boxed{
M_0(x)
=x^{i\tau}M_\tau(x)
-i\tau\int_1^xM_\tau(u)u^{i\tau-1}\,du.}
\tag{3}
\]

因此对每个固定 \(\tau\)，

\[
\boxed{
M_\tau(x)\ll_{\tau,\varepsilon}x^{1/2+\varepsilon}
\iff
M_0(x)\ll_{\varepsilon}x^{1/2+\varepsilon}
\iff\mathrm{RH}.}
\tag{4}
\]

同样，若 \(\psi\) 属于固定 dyadic partition，则

\[
B_{\psi,z}(\tau)
=\sum_n\mu(n)\psi(n/z)(n/z)^{-i\tau}
\tag{5}
\]

在所有 dyadic scales 上的平方根界与 (4) 等价。

note 133 的 bulk multiplier 在 \(s=3+it\) 上是

\[
m(t)=(-it)(1-it).
\tag{6}
\]

它只在

\[
t=0
\tag{7}
\]

消失。对每个固定实数 \(\tau\ne0\)，

\[
m(\tau)\ne0,
\tag{8}
\]

所以 product interior 仍包含一整族 RH-strength twisted Möbius modes。
partition-of-unity telescope 删除的是 cutoff commutators，不删除
\(m(t)\widetilde E(t)B_{\psi,z}(t)^2\) 的非零频 bulk。

这也说明 symbol zero 不改善软 point observability。若权在零点附近只提供
\(|t|\)，且

\[
|B_{\psi,z}'(t)|\ll z,\qquad H=|B_{\psi,z}(0)|,
\tag{9}
\]

则

\[
\int_{|t|\le1}|t|\,|B_{\psi,z}(t)|^2dt
\gg\frac{H^4}{z^2}.
\tag{10}
\]

即使左边有目标尺度 \(O(z^{1+\varepsilon})\)，也只推出

\[
H\ll z^{3/4+\varepsilon},
\tag{11}
\]

比 note 132 的无零权 \(2/3\) 恢复还弱。单频 symbol zero 不是平方根机制。

严格边界因此是：

\[
\boxed{
\text{note 133 只局部化了 \(t=0\) mode；
非零 fixed-band bulk 仍逐频 RH 等强}.}
\tag{12}
\]

product endpoints 仍需处理，但它们不是唯一障碍。下一步若继续 Mellin 路线，必须
直接利用整段 \(t\)-积分中 \(B(t)^2\) 的 signed Hankel cancellation；对非零
frequencies 逐点或逐 mode 估计会原样输入 RH。这不是 RH 的证明。
