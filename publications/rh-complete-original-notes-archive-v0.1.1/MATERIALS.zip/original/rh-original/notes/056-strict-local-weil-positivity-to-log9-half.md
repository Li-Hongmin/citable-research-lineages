> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 局部 Weil 算子的严格正性推进到 \(\frac12\log9=\log3\)

日期：2026-08-12。

## 定理

设 \(A_a=A_a^+\oplus A_a^-\) 为局部 Weil 形式对应的自伴算子。则

\[
\boxed{A_a^+>0,\qquad A_a^->0,
\qquad 0<a\le\log3.}
\tag{1}
\]

因此

\[
\boxed{A_a>0\quad(0<a\le\log3),}
\qquad
\boxed{a_{\rm deg}>\log3.}
\tag{2}
\]

## Prime 结构

在端点 \(2a=\log9\) 上，具有正测度 overlap 的 von Mangoldt 项恰为

\[
n=2,3,4,5,7,8;
\]

\(n=9\) 只在零测度端点接触。只有 \(n=2\) 含 translation；六项均含
partial reflection。特别地

\[
\alpha_8=\frac{\Lambda(8)}{\sqrt8}=\frac{\log2}{\sqrt8}.
\]

无网格 19-cell 两步 degree 枚举给出

\[
\sup D_2=7.1711424406945801079772571593\ldots,
\]

故两个奇偶扇区同时满足

\[
\boxed{\|P^\sigma\|<2.677898885450043<2.677899.}
\tag{3}
\]

## 加权补空间预解式

取 \(R=280\)、前 \(N=500\) 个正 Yukawa atoms，并令 \(P_R\) 为低 Fourier
投影、\(Q_R=I-P_R\)。在 \(Q_R\) 上写

\[
Q_RA_a^\sigma Q_R=D_Q+B_Q,
\qquad B_Q\succeq-\rho_\sigma I,
\]

其中

\[
\rho_+=2.677899,
\qquad
\rho_-=2.677899+2(\sinh a-a).
\]

于是

\[
Q_RA_a^\sigma Q_R\succeq D_Q-\rho_\sigma I>0,
\]

并由 Loewner 反序得到

\[
(Q_RA_a^\sigma Q_R)^{-1}
\preceq(D_Q-\rho_\sigma I)^{-1}.
\tag{4}
\]

令 \(d_q\) 为 \(D_Q\) 的第 \(q\) 个对角元，
\(\mu_\sigma=d_R-\rho_\sigma\)，且
\(v_q=P_RA_a^\sigma e_q\)。相对于旧标量扣除
\(\mu_\sigma^{-1}\sum_{q\ge R}v_qv_q^*\)，(4) 恢复半正定因子

\[
E^\sigma
=\sum_{q\ge R}
\left(\frac1{\mu_\sigma}-\frac1{d_q-\rho_\sigma}\right)v_qv_q^*
\succeq0.
\tag{5}
\]

证书只保留 \(280\le q<1000\)。其余项仍为半正定，故删除它们只会降低
下模型。

## PSD 子因子与真正的 Schur 更新

把旧 Householder 分块写为

\[
\mathcal A_0=
\begin{pmatrix}A&X\\X^*&C\end{pmatrix},
\qquad C>0,
\qquad S=A-XC^{-1}X^*.
\]

对 (5) 的有限因子写 \(E=WW^*\)。任取 recovery-coordinate 空间中的
正交投影 \(\Pi\)，都有

\[
E_\Pi=W\Pi W^*\preceq E.
\tag{6}
\]

证书以一个整数 dyadic 行矩阵 \(Q\) 定义

\[
\Pi=Q^*(QQ^*)^{-1}Q.
\]

这里 \(Q\) 只定义一个精确 dyadic 子空间；它不被误认为精确奇异子空间，
也不是逐列 sequential truncation。设 \(W\Pi W^*=FF^*\)，并按旧分块写
\(F=(U,V)^T\)。由 Woodbury 恒等式，加入该 PSD 子因子后的真正 Schur 补为

\[
\boxed{
S_{\Pi}
=S+U_{\rm eff}(I+V^*C^{-1}V)^{-1}U_{\rm eff}^*,
\qquad
U_{\rm eff}=U-XC^{-1}V.}
\tag{7}
\]

旧交叉块 \(X\) 不可删除。证书还独立使用物理合同列

\[
Z=\binom I{-C^{-1}X^*}
\]

构造 \(Z^*W\)，并以 discarded core Gram 的 trace \(\tau\) 给出保守下界

\[
S_{\rm low}=S_\Pi-\tau I_5.
\tag{8}
\]

## 奇扇区证书

奇扇区取 recovery 空间中 weighted complement factor 的前 40 个数值奇异方向，
再冻结为分母 \(2^{64}\) 的 dyadic 行空间。192-bit Arb 直接重建全部振幅，
并严格得到

\[
\tau_-=[2.14\times10^{-37}\pm6.32\times10^{-40}].
\]

一次 \(275\times275\) verified solve 同时处理 40 个右端。对 (8) 作对称
选主元 LDL，排列为 \((4,1,3,0,2)\)，五个主元为

\[
\begin{aligned}
p_1^-&=2.1755738994065007\times10^{-12}\pm6.25\times10^{-40},\\
p_2^-&=1.8670665683706733\times10^{-17}\pm5.23\times10^{-40},\\
p_3^-&=2.3323401317928165\times10^{-22}\pm8.03\times10^{-40},\\
p_4^-&=1.15850779273\times10^{-28}\pm8.20\times10^{-40},\\
p_5^-&=7.192\times10^{-35}\pm3.26\times10^{-39}.
\end{aligned}
\tag{9}
\]

全部下端严格为正。

## 偶扇区证书

偶扇区采用 canonical graph-row 子空间

\[
\mathcal Q_+=\operatorname{row}(Z^*W),
\qquad\dim\mathcal Q_+=5,
\]

并冻结其 64-bit dyadic 近似。256-bit Arb 给出

\[
\tau_+
=3.30308743650502793237\times10^{-47}
\pm3.96\times10^{-68},
\]

以及两个独立 \(U_{\rm eff}\) 构造之间的 interval infinity-norm 半径
\(1.93\times10^{-60}\)。verified \(C\)-solve 只含五个右端。最终排列
\((4,3,1,0,2)\) 的主元为

\[
\begin{aligned}
p_1^+&=3.5326879157387503530\times10^{-15}\pm7.31\times10^{-68},\\
p_2^+&=1.2350480842465696677\times10^{-19}\pm7.14\times10^{-68},\\
p_3^+&=3.0046150678057488210\times10^{-25}\pm5.97\times10^{-68},\\
p_4^+&=9.8611918714517403483\times10^{-32}\pm4.92\times10^{-68},\\
p_5^+&=1.8305045371659722859\times10^{-38}\pm4.32\times10^{-67}.
\end{aligned}
\tag{10}
\]

全部下端严格为正。因此端点 \(a=\log3\) 的奇偶下模型均严格正，进而
\(A_{\log3}^\pm>0\)。

## 从缓存生成与复现

下列命令从头生成临时合同缓存、raw coupling 和 dyadic 子空间，再运行承重
Arb 证书：

```bash
uv run --with python-flint python \
  computations/verify_log9_prime_two_step_degree.py 256

uv run --with python-flint --with numpy python \
  computations/generate_log9_endpoint_contract_cache.py 192 280 500 - --export-small-map-only
uv run --with python-flint --with numpy python \
  computations/generate_log9_endpoint_contract_cache.py 256 280 500 + --export-small-map-only

uv run --with numpy --with scipy python \
  computations/generate_log9_weighted_raw_coupling.py - 1000
uv run --with numpy --with scipy python \
  computations/generate_log9_weighted_raw_coupling.py + 1000

OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
uv run --with numpy --with scipy python \
  computations/generate_log9_odd_rank40_basis.py

uv run --with python-flint --with numpy python \
  computations/generate_log9_even_contract_amplitudes.py 192
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
uv run --with numpy --with scipy python \
  computations/generate_log9_even_canonical5_basis.py

uv run --with python-flint --with numpy python \
  computations/verify_log9_odd_weighted_true_schur.py 192
uv run --with python-flint --with numpy python \
  computations/verify_log9_even_weighted_true_schur.py 256
```

承重的最终奇、偶脚本已分别完整运行，耗时约 163.5 秒和 214.5 秒；输出即
(9)--(10)。

## 域单调与结论边界

由零延拓的闭形式域嵌套和谱底单调性，端点严格正性传播到所有较小尺度，
得到 (1)--(2)。本结果仍是有限尺度定理，不证明全尺度 Weil 正性或 RH；它把
已严格排除的首次退化区间从 \((0,\frac12\log8]\) 推进到 \((0,\log3]\)。
