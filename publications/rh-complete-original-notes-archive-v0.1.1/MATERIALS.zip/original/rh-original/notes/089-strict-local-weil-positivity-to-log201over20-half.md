> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 局部 Weil 算子的严格正性推进到 \(\frac12\log(201/20)\)

日期：2026-08-14。

## 定理

设 \(A_a=A_a^+\oplus A_a^-\) 为支撑于 \((-a,a)\) 的局部 Weil 算子，并令

\[
a_*:=\frac12\log\frac{201}{20}
=1.1537863172525423788\ldots .
\]

则

\[
\boxed{A_a^+>0,\qquad A_a^->0,
\qquad 0<a\le a_*.}
\tag{1}
\]

因而

\[
\boxed{A_a>0\quad(0<a\le a_*),}
\qquad
\boxed{a_{\rm deg}>a_*.}
\tag{2}
\]

这把 [note 068](068-strict-local-weil-positivity-to-log10-half.md) 的完整正性端点
从 \(\frac12\log10\) 严格推进到 \(\frac12\log(201/20)\)。它仍是有限尺度定理，
不证明全尺度 Weil 正性或 RH。

## 1. Active prime 块与四步图界

在 \(e^{2a_*}=201/20\) 时，具有正测度 overlap 的非零 von Mangoldt 项为

\[
n=2,3,4,5,7,8,9.
\]

在奇偶半区压缩中，\(n=2,3\) 同时产生 translation 与 reflection，
\(n=4,5,7,8,9\) 只产生 reflection。对取绝对权的 active-prime 图算子
\(T\)，精确枚举支撑端点及其三次逆像；所有断点都保留为
\(\log2,\log3,\log5,\log7,\log11\) 的有理线性组合，Arb 只负责严格认证其顺序。
在 200 个开放 cells 上得到

\[
\sup T^4\mathbf1
=73.81706267887072825278218608055047\ldots .
\tag{3}
\]

Schur test 与自伴性给出两个扇区共同的严格界

\[
\boxed{
\|P^\sigma\|
\le(\sup T^4\mathbf1)^{1/4}
=2.9311577357008463978993\ldots<2.931158.}
\tag{4}
\]

以下固定使用安全有理上界 \(\rho_{\rm p}=2.931158\)。

这里 (3)--(4) 的四步枚举实际在较大的窗口
\(a_{11}=\frac12\log11\) 上完成；\(n=11\) 的端点 overlap 为零。记
\(\mathcal P_a^\sigma\) 为相应的 active-prime 压缩，零延拓给出

\[
\mathcal P_{a_*}^\sigma
=E^*\mathcal P_{a_{11}}^\sigma E,
\qquad
\|\mathcal P_{a_*}^\sigma\|
\le\|\mathcal P_{a_{11}}^\sigma\|.
\tag{4a}
\]

所以该较大窗口的图界合法控制本端点；它不是把有限 Fourier 压缩的数值范数外推到无限维。

## 2. 保留全部 cross 的 joint-sharp 下算子

令 \(B_0^\sigma\) 包含全部 active prime 块、\(n<500\) 的正 Yukawa atoms
以及 signed polar 项，并写

\[
L_0^\sigma=D^\sigma+B_0^\sigma.
\]

偶扇区 polar 为正，奇扇区 polar 为负；后者没有被删除。设

\[
\rho_+=\rho_{\rm p},
\qquad
\rho_-=\rho_{\rm p}+2(\sinh a_*-a_*).
\tag{5}
\]

取 \(P=P_{400}\)、\(Q=I-P\)，并令

\[
t_q^\sigma=d_q^\sigma-\rho_\sigma,
\qquad
T_\sigma=\sum_{q\ge400}t_q^\sigma
|e_q^\sigma\rangle\langle e_q^\sigma|.
\]

偶 Fourier 频率为整数，奇 Fourier 频率为 \(q+\frac12\)。严格区间值为

\[
\begin{array}{c|cc}
 &t_{400}&t_{2000}\\ \hline
+&2.2241103475079001111170\ldots&3.8335482936622747749833\ldots\\
-&1.6781988536098498939053\ldots&3.2866375490320533812928\ldots
\end{array}
\tag{6}
\]

故 \(T_\sigma>0\)。由 (4)--(5)，

\[
QL_0^\sigma Q-T_\sigma
=Q(B_0^\sigma+\rho_\sigma I)Q\succeq0.
\tag{7}
\]

现取一族真实全空间 Yukawa atoms \(F=B_F\oplus V\)，其中偶扇区取

\[
F_+=(r_{500}^+,\ldots,r_{563}^+),
\tag{8}
\]

奇扇区取

\[
F_-=(r_{500}^-,\ldots,r_{755}^-).
\tag{9}
\]

保留它们的低块和全部低--高 cross，只在高--高块删除 \(VV^*\)，得到

\[
\underline L_F^\sigma=
\begin{pmatrix}
PL_0^\sigma P+B_FB_F^*&PB_0^\sigma Q+B_FV^*\\
QB_0^\sigma P+VB_F^*&T_\sigma
\end{pmatrix}
\preceq L_0^\sigma+FF^*\preceq A_{a_*}^\sigma.
\tag{10}
\]

第一重差只存在于 \(Q\)-\(Q\) 块，由 (7) 与 \(VV^*\succeq0\) 得到；
第二重差是尚未加入的正 Yukawa 尾。因此 (10) 是 cutoff-free 的实际无限维
Loewner 下算子，不是有限压缩补零。

## 3. 联合 Parseval covariance 与尖锐尾支付

令

\[
c_q=PB_0^\sigma e_q^\sigma,
\qquad
v_q=V^*e_q^\sigma,
\qquad
U_q=c_q+B_Fv_q.
\tag{11}
\]

消去 \(Q\) 后需要支付

\[
\sum_{q\ge400}\frac{U_qU_q^*}{t_q^\sigma}.
\]

设 \(R_P=\sum_{q\ge400}c_qc_q^*\)、
\(X_F=PB_0^\sigma QV\)、\(G_Q=V^*V\)。完整 Parseval 恒等式给出

\[
\boxed{
R_{\rm tot}
=R_P+X_FB_F^*+B_FX_F^*+B_FG_QB_F^*
=\sum_{q\ge400}U_qU_q^*.}
\tag{12}
\]

在有限带 \(400\le q<2000\) 上精确计算

\[
R_1=\sum_{400\le q<2000}U_qU_q^*,
\qquad
G_1=\sum_{400\le q<2000}
\frac{U_qU_q^*}{t_q^\sigma}.
\tag{13}
\]

因为 \(t_q^\sigma\ge t_{2000}^\sigma\) 对 \(q\ge2000\) 成立，

\[
\sum_{q\ge2000}\frac{U_qU_q^*}{t_q^\sigma}
\preceq\frac{R_{\rm tot}-R_1}{t_{2000}^\sigma},
\qquad
R_{\rm tot}-R_1\succeq0.
\tag{14}
\]

若 \(P_0=PL_0^\sigma P-R_P/t_{400}^\sigma\) 是同源 scalar base，则最终有限
Schur 下界正是

\[
\boxed{
G_\sigma=P_0+\frac{R_P}{t_{400}^\sigma}+B_FB_F^*
-G_1-\frac{R_{\rm tot}-R_1}{t_{2000}^\sigma}.}
\tag{15}
\]

式 (12)--(15) 在形成任何绝对值上界前保留了 base--atom、atom--atom 以及
所有低坐标之间的 joint covariance；这正是从 \(\frac12\log10\) 推进端点时
承重的新结构。

## 4. 偶扇区的 \(7\oplus393\) 严格证书

对前 280 个坐标施加权威 \(R=280,N=500\) even graph 的七个 Householder
合同，再把 (15) 分为

\[
\mathbf R^7\oplus\mathbf R^{393}.
\]

192-bit interval Cholesky 给出补块的最小 pivot

\[
p_{\min}(C_{393})
=0.0477168081536839398409008924216\ldots>0.
\tag{16}
\]

verified solve 后，七维 true-Schur 的对称选主元排列为

\[
(6,5,1,3,2,0,4),
\]

其 pivots 为

\[
\begin{aligned}
&2.9571167114064320142\times10^{-10},\\
&1.5007180657693821331\times10^{-14},\\
&9.3138761249961177822\times10^{-20},\\
&1.2106021613589303941\times10^{-24},\\
&2.1408605144893824337\times10^{-30},\\
&1.138107739353\times10^{-36},\\
&[6.12555523455109,\,6.12563117488625]\times10^{-44}.
\end{aligned}
\tag{17}
\]

全部严格为正，故 \(G_+>0\)，由 (10) 得

\[
A_{a_*}^+>0.
\tag{18}
\]

## 5. 奇扇区的 \(6\oplus394\) 严格证书

奇 Fourier 基采用

\[
e_k^-(x)=\sqrt{\frac2{a_*}}
\sin\frac{(k+\frac12)\pi x}{a_*},
\]

奇 Yukawa atoms 为

\[
r_n^-(x)=
\frac{e^{-c_na_*}(e^{c_nx}-e^{-c_nx})}
{\sqrt{1+e^{-2c_na_*}}},
\qquad c_n=2n+\frac12.
\tag{19}
\]

负 polar、reflection 的奇扇区符号和半整数 digamma shift 均完整进入
(11)--(15)。施加六个权威 odd Householder 合同后分块为

\[
\mathbf R^6\oplus\mathbf R^{394}.
\]

192-bit interval Cholesky 给出

\[
p_{\min}(C_{394})
=0.0318635497558205447321128219329\ldots>0.
\tag{20}
\]

最终六维 true-Schur 的排列为

\[
(5,2,0,1,4,3),
\]

六个 pivots 为

\[
\begin{aligned}
&2.1374033904744172504\times10^{-12},\\
&4.1890092801027460874\times10^{-17},\\
&2.1675652438098660369\times10^{-22},\\
&3.8400356058264323718\times10^{-27},\\
&2.3443748215325568\times10^{-33},\\
&5.570519064\times10^{-40}\pm8.86\times10^{-50}.
\end{aligned}
\tag{21}
\]

从保存的 \(6\times6\) 球矩阵重新解析并独立执行同一 pivoted LDL，累积更宽的
舍入球后仍得到最后一个 pivot 下端

\[
5.57051906216755\times10^{-40}>0.
\tag{22}
\]

因此 \(G_->0\)，结合 (10) 得

\[
A_{a_*}^->0.
\tag{23}
\]

## 6. 合并、域单调与结论边界

由 (18)、(23) 及奇偶分解，\(A_{a_*}>0\)。再由
[note 003](003-zero-extension-and-full-spectrum-monotonicity.md) 的闭形式域零延拓与
min--max 单调性，端点正性传播到全部 \(0<a\le a_*\)，得到 (1)。
[note 006](006-norm-resolvent-continuity-and-spectral-flow.md) 的谱底连续性
再给出 (2) 中的严格首次退化下界。

本结论没有把有限矩阵正性外推为无限维结论：无限维提升完全由 (7)、(10)、
(12) 和 (14) 的 Loewner/Parseval 恒等式承担。它也没有控制 \(a>a_*\)，更不证明
全尺度正性或 RH。

## 7. 复现与文献边界

晋级后的最小证书、生成源码、原始日志与 SHA-256 见
[`computations/bundles/log201over20-local-weil-positivity`](../computations/bundles/log201over20-local-weil-positivity/README.md)。

截至 2026-08-14，最近邻边界如下：

- Masatoshi Suzuki, *Weil's quadratic form via the screw function*,
  [arXiv:2606.09096](https://arxiv.org/abs/2606.09096)，建立局部闭 Weil 算子、
  离散谱、连续性及充分小尺度正性；没有给出本文端点。
- Akiva Groskin, *A finite Guinand--Weil dictionary and archimedean tail order for the
  truncated Weil quadratic form*,
  [arXiv:2607.02828](https://arxiv.org/abs/2607.02828)，建立有限 Galerkin 字典与
  archimedean cutoff 尾序；其文中明确不声称完整 Weil 正性，且不覆盖本文
  cutoff-free 的固定区间 \(A_a\) 下算子。
- Breno Wilson de Andrade Silva 的 prime Loewner/parity sign note
  ([DOI 10.5281/zenodo.20710075](https://doi.org/10.5281/zenodo.20710075)) 与 pole
  rank-two/Perron note
  ([DOI 10.5281/zenodo.20682834](https://doi.org/10.5281/zenodo.20682834)) 给出
  可迁移的符号和秩结构，但都明确不闭合完整 \(A_a\) 正性。

因此本文的新点是：对实际 cutoff-free \(A_a\) 构造 joint-residual Loewner 下算子，
保留负 odd polar、full-space Yukawa 的 base--atom--atom cross，并用 192-bit
interval true-Schur 证书严格闭合端点 \(a_*\)。
