> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一个六次正 detector 消去首个 collective residue

日期：2026-08-14。

依赖：
[note 118](118-an-endpoint-flat-detector-gives-an-exact-positive-reciprocal-product-rh-gate.md)、
[note 126](126-the-endpoint-flat-rh-kernel-has-two-independent-collective-residues.md)、
[note 136](136-endpoint-flat-polynomial-detectors-have-a-nontrivial-positive-kernel-cone.md)。

证据等级：精确 Mellin 变换、六次 Faulhaber 因式分解与最小次数证明。

note 126 的三次正核具有 \(s=-1\) 与 \(s=-3\) 两个 collective residues。
本文构造一个仍逐项非负的六次核，其 \(s=-1\) residue 精确消失，并证明
次数六是这种现象的最小次数。

## 1. Detector

令

\[
H(u)=u^2(1-u)^4\mathbf1_{(0,1)}(u),
\tag{1}
\]

\[
\begin{aligned}
V(u)
&=(-u\partial_u-1)H(u)\\
&=u^2(1-u)^3(7u-3)\\
&=-3u^2+16u^3-30u^4+24u^5-7u^6,
\qquad 0<u<1,
\end{aligned}
\tag{2}
\]

并在区间外取零。则

\[
V(0+)=V(1-)=0,\qquad \int_0^1V(u)\,du=0.
\tag{3}
\]

其 Mellin 变换为

\[
\boxed{
K_V(s)
=(s-1)B(s+2,5)
=\frac{24(s-1)}
{(s+2)(s+3)(s+4)(s+5)(s+6)}.}
\tag{4}
\]

所以 \(K_V\) 在 \(1/2<\Re s<1\) 零自由。

## 2. 精确非负 Faulhaber 核

定义

\[
P_V(y)=\sum_{c\le y}V(c/y).
\tag{5}
\]

写 \(y=N+r\)，其中 \(N=\lfloor y\rfloor\ge1\)、\(0\le r<1\)。
前六个幂和给出

\[
\boxed{
P_V(N+r)
=\frac{N(N+1)}{6(N+r)^6}F_N(r),}
\tag{6}
\]

\[
\boxed{
F_N(r)
=(N-1)\bigl[1-6r^2(1-r)^2\bigr]
+3r^3(4-3r).}
\tag{7}
\]

因 \(r^2(1-r)^2\le1/16\)，

\[
1-6r^2(1-r)^2\ge\frac58,
\qquad
3r^3(4-3r)\ge0.
\tag{8}
\]

故

\[
\boxed{P_V(y)\ge0\qquad(y\ge1).}
\tag{9}
\]

## 3. 正 reciprocal-product RH 门

置

\[
U_V(x)=\sum_n\mu(n)V(n/x),
\tag{10}
\]

\[
T_V(x)=
\sum_{a,b\le\sqrt x}\mu(a)\mu(b)
P_V\!\left(\frac{x}{ab}\right).
\tag{11}
\]

精确截断卷积恒等式给出

\[
U_V(x)=2A_V(x)-T_V(x),
\qquad
A_V(x)=\sum_{n\le\sqrt x}\mu(n)V(n/x).
\tag{12}
\]

因 \(V(u)=O(u^2)\) 于 \(0\)，

\[
|A_V(x)|
\ll
\sum_{n\le\sqrt x}\frac{n^2}{x^2}
\ll x^{-1/2}.
\tag{13}
\]

所以

\[
\boxed{T_V(x)=-U_V(x)+O(x^{-1/2}).}
\tag{14}
\]

由 (4)、note 101 的 Mellin detector 定理及 (14)，

\[
\boxed{
\mathrm{RH}
\iff
\forall\varepsilon>0,\quad
T_V(x)\ll_\varepsilon x^{1/2+\varepsilon},}
\tag{15}
\]

并且 (15) 可等价替换为 dyadic \(L^2\) 门。核 (6)--(7) 逐项非负。

## 4. Residue 移位

因为 \(V\) 没有一次项，

\[
\operatorname*{Res}_{s=-1}K_V(s)=0.
\tag{16}
\]

在负偶数处，\(K_V\) 的极点被 zeta 的 trivial zeros 消去。非零 polynomial
residues 只位于 \(s=-3,-5\)：

\[
\operatorname*{Res}_{s=-3}K_V(s)=16,\qquad
\zeta(-3)=\frac1{120},
\tag{17}
\]

\[
\operatorname*{Res}_{s=-5}K_V(s)=24,\qquad
\zeta(-5)=-\frac1{252}.
\tag{18}
\]

若

\[
S_k(z)=\sum_{a\le z}a^k\mu(a),\qquad z=\sqrt x,
\tag{19}
\]

则剥离全部非零均值周期项后，

\[
\boxed{
T_V(x)
=\frac{2S_3(z)^2}{15x^3}
-\frac{2S_5(z)^2}{21x^5}
+T_V^{(0)}(x),}
\tag{20}
\]

其中 \(T_V^{(0)}\) 的周期系数均值为零。因而 collective skeleton 从
\((S_1,S_3)\) 精确移到 \((S_3,S_5)\)。

## 5. 次数六的最小性

设一般多项式 \(V\) 满足

\[
V(0)=V(1)=\int_0^1V(u)\,du=0,
\qquad
V'(0)=0,
\tag{21}
\]

且 \(P_V(y)\ge0\) 对所有 \(y\ge1\) 成立。Euler--Faulhaber 展开首先给出

\[
P_V(N+r)
=\frac{B_2(1-r)}{2N}V'(1)+O(N^{-2}).
\tag{22}
\]

\(B_2(1-r)\) 在 \(0\le r\le1\) 上变号，故非负性迫使 \(V'(1)=0\)。
下一项为

\[
P_V(N+r)
=\frac{B_3(1-r)}{6N^2}V''(1)+O(N^{-3}),
\tag{23}
\]

而 \(B_3\) 同样变号，所以 \(V''(1)=0\)。结合 (21)，

\[
u^2(1-u)^3\mid V(u).
\tag{24}
\]

若 \(\deg V\le5\)，则只能

\[
V(u)=c\,u^2(1-u)^3.
\tag{25}
\]

但

\[
\int_0^1u^2(1-u)^3\,du=B(3,4)=\frac1{60},
\tag{26}
\]

故零均值迫使 \(c=0\)。因此：

\[
\boxed{
\deg V\le5,\ P_V\ge0,\ \operatorname*{Res}_{s=-1}K_V=0
\Longrightarrow V=0,}
\tag{27}
\]

而 (2) 在次数六达到非零情形。

## 6. 边界

对任意固定 \(k\ge1\)，平方根强度的 \(S_k\) 界仍与 RH 等价。因此
(20) 没有证明 RH；它严格证明的是：逐项非负 reciprocal-product detector
可以删除首个 RH-strength collective residue，且最小次数恰为六。后续问题是
能否继续把首个奇 residue 向左推移，或证明正性在 \(p=2\) 后停止。
