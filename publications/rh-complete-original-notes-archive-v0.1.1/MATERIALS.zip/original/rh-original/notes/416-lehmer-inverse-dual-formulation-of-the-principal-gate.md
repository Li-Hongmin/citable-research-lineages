> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 416. Lehmer 逆矩阵把 principal gate 写成局部 Sobolev 对偶

## 1. 精确的三对角逆

令
\[
L_N(i,j)=\frac{\min(i,j)}{\max(i,j)},\qquad 1\le i,j\le N.
\]
直接消元得到 \(L_N^{-1}\) 为三对角矩阵：
\[
 (L_N^{-1})_{i,i+1}=-\frac{i(i+1)}{2i+1},
\]
\[
 (L_N^{-1})_{i,i}=\frac{4i^3}{4i^2-1}\quad(i<N),
 \qquad
 (L_N^{-1})_{N,N}=\frac{N^2}{2N-1}.
\]
等价地，对任意实向量 \(x\)，
\[
\begin{aligned}
\mathcal E_N(x):=x^*L_N^{-1}x
={}&\sum_{i=1}^{N-1}\frac{i(i+1)}{2i+1}|x_{i+1}-x_i|^2 \\
&+\sum_{i=1}^{N-1}\frac{2i}{(2i-1)(2i+1)}|x_i|^2
 +\frac{N}{2N-1}|x_N|^2 .
\end{aligned}
\tag{1}
\]
这是一条完全局部的离散 Sobolev 能量；有理数脚本
`computations/verify_lehmer_inverse_factorization.py` 对小规模矩阵逐项核验。

## 2. principal filter 的精确对偶式

令
\[
 a_m^{(Y)}=2\mu(m)\mathbf1_{m\le Y}
 -\mathbf1_{2\mid m}\mu(m/2)\mathbf1_{m\le2Y},
 \qquad N=2Y.
\]
由正定矩阵的 Legendre 对偶恒等式，note 409 的主部满足
\[
\begin{aligned}
Q_w(Y)
&=\frac12(a^{(Y)})^*L_Na^{(Y)}\\
&=\sup_{x\in\mathbb C^N}
 \left\{(a^{(Y)})^*x-\frac12\mathcal E_N(x)\right\}\\
&=\sup_x\left\{
 \sum_{m\le Y}\mu(m)\bigl(2x_m-x_{2m}\bigr)
 -\frac12\mathcal E_N(x)\right\}.
\end{aligned}
\tag{2}
\]
最后一行是有限截断下的精确恒等式，不是估计。

## 3. 新的算术接口与边界

式 (2) 将原问题改写为：对所有具有局部能量 \(\mathcal E_N\) 的测试函数，
控制 Möbius 对偶配对
\[
 \sum_{m\le Y}\mu(m)(2x_m-x_{2m}).
\]
若只对 \(g_m=2x_m-x_{2m}\) 使用 PNT/经典零自由区的 Abel 估计，得到的仍是
\(Y^{2-o(1)}\)；它不会产生固定幂次节省。要达到
\(Q_w\ll Y^{1+\varepsilon}\)，必须对这整个局部 Sobolev 测试类建立新的
Möbius signed intertwiner，尤其要控制其高频局部模态。

因此 (2) 不是 RH 的新证明，但给出了比逐项 Lehmer 分块更窄的下一道门：
问题不再是抽象正核，而是带明确三对角惩罚的 dyadic Möbius 对偶估计。

## 4. 一个可审计的低频下界

在 (2) 中取常向量 \(x_i=t\)。此时
\(2x_m-x_{2m}=t\)，所以对任意实数 \(t\)，
\[
Q_w(Y)\ge tM(Y)-\frac{t^2}{2}\mathcal E_{2Y}(\mathbf1).
\]
而
\[
\mathcal E_N(\mathbf1)
=\sum_{i=1}^{N-1}\frac{2i}{4i^2-1}+\frac{N}{2N-1}
=\frac12\sum_{i=1}^{N-1}
\left(\frac1{2i-1}+\frac1{2i+1}\right)+\frac{N}{2N-1}
\asymp\log(2N).
\]
优化 \(t\) 得到严格下界
\[
\boxed{\quad Q_w(Y)\ge
\frac{|M(Y)|^2}{2\mathcal E_{2Y}(\mathbf1)}
\gg \frac{|M(Y)|^2}{\log(2Y)}.\quad}
\tag{3}
\]
这说明 principal filter 虽在 Mellin 零频有零点，仍保留一个显式的低频
Mertens 通道；该通道不会自动产生平方根上界。式 (3) 只给下界，不能替代
对 Möbius 对偶配对的上界证明。
