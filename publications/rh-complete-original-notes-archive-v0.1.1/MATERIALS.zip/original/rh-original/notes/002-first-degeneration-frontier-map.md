> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 第一次退化及邻接机制的前沿文献图

检索日期：2026-08-11。范围由 ChatGPT 对话“黎曼猜想进展”中的实际数学路线确定：局部 Weil
形式第一次退化、有限 prime-shift、边界/唯一延拓、正核分解、有限自伴近似、谱流，以及可能提供
额外算术信息的 pair correlation 与 zero-density 工作。本文是研究地图，不把摘要筛选结果晋级为
定理前提。

> **同日推进后的状态。** note 004 已完成定义域桥；note 005 关闭了标准 positivity-preserving
> 基态路线；note 006 已建立全谱连续性和 spectral flow；note 007 已证明 finite Dirac shifts 下的
> \(L^\infty\) 晋级并接通最优边界阶上界；note 008 已把严格谱底单调精确归约为
> ground-state collar UCP。下文的原始优先级应结合这些后续结果阅读。

## 一、主承重链：局部 Weil 形式

承重链为

\[
\text{Weil 正性}
\longrightarrow
\text{Yoshida 局部化}
\longrightarrow
\text{Bombieri 变分问题}
\longrightarrow
\text{Connes--Consani 闭形式}
\longrightarrow
\text{Suzuki }A_a,\lambda_a.
\]

Suzuki 2026 已使“RH 假则存在首次退化 ground state”成为严格归约。当前未解决的不是该归约，而是

\[
D(B_a)=H_0^1(-a,a)\subsetneq D(A_a)
\]

造成的定义域断点：有限 prime-shift 的强公式不能未经论证施加到 ground state 上。详见 note 001。

## 二、最直接的新接口：logarithmic Laplacian

Suzuki 形式的 Archimedean 主部具有 \(\log|D|\) 型符号，因此下列结果是目前离定义域问题最近的
邻域理论：

- Chen–Hauer–Weth 2023 把 logarithmic Laplacian 实现为高维加权局部扩张的边界算子，并证明弱
  唯一延拓；这提供了把非局部方程转成局部边界问题的候选机制。
- Hernández-Santamaría–López Ríos–Saldaña 2024 给出 Dirichlet logarithmic Laplacian 的最优
  边界正则性和 Hopf 型引理；这可能区分“form-domain 零模态”与“经典零边界零模态”。
- Chen–Véron 2020 给出 bounded-domain logarithmic Laplacian 的本征值估计，并说明纯
  Archimedean 算子在域变大时也可失去正性；因此 prime-threshold 刚性不能从纯主部单调性直接推出。

需要建立的真正桥是：这些结果对

\[
\log|D|+\text{光滑积分扰动}+\sum_{n\le e^{2a}}c_n(T_{\log n}+T_{-\log n})
\]

及 Suzuki 的具体 Friedrichs 实现是否稳定。现有文献摘要没有给出该结论。

## 三、screw function、正核与 de Branges 目标

Suzuki 2023 的 screw function 是把分布型 Weil 形式转成连续核的基础。其后两条条件性目标链为：

1. screw line 的范数恒等式/Gram 表示；
2. Weil Hilbert space 与 de Branges space 的同构及 Hilbert–Pólya 算子。

它们解释了“平方和分解”最终应长什么样，但主要结构以 RH 为前提，不能倒过来当作证明。可用的研究
问题应是有限尺度、有限素数核是否存在无条件 Gram 分解，以及该分解能否按 quadratic-form 或
operator norm 收敛；不能直接假设极限 Hilbert space 已存在。

## 四、有限谱逼近与收敛桥

Connes–Consani–Moscovici 一系工作提供：

- prolate/Sonin 空间与 zeta 零点计数渐近；
- semilocal Sonin 空间随有限 places 增长的稳定性；
- 有限素数自伴算子与正则化行列式的高精度数值吻合。

缺失桥仍是严格的谱或整函数局部一致收敛。Suzuki 2026 的有限区间全实零特征函数也面临相同类型
问题。这一簇适合作为主线失败后的备用路线；单纯提高数值零点精度不会改变数学判断。

Kim 等 2026 数值实现可提供 prime-free、prime-threshold 和人为 off-line 控制，但其结论应作为
探索计算的对照数据，而非定理输入。

## 五、谱流与整数 crossing witness

Booss-Bavnbek–Zhu 的一般谱流公式说明：连续的无界自伴 Fredholm 族在合适固定最大定义域和边界
条件下，可把谱流写成 Maslov 指数；弱内部唯一延拓是重要接口。这与对话希望用整数不变量抵抗
near-line 病态性相符。

但当前只有 \(\lambda_a\) 的连续性，尚无 \(A_a\) 的 gap/norm-resolvent 连续族结构，也没有固定最大
定义域。prime thresholds 虽使显式公式逐项变化，其总形式随 \(a\) 连续，不自动产生有限秩 crossing
公式。因此 spectral flow 目前是待建框架，不是可直接计算的不变量。

## 六、比例型零点文献：提供额外信息，但不能闭合 RH

对话中的 Claude 路线依赖或邻接以下发展：

- Baluyot–Goldston–Suriajaya–Turnage-Butterbaugh 2023/2025：无条件 Montgomery 型公式及
  horizontal pair-correlation 信息；
- Goldston–Lee–Schettler–Suriajaya 2025：PCC 甚至 Alternative Hypothesis 都可推出 density-one
  simple critical zeros；
- Tao–Trudgian–Yang 2025：改进 zero-density 与 zero-additive-energy 指数。

这组文献给出两个边界判断：

1. pair correlation 可以含有横向信息，因而可能帮助构造 depth-sensitive block penalty；
2. 不同全局相关模型仍可导向同一 density-one 结论，所以全局 pair data 不是单个离线零点的唯一
   局部指纹。即使得到 100% density，也不能推出没有稀疏反例。

zero-density 与 additive-energy 是尚未使用的信息源，但目前没有文献定理把它们转换成局部 Weil
ground state 的刚性，或转换成对话提出的 higher-trace/结构化不定块不等式。

## 七、概念饱和后的路线排序

本轮新增论文已经不再产生新的主机制；后续结果主要落在已有九类关系中。因此停止高召回扩展，保留
三个会改变下一步的精确问题：

1. **定义域桥（最高优先）**：识别 \(D(Q_W^a)\)、\(D(A_a)\) 的边界迹与 logarithmic regularity，
   并判断 ground state 是否能进入 \(H_0^1\) 或满足可用的弱 prime-shift 方程。
2. **扰动后唯一延拓**：检验 logarithmic-Laplacian 扩张/UCP 对有限平移与光滑积分扰动是否保持；
   若不保持，构造反例并关闭边界刚性路线。
3. **尺度族结构**：在固定区间缩放后，判断闭形式族是否具有足以定义 crossing form 或谱流的连续性。

只有第 1 项成功后，prime-threshold 数值图谱才可能对应一个正确的强/弱方程；只有第 2 或第 3 项
给出新的不变量，才值得升级平方和或 spectral-flow 路线。比例常数优化不进入当前主脉冲。

## 文献库入口

完整矩阵位于 ResearchLibrary：
`projects/riemann-local-weil-first-degeneration/literature-matrix.csv`。每条记录标明证据等级、原子主张、
适用边界及其与本项目的关系；PDF 是否存在与是否已经全文阅读分开记录。
