> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Reciprocal Hankel 的局部相位下界与剩余频率门

日期：2026-08-16。

本 note 把 reciprocal-product 二次型的低频部分写成一个严格的局部相位
下界。它说明：在最大 Mertens 点附近，Hankel 相位并不造成低频抵消；真正
未闭合的是其余频率，以及把二次型放回正确算术尺度时的 $N^2$ 尺度错位。

## 1. Fourier 恒等式

令

$$
p(u)={\bf1}_{u\ge0}P(e^u),
\qquad g(u)=\frac{p(u)+p(-u)}2,
$$

并采用

$$
g(u)=\frac1{2\pi}\int_{\mathbb R}h(t)e^{itu}\,dt.
$$

对整数 $N\ge2$，因为 $N^2/(ab)\ge1$（$a,b\le N$），有

$$
\begin{aligned}
T_P(N^2)
&:=\sum_{a,b\le N}\mu(a)\mu(b)P\!\left(\frac{N^2}{ab}\right)\\
&=\frac1\pi\int_{\mathbb R}h(t)N^{2it}
       \left(\sum_{n\le N}\mu(n)n^{-it}\right)^2dt.
\end{aligned}
\tag{1}
$$

置

$$
A_N(t):=N^{it}\sum_{n\le N}\mu(n)n^{-it}.
$$

则 $|A_N(t)|=|F_N(-t)|$，其中

$$
F_N(t)=\sum_{n\le N}\mu(n)n^{it},
$$

且 (1) 为 $T_P(N^2)=\pi^{-1}\int h(t)A_N(t)^2dt$。

## 2. 最大点的局部相位

令 $M(x)=\sum_{n\le x}\mu(n)$，取 $N_0\le X$ 使
$|M(N_0)|=M^*(X):=\max_{x\le X}|M(x)|$。Abel 分部求和给出

$$
A_{N_0}(t)=M(N_0)+itN_0^{it}
  \int_1^{N_0}M(u)u^{-it-1}\,du.
\tag{2}
$$

由于 $|M(u)|\le |M(N_0)|$ 对 $u\le N_0$，

$$
|A_{N_0}(t)-M(N_0)|
\le |t|\,|M(N_0)|\log N_0.
\tag{3}
$$

故当 $|t|\le(4\log N_0)^{-1}$ 时，写
$A_{N_0}(t)=M(N_0)+e(t)$，有 $|e(t)|\le|M(N_0)|/4$，从而

$$
\operatorname{Re}A_{N_0}(t)^2
\ge |M(N_0)|^2-2|M(N_0)||e(t)|-|e(t)|^2
\ge \frac7{16}|M(N_0)|^2.
\tag{4}
$$

若 $h(0)>0$，取固定 $c_0,\delta_0>0$ 使
$h(t)\ge c_0$ 于 $|t|\le\delta_0$。对充分大的 $N_0$，令
$\delta_N=(4\log N_0)^{-1}<\delta_0$。由 (4)，低频实部满足

$$
\frac1\pi\int_{|t|\le\delta_N}h(t)\operatorname{Re}A_{N_0}(t)^2dt
\ge \frac{7c_0}{32\pi\log N_0}|M(N_0)|^2.
\tag{5}
$$

这一步没有使用正 Gram，也没有把 $A_N(t)^2$ 错写成
$|A_N(t)|^2$；它只使用最大点带来的局部相位锁定。

## 3. 精确的剩余频率不等式

设

$$
E_{\mathrm{out}}(N_0):=
\int_{|t|>\delta_N}|h(t)|\,|F_{N_0}(t)|^2dt.
$$

由 (1) 的实数值、(5) 及三角不等式，得到严格不等式

$$
\boxed{
|M(N_0)|^2
\le \frac{32\pi}{7c_0}\log N_0
\left(|T_P(N_0^2)|+\frac1\pi E_{\mathrm{out}}(N_0)\right).}
\tag{6}
$$

因此，若某条新算术桥能够同时给出

$$
|T_P(N^2)|+E_{\mathrm{out}}(N)\ll_\varepsilon N^{1+\varepsilon}
\quad\text{对所有 }N,
\tag{7}
$$

则 (6) 立即给出 $M(N)\ll_\varepsilon N^{1/2+\varepsilon}$，进而推出 RH。

## 4. 为什么这还没有关闭 RH

式 (6) 只消除了“低频 Hankel 相位可能完全抵消”的误解；它没有给出
(7)。对固定 detector，已知的卷积关系是

$$
T_P(x)=-U_V(x)+O(x^{-1/2}),
\qquad U_V(x)=\sum_{n\ge1}\mu(n)V(n/x),
$$

所以零自由区只能在 $x=N^2$ 给出约
$N^2\exp[-c(\log N)^{3/5}(\log\log N)^{-1/5}]$ 的尺度；这比 (7) 大一个
幂次。直接用 (6) 的 reciprocal Hankel 路线因此存在严格的尺度错位：
控制 $U_V(N^2)$ 不是控制 $M(N)$。

当前最薄的未决命题仍是原始 half-lattice 的 signed energy/intertwiner，或
一个能够把 $T_P(N^2)$ 的 $N^2$ 算术尺度压回 $N^{1+\varepsilon}$ 的
跨尺度恒等式。本文不声称 RH。
