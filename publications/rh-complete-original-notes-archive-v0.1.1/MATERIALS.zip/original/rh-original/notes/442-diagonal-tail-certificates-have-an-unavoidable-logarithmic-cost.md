> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 对角尾能量线性证书的不可避免对数代价

日期：2026-08-17。

本 note 把 notes 346--347、441 中的尾坐标写成一个最小范数定理。结论是：
只使用各尺度尾的对角正能量，任何恢复未加权 Möbius 和的线性证书都必然支付
\(\asymp\log N\)；要继续推进 RH，必须加入真正的跨尺度 signed 相关或除数
intertwiner。

## 1. 尾坐标的精确对角化

令
\[
A_k(N):=\sum_{k<n\le N}\frac{\mu(n)}n,
\qquad 1\le k<N.
\]
由三角因子化 \(K_N=R_N^TR_N\) 逐项得到
\[
\boxed{\frac{I_N}{\pi}=\sum_{k=1}^{N-1}(2k+1)A_k(N)^2.}
\tag{1}
\]
同时有限交换求和给出
\[
\boxed{M(N)-1=2A_1(N)+\sum_{k=2}^{N-1}A_k(N).}
\tag{2}
\]
这里 (1)--(2) 是有限维恒等式，不使用 RH。

## 2. 对角 Hilbert 空间中的最小常数

在 \(\mathbb R^{N-1}\) 上定义
\[
\langle A,B\rangle_W:=\sum_{k=1}^{N-1}(2k+1)A_kB_k.
\]
式 (2) 的系数向量为
\[
c=(2,1,1,\ldots,1).
\]
因此，对所有实向量 \(A\)，Cauchy--Schwarz 的最佳常数唯一确定为
\[
\sup_{A\ne0}\frac{|c\cdot A|^2}{\langle A,A\rangle_W}
=c^TW^{-1}c
=\frac43+\sum_{k=2}^{N-1}\frac1{2k+1}.
\tag{3}
\]
特别地，若把 (2) 拆成若干线性组合后分别套用局部尾能量 (1)，
再用普通 Cauchy--Schwarz 合并，则所得常数仍不小于 (3)：所有这类拆分
只是同一个对角 Hilbert 空间中的另一种表示，不能降低其对偶范数。

等号向量可显式写出。取
\[
A_1^*=\frac23,\qquad A_k^*=\frac1{2k+1}\quad(2\le k<N),
\]
并令 \(A_N^*=0\)，由
\(x_n=n(A_{n-1}^*-A_n^*)\) 得到对应的实系数向量
\[
x_2=\frac{14}{15},\qquad
x_n=\frac{2n}{(2n-1)(2n+1)}\quad(3\le n<N),\qquad
x_N=\frac{N}{2N-1}.
\tag{4}
\]
它精确饱和 (3)。这个见证向量具有 \(x_n\asymp n^{-1}\) 的分数权重，
而不是 Möbius 的整数值；因此仅凭正能量的矩阵结构无法排除该方向。

## 3. 对 RH 路线的边界

式 (3) 严格关闭一个常见捷径：把局部调和尾不等式、有限次重新分组和
正的 Cauchy--Schwarz 叠加，不能从 \(\log N\) 评价常数中得到额外幂次。
要改善 (3)，必须使用不在 (1) 对角形式中可见的信息，例如

* Möbius 符号在不同 \(k\) 尾之间的 signed 相关；或
* 除数恒等式 \(D\mu=e_1\) 与 Lehmer 形式之间的非对角 intertwiner。

这两类输入都超出局部正能量本身；它们若能给出
\(I_N\ll_\varepsilon N^{1+\varepsilon}\)，按 notes 438--440 即精确达到 RH
门，而不是一个较弱的无条件估计。本文不把 (3) 当作 RH 证明，只把当前
正能量路线的最小可改进位置固定下来。
