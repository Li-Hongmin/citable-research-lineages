> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Averaged Chowla 不能把固定 Mellin 核能量推进到固定幂次

日期：2026-08-15。

本 note 检查 note 200--201 的
\[
 E_N(w)=\sum_{m,n\le N}\mu(m)\mu(n)
 K\!\left(\log\frac mn\right)
\]
是否可借助 averaged Chowla 或 dyadic shifted-correlation 直接得到
\(N^{2-\delta}\)（固定 \(\delta>0\)）。结论是：现有平均定理至多给
对数级节省，而且还缺一个把端点相关转成加权最大部分和的接口；不能据此
声称固定幂次。

## 1. 同一 dyadic 壳的精确移位展开

取 \(X\le m,n\le2X\)，令 \(h=n-m\)。则该壳的非对角部分为
\[
 \mathcal E_X=
 \sum_{1\le h\le X}
 \sum_{X<m\le2X-h}
 \mu(m)\mu(m+h)\,
 W_{X,h}(m),
 \qquad
 W_{X,h}(m)=K\!\left(\log\frac m{m+h}\right),
\tag{1}
\]
加上共轭的反向壳。若 \(K\) 有界 Lipschitz，则
\[
 \|W_{X,h}\|_\infty\le \|K\|_\infty,\qquad
 \operatorname{Var}_{[X,2X-h]}W_{X,h}
 \ll \|K'\|_\infty\,\frac hX\le \|K'\|_\infty .
\tag{2}
\]
因此 Abel 分部求和把 (1) 控制到
\[
 |\mathcal E_X|
 \ll_K \sum_{h\le X}
 \sup_{X\le Y\le2X-h}
 \left|\sum_{X<m\le Y}\mu(m)\mu(m+h)\right|.
\tag{3}
\]
这里出现的是对 \(h\) 的**最大部分和**，而非只在一个端点取值的
\(\sum_{m\le X}\mu(m)\mu(m+h)\)。这就是固定 ratio-kernel 的首个接口缺口。

不同 dyadic 壳 \(I_j,I_{j+d}\) 只把 \(h\) 换成随 \(m\) 移动的区间
\(n-m\asymp(2^d-1)m\)，并不会消除 (3) 的最大部分和要求。

不过这个“最大”并非不可绕过：若先用固定 \(C^1\) dyadic partition of unity
替代硬端点，使每个 \(W_{X,h}\) 在边界消失，则 Abel 公式中的边界项消失，
而
\[
 |W'_{X,h}(m)|\ll_K \frac{1+h/X}{X}.
\]
交换 \(m\)-积分与 \(h\)-求和后，只需在每个 \(m\)-截点使用 averaged Chowla
的无权 \(\sum_h|C_h(m)|\)；因 \(h\le X\)，上述导数的 \(h/X\) 因子至多损失
一个常数，整体仍为 \(X^2\rho(X)\)。因此平滑化可以把 (3) 的最大部分和缺口
降为技术性接口，但不能把其对数衰减 \(\rho(X)\) 提升为固定幂次。

## 2. 已知 averaged Chowla 的尺度

Matomäki--Radziwiłł--Tao 的 averaged Chowla 定理（原始版本
<https://arxiv.org/abs/1503.05121>，Theorem 1.1）给出
\[
 \sum_{h\le H}
 \left|\sum_{n\le Y}\lambda(n)\lambda(n+h)\right|
 \ll YH\left(
 \frac{\log\log H}{\log H}
 +\frac1{\log^{1/3000}Y}\right),
 \qquad 10\le H\le Y ,
\tag{4}
\]
并说明可推广到更一般的有界乘法函数；\(\mu\) 的对应平均结论属于同一
框架。即便把 (4) 无损地增强为所需的最大部分和版本，取 \(H\asymp Y\)
也只会给
\[
 |\mathcal E_X|
 \ll_K X^2\left(
 \frac{\log\log X}{\log X}
 +\frac1{\log^{c}X}\right),
\tag{5}
\]
即 \(X^{2-o(1)}\)，不是 \(X^{2-\delta}\)。

后续关于两点 Chowla 的定量改进仍是固定对数幂节省；例如 Pilatte 的综述明确
指出现有技术的节省停留在 \((\log X)^{-c}\) 量级：
<https://orbi.umons.ac.be/bitstream/20.500.12907/48033/1/2310.19357.pdf>。
这些结果不能替代 (3) 所需的固定核加权最大相关估计。

## 3. 固定幂次所需的最小新命题

若沿着“先按 \(h\) 分解、再对移位相关取绝对值”的路线推进，
一条足以给出固定幂次的算术输入至少应形如
\[
 \sum_{h\le H}
 \sup_{Y\le X}
 \left|\sum_{n\le Y}\mu(n)\mu(n+h)\right|
 \ll XH^{1-\delta}
 \quad(H\asymp X),
\tag{6}
\]
或直接给出带 \(W_{X,h}\) 的算子型估计
\[
 \sum_{h\le X}
 \left|\sum_m\mu(m)\mu(m+h)W_{X,h}(m)\right|
 \ll_K X^{2-\delta}.
\tag{7}
\]
(6) 比目前 averaged Chowla 的 \(XH\log^{-c}X\) 强一个固定幂次，
而且还要解决 \(Y\)-最大化和 \(m\)-依赖权。没有 (6)/(7)，Bernstein/Jackson
逼近只是在每个有限秩基上使用 Mertens 零自由区，最多产生
\(N^2e^{-c\Lambda(N)}=N^{2-o(1)}\)。

因此当前严格结论是：averaged Chowla 可作为进一步的对数节省接口，但沿此
绝对值路线不能导出固定幂次；若要过 note 192 的平方根门，仍需新的 signed
prime/reflection intertwiner、直接跨 \(h\) 的谱消去，或同等强度的二点 Möbius
相关定理。

## 4. 2026-08-16 文献复核

2026 年 7 月提交的 Menon 预印本
<https://arxiv.org/abs/2607.15574> 的摘要说明其改进了
Matomäki--Radziwiłł 方法，并给出 averaged Chowla 的改进界；但摘要仍将对象表述为
短区间乘法函数平均，未给出本项目所需的固定 Mellin 比值核
\[
\sum_{m,n\le N}\mu(m)\mu(n)K(\log(m/n))
\]
的 \(N^{1+\varepsilon}\) 或固定幂次次二次估计。故在未逐项重建其定理到
\(m\)-依赖权 \(K(\log(m/(m+h)))\) 的转移前，不把该新结果升级为当前能量门的算术输入。
## 5. Menon 预印本定理的精确适用边界

对该预印本的 HTML 正文作了逐条核对。其 Theorem 1.1 的对象是

\[
 \frac1X\int_X^{2X}
 \left|\frac1h\sum_{x\le n\le x+h}\chi(n)\lambda(n)\right|^2dx,
\]

在 \(q\le(\log X)^B\) 时给出

\[
 \ll_B \frac{(\log\log h)^2}{(\log h)^2}
       +\frac{(\log\log X)^4}{(\log X)^2},
 \qquad X\ge h\ge10.
\]

并明确说明 Möbius 版本可类似得到。Theorem 1.4--1.5 随后把该改进传到
指数和与 averaged Chowla，但仍保留对 \(h\) 或多个移位的平均；正文还说明该
Matomäki--Radziwiłł 方法在此尺度上基本达到自身阈值。

这与本项目的固定核能量

\[
 E_N(K)=\sum_{m,n\le N}\mu(m)\mu(n)
 K\!\left(\log\frac mn\right)
\]

不是同一个量：后者要求对所有宏观比值壳同时保留 \(m\)-依赖权的跨移位符号，
而 Theorem 1.1 的积分平均不能直接提供该加权二次型的
\(N^{1+\varepsilon}\) 或固定幂次上界。因而 Menon 结果应登记为“对数级接口改进”，
而不是 RH 能量门的算术输入。来源：<https://arxiv.org/html/2607.15574v1>。

## 6. 对精确 Lehmer 核的后续修正

上述“权重转移仍有接口缺口”的表述对任意光滑
\(K(\log(m/n))\) 仍适用，但对本项目的特殊核
\[
 L_N(m,n)=\frac{\min(m,n)}{\max(m,n)}
\]
需要收紧。MRT Theorem 1.6 的强化式 (1.11) 允许第一因子为乘法函数、
第二因子为任意 \(1\)-bounded 函数；利用
\[
 \frac{m}{q}=1-\frac{q-m}{q}
\]
可把 \(B/q\) 直接并入第二因子，并用两个不重不漏的长度-\(B\) 窗口覆盖
每个 dyadic 交叉块。由此，notes 349 给出了严格的
\[
 \boldsymbol\mu_N^T L_N\boldsymbol\mu_N
 \ll N^2\left(
 \frac{\log\log N}{\log N}
 +\frac1{\log^{1/3000}N}\right)^{1/2}+N\log N.
\]
这纠正了本 note 对“必须先处理最大部分和”的过强判断，但只得到
\(N^{2-o(1)}\)；固定幂次和平方根门仍未关闭。对一般 Mellin 核的结论
不因这一特殊 Lehmer 分解而改变。见
notes/349-mrt-dyadic-lehmer-energy-log-saving.md。

补充修正：note 350 发现对精确 Lehmer 核无需跨尺度窗口。按
\(h=q-m\) 分成 \(H<h\le2H\)，并写
\[
 \frac hq=\frac Hq+\frac{h-H}{H}\frac Hq .
\]
在该段中 \(H/q\) 是 \(1\)-bounded 函数，故 MRT (1.11) 可直接给出更强的
\[
 \boldsymbol\mu_N^T L_N\boldsymbol\mu_N
 \ll N^2\left(
 \frac{\log\log N}{\log N}
 +\frac1{\log^{1/3000}N}\right)+N\log N.
\]
所以本 note 中的 \(\rho_N^{1/2}\) 只应视为中间结果；最终仍是
\(N^{2-o(1)}\)，并未跨过 RH 等价的平方根门。
