> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 连续 cutoff 平均分裂为端点与斜率方差

日期与检索截止：2026-08-13。

依赖：[note 065](065-barban-vehov-hminus1-obstruction-and-weak-mertens-bridge.md)、
[note 074](074-mellin-poles-force-dyadic-mean-shell-growth.md)。

## 1. 弄清问题

note 074 把 RH 充分条件降为

\[
\boxed{
\sum_{Y<N\le2Y}I_N
\ll_\varepsilon Y^{3+\varepsilon},
\qquad
I_N:=\int_N^{2N}|D_N(y)|^2dy.
}
\tag{1}
\]

平凡界为 \(Y^4\)。本 note 检查两个历史上最接近“对 cutoff 本身平均”的对象：

\[
M(n,z)=\sum_{\substack{d\mid n\\d\le z}}\mu(d),
\qquad
\Sigma(U)=\sum_{d,e\le U}
\frac{\mu(d)\mu(e)}{[d,e]}
\log\frac Ud\log\frac Ue.
\tag{2}
\]

```mermaid
flowchart LR
  A["Letendre: average over z"] --> B["first shell forces z≥n/2"]
  B --> C["M(n,z)=-μ(n): trivial upper half"]
  D["Alterman: continuous Σ(U)"] --> E["complete lcm / H⁰"]
  E --> F["no cross-cutoff H⁻¹ control"]
  G["real cutoff X"] --> H["endpoint energy + slope variance"]
```

## 2. 历史 cutoff 平均在首壳上退化

Patrick Letendre 研究

\[
L_t(n):=\int_1^n M(n,z)^t\,dz.
\tag{3}
\]

对 squarefree \(n\) 与偶数 \(t\ge2\)，其 Theorems 1.1--1.2 给出

\[
L_t(n)
\le n\exp\!\left(O_t\!\left(
\frac{\omega(n)^{1-1/t}}{(\log_+\omega(n))^{1/t}}
\right)\right)
=n^{1+o(1)}.
\tag{4}
\]

这确实是非平凡的全截断参数矩估计；但首壳中每个增量指标满足

\[
N<m\le2N
\quad\Longrightarrow\quad
N\ge m/2.
\tag{5}
\]

若 \(m/2\le z<m\)，唯一可能大于 \(z\) 的因子是 \(m\)，故完整卷积直接给出

\[
\boxed{M(m,z)=-\mu(m).}
\tag{6}
\]

Selberg taper 又有精确 Hardy 表示

\[
\begin{aligned}
\log N\,q_N(m)
&=\sum_{\substack{d\mid m\\d\le N}}
\mu(d)\log\frac Nd\\
&=\int_1^NM(m,z)\frac{dz}{z}\\
&=\Lambda(m)+\mu(m)\log\frac mN
\qquad(N<m\le2N).
\end{aligned}
\tag{7}
\]

所以 Letendre 的全 \(z\)-范围消去在当前唯一使用的上半区间严格退化为 note 071 已知的
mixed-parity increment；不能提供累计 \(H^{-1}\) 的新抵消。

## 3. Alterman 的连续筛层仍是完整 \(H^0\)

Zuniga-Alterman 2022, Theorem 5.1 证明

\[
\boxed{
\Sigma_q(U)=\frac q{\varphi(q)}\log U-\mathfrak s_q
+O_q\!\left(\frac1{\log U}\right).
}
\tag{8}
\]

当 \(q=1\) 时，Jordan 分解给出正平方和

\[
\Sigma_1(U)
=\sum_{r\le U}\frac{\mu^2(r)\varphi(r)}{r^2}
\check m_r(U/r)^2,
\tag{9}
\]

其中

\[
m_a(x):=\sum_{\substack{n\le x\\(n,a)=1}}\frac{\mu(n)}n,
\qquad
\check m_a(x):=\sum_{\substack{n\le x\\(n,a)=1}}
\frac{\mu(n)}n\log\frac xn.
\tag{10}
\]

但在非整数点对 \(\log U\) 求导得到

\[
\dot\Sigma_1(U)
=2\sum_{r\le U}\frac{\mu^2(r)\varphi(r)}{r^2}
\check m_r(U/r)m_r(U/r),
\tag{11}
\]

没有固定符号。论文所谓 continuous/monotonic 指 cutoff profile，不是
\(U\mapsto\Sigma_q(U)\) 的逐点单调定理；也不能微分 (8) 的
\(O(1/\log U)\) 余项。

对 Selberg 权重，(8) 只恢复

\[
\sum_{d,e\le N}\frac{\lambda_{d,N}\lambda_{e,N}}{[d,e]}
=\frac1{log N}+O\!\left(\frac1{\log^2N}\right).
\tag{12}
\]

即使无损迁移到首壳再作离散 Hardy，也只有

\[
I_N\ll\frac{N^3}{\log N},
\qquad
\sum_{N\asymp Y}I_N\ll\frac{Y^4}{\log Y};
\tag{13}
\]

距 (1) 仍差 \(Y/\log Y\)。原因是 (12) 只有完整 lcm 的 \(H^0\) 密度，没有
跨 cutoff 的低频相关。

## 4. 实参数 cutoff 的精确导数

对实数 \(X\ge2\)，定义

\[
\lambda_{d,X}:=\mu(d)\left(1-\frac{\log d}{\log X}\right),
\qquad
D_X(y):=1+\sum_{d\le X}\lambda_{d,X}\left\{\frac yd\right\}.
\tag{14}
\]

新项在 \(X=d\) 激活时系数为零，故 \(X\mapsto D_X(y)\) 连续、局部绝对连续。几乎处处

\[
\boxed{
\partial_XD_X(y)
=\frac{T_X(y)}{X\log^2X},
\qquad
T_X(y):=sum_{d\le X}\mu(d)\log d\left\{\frac yd\right\}.
}
\tag{15}
\]

在 \(X=n\) 处只有斜率跳跃

\[
\partial_X^+D_n(y)-\partial_X^-D_n(y)
=\frac{\mu(n)}{n\log n}\left\{\frac yn\right\};
\tag{16}
\]

没有 Dirac 质量。若 \(X\le y\le2X\)、\(m=\lfloor y\rfloor\)，则卷积恒等式进一步给出

\[
\boxed{
T_X(y)
=y\sum_{d\le X}\frac{\mu(d)\log d}{d}
+\Psi(m)+J(m)-J(X).
}
\tag{17}
\]

整数与实 cutoff 的单位区间插值只产生低于 \(Y^{3+\varepsilon}\) 的误差，故可研究连续三角域

\[
\mathcal I_Y
:=\int_Y^{2Y}\int_X^{2X}|D_X(y)|^2dy\,dX.
\tag{18}
\]

事实上，由 \(|D_X-D_N|\ll1/\log Y\)（\(N\le X\le N+1\)）及长度至多 (1) 的下端条带，

\[
\sum_{Y<N\le2Y}I_N
\le2\int_Y^{2Y+1}\int_X^{2X}|D_X(y)|^2dy\,dX
+O(Y^3).
\tag{18a}
\]

## 5. 参数方向 Poincaré 的精确分裂

交换积分：

\[
\mathcal I_Y
=\int_Y^{2Y}\int_Y^y|D_X(y)|^2dXdy
+\int_{2Y}^{4Y}\int_{y/2}^{2Y}|D_X(y)|^2dXdy.
\tag{19}
\]

一端点 Poincaré 给出

\[
\boxed{
\mathcal I_Y
\le2Y\mathfrak E_Y^\partial+Y^2\mathfrak G_Y,
}
\tag{20}
\]

其中

\[
\mathfrak E_Y^\partial
:=\int_Y^{2Y}|D_y(y)|^2dy
+\int_{2Y}^{4Y}|D_{y/2}(y)|^2dy,
\tag{21}
\]

\[
\mathfrak G_Y
:=\int_Y^{2Y}\frac{dX}{X^2\log^4X}
\int_X^{2X}|T_X(y)|^2dy.
\tag{22}
\]

故充分条件为

\[
\mathfrak E_Y^\partial\ll_\varepsilon Y^{2+\varepsilon},
\qquad
\mathfrak G_Y\ll_\varepsilon Y^{1+\varepsilon}.
\tag{23}
\]

更尖锐地，在完整纤维 \([y/2,y]\) 上减去连接两个端点的仿射函数。令

\[
q(y):=\min_{c\in\mathbb C}
\int_{y/2}^y|\partial_XD_X(y)-c|^2dX.
\tag{24}
\]

则

\[
\boxed{
q(y)=
\int_{y/2}^y\frac{|T_X(y)|^2}{X^2\log^4X}dX
-\frac2y|D_y(y)-D_{y/2}(y)|^2\ge0.
}
\tag{25}
\]

写

\[
c_d(y):=\mu(d)\log d\left\{\frac yd\right\},
\tag{26}
\]

\[
u_d(y):=\frac1{\log\max(y/2,d)}-\frac1{\log y},
\qquad
v_{d,e}(y):=\int_{\max(y/2,d,e)}^y\frac{dX}{X^2\log^4X},
\tag{27}
\]

便有新的显式 PSD Möbius 二次型

\[
\boxed{
q(y)=\sum_{d,e\le y}c_d(y)c_e(y)
\left(v_{d,e}(y)-\frac2y u_d(y)u_e(y)\right).
}
\tag{28}
\]

两端点 Poincaré 因而把 (1) 严格归约到

\[
\boxed{
\int_Y^{4Y}\bigl(|D_y(y)|^2+|D_{y/2}(y)|^2\bigr)dy
\ll_\varepsilon Y^{2+\varepsilon},
}
\tag{29}
\]

\[
\boxed{
\int_Y^{4Y}q(y)dy\ll_\varepsilon Y^{1+\varepsilon}.
}
\tag{30}
\]

## 6. 回顾

直接估计只给

\[
\mathfrak E_Y^\partial\ll Y^3,
\qquad
\mathfrak G_Y\ll\frac{Y^2}{\log^2Y};
\tag{31}
\]

两项各差一个 \(Y\) 幂。端点也不是软误差。若

\[
H(x):=\sum_{d\le x}\frac{\mu(d)}d\log\frac xd,
\tag{32}
\]

则

\[
D_x(x)=\frac{xH(x)-\Psi(x)}{\log x},
\tag{33}
\]

且对 \(\Re s>1\)，

\[
\boxed{
\int_1^\infty[xH(x)-\Psi(x)]x^{-s-1}dx
=\frac1{(s-1)^2\zeta(s)}+
\frac{\zeta'(s)}{s\zeta(s)}.
}
\tag{34}
\]

所以端点自身仍携带全部 \(\zeta\)-零点奇性；连续 cutoff 并未绕过 RH 难度。存活的新原子只有
(28) 的“去平均斜率”PSD 核，但它必须与端点 (29) 联合处理。

## 7. 证据边界

- Letendre 2019 的 Theorems 1.1--1.2 直接支持 (3)--(4)；(5)--(7) 是本项目对首壳的归约。
- Zuniga-Alterman 2022 的 Theorem 5.1 支持 (8)、完整 lcm 二次型及其量纲；(11) 是对其有限平方和的直接分段微分。
- (15)--(30)、(34) 是本 note 的新恒等式与充分条件。
- 本 note 没有证明 (29)--(30)，因而没有证明 RH。

文献全文：

- Patrick Letendre, *Truncated convolution of the Möbius function and multiplicative energy of an integer n*,
  [arXiv:1903.05629](https://arxiv.org/abs/1903.05629)，
  [本地全文](<[unbundled local reference]>)。
- Sebastian Zuniga-Alterman, *On a logarithmic sum related to a natural quadratic sieve*,
  [arXiv:2005.04280](https://arxiv.org/abs/2005.04280)，
  [本地全文](<[unbundled local reference]>)。
