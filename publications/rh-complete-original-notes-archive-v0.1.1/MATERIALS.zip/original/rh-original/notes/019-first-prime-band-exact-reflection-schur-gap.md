> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 首个 prime band 的精确反射–Schur 正性延伸

日期：2026-08-11。

## 1. 定理

令

\[
a_1:=\frac9{25}=0.36,
\qquad d:=\log2.
\]

则

\[
\boxed{
A_a\succeq\frac1{20000}I
\qquad(0<a\le a_1).}
\]

其中可分别取

\[
A_a^+\succeq\frac1{20000}I,\qquad
A_a^-\succeq\frac1{1000}I.
\]

相对于首个阈值 \(a_*=d/2\)，这给出显式激活宽度

\[
\boxed{\varepsilon_0:=2a_1-d
=0.02685281944005469058\ldots>0.}
\]

因此首次退化若存在，必满足 \(a>0.36\)。

## 2. prime shift 是边缘 collar 上的反射

在 \(d/2<a<\log3/2\) 中只有 \(n=2\) 活跃。把奇偶函数酉映到
\(L^2(0,a)\)，并令

\[
I_a=(d-a,a),\qquad
(J_af)(x)=1_{I_a}(x)f(d-x),\qquad
p=\frac{\log2}{\sqrt2}.
\]

直接改变变量得到

\[
q_{2,a}^+(f)=-p\langle J_af,f\rangle,
\qquad
q_{2,a}^-(f)=+p\langle J_af,f\rangle.
\]

注意

\[
J_a^*=J_a,\qquad J_a^2=P_{I_a}.
\]

这既核验了符号，也核验了系数：完整直线上的两个平移给出因子 \(2\)，而奇偶半区酉映射给出
因子 \(1/2\)，二者精确抵消。普通 \(L^2\) 算子范数始终为 \(p\)，不会随 collar 宽度趋零；正确
做法是保留 \(J_a\) 的反射结构。

## 3. Yukawa 有限下模型

沿用 notes 017–018 的记号

\[
b_n=n+\frac14,
\qquad c_n=2b_n,
\qquad
\ell_n(\mu)=\frac{\mu^2}{b_n(c_n^2+\mu^2)}.
\]

偶 Robin 模式与奇 Robin 模式分别由

\[
\mu\tan(\mu a)=c_n,
\qquad
\mu\cot(\mu a)=-c_n
\]

确定。每个 Yukawa summand 的特征值 \(\ell_n(\mu_{n,j})\) 随 \(j\) 严格增加。
对前若干个 \(n\) 保留 \(j=0,1\) 两个 deficit，并以 \(j=2\) 模式作为标量底；对其余有限项只用
\(j=0\) 标量底，正的无穷尾直接丢弃。于是得到严格的形式下界。

### 偶扇区

取前 \(20\) 个 Yukawa 项的两个 deficit，得到

\[
A_{a_1}^+
\succeq
\alpha_+I-W_+W_+^*+|u\rangle\langle u|-pJ,
\qquad u(x)=2\cosh(x/2),
\]

其中 Arb 认证

\[
\alpha_+=1.0198786769920198356\ldots>p.
\]

统一脚本令 \(D_+=\alpha_+I-pJ\) 以证明严格正。独立定量证书进一步取

\[
\delta_+=\frac1{20000},\qquad
D_+=(\alpha_+-\delta_+)I-pJ.
\]

在 collar 外 \(D_+^{-1}=(\alpha_+-\delta_+)^{-1}I\)，在 collar 内

\[
D_+^{-1}
=\frac{(\alpha_+-\delta_+)I+pJ}
{(\alpha_+-\delta_+)^2-p^2}.
\]

Sherman–Morrison 后，有限 Schur 条件为

\[
I-W_+^*(D_++|u\rangle\langle u|)^{-1}W_+\succ0.
\]

所有矩阵元都是分段的 \(\sin,\cos,\sinh,\cosh\) 初等积分。Arb 区间
\(LDL^\mathsf T\) 的最小 pivot 满足

\[
\boxed{p_{\min}^+>0.01683112096147415.}
\]

故 \(A_{a_1}^+\succeq1/20000\,I\)。

### 奇扇区

取前 \(5\) 项的两个 deficit：

\[
A_{a_1}^-
\succeq
\alpha_-I-W_-W_-^*-|v\rangle\langle v|+pJ,
\qquad v(x)=2\sinh(x/2),
\]

其中

\[
\alpha_-=0.5765264684867110415\ldots.
\]

取

\[
\gamma=\frac1{50},\qquad
D_-=(\alpha_--\gamma)I+pJ.
\]

因 \(\alpha_--\gamma>p\)，有 \(D_->0\)，且在 collar 内

\[
D_-^{-1}
=\frac{(\alpha_--\gamma)I-pJ}
{(\alpha_--\gamma)^2-p^2}.
\]

Arb 认证

\[
I-W_-^*D_-^{-1}W_-\succ0,
\qquad p_{\min}^->0.2107471700669390.
\]

所以去掉极点前的奇算子不小于 \(\gamma I\)。又

\[
\|v\|_2^2=2(\sinh a_1-a_1),
\]

从而

\[
\boxed{
A_{a_1}^-
\succeq
\bigl[\gamma-2(\sinh a_1-a_1)\bigr]I
>0.004346911510690799I.}
\]

独立的十一维 Schur 证书保留负极点向量本身，而非仅用范数扣除，并进一步给出

\[
\boxed{A_{a_1}^-\succeq10^{-3}I.}
\]

## 4. 从单点覆盖整个区间

note 003 的零延拓 min–max 单调性保持奇偶子空间。因此

\[
0<a\le a_1
\Longrightarrow
\lambda_1^\pm(a)\ge\lambda_1^\pm(a_1)>0.
\]

这包括 prime-free 区间、阈值本身以及首个 activation band 的显式初段。

## 5. 可复现证书

统一脚本：
[verify_first_prime_band_gap.py](../computations/verify_first_prime_band_gap.py)

~~~bash
uv run --with python-flint python \
  computations/verify_first_prime_band_gap.py
~~~

关键输出：

~~~text
a1=0.36
epsilon0=0.02685281944005469058...
even_min_LDL_pivot=0.02132801434368709...
odd_min_LDL_pivot=0.21074717006693904...
odd_operator_gap=0.004346911510690799...
certified_positive=True
~~~

这里的 pivot 只用于证明 Schur 补严格正；它不是原无限维算子的谱隙数值。奇扇区最后一行才是
直接的算子谱隙。偶扇区本轮只主张严格正，不从 Schur pivot 误报定量谱隙。

显式扇区谱隙由下列两个独立证书给出：

- [verify_first_band_even_at_036.py](../computations/verify_first_band_even_at_036.py)：
  \(A_{a_1}^+\succeq1/20000\,I\)；
- [verify_first_band_odd_at_036.py](../computations/verify_first_band_odd_at_036.py)：
  \(A_{a_1}^-\succeq1/1000\,I\)。
