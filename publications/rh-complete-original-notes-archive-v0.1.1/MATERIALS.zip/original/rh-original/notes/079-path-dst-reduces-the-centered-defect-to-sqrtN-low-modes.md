> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 路径 DST 把中心化缺陷压到 \(\sqrt{N/\log N}\) 个低模

日期与检索截止：2026-08-13。

依赖：[note 072](072-critical-low-frequency-band-has-no-type-II-oscillation.md)、
[note 074](074-mellin-poles-force-dyadic-mean-shell-growth.md)、
[note 078](078-full-fourier-packets-form-a-finite-ramanujan-antiderivative-frame.md)。

## 1. 弄清问题

note 078 已把完整 Fourier packets 合并为有限 Ramanujan 原函数。现在不再估计一般
incomplete frame，而是对该原函数作路径差分的精确奇异值分解。

```mermaid
flowchart LR
  A["primitive packet 和 v"] --> B["路径差分 r=A₁−V"]
  B --> C["DST: σ_k≈k/N"]
  C --> D["H⁰ 支付 k>K"]
  D --> E["K≈√(N/log N)"]
  C --> F["低模=格点求积缺陷"]
  F --> G["保留零模 Γ_N"]
```

本轮只判定：普通 Barban--Vehov \(H^0\) 是否已足以支付大多数频率，以及剩余频率的
最短算术表达是什么。

## 2. 路径差分的精确谱

置

\[
L:=\log N,
\qquad
\lambda_{d,N}:=\frac{\mu(d)}L\log\frac Nd,
\qquad
V_N(n):=\sum_{\substack{d\mid n\\d\le N}}\lambda_{d,N},
\tag{1}
\]

\[
A_{1,N}:=\sum_{d\le N}\frac{\lambda_{d,N}}d,
\qquad
B_N:=LA_{1,N}
=\sum_{d\le N}\frac{\mu(d)}d\log\frac Nd.
\tag{2}
\]

沿用 note 078 的

\[
G_N(n):=\sum_{q=2}^NA_{q,N}P_q(n),
\qquad
v_j:=G_N(N+j),\quad0\le j<N.
\tag{3}
\]

则路径边上的差分为

\[
\boxed{
r_j:=v_j-v_{j-1}=A_{1,N}-V_N(N+j),
\qquad1\le j<N.
}
\tag{4}
\]

令

\[
u_k(j):=\sqrt{\frac2N}\sin\frac{\pi kj}{N},
\qquad
\sigma_k:=2\sin\frac{\pi k}{2N},
\qquad1\le j,k<N.
\tag{5}
\]

\(u_k\) 是路径差分算子 \(D:\mathbb C^N\to\mathbb C^{N-1}\) 的左奇异向量，故

\[
\boxed{
\sum_{j=0}^{N-1}|v_j|^2
=N|\bar v|^2+
\sum_{k=1}^{N-1}\frac{|\langle r,u_k\rangle|^2}{\sigma_k^2}.
}
\tag{6}
\]

这里没有周期闭边。若擅自改用循环 DFT，缺失的边
\(v_0-v_{N-1}\) 会把仿射模重新带回；因此不能声称 \(A_{1,N}\) 在非零频率中消失。

完整首壳能量恰分成

\[
\boxed{
I_N=\frac N{12}A_{1,N}^2+N|\Gamma_N|^2+E_N^{\rm cen},
\qquad
E_N^{\rm cen}:=
\sum_{k=1}^{N-1}\frac{|\langle r,u_k\rangle|^2}{\sigma_k^2}.
}
\tag{7}
\]

所以 DST 只控制中心化缺陷；零模 \(N|\Gamma_N|^2\) 必须另证。

## 3. 高频由 \(H^0\) 自动支付

Graham--Barban--Vehov 均方给出

\[
\|r\|_2^2\ll\frac N{\log N}.
\tag{8}
\]

对 \(K<N/2\)，由 \(\sigma_k\) 单调及 Parseval，

\[
\begin{aligned}
E_{N,>K}^{\rm cen}
&:=\sum_{k>K}\frac{|\langle r,u_k\rangle|^2}{\sigma_k^2}\\
&\le
\frac{\|r\|_2^2}{4\sin^2(\pi(K+1)/(2N))}
\ll\boxed{\frac{N^3}{(K+1)^2\log N}}.
\end{aligned}
\tag{9}
\]

因此

\[
\boxed{
K_N:=\left\lceil\sqrt{\frac N{\log N}}\right\rceil
\quad\Longrightarrow\quad
E_{N,>K_N}^{\rm cen}\ll N^2.
}
\tag{10}
\]

该阈值对只使用 (8) 的论证是尖锐的：\(H^0\) 谱质量可以全部集中于 \(k=K+1\)。
故未知频率数从 \(N\) 严格降为 \(N^{1/2+o(1)}\)。

## 4. 低模是两个格点求积规则之差

定义未归一化低模

\[
\mathcal R_{N,k}:=
L\sum_{j=1}^{N-1}r_j\sin\frac{\pi kj}{N},
\qquad
S_{N,k}:=\sum_{j=1}^{N-1}\sin\frac{\pi kj}{N}.
\tag{11}
\]

则

\[
S_{N,k}=
\begin{cases}
\cot\dfrac{\pi k}{2N},&k\text{ odd},\\[4pt]
0,&k\text{ even}.
\end{cases}
\tag{12}
\]

对 \(N<n<2N\)，只有因子 \(n\) 被 cutoff 排除，故

\[
\boxed{
LV_N(n)=\Lambda(n)+\mu(n)\log\frac nN.
}
\tag{13}
\]

因此有两条完全等价的表达：

\[
\boxed{
\mathcal R_{N,k}
=B_NS_{N,k}
-\sum_{N<n<2N}
\left(\Lambda(n)+\mu(n)\log\frac nN\right)
\sin\frac{\pi k(n-N)}N,
}
\tag{14}
\]

\[
\boxed{
\mathcal R_{N,k}
=\sum_{d\le N}\mu(d)\log\frac Nd
\left[
\frac{S_{N,k}}d
-\sum_{N<dm<2N}
\sin\frac{\pi k(dm-N)}N
\right].
}
\tag{15}
\]

(15) 是新出现的最小算术元。方括号不是指数和本身，而是：

\[
\boxed{
\text{全局 }N\text{-格点正弦求积}/d
-
\text{局部 }(N/d)\text{-格点正弦求积}.}
\tag{16}
\]

若 \(d\mid N\)，它进一步精确化为

\[
\frac{S_{N,k}}d-
\begin{cases}
\cot\dfrac{\pi kd}{2N},&k\text{ odd},\\[4pt]
0,&k\text{ even},
\end{cases}
\tag{17}
\]

其中第一行在没有极点的通常解释下成立。对 \(kd=o(N)\)，其首项为

\[
\frac{\pi k}{6N}\left(d-\frac1d\right)
+O\!\left(\frac{k^3d^3}{N^3}+\frac{k^3}{N^3d}\right).
\tag{18}
\]

这说明低模需要的是带 Möbius 符号的多尺度求积误差，而非一般 Farey frame 上界。

由 (5)、(11)，

\[
\langle r,u_k\rangle
=\sqrt{\frac2N}\frac{\mathcal R_{N,k}}L.
\tag{19}
\]

当 \(k\le K_N=o(N)\) 时，\(\sigma_k\asymp k/N\)，所以

\[
\boxed{
E_{N,\le K_N}^{\rm cen}
\asymp
\frac N{L^2}
\sum_{k\le K_N}\frac{|\mathcal R_{N,k}|^2}{k^2}.
}
\tag{20}
\]

于是点态充分条件为

\[
\boxed{
\sum_{k\le K_N}\frac{|\mathcal R_{N,k}|^2}{k^2}
\ll_\varepsilon N^{1+\varepsilon}L^2.
}
\tag{21}
\]

与 note 074 的完整能量目标匹配的条件是

\[
\boxed{
\sum_{Y<N\le2Y}
\sum_{k\le K_N}\frac{|\mathcal R_{N,k}|^2}{k^2}
\ll_\varepsilon Y^{2+\varepsilon}(\log Y)^2,
}
\tag{22}
\]

若坚持估计完整 \(I_N\)，还要外加

\[
\boxed{
\sum_{Y<N\le2Y}N|\Gamma_N|^2
\ll_\varepsilon Y^{3+\varepsilon}.
}
\tag{23}
\]

(22)--(23) 联合即足以支付完整未知部分；它们尚未被证明。后续
[note 080](080-centered-path-energy-alone-is-an-rh-criterion.md) 利用零点探针的零均值证明：
为推出 RH，(22) **单独已经足够**，无需 (23)。

## 5. \(\Lambda\) 主项确实消去，但不能分开估计余项

令

\[
E(x):=\Psi(x)-x,
\qquad
M_{N,k}:=\sum_{N<n<2N}\mu(n)\log\frac nN
\sin\frac{\pi k(n-N)}N.
\tag{24}
\]

Stieltjes 分部积分给出

\[
\sum_{N<n<2N}\Lambda(n)\sin\frac{\pi k(n-N)}N
=\frac{N(1-(-1)^k)}{\pi k}+\mathcal E_{\Lambda,N,k},
\tag{25}
\]

\[
\mathcal E_{\Lambda,N,k}
:=-\frac{\pi k}{N}
\int_N^{2N}E(x)\cos\frac{\pi k(x-N)}N\,dx.
\tag{26}
\]

故奇数 \(k\) 时

\[
\boxed{
\mathcal R_{N,k}
=(B_N-1)\frac{2N}{\pi k}
+B_N\left(\cot\frac{\pi k}{2N}-\frac{2N}{\pi k}\right)
-\mathcal E_{\Lambda,N,k}-M_{N,k},
}
\tag{27}
\]

偶数 \(k\) 时

\[
\boxed{
\mathcal R_{N,k}=-\mathcal E_{\Lambda,N,k}-M_{N,k}.
}
\tag{28}
\]

所以仿射项准确删除了 \(\Lambda\) 的连续主项。然而，若分别估计
\(B_N-1\)、\(\mathcal E_{\Lambda,N,k}\)、\(M_{N,k}\)，现有零自由区只给次指数误差，
仍远大于平方根尺度。必须保留 (15) 或 (27)--(28) 中的联合消去。

更直接地，若 \(e_j=E(N+j)\)，则

\[
\Lambda(N+j)-1=e_j-e_{j-1}.
\tag{29}
\]

因而把 \(\Lambda-1\) 单独送入同一 \(H^{-1}\) 逆差分，恰得到

\[
\sum_{k=1}^{N-1}
\frac{|\langle\Lambda(N+\cdot)-1,u_k\rangle|^2}{\sigma_k^2}
=\sum_{j=0}^{N-1}|e_j-\bar e|^2.
\tag{30}
\]

要求右边达到 \(O(N\log^2N)\) 已接近 RH 级 PNT 误差，故“先剥离 \(\Lambda\)”不是
较弱路线。

## 6. 最小数值判别

用线性筛生成 \(\mu,\Lambda\)，再以正交 DST-I 计算 (6)。选取结果：

| \(N\) | \(E_N^{\rm cen}/N^2\) | 50% 能量模 | 90% 能量模 | \(K_N\) | \(k>K_N\) 比例 |
|---:|---:|---:|---:|---:|---:|
| \(2^{12}\) | \(4.97\times10^{-4}\) | 20 | 141 | 23 | 0.428 |
| \(2^{15}\) | \(3.91\times10^{-4}\) | 9 | 105 | 57 | 0.156 |
| \(2^{18}\) | \(3.36\times10^{-4}\) | 13 | 97 | 145 | 0.0656 |

在 \(N=2^{18}\) 上，\(k=1,3\) 的完整 residual 相对
“仿射 + \(\Lambda\) + Möbius”三项绝对和分别只有
\(1.4\times10^{-5}\)、\(1.7\times10^{-3}\)。这只说明联合消去确实存在，不构成
渐近界。复现实验见
[`scratch/probe_selberg_dst_low_modes.py`](../scratch/probe_selberg_dst_low_modes.py)。

## 7. 历史边界与下一原子

截至 2026-08-13 的定向检索没有找到覆盖 (22) 的历史定理：

- Davenport 1937 II 对 \(\sum\mu(n)e(\alpha n)\) 给任意固定次对数节省；代入 (20)
  仍为 \(N^2\log^{-A}N\)，而目标为 \(N^{1+\varepsilon}\)；
- Montgomery--Vaughan 型大筛在 spacing \(1/N\)、长度 \(N\) 时给 \(N^2\) 尺度；
- Matomäki--Radziwiłł--Tao 与 Menon 的 moving-interval 平均给对数或 \(o(1)\) 相对节省，
  不给平方根均方；
- Wei Zhang 2022 的条件 uniform 指数即使取零自由边界 \(1/2\)，也只有
  \(N^{3/4+\varepsilon}\)，逐模代入仍不够。

这批结果共同说明：所缺输入不是普通 \(L^\infty\) Möbius 指数和，而是保留
\(N\)-dilation、\(k^{-2}\) 与格点求积差的二参数均方。

下一原子固定为

\[
\boxed{
\mathcal Q_{Y,k}:=
\sum_{Y<N\le2Y}|\mathcal R_{N,k}|^2,
\qquad
1\le k\le\sqrt{2Y/\log Y},
}
\tag{31}
\]

并优先判别：对每个固定 \(k\)，(15) 在 \(N\)-平均后是否产生严格的 divisor-switching
正交，而不是继续优化单个 \(N\) 的 Davenport 界。

本 note 新证明 (6)、(9)--(10)、(14)--(23) 的路径 DST 归约与低模格点求积公式；它没有
证明 (22)--(23)，因而没有证明 RH。

历史锚点：

- H. Davenport, *On some infinite series involving arithmetical functions (II)*,
  Q. J. Math. **os-8** (1937), 313--320,
  [DOI](https://doi.org/10.1093/qmath/os-8.1.313)；
- Wei Zhang, *On an exponential sum related to the Möbius function*,
  [arXiv:2204.04613](https://arxiv.org/abs/2204.04613)；
- Siddarth Menon, *Improved bounds for multiplicative functions in almost all short intervals*,
  [arXiv:2607.15574](https://arxiv.org/abs/2607.15574)。
