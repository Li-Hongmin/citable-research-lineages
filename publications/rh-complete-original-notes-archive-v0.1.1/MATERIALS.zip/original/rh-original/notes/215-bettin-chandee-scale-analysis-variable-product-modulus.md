> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Bettin--Chandee 对 \(q\ne0\) variable-product-modulus 层的尺度检查

日期：2026-08-15。

本 note 检查 note 212 的 reciprocal phase 是否可以直接交给
Bettin--Chandee 的 Kloosterman-fraction 三线性估计，目标是判断它能否把
incomplete-lcm 边界压到所需的固定幂次。结论是：相位在形式上可以逐块套用，
但范数型节省只有固定的小幂次（在最乐观的三线性分解中至多 \(1/8\) 量级），
而原边界的物理量纲需要再获得一个完整的 \(N^{-1+\delta}\)；因此现有黑箱
不能直接给出 \(O(N^{2-\delta})\)，更不能关闭 RH 的正能量门。

## 1. 要代入的相位与 dyadic 尺度

由 note 212 的式 (3)、(6)，取

$$
d=gb,\qquad e=ga,\qquad a,b\asymp A:=N/G,
$$

其中 \(g\asymp G\) 固定在一个 dyadic 块。cotangent 分支的 \(k\)-频率项为

$$
\frac{gab}{k^2}\left[\mathrm e\!\left(\frac{2Nk}{gab}\right)
-\mathrm e\!\left(\frac{Nk}{gab}\right)\right]
\cot^*\!\left(\frac{\pi k\bar b}{a}\right)
\mathrm e\!\left(\frac{kh\bar b}{a}\right).
\tag{1}
$$

其中使用了
$$
\cot^*\!\left(\frac{\pi k\bar b}{a}\right)
=2i\sum_{1\le h<a}\left(\frac ha-\frac12\right)
\mathrm e\!\left(\frac{kh\bar b}{a}\right).
$$

对 \(k\asymp K\)，积分差分的大小至多为
$$
\left|\mathrm e(2Nk/(gab))-\mathrm e(Nk/(gab))\right|
\ll \min(1,K/A).
\tag{2}
$$
这里 \(K\lesssim A\) 是积分核的有效低频范围；超过此范围后
\(\mathcal I_N(k/(gab))\) 以 \(1/|k|\) 衰减。将 (2) 保留下来已经是对
Bettin--Chandee 应用最有利的处理，丢掉它只会更差。

## 2. Bettin--Chandee 定理的可匹配部分

Bettin--Chandee 的 Theorem 1 对
$$
\sum_{c\asymp H}\sum_{m\asymp M}\sum_{n\asymp Q}
\alpha_m\beta_n\nu_c\,
\mathrm e\!\left(\vartheta c\bar m/n+f_{c,\vartheta}(m,n)\right)
$$
给出（记号与原论文一致）
$$
\ll \|\alpha\|_2\|\beta\|_2\|\nu\|_2
\left(1+\frac{|\vartheta|H+X}{MQ}\right)^{1/2}
\left((HMQ)^{7/20}(M+Q)^{1/4}
+(HMQ)^{3/8}(HM+HQ)^{1/8}\right),
\tag{3}
$$
其中 \(f_x\ll X/(m^2n)\)、\(f_y\ll X/(mn^2)\)。这是
[Bettin--Chandee, arXiv:1502.00769, Theorem 1](https://arxiv.org/abs/1502.00769)
及其 Remark 1 的形式。

在本问题中令
$$
c=h,\quad m=b,\quad n=a,\quad M=Q=A,\quad H\le A,
\quad \vartheta=k,
$$
并把
$$
f_{h,k}(b,a)=\frac{\tau Nk}{gab},\qquad \tau\in\{1,2\},
$$
放入 Remark 1。此时 \(X=Nk/G=AK\)，故
$$
\frac{|k|H+X}{A^2}\ll \frac KA\ll1
\tag{4}
$$
在有效 \(K\le A\) 范围内；也就是说，平滑 reciprocal phase 本身不会造成
额外的幂次损失，但也不会提供新的幂次收益。

## 3. 范数与指数的实际代入

将 \(h/a-1/2\) 分成两项。记
\(\lambda_{ga}=\mu(ga)L^{-1}\log(N/(ga))\)，则在最坏的平方和尺度上
$$
\|b\lambda_{gb}\|_2\ll A^{3/2}L^{-1},\quad
\|a\lambda_{ga}\|_2\ll A^{3/2}L^{-1},\quad
\|\lambda_{ga}\|_2\ll A^{1/2}L^{-1}.
\tag{5}
$$

在 \(h\asymp H\) 块上，
$$
\|1\|_2\asymp H^{1/2},
\qquad
\|h\|_2\asymp H^{3/2}.
\tag{6}
$$
因此，包含外层 \(ab(h/a-1/2)\) 的两项在 (3) 中都给出同一最坏尺度：
$$
\|\alpha\|_2\|\beta\|_2\|\nu\|_2
\ll A^{7/2}H^{1/2}L^{-2}
\quad\text{或}\quad
A^{2}H^{3/2}L^{-2}.
\tag{7}
$$
而 (3) 的括号为
$$
H^{7/20}A^{19/20}+H^{1/2}A^{7/8}.
\tag{8}
$$
在最坏的 \(H\asymp A\) 端，两者均不超过
$$
A^{7/2+11/8+\varepsilon}=A^{39/8+\varepsilon}.
\tag{9}
$$
这是对 \(h\)-展开后的 \(A^5\) 个带权项只节省 \(A^{1/8}\) 的范数型估计。

最后，(1) 中 \(k\asymp K\) 的权重与有效差分 (2) 合起来为
$$
\#\{k\asymp K\}\,\frac G{K^2}\min(1,K/A)
\ll \frac GA,
\tag{10}
$$
对所有 \(K\le A\) 都相同。故即使把 (2) 的小因子完整保留，单个 \(g\)-块的
乐观 Bettin--Chandee 上界仍为
$$
\ll G A^{-1}A^{39/8+\varepsilon}
=G A^{31/8+\varepsilon}.
\tag{11}
$$
代入 \(A=N/G\)，对 \(G\) 求和由 \(G=1\) 主导，得到
$$
\boxed{\mathcal B_N^{\ne0}
\ll N^{31/8+\varepsilon}\quad\text{(直接 BC 的乐观代入，尚且劣于物理平凡界)}.}
\tag{12}
$$
这里的 \(N^{31/8}\) 只是说明黑箱尺度，不能替代更强的物理平凡界
\(|E_{d,e}(N)|\le N/16\)，后者给全双和 \(O(N^3)\)。两者取最小仍只有
\(O(N^3)\)，没有固定幂次改善。

## 4. 为什么“把 cotangent 当作一个系数”也不够

若不展开 \(h\)，而假设能够把 cotangent 系数直接纳入一个理想的
bilinear Kloosterman-fraction 黑箱，则 \(a,b\asymp A\) 的系数范数至多给出
\(A^2\) 的平凡双和，Bettin--Chandee/DFI 型结果在平衡区只节省一个固定小幂次
（原始 bilinear 指数为 \(1/48\)，三线性版本的相关平衡节省为 \(1/20\)；新近
bilinear 改进也仍是固定小幂次）。乘回低频积分尺度 \(N\)，所得量级至多是
$$
N^{3-\eta+\varepsilon}\qquad(\eta\ll1),
\tag{13}
$$
而不是所需的 \(N^{2-\delta}\)。所以问题不是 (11) 中技术上损失了某个对数，
而是现有 Kloosterman-fraction 范数界没有提供从 \(N^3\) 到 \(N^2\) 所需的
一个完整平方根级抵消。

## 5. 结论与下一步

1. 式 (11) 证明了 note 212 的相位确实落在 Bettin--Chandee Remark 1
   允许的平滑扰动范围内；因此“形式不匹配”不是主要障碍。
2. 真正障碍是尺度：\(h\) 展开后的三线性估计只回收 \(A^{1/8}\) 左右，
   而原物理双和需要额外的 \(A^{-1+\delta}\)；即使假设一个理想 bilinear
   版本，也只有 \(N^{3-\eta}\) 而不是 \(N^{2-\delta}\)。
3. 因而现有 Bettin--Chandee、DFI 或普通 large-sieve 不能直接关闭
   note 208 的 signed 门。下一步必须提供超出任意系数 \(L^2\)-范数黑箱的
   Möbius-specific cancellation，或在 \(q\)、\(g\)、\(h\) 之间建立新的
   三层正交；把该层逐 dyadic 地丢给 Kloosterman-fraction 黑箱不会解决 RH。

