> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 几乎所有尺度的 Chowla 对数节省仍不能关闭 dyadic RH 门

日期：2026-08-16。

Tao--Teräväinen 的定量相关结果
（[arXiv:2512.01739v2](https://arxiv.org/abs/2512.01739)）给出一类
\[
\frac1N\sum_{N<n\le2N}
\lambda(a_1n+b_1)\lambda(a_2n+b_2)
\ll (\log N)^{-c}
\]
的估计，但只对一个对数密度为 \(1\) 的尺度集合成立，并且节省是对数级。

对本项目的固定移位相关
\[
C_h(X)=\sum_{n\le X-h}\lambda(n)\lambda(n+h),
\]
即使假设在一整个 \(h\)-区间内都有
\(|C_h(X)|\ll X(\log X)^{-c}\)，逐项求和也只给
\[
\left|\sum_{H\le h<2H}C_h(X)\right|
\ll HX(\log X)^{-c}.
\]
当 \(H\) 是宏观移位时，这仍远大于目标 \(X^{1+\varepsilon}\)。
要去掉这个 \(H\) 因子，必须保留 \(h\)-方向的 signed cancellation；
“几乎所有 \(X\) 的固定移位 Chowla”本身不能完成该转移。

因此该结果可改善本项目的 \(X^{2-o(1)}\) 基线，但不能替代
signless dyadic gate，更不能直接推出 \(L_\lambda(X)\ll X^{1/2+\varepsilon}\)。

## 平滑 \(h\)-权也不产生隐藏的 \(1/H\)

对任意 \(|w(h/H)|\le1\) 的平滑权，Theorem 1.1 直接给出
\[
\left|\sum_{h\le H}w(h/H)C_h(X)\right|
\le \sum_{h\le H}|C_h(X)|
\ll HX\left(\frac{\log\log H}{\log H}
+\log^{-1/3000}X\right).
\]
因此“先把 dyadic 指示函数平滑化”不会自动改善 \(H\) 的幂次。
要达到本项目所需的量级，最小的新输入必须在取绝对值之前证明
\[
\left|\sum_h w(h/H)C_h(X)\right|\ll_\varepsilon X^{1+\varepsilon}
\]
（对足够丰富的 \(w\) 统一成立）；这正是一个加权 Type-II signed
correlation 命题，而不是现有 averaged-Chowla 的直接推论。
