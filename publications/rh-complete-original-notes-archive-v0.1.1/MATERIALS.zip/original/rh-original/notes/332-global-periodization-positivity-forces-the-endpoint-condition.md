> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 全局 periodization 正性强制 \(V(1)=0\)

日期：2026-08-16。

此前的 Fourier no-go 常在 detector 定义中预先加入 \(V(1)=0\)。本 note
证明：在要保留 regular Mellin periodization 的标准范围内，这不是任意的
技术限制，而是由 \(P_V(y)\ge0\) 的全局正性强制出来的。

## 1. 非零均值不是 regular detector

令 \(V\in C^1([0,1])\)、\(V(0)=0\)，并置
\[
 P_V(y)=\sum_{1\le c\le y}V(c/y).
\]
写 \(y=N+r\)，其中 \(N=\lfloor y\rfloor\)、\(0\le r<1\)。右端点
Riemann--Euler 公式给出
\[
 P_V(y)
 =y\int_0^{N/y}V(u)\,du+\frac{V(N/y)-V(0)}2+O_V(y^{-1}),
\tag{1}
\]
其中误差对 \(r\in[0,1]\) 一致。

若 \(I_V=\int_0^1V(u)\,du\ne0\)，则
\[
 P_V(y)=I_V\,y+O_V(1).
\tag{2}
\]
于是 \(P_V(e^t)\) 不是 \(L^1(0,\infty)\)，其 Mellin/Fourier 变换含有
非衰减的主项；这不属于当前 \(K_V/\zeta\) 的 regular detector 门。

## 2. 零均值时的 fractional-part 尾项

现在假设 \(I_V=0\)。由于
\[
 \int_{N/y}^1V(u)\,du
 =\frac r yV(1)+O_V(y^{-2}),
\qquad
 V(N/y)=V(1)+O_V(y^{-1}),
\]
将它们代入 (1) 得到一致渐近式
\[
 \boxed{
 P_V(N+r)=V(1)\left(\frac12-r\right)+O_V(N^{-1}).
 }
\tag{3}
\]
这项是由移动截断端点产生的 sawtooth 尾，而不是数值误差。

若 \(V(1)>0\)，取任意固定 \(r\in(1/2,1)\)，则 (3) 给出
\[
 P_V(N+r)<0
\]
对所有充分大的 \(N\) 成立。若 \(V(1)<0\)，取
\(r\in(0,1/2)\) 得同样结论。因此
\[
 \boxed{
 V(0)=0,\quad \int_0^1V=0,\quad
 P_V(y)\ge0\ (y\ge1)
 \Longrightarrow V(1)=0.
 }
\tag{4}
\]

## 3. 对 RH detector 的裁决

若坚持 \(\int V=0\) 以消除 periodization 的线性主项，并要求
\(P_V\ge0\) 于整个实尺度 \(y\ge1\)，则 (4) 自动恢复端点条件
\(V(1)=0\)。随后 \(P_V(1)=0\)，而 note 180/237 的结构性结果重新适用：
非零 detector 的 log-Fourier 符号不可能全频非负，且直接 PSD 化被排除。

因此放宽 \(V(1)=0\) 没有产生新的正 detector 分支，只有两个结果：

1. \(\int V\ne0\)：periodization 具有 \(y\)-线性尾，失去 regular Mellin
   detector 结构；
2. \(\int V=0\)：全局正性强制 \(V(1)=0\)，回到已有的 signed Fourier/
   arithmetic-intertwiner 缺口。

这条必要性只使用 Euler--Maclaurin 的一致有限化，不声称 RH；它关闭了
“通过非零 \(V(1)\) 获得全频 PSD regular detector”的候选路线。
