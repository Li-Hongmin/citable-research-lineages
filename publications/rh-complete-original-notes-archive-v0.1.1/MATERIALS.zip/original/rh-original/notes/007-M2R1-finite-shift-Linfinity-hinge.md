> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有限 prime shifts 不破坏 \(L^\infty\)：M2-R1 与边界上界完成

日期：2026-08-11。本文完成 M2-R1。核心观察是：Dirac shifts 不应作为待估计的 \(L^2\) 卷积
右端，而应成对改写成非负的离散跳跃生成元。由此可把纯 logarithmic-Laplacian 的 superlevel
截断证明原样延伸到 Weil 零模态，并接通最优边界正则性定理。

## 1. Weil 零模态方程

由 note 004，实值零模态 \(v\in H((-a,a))\) 满足

\[
L_\Delta v
=c_0v+\sum_{j=1}^{J}d_j
\bigl(T_{h_j}v+T_{-h_j}v\bigr)+f
\quad\text{in }(-a,a),
\]

且 \(v=0\) a.e. 于区间外，其中

\[
c_0=2\log(2\pi),\qquad
d_j=2\frac{\Lambda(n_j)}{\sqrt{n_j}}>0,\qquad
h_j=\log n_j\ge\log2,
\]

\(J<\infty\)，而

\[
f=2Rv,\qquad
(Rv)(x)=\int_{-a}^a r''(x-y)v(y)\,dy.
\]

由于 \(r''\) 在 \([-2a,2a]\) 上连续，

\[
\lVert f\rVert_\infty
\le 2(2a)^{1/2}\lVert r''\rVert_{L^\infty(-2a,2a)}
\lVert v\rVert_2.
\]

所以光滑余项已经是 \(L^\infty\) 右端。

## 2. Kato 不等式

标准 Dirichlet logarithmic-Laplacian 形式满足绝对值收缩

\[
\mathcal E_L(|u|,|u|)\le\mathcal E_L(u,u).
\]

近场差分项使用
\(\bigl||u(x)|-|u(y)|\bigr|\le|u(x)-u(y)|\)；远场项带负号，换成绝对值同样只会降低形式。
相应的弱 Kato 不等式给出：若 \(z:=|v|\)，则对允许的非负试验函数，

\[
L_\Delta z
\le c_0z+\sum_{j=1}^{J}d_j
\bigl(T_{h_j}z+T_{-h_j}z\bigr)+|f|
\]

在弱意义下成立。这里使用

\[
\operatorname{sgn}(v(x))\,v(x\pm h_j)
\le |v(x\pm h_j)|.
\]

若原零模态为复值，可取非零实部或虚部，因为 Weil 算子与复共轭交换。

## 3. 把平移变成正的离散跳跃项

定义

\[
D_h:=2I-T_h-T_{-h}.
\]

则 Kato 不等式等价于

\[
L_\Delta z+\sum_{j=1}^{J}d_jD_{h_j}z
\le Bz+|f|,
\qquad
B:=c_0+2\sum_{j=1}^{J}d_j.
\]

每个 \(D_h\) 都是非负自伴的离散跳跃生成元。更精确地，对任意单调、1-Lipschitz 函数
\(\eta:\mathbb R\to\mathbb R\)，

\[
\begin{aligned}
\langle D_hz,\eta(z)\rangle
&=\int_{\mathbb R}
\bigl(z(x)-z(x+h)\bigr)
\bigl(\eta(z(x))-\eta(z(x+h))\bigr)\,dx\\
&\ge0.
\end{aligned}
\]

特别地，对 superlevel truncation

\[
\eta_t(s)=(s-t)^+,\qquad t\ge0,
\]

有

\[
\boxed{\langle D_hz,(z-t)^+\rangle\ge0.}
\]

这一步是 Dirac shifts 的正确处理方式。它完全绕开了非法的
\(\lVert\delta_h\rVert_2\) 估计。

## 4. \(L^\infty\) 截断估计

Dyda--Jarohs--Sk 的 Theorem 6.7 在 \(p=2\) 时证明：若 \(u\) 是纯 logarithmic-Laplacian 的
弱次解

\[
L_\Delta u\le A+B|u|
\]

并且区间外数据有界，则 superlevel test \((u-t)^+\) 给出 \(u^+\in L^\infty\)，估计只依赖
\(A,B,\Omega\) 和相应的 \(L^2/L^1\) 范数。

对上节的 \(z=|v|\) 重复该证明时，每个新增项

\[
d_j\langle D_{h_j}z,(z-t)^+\rangle
\]

都非负，位于不等式左侧，可以直接舍去。因此证明中的每个上界保持不变，得到

\[
\boxed{v\in L^\infty(-a,a).}
\]

更定量地，存在只依赖 \(a\)、\(B\) 和余项核的常数 \(C\)，使

\[
\lVert v\rVert_\infty
\le C\bigl(\lVert v\rVert_2+\lVert f\rVert_\infty\bigr)
\le C'\lVert v\rVert_2.
\]

上述论证实际上证明了一个比 Weil 所需稍广的命题：有限个实系数平移项也可先取系数绝对值进入
Kato 上界，再以非负 \(D_h\) 成对处理。

## 5. 最优边界阶上界

有界性使完整右端

\[
c_0v+\sum_jd_j(T_{h_j}+T_{-h_j})v+f
\]

属于 \(L^\infty(-a,a)\)。区间满足统一外球条件，所以
Hernández-Santamaría--López Ríos--Saldaña 2024 的 Theorem 1.1 适用。零模态具有连续代表，
在区间外连续为零，并满足

\[
\boxed{
|v(x)|
\le C\,\ell\bigl(a-|x|\bigr)^{1/2},
\qquad
\ell(r)=\frac1{|\log(\min\{r,0.1\})|}.}
\]

因此经典点值 \(v(\pm a)=0\) 现在可在这个连续代表意义下恢复，但它是 M2-R1 正则性定理的输出，
不能作为早先 form-domain 计算的输入。边界消失不是多项式阶，而是最优 logarithmic 阶上界。

## 6. 尚未得到 Hopf 非退化下界

2024 Hopf 型引理还要求函数非负、非平凡，并满足纯 \(L_\Delta\) 的弱超解不等式
\(\mathcal E_L(v,\phi)\ge0\)（\(\phi\ge0\)）。note 005 已证明，对 \(a>1/6\)，完整 Weil 形式不满足
标准绝对值收缩，因而不能由 semigroup positivity 自动选择非负 ground state；此外，Weil 方程中的
光滑卷积项也不自动给出上述超解符号。

所以当前严格结论是

\[
|v(x)|=O\!\left(\ell(a-|x|)^{1/2}\right),
\]

而不是

\[
|v(x)|\asymp\ell(a-|x|)^{1/2}.
\]

M2-R 的剩余边界铰链已经缩为：

- 从首次退化的额外结构同时证明零模态单一符号和所需的超解不等式；或
- 为可能变号的零模态定义并证明非零的 signed boundary coefficient / extension flux。

## 7. 来源与新结论边界

- Bartłomiej Dyda, Sven Jarohs and Firoj Sk,
  *The Dirichlet Problem for the Logarithmic p-Laplacian*,
  [arXiv:2411.11181](https://arxiv.org/abs/2411.11181)，Theorem 6.7 及其 superlevel 证明。
- Víctor Hernández-Santamaría, Luis Fernando López Ríos and Alberto Saldaña,
  *Optimal boundary regularity and a Hopf-type lemma for Dirichlet problems involving the logarithmic
  Laplacian*, [arXiv:2401.18033](https://arxiv.org/abs/2401.18033)，Theorem 1.1。
- Masatoshi Suzuki,
  *Weil's quadratic form via the screw function*,
  [arXiv:2606.09096](https://arxiv.org/abs/2606.09096)，有限 prime-shift 与连续余项公式。

正的离散跳跃改写、Kato 后的增广不等式、finite-shift \(L^\infty\) 晋级及其对 Weil 零模态的
边界应用是本项目的新推论。本文没有证明首次退化零模态单一符号，也没有使用 Hopf 下界。
