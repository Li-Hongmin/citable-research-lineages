> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 完整 Weil joint virial 的驻定性与边界异常项

日期：2026-08-11。

本文补全 [note 044](044-renormalized-log-pohozaev-hinge-and-prime-virial.md) 的逐项尺度公式，
并说明为什么完整 joint virial 不可能在首次退化零模态上产生普通的严格符号。真正可能承重的对象只剩
不属于形域切空间的 logarithmic boundary anomaly。

## 1. 向内酉缩放

固定 \(a>0\)，将 \(u\) 零延拓到全线，令

\[
(U_su)(x)=e^{s/2}u(e^sx),\qquad s\ge0.
\tag{1}
\]

则 \(\operatorname{supp}U_su\subset(-a,a)\)。在 active prime 集不跨阈值、且以下各项可微时，
完整 Weil 形式满足

\[
\boxed{
\left.\frac d{ds}\right|_{0+}Q_W^a(U_su)
=\|u\|_2^2+V_{\rm pr}(u)+V_r(u)+V_{\rm pol}(u).}
\tag{2}
\]

这里 \(d_n=\log n\)、\(\alpha_n=\Lambda(n)/\sqrt n\)，

\[
C_u(d)=\int_{\mathbf R}u(x+d)\overline{u(x)}\,dx,
\]

且

\[
V_{\rm pr}(u)
=-2\sum_{d_n<2a}\alpha_nd_n\operatorname{Re}C_u'(d_n).
\tag{3}
\]

等价地，在 Fourier 表示合法时，

\[
V_{\rm pr}(u)
=2\sum_{d_n<2a}\alpha_nd_n
\int_{\mathbf R}\xi\sin(d_n\xi)|\widehat u(\xi)|^2\,d\xi.
\tag{4}
\]

若 \(k=r_1''\) 是移除 polar 后的光滑余核，则

\[
V_r(u)=\iint [k(t)+tk'(t)]u(y)\overline{u(x)}\,dy\,dx,
\qquad t=x-y.
\tag{5}
\]

记

\[
c=\int\cosh(x/2)u(x)\,dx,
\qquad h=\int\sinh(x/2)u(x)\,dx,
\]

\[
j_s=\int x\sinh(x/2)u(x)\,dx,
\qquad j_c=\int x\cosh(x/2)u(x)\,dx.
\]

则 polar 项的精确导数为

\[
\boxed{
V_{\rm pol}
=-2|c|^2-2\operatorname{Re}(\bar c j_s)
+2|h|^2+2\operatorname{Re}(\bar h j_c).}
\tag{6}
\]

特别地，偶扇区的 invisible 条件 \(c=0\) 或奇扇区的 invisible 条件 \(h=0\) 都推出

\[
V_{\rm pol}=0.
\tag{7}
\]

## 2. 驻定性恒等式

设 \(Q\) 是闭半正定 Hermitian 形式，\(u\in D(Q)\) 且 \(Q(u,u)=0\)。Cauchy--Schwarz
不等式立即给出

\[
Q(u,w)=0\qquad\forall w\in D(Q).
\tag{8}
\]

因此，若 \(s\mapsto u_s\in D(Q)\) 在 \(s=0\) **以形范数可微**，\(u_0=u\)，则

\[
\boxed{
\left.\frac d{ds}\right|_0Q(u_s,u_s)
=2\operatorname{Re}Q(u,\dot u_0)=0.}
\tag{9}
\]

应用于首次退化 \(Q_W^a\succeq0\)、\(u\in\ker A_a\)，式 (2) 的普通可微版本只能给出精确抵消

\[
\boxed{
\|u\|_2^2+V_{\rm pr}(u)+V_r(u)+V_{\rm pol}(u)=0,}
\tag{10}
\]

不可能给出严格同号矛盾。

## 3. 数值门控

在 \(a=\frac12\log5,1,1.2\) 的偶、奇 Galerkin 近零分支上，Archimedean、prime 与 polar
导数分别为 \(O(1)\)，但总 joint virial 的中心差分随步长减半约缩小四倍。例如
\(a=\frac12\log5\)：

\[
\begin{array}{c|ccc}
&h=10^{-3}&5\cdot10^{-4}&2.5\cdot10^{-4}\\
\hline
\text{even}&-1.15\cdot10^{-7}&-2.87\cdot10^{-8}&-7.18\cdot10^{-9}\\
\text{odd}&-1.83\cdot10^{-6}&-4.57\cdot10^{-7}&-1.14\cdot10^{-7}
\end{array}
\]

这是式 (9) 的二阶差分误差，而不是稳定的非零 virial。改变 Galerkin rank 后残余微小符号还会变化。
该计算只作结构门控；定理部分是式 (8)--(10)。

## 4. 真正剩余的异常接口

对一般 logarithmic 零模态，\(U_su\) 虽对 \(s\ge0\) 留在形域，但未知其在 \(s=0\) 以形范数
可微。事实上：

- \(C_u(d)\) 只自动连续，不保证在 \(d=\log n\) 可微；
- prime virial 的一阶 Fourier multiplier 不受 logarithmic form norm 控制；
- dilation generator 可能不属于 \(D(Q_W^a)\)。

因此 (9) 失败时产生的不是普通 bulk virial，而是边界异常项。pure logarithmic 候选正是

\[
|\mathcal B_Ru|^2,
\qquad
\mathcal B_Ru=\lim_{x\uparrow a}
\sqrt{\log\frac1{a-x}}\,u(x).
\]

这里的“候选”不能由二次型缩放本身推出；[note 046](046-direct-dilation-does-not-produce-logarithmic-boundary-trace.md)
证明 logarithmic 主形式的缩放差商对所有形域数据恒为全局 (2\|u\|^2)，而 prime 端点层为
(o(s))。因此下述异常只能来自本征方程专属的 Green/commutator 边界配对。

故联合尺度路线的正确铰链不是证明 (2) 的 bulk 部分严格为正，而是证明一个异常 Pohozaev 公式：

\[
\boxed{
\text{右差商}
=\text{bulk 的驻定抵消}+\text{非负且非零的 boundary anomaly}.}
\tag{11}
\]

这需要同时建立一般变号零模态的精确 gauge trace、prime correlations 的异常差商及其与边界项的
联合极限。若没有这种非形域异常，joint virial 路线在代数上必然为零，不能排除首次退化。

## 5. 结论边界

严格关闭的陈述是：

\[
\boxed{\text{完整 joint bulk virial 具有稳定严格符号并排除零模态}.}
\]

保留的最小命题是式 (11) 的 boundary-anomaly identity。它比一般 virial 符号更窄，也比
note 044 的 pure-log 候选更精确：active prime 项必须在同一差商极限中处理，不能逐项假定经典可微。
