> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 局部加权频率反射的 Szegő 对偶证书

日期：2026-08-16。

note 337--340 已排除有限或全局 \(\ell^1\) 的 exact/近似反射，但当前
detector 使用固定权
\[
w(t)=\frac{|h(t)|}{2\pi},
\]
所以全实轴 Bohr 均方不能直接给出局部下界。本 note 给出一个严格的
局部对偶接口：在已有的 Szegő 外函数条件下，任何正频率近似的误差都被一个
显式的“截断 Möbius 平移核”控制。

## 假设与记号

假设 \(w=|O|^2\) 几乎处处成立，其中 \(O\) 是 note 195 的无零 Hardy
外函数。令 \(\widetilde O(t)=\overline{O(t)}\)。按 Fourier 变换
\[
\widehat f(\xi)=\int_{\mathbb R}f(t)e^{-i\xi t}\,dt
\]
的约定，\(\widehat{\widetilde O}\) 支持在 \([0,\infty)\)；记
\[
o(\xi):=\widehat{\widetilde O}(\xi).
\]
对任意 \(Q\in C_c^\infty((0,\infty))\)，令 \(q\) 为其逆 Fourier 变换，并定义
\[
g_Q(t)=\widetilde O(t)\,q(t).
\]
则 \(\widehat{g_Q}=(2\pi)^{-1}o*Q\)，仍支持在 \((0,\infty)\)。

## 对偶消去正频率

令
\[
A_c(t)=\sum_{m\ge1}c_m e^{it\log m}
\]
为任意绝对收敛的正频率 Dirichlet 级数。由于
\(\widehat{g_Q}\) 支持在正半轴且 \(Q\) 远离零频率，
\[
\int_{\mathbb R}A_c(t)g_Q(t)\,dt=0.
\tag{1}
\]
另一方面，令有限 Möbius 反射模式
\[
G_N(t)=\sum_{n\le N}\mu(n)e^{-it\log n}.
\]
定义
\[
\mathcal K_{N,o}(\eta)
:=\frac1{2\pi}\sum_{n\le N}
\mu(n)\,\mathbf 1_{0<\eta<\log n}\,
o(\log n-\eta),\qquad \eta>0.
\tag{2}
\]
直接使用卷积公式得到
\[
\int_{\mathbb R}G_N(t)g_Q(t)\,dt
=\int_0^\infty \mathcal K_{N,o}(\eta)Q(\eta)\,d\eta.
\tag{3}
\]

定义局部加权距离
\[
\operatorname{dist}_w(G_N,\mathcal A_+)
:=\inf_{A_c}\left(\int_{\mathbb R}
w(t)|G_N(t)-A_c(t)|^2\,dt\right)^{1/2},
\]
其中 \(\mathcal A_+\) 是上述正频率 Dirichlet 级数类。因
\[
\int_{\mathbb R}\frac{|g_Q(t)|^2}{w(t)}\,dt
=\int_{\mathbb R}|q(t)|^2\,dt
=\frac1{2\pi}\int_0^\infty |Q(\eta)|^2\,d\eta,
\tag{4}
\]
Cauchy--Schwarz、(1)--(3) 给出严格下界
\[
\boxed{
\operatorname{dist}_w(G_N,\mathcal A_+)
\ge \sqrt{2\pi}\,
\|\mathcal K_{N,o}\|_{L^2(0,\infty)}.
}
\tag{5}
\]
这里右端的常数只取决于 Fourier 归一化；若把 \(Q\) 在
\(C_c^\infty((0,\infty))\) 中取逼近 \(\overline{\mathcal K_{N,o}}\)，
(5) 的对偶范数没有损失。

## 这道局部门的算术内容

式 (2) 是有限 Möbius 平移核，而不是一般 Fourier 误差：
\[
\mathcal K_{N,o}(\eta)
=\frac1{2\pi}\sum_{\eta<\log n\le\log N}
\mu(n)o(\log n-\eta).
\]
因此：

* 若能证明 \(\|\mathcal K_{N,o}\|_2\) 有随 \(N\) 增长的统一下界，
  就能排除局部加权的小误差反射；
* 若只能得到 \(O(1)\) 或趋零的下界，则它只说明 exact reflection 不可能，
  不能支付 \(\sqrt N\) 级正能量；
* 要使 (5) 达到 \(\sqrt N\) 量级，必须对这组移动平移的 Möbius signed
  和建立新的 \(L^2\) 算术估计；仅由 \(w\ge0\)、Szegő 外函数或普通
  Cauchy--Schwarz 不会产生该估计。

作为归一化检查，若暂取一个模型密度
\(o(\xi)=e^{-\xi}\mathbf 1_{\xi\ge0}\)，则
\[
\mathcal K_{N,o}(\eta)
=\frac{e^\eta}{2\pi}
\sum_{e^\eta<n\le N}\frac{\mu(n)}{n}.
\tag{6}
\]
所以对偶证书确实退化为一个显式的 Möbius 尾和，而不是抽象的频率范数。
这个模型不宣称是当前 \(V_{15}\) 的外函数，只用于核对 (2)--(5) 的方向和
归一化。

令 \(A_j=\sum_{n\le j}\mu(n)/n\)。在每个区间
\(\log k<\eta<\log(k+1)\) 上，(6) 的尾和等于 \(A_N-A_k\)，故有精确离散
恒等式
\[
4\pi^2\|\mathcal K_{N,o}\|_2^2
=\sum_{k=1}^{N-1}\left(k+\frac12\right)|A_N-A_k|^2.
\tag{7}
\]
这说明即使在最简单的外函数模型中，所需的 \(\sqrt N\) 级对偶证书也不是
由平方自由计数自动给出，而是一个关于加权 Möbius 尾和的独立算术命题。

这个接口因此把 note 337 的“局部 arithmetic intertwiner”具体化为一个
可检验的双线性问题，同时明确没有把外函数构造误当成 RH 证明。
