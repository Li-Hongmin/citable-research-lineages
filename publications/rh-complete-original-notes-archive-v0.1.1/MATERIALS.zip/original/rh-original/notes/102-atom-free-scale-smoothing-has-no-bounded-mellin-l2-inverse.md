> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 无原子尺度平滑不存在有界 Mellin \(L^2\) 反演

日期：2026-08-14。

依赖：
[note 097](097-continuous-log-dilation-removes-the-endpoint-without-losing-the-detector.md)、
[note 099](099-log-dilation-is-a-strict-l2-contraction-with-one-derivative-inverse.md)。

证据等级：分布导数的 Lebesgue 分解、精确 Mellin 乘子与连续版
Wiener 均方恒等式。本文证明一个一般 no-go：任何真正消去 note 096
端点原子的尺度测度，都不可能在原加权 \(L^2\) 尺度上产生有界反演。

## 1. 一般尺度测度与乘子

沿用 note 097 的对数核

\[
f(x):=F(e^x),
\qquad
Df=\kappa\delta_\alpha+h(x)\,dx,
\qquad \kappa\ne0,
\tag{1}
\]

其中 \(h\in L^1_c(\mathbb R)\)。取任意紧支撑有限复 Borel 测度 \(\nu\)，
定义

\[
g_\nu(x):=\int f(x-y)\,d\nu(y),
\qquad
G_\nu(t):=g_\nu(\log t),
\tag{2}
\]

\[
(\mathcal A_\nu U)(x)
:=\int U(e^yx)\,d\nu(y).
\tag{3}
\]

与 note 097 相同，

\[
\boxed{
(Dg_\nu)_{\rm sing}
=\kappa\,\tau_\alpha\nu_{\rm sing}.
}
\tag{4}
\]

更精确地，对纯原子/奇异连续分解
\(\nu_{\rm sing}=\nu_{\rm pp}+\nu_{\rm sc}\)，有

\[
(Dg_\nu)_{\rm pp}=\kappa\tau_\alpha\nu_{\rm pp},
\qquad
(Dg_\nu)_{\rm sc}=\kappa\tau_\alpha\nu_{\rm sc}.
\tag{4a}
\]

因而

\[
Dg_\nu\text{ 无原子}
\Longleftrightarrow
\nu\text{ 无原子},
\tag{5}
\]

而更强的

\[
g_\nu\in W^{1,1}(\mathbb R)
\Longleftrightarrow
\nu\ll dy.
\tag{6}
\]

所以“无跳跃”与“\(W^{1,1}\) 平滑”不等价。例如取标准 Cantor
测度，\(g_\nu\) 连续但 \((Dg_\nu)_{\rm sc}\ne0\)，因而
\(g_\nu\notin W^{1,1}\)。

尺度测度的 Mellin--Laplace 乘子为

\[
\boxed{
A_\nu(s):=\int_{\mathbb R}e^{sy}\,d\nu(y).
}
\tag{7}
\]

对任意固定 \(\sigma\in\mathbb R\)，在

\[
H_\sigma
:=L^2\!\left((0,\infty),x^{-2\sigma-1}dx\right)
\tag{8}
\]

中作幺正变换

\[
v(z):=e^{-\sigma z}U(e^z).
\tag{9}
\]

则 \(\|v\|_{L^2(dz)}=\|U\|_{H_\sigma}\)。定义共轭算子

\[
(\mathcal T_{\nu,\sigma}v)(z)
:=e^{-\sigma z}(\mathcal A_\nu U)(e^z)
=\int e^{\sigma y}v(z+y)\,d\nu(y).
\tag{10}
\]

它是 Fourier 乘子算子，且

\[
\widehat{\mathcal T_{\nu,\sigma}v}(t)
=A_\nu(\sigma+it)\widehat v(t).
\tag{11}
\]

## 2. 无原子迫使竖线乘子任意小

固定 \(\sigma\in\mathbb R\)，并令

\[
d\mu_\sigma(y):=e^{\sigma y}\,d\nu(y).
\tag{12}
\]

它仍是紧支撑有限复测度，且它与 \(\nu\) 有完全相同的原子集。
又有

\[
A_\nu(\sigma+it)
=\int e^{ity}\,d\mu_\sigma(y).
\tag{13}
\]

直接展开平方并交换积分，得

\[
\begin{aligned}
\frac1{2T}\int_{-T}^T
|A_\nu(\sigma+it)|^2\,dt
&=\iint
\frac{\sin(T(y-z))}{T(y-z)}
\,d\mu_\sigma(y)d\overline{\mu_\sigma}(z).
\end{aligned}
\tag{14}
\]

其中在 \(y=z\) 处按连续延拓将该 sinc 因子定义为 \(1\)。

将对角线的原子质量与非对角线分开，并使 \(T\to\infty\)，
受控收敛给出连续版 Wiener 恒等式

\[
\boxed{
\lim_{T\to\infty}\frac1{2T}\int_{-T}^T
|A_\nu(\sigma+it)|^2\,dt
=\sum_{y\in\mathbb R}
e^{2\sigma y}|\nu(\{y\})|^2.
}
\tag{15}
\]

因此，若 \(\nu\) 无原子，则对每个 \(\sigma\in\mathbb R\)，

\[
\boxed{
\liminf_{|t|\to\infty}|A_\nu(\sigma+it)|=0.
}
\tag{16}
\]

若进一步 \(\nu\ll dy\)，则 Riemann--Lebesgue 引理给出更强的

\[
A_\nu(\sigma+it)\longrightarrow0
\qquad(|t|\to\infty).
\tag{17}
\]

## 3. 不存在原 \(H_\sigma\) 范数的有界反演

由 (11)，\(\mathcal A_\nu:H_\sigma\to H_\sigma\) 的最佳有界下常数等于
乘子 \(|A_\nu(\sigma+it)|\) 的本性下确界。若 \(\nu\) 无原子，
(15)--(16) 使该下确界为零。于是对每个 \(c>0\)，都存在
\(U\in H_\sigma\)，使

\[
\|\mathcal A_\nu U\|_{H_\sigma}
<c\|U\|_{H_\sigma}.
\tag{18}
\]

这也可以直接由 (16) 构造：在乘子连续且任意小的窄频带上
取 \(\widehat v\) 有支撑，再用 (9) 反变换。因此不存在任何有限 \(C\)
使

\[
\|U\|_{H_\sigma}
\le C\|\mathcal A_\nu U\|_{H_\sigma}
\qquad(U\in H_\sigma).
\tag{19}
\]

结合 (5)，得到一般不可兼容性：

\[
\boxed{
\begin{gathered}
Dg_\nu\text{ 无端点原子}
\quad\Longrightarrow\quad
\mathcal A_\nu\text{ 在每个 }H_\sigma
\text{ 上不有界下。}
\end{gathered}
}
\tag{20}
\]

若要求平滑后的核完全属于 \(W^{1,1}\)，则 (6) 迫使 \(\nu\)
绝对连续，此时 (17) 说明整条竖线的高频均被压制到零。
若只要求无跳跃，奇异连续测度不必满足 (17)，但 (16) 仍然排除
有界下；因而它不能成为稳定性逃逸。

## 4. 与 Mellin detector 非消零性的分工

尺度卷积还满足

\[
K_{G_\nu}(s)=K_F(s)A_\nu(s).
\tag{21}
\]

所以保持 note 094 的离线零点探测需要另外核验
乘子 \(A_\nu\) 在目标带不消零。但即使有更强的

\[
A_\nu(s)\ne0
\qquad(\Re s>0),
\tag{22}
\]

(16) 仍说明它在每条正竖线上不有界离开零。note 097 的对数均匀
尺度测度正是一个显式例子：它的 \(A_R(s)=(R^s-1)/(s\log R)\)
在 \(\Re s>0\) 无零，但 \(|A_R(\sigma+it)|\asymp|t|^{-1}\) 沿高频衰减。

因而两种“不丢信息”必须严格区分：

\[
\boxed{
\begin{aligned}
&A_\nu(\rho)\ne0
&&\Longrightarrow\text{ 定性的单点 Mellin 极点不被消去；}\\
&\inf_t|A_\nu(\sigma+it)|>0
&&\Longleftrightarrow\text{ 在该 }H_\sigma\text{ 线上存在有界反演。}
\end{aligned}
}
\tag{23}
\]

无原子端点正则化可以保留第一种性质，但由 (20) 必然丧失第二种性质。
这是 note 099 的一阶反演损失在任意尺度测度上的抽象结构原因。
反过来，若某条竖线的乘子有正下界，则 (15) 迫使 \(\nu\) 含非零原子，
并由 (4a) 在 \(Dg_\nu\) 中留下对应跳跃。“含原子”只是稳定反演的必要
而非充分条件；例如 \(\nu=(\delta_0+\delta_1)/2\) 在 \(\sigma=0\) 的乘子仍有零点。
