> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# μ 加权完整 ordinary boundary 的固定频率极点阻断

日期：2026-08-16。

本 note 补充 note 283：那里得到的
\(\mu(X)\)-加权完整 ordinary block 虽然在 \(t=0\) 消去零频，但对每个
充分小的非零固定频率，跨 \(X\) 的部分和仍然不可能具有平方根级上界。
阻断来自一个可直接审计的 \(s=1\pm it\) 极点；只有先对 \(t\) 做频率积分，
才可能利用振荡抵消。

## 1. 固定频率系数与 Euler 级数

令
\[
a_X(t):=\mu(X)\,|\Phi_X(t)|^2,
\qquad
\Phi_X(t)=\prod_{p\mid X}(1-p^{it}),
\]
其中 \(X\) 遍历平方自由整数，并设
\[
A_B(t):=\sum_{X\le B}a_X(t).
\]
对 \(\Re s>1\)，有限乘法展开给出
\[
L(s,t):=\sum_Xa_X(t)X^{-s}
 =\prod_p\bigl[1-(2-p^{it}-p^{-it})p^{-s}\bigr].
\tag{1}
\]
逐素数相乘得到 note 283 的精确分解
\[
L(s,t)=
\frac{\zeta(s-it)\zeta(s+it)}{\zeta(s)^2}S(s,t),
\tag{2}
\]
其中
\[
S(s,t)=\prod_p
\frac{[1-(2-p^{it}-p^{-it})p^{-s}]
      (1-p^{-s+it})(1-p^{-s-it})}{(1-p^{-s})^2}.
\tag{3}
\]
局部 \(p^{-s}\) 一次项抵消，所以 \(S\) 在
\(\Re s>1/2+\eta\) 局部一致绝对收敛并全纯。

## 2. 非零频率的真实极点

取 \(0<|t|<t_0\)，其中 \(t_0\) 足够小。\(s_+(t)=1+it\) 附近，
\(\zeta(s-it)\) 在 \(s=s_+\) 有留数 1，而其余因子在该点有限。因此
\[
L(s,t)=\frac{R_+(t)}{s-(1+it)}+O_t(1),
\tag{4}
\]
其中
\[
R_+(t)=
\frac{\zeta(1+2it)S(1+it,t)}{\zeta(1+it)^2}.
\tag{5}
\]
同理在 \(s_-(t)=1-it\) 有共轭极点，留数为
\[
R_-(t)=\overline{R_+(t)}.
\tag{6}
\]

\(S(1,0)=1\)，且 \(S\) 在上述邻域连续；\(\zeta(1+it)\) 与
\(\zeta(1+2it)\) 在充分小的非零 \(t\) 上均不为零。因此可取
\(t_0>0\)，使得
\[
R_+(t)\ne0 \qquad(0<|t|<t_0).
\tag{7}
\]
更精细地，利用 \(\zeta(1+u)=u^{-1}+\gamma+O(u)\)，有
\[
R_+(t)=\frac{it}{2}+O(t^2),
\qquad t\to0.
\tag{8}
\]
这解释了零频 \(t=0\) 的退化：极点留数线性趋于零，但对每个固定非零
频率它并不消失。

## 3. 平方根部分和的不可能性

若对某个固定 \(t\in(0,t_0)\) 存在
\[
A_B(t)\ll_{t,\varepsilon}B^{1/2+\varepsilon},
\tag{9}
\]
则 Abel 部分求和将 \(L\) 延拓为
\[
L(s,t)=s\int_1^\infty A_x(t)x^{-s-1}\,dx
\tag{10}
\]
（有限初始项可吸收到右端），并使其在
\(\Re s>1/2+\varepsilon\) 全纯。式 (4)--(7) 与此矛盾。

故得到严格命题：
\[
\boxed{
0<|t|<t_0\quad\Longrightarrow\quad
\sum_{X\le B}\mu(X)|\Phi_X(t)|^2
\text{ 不可能满足 }O(B^{1/2+\varepsilon})\text{（固定 }t\text{）。}}
\tag{11}
\]

若对极点作形式 Perron 反演，主项的形状为
\[
\frac{R_+(t)}{1+it}B^{1+it}
 +\frac{R_-(t)}{1-it}B^{1-it},
\tag{12}
\]
但把 (12) 升级为完整渐近式还需要余项和零点的轮廓估计；命题 (11)
本身不需要这些额外估计。

## 4. 对 RH 算术桥的含义

固定频率平方根界被极点严格排除，并不排除频率积分后的抵消。对完整
boundary 聚合，真正可能变小的是
\[
\int h(t)A_B(t)\,dt,
\]
其中 \(R_+(t)\sim it/2\) 与 \(B^{it}\) 的振荡可以在 \(t\) 上产生
积分分部的对数节省。因而可行的候选桥必须同时：

1. 保留 \(t\) 的 signed oscillation，而不能逐频率取绝对值；
2. 控制 \(t\) 接近零的极点振幅与远频余项；
3. 另外支付从完整 divisor block 回到原始 half-lattice 的 cutoff remainder。

这把 note 283 的“待补 uniform Perron 引理”进一步具体化为：
完整聚合可以利用跨频率抵消，但任何逐固定频率的平方根估计路线均已被
真实极点排除。本 note 不声称 RH，也不提供原始 half-lattice 的平方根界。

