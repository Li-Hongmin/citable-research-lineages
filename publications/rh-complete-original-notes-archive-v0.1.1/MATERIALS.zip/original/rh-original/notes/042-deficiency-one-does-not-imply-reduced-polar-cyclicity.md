> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Deficiency \((1,1)\) 不推出 reduced polar-cyclicity

日期：2026-08-11。

本文核对 Suzuki 能量空间中的最小导数算子与 reduced Weil 算子，并给出一个更强抽象反例。结论是：
simple symmetric operator 的 deficiency indices \((1,1)\) 及 defect-vector cyclicity 不会自动推出

\[
\ker M_a^\sigma\cap\phi_\sigma^\perp=\{0\}.
\tag{1}
\]

## 1. Suzuki defect vectors 与 polar vectors 不同

取

\[
\lambda<\lambda_a=\inf\sigma(A_a),
\qquad T_a=A_a-\lambda I>0.
\]

Suzuki 在 \(H(T_a)\) 上定义最小导数 \(D_a=i\,d/dx\)，其 adjoint defect equation 为

\[
D_a^*v_z=zv_z
\iff
T_av_z=e^{-izx}.
\tag{2}
\]

因此 defect vector 是 \(v_z=T_a^{-1}e^{-izx}\)，而不是指数函数本身。极点向量
\(e^{\pm x/2}\) 对应 \(z=\mp i/2\) 时式 (2) 的右端；\(c=\cosh(x/2)\)、
\(s=\sinh(x/2)\) 只是这些右端的奇偶组合。

在 \(H(S_a)\) 的等距模型中同样如此。那里

\[
S_a=G_a-\lambda(-\Delta_N)^{-1},
\]

而 defect representatives 满足

\[
(S_av)(x)=Ce^{-izx}-\frac1z.
\tag{3}
\]

指数仍是 \(S_a\) 作用后的数据，不是 defect vector。

## 2. Cyclicity 属于导数扩展，不属于 \(M_a^\sigma\)

simple symmetric operator 的标准结论控制

\[
\overline{\operatorname{span}}
\{\ker(D_a^*-z):z\in\mathbf C\setminus\mathbf R\}=H(T_a),
\tag{4}
\]

或一个 defect vector 在某个 self-adjoint extension 的 resolvent orbit 下的 cyclicity。式 (1) 只给
一个固定 polar functional 在 \(\ker M_a^\sigma\) 上的非退化性。现有理论没有证明：

- \(\ker M_a^\sigma\) 对某个导数 self-adjoint extension invariant/reducing；
- \(M_a^\sigma\) 是该扩展的单重函数演算；
- 一个 polar 正交关系会传播为对整个 defect orbit 正交。

此外 Suzuki 的能量空间由完整 \(A_a\) 构造，而 (1) 使用删去极点秩一项后的 \(M_a^\sigma\)。
rank-one 删除会改变能量内积与 adjoint，不能直接继承原 deficiency 交换图。

## 3. \(\lambda=0\) 与域的循环缺口

Suzuki 始终先取 \(\lambda<\lambda_a\)，以保证 \(T_a\) 与 \(S_a\) injective。首次退化时
\(\lambda_a=0\)，仍只能取 \(\lambda<0\)。若直接令 \(\lambda=0\)，则 \(T_a=A_a\) 已有核，
defect solution 不再由 (2) 唯一确定；\(S_a=G_a\) 的 injectivity 又正是待证对象。因此
\(\lambda=0\) 的 defect-vector 论证会循环使用结论。

还有独立定义域缺口：Friedrichs 零模态只先验属于 \(D(A_a)\)，其扩展导数属于 \(H(S_a)\)，而
Suzuki 明确指出 \(H(S_a)\not\subset L^2\)。普通 \(L^2\) defect/reproducing-vector 公式不能在未证
额外正则性时直接应用。

## 4. 更强抽象反例

令

\[
S=-i\frac d{dx},
\qquad D(S)=H_0^1(0,1).
\]

这是 closed simple symmetric operator，deficiency indices 为 \((1,1)\)。取周期 self-adjoint
extension \(D\)，其规范本征向量为 \(e_n(x)=e^{2\pi inx}\)。defect vector \(h=e^{-x}\) 满足

\[
\langle e_n,h\rangle
=\frac{1-e^{-1}}{1+2\pi in}\ne0,
\]

故 \(h\) 对 \(D\) cyclic。

定义 bounded positive operator \(M=g(D)\)，其中

\[
g(0)=g(2\pi)=0,
\qquad g(2\pi n)=1\quad(n\ne0,1).
\]

则 \(M\succeq0\)、\([M,D]=0\)，但

\[
\ker M=\operatorname{span}\{e_0,e_1\}.
\]

因此存在 \(0\ne u\in\ker M\) 满足 \(\langle u,h\rangle=0\)。所以即使同时加强到

\[
S\text{ simple},\quad n_\pm(S)=1,\quad h\text{ cyclic for }D,
\quad M\succeq0,\quad[M,D]=0,
\]

仍不能推出 polar-cyclicity。

## 5. 精确剩余条件

对固定向量 \(h\)，

\[
\ker M\cap h^\perp=\{0\}
\]

等价于线性泛函 \(u\mapsto\langle u,h\rangle\) 在 \(\ker M\) 上单射，即

\[
\boxed{
\dim\ker M\le1,
\quad
\dim\ker M=1\Rightarrow P_{\ker M}h\ne0.}
\tag{5}
\]

Deficiency indices 不提供 (5) 的任一部分。实际 prime translations/reflections 甚至不与参考导数
扩展交换，因此 Suzuki 的对象比上述反例假设更弱。

结论：defect-vector 表示没有降低 zero-cyclicity 的难度。除非另证 \(M_a^\sigma\) 的零核简单且
polar overlap 非零，或建立一个全新的 reducing-subspace intertwining，否则该路线关闭。
