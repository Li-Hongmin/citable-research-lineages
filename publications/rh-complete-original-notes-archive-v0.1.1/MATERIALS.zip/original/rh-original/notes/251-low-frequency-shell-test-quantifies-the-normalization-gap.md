> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 低频 shell 测试：归一化缺口不是可忽略常数

日期：2026-08-16。

## 测试对象

沿用 `main (19).tex` 中 Theorem 19.216 的单个 frozen class 假设。取

\[
  F_L(u)=1_{1\le u\le L},
  \qquad C=1,
  \qquad q\ge 8L,
\]

并令

\[
  S_h(q,L)=\sum_{u=1}^{L}F_L(u)e(-hu/q).
\]

这个序列满足源码所列的基本质量条件
\(​\|F_L\|_1=L\)、\(\|F_L\|_\infty\le1\)、
\(\operatorname{TV}(F_L)\le2\)，且 (F_L(0)=0)，所以不能用“去掉零点
对角项”解释掉它。

对 (h=2)，几何和公式给出

\[
 |S_2(q,L)|
 =\frac{|\sin(2\pi L/q)|}{|\sin(2\pi/q)|}.
\]

当 (q\ge8L) 时，(2\pi L/q\le\pi/4)，因此

\[
 |S_2(q,L)|\ge cL
\tag{1}
\]

其中 (c>0) 是绝对常数。例如可取由
\(\sin x\ge 2x/\pi\) 与 \(\sin y\le y\) 得到的固定下界。

## raw 与 weighted energy 的精确差异

在 dyadic 块 (H=1)（即 (1<|h|\le2)）中，(h=\pm2) 已经给出

\[
 \sum_{1<|h|\le2}|S_h(q,L)|^2\ge 2c^2L^2.
\tag{2}
\]

所以源码 Definition 20.12 所对应的 raw shell energy 至少是

\[
 E_{\rm raw}\ge 2c^2L^2,
\tag{3}
\]

而 Theorem 19.216 证明中使用的 (q^{-1})-weighted 版本至少是

\[
 E_{\rm wt}\ge \frac{2c^2L^2}{q}.
\tag{4}
\]

这两者恰相差 (q)；当 (q) 随参数增长时不是固定归一化常数。

取 (L=\lfloor q^{1/2}/8\rfloor)，则 (4) 仍为绝对常数量级，而源码证明
声称由其质量和 harmonic estimate 得到的量级

\[
 \frac{LH+\log(2q)}{q}
 \quad(H=1)
\tag{5}
\]

只有 (O(q^{-1/2}))（忽略 polylog 因子）。因此即使暂时接受
\(q^{-1}\) 归一化，给定的 ​\(\ell^1\)/sup/TV 假设仍不足以推出 displayed
energy bound；这正是 note 248 的低频反例的定量版本。

如果删除 (q^{-1}) 试图与 Definition 20.12 的 raw energy 对齐，那么 (5)
至多同时乘以 (q)，变成 (O(L+\log q))，而 (3) 仍为 (\asymp L^2)。
因此“删掉 (q^{-1})”不是修复：低频零频抵消或真正的 \(\ell^2\) 结构仍然
必须额外证明。

## 对原参数预算的含义

源码中的 (c_\eta) 是由 frozen shell fibre 的原始系数直接求和得到的；若不补
新的 cancellation，最坏低频块的能量按支持长度的平方增长。把 raw energy
直接送入后续 Cauchy--Schwarz 会把原证明中依赖 (q^{-1}) 的每个预算至少放大
一个 (q_\eta)，而 (q_\eta=Q_*\mathfrak m_\eta) 并非有界常数。

所以后续必须先完成以下之一：

1. 证明每个实际 \(\Gamma_{\eta,r,\ell}\) 有足够的零频消失，使其不能模拟
   (F_L)；或
2. 用真正的 \(\ell^2\)/spectral estimate 取代只依赖 \(\ell^1\)、sup 和 TV
   的 summation-by-parts 账本；并同时明确 (q_\eta^{-1/2}) 的来源。

在这两步之前，不能把 Theorem 19.216 的 energy estimate 视为已证，也不能把
它送入 Theorem 19.218 的 capacity/Cauchy--Schwarz 链。

## 裁决

这个测试把 note 250 的形式缺口升级为量级缺口：raw/weighted 两种定义相差
增长中的 (q_\eta)，而两种定义各自都不能由原稿列出的低正则性假设得到所需的
低频上界。该结论仍只是对证明接口的否定，不是对 RH 的否定。
