> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# cutoff-free 局部 Weil 严格正性推进到 a_11=(log 11)/2

日期：2026-08-16。

## 定理

令 a_11=(log 11)/2。对当前局部 Weil 算子 A_a 的两个 parity sector，有

~~~text
A_{a_11}^+ > 0,    A_{a_11}^- > 0.
~~~

由闭形式域的零延拓与 min--max 单调性，进一步得到

~~~text
A_a > 0  对所有 0 < a <= (log 11)/2.
~~~

因此首次退化尺度满足 a_deg > (log 11)/2。

这仍不是全尺度 Weil 正性或黎曼猜想的证明。

## 1. 闭形式应用引理（共同核与闭包）

以下论证补齐从目标 Weil 闭形式到 checker 下界的接口。固定一个 parity
\(\sigma\in\{+,-\}\)，令

\[
 \mathcal H_\sigma=L^2(0,a_{11})_\sigma,
 \qquad P=P_{400},\quad Q=I-P,
\]

并以相应的整数／半整数 Fourier 基定义 \(P\)。取共同形式核
\(\mathcal K_\sigma\) 为该基的有限线性组合。下面直接证明它在**实际目标
Weil form norm** 中稠密；证明不把正性或单调性误用成范数等价，也不要求
余项 \(\mathcal R_{850}^\sigma\) 单独为有界形式。

先记 \(I=(-a_{11},a_{11})\)，并把函数零延拓到 \(\mathbb R\)。对任意有界
区间 \(I\)，存在只依赖 \(I\) 的常数 \(0<c<C<\infty\)，使

\[
 c\sum_{k\in\mathbb Z}\log(2+|k|)|\widehat u_k|^2
 \le \|u\|_2^2+
 \iint_{|x-y|\le1}\frac{|u(x)-u(y)|^2}{|x-y|}\,dx\,dy
 \le C\sum_{k\in\mathbb Z}\log(2+|k|)|\widehat u_k|^2. \tag{FC}
\]

这里偶扇区的 \(\widehat u_k\) 是 \(2a_{11}\)-周期延拓的整数 Fourier
系数；奇扇区先作关于零点的奇延拓，再作满足
\(u(x+2a_{11})=-u(x)\) 的反周期延拓，其频率恰为
\((k+\tfrac12)\pi/a_{11}\)。为完整起见，(FC) 的直接证明如下。把积分按
\(|x-y|<\delta\) 与其补集分开，其中
\(0<\delta<\min(1,a_{11})/4\)。补集核可积，故只贡献
\(O(\|u\|_2^2)\)。在近对角区，把零延拓积分按跨越端点与不跨越端点的
四个区块反射回一个周期胞。须注意，零延拓在端点还产生权
\(w(x)\asymp1+|\log\operatorname {dist}(x,\partial I)|\)，不能把它宣称为
\(L^2\)-有界。所需的两向比较是直接的：圆周 seam 项由
\(|r-s|^2\le2|r|^2+2|s|^2\) 控制于两个端点 killing 项；反向则固定一个
长度 \(\delta/2\) 的内侧区间，对
\(|r|^2\le2|r-s|^2+2|s|^2\) 先在该区间平均、再对到端点的尺度作
\(dt/t\) 积分，得到
\[
 \int_Iw|u|^2\le C\bigl(\|u\|_2^2+E_{\rm circle}(u)\bigr).
\]
同一论证对跨 seam 的值在 odd 情形插入符号 \(-1\)，绝对值不变。
因此零延拓能量与周期（odd 为反周期）圆周能量加 \(L^2\) 范数两向等价。
圆周核由 Tonelli 与 Parseval 对角化；第 \(k\) 个
对角元为
\[
 2\int_0^\delta\frac{1-\cos(\omega_k t)}t\,dt,
 \]
其中 \(\omega_k=k\pi/a_{11}\)（even）或
\(\omega_k=(k+\tfrac12)\pi/a_{11}\)（odd）。代换
\(s=|\omega_k|t\)，并在 \([0,1]\)、各个长度 \(2\pi\) 的区间及最后
余段上估计，得到该积分为 \(2\log(2+|k|)+O(1)\)，且 \(O(1)\) 对
\(k\) 一致。这就证明 (FC)，包括半整数奇基；有限和的情形先成立，
一般情形由 Tonelli 后取单调极限。

于是若 \(P_m\) 是上述实际基的 Fourier 截断，则对每个
\(u\in H(I)_\sigma\)，(FC) 给出
\[
 \|u-P_mu\|_{H(I)}^2\asymp
 \sum_{|k|>m}\log(2+|k|)|\widehat u_k|^2\longrightarrow0. \tag{FC2}
\]
note 004 的闭形式恒等式（Chen--Weth Theorem 3.1 与 Suzuki Theorem
1.1）给出 \(D(\mathfrak a_{a_{11}}^\sigma)=H(I)_\sigma\)；有限 prime
平移和光滑余项是 \(L^2\)-有界形式。因此共同平移后的目标 Weil form
norm 与 (FC) 的 \(H(I)\) norm 等价。由 (FC2)，\(\mathcal K_\sigma\)
是目标形式的 form core。下形式 \(\mathfrak l_\sigma\) 的
\(T_\sigma\)-form norm 也由同一权 \(t_k^\sigma=\log(2+|k|)+O(1)\)
刻画，故同一截断还证明 \(\mathcal K_\sigma\) 是其 form core。这里目标
norm 已包含完整 \(\mathcal R_{850}^\sigma\)；没有从该余项的正性或单调
形式极限推断任何范数等价。

在此核上，源码中的分解逐项等于

\[
 \mathfrak a_{a_{11}}^\sigma
 =D^\sigma+B_0^\sigma+FF^*+\mathcal R_{850}^\sigma,
 \qquad \mathcal R_{850}^\sigma\succeq0,                 \tag{1}
\]

其中 \(B_0^\sigma\) 包含全部 active-prime 项、\(n<500\) 的正
Yukawa atoms 及 signed polar；\(F=(r_{500}^\sigma,\ldots,
r_{849}^\sigma)\)，而 \(\mathcal R_{850}^\sigma\) 是余下正 atom
形式的单调极限。特别地，odd polar 在 \(B_0^-\) 中带负号。

置 \(B_F=PF\)、\(V=QF\)，并定义

\[
\begin{aligned}
 M_\sigma&=P(D^\sigma+B_0^\sigma)P+B_FB_F^*,\\
 C_\sigma&=PB_0^\sigma Q+B_FV^*,\\
 T_\sigma e_q^\sigma&=t_q^\sigma e_q^\sigma,
 \qquad t_q^\sigma=d_q^\sigma-\rho_\sigma \quad(q\ge400).
                                                        \tag{2}
\end{aligned}
\]

这里 \(C_\sigma:Q\mathcal H_\sigma\to P\mathcal H_\sigma\) 有界：
\(B_0^\sigma\) 是有限个有界 prime-shift 与有限秩项之和，\(F\) 也
是有限秩。trigamma 级数给出 \(t_q^\sigma\) 严格递增，本次区间输入又
认证 \(t_{400}^\sigma>0\)，故 \(T_\sigma\ge\tau_\sigma Q>0\)。

令 \(\mathfrak l_\sigma\) 是矩阵

\[
 L_\sigma=\begin{pmatrix}M_\sigma&C_\sigma\\
 C_\sigma^*&T_\sigma\end{pmatrix}                     \tag{3}
\]

在 \(P\mathcal H_\sigma\oplus D(T_\sigma^{1/2})\) 上的形式。它是
闭形式：对角形式 \(0\oplus T_\sigma\) 闭，有限维 \(M_\sigma\) 与
有界 cross 是 form-bounded 的有界扰动。对
\(x\in P\mathcal H_\sigma\)、\(y\in Q\mathcal K_\sigma\)，(1)--(3)
的 \(P\)-\(P\) 与 \(P\)-\(Q\) 块完全相同，而差只在 \(Q\)-\(Q\)
块及正 atom 余项：

\[
\begin{aligned}
 \mathfrak a_{a_{11}}^\sigma[x+y]-\mathfrak l_\sigma[x,y]
 ={}&\langle Q(B_0^\sigma+\rho_\sigma I)Qy,y\rangle
   +\|V^*y\|^2\\
   +\mathcal R_{850}^\sigma[x+y]\ge0.                 \tag{4}
\end{aligned}
\]

第二项的正性来自源码使用的严格界：even 为 active-prime 范数界；odd
再把负 polar 的范数 \(2(\sinh a_{11}-a_{11})\) 纳入 \(\rho_-\)。
因此 (4) 是由目标形式逐项推出的比较，不是作为假设写入。以下给出不依赖
形式值逐点连续性的闭包步骤。取共同下界的平移 \(b\)，使
\(\mathfrak a_b=\mathfrak a+b\|\cdot\|^2\) 与
\(\mathfrak l_b=\mathfrak l+b\|\cdot\|^2\) 均非负。若
\(u_n\in\mathcal K_\sigma\) 在 \(\mathfrak a_b\)-form norm 下趋于
\(u\)，则由核上的 \(\mathfrak l_b\le\mathfrak a_b\) 有
\(\mathfrak l_b[u_n-u_m]\le\mathfrak a_b[u_n-u_m]\to0\)。
\(\mathfrak l_b\) 的闭性说明 \(u\in D(\mathfrak l)\) 且
\(u_n\to u\) 于 \(\mathfrak l_b\)-form norm；对核上不等式取极限便得
\(\mathfrak l_b[u]\le\mathfrak a_b[u]\)。正 atom 余项则由其单调形式
极限保留非负性。故比较延拓到完整目标形式域，并同时得到该域连续嵌入
\(D(T_\sigma^{1/2})\)：

\[
 \boxed{\mathfrak a_{a_{11}}^\sigma\succeq\mathfrak l_\sigma}. \tag{5}
\]

由于 \(T_\sigma^{-1}\) 有界，可在形式域内配方：

\[
 \mathfrak l_\sigma[x,y]
 =\|T_\sigma^{1/2}y+T_\sigma^{-1/2}C_\sigma^*x\|^2
 +\langle S_\sigma x,x\rangle,
 \quad S_\sigma=M_\sigma-C_\sigma T_\sigma^{-1}C_\sigma^*. \tag{6}
\]

这是本应用所需的自足闭形式 Schur 引理；不声称任意可数 response family
的更一般版本。

## 2. checker 的 Schur 下界与合同识别

note 089 的式 (4)--(15) 给出统一的 Loewner--Parseval 机制。这里把其端点从 a_*=(log(201/20))/2 换成 a_11，并重新生成两个 parity 的全部 parent cache。

在 a_11 的 active-prime 图上，已有严格四步证书

~~~text
sup T^4 1 = 73.81706267887072825278...
rho_p < 2.931158.
~~~

该图界直接在较大窗口 a_11 上计算；较小窗口只通过零延拓压缩。因此对两个 parity 均可取

~~~text
rho_+ = rho_p,
rho_- = rho_p + 2*(sinh(a_11)-a_11).
~~~

令 P=P_400，Q=I-P，t_q=d_q-rho_sigma。q=400 与 q=8000 的 t_q 均严格为正。取完整 500:850 Yukawa family F=B_F+V，并保留 base--atom、atom--atom 及所有 P--Q cross。

对 c_q=P B_0 e_q、v_q=V^*e_q、U_q=c_q+B_F v_q，完整 Parseval 恒等式为

~~~text
R_tot = sum_{q>=400} U_q U_q^*
~~~

并在 q_f=8000 处使用单调尾支付

~~~text
sum_{q>=q_f} U_q U_q^*/t_q <= (R_tot-R_1)/t_qf.
~~~

因此 note 089 的 cutoff-free lower operator满足

~~~text
L_F <= A_{a_11},
L_F > 0 只需其 Q-block T_sigma>0 与有限 P-Schur 矩阵 G_sigma>0.
~~~

更精确地，Fourier 坐标中 \(C_\sigma e_q=U_q\)，所以 Parseval 给出
\(C_\sigma C_\sigma^*=R_{\rm tot}\)，且该正矩阵级数在有限维
\(P\mathcal H_\sigma\) 上按迹范数收敛。于是 checker 构造

\[
 G_\sigma=M_\sigma-
 \sum_{400\le q<8000}\frac{U_qU_q^*}{t_q^\sigma}
 -\frac{R_{\rm tot}-R_1}{t_{8000}^\sigma}
 \preceq S_\sigma.                                    \tag{7}
\]

源码变量逐项为
`M=P0+RP/t400+BF*BF.T`、`C e_q=U_q=c_q+BF*v_q`、
`T=diag(t_q)`；`G1` 是 (7) 的有限带加权和，`RTOT-R1` 是同一
\(U_q\) 的剩余 Parseval Gram。这里 `P0=PL0P-RP/t400`，故没有遗漏
clean base。由 \(t_q\) 递增，(7) 的尾替代方向正确。

`left_contract` 依次施加 verified graph 保存的 Householder 矩阵；每一步
都是 \(H_j=I-2h_jh_j^*/\|h_j\|^2\) 的正交合同。令
\(U_H=H_1\cdots H_m\)，checker 实际分解的是
\(U_H^*G_\sigma U_H\)，随后作 \(7\oplus393\)（even）或
\(6\oplus394\)（odd）Schur 合同。因此补块与核心 pivots 全正等价于
同一个 \(G_\sigma>0\)，不是另一个未经识别的矩阵。结合 (5)--(7)，

\[
 \mathfrak a_{a_{11}}^\sigma[x+y]\ge
 \|T_\sigma^{1/2}y+T_\sigma^{-1/2}C_\sigma^*x\|^2
 +\langle G_\sigma x,x\rangle.                        \tag{8}
\]

## 3. even sector 256-bit certificate

round-1 永久包的统一 256-bit Arb parent/base、R=280 verified graph、
F_{500:850} 和 q_f=8000 输出给出补空间 Cholesky 最小 pivot

~~~text
0.040799562910896252229291041959... +/- 2.20e-58 > 0.
~~~

核心置换 (6,2,3,4,5,1,0) 下七个 Schur pivot 全正，最后一个为

~~~text
3.68238777398334030e-50 +/- 5.91e-68 > 0.
~~~

所以 G_+>0，且 T_+>0，得到 L_F^+>0，进而 A_{a_11}^+>0。

## 4. odd sector 256-bit certificate

同一永久包的 odd 输出给出补空间 Cholesky 最小 pivot

~~~text
0.007336690629086577841762831004... +/- 6.52e-63 > 0.
~~~

核心置换 (3,5,4,1,0,2) 下六个 Schur pivot 全正，最后一个为

~~~text
3.64350282733546052388e-45 +/- 7.93e-66 > 0.
~~~

所以 G_->0，且 T_->0，得到 L_F^->0，进而 A_{a_11}^->0。

## 5. 复现与证据边界

永久证书、源码、日志及哈希位于

~~~text
computations/bundles/log11-local-weil-positivity-round1/
~~~

固定的大 parent 仍按包内 `PARENT-SHA256.txt` 在 `scratch/` 重生；永久小型
结果在 `results/`。checker 现在要求核心 pivot 数量恰为 even 7／odd 6，
且每个 pivot 下端严格为正；非正或区间不定 pivot 均以非零状态退出。

本定理的承重范围是 cutoff-free 的两个 parity 局部算子在单一端点及其更小尺度上的正性。它没有给出：

1. a>(log 11)/2 的局部正性；
2. 全局 Weil 正性；
3. Möbius reciprocal-product 二次型的平方根级 signed cancellation；
4. 黎曼猜想。

因此下一道真正的 RH 门仍是全局算术 intertwiner 或等价的平方根级 Möbius energy bound，而不是再增加同一有限 Fourier family。
