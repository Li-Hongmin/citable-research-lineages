> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 连续对数 dilation 消去 Mertens 端点而不损失 Mellin detector

日期：2026-08-14。

依赖：[note 094](094-k1-a2-high-divisor-cell-has-a-zero-free-mellin-detector.md)、
[note 095](095-k1-a2-cell-reduces-to-moving-scale-mobius-covariance.md)、
[note 096](096-finite-dilations-cannot-remove-the-a2-mertens-endpoint.md)。

证据等级：分布导数、Mellin 卷积与离散 Abel 恒等式。本文给出一个无端点原子的
新 RH 等价核，但不估计其 Möbius 均方，因而不证明 RH。

## 1. 尺度测度的奇异部分就是端点障碍

将 note 094 的权函数按零延拓到 \((0,\infty)\)：

\[
F(t)=\log\frac1t\left(\frac2{\pi t}+\sin 2\pi t\right)
\mathbf 1_{(2/3,1)}(t).
\tag{1}
\]

令

\[
\alpha:=\log\frac23,
\qquad
f(x):=F(e^x),
\qquad
\kappa:=f(\alpha+)
=\log\frac32\left(\frac3\pi-\frac{\sqrt3}{2}\right)>0.
\tag{2}
\]

因为 \(f(0-)=f(0+)=0\)，而 \(x=\alpha\) 是唯一的值跳跃，故

\[
Df=\kappa\delta_\alpha+h(x)\,dx,
\qquad
h=f'_{\rm cl}\mathbf 1_{(\alpha,0)}\in L^1(\mathbb R).
\tag{3}
\]

取任意紧支撑有限复 Borel 测度 \(\nu\) 作为对数尺度测度，并置

\[
g_\nu(x):=\int_{\mathbb R}f(x-y)\,d\nu(y),
\qquad
G_\nu(t):=g_\nu(\log t)
=\int_{\mathbb R}F(te^{-y})\,d\nu(y).
\tag{4}
\]

卷积与分布导数给出精确式

\[
\boxed{
Dg_\nu
=\kappa\,\tau_\alpha\nu+(h*\nu)(x)\,dx.
}
\tag{5}
\]

由于 \(h*\nu\in L^1(\mathbb R)\)，Lebesgue 分解的唯一性进一步给出

\[
\boxed{
(Dg_\nu)_{\rm sing}=\kappa\,\tau_\alpha\nu_{\rm sing}.
}
\tag{6}
\]

这里对复测度仍成立：将 \(\nu=\nu_{\rm ac}+\nu_{\rm sing}\) 作复测度的
Lebesgue 分解，\(\tau_\alpha\nu_{\rm ac}\) 绝对连续，
\(\tau_\alpha\nu_{\rm sing}\) 奇异，而 \((h*\nu)dx\) 绝对连续。故它们之间不可能
发生奇异抵消。又 \(g_\nu\in L^1_c\) 且 \(\kappa\ne0\)，因此：

\[
\begin{aligned}
Dg_\nu\text{ 无原子}
&\Longleftrightarrow \nu\text{ 无原子},\\
g_\nu\in W^{1,1}(\mathbb R)
&\Longleftrightarrow \nu\ll dy.
\end{aligned}
\tag{7}
\]

note 096 的有限 dilation 刚性恰是 \(\nu\) 为有限原子测度的特例；它不延伸到
连续尺度密度。

## 2. 显式无原子核

固定 \(R>1\)，令 \(L=\log R\)，并取对数区间上的均匀概率测度

\[
d\nu_R(y)=\frac1L\mathbf 1_{[0,L]}(y)\,dy.
\tag{8}
\]

对应的乘性移动平均为

\[
\boxed{
G_R(t)
=\frac1{\log R}\int_1^R F(t/\lambda)\frac{d\lambda}{\lambda}
=\frac1{\log R}\int_{t/R}^{t}F(u)\frac{du}{u}.
}
\tag{9}
\]

它支撑于 \([2/3,R]\)，在两个端点均取零，并且

\[
G_R\in W^{1,\infty}(0,\infty),
\qquad
\boxed{
tG_R'(t)=\frac{F(t)-F(t/R)}{\log R}
\quad\text{a.e.}
}
\tag{10}
\]

特别地，它的 Stieltjes 导数不再含任何端点 Dirac 原子。当 \(R=3/2\) 时，
这个差商变成相邻 cell 的固定尺度差

\[
tG_{3/2}'(t)
=\frac{F(t)-F(2t/3)}{\log(3/2)}.
\tag{11}
\]

定义

\[
S_{N,R}:=\sum_{d\ge1}\mu(d)G_R(d/N),
\qquad
M(x):=\sum_{d\le x}\mu(d).
\tag{12}
\]

若将 note 095 的 \(U_X=\sum_d\mu(d)F(d/X)\) 对实数 \(X>0\) 作同样定义，
则还有精确的对数尺度平均式

\[
\boxed{
S_{N,R}=\frac1{\log R}\int_1^R U_{\lambda N}\frac{d\lambda}{\lambda}.
}
\tag{12a}
\]

由于 \(d\mapsto G_R(d/N)\) 有限支撑，全局离散 Abel 求和直接给出

\[
\boxed{
S_{N,R}
=\sum_{d\ge1}M(d)
\left[G_R(d/N)-G_R((d+1)/N)\right].
}
\tag{13}
\]

式 (13) 没有 \(M(\lfloor2N/3\rfloor)\) 的固定非零系数。更精确地，存在只依赖
\(R,F\) 的 \(C_R\)，使

\[
|S_{N,R}|^2
\le \frac{C_R}{N}
\sum_{2N/3-1<d<RN}|M(d)|^2,
\tag{14}
\]

事实上，若 (13) 中的差分非零，则

\[
2N/3-1<d<RN.
\tag{15}
\]

该区间含 \(O_R(N)\) 个整数，而 (10) 给出

\[
\left|G_R(d/N)-G_R((d+1)/N)\right|\le \frac{C_R}{N}.
\tag{16}
\]

故 Cauchy--Schwarz 给出 (14)。对 \(Y<N\le2Y\) 求和并交换 \(N,d\)；每个固定
\(d\) 的内层权重不超过

\[
\sum_{Y<N\le2Y}\frac1N\le 1.
\tag{17}
\]

因而

\[
\boxed{
\sum_{Y<N\le2Y}|S_{N,R}|^2
\le C_R
\sum_{2Y/3-1<d<2RY}|M(d)|^2.
}
\tag{18}
\]

这消去了单独的 Mertens 端点，但没有无条件支付右端的平方根均方。

## 3. Mellin detector 原封不动

令

\[
K_R(z):=\int_0^\infty G_R(t)t^{z-1}\,dt.
\tag{19}
\]

由 Fubini 定理与 \(t=\lambda u\)，

\[
\boxed{
K_R(z)=K(z)A_R(z),
\qquad
A_R(z):=\frac{R^z-1}{z\log R},
\qquad A_R(0):=1.
}
\tag{20}
\]

\(A_R\) 的全部零点为

\[
z=\frac{2\pi i k}{\log R},
\qquad k\in\mathbb Z\setminus\{0\}.
\tag{21}
\]

故 \(A_R(z)\ne0\) 于 \(\Re z>0\)。结合 note 094 已严格证明的
\(K(z)\ne0\;(1/2\le\Re z\le1)\)，得

\[
\boxed{
K_R(z)\ne0
\qquad (1/2\le\Re z\le1).
}
\tag{22}
\]

对 \(\Re s>2\) 交换绝对收敛和，并对

\[
\phi_{s,R}(u):=G_R(1/u)u^{-s}
\tag{23}
\]

作复合梯形求和。在对数坐标中令 \(L=\log R\)、
\(b=L^{-1}\mathbf1_{[0,L]}\)、\(f(x)=F(e^x)\)，则
\(G_R(e^x)=f*b(x)\)。由于 \(Df\) 是紧支撑有限测度且
\(Db=L^{-1}(\delta_0-\delta_L)\)，

\[
D^2(f*b)=Df*Db\in\mathcal M_c(\mathbb R).
\tag{24}
\]

光滑坐标变换与光滑乘子保持这一阶正则性：对每个
\(s\)-紧集 \(C\)，\(D^2\phi_{s,R}\) 的总变差由只依赖 \(C,R,F\)
的常数控制。取

\[
\widehat\phi(\xi)=\int_{\mathbb R}\phi(u)e^{-i\xi u}\,du,
\tag{25}
\]

则 \(|\widehat\phi_{s,R}(\xi)|\ll_{C,R}|\xi|^{-2}\)。Poisson 求和
给出局部一致的

\[
\sum_{n\ge1}\phi_{s,R}(n/d)
-d\int_{\mathbb R}\phi_{s,R}(u)\,du
=d\sum_{k\ne0}\widehat\phi_{s,R}(2\pi kd)
=O_{C,R}(d^{-1}).
\tag{26}
\]

因而

\[
\sum_{n\ge1}G_R(d/n)n^{-s}
=d^{1-s}K_R(s-1)+E_d(s),
\qquad
E_d(s)=O_{C,R}(d^{-\Re s-1}).
\tag{27}
\]

每个 \(E_d\) 对 \(s\) 全纯，且 \(\sum_d\mu(d)E_d(s)\) 在 \(\Re s>0\)
的紧集上正常收敛。故存在全纯于 \(\Re s>0\) 的 \(H_R\)，
使初始在 \(\Re s>2\) 有

\[
\boxed{
\sum_{N\ge1}S_{N,R}N^{-s}
=\frac{K_R(s-1)}{\zeta(s-1)}+H_R(s).
}
\tag{28}
\]

右边同时给出该 Dirichlet 级数同一分支在 \(\Re s>0\) 的亚纯延拓；
这里不声称左边原级数在整个延拓域收敛。

因此对任意非平凡零点 \(\rho\) 且 \(\Re\rho>1/2\)，对数平滑因子 \(A_R(\rho)\)
既不消去 \(K(\rho)\)，也不消去 \(1/\zeta(s-1)\) 在 \(s=\rho+1\) 的极点。

## 4. 无端点原子的 RH 等价式

**定理 1。** 对每个固定 \(R>1\)，

\[
\boxed{
\mathrm{RH}
\Longleftrightarrow
\forall\varepsilon>0,\qquad
\sum_{Y<N\le2Y}|S_{N,R}|^2
\ll_{\varepsilon,R}Y^{2+\varepsilon}.
}
\tag{29}
\]

**证明。** RH 蕴含
\(M(x)=O_\delta(x^{1/2+\delta})\)。将它代入 (13)，并使用 (10) 的一致
Lipschitz 界，得

\[
S_{N,R}=O_{\delta,R}(N^{1/2+\delta}).
\tag{30}
\]

取 \(\delta<\varepsilon/2\) 即得 (29) 右边。

反向，若 \(\rho=\beta+i\gamma\) 是 \(\zeta\) 的 \(q\) 重零点且 \(\beta>1/2\)，
则 (22)--(28) 使该 Dirichlet 级数在 \(s=\rho+1\) 有 \(q\) 阶极点。为核对离散
dyadic 指数，反设下式左边为零，并置

\[
\mathcal A_k:=\sum_{2^k<N\le2^{k+1}}|S_{N,R}|^2,
\qquad
b_k:=\frac{\mathcal A_k^{1/2}}
{2^{k(\beta+1/2)}k^{q-1}}.
\tag{31}
\]

则 \(b_k\to0\)。对 \(0<\eta\le1\)，Cauchy--Schwarz 给出

\[
\sum_{2^k<N\le2^{k+1}}
|S_{N,R}|N^{-\beta-1-\eta}
\le C_\beta b_k k^{q-1}2^{-k\eta}.
\tag{32}
\]

因而该 Dirichlet 级数在 \(\Re s>\beta+1\) 绝对收敛并等于 (28) 的延拓。
再沿 \(s=\rho+1+\eta\) 使 \(\eta\downarrow0\)，利用

\[
\eta^q\sum_{k\ge1}k^{q-1}2^{-k\eta}
\longrightarrow\frac{\Gamma(q)}{(\log2)^q}
\tag{33}
\]

并先后分离 \(b_k\) 的有限前缀与一致小尾，可得级数乘 \(\eta^q\)
趋于零；这与 \(q\) 阶极点的非零最高系数矛盾。故

\[
\limsup_{Y\to\infty}
\frac{\sum_{Y<N\le2Y}|S_{N,R}|^2}
{Y^{2\beta+1}(\log Y)^{2q-2}}>0,
\tag{34}
\]

这与 (29) 右边矛盾。\(\square\)

```mermaid
flowchart LR
  A["finite dilation = atomic scale measure"] --> B["unavoidable Abel atoms"]
  C["log-uniform continuous dilation"] --> D["AC kernel: no Abel atoms"]
  C --> E["multiplier A_R(z)"]
  E --> F["zeros only on Re z=0"]
  F --> G["same offline-zero detector"]
```

## 5. 任意有限阶端点 jet 也可消去

令 \(\nu_{R,m}=\nu_R^{*m}\)，并定义

\[
G_{R,m}(t):=\int F(te^{-y})\,d\nu_{R,m}(y).
\tag{35}
\]

对数坐标中 \(\nu_{R,m}\) 的密度是 \(m\) 阶紧支撑 B-spline。由 \(f\in BV_c\)
与卷积正则性，

\[
G_{R,m}(e^x)\in C_c^{m-1}(\mathbb R),
\qquad
K_{R,m}(z)=K(z)A_R(z)^m.
\tag{36}
\]

还有一个对离散余项有用的更精确正则性。令
\(g_m=f*b^{*m}\)，则分布意义下

\[
D^{m+1}g_m
=Df*(Db)^{*m}
=L^{-m}\sum_{j=0}^m(-1)^j\binom mj\tau_{jL}Df
\in\mathcal M_c(\mathbb R).
\tag{37}
\]

对应的

\[
\phi_{s,R,m}(u):=G_{R,m}(1/u)u^{-s}
\tag{38}
\]

支撑于 \([R^{-m},3/2]\)，且 \(D^{m+1}\phi_{s,R,m}\) 的总变差
在 \(s\)-紧集上一致有界。与 (26) 同样的 Poisson 求和因而给出

\[
\sum_{n\ge1}\phi_{s,R,m}(n/d)
-d\int\phi_{s,R,m}
=O_{C,R,m}(d^{-m}),
\tag{39}
\]

以及

\[
E_{d,m}(s)=O_{C,R,m}(d^{-\Re s-m}),
\qquad
H_{R,m}(s):=\sum_d\mu(d)E_{d,m}(s)
\text{ 全纯于 }\Re s>1-m.
\tag{40}
\]

所以对任意预先给定的有限阶数，都能同时做到：

\[
\boxed{
\text{紧支撑核的该阶端点 jet 全消失}
\quad+\quad
\text{右半平面 Mellin detector 不消失}.
}
\tag{41}
\]

因而任何有限阶端点正则化本身都不能弱化 note 095 的 RH 级 signed covariance。
连续 dilation 确实移除了 note 096 的原子障碍，但所有离线零点仍由 (28)
完整保留。此外，(12a) 是实尺度的连续平均，不是原 high-divisor Gram
中已存在的有限坐标。因而本文不会把无端点核的均方界自动转回原始
single-cell 均方；它只精确证明，端点原子不是该 Mellin detector 不可移除的本质。
一般也不能仅凭正则性将 (40) 再向左推一阶：(37) 的原子部分
通常非零，因而并无更高一阶的免费有限变差控制。
