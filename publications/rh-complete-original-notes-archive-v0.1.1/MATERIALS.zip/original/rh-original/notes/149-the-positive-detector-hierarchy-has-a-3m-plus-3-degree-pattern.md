> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正 detector 层级的 (3m+3) 次模式与真正缺口

日期：2026-08-15。

相关文件：[note 145](145-degree-fifteen-is-minimal-for-four-residue-positive-detectors.md)、
[note 146](146-a-positive-degree-eighteen-detector-removes-five-collective-residues.md)、
[note 147](147-degree-twenty-one-candidate-removes-six-collective-residues.md)。

## 1. 一般次数下界

若要求

\[
V(0)=V(1)=\int_0^1V=0,
\qquad v_1=v_3=\cdots=v_{2m-1}=0,
\qquad P_V(y)\ge0,
\]

则 shifted Euler--Faulhaber 的 k=2,...,2m+1 项逐次强迫

\[
u^2(1-u)^{2m+1}\mid V(u).
\tag{1}
\]

若 \(\deg V\le3m+2\)，商次数至多 m-1，而剩余的
v3,v5,...,v(2m-1) 与零均值给出 m 个线性条件；对
m=1,...,10 这些矩阵均满秩。因此自然端点平坦类的首个非零可能次数是

\[
\boxed{\deg V=3m+3.}
\tag{2}
\]

## 2. 已验证的正方向

在次数 3m+3 的一维解空间中，选择使 P_V>=0 的 orientation。精确
有理计算已验证 m=1,...,43 的 falling-factorial Bernstein 系数；下表列出前十层：

\[
\begin{array}{c|c|c}
m&\deg V&\text{已验证的 residue}\ \hline
1&6&s=-1\\
2&9&s=-1,-3\\
3&12&s=-1,-3,-5\\
4&15&s=-1,-3,-5,-7\\
5&18&s=-1,-3,-5,-7,-9\\
6&21&s=-1,-3,-5,-7,-9,-11\\
7&24&s=-1,-3,-5,-7,-9,-11,-13\\
8&27&s=-1,-3,-5,-7,-9,-11,-13,-15\\
9&30&s=-1,-3,-5,-7,-9,-11,-13,-15,-17\\
10&33&s=-1,-3,-5,-7,-9,-11,-13,-15,-17,-19
\end{array}
\tag{3}
\]

脚本 [scan_positive_detector_family.py](../computations/scan_positive_detector_family.py)
在定义域 N=floor(y) 为正整数上执行全部有理断言；这不是把 N 错误连续化的数值扫描。
本次 m=11,...,43 的并行精确计算在 OMEN 临时环境完成，脚本哈希与本地版本一致
(SHA-256: `86a57a5e970d5c89a1970677a973f409a2308595554dab815818df09e2489fc7`)；
这些有限层结果仍不替代对任意 m 的证明。

## 3. Mellin 形状

相应 Mellin 分母呈现稳定模式

\[
D_m(s)=\prod_{j=1}^{m}(s+2j)\prod_{k=2m+1}^{3m+3}(s+k),
\tag{4}
\]

而 K_m(s)=C_m(s-1)/D_m(s)，其中 C_m 非零，由 orientation 和归一化决定。
这保证每一层仍是 zero-free Mellin detector。

## 4. 为什么这还没有解决 RH

每个 m 都只给出

\[
\mathrm{RH}\iff T_m(x)\ll_\varepsilon x^{1/2+\varepsilon}.
\]

正性只保证 P_m(y)>=0，不保证 reciprocal-product 矩阵 PSD；note 148 的固定
2x2 负块对所有已构造层都存在。因此即使 (3) 能推广到所有 m，仍必须另行证明
作用于完整 Möbius 向量的 signed dispersion / commutator 估计。整族正 detector 本身
不会提供该平方根界。
