> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius-preconditioned detector 的除数反射与 parity 接口

日期：2026-08-17。

本 note 将 note 239 的 exact collapse 接到完整平方自由除数格的
complement reflection，明确说明剩余的 signed phase。

## 1. 完整除数格上的反射分解

取平方自由 \(X\)，令 \(\mathcal D_X=\{a:a\mid X\}\)，并定义
\[
 R_X e_a=e_{X/a},\qquad
 p(t):=\phi(e^t).
\]
由于 \(\phi\) 支撑于 \((0,1)\)，\(p\) 是单侧 log-kernel。对
\(a,b\mid X\)，note 239 的 reciprocal kernel 为
\[
 H_{a,b}=\phi(ab/X)=p\!\left(\log\frac{a}{X/b}\right)
 = (G_pR_X)_{a,b},
\quad
 (G_p)_{a,b}=p\!\left(\log\frac ab\right).
\tag{1}
\]

将 \(p=g+o\) 分解为偶部与奇部：
\[
 g(t)=\frac{p(t)+p(-t)}2,\qquad
 o(t)=\frac{p(t)-p(-t)}2.
\]
则 \(G_g\) 与 \(R_X\) 对易，\(G_o\) 与 \(R_X\) 反对易，而
\[
 H=(G_g-G_o)R_X.
\tag{2}
\]

## 2. Möbius parity

令 \(c_a=\mu(a)\)（\(a\mid X\)）。由于 \(X\) 平方自由，
\[
 R_Xc=\mu(X)c.
\tag{3}
\]
奇部 \(G_o\) 的二次型恒为零，因此由 (2) 得到精确恒等式
\[
 \boxed{
 c^*Hc=\mu(X)\,c^*G_gc.
 }
\tag{4}
\]
若 \(\widehat g\) 表示 Fourier 变换，右端又可写成
\[
 c^*G_gc
 =\frac1{2\pi}\int_{\mathbb R}
 \widehat g(\xi)\left|\sum_{a\mid X}\mu(a)a^{i\xi}\right|^2d\xi.
\tag{5}
\]
所以 exact \(\zeta^{-1}\) collapse 并没有消除 complement parity；
它把 reciprocal 二次型精确转成带 \(\mu(X)\) 符号的偶 log-kernel 能量。

## 3. 不能直接 PSD 化

因为 \(\phi(1)=0\)，有 \(g(0)=0\)。若 \(g\not\equiv0\) 且
\(\widehat g\ge0\)，Gaussian 正则化会给出
\[
 0=g(0)=\lim_{\varepsilon\downarrow0}
 \frac1{2\pi}\int_{\mathbb R}\widehat g(\xi)e^{-\varepsilon\xi^2}d\xi,
\]
从而 \(\widehat g\equiv0\)，矛盾。因此 \(\widehat g\) 必须变号。

这说明 (5) 不能成为普通 PSD Gram；在完整除数格上，奇偶
\(\mu(X)\) 反射符号和 Fourier signed phase 必须同时保留。若只取
\(|\widehat g|\)，就失去 (1)--(4) 的 exact arithmetic identity。

因此 note 239 的构造确实给出正 periodization 与 \(\zeta^{-1}\)，
但其可用的全局桥只能是 signed reflection/Feshbach 型，而不是
普通正 Gram。
