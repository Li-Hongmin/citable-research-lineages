> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# stretched-log 能量门不能单独越过低频局部化障碍

日期：2026-08-15。

本 note 检查 note 201 的
\[
E_N(w)\ll N^2e^{-\gamma\Lambda(N)}
\tag{1}
\]
是否能通过 \(h(0)>0\) 的低频局部化推出比经典 Mertens 零自由区更强的
部分和估计。结论是否定的：一阶 Lipschitz 门只返回同型的
\(Ne^{-c\Lambda(N)}\) 估计；高导数和 RKHS 需要新的算术输入。

## 1. 一阶局部化的精确后果

设 \(F_N(\xi)=\sum_{n\le N}\mu(n)n^{i\xi}\)、\(M(N)=F_N(0)\)，并假设
\(|h(\xi)|\ge c_0>0\) 当 \(|\xi|\le\delta_0\)。由于
\[
|F_N'(\xi)|\le\sum_{n\le N}\log n\le N\log N,
\]
当 \(N\) 足够大、\(\delta=|M(N)|/(2N\log N)\le\delta_0\) 时，
\(|F_N(\xi)|\ge|M(N)|/2\) 对 \(|\xi|\le\delta\) 成立。因此
\[
E_N(w)\ge
\frac{c_0}{2\pi}\int_{-\delta}^{\delta}|F_N(\xi)|^2d\xi
\ge \frac{c_0|M(N)|^3}{8\pi N\log N}.
\tag{2}
\]
合并 (1) 得
\[
\boxed{|M(N)|\ll
N(\log N)^{1/3}e^{-\gamma\Lambda(N)/3}.}
\tag{3}
\]
这仍是 \(N e^{-c\Lambda(N)}\) 的经典零自由区形状，而不是
\(N^{1/2+\varepsilon}\)。注意它相对于能量门
\(E_N\ll N^{1+\varepsilon}\) 所给的 \(N^{2/3+\varepsilon}\) 并非幂次改善：
\(e^{-\gamma\Lambda(N)}=N^{-o(1)}\)。

## 2. 更高导数不能仅由能量门产生增益

对任意 \(k\ge1\) 只有平凡的
\[
|F_N^{(k)}(\xi)|\le N(\log N)^k.
\tag{4}
\]
若只固定 \(F_N(0)=M(N)\)，而不控制
\(F_N^{(j)}(0)\)（\(1\le j<k\)），高阶 Taylor 余项不能保证
\(F_N\) 在更长区间保持大值；低阶项可先行抵消。因此 (4) 不给出
强于 (2) 的正局部能量下界。任何高阶改进都必须另行证明
对 \(\sum\mu(n)(\log n)^j\) 的 cancellation，这已是新的 Mertens 型输入。

## 3. RKHS 形式与最小新命题

对固定 \(\delta\le\delta_0\)，令
\[
G_{\delta,N}[m,n]
=\int_{-\delta}^{\delta}e^{i\xi\log(m/n)}d\xi
=\frac{2\sin(\delta\log(m/n))}{\log(m/n)}
\]
（对角值为 \(2\delta\)）。则
\[
E_N(w)\ge \frac{c_0}{2\pi}\,\boldsymbol\mu^*G_{\delta,N}\boldsymbol\mu.
\]
由于 \(G_{\delta,N}\) 是有限指数 Gram，正定；评价向量
\(\mathbf1=(1,\ldots,1)^T\) 满足精确 Cauchy--Schwarz 关系
\[
|M(N)|^2
\le(\boldsymbol\mu^*G_{\delta,N}\boldsymbol\mu)
(\mathbf1^*G_{\delta,N}^{-1}\mathbf1).
\tag{5}
\]
故从正能量门得到平方根级别，至少需要一个新的 uniform arithmetic
估计 \(\mathbf1^*G_{\delta,N}^{-1}\mathbf1=N^{o(1)}\)（或等价的
log-frequency Dirichlet-polynomial RKHS 估计）。它不由 \(h(0)>0\) 或
note 201 的正核能量自动推出；\(\log n\) 频率随 \(N\) 变密，正是该逆
Gram 的未解决部分。

因此 note 201 的严格贡献限于固定 Möbius 能量的
stretched-log 节省；在没有新 signed/intertwiner 或 inverse-Gram 输入前，
它不能越过低频 \(2/3\) 局部化门，也不能推出 RH。

## 4. 多项式频窗也不能消除零频项

为排除“把低频截断提高到多项式尺度即可获得幂次节省”的另一种可能，
令 \(T=N^\alpha\)（固定 \(0<\alpha<1\)），并暂时**假设**在
\(|t|\le T\) 上已有某个统一的零自由区 Perron 估计
\[
 \sup_{|t|\le T}|F_N(t)|
 \ll N\exp\{-c_\alpha L_\alpha(N)\},
 \qquad L_\alpha(N)=o(\log N).
\tag{6}
\]
这里不需要决定 \(L_\alpha\) 的具体指数；只要它是次对数的即可。
若 \(w(t)\ll (1+|t|)^{-p}\) 且 \(p>1\)，则低频部分至多为
\[
 \int_{|t|\le T}w(t)|F_N(t)|^2dt
 \ll_w N^2e^{-2c_\alpha L_\alpha(N)}.
\tag{7}
\]
高频部分可用 Dirichlet 多项式均值不等式
\[
 \int_T^{2T}|F_N(t)|^2dt\ll (T+N)N
\]
逐 dyadic 频带求和，得到
\[
 \int_{|t|>T}w(t)|F_N(t)|^2dt
 \ll_{w,p}N^2T^{-p}+NT^{1-p}
 \ll N^{2-\alpha p}+N^{1-\alpha(p-1)}.
\tag{8}
\]
所以即使把高频尾压到固定幂次，整体上界仍被 (7) 的
\(N^2e^{-c_\alpha L_\alpha(N)}=N^{2-o(1)}\) 主导。要得到
\(N^{1+\varepsilon}\)，必须在一个包含 \(t=0\) 的频窗内取得平方根级
\(F_N(t)\) 控制；这正是 RH-strength 的 Möbius 输入，而不是尾部截断
或大筛技术可以补上的误差。
