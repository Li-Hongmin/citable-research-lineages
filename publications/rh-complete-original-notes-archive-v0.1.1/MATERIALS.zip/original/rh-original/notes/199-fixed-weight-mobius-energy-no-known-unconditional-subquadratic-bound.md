> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定权 Möbius Dirichlet 能量：无条件基线与 RH-strength 缺口

日期：2026-08-15。

本 note 核对
\[
E_N(w)=\int_{\mathbb R}w(t)\left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt,
\qquad w\ge0,
\]
是否已有无条件的 \(N^{1+\varepsilon}\) 或固定幂次
\(N^{2-\delta}\)（\(\delta>0\)）统一上界。结论是一个严格的基线与缺口
说明：标准 Dirichlet 多项式均值定理只给 \(O_w(N^2)\)（固定频宽）。
下文另外证明无速率的 \(o(N^2)\)，但定向检索截至 2026-08-15 未找到
直接覆盖本固定 \(w\)、全 \(N\) 对象的无条件固定幂次次二次定理；这不是
“文献不存在”的数学证明。

## 1. 精确展开与无条件二次基线

令
\[
\check w(u)=\frac1{2\pi}\int_{\mathbb R}w(t)e^{itu}\,dt .
\]
若 \(w\in L^1(\mathbb R)\)，有限和与积分交换给出
\[
\boxed{
E_N(w)=\sum_{m,n\le N}\mu(m)\mu(n)\,
\check w\!\left(\log\frac mn\right).}
\tag{1}
\]
对角线为
\[
\check w(0)\sum_{n\le N}\mu(n)^2
=\frac{6\check w(0)}{\pi^2}N+O_w(\sqrt N),
\tag{2}
\]
但非对角项含有全部
\[
\sum_{m\ne n}\mu(m)\mu(n)\check w(\log(m/n)).
\tag{3}
\]
仅用 \(|\check w(u)|\le\|w\|_1/(2\pi)\) 给出 \(O_w(N^2)\)，不能改善幂次。

若 \(w\) 支持在 \([-T,T]\) 且有界，标准 Dirichlet 多项式均值定理
\[
\int_{-T}^{T}\left|\sum_{n\le N}a_n n^{it}\right|^2dt
\ll (T+N)\sum_{n\le N}|a_n|^2
\tag{4}
\]
取 \(a_n=\mu(n)\) 后同样得到
\[
E_N(w)\ll_w N^2
\qquad(T\ \text{固定}).
\tag{5}
\]
这是 Montgomery--Vaughan 型 mean-value/large-sieve 基线；它对角化不了
\(\log(m/n)\) 的近碰撞，故不提供 \(N^{1+\delta}\)（\(\delta<1\)）。
对当前 \(w=|h|/(2\pi)\) 的多项式频率尾，可用 dyadic 频窗与
\(\int (1+|t|)^A w(t)\,dt<\infty\) 得到同类 \(O_w(N^2)\) 基线。

在固定频窗 \(|t|\le T_0\) 内，经典 zeta 零自由区与 Perron 方法至多给出
形如
\[
\sup_{|t|\le T_0}\left|\sum_{n\le N}\mu(n)n^{it}\right|
\ll N\exp\!\left[-c(\log N)^{3/5}(\log\log N)^{-1/5}\right],
\tag{5a}
\]
即 \(N^{2-o(1)}\) 级的能量，而不是固定的 \(N^{2-\delta}\)。
对本项目的非紧支撑 \(w=|h|/(2\pi)\)，还必须同时证明
\(t\)-依赖常数和频率尾部的统一截断；本 note 不把 (5a) 的延伸当作已完成
的全 \(w\) 估计。

## 2. 次二次幂所需的最小新输入

设 \(\check w\) 在 \(0\) 的某邻域内不恒为零。取固定
\(0<\eta<1\)，只保留 \(m,n\asymp N\)、\(|m-n|\le\eta N\) 的部分，则
\(\log(m/n)=O(\eta)\)，该部分包含加权相关
\[
\sum_{|h|\le\eta N}
\sum_{N<m\le 2N-h}\mu(m)\mu(m+h)\,
\check w\!\left(\log\frac{m}{m+h}\right),
\tag{6}
\]
（边界端点可按 \(m,n\in[N,2N]\) 的同一 dyadic 壳调整），
其权在 \(h/m\) 上是平滑的。
因此任何 \(E_N(w)\ll N^{1+\varepsilon}\) 证明都必须在一个宏观
乘法邻域内保留 \(\mu(m)\mu(m+h)\) 的 signed cancellation；逐项取模、
平方自由密度或标准 mean-value theorem 均退回 \(N^2\)。

现有短区间 Möbius 结果通常是“几乎所有区间”或额外平均参数下的结论，
不直接给出同一个固定宏观区间、固定 multiplicative-ratio kernel 的
(6) 全部 signed 双和。相关范围可参见 Matomäki--Radziwiłł 关于
乘法函数短区间的工作：
<https://annals.math.princeton.edu/2016/183-3/p06>；
以及 Dirichlet polynomial mean-value 的标准应用：
<https://academic.oup.com/qjmath/article/73/2/729/6446139>。
这些来源不支持把 (6) 的固定尺度平方根界当作现成定理。

截至 2026-08-18 的新边界：Menon 的预印本
[`arXiv:2607.15574`](https://arxiv.org/abs/2607.15574)，Theorems 1.1、1.4
和 1.5，将 Möbius/Liouville 的短区间平均及 averaged-Chowla 误差进一步
改善到对数平方量级；其输入仍是对区间位置或移位参数的平均。该文第 1 节
还明确指出，这一方法在更强于对数衰减的范围存在大素数因子障碍。它没有给出
固定的乘法比值核
\(\check w(\log(m/n))\) 在全部 \(m,n\le N\) 上的 signed 二次型界，
因此不改变本项目的最小缺口：必须把这些平均短区间结果转移到一个
\(m\)-依赖的 multiplicative-ratio 权，或提供新的跨尺度 signed intertwiner。

需要区分一个可用但尚未完成转移的平均结果。Matomäki--Radziwiłł--Tao
的 averaged Chowla/Elliott 定理对 \(1\)-bounded multiplicative functions
（因而包括 \(\mu\)）给出形如
\[
\sum_{1\le h\le H}
\left|\sum_{n\le X}\mu(n)\mu(n+h)\right|
\ll XH\left(\frac{\log\log H}{\log H}
+\frac1{\log^{c}X}\right),\qquad 10\le H\le X,
\tag{6a}
\]
见原始论文 <https://arxiv.org/abs/1503.05121>。
并允许固定的 \(O(X)\) 平移参数。若能建立一个加权 dyadic localization
引理，把 (6) 的 \(m\)-依赖权
\(\check w(\log(m/(m+h)))\) 和所有相邻尺度块转移到 (6a)，则形式上可望得到
\(E_N(w)\ll N^2\log\log N/\log N\) 一类的 \(N^{2-o(1)}\) 改善。
但现有定理本身只控制移位平均的无权内和；它没有直接给出固定
multiplicative-ratio kernel 的全 \(E_N\) 估计。因此 (6a) 是最小的潜在
无条件入口，不是本项目已经获得的能量上界。

## 3. 为什么该门达到 RH-strength

对本项目的 \(w=|h|/(2\pi)\)，notes 194--195 已给出精确对偶：
若
\[
E_N(w)\ll_\varepsilon N^{1+\varepsilon},
\tag{7}
\]
则所有满足相应 \(W^{-1}\) 条件的 Mellin 测试函数满足
\[
\sum_{n\le N}\mu(n)\psi(n/N)\ll_{\psi,\varepsilon}N^{1/2+\varepsilon}.
\tag{8}
\]
若取零自由的 Szegő outer Mellin multiplier，则 (8) 的 Mellin 变换在
\(\Re s>1/2\) 给出 \(1/\zeta(s)\) 的解析延拓，从而推出 RH。
所以 (7) 不是一个可由 ordinary Gram 正性“软推出”的次要估计，
而是已经足以承载 RH 的算术门。

反向地，RH 型的 uniform twisted-Mertens 估计
\[
\sum_{n\le Y}\mu(n)n^{it}
\ll_{\varepsilon,A}Y^{1/2+\varepsilon}(1+|t|)^A
\tag{9}
\]
连同 \(w\) 的 \(2A\)-阶频率矩，直接推出
\[
E_N(w)\ll_{\varepsilon,w}N^{1+2\varepsilon}.
\tag{10}
\]
但 (9) 需要以 \(1/\zeta(s-it)\) 的 Perron 移位、零点界和频率尾为
输入；不能在当前项目中把它当作无条件结果。

## 4. 一个无条件但无速率的次二次结论

虽然当前没有固定幂次 \(N^{2-\delta}\) 的结果，但可以严格证明一个
\(o(N^2)\) 结论。假设 \(w\in L^1(\mathbb R)\)，令 \(K=\check w\)，则
Riemann--Lebesgue 引理给出 \(K\in C_0(\mathbb R)\)。对任意
\(\varepsilon>0\)，取 \(D\) 使 \(|K(u)|<\varepsilon\) 当 \(|u|>D\)。
远离比值对角 \(|\log(m/n)|>D\) 的部分绝对值至多
\(\varepsilon N^2\)。

剩余部分只涉及有限个 dyadic 比值块。设
\(I_j=(2^j,2^{j+1}]\)，且 \(|k-j|\le D/\log2+2\)。对每个固定偏移
\(d=k-j\)，连续函数
\[
F_d(x,y)=K(2^{-d}x/y),\qquad (x,y)\in[1,2]^2,
\]
由 Stone--Weierstrass 以任意精度 \(\varepsilon\) 逼近有限和
\(\sum_{r,s}c_{rs}x^ry^s\)。相应的主项因子化为
\[
\left(2^{-jr}\sum_{m\in I_j}\mu(m)m^r\right)
\left(2^{-(j+d)s}\sum_{n\in I_{j+d}}\mu(n)n^s\right).
\]
由 PNT 等价的 \(M(x)=\sum_{n\le x}\mu(n)=o(x)\) 及部分求和，对每个固定
\(r\) 有
\[
2^{-jr}\sum_{m\in I_j}\mu(m)m^r=o(2^j).
\]
对固定的有限秩逼近，给定 \(\eta>0\) 后存在 \(J_0\)，使 \(j\ge J_0\)
时上述每个归一化和的模都不超过 \(\eta 2^j\)；而
\(\sum_{j<J_0}2^{2j}=O_{J_0}(1)\)、\(\sum_{J_0\le j\le\log_2N}2^{2j}
\ll N^2\)。所以所有有限秩主项的 limsup 除以 \(N^2\) 不超过
\(C_D\eta^2\)，低 \(j\) 部分除以 \(N^2\) 趋于零。
先令 \(N\to\infty\)，再令有限秩逼近精度
\(\varepsilon\to0\)，得到
\[
\boxed{E_N(w)=o(N^2).}\tag{11}
\]
该论证只用 \(K\in C_0\) 与一阶 PNT；它没有给出任何统一衰减率，因而
不能替代所需的 \(N^{1+\varepsilon}\) 正能量门。若要把 (11) 提升成
\(N^{2-\delta}\)，必须给出带增长秩的多项式近似、其系数总量控制以及
定量的 Mertens 区间误差；这些正是当前缺失的额外算术输入。

## 5. 严格结论

当前可审计结论是：

* 无条件标准工具给出固定 \(w\) 的 \(E_N(w)\ll_w N^2\)；
* 但由上述有限秩 dyadic 逼近，任何 \(w\in L^1\) 的目标实际上满足
  无速率的 \(E_N(w)=o(N^2)\)；
* \(N^{1+\varepsilon}\) 门等价于控制 (3)/(6) 的全尺度 signed Möbius
  二点相关，至少是 RH-strength 的对象；
* 定向文献检索没有找到可直接代入本项目固定 \(w\) 的无条件
  \(N^{2-\delta}\) 固定幂次定理；
* 因此宏观 boundary block 不能被声称已经有 \(N^{1+o(1)}\) 上界，必须
  明确引入新的 arithmetic intertwiner 或承认该门仍未闭合。

本文不把文献范围比较外推成“不可能”，也不声称 RH。
