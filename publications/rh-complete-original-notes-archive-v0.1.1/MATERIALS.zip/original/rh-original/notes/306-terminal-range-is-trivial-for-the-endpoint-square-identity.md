> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 终端大移位区对端点平方恒等式是平凡可控的

日期：2026-08-16。

外部 Liouville-collar 路线用
\[
C_h^*(X)=\sup_{Y\le X-h}
\left|\sum_{n\le Y}\lambda(n)\lambda(n+h)\right|
\]
来控制所有端点。这个 maximal 量在终端大移位区很强，但平方恒等式本身只需要
\[
C_h^{\rm end}(X)=
\sum_{n\le X-h}\lambda(n)\lambda(n+h).
\]
对后者，terminal range 有一个完全平凡但重要的改写。

## 精确终端估计

固定 \(0<\eta<1/2\)，考虑
\[
\mathcal T_\eta(X)
=\sum_{X^{1-\eta}<h<X}C_h^{\rm end}(X).
\]
置 \(t=X-h\)，则 \(1\le t<X^\eta\)，且
\[
C_{X-t}^{\rm end}(X)
=\sum_{n\le t}\lambda(n)\lambda(n+X-t).
\]
由于 \(|\lambda|\le1\)，
\[
\left|C_{X-t}^{\rm end}(X)\right|\le t.
\]
因此
\[
\boxed{
|\mathcal T_\eta(X)|
\le\sum_{1\le t<X^\eta}t
\ll X^{2\eta}.}
\tag{1}
\]
特别地，若 \(\eta<1/2\)，则
\[
\mathcal T_\eta(X)=O(X^{1-\delta_\eta})
\quad\text{其中 }\delta_\eta=1-2\eta>0,
\]
远小于平方恒等式所允许的 \(X^{1+\varepsilon}\) 误差。

## 对中等移位门的精确重写

因此要从
\[
L(X)^2
=X+2\sum_{1\le h<X}C_h^{\rm end}(X)
\]
推出 RH，只需在 \(H\le X^{1-\eta}\) 的中短移位范围证明
\[
\mathcal E_\lambda^{\rm end}(X,H)
:=\sum_{H<h\le2H}
\left|C_h^{\rm end}(X)\right|^2
\ll_{\varepsilon,\eta}X^{2+\varepsilon}H^{-1}.
\tag{2}
\]
对每个 dyadic 块用 Cauchy--Schwarz，
\[
\left|\sum_{H<h\le2H}C_h^{\rm end}(X)\right|
\le H^{1/2}\mathcal E_\lambda^{\rm end}(X,H)^{1/2}
\ll X^{1+\varepsilon}.
\]
对 \(O(\log X)\) 个中短块求和，再加入 (1)，得到
\[
L(X)^2\ll_\varepsilon X^{1+\varepsilon},
\qquad
L(X)\ll_\varepsilon X^{1/2+\varepsilon},
\]
继而推出 RH。

## 裁决

这并没有证明 (2)，但严格移除了外部论文中一个不必要的附加门：
终端区的 maximal shifted-correlation estimate 不是平方恒等式所需的最小条件。
剩余真正的算术门是端点相关的中短移位四点均方 (2)，而不是
\(\sup_Y\) 版本加上 terminal range。

## 与公开 QSLB 门的严格关系

若采用公开路线所写的更强条件
\[
 \sum_{H<h\le 2H} C_h^*(X)^2
 \ll_{\varepsilon,\eta}X^{2+\varepsilon}H^{-1},
 \qquad H\le X^{1-\eta},
 \tag{3}
\]
则因为
\(C_h^{\rm end}(X)\) 是 \(C_h^*(X)\) 所控制的一个特定端点，
(3) 立即推出 (2)，再由上面的 dyadic 分解得到
\(L(X)\ll X^{1/2+\varepsilon}\)，从而推出 RH。
因此该公开门是一个**充分条件**，但目前没有证据表明它是 RH 的自然
等价条件；它比固定移位 Chowla、普通平均相关或定性短区间结果强得多。
来源正文把同一条件列为 Open Problem 6.1，而非定理：
<https://www.preprints.org/manuscript/202606.1350>。

这一区分很重要：当前可以严格证明的是
\[
 \text{QSLB/maximal square gate}\Longrightarrow\text{RH},
\]
而不是反向蕴含。有限 FFT 中该门在
\(H=\lfloor X^{3/4}\rfloor\) 的量纲表现也明显偏强（见 note 322），
所以不能把它当作“只差技术细节”的 RH 证明。
