> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Dyadic block-square 的四点展开与 Fourier Bessel 边界

日期：2026-08-16。

令
\[
C_h(N)=\sum_{n\le N-h}\mu(n)\mu(n+h),
\qquad
D_H(N)=\sum_{H\le h<2H}C_h(N),
\]
其中 (H) 遍历小于 (N) 的二次幂。

## 精确四点形式

写
\[
\Delta_H(d)=\mathbf 1_{H\le d<2H}.
\]
则
\[
D_H(N)=\sum_{1\le a<b\le N}\mu(a)\mu(b)\Delta_H(b-a).
\]
由于正整数差只属于一个 dyadic 壳，得到精确恒等式
\[
\sum_H|D_H(N)|^2
=
\sum_{\substack{a<b\le N\\c<d\le N}}
\mu(a)\mu(b)\mu(c)\mu(d)\,
\mathbf 1_{\lfloor\log_2(b-a)\rfloor
=\lfloor\log_2(d-c)\rfloor}.
\tag{1}
\]

因此目标门不是普通二点 Chowla 平均，而是带有“两个差属于同一 dyadic 壳”约束的四点 signed form。

## Fourier 侧的严格边界

令
\[
F_N(\theta)=\sum_{n\le N}\mu(n)e(n\theta),
\qquad
b_H(\theta)=\sum_{H\le h<2H}\cos(2\pi h\theta).
\]
Parseval 给出
\[
D_H(N)=\int_0^1b_H(\theta)|F_N(\theta)|^2\,d\theta.
\tag{2}
\]
不同 (H) 的 (b_H) 具有不交的 Fourier 支持。对
\(g(\theta)=|F_N(\theta)|^2\)，先对每个壳使用 Cauchy--Schwarz，再对壳求和，得到
\[
\sum_H\frac{|D_H(N)|^2}{\#\{h:H\le h<2H\}}
\le
\sum_{h=1}^{N-1}|\widehat g(h)|^2
\le \int_0^1|F_N(\theta)|^4\,d\theta.
\tag{3}
\]
最后一项又是加性四点相关：
\[
\int_0^1|F_N(\theta)|^4d\theta
=
\sum_{a+b=c+d\atop a,b,c,d\le N}
\mu(a)\mu(b)\mu(c)\mu(d).
\tag{4}
\]

式 (3) 只有 (H^{-1}) 加权，而 RH 所需的自然门是
\(\sum_H|D_H(N)|^2\ll N^{2+\varepsilon}) 的无权版本。用 (3) 去掉该权会付出最大的壳长，不能产生平方根节省；对一般有界序列，常数序列也显示这种损失是实质性的。

## 裁决

这条恒等式排除了“Fejér 正性或普通 Parseval 自动给出 block-square”的捷径。剩余问题至少需要以下之一：

1. 直接控制 (1) 的四点 Möbius signed form；或
2. 在 (2) 的正负 Fourier 区间之间构造保留 Möbius 乘法结构的算术 intertwiner；或
3. 证明比 (3) 更强、能恢复无权壳平方和的加性四阶 Möbius 能量估计。

现有 averaged-Chowla 和短区间正能量结果均未提供这些命题；本记录不声称 RH。
