> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 除数链交叉能量的精确递归

日期：2026-08-17。

note 452 给出了 \(G_N\) 的对角递归。本 note 将它推广到除数链
\(e=ad\)，把非对角项写成两个截断调和尾序列的整数抽样内积。

## 1. 记号

令

\[
M=\left\lfloor\frac Nd\right\rfloor,
\qquad
M'=\left\lfloor\frac N{ad}\right\rfloor
=\left\lfloor\frac Ma\right\rfloor,
\]

并写

\[
A_q(M):=\sum_{q<n\le M}\frac{\mu(n)}n,
\qquad
S(M):=A_0(M)=\sum_{n\le M}\frac{\mu(n)}n.
\]

## 2. 精确链公式

由 note 445，

\[
(G_N)_{d,ad}
=\frac1{ad^2}\sum_{k=1}^{N-1}(2k+1)
A_{\lfloor k/d\rfloor}(M)
A_{\lfloor k/(ad)\rfloor}(M').
\]

当 \(k=dq+r\) 且 \(0\le r<d\) 时，
\(\lfloor k/(ad)\rfloor=\lfloor q/a\rfloor\)。块 \(q=1,\ldots,M-1\)
完整出现，且

\[
\sum_{r=0}^{d-1}\bigl(2(dq+r)+1\bigr)=d(2q+1).
\]

块 \(q=0\) 的权重和为 \(d^2-1\)，末端 \(q=M\) 的尾为零。因此

\[
\boxed{
(G_N)_{d,ad}
=\frac1a\left[
\left(1-\frac1{d^2}\right)S(M)S(M')
+\sum_{q=1}^{M-1}(2q+1)
A_q(M)A_{\lfloor q/a\rfloor}(M')
\right].
}
\tag{1}
\]

当 \(a=1\) 时，(1) 正好退化为 note 452 的对角公式。OMEN 已用精确有理数对
\(N=20,31,64\) 的所有 \(d\) 与允许的 \(a\) 核验 (1)。

## 3. 算术含义

式 (1) 说明除数链上的非对角 Gram 项不是任意的黑箱相关，而是一个明确的
整数抽样算子

\[
A_q(M)\longmapsto A_{\lfloor q/a\rfloor}(M').
\]

第一项是零频边界乘积；第二项是带 Lehmer 权
\(2q+1\) 的 signed 抽样内积。若要从除数链构造 RH-strength 的消去，必须控制
这些抽样内积的总和，而不能只控制每个对角能量。

## 4. 边界

公式 (1) 只处理 \(d\mid e\) 的链；一般 \(d,e\) 需要按
\(\operatorname{lcm}(d,e)\) 的残类进一步分块，可能产生真正的二维 signed
相关。本 note 因而给出一条精确的链级接口，而不是完整的 RH 证明。
