> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正 detector 层级的统一 Euler--beta 算子表示

日期：2026-08-15。

依赖：[note 149](149-the-positive-detector-hierarchy-has-a-3m-plus-3-degree-pattern.md)。

证据等级：一般 (m) 的精确恒等式；正性部分仍只完成有限层验证。

## 1. 统一构造

令

\[
 H_m(u)=u^2(1-u)^{3m+1}\mathbf 1_{(0,1)}(u),
 \qquad \Theta=-u\partial_u,
\]

并定义

\[
 \mathcal D_m=(\Theta-1)\prod_{j=1}^{m-1}(\Theta+2j+1),
 \qquad
 C_m=(3m+4)\prod_{j=1}^{m-1}(3m+2-2j).
\tag{1}
\]

空乘积取 1。则 note 149 中以 (u^2(1-u)^{2m+1}) 为端点因子的唯一方向（取最高次项系数为 1）恰为

\[
 \boxed{V_m(u)=C_m^{-1}\mathcal D_m H_m(u).}
\tag{2}
\]

例如

\[
 C_1=7,\quad C_2=60,\quad C_3=819,\quad C_4=15360,
\]

并给出

\[
 V_1=u^2(1-u)^3(u-3/7),
\]

\[
 V_4=u^2(1-u)^9
 \frac{1024u^4+207u^3-57u^2-27u-3}{1024}.
\]

## 2. Mellin 变换与消去的 residues

对 (\Re s) 足够大，

\[
 \widehat H_m(s)=\int_0^1H_m(u)u^{s-1}\,du=B(s+2,3m+2).
\]

分部积分给出

\[
 \widehat{(\Theta+c)f}(s)=(s+c)\widehat f(s),
\]

因此

\[
 \widehat V_m(s)=
 \frac{(s-1)\prod_{j=1}^{m-1}(s+2j+1)}{C_m}
 B(s+2,3m+2).
\tag{3}
\]

使用

\[
 B(s+2,3m+2)=
 \frac{(3m+1)!}{\prod_{k=2}^{3m+3}(s+k)},
\]

分子恰好消去 (s+3,s+5,\ldots,s+2m-1)，从而

\[
 \boxed{
 \widehat V_m(s)=
 \frac{(3m+1)!(s-1)}{C_m}
 \left[
 \prod_{j=1}^{m}(s+2j)
 \prod_{k=2m+1}^{3m+3}(s+k)
 \right]^{-1}.}
\tag{4}
\]

这严格解释了 note 149 的 Mellin 分母模式。因子 (s-1) 给出零均值；缺失的奇数极点等价于 (v_1=v_3=\cdots=v_{2m-1}=0)。算子 (\mathcal D_m) 的阶数为 (m)，而 (H_m) 在 (u=1) 的阶数为 (3m+1)，故 (V_m) 的右端平坦阶为 (2m+1)，总次数为

\[
 2+(2m+1)+m=3m+3.
\]

## 3. 对 reciprocal-product 核的算子表达

令

\[
 S_m(y)=\sum_{1\le c\le y}H_m(c/y),
 \qquad y\ge1.
\]

由于 (H_m^{(j)}(1)=0) 对 (0\le j<m) 成立，跨过整数 (y) 时没有边界跳项；逐项使用

\[
 -u\partial_u H_m(c/y)=y\partial_y H_m(c/y)
\]

得到全局精确恒等式

\[
 \boxed{
 P_m(y):=\sum_{c\le y}V_m(c/y)
 =C_m^{-1}(y\partial_y-1)
 \prod_{j=1}^{m-1}(y\partial_y+2j+1)S_m(y).}
\tag{5}
\]

这把所有层压缩为一个 beta--Riemann 和的 Euler 导数问题。它是进一步证明全 (m) 正性的最薄解析接口：需要证明右侧对所有 (y\ge1) 非负。

还有一个可严格归纳的内部正性事实。令

\[
G_{m,j}=\prod_{\ell=1}^{j}(\Theta+2\ell+1)H_m
 =u^2(1-u)^{3m+1-j}R_{m,j}(u).
\]

则 (R_{m,0}=1)，且若 (R_{m,j}=sum r_k u^k)，有

\[
R_{m,j+1}=\bigl((2j+1)(1-u)+(3m+1-j)u\bigr)R_{m,j}
 -u(1-u)R'_{m,j}.
\]

其 (u^k) 系数为

\[
(2j+1-k)r_k+(3m-3j-1+k)r_{k-1}.
\]

在 (0\le j\le m-2) 且 (0\le k\le j+1) 时两因子均非负（非零系数严格为正），故 (R_{m,j}) 的系数全为正。特别地，若

\[
F_m(u)=uG_{m,m-1}(u),
\]

则 (F_m=u^3(1-u)^{2m+2}R_{m,m-1}) 且 (R_{m,m-1}) 具有正系数；同时

\[
V_m=-C_m^{-1}F'_m.
\]

这说明每层 detector 是一个正系数 beta--导数的特殊线性组合，但尚不能逐项推出其 periodization 正性：高阶正系数项对应的单独 beta--导数族本身会变号。缺的仍是一个保持整个特殊组合的 variation-diminishing/离散 Euler 不等式。

### Bernstein 累积系数的精确因子化

还可以把上述“特殊组合”压缩到一个更薄的离散对象。令
\(D=3m+3\)、\(B_{k,D}(u)=\binom Dk u^k(1-u)^{D-k}\)，并写
\[
G_{m,j}:=\prod_{\ell=1}^{j}(\Theta+2\ell+1)H_m
       =\sum_k c_{j,k}B_{k,D}.
\]
因为 \(H_m=B_{2,D}/\binom D2\)，且
\[
\Theta B_{k,D}=-kB_{k,D}+(k+1)B_{k+1,D},
\]
系数满足精确递推
\[
c_{0,2}=\binom D2^{-1},\qquad
c_{j+1,k}=(2j+3-k)c_{j,k}+k\,c_{j,k-1}.
\tag{5a}
\]
在 \(0\le j\le m-2\)、\(k\le j+2\) 时右端系数非负，故全部
\(c_{m-1,k}\ge0\)。最后一个因子给出
\[
V_m=C_m^{-1}\sum_k c_{m-1,k}(k+1)(B_{k+1,D}-B_{k,D}),
\tag{5b}
\]
并且其 Bernstein 系数的前缀和恰为
\[
\sum_{i=0}^{k}b_i=-(k+1)c_{m-1,k}\le0.
\tag{5c}
\]
因此，对 \(W_k(y):=\sum_{n\le y}B_{k,D}(n/y)\)，periodization 的完整恒等式是
\[
P_m(y)=C_m^{-1}\sum_k(k+1)c_{m-1,k}\,[W_{k+1}(y)-W_k(y)].
\tag{5d}
\]
这严格说明了正性问题的最薄形式：权重 \((k+1)c_{m-1,k}\) 全正，但单个
\(W_{k+1}-W_k\) 并不恒正。例如 \(m=3,D=12,y=4.46\) 时
\[
W_3=0.3490273102142367\ldots>W_4=0.3489695699908136\ldots.
\]
这个障碍可完全有理化：取 \(y=223/50\)（仍为 \(N=4\)），则共同分母
\(15123710539293666054338805121\) 下
\[
\Delta W_3=-873246425526672312500000<0,\qquad
\Delta W_4=-91203315306290160187500000<0,
\]
\[
\Delta W_5=1728667930600875000000000>0,\qquad
\Delta W_7=-88536570604453125000000000<0.
\]
所以 \(W_k\) 在实际 periodization 中甚至多次变差，并非单峰序列；这排除了
仅依靠单调性、单峰性或逐差分正性的 variation-diminishing 证明。
所以 (5d) 不能逐项正化；仍需对这一特定正权组合证明离散
variation-diminishing 不等式。

### 正权的反向 Bessel 闭式

上述正权还可完全写出。令
\(C_j(z)=\sum_k c_{j,k}z^k\)、\(t=z/(1-z)\)。由 (5a) 的生成函数递推，
\(D_j(t):=C_j(z)/(1+t)\) 满足
\[
D_{j+1}=(2j+3)D_j-tD_j'.
\]
写 \(D_j=t^2E_j\)，则对应的多项式是反向 Bessel 多项式
\[
p_j(q)=\sum_{\ell=0}^{j}
\frac{(2j-\ell)!}{2^{j-\ell}(j-\ell)!\,\ell!}\,q^\ell,
\qquad p_{j+1}=(2j+1+q)p_j-qp_j'.
\]
因此对 \(j=m-1\)、\(D=3m+3\)、\(B=\binom D2\)，有显式正系数
\[
\boxed{
c_{m-1,\ell+2}=
\frac{(2m-2-\ell)!(\ell+2)!}
{2^{m-\ell}(m-1-\ell)!\,\ell!\,\binom{3m+3}{2}},
\quad 0\le\ell\le m-1.}
\tag{5e}
\]
这把 (5d) 的权重压缩为反向 Bessel 系数的显式正组合；但
\(W_{k+1}-W_k\) 的多重变号仍未被消除，故 (5e) 尚不是全 \(m\) 正性证明。

## 4. 当前边界

精确 Bernstein/falling-factorial 计算已验证 (P_m(y)\ge0) 的层数 (m=1,\ldots,43)；这是有限计算，不是全 (m) 定理。式 (5) 尚未给出符号保持性，也没有绕过 note 148 的固定不定 (2\times2) Möbius block。

因此，即便未来证明 (5) 对所有 (m) 非负，仍需另行建立完整 signed Möbius 双和的平方根尺度估计；正 detector 的统一算子表示本身不等于 RH 证明。
