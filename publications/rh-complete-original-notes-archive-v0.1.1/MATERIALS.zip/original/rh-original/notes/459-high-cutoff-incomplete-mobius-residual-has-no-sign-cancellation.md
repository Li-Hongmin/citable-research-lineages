> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 高截断区间的不完全 Möbius residual 没有符号抵消

日期：2026-08-17。

本 note 给出 notes/445、458 中截断倍数链的一个严格边界。它说明：若截断保留了超过一半的完整倍数链，那么 residual 中的不完全 Möbius 系数在整个剩余区间都等于 \(1\)，因而不能从 Möbius 符号得到任何抵消。

## 1. residual 的记号

令

$$
M_d=\left\lfloor\frac Nd\right\rfloor,
\qquad 1\le A<M_d,
$$

并沿用 note 458 的

$$
\eta_A(n)=\sum_{\substack{a\mid n\\a>A}}\mu(n/a),
\qquad
\mathcal R_{d,A}=R_Ne_d-T_NC_{d,A}.
$$

由 note 458 式 (3)，对 \(1\le k<N\)，

$$
(\mathcal R_{d,A})_k
=\frac{\sqrt{2k+1}}d
\sum_{\substack{\max(A,\lfloor k/d\rfloor)<n\le M_d}}
\frac{\eta_A(n)}n.
\tag{1}
$$

## 2. 超过半链时 \(\eta_A\) 恒等于 1

假设

$$
A>\frac{M_d}{2}.
\tag{2}
$$

若 \(A<n\le M_d\)，取定义 \(\eta_A(n)\) 中任一满足 \(a>A\) 的因子，并写 \(n=aj\)。由 (2)，

$$
1\le j=\frac na<\frac{M_d}{A}<2.
$$

因此 \(j=1\)，且唯一可能的因子是 \(a=n\)。于是有严格恒等式

$$
\boxed{\eta_A(n)=\mu(1)=1\qquad(A<n\le M_d).}
\tag{3}
$$

这里没有使用平均估计、素数定理或 RH；这是“超过半链”这一纯粹整数几何条件的直接结果。

## 3. 一个显式 residual 下界

取 \(k=1\)。因为 \(\lfloor1/d\rfloor\le1\)，而 \(A\ge1\)，式 (1) 与 (3) 给出

$$
(\mathcal R_{d,A})_1
=\frac{\sqrt3}{d}\sum_{n=A+1}^{M_d}\frac1n
=\frac{\sqrt3}{d}\bigl(H_{M_d}-H_A\bigr),
$$

其中 \(H_r=\sum_{n\le r}1/n\)。故

$$
\boxed{
\|\mathcal R_{d,A}\|_2^2
\ge \frac3{d^2}\bigl(H_{M_d}-H_A\bigr)^2
\ge \frac3{d^2}
\log^2\!\frac{M_d+1}{A+1}.
}
\tag{4}
$$

最后一个不等式只是
\(\sum_{n=A+1}^{M_d}n^{-1}\ge\int_{A+1}^{M_d+1}x^{-1}\,dx\)。

特别地，若沿某个尺度族有 \(A\le\vartheta M_d\)，其中固定

$$
\frac12<\vartheta<1,
$$

则在 \(M_d\to\infty\) 时

$$
\|\mathcal R_{d,A}\|_2
\ge \frac{\sqrt3}{d}\bigl(\log(1/\vartheta)+o(1)\bigr).
\tag{5}
$$

因此，保留一个固定比例但小于完整链的高截断，不可能依靠 \(\mu\) 的符号抵消把 residual 压到零；若要使这个显式下界趋于零，必须令 \(A/M_d\to1\)，即截断必须渐近地接近完整链。

## 4. 对跨尺度方案的含义

这条结果只处理 \(A>M_d/2\) 的高截断区，并没有解决 \(A\le M_d/2\) 时的不完全除数和。后者仍是 notes/445、458 中真正的 signed arithmetic gate。

它排除了一个常见但无效的捷径：先把每条倍数链截得很长，再把剩余项当作“少量 Möbius 边界”并期待自动得到平方根误差。高截断区的边界不是少量 signed 项，而是一个同号调和尾。任何有效的跨尺度 intertwiner 必须处理低截断区的完整不完全除数相关，或显式使用跨 \(d\) 的 signed cancellation；逐链正估计不能完成这一步。

本 note 是严格的结构性 no-go，不是 RH 证明，也不声称低截断区不存在新的算术桥。
