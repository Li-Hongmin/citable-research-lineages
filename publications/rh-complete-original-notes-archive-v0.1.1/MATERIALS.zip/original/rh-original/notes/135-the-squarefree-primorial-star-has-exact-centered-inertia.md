> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Squarefree primorial star 具有精确 centered inertia

日期：2026-08-14。

依赖：[note 118](118-an-endpoint-flat-detector-gives-an-exact-positive-reciprocal-product-rh-gate.md)、
[note 122](122-squarefree-primorial-stars-have-codimension-one-negative-inertia.md)。

证据等级：精确对角合同、秩一惯性公式与 Cauchy--Schwarz。

note 122 在 squarefree Möbius 支撑上构造了余维一负子空间，但只记录了负惯性下界。
本文确定原核与 centered 核的完整惯性：centering 改变 collective mode 的大小，却不改变
其正号；所有横向方向仍严格为负。

## 1. Squarefree star 与 centered 核

令

\[
x=p_m^\#=\prod_{i=1}^m p_i,
\qquad
a_j=2p_j\quad(2\le j\le m),
\qquad m\ge6,
\tag{1}
\]

其中 \(p_1=2<p_2<\cdots<p_m\) 为前 \(m\) 个素数。定义

\[
K_{jk}=P\!\left(\frac{x}{a_ja_k}\right),
\qquad
C_{jk}=K_{jk}-\frac{a_ja_k}{6x},
\tag{2}
\]

其中

\[
P(y)=
\frac{\lfloor y\rfloor(\lfloor y\rfloor+1)}{y^3}
\{y\}(1-\{y\}).
\tag{3}
\]

沿用 note 122 的正对角矩阵与缺陷矩阵

\[
D_{jj}=\frac{p_j}{\sqrt x},
\qquad
K=D(J-E),
\tag{4}
\]

其中 \(J=\mathbf1\mathbf1^T\)，且 \(E\succ0\)。由于

\[
\frac{a_ja_k}{6x}
=\frac{4p_jp_k}{6x}
=\frac23D_{jj}D_{kk},
\tag{5}
\]

有精确分解

\[
\boxed{
C=D\left(\frac13J-E\right)D.}
\tag{6}
\]

## 2. 唯一标量阈值

置 \(n=m-1\) 及

\[
q=\mathbf1^TE^{-1}\mathbf1.
\tag{7}
\]

以 \(E^{1/2}\) 作合同，得到

\[
E^{-1/2}\left(\frac13J-E\right)E^{-1/2}
=\frac13uu^T-I,
\qquad
u=E^{-1/2}\mathbf1.
\tag{8}
\]

右端在 \(u^\perp\) 上等于 \(-I\)，而在 \(u\) 方向的特征值为

\[
\frac{\lVert u\rVert^2}{3}-1
=\frac q3-1.
\tag{9}
\]

因此 \(C\) 的完整惯性只由 \(q\) 是否大于 \(3\) 决定。

## 3. 严格越过阈值

note 122 已证明，对每个 \(j\)，

\[
\sum_{k\ne j}E_{jk}<p_m^{-2},
\qquad
0<E_{jj}\le1.
\tag{10}
\]

故

\[
\mathbf1^TE\mathbf1
<n(1+p_m^{-2}).
\tag{11}
\]

在内积 \(\langle v,w\rangle_E=v^TEw\) 中用 Cauchy--Schwarz，

\[
(\mathbf1^T\mathbf1)^2
\le
(\mathbf1^TE\mathbf1)
(\mathbf1^TE^{-1}\mathbf1),
\tag{12}
\]

从而

\[
q>
\frac{n}{1+p_m^{-2}}
\ge
\frac5{1+13^{-2}}
=\frac{169}{34}>3.
\tag{13}
\]

结合 (6)--(9) 得到：

## 定理

对每个 \(m\ge6\)，squarefree primorial star 上的 centered 核满足

\[
\boxed{
n_+(C)=1,
\qquad
n_-(C)=m-2,
\qquad
n_0(C)=0.}
\tag{14}
\]

同一论证对 \(K=D(J-E)D\) 使用阈值 \(q>1\)，也给出

\[
\boxed{
n_+(K)=1,
\qquad
n_-(K)=m-2,
\qquad
n_0(K)=0.}
\tag{15}
\]

更一般地，对 \(D(\gamma J-E)D\)，唯一 collective eigenvalue 的符号由
\(\gamma q-1\) 决定。这里 \(\gamma=1/3\) 仍严格越过正阈值，所以 subtracting
the Bernoulli mean 保留恰好一个正 collective mode，而不能把 squarefree star
变成 negative definite。

## 4. 边界

(14) 是所选 squarefree principal submatrix 的精确惯性，不是完整 \(K_x\) 或 \(C_x\)
矩阵的精确惯性。由主子矩阵交错，它严格推出完整 centered 核的负惯性至少为 \(m-2\)，
但不限制完整矩阵在 star 之外出现更多正负方向。该结果描述谱几何，不给出实际 Möbius
二次型的平方根上界，因而不构成 RH 的证明。
