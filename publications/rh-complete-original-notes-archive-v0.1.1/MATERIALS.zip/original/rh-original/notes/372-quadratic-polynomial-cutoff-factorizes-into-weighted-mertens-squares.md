> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 二次多项式 cutoff 核精确因子化为加权 Mertens 平方差

本 note 给出原始 \(\sqrt x\)-截断门的一个完全显式低阶模型，说明
periodization 的逐点正性并不等于二次型正性，也不自动控制单个
Möbius 加权和。

## 精确因子化

令
\[
\phi(u)=u(1-u)\mathbf1_{(0,1)}(u),
\qquad z=\lfloor\sqrt x\rfloor,
\]
并定义加权 Mertens 和
\[
A_j(z)=\sum_{n\le z}\mu(n)n^j.
\]
原始 cutoff reciprocal-product 为
\[
T^{\mathrm{cut}}_\phi(x)=
\sum_{a,b\le z}\mu(a)\mu(b)\phi(ab/x).
\]
因为
\(\phi(ab/x)=ab/x-a^2b^2/x^2\)（而 \(ab\le z^2\le x\)，端点项为零），
双和逐项分离，得到严格恒等式
\[
\boxed{
T^{\mathrm{cut}}_\phi(x)=
\frac{A_1(z)^2}{x}-\frac{A_2(z)^2}{x^2}.}
\tag{1}
\]
这与 note 371 的 full/cutoff 双曲尾分解完全相容；这里没有使用任何
渐近估计或 Mellin 延拓。

## 有理核验

直接用 \(\mu(1)=1,\mu(2)=-1\) 得：
\[
\begin{array}{c|c|c|c}
x&z&A_1(z)&T^{\mathrm{cut}}_\phi(x)\\\hline
3&1&1&2/9\\
5&2&-1&-4/25\\
7&2&-1&-2/49
\end{array}
\]
例如在 \(x=5\)，\(A_2(2)=1-4=-3\)，故
\(T^{\mathrm{cut}}=1/5-9/25=-4/25\)。这些值与逐项双和完全一致。

## 算术含义

写成归一化形式
\[
T^{\mathrm{cut}}_\phi(x)
 =\left(\frac{A_1(z)}{z}\right)^2
  -\left(\frac{A_2(z)}{z^2}\right)^2
\quad (x\asymp z^2).
\tag{2}
\]
单个正 kernel 的平方根级上界只控制两个归一化模式平方的差，
并不分别控制 \(A_1\) 与 \(A_2\)；当两者较大时可以发生精确的
平方差抵消。因而不能把 (1) 误读为
\(A_1(z),A_2(z)=O(z^{1+\varepsilon})\) 或任何单独的 RH 级界。

更高次的非负多项式核会给出有限个
\(A_j(z)^2/x^j\) 的线性组合；要从这些组合中分离单个加权 Mertens
模式，必须保留多个 kernel 的 signed/矩阵关系，而不是对每个 kernel
逐项取绝对值。这个低阶模型因此把 cutoff 难点具体化为一个
有限矩空间的相消问题；它没有提供 RH 证明，也没有排除非局部
intertwiner。

上游：notes 205、370、371。
