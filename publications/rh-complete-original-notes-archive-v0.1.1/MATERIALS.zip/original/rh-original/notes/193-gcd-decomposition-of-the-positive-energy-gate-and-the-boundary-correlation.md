> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正能量门的 gcd 分解与宏观边界相关

沿用 note 192，写
\[
w(\xi)=\frac{|h(\xi)|}{2\pi},\qquad
\widetilde g(t)=\int_{\mathbb R}w(\xi)e^{i\xi t}\,d\xi .
\]
对 \(N=\lfloor\sqrt X\rfloor\)，正能量为
\[
E_N=\int_{\mathbb R}w(\xi)
\left|\sum_{a\le N}\mu(a)a^{i\xi}\right|^2d\xi
=\sum_{a,b\le N}\mu(a)\mu(b)\widetilde g(\log(a/b)).
\tag{1}
\]

## 精确 gcd 恒等式

令 \(d=(a,b)\)、\(a=dr\)、\(b=ds\)，则 \((r,s)=1\)。在
\(\mu(a)\mu(b)\ne0\) 时，\(d\) 必须平方自由且 \((d,rs)=1\)，并且
\[
\mu(dr)\mu(ds)=\mu(r)\mu(s).
\]
定义
\[
\mathcal S_q(Y)=\sum_{\substack{d\le Y\\(d,q)=1}}\mu(d)^2 .
\]
逐项重排 (1) 得到无误差恒等式
\[
\boxed{
E_N=
\sum_{\substack{r,s\le N\\(r,s)=1}}
\mu(r)\mu(s)\widetilde g(\log(r/s))\,
\mathcal S_{rs}\!\left(\left\lfloor\frac{N}{\max(r,s)}\right\rfloor\right).
}
\tag{2}
\]
这一步只用了 gcd 分解，没有平均或渐近假设。

## 首个不可约边界

若 \(r,s>N/2\)，则
\(\lfloor N/\max(r,s)\rfloor=1\)，且
\(\mathcal S_{rs}(1)=1\)。因此 (2) 含有精确的宏观边界块
\[
\boxed{
\sum_{\substack{N/2<r,s\le N\\(r,s)=1}}
\mu(r)\mu(s)\widetilde g(\log(r/s)).
}
\tag{3}
\]
其规模有 \(\asymp N^2\) 个候选有序对，且
\(\log(r/s)=O(1)\)；平方自由计数、PNT 或对 \(\mathcal S_q\)
的主项展开在该块中没有任何额外平均可用。要使 \(E_N\ll
N^{1+\varepsilon}\)，必须直接控制 (3) 的 signed Möbius correlation。

对比之下，只有在 \(\max(r,s)\ll N\) 时，\(\mathcal S_{rs}\) 才有长
\(d\)-平均区间，平方自由密度可提供主项
\[
\mathcal S_q(Y)=\frac{Y}{\zeta(2)}
\prod_{p\mid q}\left(1+\frac1p\right)^{-1}
+O(2^{\omega(q)}\sqrt Y)
\]
之类的估计；这类主项不能覆盖 (3) 的 \(Y=1\) 区域。

## 路线含义

式 (2) 把 note 192 的剩余门压成一个明确的算术命题：不是
divisor completion，也不是 ordinary Gram 正性，而是宏观区间上的
互素 Möbius 相关。若逐项取绝对值，(3) 立即回到 \(N^2\)；若只用
\(\mathcal S_q\) 的平方自由密度，也只能处理长 \(d\)-平均部分。
因此任何成功的平方根估计必须在 (3) 中保留 Möbius 符号并产生
\(N^{1/2}\) 级的双线性抵消；这正是当前尚未得到的 arithmetic input。

## 文献范围核对

Tao--Teräväinen 的相关结构定理研究的是有界乘法函数在**几乎所有尺度**
上的 additive-shift correlations；见
<https://arxiv.org/abs/1809.02518>。它不直接给出 (3) 这种单一宏观尺度、
乘法比值核 \(\widetilde g(\log(r/s))\) 的平方根界。这里的判断只是对象范围
比较，不把文献结果外推到本问题。

本 note 是精确分解与首断点，不声称给出该相关的估计或 RH。
