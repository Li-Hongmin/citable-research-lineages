> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 除数共轭 Gram 矩阵的伴随矩阵与伪行列式

日期：2026-08-17。

令

\[
G_N:=T_N^{\mathsf T}T_N,
\qquad
\delta_N:=\det B_N,
\qquad B_N=T_N[:,2:N].
\]

note 447 给出 \(T_N\mathbf1_N=0\)，note 448 给出 \(B_N\) 可逆及

\[
\delta_N^2
=\frac{\displaystyle\prod_{k=1}^{N-1}(2k+1)}{(N!)^2}.
\tag{1}
\]

## 1. 伴随矩阵

因为 \(G_N\mathbf1_N=0\) 且 \(\operatorname{rank}G_N=N-1\)，
\(\operatorname{adj}(G_N)\) 是秩一矩阵，其列空间和行空间都等于
\(\operatorname{span}\{\mathbf1_N\}\)。因此存在常数 \(c_N\) 使

\[
\operatorname{adj}(G_N)=c_N\,\mathbf1_N\mathbf1_N^{\mathsf T}.
\]

取左上角余子式，并用 Cauchy--Binet，

\[
\bigl(\operatorname{adj}(G_N)\bigr)_{1,1}
=\det\bigl(B_N^{\mathsf T}B_N\bigr)
=\delta_N^2.
\]

故有精确恒等式

\[
\boxed{
\operatorname{adj}(G_N)
=\frac{\displaystyle\prod_{k=1}^{N-1}(2k+1)}{(N!)^2}
\mathbf1_N\mathbf1_N^{\mathsf T}.
}
\tag{2}
\]

这说明 \(G_N\) 的每个 \((N-1)\times(N-1)\) 主余子式都相同，且全部最大子式的符号信息已经被唯一零模 \(\mathbf1_N\) 固定。

## 2. 伪行列式

由 Cauchy--Binet，\(T_N\) 的 \(N\) 个最大子式绝对值都为 \(\delta_N\)，所以

\[
\boxed{
\det(T_NT_N^{\mathsf T})
=\operatorname{pdet}(G_N)
=N\delta_N^2
=\frac{N\displaystyle\prod_{k=1}^{N-1}(2k+1)}{(N!)^2}.
}
\tag{3}
\]

等价地，\(G_N\) 的 \(N-1\) 个非零特征值之积正是 (3)。若加入零模正则化
\(\lambda\mathbf1_N\mathbf1_N^{\mathsf T}\)，则

\[
\boxed{
\det\bigl(G_N+\lambda\mathbf1_N\mathbf1_N^{\mathsf T}\bigr)
=\lambda N^2\delta_N^2.
}
\tag{4}
\]

这里正则化只抬升唯一的全尺度零模；它不改变非零谱，也不提供 Möbius signed cancellation。

## 3. 对 RH 路线的含义

式 (2)--(4) 是有限维精确不变量。任何把 \(G_N\) 作为正 Gram 矩阵输入的 Schur、Feshbach 或正则化操作，都必须保留这个全除数零模及其精确伪行列式。尤其是，给零模加入一个正 rank-one 项不能替代对非零谱与 Möbius 边界向量的控制。

因此下一道算术问题仍是 note 449 的差分—除数余项估计；本 note 只固定有限维线性代数边界，不宣称 RH 已证明。
