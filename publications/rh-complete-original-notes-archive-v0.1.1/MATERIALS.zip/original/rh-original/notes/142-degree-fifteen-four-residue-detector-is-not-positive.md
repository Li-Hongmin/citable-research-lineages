> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 更正：撤回旧的次数十五 no-go 草稿

日期：2026-08-15。

本文件名下的旧版本把非整数 y 的截断和误作 Faulhaber 的解析延拓，因而“次数十五
不正”的结论无效，现正式撤回。定义中必须先取 N=floor(y)，再在 y=N+r 上使用
移位 Faulhaber 恒等式。

正确的次数十五正 detector 与完整 Bernstein 证书见
[note 144](144-a-positive-degree-fifteen-detector-removes-four-collective-residues.md)；
更正说明见 [note 142-correction](142-correction-noninteger-faulhaber-summation.md)。
