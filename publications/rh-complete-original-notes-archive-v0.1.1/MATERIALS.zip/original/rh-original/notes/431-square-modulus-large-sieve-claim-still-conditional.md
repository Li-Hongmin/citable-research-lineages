> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 431. Square-modulus large-sieve 声称仍缺无损桥接

## 来源与核查范围

2026 年 1 月的预印本 *Analytic Reduction of the Riemann Hypothesis via
Square-Modulus Large Sieve Conditions*（DOI: 10.2139/ssrn.6121308）声称把
Mertens 函数的增长问题化为一个 square-modulus mean-square large-sieve
不等式，并把 Baier--Zhao 型输入作为无条件输入。

目前可直接核对的摘要同时明确写出：从原始 Möbius 二次型到 rational-point
mean-square 的“无损”重排仍要求 A/B/C consistency package，涉及 weighting、
rearranging、truncation/smoothing 与 discretization；只有在该 package 建立后，
才可把 large-sieve 输入代入 RH 结论。

## 与本项目主线的对应

本项目 notes 406--418 已把同一类问题写成精确的 moving-ratio 核：

\[
 Q_Y=\sum_{m,n\le Y}\mu(m)\mu(n)\,\kappa_Y(m/n),
\]

其齐次主核有正 Mellin 符号，但端点截断留下全尺度 signed Möbius 耦合。
把该耦合“无损”转成 rational-point 或 square-modulus 大筛，正是上述
A/B/C package 所必须证明的内容，而不是 Baier--Zhao 大筛定理本身自动给出的
推论。

因此，现有来源支持的最强结论是：该预印本给出一个可能的条件性 reduction
scheme；它没有提供已经核验的无条件 square-root bound，也没有关闭 notes 410
所定义的 RH-equivalent dyadic \(M_1\) 能量门。除非 A/B/C consistency 逐项给出
严格的双射、权重保真和截断误差界，否则不能把这条路线记为 RH 证明。

来源：

- https://doi.org/10.2139/ssrn.6121308
- https://www.researchgate.net/publication/401879139_Analytic_Reduction_of_the_Riemann_Hypothesis_via_Square-Modulus_Large_Sieve_Conditions

本记录只作路线边界核查，不否定未来建立该 consistency package 的可能性。
