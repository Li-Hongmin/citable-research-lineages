> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Sign-channel 的有限闭性与 growing-rank 下界：当前可证边界

日期：2026-08-15。

设 \(\mathcal H=L^2(I,|h(\xi)|\,d\xi)\)，其中 \(I\) 为包含所考察 transition
的有限频率区间；\(h\) 是当前偶实 boundary symbol，
\(\Sigma(\xi)=\operatorname{sgn}h(\xi)\)，并令
\(T_X e_a=e^{i\xi\log a}\) 为有限 divisor 指数映射。已有严格事实是
\[
 h(0)>0,\qquad h(2)<0,
\]
所以 \(\Sigma\) 在两个正测度区间取相反符号。

## 1. 原 divisor 空间的严格 finite-rank NO-GO

若存在有限矩阵 \(S_X\) 使
\[
 \Sigma T_X=T_XS_X,
\tag{1}
\]
则对任意 \(a\mid X\)，函数
\(\Sigma(\xi)e^{i\xi\log a}\) 必须等于有限纯指数和，因此在实轴上是整函数的
连续限制。另一方面，\(\Sigma\) 在符号边界处有 jump（若在零点高阶接触，则
取其相邻正负区间的边界），乘以非零指数仍保留该不连续性。故 (1) 不可能。
这给出固定 divisor rank 的严格 NO-GO，但没有给出随 \(X\) 增长的定量误差。

若 \(T_X\) 满列秩，令
\[
 G_X=T_X^*T_X,\qquad C_X=T_X^*\Sigma T_X,\qquad
 P_X=T_XG_X^{-1}T_X^* .
\]
则 sign-channel 投影残差有精确 Schur 恒等式
\[
 \bigl\|(I-P_X)\Sigma T_X\bigr\|_{\mathrm{HS}}^2
 =\operatorname{tr}\!\left(G_X-C_X^*G_X^{-1}C_X\right)>0 .
\tag{2}
\]
严格正性等价于 (1) 失败；这是当前可审计的 rank-dependent 量，但尚无统一的
下界（例如 \(X^{-\alpha}\) 或 \(R^{-\alpha}\)）。

## 2. 为什么当前数据不能推出 \(R\)-rank 逼近下界

仅由 \(h(0)>0,h(2)<0\) 只能保证至少一个 sign transition。对任意固定的
有限指数子空间 \(V_R\)，连续 sign 函数 \(\Sigma\) 不属于 \(V_R\)，故
\[
 \operatorname{dist}_{L^2(I)}(\Sigma,V_R)>0
\]
（\(I\) 为包含该 transition 的有限频率区间）；但该距离依赖实际频率集合和
区间，现有符号信息不给出随 \(R\) 的统一下界。要得到 \(c/R^\alpha\) 或更强
的下界，至少需要可审计的 sign-transition 数量/间距与频率集合的逼近理论；
当前 note 只记录一个 transition，不能外推 growing-rank 障碍。

## 3. 可行的精确替代：二通道而非原空间增长逼近

不必在 \(\operatorname{Ran}T_X\) 内逼近 \(\Sigma\)。令
\[
 \mathcal T_X=[\,T_X,\Sigma T_X\,].
\]
则
\[
 \Sigma\mathcal T_X=\mathcal T_X
 \begin{pmatrix}0&I\\ I&0\end{pmatrix},
\qquad
 J_{\log X}\mathcal T_X=\mathcal T_X
 \begin{pmatrix}R_X&0\\0&R_X\end{pmatrix},
\]
是对每个有限 \(X\) 的精确 rank-doubling 闭性。其 Gram block 正是
\(G_{|h|}\) 与 \(G_h\) 的正 \(2\times2\) channel 分解（见 notes 184--186）。

因此当前最薄、可证的结论是：原 divisor basis 内没有 finite-rank sign closure；
允许显式 sign channel 后 rank 只需乘二且精确闭合。至于只用原 basis 的
growing-rank 近似速率，现有 \(h(0),h(2)\) 数据不足以给出非平凡统一下界；
不能把 fixed-rank NO-GO 外推成 growing-rank NO-GO。

若 (T_X) 满列秩，令 (G=T_X^*T_X)、(C=T_X^*\Sigma T_X)、
(P=T_XG^{-1}T_X^*)（在任意固定有限频率窗的 Hilbert 空间中），则还有精确
[
 \|(I-P)\Sigma T_X\|_{\mathrm{HS}}^2
 =\operatorname{tr}\!\left(G-C^*G^{-1}C\right)>0.
]
这把 sign 闭性失败写成一个 Schur 残差；但由当前仅有的 sign transition
信息，尚不能给出该残差对 (X) 或维数的统一下界。
