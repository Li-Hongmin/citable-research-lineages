> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 中心化路径能量单独构成 RH 判据

日期：2026-08-13。

依赖：[note 064](064-selberg-affine-first-shell-rh-criterion.md)、
[note 074](074-mellin-poles-force-dyadic-mean-shell-growth.md)、
[note 079](079-path-dst-reduces-the-centered-defect-to-sqrtN-low-modes.md)。

## 1. 问题

note 079 把完整首壳写成

\[
I_N=\frac N{12}A_{1,N}^2+N|\Gamma_N|^2+E_N^{\rm cen}.
\tag{1}
\]

若沿用完整 \(I_N\) 判据，必须同时控制零模 \(\Gamma_N\)。本 note 检查这一要求是否真实。

```mermaid
flowchart LR
  A["零点探针 w"] --> B["∫w=0"]
  B --> C["Γ_N 完全不可见"]
  C --> D["centered shell J_N"]
  D --> E["路径 DST"]
  E --> F["仅前 √(N/log N) 模"]
  F --> G["dyadic bound ⇒ RH"]
```

## 2. 精确中心化恒等式

沿用

\[
D_N(y):=1+\sum_{d\le N}\lambda_{d,N}\{y/d\},
\qquad
\lambda_{d,N}:=\mu(d)\left(1-\frac{\log d}{\log N}\right).
\tag{2}
\]

定义首壳均值与方差

\[
\Gamma_N:=\frac1N\int_N^{2N}D_N(y)\,dy,
\qquad
\mathcal J_N:=\min_{c\in\mathbb C}\int_N^{2N}|D_N(y)-c|^2dy.
\tag{3}
\]

note 078 的单位格公式

\[
D_N(n+u)=\gamma_N+A_{1,N}(u-1/2)+G_N(n)
\tag{4}
\]

立即给出

\[
\boxed{
\mathcal J_N
=\frac N{12}A_{1,N}^2
+\sum_{j=0}^{N-1}|v_j-\bar v|^2
=\frac N{12}A_{1,N}^2+E_N^{\rm cen}.
}
\tag{5}
\]

所以 \(\Gamma_N\) 是完整能量的正交零模，但不是中心化能量的一部分。

## 3. 零点探针自动消去零模

若 \(\rho=\beta+i\gamma\) 是 \(\zeta\) 的零点，note 064 选择
\(w\in C_c^\infty(1,2)\) 使

\[
W(0)=W(1)=W(\rho)=0,
\qquad
W'(\rho)\ne0,
\qquad
W(s):=\int_1^2w(t)t^sdt.
\tag{6}
\]

特别地，\(W(0)=0\)，即

\[
\int_1^2w(t)dt=0.
\tag{7}
\]

note 064 的精确探针恒等式为

\[
\int_1^2D_N(Nt)w(t)dt=\frac{R_w(N)}{\log N}.
\tag{8}
\]

由 (7)，可在左边自由减去 \(\Gamma_N\)。Cauchy--Schwarz 因而给出比完整能量更尖锐的

\[
\begin{aligned}
\frac{|R_w(N)|^2}{\log^2N}
&=\left|\int_1^2[D_N(Nt)-\Gamma_N]w(t)dt\right|^2\\
&\le
\frac{\|w\|_2^2}{N}\mathcal J_N.
\end{aligned}
\tag{9}
\]

即

\[
\boxed{
|R_w(N)|^2
\le C_w\frac{\log^2N}{N}\mathcal J_N.
}
\tag{10}
\]

这证明零模对全部离线零探针严格不可见。

## 4. 中心化 dyadic RH 判据

若 \(\rho\) 是 \(q\) 重零点且 \(\beta>1/2\)，note 074 已证明某个 dyadic 子列满足

\[
\sum_{Y<N\le2Y}|R_w(N)|^2
\gg_{\rho,w}Y^{2\beta+1}(\log Y)^{2q-2}.
\tag{11}
\]

由 (10)，在同一子列上

\[
\boxed{
\sum_{Y<N\le2Y}\mathcal J_N
\gg_{\rho,w}
Y^{2\beta+2}(\log Y)^{2q-4}.
}
\tag{12}
\]

因此得到：

**定理 1（中心化首壳判据）。** 若对每个 \(\varepsilon>0\)，

\[
\boxed{
\sum_{Y<N\le2Y}\mathcal J_N
\ll_\varepsilon Y^{3+\varepsilon},
}
\tag{13}
\]

则 RH 成立。

**证明。** 若有 \(\beta>1/2\)，取 \(0<\varepsilon<2\beta-1\)，则 (12) 与 (13)
矛盾。功能方程排除左半边对应零点。\(\square\)

## 5. 只剩低模的单一充分条件

令

\[
K_N:=\left\lceil\sqrt{N/\log N}\right\rceil,
\qquad
\mathcal H_N:=
\sum_{k\le K_N}\frac{|\mathcal R_{N,k}|^2}{k^2},
\tag{14}
\]

其中 \(\mathcal R_{N,k}\) 由 note 079 的格点求积差给出。note 079 已证明

\[
E_{N,>K_N}^{\rm cen}\ll N^2,
\qquad
E_{N,\le K_N}^{\rm cen}\asymp\frac N{\log^2N}\mathcal H_N.
\tag{15}
\]

又由平凡估计 \(|A_{1,N}|\ll\log N\)，

\[
\sum_{Y<N\le2Y}\frac N{12}A_{1,N}^2
\ll Y^2\log^2Y=o(Y^3).
\tag{16}
\]

故定理 1 立即推出：

**定理 2（平方根低模判据）。** 若对每个 \(\varepsilon>0\)，

\[
\boxed{
\sum_{Y<N\le2Y}\mathcal H_N
\ll_\varepsilon Y^{2+\varepsilon}(\log Y)^2,
}
\tag{17}
\]

则 RH 成立。这里不需要任何 \(\Gamma_N\) 上界。

反过来，若存在 \(q\) 重离线零 \(\rho=\beta+i\gamma\)，则由 (12)、(15)、(16) 及
\(\sum_{N\asymp Y}E_{N,>K_N}^{\rm cen}\ll Y^3\)，在某个 dyadic 子列上

\[
\boxed{
\sum_{Y<N\le2Y}\mathcal H_N
\gg_\rho Y^{2\beta+1}(\log Y)^{2q-2}.
}
\tag{18}
\]

所以离线零强迫的超临界质量必定位于前 \(N^{1/2+o(1)}\) 个路径模，不可能藏在零模或
高频尾中。

## 6. 决策更新

```mermaid
flowchart TD
  RH["RH"]
  L["低模 dyadic 界 (17)"] --> RH
  Z["零模 Γ_N"] -. "不需要" .-> L
  H["高频 k>K_N"] -->|"H⁰ 已支付"| L
  O["离线零 β>1/2"] -->|"强迫 (18)"| L
```

下一原子因此唯一化为

\[
\boxed{
\sum_{Y<N\le2Y}
\sum_{k\le\sqrt{N/\log N}}
\frac1{k^2}
\left|
\sum_{d\le N}\mu(d)\log\frac Nd
\left[
\frac{S_{N,k}}d-
\sum_{N<dm<2N}\sin\frac{\pi k(dm-N)}N
\right]
\right|^2.
}
\tag{19}
\]

本 note 删除了一个此前被认为必须控制的未知量，并把所有离线零质量严格定位到 (19)。它证明
的是新的 RH 充分判据，不是 (17) 本身；因此尚未证明 RH。
