> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 指数 Bernstein 阶数给出的 stretched-log 能量节省

日期：2026-08-15。

本 note 优化 note 200 的 dyadic--Bernstein 论证。结论是严格的
stretched-exponential 对数节省，但必须同步把比值窗扩大到
\(D\asymp\Lambda(N)\)。固定 \(\alpha>0\) 时
\(R=e^{\alpha\Lambda(N)}\) 不是 \(o(\log N)\)，而只满足 \(R=N^{o(1)}\)。

## 1. 假设与参数

令
\[
\Lambda(x)=(\log x)^{3/5}(\log\log x)^{-1/5},\qquad
M(x)=\sum_{n\le x}\mu(n).
\]
假设经典零自由区估计
\[
|M(x)|\le C_M x e^{-c_M\Lambda(x)}\qquad(x\ge x_0).
\tag{1}
\]
令 \(w\ge0\) 满足 \(w\in L^1(\mathbb R)\)、
\(\int |t|w(t)\,dt<\infty\)，并设
\[
K(u)=\frac1{2\pi}\int_{\mathbb R}w(t)e^{itu}\,dt,\qquad
E_N(w)=\int_{\mathbb R}w(t)
\left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt.
\tag{2}
\]
则 \(K\) 有界且 Lipschitz。固定 \(\alpha,\beta>0\)，取
\[
R=\left\lceil e^{\alpha\Lambda(N)}\right\rceil,\qquad
D=\left\lceil\frac{\beta\Lambda(N)}{\log2}\right\rceil .
\tag{3}
\]
由于 \(\Lambda(N)=o(\log N)\)，
\[
D=o(\log N),\qquad \log R=o(\log N),\qquad R=N^{o(1)}.
\tag{4}
\]
但
\[
\frac{R}{\log N}
=\exp\!\bigl(\alpha\Lambda(N)-\log\log N+o(1)\bigr)\longrightarrow\infty.
\tag{5}
\]
所以不能声称 \(R=o(\log N)\)；以下只使用 (4)。
## 2. Dyadic 块与 Bernstein 逼近

令 \(I_j=(2^j,2^{j+1}]\)。对 \(m\in I_j\)、\(n\in I_{j+d}\)，
\(d\ge0\)，设
\[
F_d(x,y)=K\!\left(\log(2^{-d}x/y)\right),\qquad (x,y)\in[1,2]^2.
\tag{6}
\]
由 \(K\) 的有界 Lipschitz 常数，\(F_d\) 在所有 \(d\ge0\) 上有统一
\(\|\cdot\|_\infty\) 与 Lipschitz 界。令
\[
b_{R,r}(u)=\binom Rr u^r(1-u)^{R-r},
\]
并定义
\[
B_{R,d}(x,y)=
\sum_{r,s=0}^{R}
F_d\!\left(1+\frac rR,1+\frac sR\right)
b_{R,r}(x-1)b_{R,s}(y-1).
\tag{7}
\]
Bernstein 的概率表示给出
\[
\|F_d-B_{R,d}\|_{\infty,[1,2]^2}\le C_wR^{-1/2}.
\tag{8}
\]
又
\[
\sum_{j+d\le\log_2N}2^{2j+d}\ll N^2\sum_{d\ge0}2^{-d}\ll N^2,
\]
故所有 \(d\le D\) 的逼近误差满足
\[
E_{\rm err}\ll_w N^2R^{-1/2}
\ll_w N^2e^{-\alpha\Lambda(N)/2}.
\tag{9}
\]

## 3. Bernstein 系数项：高块与低块

令
\[
A_{j,r}=\sum_{m\in I_j}\mu(m)b_{R,r}(m/2^j-1).
\]
每个 \(b_{R,r}\) 取值于 \([0,1]\)，且
\[
\operatorname{Var}_{[0,1]}b_{R,r}\le2
\tag{10}
\]
对所有 \(R,r\) 成立。故 Abel 分部求和与 (1) 给出：若
\(2^j\ge N^{1/2}\)，取任意固定 \(\kappa<2^{-3/5}\)，则对充分大 \(N\)
\[
|A_{j,r}|\ll 2^j e^{-\eta\Lambda(N)},\qquad
\eta=c_M\kappa>0,
\tag{11}
\]
且常数与 \(j,r,R,d\) 无关。这里用了
\(\Lambda(2^j)\ge\kappa\Lambda(N)\)。若 \(2^j<N^{1/2}\)，只用
\[
|A_{j,r}|\le2^j.
\tag{12}
\]

代回 Bernstein 展开，系数
\(F_d(1+r/R,1+s/R)\) 一致有界。高块 \(2^j\ge N^{1/2}\) 中两因子均用
(11)，故
\[
E_{\rm high}\ll_w R^2D\,N^2e^{-2\eta\Lambda(N)}.
\tag{13}
\]
低块 \(2^j<N^{1/2}\) 用 (12) 和
\(\sum_{d\le D}2^d\ll e^{\beta\Lambda(N)}\)，得
\[
E_{\rm low}\ll_w R^2D\,N e^{\beta\Lambda(N)}.
\tag{14}
\]
保留 \(D\) 只是粗估；几何求和可略去该因子。

## 4. 远比值尾

当 \(d>D\) 时只使用 \(K\) 的有界性：
\[
E_{\rm far}\ll_w N^2\sum_{d>D}2^{-d}
\ll_w N^2e^{-\beta\Lambda(N)}.
\tag{15}
\]

## 5. 合并与常数选择

由 \(R^2D=\exp(2\alpha\Lambda(N)+o(\Lambda(N)))\)，有
\[
E_N(w)\ll_w
N^2e^{-\alpha\Lambda/2}
 +N^2e^{-(2\eta-2\alpha)\Lambda+o(\Lambda)}
 +N e^{(2\alpha+\beta)\Lambda+o(\Lambda)}
 +N^2e^{-\beta\Lambda}.
\tag{16}
\]
第三项相对于 \(N^2e^{-\gamma\Lambda}\) 为
\[
N^{-1}\exp\!\bigl((2\alpha+\beta+\gamma)\Lambda+o(\Lambda)\bigr)\to0
\]
对任意固定 \(\alpha,\beta,\gamma\)，因为 \(\Lambda=o(\log N)\)。
若
\[
0<\alpha<\eta,\qquad
\gamma<\min\{\alpha/2,\;2\eta-2\alpha,\;\beta\},
\tag{17}
\]
便得到
\[
\boxed{E_N(w)\ll_{w,\alpha,\beta,\gamma}
N^2e^{-\gamma\Lambda(N)}.}
\tag{18}
\]
例如取 \(\alpha=4\eta/5\)、\(\beta\ge2\eta/5\)，则任意
\(\gamma<2\eta/5\) 均可。

## 6. 边界与 RH 含义

若强行要求 \(R=o(\log N)\)，固定 \(\alpha>0\) 不可能；此时只能取
\(\log R=O(\log\log N)\)，得到至多幂对数误差，而非 (18) 的
\(e^{-\gamma\Lambda(N)}\) 节省。指数 Bernstein 阶数的代价是
\(R\gg\log N\)，但仍仅为 \(N^{o(1)}\)，且 (10) 保证所有 Möbius
部分和估计对 \(R\) 均匀。

该结果仍远大于 \(N^{1+\varepsilon}\)，所以不能关闭 note 192 的平方根
能量门，也不能单独推出 RH。
