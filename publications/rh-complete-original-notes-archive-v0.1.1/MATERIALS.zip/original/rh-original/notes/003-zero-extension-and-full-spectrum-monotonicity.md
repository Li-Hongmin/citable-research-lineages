> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 零延拓下的闭形式嵌入与全谱单调性

日期：2026-08-11。本文在 Suzuki 2026 已建立的局部闭 Weil 形式框架内，把谱底的尺度单调性
提升到全部离散本征值。结论是闭形式层面的，不使用一般算子定义域的端点值。

## 1. 设定

记

\[
q_a:=Q_W^a,\qquad \mathcal D_a:=D(q_a)\subset L^2(-a,a),
\]

并将 \(L^2(-a,a)\) 通过区间外零延拓视为 \(L^2(\mathbb R)\) 的闭子空间。按重数排列与
\(q_a\) 对应的自伴算子 \(A_a\) 的本征值：

\[
\lambda_1(a)\le \lambda_2(a)\le\cdots\longrightarrow+\infty.
\]

Suzuki 的 Theorem 1.1 及其证明给出：

- \(q_a\) 是下有界闭 Hermitian 形式，\(A_a\) 是相应的自伴算子；
- \(C_c^\infty(-a,a)\) 是 \(q_a\) 的 form core；
- \(A_a\) 具有紧预解式，故上述本征值序列存在；
- \(\lambda_1(a)\) 可在公共核心上取 Rayleigh 下确界。

若 \(0<a<b\)，记 \(J_{a,b}\) 为从 \((-a,a)\) 到 \((-b,b)\) 的零延拓。

## 2. 先在公共核心上比较

对 \(v\in C_c^\infty(-a,a)\)，局部形式只是同一个全局 Weil 形式在不同支撑子空间上的限制，故

\[
q_b(J_{a,b}v)=q_a(v),\qquad
\lVert J_{a,b}v\rVert_{L^2(-b,b)}=\lVert v\rVert_{L^2(-a,a)}.
\]

因此公共核心的 Rayleigh 商不变，而大区间允许更多试验函数：

\[
\lambda_1(b)\le \lambda_1(a).
\]

这一步只用 Suzuki 的 core 结论，不需要预先知道两个完整 form domain 之间的关系。

## 3. 闭形式定义域确实嵌套

采用 Suzuki 使用的形式范数

\[
\lVert v\rVert_{q_a}^2
:=q_a(v)+(1-\lambda_1(a))\lVert v\rVert_2^2.
\]

在 \(C_c^\infty(-a,a)\) 上有精确恒等式

\[
\lVert J_{a,b}v\rVert_{q_b}^2
=\lVert v\rVert_{q_a}^2
+\bigl(\lambda_1(a)-\lambda_1(b)\bigr)\lVert v\rVert_2^2.
\]

又因 \(q_a(v)\ge\lambda_1(a)\lVert v\rVert_2^2\)，有

\[
\lVert v\rVert_2^2\le\lVert v\rVert_{q_a}^2.
\]

故在公共核心上

\[
\lVert v\rVert_{q_a}
\le \lVert J_{a,b}v\rVert_{q_b}
\le
\sqrt{1+\lambda_1(a)-\lambda_1(b)}\,\lVert v\rVert_{q_a}.
\]

两种范数在该核心上等价。对核心取完备化得到连续单射

\[
J_{a,b}:\mathcal D_a\hookrightarrow\mathcal D_b,
\]

而且由闭形式的连续性，

\[
q_b(J_{a,b}u,J_{a,b}v)=q_a(u,v)
\qquad (u,v\in\mathcal D_a).
\]

所以这里不只是试验函数集合嵌套；完整 Friedrichs form domain 也在零延拓下嵌套，且形式被保留。

## 4. 全部本征值单调不增

闭形式的 min--max 表示为

\[
\lambda_k(a)
=\inf_{\substack{L\subset\mathcal D_a\\ \dim L=k}}
\ \sup_{0\ne v\in L}\frac{q_a(v)}{\lVert v\rVert_2^2}.
\]

任意 \(k\) 维 \(L\subset\mathcal D_a\) 经 \(J_{a,b}\) 变成 \(\mathcal D_b\) 中的 \(k\) 维子空间，
且其所有 Rayleigh 商不变。因此

\[
\boxed{\lambda_k(b)\le\lambda_k(a)\qquad(k\ge1,\ 0<a<b).}
\]

这比只控制 ground state 更强：尺度增加时，按序号排列的每一条谱支都只能向下。

## 5. 负指标推论及其边界

定义有限 Morse 指标

\[
N_-(a):=\#\{k:\lambda_k(a)<0\},
\]

其中按重数计数。全谱单调性立即给出

\[
\boxed{N_-(b)\ge N_-(a)\qquad(0<a<b).}
\]

同理，非正谱计数 \(\#\{k:\lambda_k(a)\le0\}\) 也单调不减。这给第一次退化标准形增加了一个
整数约束：一旦某个谱方向变成负方向，扩大支撑区间不会把它从按序谱列中恢复为正方向。

note 006 随后利用固定区间上的公共 form domain 证明了所有 \(\lambda_k(a)\) 连续。因此这里保留的
限制缩减为：

- 过零必为严格 crossing；本征值可能在零处形成平台；
- \(N_-(a)\) 只在 prime-power 阈值改变；闭形式本身随尺度连续变化，阈值不是唯一可能的 crossing 点；
- 单个 crossing form 可由经典尺度导数直接计算；形式族目前只有连续性。

完整路径的 spectral flow 已由 note 006 建立并等于端点负指标之差；尚未完成的是局部 crossing form
或 Maslov-index 表示。

## 6. 来源

直接承重来源是 Masatoshi Suzuki, *Weil's quadratic form via the screw function*,
[arXiv:2606.09096](https://arxiv.org/abs/2606.09096)：Theorem 1.1、Corollary 1.2、
Theorem 1.3、Proposition 4.1，以及 Theorem 1.1 中 \(C_c^\infty(-a,a)\) 为 form core 的证明。
全谱单调性是本项目在这些结果上的 min--max 推论，不是 Suzuki 文中的原句。
