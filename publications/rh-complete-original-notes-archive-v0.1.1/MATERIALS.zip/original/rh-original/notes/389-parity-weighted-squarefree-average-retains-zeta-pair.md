> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius parity 加权的 squarefree 平均仍保留 ζ reciprocal pair

设 p(t) 为单侧 reciprocal 核，g(t) = (p(t)+p(-t))/2 为其偶部。
沿用 note 177 的记号，令

$$
H_X^p=\sum_{a,b\mid X}\mu(a)\mu(b)\,p(\log(X/(ab)))
$$

其中 X 遍历平方自由整数。对 Re s > 1，绝对收敛与 Fourier 展开给出

$$
\mathscr D_g(s)
:=\sum_{X\ {\rm squarefree}}\mu(X)X^{-s}H_X^p
=\frac1{2\pi}\int_{\mathbb R}\widehat g(\xi)
\prod_{\ell}\left(1+\ell^{-s}|1-\ell^{i\xi}|^2\right)\,d\xi .
$$

## 1. 局部 Euler 因子

令 x = ℓ^{-s}、z = ℓ^{iξ}。局部因子为

$$
L_\ell(x,z)=1+x(2-z-z^{-1}).
$$

它可以精确分解为

$$
L_\ell(x,z)
=\frac{(1-xz)(1-xz^{-1})}{(1-x)^2}\,R_\ell(x,z),
$$

其中

$$
R_\ell(x,z)
=\frac{L_\ell(x,z)(1-x)^2}
{(1-xz)(1-xz^{-1})},
$$

以及

$$
R_\ell(x,z)-1
=-\frac{x^2(x-2)(z-1)^2}{(x-z)(xz-1)}.
$$

当 ξ 为实数且 σ = Re s > 1/2 时，|z| = 1、|x| = ℓ^{-σ}<1，
故

$$
|R_\ell(x,z)-1|
\le \frac{12|x|^2}{(1-|x|)^2}.
$$

因此在实轴 s=σ>1/2 上，∏ℓ Rℓ(σ,ξ) 局部一致绝对收敛且严格为正；
作为复 s 的 Euler 修正，它在避开离散 local zeros 的区域内正规收敛，而主因子满足

$$
\prod_\ell
\frac{(1-\ell^{-s+i\xi})(1-\ell^{-s-i\xi})}
{(1-\ell^{-s})^2}
=\frac{\zeta(s)^2}
{\zeta(s-i\xi)\zeta(s+i\xi)}.
$$

所以

$$
\boxed{
\mathscr D_g(s)
=\frac1{2\pi}\int_{\mathbb R}\widehat g(\xi)\,
\frac{\zeta(s)^2}
{\zeta(s-i\xi)\zeta(s+i\xi)}
\,\mathscr R(s,\xi)\,d\xi,
}
$$

其中 \(\mathscr R=\prod_\ell R_\ell\) 是上述绝对收敛的 Euler 修正。
在后面的实轴极点检验中，\(\mathscr R(\beta,\xi)>0\)，所以不会抵消零点极点。

## 2. 离线零点仍是显式频率极点

若 ζ 有零点 ρ = β+iγ，β>1/2，且 \(\widehat g(\gamma)\neq0\)，则
在 (s,ξ) = (β,γ) 附近，积分核包含

$$
\frac1{\zeta(s+i\xi)}
$$

及其共轭因子；若零点重数为 m，局部规模为
\(|s-\beta+i(\xi-\gamma)|^{-2m}\)，而 \(\mathscr R\) 不会抵消该极点。
于是 parity 加权没有删除离线零点，而是把它们变成 squarefree Dirichlet
平均的实轴奇性。

若另有独立证据使 \(\mathscr D_g(s)\) 在 Re s > 1/2 解析（例如相应系数的
\(X^{1/2+\varepsilon}\) 级控制），则上述极点迫使 RH。反向地，单凭 Euler
因子的正性不能提供该解析延拓；它只是把原 reciprocal signed 门重写成一个
仍含 reciprocal ζ-pair 的 RH-strength 门。

## 结论

乘上 \(\mu(X)\) 并做 squarefree 平均是一个精确的 parity 修正，但不是新的
PSD 算术桥：其 Euler 主部恰为
\(\zeta(s)^2/[\zeta(s-i\xi)\zeta(s+i\xi)]\)。因此它保留了 RH 信号，同时把
所需的半平面解析性完整地留给原 Möbius cancellation。本文不声称 RH。
