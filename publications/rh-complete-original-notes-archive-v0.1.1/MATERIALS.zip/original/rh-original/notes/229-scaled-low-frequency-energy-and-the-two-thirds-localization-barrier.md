> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 缩放低频能量与 \(2/3\) 局部化障碍

日期：2026-08-16。

本 note 将 note 228 的低频接口压缩为一个有限和引理，量化
“低频能量 \(\Rightarrow\) Mertens 和”之间的最基本损失。

## 引理

令 \(|a_n|\le1\)，令 \(\phi\in C^1([0,\infty))\) 支持在 \([0,2]\)，并定义
\[
A_X(t)=\sum_{n\ge1}a_n\phi(n/X)e^{itn/X}.
\]
设
\[
M_X=|A_X(0)|,\qquad
L_\phi=\sup|\phi|,\qquad
C_\phi=2L_\phi .
\]
则
\[
|A_X'(t)|
\le \frac1X\sum_{n\le2X}n|\phi(n/X)|
\le C_\phi X.
\tag{1}
\]
若 \(q(t)\ge q_0>0\) 于 \([-T,T]\)，且
\(\delta_X=M_X/(2C_\phi X)\le T\)，则
\[
\int_{-T}^{T}q(t)|A_X(t)|^2dt
\ge \frac{q_0}{4C_\phi}\frac{M_X^3}{X}.
\tag{2}
\]

## 证明

由 (1)，当 \(|t|\le\delta_X\) 时
\[
|A_X(t)-A_X(0)|\le C_\phi X|t|\le M_X/2.
\]
故 \(|A_X(t)|\ge M_X/2\)；在 \([-\delta_X,\delta_X]\) 上积分即得 (2)。

## 对 RH 低频门的含义

若能证明相应低频能量
\[
\int_{-T}^{T}q(t)|A_X(t)|^2dt\ll_\varepsilon X^{1+\varepsilon},
\tag{3}
\]
则 (2) 至多推出
\[
M_X\ll_{\varepsilon,q,\phi}X^{2/3+\varepsilon/3}.
\tag{4}
\]
因此固定低频窗的正能量估计，若只使用一般 Lipschitz 局部化，
不能直接达到 \(X^{1/2+\varepsilon}\)。要越过 \(2/3\) 指数，必须证明
额外的 Liouville-specific 结构（例如更强的短区间导数控制、频率
正交性或 signed Type-II cancellation）；单纯提高积分精度或使用
正 Gram 不会改变这个门。

该引理只对任意有界系数成立，不能被误解为 RH 的反例；它精确说明
固定 \(N\) 的点值局部化还缺哪一种算术输入。若能量估计对所有截断统一成立，
则最大点 Abel 部分求和可消除这一 \(2/3\) 损失，见 note 246。
