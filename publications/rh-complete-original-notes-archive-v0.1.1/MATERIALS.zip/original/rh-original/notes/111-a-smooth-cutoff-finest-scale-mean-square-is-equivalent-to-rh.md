> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 平滑截断的最细尺度均方门与 RH 等价

日期：2026-08-14。

依赖：
[note 087](087-two-sine-cutoff-mean-square-is-equivalent-to-rh.md)、
[note 105](105-the-cell-detector-is-zero-free-to-the-imaginary-axis.md)、
[note 110](110-full-output-finest-scale-has-uniform-discrete-coercivity.md)。

证据等级：确定性统一 coercivity、截断 Mertens 路径能量恒等式，
以及经典 Mellin 延拓的双向归约。

note 110 中的零延拓路径能量包含两端 Mertens trace。
本文用一个固定慢变 cutoff 将该 trace 代价完全转换为 \(O(Y)\)，
从而得到一个没有 note 106 插值指数损失的 RH 等价均方门。

## 1. 有限 observation

令

\[
a=\frac23,
\tag{1}
\]

并固定一个实值函数

\[
\chi\in C_c^1((a,2e)),
\qquad
0\le\chi\le1,
\qquad
\chi(u)=1\quad(1\le u\le2).
\tag{2}
\]

记

\[
M(x)=\sum_{n\le x}\mu(n),
\qquad
q_Y(d)=\chi(d/Y)M(d),
\tag{3}
\]

并在 \(\chi(d/Y)=0\) 时把 \(q_Y(d)\) 视为零。取

\[
J=\lceil\log_2Y\rceil,
\qquad L_Y=2^{-J}.
\tag{4}
\]

沿用 note 110 的 \(G_{L_Y}\) 和完整活动行集 \(\mathcal N_Y\)，定义

\[
\mathcal U_\chi(Y;N)
=\sum_{d\in\mathbb Z}
\left[
G_{L_Y}(d/N)-G_{L_Y}((d+1)/N)
\right]
\chi(d/Y)M(d),
\tag{5}
\]

以及

\[
\mathcal O_\chi(Y)
=\sum_{N\in\mathcal N_Y}|\mathcal U_\chi(Y;N)|^2.
\tag{6}
\]

由 \(\chi\) 的固定紧支撑，\(\mathcal N_Y\) 总可选在一个固定常数窗

\[
c_\chi Y-O(1)\le N\le C_\chi Y+O(1)
\tag{7}
\]

中，因此其行数为 \(O_\chi(Y)\)。

## 2. cutoff 将路径能量降到 \(O(Y)\)

对整数 \(d\)，

\[
\begin{aligned}
q_Y(d+1)-q_Y(d)
&=\chi((d+1)/Y)\mu(d+1)\\
&\quad+
\left[\chi((d+1)/Y)-\chi(d/Y)\right]M(d).
\end{aligned}
\tag{8}
\]

因 \(\chi\) 在支撑边界前已经为零，(8) 同时包含 note 110 的零延拓端点差分。
使用 \(|\chi((d+1)/Y)-\chi(d/Y)|\le\|\chi'\|_\infty/Y\)，得

\[
D_0(q_Y)
\ll_\chi
\sum_{d\asymp_\chi Y}|\mu(d)|^2
+\frac1{Y^2}\sum_{d\asymp_\chi Y}|M(d)|^2.
\tag{9}
\]

第一项为 \(O_\chi(Y)\)。对第二项，平凡界 \(|M(d)|\le d\) 已给出

\[
\frac1{Y^2}\sum_{d\asymp_\chi Y}|M(d)|^2
\ll_\chi Y.
\tag{10}
\]

因此不使用 RH 就有

\[
\boxed{D_0(q_Y)\ll_\chi Y.}
\tag{11}
\]

note 110 的统一 coercivity 与 \(\chi=1\) on \([1,2]\) 给出

\[
\boxed{
\sum_{Y\le d\le2Y}|M(d)|^2
\ll_{F,\chi}
\mathcal O_\chi(Y)+Y.}
\tag{12}
\]

这是本文的承重定量归约。

## 3. RH 等价定理

### 定理

以下两个命题等价：

1. 黎曼猜想成立；
2. 对每个 \(\varepsilon>0\)，

   \[
   \boxed{
   \mathcal O_\chi(Y)
   \ll_{\varepsilon,F,\chi}Y^{2+\varepsilon}
   \qquad(Y\ge2).}
   \tag{13}
   \]

**RH \(\Rightarrow\) (13)。** 使用经典 RH 等价式

\[
M(x)\ll_\delta x^{1/2+\delta}
\qquad(\delta>0).
\tag{14}
\]

对每个 \(N\in\mathcal N_Y\)，沿 \(d\) 的差分系数的 \(\ell^1\) 范数由
\(\operatorname{Var}G_{L_Y}\) 控制。log-dilation 平均不增加总变差，故一致于 \(Y\)，

\[
\sum_d
|G_{L_Y}(d/N)-G_{L_Y}((d+1)/N)|
\le\operatorname{Var}G_{L_Y}
\le\operatorname{Var}F.
\tag{15}
\]

因此

\[
|\mathcal U_\chi(Y;N)|
\ll_{F,\chi,\delta}Y^{1/2+\delta}.
\tag{16}
\]

由 (7) 只有 \(O(Y)\) 个行，在 (16) 中取 \(\delta<\varepsilon/2\)，即得 (13)。

**(13) \(\Rightarrow\) RH。** 由 (12)--(13)，对每个 \(\varepsilon>0\)，

\[
\sum_{Y\le d\le2Y}|M(d)|^2
\ll_{\varepsilon,F,\chi}Y^{2+\varepsilon}.
\tag{17}
\]

固定 \(\sigma>1/2\)，并取 \(0<\varepsilon<2\sigma-1\)。Cauchy--Schwarz 给出

\[
\begin{aligned}
\int_Y^{2Y}|M(x)|x^{-\sigma-1}dx
&\le
\left(\int_Y^{2Y}|M(x)|^2dx\right)^{1/2}
\left(\int_Y^{2Y}x^{-2\sigma-2}dx\right)^{1/2}\\
&\ll Y^{1/2-\sigma+\varepsilon/2}.
\end{aligned}
\tag{18}
\]

整数和版本 (17) 与积分版本只相差端点及长度为一的阶梯 cell，同一界成立。
因为 (18) 的 dyadic 指数为负，所以

\[
\int_1^\infty M(x)x^{-s-1}dx
\tag{19}
\]

在 \(\Re s>1/2\) 上局部一致收敛。它与 \(\Re s>1\) 上的恒等式

\[
\frac1{\zeta(s)}
=s\int_1^\infty M(x)x^{-s-1}dx
\tag{20}
\]

一致，因此 \(1/\zeta(s)\) 全纯延拓到 \(\Re s>1/2\)。该开半平面中没有
\(\zeta\) 零点。与函数方程合并即得 RH。\(\square\)

## 4. 边界与文献位置

(13) 是 RH 的等价判据，不是 RH 的无条件证明。它的新数学内容在于

\[
\boxed{
\text{一个最细 log-dilation block 的均方上界}
\Longrightarrow
\text{raw Mertens 均方，且无插值指数损失}.}
\]

它不能由 note 105 的全线 Mellin 符号单独得到；承重输入是 note 110 的完整行窗
离散 coercivity 和 (8)--(11) 的 cutoff 路径能量。

2026-08-14 的定向文献核对中，Nathan Ng 的
*The distribution of the summatory function of the Möbius function* (2004, arXiv:math/0310381)
研究的 weak Mertens 均方条件更强：它推出 RH、零点单性以及关于
\(1/\zeta'(\rho)\) 的额外收敛性，反向则需要比 RH 更强的输入。
该文不包含 (5)--(13) 的有限 finest-scale detector。
本文不据此声称穷尽性首创；它只记录当前项目中已证的精确对象与量词。
