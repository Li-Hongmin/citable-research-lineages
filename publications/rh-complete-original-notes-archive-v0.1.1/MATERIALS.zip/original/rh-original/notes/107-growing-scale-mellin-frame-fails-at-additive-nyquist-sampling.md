> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 增长尺度 Mellin frame 在加法 Nyquist 采样处失效

日期：2026-08-14。

依赖：[note 104](104-log-dilation-gram-has-explicit-mellin-null-modes.md)、
[note 105](105-the-cell-detector-is-zero-free-to-the-imaginary-axis.md)、
[note 106](106-hminus2-observation-and-path-energy-lose-two-thirds-of-an-exponent.md)。

证据等级：连续 Mellin 乘子的显式上下界，以及有限采样矩阵的显式定量近零向量。

note 105 证明任意固定有限个 log-dilation 滤波器只给出负阶 frame。
本文判定自然的增长秩修复

\[
L_j=2^{-j},\qquad 0\le j\le J\asymp\log_2Y.
\tag{1}
\]

它在连续 Mellin 层确实恢复频带上的 raw lower frame，却在整数采样层
被显式 additive-Nyquist 载波破坏。

## 1. 连续增长尺度 frame

沿用 note 105 的

\[
F(t)=\log\frac1t\left(\frac2{\pi t}+\sin2\pi t\right)
\mathbf1_{(2/3,1)}(t),
\qquad K(s)=\int_{2/3}^1F(t)t^{s-1}\,dt.
\tag{2}
\]

令 \(R_j=e^{L_j}\)，对应 Mellin 符号为

\[
m_j(t)=K(it)\frac{1-e^{itL_j}}{L_j}.
\tag{3}
\]

note 105 给出绝对常数 \(c_K,C_K>0\)，使

\[
c_K\le |tK(it)|\le C_K\qquad(|t|\ge1).
\tag{4}
\]

### 定理 1

对每个固定 \(A<2\pi\)，存在与 \(J\) 无关的 \(c_A,C>0\)，使

\[
\boxed{c_A\le\max_{0\le j\le J}|m_j(t)|\le C
\qquad(1\le|t|\le A2^J).}
\tag{5}
\]

**证明。** 若 \(1\le|t|\le2^J\)，取
\(j=\lceil\log_2|t|\rceil\)，则 \(x=|t|2^{-j}\in(1/2,1]\)，故

\[
\frac{|1-e^{itL_j}|}{L_j}=|t|\frac{|1-e^{ix}|}{x}\gg|t|.
\tag{6}
\]

若 \(2^J<|t|\le A2^J\)，取 \(j=J\)，此时 \(x\in[1,A]\)，而
\(A<2\pi\) 使 \(|1-e^{ix}|/x\) 有正下界。与 (4) 合并得下界；
上界由 \(|1-e^{ix}|\le\min(2,|x|)\) 得到。\(\square\)

常数 \(2\pi\) 在共同零的意义下尖锐：

\[
t=2\pi2^J\quad\Longrightarrow\quad1-e^{itL_j}=0\quad(0\le j\le J).
\tag{7}
\]

平方和也有统一下界，但无与 \(J\) 无关的上界：固定非零低频上，
所有足够细尺度都贡献常数量，总和为 \(\asymp J\)。

## 2. 整数采样的显式近零向量

记 \(G_{L_j}\) 为相应 dilation 平均，并对 \(Y<N\le2Y\) 定义

\[
b_d^{(j,N)}=G_{L_j}(d/N)-G_{L_j}((d+1)/N),
\qquad(B_Y^{(j)}q)_N=\sum_db_d^{(j,N)}q(d).
\tag{8}
\]

### 定理 2

存在显式 mean-zero 向量 \(q_Y\)，使

\[
\|q_Y\|_2^2\asymp Y,
\qquad
\boxed{\frac{\sum_{j=0}^J\|B_Y^{(j)}q_Y\|_2^2}{\|q_Y\|_2^2}
\ll\frac{\log Y}{Y^2}.}
\tag{9}
\]

**证明。** 取一个长度与 \(Y\) 成比例的偶数长连续整数区间

\[
I_Y\subset[3Y/2,8Y/5],\qquad |I_Y|\asymp Y,
\qquad q_Y(d)=(-1)^d\mathbf1_{I_Y}(d).
\tag{10}
\]

则 \(\sum_dq_Y(d)=0\) 且 \(\|q_Y\|_2^2\asymp Y\)。关键局部估计是

\[
\sup_{j\ge0}\left(\|G'_{L_j}\|_{L^\infty(H)}+
\operatorname{Var}_H G'_{L_j}\right)<\infty,
\qquad H=[0.74,1.61].
\tag{11}
\]

显式 \(F\) 在 \(a=2/3\) 有唯一值跳跃；在 \(1\) 连续为零，仅一阶导数跳跃。
又

\[
tG'_L(t)=\frac{F(t)-F(te^{-L})}{L}.
\tag{12}
\]

当 \(j\ge4\) 时，
\((2/3)e^{L_j}<(2/3)e^{1/16}<0.710\)，所以 \(H\) 避开值跳跃及其平移。
在对数坐标中令 \(f(x)=F(e^x)\)，则相关紧区间上 \(f\) 绝对连续且 \(f'\in BV\)；
而

\[
\frac{f(x)-f(x-L_j)}{L_j}=\frac1{L_j}\int_0^{L_j}f'(x-y)\,dy.
\tag{13}
\]

平移平均不增加 \(L^\infty\) 或 BV 范数。余下只有有限个固定核，因此 (11) 成立。

对充分大的 \(Y\)，\(d,d+1,d+2\in I_Y+O(1)\) 且 \(Y<N\le2Y\) 时的所有 cell 都落入 \(H\)。
由 cell-integral 表示和 (11)，一致于 \(j,N\) 有

\[
\max_{d\in I_Y}|b_d^{(j,N)}|\ll N^{-1},
\qquad
\sum_{d\in I_Y}|b_{d+1}^{(j,N)}-b_d^{(j,N)}|
\le N^{-1}\operatorname{Var}_HG'_{L_j}\ll N^{-1}.
\tag{14}
\]

将交错和按相邻项配对，得

\[
|(B_Y^{(j)}q_Y)_N|\ll Y^{-1}.
\tag{15}
\]

每个 block 有 \(O(Y)\) 行，故
\(\|B_Y^{(j)}q_Y\|_2^2\ll Y^{-1}\)。对 \(O(\log Y)\) 个尺度求和再除以
\(\|q_Y\|_2^2\asymp Y\)，即得 (9)。\(\square\)

## 3. 边界与路线裁决

反例机制是 additive Nyquist aliasing：最细尺度的强跳跃只在
\(d/N\approx2/3\) 的窄带内被采样；在固定内部带上，全部尺度行仍是一致 BV 的缓变序列，
因而交错载波将其同时消去。更一般的有限调制可用避开其载频的内部高频波包复制这一机制；
因此少量 shifted-grid 或 modulation 不会恢复统一 raw frame。

定理 2 是任意向量上的确定性 frame 反例，它不声称真实 Mertens 向量沿该方向集中。
然而，若新 augmentation 真正给出把任意 \(q\) 的 \(\ell^2\) 范数控制为观测能量的 coercivity，
则对 \(q=M\) 证明 RH-scale 观测上界会立即推出 RH-strength Mertens 平方门。
确定性 coercivity 本身不能代替这个算术上界。

因此以下黑箱桥严格关闭：

\[
\boxed{
\text{continuous growing-scale Mellin frame}
\not\Longrightarrow
\text{finite mean-zero raw coercivity}.}
\tag{16}
\]

连续乘子的全频带覆盖与有限整数采样的加法可观性是两个不同的门。
