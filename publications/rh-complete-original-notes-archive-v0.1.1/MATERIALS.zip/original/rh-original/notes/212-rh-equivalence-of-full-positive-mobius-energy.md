> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 全整数 |h| 正能量门与 RH 的精确逻辑关系

日期：2026-08-15。

本 note 只讨论全整数正能量
\[
w(t)=\frac{|h(t)|}{2\pi},\qquad
F_N(t)=\sum_{n\le N}\mu(n)n^{it},\qquad
E_N(w)=\int_{\mathbb R}w(t)|F_N(t)|^2\,dt .
\tag{1}
\]
重点是区分已经证明的蕴含、需要一个解析乘子引理的蕴含，以及 RH 假设下
可以反向推出的估计；不能把“正能量门”直接写成无条件的 RH 等价式。

## 1. 正能量门给出的精确测试空间估计

令 \(\psi\) 为 \((0,1)\) 上的 Mellin 测试函数，并写
\[
 K_\psi(s)=\int_0^1\psi(u)u^{s-1}\,du,
 \qquad \Psi(t)=K_\psi(it).
\]
只要
\[
 \|\Psi\|_{w^{-1}}^2:=\int_{\mathbb R}\frac{|\Psi(t)|^2}{w(t)}\,dt<\infty
 \tag{2}
\]
（零点处按零延拓理解），Mellin 反演和 Cauchy--Schwarz 给出
\[
 \begin{aligned}
 S_\psi(N)&:=\sum_{n\le N}\mu(n)\psi(n/N)\\
 &=\frac1{2\pi}\int_{\mathbb R}\Psi(t)N^{it}F_N(-t)\,dt,
 \end{aligned}
\]
以及
\[
|S_\psi(N)|^2
 \le \frac{E_N(w)}{4\pi^2}\int_{\mathbb R}
       \frac{|\Psi(t)|^2}{w(t)}\,dt .
 \tag{3}
\]
因此
\[
 E_N(w)\ll_\varepsilon N^{1+\varepsilon}
 \quad\Longrightarrow\quad
 S_\psi(N)\ll_{\psi,\varepsilon}N^{1/2+\varepsilon}
 \tag{4}
\]
对所有满足 (2) 的 \(\psi\) 成立。这一步完全是有限和恒等式，不使用 RH。

## 2. 何时 (4) 真正推出 RH

设存在一个测试函数 \(\psi_0\) 满足 (2)，且 \(K_{\psi_0}\) 在开临界带
\(1/2<\operatorname{Re}s<1\) 全纯并且无零。对 \(\operatorname{Re}s>1\)，Mellin--Fubini
恒等式为
\[
 \int_1^\infty S_{\psi_0}(x)x^{-s-1}\,dx
   =\frac{K_{\psi_0}(s)}{\zeta(s)} .
 \tag{5}
\]
由 (4)，左侧在每个半平面 \(\operatorname{Re}s>1/2+\eta\) 绝对收敛并全纯；
解析延拓后，在开带 \(1/2<\operatorname{Re}s<1\) 除以无零的
\(K_{\psi_0}\)，得到 \(1/\zeta(s)\) 全纯。因此 \(\zeta\) 在开带内无零；
结合函数方程与临界线对称性即得 RH。这里不要求在边界点 \(s=1\) 讨论乘子的零点。

所以逻辑上严格成立的是
\[
 \boxed{\text{正能量门}+(\text{一个 admissible、临界带无零的 Mellin 乘子})
 \ \Longrightarrow\ \mathrm{RH}.}
\tag{6}
\]

对当前正 detector 还存在一个更直接的推论：\(h(0)>0\) 给出 \(w\) 在零频
的正邻域。若 (4) 对所有截断 \(N\) 统一成立，在
\(\max_{x\le X}|M(x)|\) 的最大点应用 Abel 部分求和，即可直接得到
\(M(X)\ll_\varepsilon X^{1/2+\varepsilon}\)，从而推出 RH；详见 note 246。
因此外函数乘子是一个稳健的通用接口，但不是当前 detector 从正能量门推出
RH 所必需的额外假设。
正能量门本身不自动给出该乘子。对当前 \(V_{15}\) detector，note 213
把所需的条带 Jensen--Blaschke--Green 因子化压缩为一个明确的标准引理，并
给出零点计数与 Green 加权的证明框架：
\[
 \int_{\mathbb R}\frac{\log^-|h(t)|}{1+t^2}\,dt<\infty.
\tag{7}
\]
在该条带引理成立时，外函数 \(O\) 满足 \(|O(it)|^2=w(t)\)；再除以 \((s+1)^J\) 即得到
\(\Psi=O/(s+1)^J\) 满足 (2) 且在 \(\operatorname{Re}s>0\) 无零。对当前
detector，(6) 与 RH 的双向关系只剩算术正能量界本身。

## 3. RH 反向推出能量门：一个更短的 Abel 证明

这里不需要截断 Perron 或扭曲的 \(1/\zeta\) 估计。RH 的经典 Mertens
等价性给出：对每个 \(\delta>0\)，
\[
 M(x):=\sum_{n\le x}\mu(n)\ll_\delta x^{1/2+\delta}.
\tag{8}
\]
对任意实数 \(t\)，Abel 部分求和给出精确恒等式
\[
 F_N(t)=M(N)N^{it}-it\int_1^N M(u)u^{it-1}\,du .
\tag{9}
\]
取 \(0<\delta<1/2\)，由 (8)--(9) 得
\[
 |F_N(t)|\ll_\delta N^{1/2+\delta}(1+|t|),
\tag{10}
\]
因为 \(\int_1^N u^{-1/2+\delta}\,du\ll_\delta N^{1/2+\delta}\)。若
\[
 \int_{\mathbb R}(1+t^2)w(t)\,dt<\infty,
\tag{11}
\]
则直接积分得到
\[
 E_N(w)=\int w(t)|F_N(t)|^2dt
 \ll_{w,\delta}N^{1+2\delta}.
\tag{12}
\]
令 \(2\delta<\varepsilon\)，便得到
\[
 \boxed{\mathrm{RH}+(11)\quad\Longrightarrow\quad
 E_N(w)\ll_{w,\varepsilon}N^{1+\varepsilon}.}
\tag{13}
\]
对当前 detector，\(h(t)=O_\varepsilon(|t|^{-19/2+\varepsilon})\)，所以 (11)
严格成立。这个方向只使用经典 RH\(\Rightarrow\)Mertens 平方根界和一次
Abel 恒等式；不再需要旧版中的截断 Perron 量化。

对于当前 \(V_{15}\) detector，note 246 已用 \(h(0)>0\) 和最大点 Abel
部分求和直接给出正向 \(E_N\Rightarrow\mathrm{RH}\)，不需要 (7) 的外函数
引理。结合 RH 下的 (13)，这里的正能量门与 RH 已形成严格双向关系；note 213
仍保留为更一般的 Mellin 测试空间接口，但不再是当前 detector 的必要步骤。

## 4. 已知零自由区只能给 subpower 节省

无条件地，经典零自由区与
\[
 |M(x)|\ll x\exp\{-c(\log x)^{3/5}(\log\log x)^{-1/5}\}
 \tag{14}
\]
结合 dyadic 比值分解和指数阶 Bernstein 逼近（notes 200--202），对
\(w\in L^1\) 且 \(\int |t|w(t)dt<\infty\) 得到
\[
 E_N(w)\ll_w N^2
 \exp\{-c_w(\log N)^{3/5}(\log\log N)^{-1/5}\}.
 \tag{15}
\]
因为指数只为 \(o(\log N)\)，(15) 对每个固定 \(\varepsilon>0\) 仍远大于
\(N^{1+\varepsilon}\)。所以已知 zero-free 区不能把正能量门推进到平方根
尺度；缺口确实是宏观 Möbius 二点 signed cancellation，而非频率尾的技术误差。

## 5. 结论

当前可审计的最精确表述是：

1. (3)--(4) 是无条件的正能量到 Mellin 测试和估计；
2. 加上一个满足 (2)、临界带无零的 Mellin 乘子，便严格推出 RH；
3. RH 加经典 Mertens 界及 (11) 反向推出 (13)；
4. 对当前 detector，note 246 给出不依赖外函数的
   \(E_N\Rightarrow M(X)\ll X^{1/2+\varepsilon}\) 推论；note 213 的外函数
   接口仍是可复用的条件性解析框架；
5. 无条件 zero-free 区只给 (15) 的 stretched-log 次幂节省，不能宣称解决 RH。

因此对当前 detector，“\(E_N\ll N^{1+\varepsilon}\)”与 RH 的双向关系
已经严格归约完成；剩余唯一承重缺口是该算术能量界本身。本 note 不把它
误报为已经得到的无条件估计。

更一般地，上述证明给出如下与 detector 具体形式无关的命题：

\[
\boxed{
\begin{gathered}
w\ge0,\qquad
w(t)\ge c_0>0\ \ (|t|\le\delta_0),\qquad
\displaystyle\int_{\mathbb R}(1+t^2)w(t)\,dt<\infty
\\[2mm]
\Longrightarrow\quad
\mathrm{RH}
\ \Longleftrightarrow\
\forall\varepsilon>0,\quad
\int_{\mathbb R}w(t)\left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt
\ll_{w,\varepsilon}N^{1+\varepsilon}.
\end{gathered}}
\tag{16}
\]

右向左是 note 246 的最大点 Abel 引理；左向右是 (8)--(13) 的直接
部分求和。故“寻找更好的正权”本身不会产生一个弱于 RH 的算术目标：
只要该权保留零频正质量并具有有限二阶矩，其平方根能量界就是 RH 的另一种
表述。

把量词写成一个单独的命题，就是

\[
\boxed{
\mathrm{RH}
\quad\Longleftrightarrow\quad
\forall\varepsilon>0,
\quad
E_N\!\left(\frac{|h|}{2\pi}\right)
\ll_{\varepsilon}N^{1+\varepsilon}
\quad(N\ge2).
}
\tag{17}
\]

这里左向右使用 RH 下的 Mertens 界与 Abel 部分求和；右向左只用
\(h(0)>0\) 与 note 246 的最大点 Abel 引理。因此当前 detector 的正能量
路线已经精确识别为 RH 的固定权二次型重述，而不是一个已知的较弱中间命题。
