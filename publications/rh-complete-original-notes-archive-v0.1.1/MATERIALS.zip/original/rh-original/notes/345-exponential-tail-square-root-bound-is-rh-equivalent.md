> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 指数外函数尾核的平方根界与 RH 双向等价

日期：2026-08-16。

沿用 note 341 的指数模型
\[
o(\xi)=e^{-\xi}{\bf1}_{\xi\ge0},
\qquad
A_N=\sum_{n\le N}\frac{\mu(n)}n,
\qquad
D_N(t)=\sum_{n\le N}\mu(n)n^{-it}.
\]
由 note 343 的 Hardy--Laplace 恒等式，定义
\[
I_N:=\int_{\mathbb R}\frac{|D_N(t)-A_N|^2}{1+t^2}\,dt
=8\pi^3\|\mathcal K_{N,o}\|_2^2.
\tag{1}
\]
则
\[
\boxed{
\mathrm{RH}
\quad\Longleftrightarrow\quad
\forall\varepsilon>0,\quad
I_N\ll_\varepsilon N^{1+\varepsilon}
\quad(N\ge2).}
\tag{2}
\]

## 1. RH 推出能量界

在 RH 下，经典 Mertens 界给出
\[
M(x):=\sum_{n\le x}\mu(n)\ll_\varepsilon x^{1/2+\varepsilon}.
\]
部分求和及 \(A_x\to0\) 给出
\[
|A_x|\ll_\varepsilon x^{-1/2+\varepsilon}.
\]
将其代入 note 341 的精确尾和恒等式
\[
4\pi^2\|\mathcal K_{N,o}\|_2^2
=\sum_{k=1}^{N-1}\left(k+\frac12\right)|A_N-A_k|^2
\]
可得
\[
\|\mathcal K_{N,o}\|_2\ll_\varepsilon N^{1/2+\varepsilon},
\]
即 \(I_N\ll_\varepsilon N^{1+\varepsilon}\)。这也是 note 342 的条件估计。

## 2. 能量界推出 Mertens 平方根界

反设 (2) 的右侧成立。令
\[
M^*(X)=\max_{1\le x\le X}|M(x)|
\]
并选 \(X_0\le X\) 使 \(|M(X_0)|=M^*(X)\)。由素数定理，
\[
A_x\longrightarrow0.
\tag{3}
\]
因此存在固定 \(X_1\)，使 \(|A_x|\le1/4\) 对 \(x\ge X_1\) 成立。
若 \(M^*(X)<1\) 或 \(X_0<X_1\)，所需的
\(M^*(X)\ll_\varepsilon X^{1/2+\varepsilon}\) 已是平凡的。否则
\[
|D_{X_0}(0)-A_{X_0}|
=|M(X_0)-A_{X_0}|
\ge \frac34M^*(X).
\tag{4}
\]

Abel 部分求和给出
\[
D_{X_0}(t)
=M(X_0)X_0^{-it}
+it\int_1^{X_0}M(u)u^{-it-1}\,du.
\]
于是对实 \(t\)
\[
|D_{X_0}(t)-D_{X_0}(0)|
\le 2|t|M^*(X_0)\log X_0.
\tag{5}
\]
当
\[
|t|\le\frac1{32\log X_0}
\]
时，(4)--(5) 给出
\[
|D_{X_0}(t)-A_{X_0}|
\ge \frac12M^*(X).
\tag{6}
\]
又因 \(1/(1+t^2)\ge1/2\) 于该区间，故
\[
I_{X_0}
\ge \frac12\cdot\frac14(M^*(X))^2
\cdot\frac1{16\log X_0}
=\frac{(M^*(X))^2}{128\log X_0}.
\tag{7}
\]
假设 \(I_{X_0}\ll_\delta X_0^{1+\delta}\)，便有
\[
(M^*(X))^2\ll_\delta X^{1+\delta}\log X.
\]
给定任意 \(\varepsilon>0\)，取 \(\delta<\varepsilon\) 并吸收对数因子，得到
\[
M(X)\ll_\varepsilon X^{1/2+\varepsilon}.
\tag{8}
\]
经典的 Mertens--RH 等价性遂推出 RH。

## 3. 结论

指数外函数模型并非丢失零频的弱证书；其零频值是
\[
D_N(0)-A_N=M(N)-A_N,
\]
而 \(A_N=o(1)\)。所以它提供了一个与 RH 双向等价的、完全显式的局部
对偶门。无条件零自由区只能给 note 342 的
\(N^{1-o(1)}\) 上界；无条件平方根界仍等价于 RH 本身。
