> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius-preconditioned detector 的精确正 periodization

日期：2026-08-17。

本 note 给出一个真正把 Möbius 卷积和正 periodization 同时实现的
精确构造。它使用 \(\mu\) 本身作为 detector 的预条件器，因此不是
无条件 RH 证明；但它把 arithmetic intertwiner 的目标形式写成了
完全可审计的对象。

## 1. 构造

取 \(\phi\in C_c^\infty((0,1))\)，并定义
\[
 V_\phi(u):=\sum_{n\ge1}\mu(n)\phi(nu),\qquad u>0.
\tag{1}
\]
因为 \(\phi\) 紧支撑于 \((0,1)\)，对每个固定 \(u>0\) 该和只有有限项。
定义 periodization
\[
 P_{V_\phi}(y):=\sum_{c\le y}V_\phi(c/y),\qquad y\ge1.
\]
代入 (1) 并令 \(k=nc\)，得到
\[
\begin{aligned}
P_{V_\phi}(y)
 &=\sum_{k<y}\phi(k/y)\sum_{n\mid k}\mu(n)\\
 &=\phi(1/y),
\end{aligned}
\tag{2}
\]
因为 \(\sum_{n\mid k}\mu(n)=\mathbf1_{k=1}\)。特别地，若
\(\phi\ge0\)，则
\[
\boxed{P_{V_\phi}(y)=\phi(1/y)\ge0.}
\tag{3}
\]
这是 exact collapse，不是平均估计。

## 2. Mellin 乘子

令
\[
 \Phi(s):=\int_0^1\phi(u)u^{s-1}\,du.
\]
在 \(\Re s>1\) 的绝对收敛区，
\[
\begin{aligned}
 K_{V_\phi}(s)
 &=\int_0^1V_\phi(u)u^{s-1}\,du\\
 &=\Phi(s)\sum_{n\ge1}\frac{\mu(n)}{n^s}
 =\boxed{\frac{\Phi(s)}{\zeta(s)}}.
\end{aligned}
\tag{4}
\]
所以该构造精确携带一个 \(\zeta^{-1}\) 因子，而不是只匹配边界模长。

## 3. 它支付的算术代价（完整和；截断校正见 note 370）

对应的 reciprocal Möbius 双和为
\[
\begin{aligned}
 T_\phi^{\mathrm{full}}(x)
 &:=\sum_{ab<x}\mu(a)\mu(b)
 P_{V_\phi}\!\left(\frac{x}{ab}\right)\\
 &=\sum_{ab<x}\mu(a)\mu(b)\phi(ab/x)\\
 &=\sum_{k<x}(\mu*\mu)(k)\phi(k/x).
\end{aligned}
\tag{5}
\]
其 Mellin 变换在绝对收敛区为
\[
\int_1^\infty T_\phi^{\mathrm{full}}(x)x^{-s-1}\,dx
=\frac{\Phi(s)}{\zeta(s)^2}.
\tag{6}
\]
因此完整和的正 periodization 并没有自动给出正的 Möbius 二次型；
它把 full 对象精确转成 \(\mu*\mu\) 的平滑和。原始
\(a,b\le\sqrt x\) 截断和与它相差 incomplete-lcm boundary，不能由
上述重排消掉；见 note 370。

## 4. 对 RH 的边界

若能无条件控制 (5) 到 \(x^{1/2+\varepsilon}\) 级，(6) 将直接给出
\(1/\zeta(s)^2\) 在相应半平面的解析性，从而达到 RH 级结论。反过来，
在 RH 下，\(\Phi/\zeta\) 的增长和 (5) 的平方根级控制才有标准解析
路径。

所以 (1)--(6) 提供了一个真实的 arithmetic intertwiner 候选：
它同时满足正 periodization 和精确 \(\zeta^{-1}\) 乘子；但其代价是
需要控制 \(\mu*\mu\) 的 signed cancellation。这个代价正是当前未闭合的
RH-strength 算术门，不能用 detector 正性本身替代。
