> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(\frac12\log11\) 处 even \(J=640\) joint-Parseval 真下模型门不定

日期：2026-08-14。

本 note 使用 [note 089](089-strict-local-weil-positivity-to-log201over20-half.md) 的 full-space
Yukawa Loewner 下算子与 joint Parseval 恒等式，严格关闭该机制在
\(a=\frac12\log11\)、even、\(J=640\) 的一个有限正性门。

## 命题

令 \(P=P_{400}^+\)、\(Q=I-P\)，取

\[
F_{640}=(r_{500}^+,\ldots,r_{639}^+)=B_F\oplus V,
\qquad t_q=d_q-2.931158.
\]

令 \(P_0=PL_0^+P-R_P/t_{400}\)，并定义

\[
\begin{aligned}
U_q&=PB_0^+e_q+B_FV^*e_q,\\
R_{\rm tot}&=\sum_{q\ge400}U_qU_q^*,\\
R_1&=\sum_{400\le q<2000}U_qU_q^*,\qquad
G_1=\sum_{400\le q<2000}\frac{U_qU_q^*}{t_q},\\
G_{11,640}&=P_0+\frac{R_P}{t_{400}}+B_FB_F^*
-G_1-\frac{R_{\rm tot}-R_1}{t_{2000}}.
\end{aligned}
\tag{1}

则

\[
\boxed{\operatorname{inertia}(G_{11,640})=(399,1,0).}
\tag{2}
\]

特别地，\(G_{11,640}\not>0\)。

## 证明

note 089 的 Parseval 恒等式给出

\[
R_{\rm tot}
=R_P+X_FB_F^*+B_FX_F^*+B_FG_QB_F^*,
\tag{3}
\]

且 \(t_q\ge t_{2000}\)（\(q\ge2000\)）。所以 (1) 是
\(\operatorname{Schur}_Q(\underline L_{11,640})\) 的严格有限 Loewner 下界。这里没有逐 atom
绝对值支付。

在权威七个 Householder 合同后，分块为 \(7\oplus393\)。256-bit Arb Cholesky 严格给出

\[
p_{\min}(H_{393})
=[0.04076175743113018099732688390629\ldots\pm5.10\cdot10^{-58}]>0.
\tag{4}
\]

verified solve 后，七维 Schur complement 在排列

\[
(6,2,3,4,5,1,0)
\tag{5}
\]

下的前六个 LDL pivot 严格正，最后一个为

\[
[-2.00233952790691326054\cdot10^{-47}\pm4.15\cdot10^{-68}]<0.
\tag{6}
\]

由 (4)--(6) 得 (2)。完整冻结输出、父缓存 hash 和 replay 入口见
[`log11-even-j640-true-lower-model-obstruction`](../computations/bundles/log11-even-j640-true-lower-model-obstruction/README.md)。

## 能与不能推出的结论

这一结论关闭的是

\[
G_{11,640}>0\Longrightarrow A_{\frac12\log11}^+>0
\tag{7}
\]

中的左侧有限门；它不否定 (7)。事实上仅有

\[
G_{11,640}\preceq\operatorname{Schur}_Q(\underline L_{11,640})
\preceq A_{\frac12\log11}^+,
\tag{8}
\]

故 (2) 不能反推 \(\underline L_{11,640}\) 或 \(A_{\frac12\log11}^+\) 不定。它也不改变
[note 090](090-log11-even-p400-principal-compression-is-strictly-positive.md) 的有限主压缩正性。
