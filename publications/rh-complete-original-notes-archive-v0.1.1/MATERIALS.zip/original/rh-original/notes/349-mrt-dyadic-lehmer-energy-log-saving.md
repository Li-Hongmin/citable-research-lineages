> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# MRT 单移位门闭合 Lehmer 核的对数级上界

日期：2026-08-16。

本 note 修正 note 202 对“\(m\)-依赖比值权必须引入最大部分和”的过强判断。
关键是 MRT Theorem 1.6 的强化式 (1.11)：固定的第一因子可以取乘法函数，
第二因子只需 \(1\)-bounded。因此 \(B/q\) 可以直接放入第二因子；用
\(m/q=1-(q-m)/q\) 后，完整 dyadic Lehmer 块可由单移位平均定理控制。
所得仍只有对数级节省，远未达到 RH 的平方根门。

## 1. MRT 输入

对 \(10\le H\le X\)，\(a_i\le A\)、\(b_i\ll_A X\)，若 \(g_1,g_2\) 为
\(1\)-bounded 且 \(g_1\) 是乘法函数，则 MRT Theorem 1.6 的强化式给出
\[
 \sum_{1\le h\le H}
 \left|\sum_{1\le n\le X}
 g_1(a_1n+b_1)g_2(a_2n+b_2+h)\right|
 \ll_A XH\rho(X,H),
\tag{1}
\]
其中
\[
 \rho(X,H)=\frac{\log\log H}{\log H}+\frac1{\log^{1/3000}X}.
\]
对 \(\mu\) 的版本由原文第 1.1 节末明确说明。来源：
<https://arxiv.org/html/1503.05121>，Theorem 1.6，式 (1.11)。

## 2. 一个完整 dyadic 块的精确移位表达

令 \(B\ge10\)，\(I_B=(B,2B]\)，并令
\[
 \beta_B(q)=\min(1,B/q).
\]
对上三角 \(m<q\) 定义
\[
 U_B=\sum_{n=1}^{B}\sum_{h=1}^{B}
 \mu(B+n)\mu(B+n+h)\frac{B+n}{B+n+h}
 {\bf1}_{B<B+n+h\le2B}.
\tag{2}
\]
这恰好是 \(I_B\) 内所有上三角有序对的 Lehmer 权和：每个
\(m=B+n<q=B+n+h\) 出现一次。

把
\[
 \frac{B+n}{B+n+h}=1-\frac hB\frac B{B+n+h}
\tag{3}
\]
代入。对第一项在 (1) 中取
\[
 g_1=\mu,\qquad g_2(q)=\mu(q){\bf1}_{B<q\le2B},
\]
对第二项取
\[
 g_1=\mu,\qquad
 g_2(q)=\mu(q)\beta_B(q){\bf1}_{B<q\le2B}.
\]
两者均满足 MRT 的假设，且 \(a_1=a_2=1\)、\(b_1=b_2=B\)、\(X=H=B\)。
由于 \(0\le h/B\le1\)，得到
\[
 \boxed{|U_B|\ll B^2\rho(B,B).}
\tag{4}
\]
下三角等于上三角，故整个同尺度块（含对角线）满足
\[
 \left|\sum_{m,q\in I_B}\mu(m)\mu(q)\frac{\min(m,q)}{\max(m,q)}\right|
 \ll B+B^2\rho(B,B).
\tag{5}
\]

## 3. 不同 dyadic 尺度的精确覆盖

令 \(C=2^dB\)、\(d\ge1\)，并考虑
\(I_B\times I_C\)。把大块写成 \(2^d\) 个长度为 \(B\) 的窗口
\[
 W_\ell=(C+\ell B,C+(\ell+1)B],
 \qquad 0\le\ell<2^d.
\]
写 \(m=B+n\)、\(q=C+\ell B+v\)，其中 \(1\le n,v\le B\)。
每个窗口被以下两个单移位参数化**不重不漏**：
\[
\begin{array}{c|c|c}
 \text{区域}&b_2&h\ \\ \hline
 v>n&C+\ell B&v-n\in[1,B-1]\\
 v\le n&C+(\ell-1)B&B+v-n\in[1,B].
\end{array}
\tag{6}
\]
在第二行 \(\ell=0\) 时 \(b_2=C-B\ge B\)，所以所有偏移仍为非负且
\(b_2\ll 2^{d+1}B\)。两行都使用 (1)，并在第二因子中加入窗口指示函数
\({\bf1}_{W_\ell}(q)\)。对每一行，令
\(\Delta=b_2-B\)，则
\[
 \frac mq=1-\frac{\Delta+h}{B}\frac Bq,
 \qquad 0\le\frac{\Delta+h}{B}\ll2^d.
\tag{7}
\]
MRT 的常数中 \(A\ll2^{d+1}\)，所以每个窗口的贡献满足
\[
 |U_{B,C,\ell}^{\pm}|
 \ll 2^{3d+O(1)}B^2\rho(B,B).
\tag{8}
\]
求和 \(2^d\) 个窗口，得到
\[
 \boxed{|U_{B,C}|\ll 2^{4d+O(1)}B^2\rho(B,B).}
\tag{9}
\]
式 (6) 是关键：它避免了对 \(m\)-依赖权作 Abel 分部，也不引入最大部分和。

## 4. 对所有块求和

先取 \(N=2^J\)，并把 \(1,\ldots,N\) 分成 \(I_{2^j}\)。以下均假设
\(N\) 足够大，使 \(\rho_N<1\)；有限小 \(N\) 吸收到常数中。取
\[
 \rho_N=\frac{\log\log N}{\log N}+\frac1{\log^{1/3000}N},
 \qquad
 D=\left\lfloor\frac14\log_2(1/\rho_N)\right\rfloor.
\]
对 \(2^j\ge N^{1/2}\) 有 \(\rho(2^j,2^j)\ll\rho_N\)。由
\(\sum_{j\le J-d}2^{2j}\ll N^2 4^{-d}\)，(9) 给出近尺度部分
\[
 \sum_{d\le D}\sum_j |U_{2^j,2^{j+d}}|
 \ll N^2\rho_N\sum_{d\le D}4^d
 \ll N^2\rho_N^{1/2}.
\tag{10}
\]
块 \(2^j<N^{1/2}\) 的所有贡献用绝对值估计为
\(O(N\log N)\)。对 \(d>D\)，直接用
\(\min(m,q)/\max(m,q)\ll2^{-d}\) 得
\[
 \sum_{d>D}\sum_j |U_{2^j,2^{j+d}}|
 \ll N^2\sum_{d>D}4^{-d}
 \ll N^2\rho_N^{1/2}.
\tag{11}
\]
因此对 dyadic \(N\) 有严格的无条件界
\[
 \boxed{
 \boldsymbol\mu_N^T L_N\boldsymbol\mu_N
 \ll N^2\rho_N^{1/2}+N\log N.}
\tag{12}
\]
对一般 \(N\)，令 \(B=2^{\lfloor\log_2N\rfloor}\)，把 \((B,N]\) 视为末块，长度记为
\(L=N-B\)。若 \(L<\rho_NN\)，涉及末块的所有项绝对值估计为
\(O(\rho_NN^2)\)。若 \(L\ge\rho_NN\)，把末块按每个较小块
\(I_b=(b,2b]\) 的长度 \(b\) 再切成窗口；当 \(b\ge N/2^D\) 时，窗口数和
\(A\)-参数至多为 \(O(N/b)\)，重复 (8) 后该尺度的总贡献为
\(O(\rho_NN^2(N/b)^2)\)，对几何级数求和为
\(O(\rho_NN^2 4^D)=O(N^2\rho_N^{1/2})\)。当
\(b<N/2^D\) 时直接用权重 \(b/N\)，总贡献为
\(O(N^2 4^{-D})=O(N^2\rho_N^{1/2})\)。因此 (12) 对所有 \(N\) 成立（只改变绝对常数）。

由于
\[
 I_N=\pi\,\boldsymbol\mu_N^T(L_N-v_Nv_N^T)\boldsymbol\mu_N
 \le \pi\,\boldsymbol\mu_N^TL_N\boldsymbol\mu_N,
\]
指数尾模型的能量也满足
\[
 \boxed{I_N\ll N^2\rho_N^{1/2}.}
\tag{13}
\]

## 5. 边界与 RH-strength 解释

式 (13) 是无条件的 \(N^{2-o(1)}\) 对数级节省，不是固定幂次
\(N^{2-\delta}\)，更不是 \(N^{1+\varepsilon}\)。后者由 note 347 的显式
评价常数直接推出 Mertens 平方根界，因而仍与 RH 等价。

本 note 的实质修正是：对 Lehmer 核本身，MRT 的单移位定理已经足以处理
\(m/q\) 的权重；先前“必须使用最大部分和”的判断只适用于任意光滑
\(m\)-依赖权的直接 Abel 路线，不适用于这里的
\(m/q=1-(q-m)/q\) 特殊结构。剩余困难从“权重转移”收缩为固定幂次的
Möbius 相关门，而不是文献定理的适用性空白。

后续 note 350 进一步按差值 \(h=q-m\) 做 dyadic 分块；在每段
\(h\asymp H\) 中使用 \(h/q=(H/q)+(h-H)/H\cdot(H/q)\)，从而避免
跨尺度的 \(A\)-因子，把本 note 的 \(\rho_N^{1/2}\) 改进为
\(\rho_N\)。本 note 的跨尺度证明仍可作为独立的覆盖核验，但不是当前最强界。
