> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 对数 dilation 给出配对加性差分，但不是 divisor-incidence Gram

日期：2026-08-14。

依赖：
[note 095](095-k1-a2-cell-reduces-to-moving-scale-mobius-covariance.md)、
[note 097](097-continuous-log-dilation-removes-the-endpoint-without-losing-the-detector.md)、
[note 099](099-log-dilation-is-a-strict-l2-contraction-with-one-derivative-inverse.md)。

证据等级：精确尺度差分、离散 Abel 恒等式与有限 same-lcm 反例。
本文回答一个有限接口问题：note 097 的无端点核确实产生一左一右两个
genuine differences，但它们是实尺度/加法链差分，不是 Barban--Vehov--Graham
\(H^0\) 核所需的 divisor-incidence differences。

## 1. 精确的尺度配对差分

固定 \(R>1\)，令 \(L=\log R\)，并定义

\[
\Psi(t):=\int_t^\infty F(u)\frac{du}{u}.
\tag{1}
\]

因 \(F\) 支撑于 \((2/3,1)\)，有 \(\Psi(t)=0\;(t\ge1)\)。直接分割积分给出

\[
\boxed{
G_R(t)=\frac{\Psi(t/R)-\Psi(t)}{L}.
}
\tag{2}
\]

置

\[
V(x):=\sum_{d\ge1}\mu(d)\Psi(d/x).
\tag{3}
\]

对每个 \(x\)，(3) 只含 \(d<x\) 的有限和。由 (2)，

\[
\boxed{
S_{N,R}=\frac{V(RN)-V(N)}{L}.
}
\tag{4}
\]

若记 \(\mathscr D_RV(N):=V(RN)-V(N)\)，并令 \(P_Y\) 表示到
\(Y<N\le2Y\) 的正交坐标投影，则

\[
\boxed{
\sum_{Y<N\le2Y}|S_{N,R}|^2
=\frac1{L^2}\|P_Y\mathscr D_RV\|_{\ell^2}^2.
}
\tag{5}
\]

二次型的极化因而精确包含一个左 \(\mathscr D_R^*\) 与一个右
\(\mathscr D_R\)。这不是形式类比，而是完整平滑向量层的精确配对尺度差分。

## 2. 离散 Abel 给出双加性差分

令

\[
M(d):=\sum_{j\le d}\mu(j),
\qquad
a_{N,d}:=G_R(d/N),
\tag{6}
\]

并取差分约定

\[
\Delta_d^+a_{N,d}:=a_{N,d}-a_{N,d+1}.
\tag{7}
\]

由于 \(a_{N,d}\) 对 \(d\) 有限支撑，离散 Abel 求和没有边界项：

\[
S_{N,R}=\sum_{d\ge1}M(d)\Delta_d^+a_{N,d}.
\tag{8}
\]

定义

\[
H_{Y,R}(d,e)
:=\sum_{Y<N\le2Y}a_{N,d}a_{N,e},
\tag{9}
\]

则逐项展开 (8) 得

\[
\boxed{
\sum_{Y<N\le2Y}|S_{N,R}|^2
=\sum_{d,e\ge1}M(d)M(e)
\Delta_d^+\Delta_e^+H_{Y,R}(d,e).
}
\tag{10}
\]

且中间核有正 Gram 表示

\[
\boxed{
\Delta_d^+\Delta_e^+H_{Y,R}(d,e)
=\sum_{Y<N\le2Y}B_{N,d}B_{N,e},
\qquad
B_{N,d}:=G_R(d/N)-G_R((d+1)/N).
}
\tag{11}
\]

因而在完整有符号二次型中，两侧 centering 的确产生了两个真实
covariance differences。剩下的问题只在中间 Gram 的 basis。

## 3. 中间 Gram 不是 lcm/incidence 核

标准 divisor-incidence 算子为

\[
\mathcal I_{n,d}:=\mathbf1_{d\mid n}.
\tag{12}
\]

对任意非负对角权 \(W=\operatorname{diag}(w_n)\)，完整加权 Gram 满足

\[
\boxed{
(\mathcal I^*W\mathcal I)_{d,e}
=\sum_{k\ge1}w_{k[d,e]}
=:\Theta([d,e]).
}
\tag{13}
\]

特别地，它的 entry 只依赖 \([d,e]\)。下面的有限反例说明
(11) 不具有这一性质。

由 note 094 的 \(F(2/3+)>0\) 与 note 097 的

\[
tG_R'(t)=\frac{F(t)-F(t/R)}{L},
\tag{14}
\]

\(G_R\) 在 \(2/3\) 右侧的一个区间上严格递增。取足够大的
\(N_0\equiv0\pmod3\)，使 \([2/3,2/3+1/N_0]\) 落在该递增区间内，并置

\[
Y=N_0-1,
\qquad
d_1=\frac{N_0}{3},
\qquad
d_0=\frac{2N_0}{3}.
\tag{15}
\]

对 shell 中所有 \(N\ge N_0\)，

\[
\frac{d_1+1}{N}<\frac23,
\qquad
B_{N,d_1}=0.
\tag{16}
\]

所以

\[
(B^*B)_{d_1,d_0}=0.
\tag{17}
\]

另一方面，\(G_R(2/3)=0\)，而所选区间上严格递增，故

\[
B_{N_0,d_0}
=G_R(2/3)-G_R(2/3+1/N_0)\ne0,
\tag{18}
\]

从而

\[
(B^*B)_{d_0,d_0}>0.
\tag{19}
\]

但 \(d_1\mid d_0\)，因而

\[
[d_1,d_0]=[d_0,d_0]=d_0.
\tag{20}
\]

(17)--(20) 与任意 (13) 型 lcm 核的 same-lcm 等值性矛盾。因而
(11) 不可能是一个完整加权 divisor-incidence Gram。

## 4. 精确边界

\[
\boxed{
\begin{gathered}
\text{存在精确的 }\mathscr D_R^*P_Y\mathscr D_R
\text{ 尺度差分与 }\Delta_d^+\Delta_e^+
\text{ 加性差分；}\\
\text{但不存在到 Barban--Vehov--Graham }H^0
\text{ 完整 divisor Gram 的直接识别。}
\end{gathered}
}
\tag{21}
\]

若允许任意稠密的 \(D,T\)，任何有限正矩阵都可以作 Cholesky
分解，那已不是现有 Graham 黑箱。从 (10)--(13) 跨过首个失配所缺的
最小新输入，是一个将 common-scale total-order basis 映到
divisor-incidence basis 的非平凡 intertwiner。对数均匀 dilation 本身不提供它。
