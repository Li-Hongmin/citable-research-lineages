> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Báez--Duarte 逃逸尾的 Mertens 壳分解与首壳非消失

日期与检索截止：2026-08-12。

依赖：[note 062](062-baez-duarte-exact-window-interpolation-closes-compact-weil-transfer.md)。

## 1. 问题

note 062 将 compact-transfer 的剩余对象定位为

\[
f_N:=\chi+B_N,
\qquad
\operatorname{supp}f_N\subset(0,N^{-1}].
\tag{1}
\]

本 note 判定：缩放后的首个 causal/dual 窗是否已经控制该尾。

```mermaid
flowchart LR
  A["精确窗口插值 B_N"] --> B["逃逸尾 f_N"]
  B --> C["reciprocal 阶梯 h_N(m)"]
  C --> D["第一壳: M(m)+Nγ(N)"]
  D --> E["临界零点强制 limsup 壳能量 > 0"]
  B --> F["首个 dual 窗"]
  F --> G["仅 γ(N)+已知 sinc"]
```

## 2. 精确 reciprocal-shell 分解

沿用

\[
\rho_k(x)=\left\{\frac1{kx}\right\},
\quad
g(N)=\sum_{k\le N}\frac{\mu(k)}k,
\quad
\gamma(N)=g(N)-\frac{M(N)}N,
\quad
M(x)=\sum_{k\le x}\mu(k),
\tag{2}
\]

以及

\[
B_N=\sum_{k\le N}\mu(k)\rho_k-Ng(N)\rho_N.
\tag{3}
\]

**定理 1（精确 Mertens 壳）。** 对整数 \(m\ge N\)，在

\[
I_m:=\left(\frac1{m+1},\frac1m\right]
\tag{4}
\]

上 \(f_N\) a.e. 等于常数 \(h_N(m)\)，其中

\[
\begin{aligned}
h_N(m)
&=1+Ng(N)\left\lfloor\frac mN\right\rfloor
-\sum_{k\le N}\mu(k)\left\lfloor\frac mk\right\rfloor \\
&=Ng(N)\left\lfloor\frac mN\right\rfloor
+\sum_{N<k\le m}\mu(k)\left\lfloor\frac mk\right\rfloor \\
&=Ng(N)\left\lfloor\frac mN\right\rfloor
+\sum_{r\le m/(N+1)}
\left[M\!\left(\left\lfloor\frac mr\right\rfloor\right)-M(N)\right].
\end{aligned}
\tag{5}
\]

因此

\[
\boxed{
\|f_N\|_2^2
=\sum_{m=N}^{\infty}\frac{|h_N(m)|^2}{m(m+1)}.
}
\tag{6}
\]

若

\[
(D_Nf)(t)=N^{-1/2}f(t/N),
\qquad F_N=D_Nf_N,
\tag{7}
\]

则

\[
F_N(t)=N^{-1/2}h_N(m)
\quad\text{于}\quad
\frac N{m+1}<t\le\frac Nm.
\tag{8}
\]

**证明。** 令 \(y=x^{-1}\)。消去所有线性 \(y\)-项，得

\[
f_N(x)=1+Ng(N)\left\lfloor\frac yN\right\rfloor
-\sum_{k\le N}\mu(k)\left\lfloor\frac yk\right\rfloor
\qquad(0<x\le N^{-1}).
\tag{9}
\]

在 \(I_m\) 上可将 \(y\) 换成 \(m\)。再用

\[
\sum_{k\le m}\mu(k)\left\lfloor\frac mk\right\rfloor=1
\tag{10}
\]

得到 (5) 的第二式；交换有限和得到第三式。最后

\[
|I_m|=\frac1{m(m+1)}
\tag{11}
\]

给出 (6)，变量 \(t=Nx\) 给出 (8)。\(\square\)

### 2.1 第一 dyadic shell

若 \(N\le m<2N\)，则 (5) 退化为

\[
\boxed{
h_N(m)=Ng(N)+M(m)-M(N)=M(m)+N\gamma(N).
}
\tag{12}
\]

故

\[
\boxed{
\int_{1/(2N)}^{1/N}|f_N(x)|^2\,dx
=\sum_{m=N}^{2N-1}
\frac{|M(m)+N\gamma(N)|^2}{m(m+1)}.
}
\tag{13}
\]

## 3. 临界零点强制首壳非消失

对 \(c\in\mathbb C\) 定义中心化壳能量

\[
\mathcal E_N(c)
:=\sum_{m=N}^{2N-1}\frac{|M(m)+c|^2}{m(m+1)}.
\tag{14}
\]

**定理 2（center-free dyadic obstruction）。** 存在常数
\(\delta>0\) 及无穷整数序列 \(N_j\to\infty\)，使

\[
\boxed{
\inf_{c\in\mathbb C}\mathcal E_{N_j}(c)\ge\delta.
}
\tag{15}
\]

等价地，

\[
\boxed{
\limsup_{N\to\infty}\inf_{c\in\mathbb C}\mathcal E_N(c)>0.
}
\tag{16}
\]

此结论无条件；只使用已知存在的临界线零点。

**证明。** 固定一个

\[
\rho=\frac12+i\tau,
\qquad \zeta(\rho)=0.
\tag{17}
\]

取实值 \(\psi\in C_c^\infty(1,2)\)，使

\[
\int_1^2\psi(t)\,dt=0,
\qquad
\Psi(\rho):=\int_1^2\psi(t)t^\rho\,dt\ne0.
\tag{18}
\]

这样的 \(\psi\) 存在：可取窄支撑非负 \(\phi\)，令
\(\psi=\phi'\)，则

\[
\Psi(\rho)=-\rho\int_1^2\phi(t)t^{\rho-1}\,dt\ne0
\tag{19}
\]

只要支撑足够窄。

令

\[
L(X)=\int_1^2M(Xt)\psi(t)\,dt.
\tag{20}
\]

对 \(\Re s>1\)，Fubini 与

\[
\int_1^\infty M(u)u^{-s-1}\,du=\frac1{s\zeta(s)}
\tag{21}
\]

给出

\[
\int_1^\infty L(X)X^{-s-1}\,dX
=\frac{\Psi(s)}{s\zeta(s)}-H(s),
\tag{22}
\]

其中

\[
H(s)=\int_1^2\psi(t)t^s
\int_1^tM(u)u^{-s-1}\,du\,dt
\tag{23}
\]

为整函数。故 (22) 的右侧在 \(s=\rho\) 有非可去极点。若假设
\(L(X)=o(X^{1/2})\)，则 (22) 的左侧在 \(\Re s>1/2\) 绝对收敛；它与右侧在
去掉离散 \(\zeta\)-零点后的连通域由解析延拓相等。

于是对 \(\varepsilon\downarrow0\)，分割积分于固定大
\(A\) 后有 Abel 边界估计

\[
\varepsilon
\int_1^\infty L(X)X^{-\rho-\varepsilon-1}\,dX
\longrightarrow0.
\tag{24}
\]

但 (22) 在 \(\rho\) 的任意正阶极点使 (24) 的左侧趋于非零常数或无界，矛盾。故

\[
L(X)\ne o(X^{1/2}).
\tag{25}
\]

将 \(X\) 换成最近整数只改变 \(L(X)\) 一个 \(O_\psi(1)\) 量，因为
\(|M(Xt)-M(Nt)|=O(1)\) 对 \(1\le t\le2\) 一致成立。因此存在
\(\varepsilon_0>0\) 及整数 \(N_j\to\infty\)，使

\[
|L(N_j)|\ge\varepsilon_0\sqrt{N_j}.
\tag{26}
\]

由 \(\int\psi=0\)，对任意 \(c\in\mathbb C\)，

\[
L(N)=\int_1^2(M(Nt)+c)\psi(t)\,dt.
\tag{27}
\]

Cauchy--Schwarz 给出

\[
|L(N)|^2
\le
\frac{\|\psi\|_2^2}{N}
\sum_{m=N}^{2N-1}|M(m)+c|^2.
\tag{28}
\]

又因 \(m(m+1)<4N^2\)，

\[
\mathcal E_N(c)
\ge\frac1{4N^2}
\sum_{m=N}^{2N-1}|M(m)+c|^2
\ge\frac{|L(N)|^2}{4N\|\psi\|_2^2}.
\tag{29}
\]

代入 (26)，得到 (15)，其中

\[
\delta=\frac{\varepsilon_0^2}{4\|\psi\|_2^2}>0.
\tag{30}
\]

证毕。\(\square\)

**推论 3（Báez--Duarte 失败已局域在第一壳）。** 取
\(c=N\gamma(N)\)，由 (13) 与定理 2，

\[
\boxed{
\limsup_{N\to\infty}
\int_{1/(2N)}^{1/N}|\chi(x)+B_N(x)|^2\,dx>0.
}
\tag{31}
\]

因此 \(B_N\not\to-\chi\) 的障碍不需要聚集全部
\((0,N^{-1})\)：第一个 dyadic shell 已足够。

## 4. 首个 dual 窗只剩一个标量

Báez--Duarte 的 dilation-invariant unitary \(\mathcal U\) 满足

\[
\mathcal UK_a=K_a\mathcal U,
\qquad
\mathcal U\rho_1(x)=\frac{\rho(x)}x,
\qquad
\mathcal U\chi(x)=S(x):=\frac{\sin(2\pi x)}{\pi x}.
\tag{32}
\]

由 (3)，

\[
\mathcal UB_N(x)=-N\gamma(N)
\qquad(0<x<N^{-1}).
\tag{33}
\]

所以 residual 的首个 dual 窗精确为

\[
\boxed{
\mathcal Uf_N(x)=S(x)-N\gamma(N)
\qquad(0<x<N^{-1}).
}
\tag{34}
\]

缩放后

\[
(D_N\mathcal Uf_N)(t)
=N^{-1/2}
\left[
S(t/N)-N\gamma(N)
\right],
\qquad0<t<1.
\tag{35}
\]

故该窗的全部信息是已知 \(S\) 与单个数 \(\gamma(N)\)：

\[
\mathcal J_N
:=\int_0^{1/N}|\mathcal Uf_N(x)|^2\,dx
=\frac1N\int_0^1|S(t/N)-N\gamma(N)|^2\,dt.
\tag{36}
\]

与此相反，原始第一壳 (13) 包含完整向量

\[
\bigl(M(N),M(N+1),\ldots,M(2N-1)\bigr)
\pmod{\mathbb C\mathbf1}.
\tag{37}
\]

因此任何

\[
\mathcal E_N(N\gamma(N))\le C\mathcal J_N
\quad\text{或}\quad
\|f_N\|_2^2\le C\mathcal J_N
\tag{38}
\]

都不是 unitarity、dilation commutation 或 support causality 的推论，而是新的
Mertens 算术不等式。本文既未证明也未否定 (38)。使用完整 \(\mathcal U\) 则只有恒等式
\(\|\mathcal Uf_N\|_2=\|f_N\|_2\)，不构成新控制。

## 5. 路线裁决

note 062 的泛化目标 (31) 需要收紧。单个 compact dual/Hardy channel 不应再作为未展开的
“可观测性”黑箱；正确对象是显式壳族

\[
\boxed{
\mathcal E_{N,q}
:=\sum_{m=qN}^{(q+1)N-1}
\frac{|h_N(m)|^2}{m(m+1)},
\qquad
\|f_N\|_2^2=\sum_{q\ge1}\mathcal E_{N,q}.
}
\tag{39}
\]

对精确插值 \(B_N\)，定理 2 已给出

\[
\limsup_N\mathcal E_{N,1}>0.
\tag{40}
\]

故它不能成为 RH 的收敛逼近。下一最薄问题应改为：对历史上的**边界 taper/regularized
Möbius 系数**，先推导 (5)--(13) 的对应壳公式，再判定 local Weil prime-shift 正性是否
控制全部 \(\sum_q\mathcal E_{N,q}\)；不能继续只观察 \(\gamma(N)\)。

## 6. 证据与新判断边界

文献直接支持：

- \(B_N\)、\(\gamma(N)\)、\(\mathcal U\) 的 (32)--(33) 以及 \(L^2\) 不收敛：
  Luis Báez-Duarte, *New versions of the Nyman--Beurling criterion for the Riemann
  hypothesis*, IJMMS 31 (2002), 387--406,
  [DOI](https://doi.org/10.1155/S0161171202013248)。
- dilation-invariant unitary 的一般构造：Báez-Duarte,
  *A Class of Invariant Unitary Operators*, Adv. Math. 144 (1999), 1--12,
  [DOI](https://doi.org/10.1006/aima.1998.1801)。
- co-Poisson 的 Fourier/Mellin/support 交换框架：Jean-François Burnol,
  *Entrelacement de co-Poisson*, Ann. Inst. Fourier 57 (2007), 525--602,
  [DOI](https://doi.org/10.5802/aif.2268)；
  [本地 arXiv 全文](<[unbundled local reference]>)。

本 note 新增的是定理 1 的完整壳分解、定理 2 的中心无关 dyadic Mertens 障碍、推论 3 的
首壳局域化，以及 (34)--(38) 对首个 dual 窗信息量的严格识别。针对检索日所做的
Mertens dyadic-variance、\(B_N\) local-shell 与 Nyman natural-approximation 定向检索未发现
相同的 (15) 或 (31) 陈述；这只界定本次检索覆盖，不作绝对首创声明。未证明 RH，未证明 (38)。
