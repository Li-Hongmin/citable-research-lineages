> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 增长偏移的相关项给平方根指数加税

日期：2026-08-16。

沿用 note 313。对 \(q\ge0\) 及 \(X=2U+q\)，记
\[
I_{U,q}=\{U+1,\ldots,2U+q-1\},\qquad
S_{U,q}=\sum_{n\in I_{U,q}}\lambda(n),
\]
并设
\[
C_{U,q}(d)=
\sum_{\substack{a,a+d\in I_{U,q}}}
\lambda(a)\lambda(a+d).
\]
note 313 的恒等式为
\[
S_{U,q}^2
=2B_U(2U+q)+N_{U,q}
 +2\sum_{d=1}^{q}C_{U,q}(d).
\tag{1}
\]

## 用已有 averaged-Chowla 控制扣除项

令 \(1\le d\le q\le U\)，并取固定端点 \(Y_+=2U-1\)、\(Y_-=U\)。因为
\[
C_{U,q}(d)
=\sum_{a\le Y_+}\lambda(a)\lambda(a+d)
 -\sum_{a\le Y_-}\lambda(a)\lambda(a+d)
 +O(q-d),
\]
有
\[
\sum_{d\le q}|C_{U,q}(d)|
\le
\sum_{d\le q}\left|\sum_{a\le Y_+}\lambda(a)\lambda(a+d)\right|
 +\sum_{d\le q}\left|\sum_{a\le Y_-}\lambda(a)\lambda(a+d)\right|
 +O(q^2).
\tag{2}
\]
应用 notes 307--308 所用的 Matomäki--Radziwiłł--Tao averaged-Chowla 输入，定义
\[
\rho_U(q)=
\frac{\log\log(3q)}{\log(3q)}
 +\frac1{\log^{1/3000}(3U)},
\]
则在 \(10\le q\le U\) 时
\[
\boxed{
\sum_{d\le q}|C_{U,q}(d)|
\ll Uq\,\rho_U(q)+q^2.
}
\tag{3}
\]
对 \(q<10\) 则有平凡界 \(O(Uq)\)。这里没有把 averaged-Chowla 外推到宏观以外；(3) 只是两个固定端点的直接应用。

## 对 \(B_U\) 估计的定量后果

若某个方法给出
\[
|B_U(2U+q)|\ll_\varepsilon U^{1+\varepsilon},
\tag{4}
\]
则由 (1)--(3)
\[
|S_{U,q}|^2
\ll_\varepsilon
U^{1+\varepsilon}+Uq\,\rho_U(q)+q^2.
\tag{5}
\]
特别地，若 \(q\le U^\theta\)（固定 \(0\le\theta\le1\)），则
\[
|S_{U,q}|
\ll_{\varepsilon,\theta}
U^{(1+\max\{\varepsilon,\theta\})/2+o(1)}.
\tag{6}
\]
因此：

* \(q\,\rho_U(q)\le U^\varepsilon\) 时，仍可得到 RH 等价门所需的平方根级区间和；
* \(q=U^\theta\) 时，现有平均相关输入最多把指数推进到
  \((1+\theta)/2+o(1)\)，而不是 \(1/2\)；
* 宏观 \(q\asymp U\) 时，(5) 退化为 \(S_{U,q}\ll U^{1+o(1)}\)，没有平方根收益。

所以“让 \(q\) 增长以避开 note 313 的固定偏移 RH 门”并非免费：必须同时证明比 averaged-Chowla 更强的跨移位 signed cancellation，使
\[
\sum_{d\le q}C_{U,q}(d)=U^{1+o(1)}
\]
而不是只得到其绝对值的 \(Uq\rho_U(q)\) 级界。这个跨尺度相关门是当前长移位路线的精确剩余对象。

## \(q\)-方向的精确差分

记
\[
\mathcal S_U^\circ=\sum_{U<a<2U}\lambda(a),
\qquad
\mathcal C_U(q)=\sum_{U<a<2U}\lambda(a)\lambda(a+q).
\]
直接比较定义中的上下端点，对每个 \(q\ge1\) 有
\[
\boxed{
B_U(2U+q)-B_U(2U+q-1)
=\lambda(2U+q-1)\mathcal S_U^\circ-\mathcal C_U(q).
}
\tag{7}
\]
若将 (7) 乘以 \(\lambda(2U+q-1)\) 并对 \(1\le q\le Q\) 求和，则左侧是带端点符号的 \(B\)-差分，而右侧为
\[
Q\,\mathcal S_U^\circ
-\sum_{q\le Q}\sum_{U<a<2U}
\lambda(a)\lambda(a+q)\lambda(2U+q-1).
\tag{8}
\]
因此，试图利用 \(q\)-望远镜消除固定偏移 RH 门，会把问题提升为三点 signed correlation；现有两点 averaged-Chowla 输入不能直接控制 (8)。式 (7) 给出了跨尺度 arithmetic intertwiner 需要保留的最小端点结构。
