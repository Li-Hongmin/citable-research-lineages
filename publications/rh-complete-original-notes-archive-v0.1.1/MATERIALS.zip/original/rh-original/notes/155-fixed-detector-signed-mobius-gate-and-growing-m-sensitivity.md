> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定 detector 的 signed Möbius 门与 growing-\(m\) 灵敏度衰减

日期：2026-08-15。

依赖：[note 118](118-an-endpoint-flat-detector-gives-an-exact-positive-reciprocal-product-rh-gate.md)、
[note 135](135-the-squarefree-primorial-star-has-exact-centered-inertia.md)、
[note 138](138-the-fully-centered-reciprocal-kernel-has-soft-o-x-but-no-l2-square-root-gain.md)、
[note 151](151-the-detector-hierarchy-is-not-a-positive-mellin-convolution-semigroup.md)。

证据等级：固定 detector 的精确 Mellin 恒等式、显式不定主子式，以及统一层级的
Mellin 比值渐近。本文只标出 signed Möbius 接口的最小缺口，不声称 RH 已被证明。

## 1. 固定 detector 的平方根门恰等价于 RH

令 \(V\) 支持在 \((0,1)\)，

\[
U_V(x)=\sum_n\mu(n)V(n/x),\qquad
P_V(y)=\sum_{c\le y}V(c/y),
\]

并定义截断 reciprocal-product 二次型

\[
T_V(x)=\sum_{a,b\le\sqrt x}
\mu(a)\mu(b)P_V\!\left(\frac{x}{ab}\right).
\]

若 \(V(u)=O(u^2)\) 于 \(u=0\)，则截断卷积恒等式给出严格的

\[
\boxed{T_V(x)=-U_V(x)+O_V(1).}
\tag{1}
\]

另一方面，对 \(\Re s>1\)，Mellin--Fubini 给出

\[
\boxed{
\int_1^\infty U_V(x)x^{-s-1}\,dx
=\frac{K_V(s)}{\zeta(s)},\qquad
K_V(s)=\int_0^1V(u)u^{s-1}\,du.}
\tag{2}
\]

若 \(K_V\) 在 \(1/2<\Re s<1\) 无零，则

\[
\boxed{
\mathrm{RH}\iff
\forall\varepsilon>0,\quad
|T_V(x)|\ll_{V,\varepsilon}x^{1/2+\varepsilon}.}
\tag{3}
\]

同样可把点态门替换为每个 dyadic 壳上的 \(L^2\) 门。零点 \(\rho\) 在显式
Mellin 移位中贡献

\[
\operatorname*{Res}_{s=\rho}
\frac{K_V(s)x^s}{\zeta(s)}
=\frac{K_V(\rho)}{\zeta'(\rho)}x^\rho
\]

（重数 \(m\) 时为 \(x^\rho(\log x)^{m-1}\) 的相应主项）。因此
\(K_V(\rho)\ne0\) 使平方根界排除一切 \(\Re\rho>1/2\)；反向则由 RH
下的 Mertens 界和 Abel 求和得到。固定 detector 的 signed-dispersion
平方根估计不是比 RH 更弱的中间命题。

## 2. 中心化没有产生正 Gram

对最小 cubic detector，写

\[
P(y)=\frac1{6y}-\frac1{30y^3}+C_0(y),
\qquad
S_k(z)=\sum_{n\le z}n^k\mu(n),\quad z=\sqrt x.
\]

则完全中心化余项满足精确恒等式

\[
\boxed{
T^{(0)}(x)=-U_V(x)+2A_V(x)
-\frac{S_1(z)^2}{6x}+\frac{S_3(z)^2}{30x^3}.}
\tag{4}
\]

其中 \(A_V(x)=O(1)\)。首项 \(S_1(z)^2/(6x)\) 本身已经是 RH 强度：

\[
S_1(z)\ll z^{3/2+\varepsilon}
\iff
M(z):=\sum_{n\le z}\mu(n)\ll z^{1/2+\varepsilon},
\]

两方向分别由

\[
S_1(z)=zM(z)-\sum_{n<z}M(n),\qquad
M(z)=\frac{S_1(z)}z+\sum_{n<z}\frac{S_1(n)}{n(n+1)}.
\]

即使减去这一 rank-one，核仍不定。在 \(x=9k^2\)、\((a,b)=(3k,2k)\) 上，

\[
\boxed{
\begin{pmatrix}
-2/15&19/405\\
19/405&302/10935
\end{pmatrix}}
\tag{5}
\]

是 \(C_0(x/(ab))\) 的固定主子式，且
\[
\det(5)=-\frac{193}{32805}<0.
\]

更大的 squarefree primorial 主子式还有 \(m-2\) 个负方向
\((m\asymp\log x/\log\log x)\)。因此普通 PSD Gram、固定秩 Schur 补或逐项
绝对值不能提供平方根 signed cancellation。

对次数十五的正 detector，这个障碍甚至在实际 Möbius 向量上已出现于最小尺度。
直接计算
\[
P_{15}(1)=0,\qquad
P_{15}(2)=\frac{473}{16384},\qquad
P_{15}(4)=\frac{149005}{134217728}.
\]
在 \(x=4\)、指标 \(a,b\le2\) 上，\(\mu=(1,-1)\)，因此
\[
K_4=
\begin{pmatrix}
149005/134217728&473/16384\\
473/16384&0
\end{pmatrix},
\qquad
\det K_4=-\left(\frac{473}{16384}\right)^2<0,
\]
且
\[
\boxed{T_{V_{15}}(4)
=\mu^\mathsf{T}K_4\mu
=-\frac{7600627}{134217728}<0.}
\]
所以 \(P_{15}\) 的逐点非负性不能升级为 combined Möbius form 的非负性，
甚至不能在实际 Möbius 向量上给出符号结论。

## 3. growing-\(m\) detector 会抹掉零点响应

统一层级的 Mellin 变换为

\[
K_m(s)=
\frac{(3m+1)!(s-1)}
{C_m\displaystyle\prod_{j=1}^{m}(s+2j)
\displaystyle\prod_{k=2m+1}^{3m+3}(s+k)},
\qquad
C_m=(3m+4)\prod_{j=1}^{m-1}(3m+2-2j).
\]

记
\[
A_m=(3m+2)(3m+3)(3m+4)\frac{C_m}{C_{m+1}}.
\]
则有精确比值
\[
\boxed{
\frac{K_{m+1}(s)}{K_m(s)}
=A_m\frac{s+2m+1}
{(s+3m+4)(s+3m+5)(s+3m+6)}.}
\tag{6}
\]

将 \(m=2q\) 与 \(m=2q+1\) 分开，并使用
\[
C_{2q}=(6q+4)2^{3q-1}(3q)!,
\qquad
C_{2q+1}=\frac{(6q+7)(6q+4)!}{3\cdot2^{3q+2}(3q+2)!},
\]
得到对固定 \(s\) 的渐近
\[
\frac{K_{2q+1}(s)}{K_{2q}(s)}
=\frac{\sqrt{3\pi}}{6\sqrt q}\left(1+O_s(q^{-1})\right),
\quad
\frac{K_{2q+2}(s)}{K_{2q+1}(s)}
=\frac{4}{9\sqrt{3\pi q}}\left(1+O_s(q^{-1})\right),
\]
从而
\[
\boxed{
\frac{K_{2q+2}(s)}{K_{2q}(s)}
=\frac4{27q}\left(1+O_s(q^{-1})\right).}
\tag{7}
\]

所以 \(|K_{2q}(s)|\) 至多为
\[
C_s q^{B_s}\frac{(4/27)^q}{q!}
\]
型的快速衰减。若令 \(m=m(x)\to\infty\) 以便让 \(P_m\) 的二次型变小，
同一个因子 \(K_m(\rho)\) 也会迅速抹掉任意 off-critical 零点的
\(K_m(\rho)x^\rho\) 响应。要把 moving-\(m\) 门用于 RH，必须另给统一的
零点响应下界（或一个等强的 renormalized error bound）；当前没有这样的命题。

## 4. 最小未闭合接口

固定 detector 的最小新输入可以写成
\[
\left|\sum_{a,b\le\sqrt x}
\mu(a)\mu(b)P_V\!\left(\frac{x}{ab}\right)\right|
\ll_{V,\varepsilon}x^{1/2+\varepsilon},
\]
但由 (1)--(3) 它本身就是 RH。若希望 Weil/Gram/Schur 路线成为独立证明，
必须构造一个保留 Möbius 符号的 arithmetic intertwiner，把 centered reciprocal
核转成有界正算子作用于差分后的实际 Möbius 向量；仅有 entrywise positivity、
有限秩 Schur 消元或连续 Gram 正性均不足。

本文的结论是路线边界，不是 RH 证明。
