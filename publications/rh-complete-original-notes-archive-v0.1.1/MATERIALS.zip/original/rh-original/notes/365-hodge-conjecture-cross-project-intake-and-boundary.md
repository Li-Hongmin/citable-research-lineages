> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Hodge-Conjecture 裁决文本：跨项目吸收边界

日期：2026-08-17。

## 来源

本轮附带文本来自：

`[unbundled local reference]`

文本自述其依据为 `Li-Hongmin/Hodge-Conjecture` 的 draft PR #4，head
`fbc6361d1bc418befb40aea1d63b3dae117b7f85`，讨论对象是
`(X_{33}^4)`、fixed-theta block、theta structures 与几何 T4--T8 门。

## 已吸收的可迁移研究纪律

1. 先冻结一个可复核的真实输入，再判定最高信息增益的单一未决门；不以继续枚举窄候选替代主问题。
2. 巨型线性映射应保存为结构化 kernel、factorization、restriction 或 exact minor 证书，而不是生成 dense matrix。
3. 必须把 theorem、no-go、scope gate 和待复现实验分层；有限域、数值或工程性候选不能直接晋级为定理。
4. 下游结论应在上游 kernel/非零性真正成立后再启动，不能把“存在入口”写成“完成证明”。

这些原则与本 RH 项目的工作流一致，但只是方法论输入，不是 RH 数学证据。

## 明确不迁移的内容

Hodge 项目的候选数值、theta block、T4/T5/T6 状态、PR head 与仓库内部判断，均未在本 RH 工作区独立读取其源仓库、重建定义或核验证明。因此不写入 RH 的 theorem universe，也不改变当前 RH 判定。特别是，它们不能替代本项目仍未闭合的 Möbius reciprocal-product signed energy / arithmetic intertwiner。

## 当前项目裁决

本次“吸收”完成的是来源登记与跨项目边界确认：保留上述四条可迁移的研究纪律；Hodge 的具体数学主张留在
`[unbundled local reference]`
及其对应 Drive 镜像中。RH 主线仍以本地可复核的 Mellin、periodization 与 Möbius signed-cancellation 结果为准。
