> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Dirichlet 预条件器对 periodization 正性与 ζ 信号的精确权衡

本 note 把普通正 detector 与 Möbius-preconditioned detector 放进同一个
精确恒等式中。结论是：预条件器只是在 periodization 系数与 Mellin
ζ-幂次之间搬运因子；它不能同时消除 signed cancellation 并保留原有
的零点信号。

## 一般构造

令 \(\phi\) 为 \((0,1)\) 上的可积函数，并令 \(b=(b_n)_{n\ge1}\)
为一个算术序列，使
\(B(s)=\sum_{n\ge1}b_n n^{-s}\) 在某个右半平面绝对收敛。定义
\[
V_b(u)=\sum_{n\ge1}b_n\phi(nu),\qquad 0<u<1.
\]
记 \(\mathbf 1(n)=1\)，以及 Dirichlet 卷积
\[
c=\mathbf 1*b.
\]
则有限重排给出
\[
\begin{aligned}
P_b(y)&:=\sum_{r\le y}V_b(r/y)\\
&=\sum_{k\le y}c_k\phi(k/y).
\end{aligned}
\tag{1}
\]
因此当 \(\phi\ge0\) 且 \(c_k\ge0\) 时，periodization 逐点非负。

## Reciprocal-product 二次和（full 与 cutoff 必须区分）

先定义去掉 individual cutoff 的 full 对象
\[
T_b^{\mathrm{full}}(x)=\sum_{ab<x}\mu(a)\mu(b)P_b(x/(ab)).
\]
再次有限重排，令 \(n=abk\)，得到
\[
T_b^{\mathrm{full}}(x)=\sum_{n<x}(\mu*\mu*c)(n)\phi(n/x),
\tag{2}
\]
其中端点可由 \(\phi(1)=0\) 吸收。由于
\[
\sum_n c_n n^{-s}=\zeta(s)B(s),
\]
系数 \(\mu*\mu*c\) 的 Dirichlet 级数为
\[
\frac1{\zeta(s)^2}\,\zeta(s)B(s)=\frac{B(s)}{\zeta(s)}.
\]
若 \(\Phi(s)=\int_0^1\phi(u)u^{s-1}\,du\)，则在绝对收敛半平面
\[
\int_1^\infty T_b^{\mathrm{full}}(x)x^{-s-1}\,dx
 =\Phi(s)\frac{B(s)}{\zeta(s)}.
\tag{3}
\]
这是统一的 full Mellin identity。

原始对象 \(T_b^{\mathrm{cut}}(x)\) 将 \(a,b\) 各自限制为
\(\le\sqrt x\)，与 full 对象相差 note 370 的 incomplete-lcm boundary；
因此下面三种 ζ-幂次只描述 full 和的精确信号，不能直接替代原始 cutoff 门。

## 三个精确端点

取同一个非负 \(\phi\)，例如 \(\phi(u)=u(1-u)\mathbf1_{(0,1)}(u)\)，有：

1. **不预条件：** \(b=\delta_1\)，所以 \(B=1\)、\(c=\mathbf1\)。
   此时
   \[
   P_b(y)=\sum_{k\le y}\phi(k/y)\ge0,
   \qquad \mathcal M[T_b^{\mathrm{full}}](s)=\Phi(s)/\zeta(s).
   \]
   这是 full 和中保留单个 \(1/\zeta\) 零点通道的普通正 detector。

2. **Möbius 预条件：** \(b=\mu\)，所以 \(B=1/\zeta\)、\(c=\delta_1\)。
   此时
   \[
   P_b(y)=\phi(1/y)\ge0,
   \qquad \mathcal M[T_b^{\mathrm{full}}](s)=\Phi(s)/\zeta(s)^2.
   \]
   这正是 note 368 的 full \(\zeta^{-2}\) 门；它没有把 signed cancellation
   变成 PSD。

3. **全 1 预条件：** \(b=\mathbf1\)，所以 \(B=\zeta\)、
   \(c=\mathbf1*\mathbf1=d\)（约数函数）。此时
   \[
   P_b(y)=\sum_{k\le y}d(k)\phi(k/y)\ge0,
   \qquad \mathcal M[T_b^{\mathrm{full}}](s)=\Phi(s).
   \]
   full 和中的 ζ 零点信号被完全消掉；得到的正 detector 可以很容易估计，
   但不再能推出 RH。

这三个例子对 full 和均有非负 periodization，却分别携带 \(\zeta^{-1}\)、
\(\zeta^{-2}\) 和 \(\zeta^0\) 的 Mellin 信号。

## 结构性含义

若目标是从 full 和的平方根级界推出 RH，则 (3) 要求 \(B(s)\) 在
临界带内不能抵消 \(1/\zeta(s)\) 的极点；因此 \(B=\zeta\) 这类最容易
保持正性的预条件器反而删除了所需的零点信号。另一方面，取
\(B=1/\zeta\) 虽保留正 periodization，却把算术对象升级成
\(\mu*\mu\)，其平方根界仍是 RH-strength。

这不是对所有可能非 Dirichlet 结构化 intertwiner 的 no-go；它只严格
关闭“仅靠乘法 Dirichlet 预条件器同时获得 PSD 与低于 RH 的 ζ 信号”
这一类 full-sum 路线。对原始 cutoff 问题，还必须先处理 note 370 的
incomplete-lcm boundary，再引入不由 (1) 的卷积系数描述的跨尺度
signed/reflection 算子。

上游：notes 239、368、212、241。
