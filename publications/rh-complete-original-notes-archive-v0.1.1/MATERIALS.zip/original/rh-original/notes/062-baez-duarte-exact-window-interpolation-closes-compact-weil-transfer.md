> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Báez--Duarte 精确窗口插值关闭 compact Weil 传递

日期与检索截止：2026-08-12。

依赖：[note 060](060-nyman-weil-paley-wiener-obstruction-and-log-semigroup-bridge.md)。

> **后续收紧。** [note 063](063-baez-duarte-tail-mertens-shell-localization.md) 将逃逸尾
> 精确分解成 Mertens 壳，证明第一 dyadic shell 的中心化能量已有正的 limsup；同时证明
> 首个 dilation-invariant dual 窗只保留 (gamma(N)) 一个标量。故下文 (31) 必须解释为
> 待展开的壳族问题，不能把“dual/Hardy channel”本身当作 coercivity。

## 1. 问题

note 060 留下候选：先截断 Nyman 向量到 \((-a,a)\)，再用 local Weil
prime-Schur 增益控制窗口残差，最后令 \(a\to\infty\)。

最便宜观测：窗口残差是否本来就能无条件精确消失。

```mermaid
flowchart LR
  A["Báez--Duarte B_N"] --> B["χ+B_N=0 on x>N⁻¹"]
  B --> C["log support: u≤-log N"]
  C --> D["W_a(χ+B_N)=0, a≤log N"]
  D --> E["所有 compact Weil Schur residual=0"]
  C --> F["global L² residual"]
  F --> G["不趋于 0"]
```

## 2. 历史自然逼近

令

\[
\rho_k(x)=\left\{\frac1{kx}\right\},
\qquad
\chi=\mathbf1_{(0,1]},
\qquad
g(N)=\sum_{k\le N}\frac{\mu(k)}k.
\tag{1}
\]

Báez--Duarte 定义

\[
\boxed{
B_N(x)=
\sum_{k\le N}\mu(k)\rho_k(x)
-Ng(N)\rho_N(x).
}
\tag{2}
\]

等价地，

\[
B_N=\sum_{k<N}\mu(k)\rho_k-Ng(N-1)\rho_N.
\tag{3}
\]

系数满足 Beurling 消失条件

\[
\sum_{k\le N}\frac{\mu(k)}k-g(N)=0.
\tag{4}
\]

## 3. 定理：每个有限窗口已被精确解完

**定理 1（精确窗口插值）。** 对每个整数 \(N\ge2\)，

\[
\boxed{
B_N(x)=-\chi(x)
\qquad\text{a.e. on }(N^{-1},\infty).
}
\tag{5}
\]

**证明。** 令 \(y=x^{-1}<N\)。由 \(\{y/k\}=y/k-\lfloor y/k\rfloor\)，

\[
\begin{aligned}
B_N(x)
&=y\sum_{k\le N}\frac{\mu(k)}k
-\sum_{k\le N}\mu(k)\left\lfloor\frac yk\right\rfloor
-yg(N)\\
&=-\sum_{k\le y}\mu(k)\left\lfloor\frac yk\right\rfloor.
\end{aligned}
\tag{6}
\]

而

\[
\sum_{k\le y}\mu(k)\left\lfloor\frac yk\right\rfloor
=\sum_{m\le y}\sum_{k\mid m}\mu(k)
=\mathbf1_{y\ge1}.
\tag{7}
\]

故 \(B_N=-1\) 于 \(N^{-1}<x\le1\)，且由 (4)，\(B_N=0\) 于 \(x>1\)。证毕。

令

\[
\eta_k=-\rho_k,
\qquad
c_{k,N}=\begin{cases}
\mu(k),&k<N,\\
-Ng(N-1),&k=N.
\end{cases}
\tag{8}
\]

则

\[
-B_N=\sum_{k\le N}c_{k,N}\eta_k.
\tag{9}
\]

取 note 060 的对数酉变换

\[
(Uf)(u)=e^{u/2}f(e^u),
\qquad
W_a=\mathbf1_{(-a,a)},
\tag{10}
\]

并记

\[
g_0=U\chi,
\qquad g_k=U\eta_k,
\qquad
r_N=g_0-\sum_{k\le N}c_{k,N}g_k=U(\chi+B_N).
\tag{11}
\]

由 (5)，

\[
\boxed{
\operatorname{supp}r_N\subset(-\infty,-\log N]\quad\text{a.e.}
}
\tag{12}
\]

从而

\[
\boxed{
W_ar_N=0
\qquad(0<a\le\log N).
}
\tag{13}
\]

特别地，

\[
\boxed{
W_ag_0=\sum_{k\le N}c_{k,N}W_ag_k
\qquad(a\le\log N).
}
\tag{14}
\]

例：\(N=2\)、\(a=\log2\) 时

\[
W_ag_0=W_ag_1-2W_ag_2.
\tag{15}
\]

### 3.1 匹配窗口唯一性

**定理 2（interpolation trap）。** 在匹配尺度 \(a=\log N\)，方程

\[
W_ag_0=\sum_{k\le N}d_kW_ag_k
\tag{15a}
\]

只有一个解，即 \(d_k=c_{k,N}\) 如 (8)。因此
\(\{W_ag_k:1\le k\le N\}\) 线性无关；普通 \(L^2\) 或任意正内积下的
零 residual 拟合都强制选出同一个 Báez--Duarte \(B_N\)。

**证明。** 回到 \(x=e^u\)。在窗口的 \(1<x<N\) 部分，\(\chi=0\) 且
\(\rho_k(x)=1/(kx)\)，故 (15a) 强制

\[
\sum_{k\le N}\frac{d_k}{k}=0.
\tag{15b}
\]

令 \(y=x^{-1}\)。在 \(1\le y<N\) 上，(15a) 等价于

\[
\sum_{k\le j}d_k\left\lfloor\frac jk\right\rfloor=1,
\qquad j=1,\ldots,N-1.
\tag{15c}
\]

记 \(h(m)=\sum_{k\mid m}d_k\)。则左侧为 \(\sum_{m\le j}h(m)\)，故

\[
h(1)=1,
\qquad h(m)=0\quad(2\le m<N).
\tag{15d}
\]

Möbius 反演给 \(d_k=\mu(k)\)（\(k<N\)）；(15b) 再给
\(d_N=-Ng(N-1)\)。齐次方程同理只有零解，故线性无关。\(\square\)

## 4. Compact Weil 盲区定理

**定理 3（compact-form blindness）。** 设 \(q_a\) 是定义在
\(H((-a,a))\) 上的任意二次型，尤其可取 local Weil 形式 \(Q_W^a\)。若
\(N\ge e^a\)，则存在显式 \(c\in\mathbb C^N\) 使

\[
q_a\!\left(
W_ag_0-\sum_{k\le N}c_kW_ag_k
\right)=0.
\tag{16}
\]

该 \(c\) 即 (8) 的 Möbius 系数。若 \(q_a\) 在相应 residual affine space 上非负，则其
下确界为零；若 \(q_a\) 在该有限空间上正定，则 Gram Schur residual 精确为零。

**证明。** 代入 (14)。\(\square\)

这一定理与 \(Q_W^a\) 的具体 Archimedean、prime、polar 结构无关。故

\[
\boxed{
\bigl[\forall a<\infty:\ W_ar_N\to0\bigr]
\centernot\Longrightarrow
\|r_N\|_2\to0
}
\tag{17}
\]

因此不能仅凭“逐窗口 Schur residual 已趋零”作极限交换；对这组历史自然逼近，窗口
residual 已代数恒零，而全局结论仍失败。这里关闭的是该 compact-transfer 机制，不是否定
Weil 判据可能存在的其他全局证明。

## 5. 全局反差不是技术尾项

Báez--Duarte 2002 的 Proposition 4.13 证明

\[
\boxed{
B_N\not\longrightarrow-\chi
\quad\text{in }L^2(0,\infty).
}
\tag{18}
\]

其证明使用一个与 dilation 通勤的酉算子 \(\mathcal U\)，并在 \((0,N^{-1})\)
上得到

\[
\mathcal U B_N=-N\gamma(N),
\qquad
\gamma(N)=\sum_{k<N}\frac{M(k)}{k(k+1)},
\tag{19}
\]

从而 L2 收敛将强迫

\[
N\gamma(N)^2\to0,
\tag{20}
\]

与临界线零点给出的已知障碍冲突。

结合 (13) 与 (18)：

\[
\boxed{
\forall a<\infty:\ W_ar_N=0\text{ eventually};
\qquad
\|r_N\|_2\not\to0.
}
\tag{21}
\]

因此 note 060 的 \(O(e^{-a})\ell^1\) 粗尾不是待优化的小误差；全部 RH 难度恰好被
推入逃向 \(-\infty\) 的因果尾。

## 6. 等价内积也不能传递单步 gain

设 \(A>0\)，\(mI\preceq A\preceq MI\)。目标 \(e\)、旧空间 \(V\)、新增方向
\(w\) 的普通与 \(A\)-Schur gain 记为 \(\Delta_2,\Delta_A\)。一般不存在

\[
\Delta_A\ge c(m,M)\Delta_2
\quad\text{或}\quad
\Delta_2\ge c(m,M)\Delta_A
\tag{22}
\]

的正统一常数。

取 \(V=0\)、\(e=(1,0)\)、\(w=(1,1)\) 及

\[
A=\begin{pmatrix}1&-1\\-1&2\end{pmatrix}>0.
\tag{23}
\]

则

\[
\Delta_2=\frac12,
\qquad
\Delta_A=\frac{|e^TAw|^2}{w^TAw}=0.
\tag{24}
\]

反向取 \(e=(1,0)\)、\(w=(0,1)\) 及

\[
A_\alpha=\begin{pmatrix}1&\alpha\\\alpha&1\end{pmatrix},
\qquad0<\alpha<1,
\tag{25}
\]

则

\[
\Delta_2=0,
\qquad
\Delta_A=\alpha^2.
\tag{26}
\]

只有累计距离保留范数等价：

\[
\boxed{
m\,d_2(e,V)^2
\le d_A(e,V)^2
\le M\,d_2(e,V)^2.
}
\tag{27}
\]

故逐 prime 的 individual Schur gain 还需要真实 residual/新增方向的夹角可观测性；谱隙本身不够。

## 7. 路线裁决

关闭：

\[
\boxed{
\text{finite centered windows}
\to\text{local Weil Schur gains}
\to\text{Nyman }L^2\text{ convergence}.
}
\tag{28}
\]

存活对象必须看见逃逸尾。令

\[
(D_Nf)(y)=N^{-1/2}f(y/N).
\tag{29}
\]

则 \(D_N\) 酉且

\[
\operatorname{supp}(D_NU^{-1}r_N)\subset(0,1],
\qquad
\|D_NU^{-1}r_N\|_2=\|r_N\|_2.
\tag{30}
\]

下一正确接口不是再加一个 compact Gram，而是给**缩放后的固定尾**建立双通道可观测性：

\[
\boxed{
\|r_N\|_2^2
\lesssim
\|\mathsf O_1D_NU^{-1}r_N\|_2^2
+\|\mathsf O_2D_NU^{-1}r_N\|_2^2,
}
\tag{31}
\]

其中至少一个 \(\mathsf O_j\) 必须是 Báez--Duarte 的 dilation-commuting dual channel
\(\mathcal U\) 或 Burnol 的 Hardy/causal projection；任意只依赖 \(W_a r_N\) 的观测均由 (13)
恒为零。

式 (31) 目前只是正确量词下的新目标，不是已证估计。

## 8. 证据边界

文献直接支持：

- \(B_N\) 的定义、其在 \((N^{-1},1]\) 上等于 \(-1\)，以及 Proposition 4.13 的
  L2 不收敛：Luis Báez-Duarte, *New versions of the Nyman--Beurling criterion for the
  Riemann hypothesis*, IJMMS 31 (2002), 387--406,
  [DOI](https://doi.org/10.1155/S0161171202013248)。
- 整数 dilation 的 RH 等价：Báez-Duarte,
  [arXiv:math/0202141](https://arxiv.org/abs/math/0202141)；[本地全文](<[unbundled local reference]>)。
- Nyman Gram 的现代显式分解：Werner Ehm,
  [arXiv:2405.06349](https://arxiv.org/abs/2405.06349)；[本地全文](<[unbundled local reference]>)。

本 note 新增的是：定理 2 的匹配窗口唯一性，以及把历史精确插值与
\(D(Q_W^a)=H((-a,a))\) 组合成定理 3，从而严格关闭 note 060 的 compact Weil
传递；式 (22)--(27) 给出该失败的独立有限维机制。未证明 RH，未证明 (31)。
