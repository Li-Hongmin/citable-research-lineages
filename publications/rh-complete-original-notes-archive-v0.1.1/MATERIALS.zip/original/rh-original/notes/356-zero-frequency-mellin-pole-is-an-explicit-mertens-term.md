> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A Mellin pole at zero is an explicit Mertens term

日期：2026-08-16。

## 结论

在当前 endpoint-flat detector 类中，试图让 Mellin multiplier 在 \(s=0\)
产生极点，不能提供独立的零频放大；该极点恰好等价于在 reciprocal
sum 中显式保留 \(M(x)\)。

## 精确分解

设 \(V\) 在 \(u=0\) 附近满足
\[
 V(u)=c+O(u^\alpha),\qquad \alpha>0.
\]
令 \(W(u)=V(u)-c\)。则
\[
 K_V(s):=\int_0^1V(u)u^{s-1}\,du
 =\frac{c}{s}+K_W(s),
\tag{1}
\]
其中 \(K_W\) 在 \(\operatorname{Re}s>-\alpha\) 内解析。另一方面，对每个
正整数 \(x\)，reciprocal Möbius sum 有完全代数的恒等式
\[
 U_V(x):=\sum_{n\le x}\mu(n)V(n/x)
 =c\,M(x)+U_W(x).
\tag{2}
\]
所以 \(K_V\) 的 \(s=0\) 极点并没有制造新的算术 cancellation；它只是把
Mertens 函数 \(M(x)\) 以系数 \(c\) 直接写进 detector。

若要求 \(V(0)=0\) 且 \(V(u)=O(u^\alpha)\)，则 \(K_V\) 在 \(s=0\) 正则，
相应的 log-frequency weight 在零频附近没有极点。所有当前 endpoint-flat
detector 都属于这一正则分支，不能靠 singular zero-frequency weighting
绕过 RH-equivalent 的平方根门。

## 对 detector 设计的含义

如果 \(c\ne0\)，任何对 \(U_V\) 的平方根级估计都必须同时控制 (2) 中的
\(cM(x)\)；若 \(U_W\) 只有经典零自由区量级，则它不会抵消 \(cM(x)\)，
而只留下原 RH-strength 问题。若 \(c=0\)，则回到 regular Mellin
multiplier 与现有 Lehmer 门。

因此“在 \(s=0\) 制造极点来增强零频”不是新的 RH 证明路线，而是
Mertens 目标的显式重写。更弱的非幂次端点奇性需要另行建立统一
Tauberian 估计，当前没有证据表明它能避免同一算术门。
