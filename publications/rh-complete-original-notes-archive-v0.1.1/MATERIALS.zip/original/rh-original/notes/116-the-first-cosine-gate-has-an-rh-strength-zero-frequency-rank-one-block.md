> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 第一余弦门含有 RH 强度的零频秩一块

日期：2026-08-14。

依赖：
[note 101](101-a-bv-mellin-detector-sees-exactly-uncancelled-zeta-multiplicity.md)、
[note 114](114-the-first-dirichlet-neumann-cosine-mode-alone-is-an-rh-criterion.md)。

证据等级：精确离散 Abel 恒等式、截断卷积恒等式及尖锐的一阶
Sobolev 边界。

note 114 证明第一 Dirichlet--Neumann 余弦模的平方根界与 RH 等价。
本文检查三条可能的软推进：正核平均、Vaughan/Heath--Brown 型卷积分解，
以及从均方到逐点的 Lipschitz 放大。三者的首个损失都可显式定位。

## 1. 余弦模是 Mertens 函数的正概率平均

令

\[
\theta_m=\frac{\pi}{2m+1},\qquad
w_m(n)=\cos\left((n-\tfrac12)\theta_m\right),
\tag{1}
\]

\[
\mathcal C_m=\sum_{n\le m}\mu(n)w_m(n),\qquad
M(r)=\sum_{n\le r}\mu(n).
\tag{2}
\]

离散 Abel 求和严格给出

\[
\boxed{\mathcal C_m=\sum_{r\le m}a_{m,r}M(r),}
\tag{3}
\]

其中

\[
a_{m,m}=\sin\theta_m,
\qquad
a_{m,r}=2\sin(r\theta_m)\sin(\theta_m/2)
\quad(1\le r<m).
\tag{4}
\]

因此

\[
a_{m,r}>0,\qquad
\sum_{r\le m}a_{m,r}=w_m(1)=\cos(\theta_m/2)=1+O(m^{-2}).
\tag{5}
\]

并且对每个固定 \(c>0\)，一致于 \(cm\le r\le m\)，

\[
a_{m,r}\asymp_c m^{-1}.
\tag{6}
\]

所以第一余弦模在 Abel 后不是变号振荡积分，而是 \(M(r)\) 的正平均。
Cauchy--Schwarz 只能给

\[
|\mathcal C_m|^2
\le\left(\sum_ra_{m,r}\right)
\left(\sum_ra_{m,r}|M(r)|^2\right).
\tag{7}
\]

要由此推出
\(|\mathcal C_m|\ll_\varepsilon m^{1/2+\varepsilon}\)，已经需要

\[
\sum_{r\asymp m}|M(r)|^2\ll_\varepsilon m^{2+2\varepsilon},
\tag{8}
\]

即 RH 强度的 dyadic Mertens 二次门。

这个损失对只使用路径约束与二次质量的论证是尖锐的。取

\[
M_*(r)=\min(r,A),\qquad 1\ll A=o(m).
\tag{9}
\]

则 \(|\Delta M_*|\le1\)，且

\[
\sum_{r\le m}|M_*(r)|^2\asymp mA^2,\qquad
\sum_{r\le m}a_{m,r}M_*(r)\asymp A.
\tag{10}
\]

故正性路线不能优于
\(\sqrt{m^{-1}\sum|M(r)|^2}\)。

## 2. 精确截断卷积恒等式

现在写连续尺度版本

\[
W(u)=\cos(\pi u/2)\mathbf 1_{(0,1]}(u),\qquad
U_W(x)=\sum_n\mu(n)W(n/x).
\tag{11}
\]

令 \(z=\sqrt x\)，

\[
\nu_z(n)=\mu(n)\mathbf 1_{n\le z},\qquad
r=\delta-\nu_z*1.
\tag{12}
\]

对 \(n\le z\)，有 \((\nu_z*1)(n)=(\mu*1)(n)=\delta(n)\)，故
\(r(n)=0\)。于是对 \(n\le x=z^2\)，每个因子分解 \(n=ab\) 至少有
一个因子不超过 \(z\)，从而

\[
(r*r)(n)=0.
\tag{13}
\]

将 (13) 与 \(\mu\) 卷积，并使用
\((\nu_z*1)*\mu=\nu_z\)，得到

\[
\boxed{
\mu(n)=2\nu_z(n)-(\nu_z*\nu_z*1)(n)
\qquad(n\le x).}
\tag{14}
\]

因此

\[
\boxed{
U_W(x)
=2\sum_{a\le z}\mu(a)W(a/x)
-\sum_{a,b\le z}\mu(a)\mu(b)
P_W\left(\frac{x}{ab}\right),}
\tag{15}
\]

其中

\[
P_W(y)=\sum_{c\le y}W(c/y).
\tag{16}
\]

第一项的绝对值至多 \(2\sqrt x\)。故目标平方根界精确归约为控制
(15) 的双线性项。

## 3. 零频秩一块

BV Euler 求和给出

\[
P_W(y)=y\int_0^1W(u)\,du+O(1)
=\frac{2}{\pi}y+O(1).
\tag{17}
\]

代入 (15)，主零频是

\[
\boxed{
T_0(x)=\frac{2x}{\pi}
\left(\sum_{a\le\sqrt x}\frac{\mu(a)}a\right)^2.}
\tag{18}
\]

若逐块估计要求 \(T_0(x)\ll_\varepsilon x^{1/2+\varepsilon}\)，则必须有

\[
\sum_{a\le z}\frac{\mu(a)}a
\ll_\varepsilon z^{-1/2+\varepsilon}.
\tag{19}
\]

(19) 与

\[
M(z)\ll_\varepsilon z^{1/2+\varepsilon}
\tag{20}
\]

等价。一个方向由 \(\sum_{n\ge1}\mu(n)/n=0\) 及尾部 Abel 求和得到；
反方向由

\[
M(z)=zA(z)-\sum_{n<z}A(n),\qquad
A(z)=\sum_{n\le z}\frac{\mu(n)}n,
\tag{21}
\]

得到。因此 (18) 本身已是 RH 强度。

若不逐块取绝对值，而保留 (17) 的误差与 (18) 的 signed cancellation，
则所需的联合 Type-II 估计正是 (15) 双线性项的平方根界。由 (15) 及
第一项的平凡平方根界，它与 \(U_W(x)\) 的平方根界等价；note 114 又证明
后者与 RH 等价。截断分解没有产生严格弱于 RH 的中间门。

## 4. 一阶均方放大的尖锐边界

在整数入口之间，

\[
U_W'(x)=\frac{\pi}{2x^2}
\sum_{n\le x}n\mu(n)\sin\left(\frac{\pi n}{2x}\right),
\qquad
\|U_W'\|_\infty\ll1.
\tag{22}
\]

因此一维局部 Gagliardo--Nirenberg 只给

\[
\boxed{
|U_W(x)|^3
\ll_W\int_{X/2}^{4X}|U_W(t)|^2\,dt+O_W(1)
\qquad(X\le x\le2X).}
\tag{23}
\]

若右边只有 \(O(X^{2+\eta})\)，则

\[
|U_W(x)|\ll X^{2/3+\eta/3},
\tag{24}
\]

而不是平方根界。高度 \(H\)、斜率 \(1\)、宽度 \(H\) 的三角脉冲满足
\(\|f\|_2^2\asymp H^3\)，故 (23) 在 Lipschitz 类中尖锐。取
\(H=X^{2/3}\) 即同时有 \(\|f\|_2^2\asymp X^2\) 与
\(\|f\|_\infty\asymp X^{2/3}\)。

余弦 cutoff 在 \(u=1\) 只有零阶匹配；新项进入时一阶导数发生跳跃。
因此不能把它当作 \(C_c^\infty\) detector，借任意高阶 Sobolev 插值无损
恢复逐点平方根界。

## 5. 结论

三条软路线的最小缺口分别是：

\[
\begin{array}{c|c}
\text{路线}&\text{首个承重门}\\ \hline
\text{正 Abel 平均}&
\sum_{r\asymp m}|M(r)|^2\ll m^{2+\varepsilon}\\
\text{Vaughan/HB 分块}&
x\left|\sum_{n\le\sqrt x}\mu(n)/n\right|^2\ll x^{1/2+\varepsilon}\\
\text{一阶均方放大}&
X^{2+\eta}\mapsto X^{2/3+\eta/3}
\end{array}
\tag{25}
\]

所以第一余弦模的下一项真实进展必须直接控制随 \(m\) 移动的 signed
Möbius covariance，或提供一个能消去 (18) 而不把同等难度搬入其余块的
新算术结构。正性、逐项绝对值、标准 Type-I/II 分块和一阶平滑本身均不能
越过现有 RH 强度门。这是路线关闭，不是 RH 的证明。
