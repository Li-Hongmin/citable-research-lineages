> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# detector 层级递推不是正 Mellin 卷积半群

日期：2026-08-15。

依赖：[note 150](150-universal-euler-operator-form-of-the-positive-detector-hierarchy.md)。

## 1. 相邻层的精确商

记 (K_m) 为 note 150 的规范化 Mellin 变换，

\[
K_m(s)=\frac{(3m+1)!(s-1)}{C_mD_m(s)},
\]

其中

\[
D_m(s)=\prod_{j=1}^{m}(s+2j)
\prod_{k=2m+1}^{3m+3}(s+k).
\]

直接约去公共因子得到

\[
\boxed{
\frac{K_{m+1}(s)}{K_m(s)}
=A_m\frac{s+2m+1}{(s+3m+4)(s+3m+5)(s+3m+6)},
}
\tag{1}
\]

其中

\[
A_m=(3m+2)(3m+3)(3m+4)C_m/C_{m+1}>0.
\]

## 2. 逆 Mellin 核必然变号

令 (B=3m+4)。由部分分式分解，(1) 的逆 Mellin 密度（忽略正的
常数 (A_m)）为

\[
w_m(u)=u^{B}
\left[-\frac{m+3}{2}+(m+4)u-\frac{m+5}{2}u^2\right]
\mathbf 1_{(0,1)}(u).
\tag{2}
\]

括号中的多项式精确因式分解为

\[
\frac{1-u}{2}\bigl((m+5)u-(m+3)\bigr).
\tag{3}
\]

因此它在

\[
u_0=\frac{m+3}{m+5}
\]

处变号：在 (0<u<u_0) 为负，在 (u_0<u<1) 为正。

## 3. 含义

所以 (V_{m+1}) 不能由 (V_m) 与一个非负 Mellin 卷积核生成；相邻层
之间的递推本身已经携带 signed cancellation。全 (m) 正性若成立，必须来自
每一层 reciprocal-product periodization 的新不等式，而不能由一个简单的正卷积
归纳得到。这也与 note 148 的不定 (2\times2) block 一致：层级的 entrywise
正性并未提升为正算子结构。

该计算不否定全 (m) 正性；它只排除了最薄的正 semigroup 证明路线。
