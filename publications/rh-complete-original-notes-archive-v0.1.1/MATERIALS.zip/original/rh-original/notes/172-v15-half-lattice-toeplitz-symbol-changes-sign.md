> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# V15 单侧半格边界的 Toeplitz 符号严格变号

日期：2026-08-15。

note 171 的边界项 \(G_X\) 不能一般地当作正 Toeplitz Gram。下面对当前
最小四-residue 正 detector \(V_{15}\) 给出一个严格的连续符号证书。

## 1. Mellin 到 log-Fourier

令
\[
g_{15}(t)=\frac12P_{15}(e^{|t|}),\qquad t\in\mathbb R,
\]
其中 \(P_{15}(y)=\sum_{c\le y}V_{15}(c/y)\)，并令
\[
K_{15}(s)=
\frac{415134720(s-1)}{(s+2)(s+4)(s+6)(s+8)(s+9)(s+10)(s+11)
(s+12)(s+13)(s+14)(s+15)}.
\]
端点平坦性给出 \(P_{15}(y)=O(y^{-2})\)，因此 \(g_{15}\in L^1(\mathbb R)\)。
在 \(\Re s>1\) 先作 Mellin--Fubini，再解析延拓到 \(s=i\xi\)，得到
\[
\widehat g_{15}(\xi)
=\int_{0}^{\infty}P_{15}(e^t)\cos(\xi t)\,dt
=\Re\!\left[\zeta(i\xi)K_{15}(i\xi)\right].
\tag{1}
\]

这只是连续 log-Fourier 符号；它不是把离散 divisor 矩阵自动 PSD 化的假设。

## 2. 两个严格取值

在 \(\xi=0\) 处，直接使用 \(\zeta(0)=-1/2\) 与 \(K_{15}(0)=-1/30\)，有
\[
\widehat g_{15}(0)=\frac1{60}>0.
\tag{2}
\]

在 \(\xi=2\) 处，192-bit Arb 计算（脚本见下）给出
\[
\Re\!\left[\zeta(2i)K_{15}(2i)\right]
=[-5.0808400690610\times10^{-4}\pm2.30\times10^{-17}],
\]
故其实部严格为负：
\[
\widehat g_{15}(2)<0.
\tag{3}
\]
结合 (2)，连续 Toeplitz 符号严格变号，\(g_{15}\) 不是正定 log-kernel。

## 3. 边界含义

因此 note 171 中的 \(G_X\) 不能通过 Bochner 正性直接控制；即使
\(P_{15}(y)\ge0\) 对所有 \(y\ge1\)，其对称 log-kernel 仍含负频带。要获得
全尺度 signed Schur 补，必须保留 prime/reflection 的非对角 cancellation，
不能把 \(G_X\) 换成普通 PSD Gram 或逐频取绝对值。

本文只排除一个正化捷径，不否定 RH，也不声称离散有限格必然拥有同样的
负特征向量。

