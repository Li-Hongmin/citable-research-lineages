> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一个公开 RH 审计稿对平方根桥的精确裁决

日期：2026-08-16。

## 来源与范围

来源是 Deep Bhattacharjee 的 ResearchGate 预印本：

<https://www.researchgate.net/publication/404380360_The_Final_and_Exhaustive_Proof_of_the_Riemann_Hypothesis_Unconditionally_from_First_Principles>

该文不是已完成的 RH 证明；它把需要的定量桥显式命名为 QSLB，并在正文中把其后
的推论与该桥的条件性分开。本文只吸收其中可直接核验的恒等式和逻辑关系，不把作者
的标题或摘要当成数学证据。

## QSLB 的精确定义

对 \(1\le H<X\)、\(H\le h<2H\)、\(|\theta_h|\le1\) 以及
\(1\le y_h\le X-h\)，定义
\[
 B(X,H;\theta,y)
 =
 \sum_{H\le h<2H}\theta_h
 \sum_{n\le y_h}\lambda(n)\lambda(n+h).
\]
文中提出的 Quantitative Shifted-Liouville Bilinear Theorem（QSLB）是
\[
 |B(X,H;\theta,y)|\ll_\varepsilon X^{1+\varepsilon}
\]
在上述参数上统一成立。

其强度来自三个同时存在的量词：移位 \(h\) 在完整 dyadic 块中平均，
\(\theta_h\) 可以任意取模不超过一的符号，且每个移位允许独立选择最大部分和
位置 \(y_h\)。因此它不是固定移位的定性 Chowla，也不是普通平均相关估计。

## 可核验的闭合链

文中逐步给出
\[
\mathrm{QSLB}
\Longrightarrow \mathrm{DQAU}
\Longrightarrow \mathrm{QAU}
\Longrightarrow \mathrm{AC}
\Longrightarrow
 \sum_{n\le X}\lambda(n)\ll_\varepsilon X^{1/2+\varepsilon}
\Longrightarrow \mathrm{RH}.
\]
最后一步是标准的 Littlewood--Denjoy 判据。换言之，若 QSLB 真能无条件证明，
它确实会关闭 RH；但 QSLB 本身正是未证明的承重输入。

文中还明确指出：即使完整的定性固定移位 Chowla 成立，也不能交换
\(X\to\infty\) 与随 \(X\) 增长的移位求和，更不能自动得到 QAU。这个量词差异与
本项目 notes 220、212、199 中的 variable-shift energy gap 完全一致。

## 绝对值路线的结构性失败

文中对 all-singleton partition 的 absolute partition-energy 方案给出了直接反例：
若对所有 \(1\le h_1<\cdots<h_{2m-1}\le X/2\) 取部分和上确界并逐项取绝对值，
则每个移位元组的 \(y=1\) 项至少为 \(1\)，所以总和至少为
\[
 \binom{\lfloor X/2\rfloor}{2m-1}\asymp_m X^{2m-1}.
\]
这不可能满足目标的 \(X^{m+\varepsilon}\) 级估计（\(m\ge2\) 且
\(\varepsilon<m-1\)）。因此必须保留跨移位的 signed cancellation；增加绝对值、
Cauchy 或单个 partition 的局部正性不能修复该路线。

## 对本项目的裁决

这份审计稿没有提供 RH 证明，但提供了一个比“固定移位 Chowla”更精确的最小
承重命题：若要沿 shifted-correlation 路线推进，必须证明 QSLB 或强度等价的
跨 dyadic 移位、任意符号、最大部分和的 \(X^{1+\varepsilon}\) 界。现有
MRT 型 averaged Chowla、定性固定移位 Chowla、Bernstein/Jackson 正能量估计均
不足以推出该桥。

因此本项目仍不能把任何公开的“RH proof”标题、Chowla 摘要或有限谱计算升级为
RH 已证；当前最小未决命题已由 QSLB/正能量门明确化。

## 与更弱的 Liouville-collar 门对照

另一篇公开预印本 [Maximal Large Sieve and Coefficient Uniform Failure for Liouville Correlations](https://www.preprints.org/manuscript/202606.1350)
把同一缺口写成一个更贴近原始平方恒等式的条件：令

\[
 C_h(Y)=\sum_{n\le Y}\lambda(n)\lambda(n+h),\qquad
 C_h^*(X)=\sup_{Y\le X-h}|C_h(Y)|.
\]

其 Open Problem 6.1 要求，对每个 dyadic \(H<X\)，

\[
 \sum_{H<h\le 2H} C_h^*(X)^2
 \ll_{\varepsilon} X^{2+\varepsilon}H^{-1}.
 \tag{6.1}
\]

按 Cauchy--Schwarz 对每个 dyadic 壳求和，(6.1) 立即给
\(\sum_{n\le X}\lambda(n)\ll X^{1/2+\varepsilon}\)，再由标准
Littlewood--Denjoy 判据推出 RH。该条件比 QSLB 的“任意 \(\theta_h\)、独立
\(Y_h\)”量词弱，但比固定端点、对数平均或定性 Chowla 强得多；它正好暴露出
仍未支付的 signed Liouville collar。

该预印本还给出两个可核验的边界结论：

1. 固定端点的谱大筛可通过二进制区间分解无损升级到最大端点，因此 \(\sup_Y\)
   不是主要障碍；
2. 将 \(\lambda\) 换成任意 \(|c_n|\le1\) 的系数会失败，常数序列在
   \(H\asymp X^{1/4}\) 时产生 \(\asymp X^{9/4}\) 的 collar energy，而目标只有
   \(X^{15/8+o(1)}\)。因此任何真正的证明必须使用
   \(\lambda(n)=\sum_{r^2\mid n}\mu(n/r^2)\) 的乘法符号，不能靠系数无关的大筛。

这把当前缺口从“某个公开证明的技术细节”改写成了一个独立、可逐项核验的
最大均方命题；该命题在来源中明确标为 Open Problem，不能当作已证 RH。

## 终端区间的数值风险（仅作路线诊断）

同一来源的 Proposition 2.3 还把终端区间
\(X^{1-\eta}<h<X\) 的最大相关绝对值和作为输入。为检查这个输入的数量级，
对 \(\lambda(n)\) 做线性筛，并用零填充 FFT 精确计算
\[
 c_h(X)=\sum_{n\le X-h}\lambda(n)\lambda(n+h)
\]
（小规模直接求和核对 FFT 结果一致）。在 \(X=2^{12},\ldots,2^{19}\) 上，
\[
 \sum_{X/2\le h<X}|c_h(X)|
\]
与 \(X^{3/2}\) 的比值约为 \(0.18\)--\(0.21\)；例如 \(X=2^{18}\) 时为
\(0.1881\)，\(X=2^{19}\) 时为 \(0.1884\)。这只是有限范围的经验观察，不能
反驳渐近命题，但它与随机符号模型的 \(X^{3/2}\) 尺度相符，明显不显示
\(X^{1+o(1)}\) 的趋势。因此，若继续沿该预印本路线，终端区间必须被视为一个
独立且非常强的未决假设，不能当作由普通短区间平均结果“顺带得到”。

可复现实验脚本为
`computations/check_liouville_terminal_fft.py`；脚本先用线性筛生成
\(\lambda\)，再用零填充 FFT，并对小移位逐项直接求和核对相关方向。
同一脚本同时输出 signless dyadic 端点块
\(D_H(X)=\sum_{H\le h<2H}c_h(X)\)；在 \(X=2^{20},2^{21},2^{22}\)
上，\(\max_H|D_H(X)|/X\) 分别约为 \(0.55,0.43,0.32\)。这只说明块内
signed cancellation 在有限样本中与 \(O(X)\) 尺度相容，仍不是任何渐近证明。
