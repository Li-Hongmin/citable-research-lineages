> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 更正：非整数 y 必须保留 floor(y)

日期：2026-08-15。

本文件更正原先误写为“次数十五四-residue detector 不是正”的草稿。错误来自把
sum(c^k, c<=y) 在非整数 y 上当作 Faulhaber 的解析延拓；定义中上限应为
N=floor(y)。因此原草稿的变号证书不成立，相关 no-go 结论撤回。

正确的次数十五正 detector 及其完整 Bernstein 证书见
[note 144](144-a-positive-degree-fifteen-detector-removes-four-collective-residues.md)。
更高次数十六的独立正 detector 证书见
[note 143](143-a-positive-degree-sixteen-detector-removes-four-collective-residues.md)。
