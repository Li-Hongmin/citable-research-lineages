> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Scale-difference 的 Mellin 门与其 RH 强度

日期：2026-08-15。

本 note 把 note 165 的有限和 scale-difference 恒等式提升到连续 Mellin
层。结论不是新的 RH 证明，而是精确确定：若这个较薄对象获得跨临界线的
平方根级统一界，它本身已经包含 RH 强度。

## 1. Mellin 恒等式

取 \(F\in C_c^\infty((2/3,1))\)，令

\[
\Psi(t)=\int_t^\infty F(u)\,\frac{du}{u},\qquad
V(x)=\sum_{d\ge1}\mu(d)\Psi(d/x).
\]

记

\[
K_F(s)=\int_0^1F(u)u^{s-1}\,du .
\]

在 \(\Re s>1\) 中，有限支撑与 Mellin--Fubini 给出

\[
\begin{aligned}
\int_0^\infty V(x)x^{-s-1}\,dx
&=\frac{K_F(s)}{s}\sum_{d\ge1}\frac{\mu(d)}{d^s}\\
&=\frac{K_F(s)}{s\zeta(s)}.
\end{aligned}
\tag{1}
\]

对固定 \(R>1\) 定义
\[
\mathscr D_RV(x)=V(Rx)-V(x).
\]
作变量代换 \(y=Rx\)，得到

\[
\boxed{
\mathcal M[\mathscr D_RV](s)
=\frac{(R^s-1)K_F(s)}{s\zeta(s)}.}
\tag{2}
\]

这与 note 165 的离散式
\[
\sum_d\mu(d)G_R(d/N)=\frac{V(RN)-V(N)}{\log R}
\]
是同一 scale-difference 在连续与整数壳上的两种表达。

## 2. 统一平方根界已经是 RH 门

设 \(K_F\) 在 \(1/2<\Re s<1\) 无零。若对每个
\(\varepsilon>0\) 有

\[
\mathscr D_RV(x)\ll_{\varepsilon,R}x^{1/2+\varepsilon},
\tag{3}
\]
则左侧 Mellin 积分在 \(\Re s>1/2\) 绝对收敛，从而 (2) 给出
\[
\frac1{\zeta(s)}
=\frac{s\,\mathcal M[\mathscr D_RV](s)}
{(R^s-1)K_F(s)}
\]
在该半平面解析。因为 \(R^s-1\ne0\)（\(\Re s>0\)），这排除了
\(\zeta\) 在 \(1/2<\Re s<1\) 的零点。

同样，若直接得到连续 dyadic 均方界

\[
\int_Y^{2Y}|\mathscr D_RV(x)|^2\,dx
\ll_{\varepsilon,R}Y^{2+\varepsilon},
\tag{4}
\]
并另有足够的局部平滑/插值把 dyadic 数据送入 Mellin 积分，则离线零点
\(\rho=\beta+i\gamma\) 的显式项大小为 \(Y^\beta\)，其壳均方主阶为
\(Y^{2\beta+1}\)；(4) 强迫 \(\beta\le1/2\)。因此 (4) 不是一个已知的
弱于 RH 的门，而是 RH-strength 的 signed dispersion 命题。

## 3. Scale multiplier 对离线零点不退化

令 \(R=e^t\)。对 \(\rho=\beta+i\gamma\)，

\[
|R^\rho-1|^2
=|e^{\rho t}-1|^2
=(e^{\beta t}-1)^2+2e^{\beta t}(1-\cos\gamma t)
\ge(e^{\beta t}-1)^2.
\tag{5}
\]

所以若 \(t\in[t_0,t_1]\subset(0,\infty)\) 且
\(\beta\ge1/2+\delta\)，则

\[
\int_{t_0}^{t_1}|e^{\rho t}-1|^2\,dt
\ge
\int_{t_0}^{t_1}(e^{(1/2+\delta)t}-1)^2\,dt
>0,
\tag{6}
\]
下界与 \(\gamma\) 无关。也就是说，平均多个 \(R\) 不能把离线零点
通过 \(R^\rho-1\) 消掉；真正可能衰减的是 \(K_F(\rho)\)，而固定 detector
通常只有逐点非消失，没有随高度一致的下界。

## 4. 显式 co-Poisson 映射与真正的基底失配

对有限系数 \(c=(c_d)\) 定义
\[
(\mathcal J_Fc)(x)=\sum_d c_d\Psi(d/x),\qquad
P_c(s)=\sum_d c_dd^{-s}.
\]
同一个 Fubini 计算给出精确的 co-Poisson/Mellin intertwining
\[
\mathcal M[\mathcal J_Fc](s)=\frac{K_F(s)}sP_c(s).
\tag{7}
\]
所以“存在一个把有限整数向量送到 Mellin 函数的映射”并不是当前缺口。
在 \(L^2(dx/x)\) 的 Hilbert 范数下，Plancherel 给出的是
\[
\|\mathcal J_Fc\|_2^2
=\frac1{2\pi}\int_{\mathbb R}
\frac{|K_F(1/2+it)|^2}{|1/2+it|^2}
\left|\sum_d c_dd^{-1/2-it}\right|^2dt.
\tag{8}
\]
这是 \(a/b\) 型 Toeplitz（差坐标）核。

而 reciprocal-product detector 的 Mellin 展开是双线性的
\[
\sum_{a,b}c_ac_bP\!\left(\frac{x}{ab}\right)
=\frac1{2\pi i}\int
K_P(s)x^s
\left(\sum_ac_aa^{-s}\right)^2ds,
\tag{9}
\]
其 log 坐标是 \(a+b\) 型 Hankel（和坐标）核。除非先限制在临界线并把
第二槽替换成反射共轭，否则 (8) 的模平方不能等同于 (9) 的平方。
因此合法的 co-Poisson 映射存在，但从它的正 Hilbert 范数回到原
reciprocal-product signed 门，仍缺一个保持双线性 \(A(s)^2\) 的全局 Weil
intertwiner；在临界线上偷换为 \(|A(s)|^2\) 会丢失离线零点信息。

## 5. 对路线的最薄结论

当前可严格保留的对象链是

\[
\text{Möbius signed scale difference}
\longrightarrow
\frac{(R^s-1)K_F(s)}{s\zeta(s)}.
\]

它比 reciprocal-product Hankel 双和更薄，但要完成 RH 仍至少需要：

1. 一个把整数壳上的 common-scale difference 与连续 Mellin/Weil 空间相容的
   signed intertwiner；
2. 在该 intertwiner 下证明 (3) 或 (4) 型统一界；
3. 若使用固定 \(F\)，还需控制 \(K_F(\rho)\) 的高度衰减，或构造随高度变化
   且仍可统一审计的 detector family。

note 165 的 common-scale/divisor-incidence 基底失配与固定有限秩 inertia
障碍，说明普通正 Schur、固定 rank-one Yukawa atom 或逐项绝对值估计不能
替代上述输入。本文不声称 RH 已被证明。
