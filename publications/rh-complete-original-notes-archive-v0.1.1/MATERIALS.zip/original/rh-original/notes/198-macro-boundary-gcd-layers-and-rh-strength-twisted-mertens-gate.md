> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 宏观 half-lattice 边界的 gcd 层与 RH-strength twisted-Mertens 门

日期：2026-08-15。

本 note 处理 [note 193](193-gcd-decomposition-of-the-positive-energy-gate-and-the-boundary-correlation.md) 中的宏观块
\[
B_N=\sum_{\substack{N/2<r,s\le N\\(r,s)=1}}\mu(r)\mu(s)\,\widetilde g(\log(r/s)),
\qquad \widetilde g(t)=\int_{\mathbb R}w(\xi)e^{i\xi t}\,d\xi .
\]
结论是一个精确的 signed gcd-layer 分解，以及一个清楚的 RH-strength 充分条件。它不把 \(B_N\) 的有限估计外推为 RH。

## 1. 精确 gcd-layer 恒等式

用 \(\mathbf 1_{(r,s)=1}=\sum_{d\mid(r,s)}\mu(d)\)、\(r=du\)、\(s=dv\)，并把 Fourier 积分与有限和交换，得到
\[
\boxed{B_N=\int_{\mathbb R}w(\xi)\sum_{d\le N}\mu(d)|U_{d,N}(\xi)|^2\,d\xi,}
\tag{1}
\]
其中
\[
U_{d,N}(\xi)=\sum_{\frac{N}{2d}<u\le\frac Nd}\mu(du)\,u^{i\xi}.
\tag{2}
\]
这里 \(d\) 非平方自由时项自动为零。式 (1) 是有序对的精确恒等式，没有平均、截断误差或 RH 假设。

第一层 \(d=1\) 是完整 shell 正能量
\[
\int_{\mathbb R}w(\xi)\left|\sum_{N/2<u\le N}\mu(u)u^{i\xi}\right|^2d\xi .
\]
而 \(d>N/2\) 时区间 (2) 只含 \(u=1\)，故
\[
\sum_{N/2<d\le N}\mu(d)|U_{d,N}(\xi)|^2=\sum_{N/2<d\le N}\mu(d).
\tag{3}
\]
显式出现 Mertens shell。因此 \(B_N\) 不是一个正 Gram：其正层与负层必须保留 signed cancellation。

## 2. 逐层绝对值为何不够

由 (1) 只能无条件得到
\[
|B_N|\le\sum_{d\le N}\int_{\mathbb R}w(\xi)|U_{d,N}(\xi)|^2\,d\xi .
\tag{4}
\]
若只用 \(|\mu(du)|\le1\)，右边的 \(d\)-层长度为 \(N/d\)，并且在 \(\xi\) 的固定邻域上可达到总量 \(N^2\) 的三角估计；这不能给出 \(N^{1+\varepsilon}\)。所以 \(d\)-层之间的 \(\mu(d)\) 符号不能被逐层取模。

## 3. 一个明确的 RH-strength 充分条件

设对某个 \(A\ge0\)，权函数满足
\[
\int_{\mathbb R}w(\xi)(1+|\xi|)^{2A}\,d\xi<\infty.
\tag{5}
\]
考虑如下 uniform twisted-Mertens 输入：对每个 \(\varepsilon>0\)，所有 \(Y\ge2\)、平方自由 \(d\le N\) 与实 \(\xi\) 有
\[
\left|\sum_{\substack{u\le Y\\(u,d)=1}}\mu(u)u^{i\xi}\right|\le C_{\varepsilon,A}Y^{1/2+\varepsilon}d^\varepsilon(1+|\xi|)^A .
\tag{6}
\]
由区间差分和 \(\mu(du)=\mu(d)\mu(u)\mathbf 1_{(u,d)=1}\)，(6) 给出
\[
|U_{d,N}(\xi)|\ll_{\varepsilon,A}(N/d)^{1/2+\varepsilon}d^\varepsilon(1+|\xi|)^A .
\tag{7}
\]
当 \(N/d<2\) 时不使用 (6)，而直接用 \(|U_{d,N}|\le1\)；这与 (7) 的
右端同阶，故不改变后续求和。
若 \(\varepsilon\) 在 (7) 中取同一值，则 (5) 与 (7) 推出
\[
\int_{\mathbb R}w(\xi)|U_{d,N}(\xi)|^2d\xi\ll_{\varepsilon,A}\frac{N^{1+2\varepsilon}}{d}.
\tag{8}
\]
代回 (4)，得到
\[
\boxed{|B_N|\ll_{\varepsilon,A}N^{1+2\varepsilon}\log(2N).}
\tag{9}
\]
这给出宏观边界的一个可审计充分条件，但条件 (6) 本身已经是平方根级 Möbius 输入。

## 4. 与 RH 的关系及边界

若 RH 成立，并且采用标准 Perron 移位及
\[
\frac1{\zeta(\sigma+it)}\ll_{\varepsilon}(1+|t|)^{A_\varepsilon},\qquad \sigma\ge\tfrac12+\varepsilon,
\]
则 Dirichlet 级数
\[
\sum_{(u,d)=1}\mu(u)u^{-s+i\xi}=\frac1{\zeta(s-i\xi)}\prod_{\ell\mid d}(1-\ell^{-s+i\xi})^{-1}
\]
给出 (6) 型的 twisted-Mertens 界（有限 Euler 因子只产生 \(d^\varepsilon\) 损失），从而得到 (9)。这里仍需在正式证明中写出 Perron 截断、\(\xi\)-依赖和权函数尾部的统一常数；本 note 不把这一步当作已完成定理。

反方向不能从固定 \(w\) 的 \(B_N=O(N^{1+\varepsilon})\) 直接推出 RH：(1) 中 \(d=1\) 的正 shell 能量可能与 \(d\ge2\) 的 signed 层抵消。要得到 note 192 所需的
\[
\int_{\mathbb R}w(\xi)\left|\sum_{n\le N}\mu(n)n^{i\xi}\right|^2d\xi\ll_\varepsilon N^{1+\varepsilon},
\]
必须控制未作 Möbius-gcd 交错的完整正能量，而不能只控制宏观互素块 \(B_N\)。

因此 note 193 的首断点可精确表述为：宏观块的无条件平方根上界等价于保留 \(d\)-层 signed cancellation 的 uniform twisted-Mertens 门；其自然强度与 RH 同阶，普通平方自由密度或逐项绝对值均不足。
