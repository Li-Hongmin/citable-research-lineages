> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# V15 sharp half-lattice 平方根界与 RH 的双向等价

日期：2026-08-16。

本 note 把 note 290 的精确 Mellin 因子化整理成一个双向命题。它不声称
RH，而是严格说明：对当前正 detector \(V_{15}\)，sharp half-lattice
二次型的平方根级估计恰好就是 RH 的另一种表述。

## 命题

令

\[
V_{15}(u)=u^2(1-u)^9
(1024u^4+207u^3-57u^2-27u-3),
\]

在 \(0<u<1\) 外作零延拓，并令

\[
P_{15}(y)=\sum_{c\le y}V_{15}(c/y),
\quad
U_{15}(x)=\sum_{n\ge1}\mu(n)V_{15}(n/x),
\]

\[
T_{15}(x)=\sum_{a,b\le\sqrt{x}}
\mu(a)\mu(b)P_{15}\!\left(\frac{x}{ab}\right).
\]

则以下两条命题等价：

\[
\mathrm{RH},
\qquad
T_{15}(x)\ll_\varepsilon x^{1/2+\varepsilon}
\quad(\forall\varepsilon>0).
\tag{1}
\]

## 1. 从 \(T_{15}\) 到 RH

截断卷积恒等式给出

\[
U_{15}(x)=2A_{15}(x)-T_{15}(x),
\qquad
A_{15}(x)=\sum_{n\le\sqrt{x}}\mu(n)V_{15}(n/x).
\tag{2}
\]

由于 \(V_{15}(u)=O(u^2)\) 于 \(u=0\)，

\[
|A_{15}(x)|
\le \sum_{k\ge2}|v_k|x^{-k}\sum_{n\le\sqrt{x}}n^k
=O_{V_{15}}(x^{-1/2}).
\tag{3}
\]

因此 (1) 中的二次型界推出

\[
U_{15}(x)\ll_\varepsilon x^{1/2+\varepsilon}.
\tag{4}
\]

对 \(\Re s>1\)，Mellin--Fubini 给出

\[
\int_1^\infty U_{15}(x)x^{-s-1}\,dx
=\frac{K_{15}(s)}{\zeta(s)},
\qquad
K_{15}(s)=\int_0^1V_{15}(u)u^{s-1}\,du.
\tag{5}
\]

由 (4)，左端绝对收敛并定义 \(\Re s>1/2+\varepsilon\) 内的全纯函数。
另一方面，直接积分得到

\[
K_{15}(s)=
\frac{415134720(s-1)}
{(s+2)(s+4)(s+6)(s+8)(s+9)(s+10)(s+11)(s+12)(s+13)(s+14)(s+15)}.
\tag{6}
\]

该函数在 \(1/2<\Re s<1\) 内没有零点。因此 \(\zeta(s)\) 在该带不能有零点。
令 \(\varepsilon\downarrow0\)，得到 RH。

## 2. RH 到 \(T_{15}\)

反过来假设 RH。标准的 Mertens 平方根界

\[
M(x)=\sum_{n\le x}\mu(n)\ll_\varepsilon x^{1/2+\varepsilon}
\tag{7}
\]

与一次 Abel 部分求和给出

\[
U_{15}(x)
=M(x)V_{15}(1)-\frac1x\int_1^x M(t)V_{15}'(t/x)\,dt
=O_\varepsilon(x^{1/2+\varepsilon}),
\tag{8}
\]

其中 \(V_{15}(1)=0\)，且 \(V_{15}'\) 在 \([0,1]\) 有界。

再次使用 (2) 和 (3)，得到

\[
T_{15}(x)=2A_{15}(x)-U_{15}(x)
=O_\varepsilon(x^{1/2+\varepsilon}).
\tag{9}
\]

这证明了反向蕴含。

## 3. 与精确 Mellin 因子化的一致性

note 290 给出的初始绝对收敛区公式为

\[
\int_1^\infty T_{15}(x)x^{-s-1}\,dx
=2\sum_{k\ge2}\frac{v_k}{(s+k)\zeta(2s+k)}
-\frac{K_{15}(s)}{\zeta(s)}.
\tag{10}
\]

第一项在 \(\Re s>-1/2\) 全纯；所以临界带右侧的所有潜在极点都来自
\(K_{15}(s)/\zeta(s)\)。这与上面的双向证明完全一致，并说明 sharp
cutoff 没有创造一个比 RH 更弱、却又足以闭合的独立谱不等式。

本命题的结论是严格的逻辑定位，不是 RH 的证明：当前缺少的正是式 (1)
中的无条件平方根级 signed Möbius 估计。
