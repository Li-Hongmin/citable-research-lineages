> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# incomplete-lcm 边界的 Bernoulli--Dedekind 精确化与平衡区铰链

日期与检索截止：2026-08-12。

依赖：[note 065](065-barban-vehov-hminus1-obstruction-and-weak-mertens-bridge.md)。

## 1. 弄清问题

沿用

\[
\lambda_d=\mu(d)\left(1-\frac{\log d}{\log N}\right),
\qquad
B_d(y)=\left\{\frac yd\right\}-\frac12,
\]

\[
E_{d,e}(N)=\int_N^{2N}B_d(y)B_e(y)\,dy
-\frac{N(d,e)^2}{12de}.
\tag{1}
\]

note 065 已将首壳 RH 充分条件压成

\[
\mathcal B_N
=Nc_N^2+2c_N\sum_{d\le N}\lambda_dE_d(N)
+\mathcal S_N=o(N^2),
\tag{2}
\]

其中

\[
\mathcal S_N:=\sum_{d,e\le N}\lambda_d\lambda_eE_{d,e}(N).
\tag{3}
\]

本轮问题不是重新估计 (1)，而是识别其历史标准对象及真正缺失的参数区。

```mermaid
flowchart LR
  A["incomplete-lcm 余项 E(d,e)"] --> B["Fourier: inverse cotangent coefficients"]
  A --> C["unit cells: three-factor Bernoulli–Dedekind difference"]
  B --> D["Maier–Rassias: power-separated one-modulus sums"]
  C --> E["真实主区: a≈b, endpoint r=N mod gab"]
  D -. "misses near diagonal" .-> E
  E --> F["missing: balanced coupled shift–lcm dispersion"]
```

## 2. 拟定计划

\[
\begin{array}{c|c}
\text{原子}&\text{判别}\\
\hline
E_{d,e}&\text{求精确 Fourier--cotangent 形式}\\
E_{d,e}&\text{求 complete generalized Dedekind 形式}\\
\mathcal S_N&\text{检验能否降为可分别估计的单壳和}\\
\text{历史定理}&\text{逐变量核对 balanced / unbalanced 范围}\\
\text{有限数据}&\text{定位 signed 与 absolute 质量}
\end{array}
\tag{4}
\]

## 3. 实现计划

### 3.1 精确 Fourier--cotangent 展开

记

\[
d=gb,\qquad e=ga,qquad (a,b)=1,qquad \ell=[d,e]=gab,
\tag{5}
\]

并写

\[
\mathrm e(x):=e^{2\pi ix}.
\]

若 \(q\mid r\)，置 \(\cot^*(\pi r/q)=0\)；否则置
\(\cot^*(\pi r/q)=\cot(\pi r/q)\)。模数为 \(1\) 时同样取零。

**定理 1（cotangent 边界公式）。** 定义主值和

\[
C_{a,b}(k):=
\operatorname{PV}
\sum_{\substack{am+bn=k\\m,n\ne0}}\frac1{mn}.
\tag{6}
\]

则

\[
\boxed{
C_{a,b}(k)
=\frac{\pi}{k}
\left[
\cot^*\!\left(\frac{\pi \bar b k}{a}\right)
+\cot^*\!\left(\frac{\pi \bar a k}{b}\right)
\right]
-\frac{ab}{k^2}
\left(\mathbf1_{a\mid k}+\mathbf1_{b\mid k}\right),
}
\tag{7}
\]

其中 \(\bar b=b^{-1}\pmod a\)、\(\bar a=a^{-1}\pmod b\)。并且

\[
\boxed{
E_{d,e}(N)
=-\frac{\ell}{8\pi^3i}
\sum_{k\ne0}\frac{C_{a,b}(k)}k
\left[
\mathrm e\!\left(\frac{2Nk}{\ell}\right)
-\mathrm e\!\left(\frac{Nk}{\ell}\right)
\right].
}
\tag{8}
\]

对固定 \(a,b\)，(8) 绝对收敛。

**证明。** 周期 Bernoulli 函数在 \(L^2\) 中满足

\[
\overline B_1(x)
=-\frac1{2\pi i}\sum_{m\ne0}\frac{\mathrm e(mx)}m.
\tag{9}
\]

它与本项目的 \(\{x\}-1/2\) 只在整数点不同，故积分不变。乘积的频率为

\[
\frac m{gb}+\frac n{ga}=\frac{am+bn}{gab}.
\tag{10}
\]

零频满足 \(am+bn=0\)，其系数为

\[
-\frac1{4\pi^2}
\sum_{t\ne0}\frac1{(bt)(-at)}
=\frac1{12ab}
=\frac{(d,e)^2}{12de}.
\tag{11}
\]

删去零频并积分即得 (8)。对非零 \(k\)，把

\[
\frac1{mn}=\frac{a}{n(k-bn)}
=\frac a{k}\left(\frac1n+\frac b{k-bn}\right)
\tag{12}
\]

沿算术级数求主值，得到两个 cotangent 项；再删去 \(m=0\) 与 \(n=0\)
的两个可能解，产生 (7) 的 divisibility 修正。最后，cotangent 因子对 \(k\)
周期有界，故 (8) 的项为 \(O_{a,b}(k^{-2})\)。\(\square\)

公式 (8) 把边界放入 Vasyunin--Bettin--Conrey cotangent 语言；但 endpoint phase
仍同时含 \(a,b,g\)，不能把它误认成单个 \(c_0(h/k)\)。

### 3.2 精确 complete 三因子 Dedekind 形式

令

\[
\beta(x):=\{x\}-\frac12,\qquad r:=N\bmod\ell,
\tag{13}
\]

以及

\[
\begin{aligned}
H_{d,e}(n):={}&
\beta(n/d)\beta(n/e)
+\frac{\beta(n/e)}{2d}
+\frac{\beta(n/d)}{2e}\\
&+\frac1{3de}-\frac1{12ab}.
\end{aligned}
\tag{14}
\]

**定理 2（complete endpoint transform）。** 有

\[
\sum_{n\bmod\ell}H_{d,e}(n)=0
\tag{15}
\]

及

\[
\boxed{
E_{d,e}(N)=
\sum_{n\bmod\ell}H_{d,e}(n)
\left[
\beta\!\left(\frac{n-2r}{\ell}\right)
-\beta\!\left(\frac{n-r}{\ell}\right)
\right].
}
\tag{16}
\]

定义

\[
T_{\ell;a,b}(u):=
\sum_{n\bmod\ell}
\beta(an/\ell)\beta(bn/\ell)\beta((n-u)/\ell),
\tag{17}
\]

\[
S_{\ell;c}(u):=
\sum_{n\bmod\ell}
\beta(cn/\ell)\beta((n-u)/\ell).
\tag{18}
\]

则

\[
\boxed{
\begin{aligned}
E_{d,e}(N)
={}&T_{\ell;a,b}(2r)-T_{\ell;a,b}(r)\\
&+\frac{S_{\ell;b}(2r)-S_{\ell;b}(r)}{2d}
+\frac{S_{\ell;a}(2r)-S_{\ell;a}(r)}{2e}.
\end{aligned}}
\tag{19}
\]

**证明。** 对整数 \(n\)，直接积分一个 unit cell：

\[
\int_n^{n+1}B_d(y)B_e(y)\,dy
=\beta(n/d)\beta(n/e)
+\frac{\beta(n/e)}{2d}
+\frac{\beta(n/d)}{2e}
+\frac1{3de}.
\tag{20}
\]

完整 \(\ell\)-周期扣除 (11) 后给出 (15)。另一方面，(16) 中方括号等于
长度为 \(r\) 的循环区间指示函数减 \(r/\ell\)；常数项因 (15) 消失，故它精确选出
从 \(N\bmod\ell\) 开始的剩余 \(r\) 个 unit cells。展开 (14) 即得 (19)。\(\square\)

因此真正对象是

\[
\boxed{
\text{coupled shift--lcm 三因子 Dedekind 差}
+\text{两个二因子差},
}
\tag{21}
\]

而非固定模数的 classical Dedekind sum。

### 3.3 双和可化为单壳相关，但不能拆开估计

令 \(\overline B_j\) 为周期 Bernoulli 多项式，并置

\[
F_N(y):=\sum_{d\le N}\lambda_dB_d(y)=D_N(y)-c_N,
\tag{22}
\]

\[
U_N(y):=\sum_{d\le N}\lambda_d d\,\overline B_2(y/d),
\qquad
U_N'(y)=2F_N(y)\quad\text{a.e.},
\tag{23}
\]

\[
V_N:=\sum_{d\le N}\lambda_dd^2
\left[\overline B_3(2N/d)-\overline B_3(N/d)\right].
\tag{24}
\]

**定理 3（单壳 Stieltjes 形式）。** 有精确恒等式

\[
\boxed{
\begin{aligned}
\mathcal S_N
={}&\frac12\sum_{N<n\le2N}q_N(n)U_N(n)\\
&+\frac12\left[
U_N(2N)(D_N(2N)-c_N)
-U_N(N)(D_N(N)-c_N)
\right]\\
&-\frac{A_N}{6}V_N-\frac N{12}Q_2(N).
\end{aligned}}
\tag{25}
\]

更直接地，完整首壳能量满足

\[
\boxed{
I_N
=Nc_N^2
+\frac12\left[U_N(y)(D_N(y)+c_N)\right]_{N}^{2N}
+\frac12\sum_{N<n\le2N}q_N(n)U_N(n)
-\frac{A_N}{6}V_N.
}
\tag{26}
\]

**证明。** \(F_N\) 在每个 unit cell 内斜率为 \(A_N\)，在整数 \(n\) 处跳跃
\(-q_N(n)\)。对 \(U_N'=2F_N\) 作 Stieltjes 分部积分，并用

\[
\int_N^{2N}U_N(y)\,dy=\frac{V_N}{3},
\tag{27}
\]

即得

\[
\int_N^{2N}F_N(y)^2dy
=\frac12[U_NF_N]_{N}^{2N}
+\frac12\sum_{N<n\le2N}q_N(n)U_N(n)
-\frac{A_NV_N}{6}.
\tag{28}
\]

分别代入 \(\mathcal S_N=\int F_N^2-NQ_2/12\) 与
\(I_N=\int(c_N+F_N)^2\)，并用
\(\int F_N=(U_N(2N)-U_N(N))/2\)，得到 (25)--(26)。\(\square\)

写

\[
T_1:=\frac12\sum q_NU_N,quad
T_2:=\frac12[U_N(D_N-c_N)]_N^{2N},quad
T_3:=-\frac{A_NV_N}{6},quad
T_4:=-\frac N{12}Q_2.
\tag{29}
\]

全量计算 \(N=2^{10},\ldots,2^{22}\) 显示

\[
\operatorname{corr}(T_1,T_3)=-0.997878,
\qquad
\operatorname{corr}_{18\le k\le22}(T_1,T_3)=-0.999948.
\tag{30}
\]

最后五个尺度的四项绝对质量平均为

\[
(|T_1|,|T_2|,|T_3|,|T_4|)
=(49.65\%,0.039\%,48.51\%,1.79\%).
\tag{31}
\]

例如 \(N=2^{22}\)，除以 \(N^2\) 后

\[
(T_1,T_2,T_3,T_4)
=(2.615542,0.000065,-2.456645,-0.134994)\times10^{-3},
\tag{32}
\]

而

\[
\mathcal S_N/N^2=2.396798\times10^{-5}.
\tag{33}
\]

所以 (25) 是精确降维字典，却不是可分别粗估的分解：必须保留

\[
\boxed{
T_1+T_3
=\frac12\left(
\sum_{N<n\le2N}q_N(n)U_N(n)
-A_N\int_N^{2N}U_N(y)\,dy
\right).
}
\tag{34}
\]

分别证明 \(T_1=o(N^2)\)、\(T_3=o(N^2)\) 不是与真实抵消相容的主路线。

### 3.4 历史定理准确到达哪里

He--Shi 的 Bernoulli 乘积公式给出 (19) 所属的 generalized
Dedekind--Rademacher 字典；Beck--Chavez 与 Hall--Wilson--Zagier 给出相邻的 complete
互反律；Bettin--Conrey 给出 Vasyunin/cotangent 互反律。这些定理重排固定模数对象，均不估计
\(r=N\bmod[d,e]\) 与 Möbius 权耦合后的双和。

Maier--Rassias 2018 的 Theorem 1.1 则证明：给定

\[
0<\delta<D/2,\qquad k^{2\delta}\le B\le k^D,\qquad k^{-\delta}\le\eta\le1,
\tag{35}
\]

存在 \(\beta=\beta(\delta,D)>0\)，使

\[
\sum_{Bk\le h<(1+\eta)Bk}\mu(h)g(h/k)
=O\!\left((\eta Bk)^{1-\beta}\right).
\tag{36}
\]

其 Corollary 1.2 恰好把未处理尾部留在 \(h\le k^{1+\varepsilon}\)。2019 的续篇在
\(n\asymp k^D,D\ge2\) 给出显式固定幂节省。故现成技术覆盖的是一个固定分母与
**多项式分离**的分子；它没有覆盖

\[
a\asymp b,\qquad r=N\bmod(gab),\qquad
T_{gab;a,b}(2r)-T_{gab;a,b}(r).
\tag{37}
\]

还需注意：arXiv:1806.05070v1 的 Theorem 2.1 所列 \(C\) 方程在约束
\(C\ge(1+\sqrt5)/2\) 下无解，而证明中的参数方程不同。因此这里只采用已证明的定性
“固定幂节省、\(D\ge2\)”范围，不移植该版本显示的数值指数。

原始入口：
[He--Shi 2024](https://arxiv.org/abs/2310.17093)、
[Beck--Chavez 2010](https://arxiv.org/abs/1008.0038)、
[Bettin--Conrey 2013](https://arxiv.org/abs/1111.0931)、
[Maier--Rassias 2018](https://arxiv.org/abs/1705.09921)、
[Maier--Rassias 2019](https://doi.org/10.1016/j.jfa.2018.06.022)。

### 3.5 非二幂端点与 reduced-balance 定位

取 cutoff-relative blocks

\[
R_j(N)=\left[\frac{N}{2^{j+1}},\frac{N}{2^j}\right)\cap\mathbb N,
\qquad
\mathcal S_{ij}(N)=
\sum_{d\in R_i,e\in R_j}\lambda_d\lambda_eE_{d,e}(N).
\tag{38}
\]

置

\[
\mathfrak A_{\rm blk}=\sum_{i,j}|\mathcal S_{ij}|,
\quad
H_8=\frac{\sum_{i,j<8}|\mathcal S_{ij}|}{\mathfrak A_{\rm blk}},
\tag{39}
\]

\[
X_8=\frac{\sum_{\min(i,j)<8\le\max(i,j)}|\mathcal S_{ij}|}
{\mathfrak A_{\rm blk}}.
\tag{40}
\]

在 \(N=\lfloor u2^{22}\rfloor\) 上的 exact-cell/Jordan 全量计算为

\[
\begin{array}{c|c|c|c}
u&H_8&X_8&\displaystyle
\frac{\sum_{i,j<8}\mathcal S_{ij}}{\mathcal S_N}\\
\hline
1&0.975070&0.018261&0.959445\\
9/8&0.966046&0.025623&0.959606\\
5/4&0.968298&0.023942&0.992016\\
3/2&0.967670&0.023889&0.988764\\
7/4&0.969918&0.023066&1.015941
\end{array}
\tag{41}
\]

故固定高块局部化不是 \(N=2^k\) 的明显端点共振。最大块始终位于

\[
d,e\asymp N/8,N/4
\quad\text{或}\quad
N/16,N/8.
\tag{42}
\]

进一步逐对写 \(d=gb,e=ga,(a,b)=1\)。在 \(N=2^{15}\) 时，逐项绝对质量满足

\[
\begin{array}{c|c|c}
\text{区域}&\text{全域占比}&j=2,3\text{ 主块占比}\\
\hline
\max(a,b)\le2\min(a,b)&62.620\%&84.492\%\\
\max(a,b)\ge\min(a,b)^2&0.0818\%&0.0123\%\\
g\ge\max(a,b)&0.2435\%&0.3155\%
\end{array}
\tag{43}
\]

主对角块 \(R_2^2,R_3^2\) 的 physical support 本身强制 \(a/b\in[1/2,2]\)，而
候选 \(D\ge2\) 区只占 \(0.29\%-0.37\%\) 的逐项绝对质量。于是

\[
\boxed{
\text{现有 Maier--Rassias power-separated 范围不覆盖主质量。}
}
\tag{44}
\]

另一方面，\(N=2^{15}\) 时

\[
\sum_{d,e}|\lambda_d\lambda_eE_{d,e}|/N^2=0.7050,
\qquad
|\mathcal S_N|/N^2=1.028\times10^{-4}.
\tag{45}
\]

所以逐对绝对值路线损失超过三个数量级，并随当前样本扩大；真实机制是 balanced 块内的
Möbius 抵消。

## 4. 回顾反思

### 4.1 已得到的严格新归约

\[
\boxed{
\text{signed incomplete-lcm boundary}
\equiv
\text{coupled three-factor Bernoulli--Dedekind dispersion}.
}
\tag{46}
\]

最薄的新算术命题不是 fixed-modulus reciprocity，而是以下 near-diagonal 版本。对固定
\(i,j\)，令 \(\mathfrak D_{ij}^{\rm bal}(N)\) 为 (19) 的三因子差在

\[
d\in R_i(N),\quad e\in R_j(N),quad
\frac12\le\frac{e/(d,e)}{d/(d,e)}\le2
\tag{47}
\]

上的 \(\lambda_d\lambda_e\) 加权和。需要建立

\[
\boxed{
\mathfrak D_{ij}^{\rm bal}(N)=o(N^2)
\qquad(i,j\ \text{固定}),
}
\tag{MR-bal}
\]

连同两个二因子差、常数块及低物理尺度尾的一致可和估计。它是 Maier--Rassias
one-modulus theorem 的真正缺失变体：

\[
\begin{array}{c|c}
\text{已有}&h/k\ge k^{2\delta},\ \text{fixed }k,\ \text{one Möbius sum}\\
\text{所需}&a/b\asymp1,\ \ell=gab,\ r=N\bmod\ell,\ \text{bilinear Möbius sum}
\end{array}
\tag{48}
\]

### 4.2 被关闭的候选捷径

\[
\begin{array}{c|c}
\text{捷径}&\text{关闭原因}\\
\hline
\sum|E_{d,e}|&\text{丢失超过三数量级的块内抵消}\\
\text{classical reciprocity}&\text{只重排 fixed complete moduli}\\
\text{直接套 MR 2018/2019}&\text{主质量在 balanced near diagonal}\\
T_1,T_3\text{ 分别估计}&\text{二者承担约 }98\%\text{ 绝对质量且几乎反相}\\
N=2^k\text{ 共振解释}&\text{五个非二幂端点保持 }H_8>0.966
\end{array}
\tag{49}
\]

### 4.3 下一原子任务

不再扩大互反律目录。下一步只做一个会改变决策的推导：对
\(j=2,3\) 的 (MR-bal) 应用 Vaughan/Heath--Brown 分解，检查 Type I 是否由
Maier--Rassias 的 continued-fraction/Fourier 技术覆盖，并把第一个不能覆盖的 balanced
Type II 核写成显式 inverse-fraction bilinear form。若该 Type II 已有 Kloosterman-fraction
平均定理可用，则进入证明；否则它就是下一最薄新定理。

有限计算只用于定位机制，不构成 (MR-bal)、(2) 或 RH 的证明。
