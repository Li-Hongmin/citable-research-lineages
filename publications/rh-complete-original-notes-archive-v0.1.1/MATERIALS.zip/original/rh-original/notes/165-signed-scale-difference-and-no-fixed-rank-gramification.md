> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Signed scale difference 的精确恒等式与固定秩 Gram 化不可能性

日期：2026-08-15。

证据等级：有限和恒等式、有限主子式惯性定理。本文给出一个比直接平方根门更薄的
signed Möbius 接口，同时说明它不能被固定有限秩的正化/Schur 修正替代。

## 1. 精确的双尺度差分接口

取 \(F\) 支持于 \((2/3,1)\)，令

\[
 \Psi(t)=\int_t^\infty F(u)\,\frac{du}{u},
 \qquad
 G_R(t)=\frac{\Psi(t/R)-\Psi(t)}{\log R},\quad R>1,
\]

以及

\[
 V(x)=\sum_{d\ge1}\mu(d)\Psi(d/x).
\]

由于每个 \(x\) 只含有限个 \(d<x\)，这是无条件的有限和。对任意壳
 \(Y<N\le2Y\)，有精确恒等式

\[
 S_{N,R}:=\sum_d\mu(d)G_R(d/N)
 =\frac{V(RN)-V(N)}{\log R}.
\tag{1}
\]

因此

\[
 \boxed{
 \sum_{Y<N\le2Y}|S_{N,R}|^2
 =\frac{1}{(\log R)^2}
 \|P_Y\mathscr D_RV\|_{\ell^2}^2,
 \qquad
 \mathscr D_RV(N)=V(RN)-V(N).}
\tag{2}
\]

这是真正保留 Möbius 符号的两侧 scale-difference，而不是把两个槽逐项取绝对值。
离散 Abel 求和还给出

\[
 S_{N,R}=\sum_{d\ge1}M(d)\,[G_R(d/N)-G_R((d+1)/N)],
 \qquad M(d)=\sum_{j\le d}\mu(j),
\tag{3}
\]

故二次型满足

\[
 \sum_{Y<N\le2Y}|S_{N,R}|^2
 =\sum_{d,e}M(d)M(e)\,\Delta_d^+\Delta_e^+H_{Y,R}(d,e),
\tag{4}
\]

\[
 H_{Y,R}(d,e)=\sum_{Y<N\le2Y}G_R(d/N)G_R(e/N),
 \qquad
 \Delta_d^+\Delta_e^+H_{Y,R}
 =\sum_{Y<N\le2Y}B_{N,d}B_{N,e},
\]

\[
 B_{N,d}=G_R(d/N)-G_R((d+1)/N).
\tag{5}
\]

式 (4)--(5) 是可迁移的有限差分/Gram 恒等式：两个槽确实各有一个 genuine
差分，所有 signed cancellation 在 \(M(d)M(e)\) 层保留。

但是中间 Gram (5) 不是标准 divisor-incidence Gram。若
 \(\mathcal I_{n,d}=1_{d\mid n}\)、\(W=\operatorname{diag}(w_n)\ge0\)，则

\[
 (\mathcal I^*W\mathcal I)_{d,e}=\sum_{k\ge1}w_{k[d,e]}
\tag{6}
\]

只依赖于 \([d,e]\)。而对 (5)，取大 \(N_0\equiv0\pmod3\)、\(Y=N_0-1\)、
 \(d_1=N_0/3\)、\(d_0=2N_0/3\)。因 \(G_R\) 在 \(2/3\) 右侧严格递增，
 \(B_{N,d_1}=0\) 对壳中所有 \(N\ge N_0\)，但 \(B_{N_0,d_0}\ne0\)。于是

\[
 (B^*B)_{d_1,d_0}=0,
 \qquad (B^*B)_{d_0,d_0}>0,
 \qquad [d_1,d_0]=[d_0,d_0],
\]

否定了任何完整的 (6) 型识别。故最薄未闭合输入是一个
 common-scale total-order basis 到 divisor-incidence basis 的 signed intertwiner；
 scale difference 本身并不提供它。

## 2. 固定有限秩正化的严格 no-go

对 note 118 的 cubic endpoint-flat detector，记

\[
 K_x(a,b)=P\!\left(\frac{x}{ab}\right),
 \qquad
 P(y)=\frac{\lfloor y\rfloor(\lfloor y\rfloor+1)}{y^3}\{y\}(1-\{y\}).
\]

取 \(x=p_m^\#\)、\(a_j=2p_j\) (\(2\le j\le m\))。note 135 的精确合同给出

\[
 K_x|_{\{a_j\}}=D(J-E)D,
 \qquad E\succ0,
\]

并且

\[
 \operatorname{inertia}(K_x|_{\{a_j\}})=(1,m-2,0).
\tag{7}
\]

对 fully-centered 核同样有

\[
 C_x|_{\{a_j\}}=D\left(\frac13J-E\right)D,
 \qquad
 \operatorname{inertia}(C_x|_{\{a_j\}})=(1,m-2,0).
\tag{8}
\]

设 \(F_x\) 是任意在该有限坐标集上的 rank-\(r\) 修正，并假设希望
 \(K_x+F_x\succeq0\) 或 \(C_x+F_x\succeq0\)。由于 \(K_x,C_x\) 自伴，
这一 PSD 假设自动迫使 \(F_x=F_x^*\)；于是有限维惯性扰动不等式

\[
 n_-(A+B)\ge n_-(A)-\operatorname{rank}B
\tag{9}
\]

给出

\[
 n_-(K_x+F_x)\ge m-2-r,
 \qquad
 n_-(C_x+F_x)\ge m-2-r.
\tag{10}
\]

令 \(m>r+2\)，右端严格为正。因此：

\[
 \boxed{\text{不存在秩独立于 }x\text{ 的有限-rank signed correction，能把该 reciprocal
 Hankel detector 统一 Gram 化或变成 PSD Schur 补。}}
\]

这个 no-go 不依赖逐项绝对值，也不依赖数值近似；它只用真实 squarefree Möbius 支撑上的
 primorial 主子矩阵。若要正化，修正秩至少满足

\[
 r_x\ge m-2\asymp\frac{\log x}{\log\log x}
\]

沿 primorial 序列增长。因而任何声称由固定 rank-one/rank-(r) Feshbach 或固定
 commutator 自动产生 signed Möbius/Weil intertwiner 的路线均已被 (10) 排除。

## 3. 决策边界

式 (2)--(5) 是目前最薄的合法候选：它把 reciprocal-product 双线性改写成一个完整
scale-difference 向量的范数，而不逐项取模。这里的“更薄”是对象复杂度的说法，
不是已证明的逻辑弱化；若要求对所有壳给出平方根级界，固定 \(R>1\) 下离线主项
 \(V(Rx)-V(x)\sim(R^\rho-1)x^\rho\) 仍不消失，故该界很可能本身具有 RH 强度。
但若还要把它转成 divisor Gram 或正 Schur，首个缺口就是上述 basis intertwiner；
固定有限秩修正不可能跨越该缺口。增长秩的修正虽未被 (10) 排除，却至少支付
 \( \asymp\log x/\log\log x\) 个真实 signed modes，并非已有 detector 正性自动给出。

本文不声称 RH 已被证明。
