> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Screw-kernel 半正性不推出 injectivity

日期：2026-08-11。

Suzuki 把 Weil 形式写成 \(A_a=D^*G_aD\)，其中 \(G_a\) 是均值零空间上的连续核紧算子。
本文证明：injectivity 精确等价于谱测度支撑构成 Paley--Wiener uniqueness set；即使加入与
Suzuki 相同的 \(\frac12|t|\log|t|\) 对角主奇性，PSD screw kernel 仍可有非平凡核。

## 1. 谱测度与唯一集

若连续偶 screw function \(g\) 具有正谱测度 \(\nu\)，则均值零的
\(u\in L^2(-a,a)\) 满足

\[
\langle G_au,u\rangle
=\int_{\mathbb R}|\widehat u(\lambda)|^2\,d\nu(\lambda).
\tag{1}
\]

因为 \(\widehat u\in PW_a\)，所以

\[
\boxed{
\ker G_a=\{0\}
\iff
\operatorname{supp}\nu
\text{ 是 }PW_a\text{ uniqueness set}.}
\tag{2}
\]

谱支撑无限或只在无穷远聚积均不足以保证 (2)。

## 2. 匹配 Suzuki 主奇性的反例

令

\[
w_n=\frac{\log(en)}{\pi n^2}>0,
\qquad
g_0(t)=\sum_{n\ge1}w_n(\cos nt-1).
\tag{3}
\]

\(\sum_nw_n<\infty\)，故 \(g_0\) 连续、实偶，并由正离散谱测度产生 PSD screw Gram kernel。
尺度换元及

\[
\int_0^\infty\frac{\cos y-1}{y^2}\,dy=-\frac\pi2
\]

给出连续主项

\[
\frac1\pi\int_1^\infty
\frac{\log x}{x^2}(\cos tx-1)\,dx
=\frac12|t|\log|t|+O(|t|).
\]

逐单位区间的 Euler 比较误差为

\[
O\!\left(t^2\log^2\frac1{|t|}\right)=o(|t|),
\]

而 \(\log(en)\) 中的常数部分只贡献 \(-|t|/2+O(t^2)\)。因此

\[
\boxed{
g_0(t)=\frac12|t|\log|t|+O(|t|),
\qquad t\to0,}
\tag{4}
\]

其主奇性与 Suzuki 公式 (2.2) 完全相同。

然而谱支撑是整数集。当 \(a>\pi\) 时，整数指数系统在 \(L^2(-a,a)\) 中不完备，存在非零均值零
\(u\) 满足 \(\widehat u(n)=0\) 对所有整数 \(n\)。由 (1)，

\[
\boxed{G_{0,a}\succeq0,\qquad\ker G_{0,a}\ne\{0\}.}
\tag{5}
\]

有限增加若干谱点也不能修复该不完备性。故

\[
\text{PSD}+\text{连续 screw kernel}
+\tfrac12|t|\log|t|\text{ 主奇性}
\not\Longrightarrow\text{injective}.
\]

## 3. RH 下严格正，但不能反向使用

若预先假设 RH，实际 Suzuki 形式满足

\[
\langle G_au,u\rangle
=\sum_\gamma\frac{m_\gamma}{\gamma^2}|\widehat u(\gamma)|^2.
\tag{6}
\]

zeta ordinates 的计数为 \(N(T)\asymp T\log T\)，而非零 \(PW_a\) 整函数在
\([-T,T]\) 中只有 \(O_a(T)\) 个零，所以 (6) 为零强迫 \(u=0\)。

但只知道某个固定区间上 \(G_a\succeq0\) 时，局部正延拓的谱测度并不唯一，不能宣称其支撑就是
zeta ordinates；否则会循环使用 RH。

## 4. 定义域障碍

在强形式域上，

\[
D:H_0^1(-a,a)\to L_0^2(-a,a)
\]

是双射。但首次退化本征函数只先验属于 Friedrichs 算子域。Suzuki Section 8.3 明确指出

\[
\bar Dv\in H(S_a),
\qquad H(S_a)\not\subset L^2(-a,a).
\]

因此从 \(v\in\ker A_a\) 推到普通 \(L_0^2\) 意义的 \(Dv\in\ker G_a\)，还需要额外的导数
\(L^2\) 正则性。不能把 form-completion 零模态直接代入紧积分算子方程。

## 5. 路线结论

1. 一般 screw 结构与精确对角主奇性不足以推出 injectivity。
2. 普通紧算子的最小奇值即使在 injective 情形也趋于零，Galerkin singular gap 不能认证真核。
3. \(G_a\) 只把问题改写成 strict local screw positivity/Paley--Wiener uniqueness，并未绕开
   原零模态问题。
4. Friedrichs 零模态到普通 \(G_a\) 核之间还存在独立的导数正则性缺口。
