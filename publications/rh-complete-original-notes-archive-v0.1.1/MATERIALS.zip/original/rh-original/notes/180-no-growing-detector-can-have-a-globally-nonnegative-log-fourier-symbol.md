> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# growing detector 的 log-Fourier 符号不可能全频非负

日期：2026-08-15。

本 note 给出一个不依赖有限数值扫描的结构性障碍。对统一 detector
\(V_m\)（以及它们的任意非零有限线性组合），其对称 log-kernel 的
Fourier 符号不可能在整个实轴非负。原因不是某一个频率的偶然负值，而是
所有 detector 都有 \(P(1)=0\)，同时 \(P\not\equiv0\)。

## 1. 对称 log-kernel 与 Mellin 符号

令
\[
 P_m(y)=\sum_{1\le c\le y}V_m(c/y),\qquad y\ge1,
\]
并置
\[
 g_m(t)=\frac12P_m(e^{|t|}),\qquad t\in\mathbb R.
\]
沿用统一层级的 Mellin 变换
\[
 K_m(s)=
 \frac{(3m+1)!(s-1)}{C_m
 \displaystyle\prod_{j=1}^{m}(s+2j)
 \displaystyle\prod_{k=2m+1}^{3m+3}(s+k)}.
\tag{1}
\]
端点平坦性 \(V_m(u)=O(u^2)\) 于 \(u=0\)，以及

\[
 \int_0^1V_m(u)\,du=K_m(1)=0,
\]
使 Euler--Faulhaber 展开中的 \(y^1\) 项消失；因而

\[
 P_m(y)=O_m(y^{-2})\qquad(y\to\infty).
\tag{2}
\]
故 \(g_m\in L^1(\mathbb R)\)。在 \(\Re s>1\) 先做 Mellin--Fubini，再用
解析延拓和偶化，得到连续 Fourier 变换恒等式
\[
 \widehat g_m(\xi)
 :=\int_{\mathbb R}g_m(t)e^{-i\xi t}\,dt
 =\int_0^\infty P_m(e^t)\cos(\xi t)\,dt
 =\Re\!\left[\zeta(i\xi)K_m(i\xi)\right].
\tag{3}
\]
常数约定与 note 172 相同；改变 Fourier 归一化只会乘一个正常数。

## 2. 原点为零排除全频非负

由 detector 的端点因子，\(V_m(1)=0\)，而 \(1\le c\le1\) 时只有
 \(c=1\)，所以
\[
 g_m(0)=\frac12P_m(1)=\frac12V_m(1)=0.
\tag{4}
\]
另一方面 \(P_m\not\equiv0\)：在 \(1<y<2\) 时
 \(P_m(y)=V_m(1/y)\)，而 \(V_m\) 是非零多项式（其 Mellin 变换 (1)
 非零），故 \(g_m\) 在一个开区间上不恒为零。

为避免额外要求 \(\widehat g_m\in L^1\)，取 Gaussian 正则化
\(\widehat g_{m,\varepsilon}(\xi)=\widehat g_m(\xi)e^{-\varepsilon\xi^2}\)。
因为 \(g_m\in L^1\)，\(\widehat g_m\) 有界；故对每个
\(\varepsilon>0\)，Gaussian 权下的 Fourier 积分绝对收敛，并且
\[
 (g_m*\varphi_\varepsilon)(0)
 =\frac1{2\pi}\int_{\mathbb R}
 \widehat g_m(\xi)e^{-\varepsilon\xi^2}\,d\xi
\longrightarrow g_m(0)=0
\quad(\varepsilon\downarrow0),
\tag{5}
\]
其中 \(\varphi_\varepsilon\) 是对应的 Gaussian approximate identity。
若假定 \(\widehat g_m(\xi)\ge0\) 对全部 \(\xi\in\mathbb R\)，则右侧积分非负，
且随 \(\varepsilon\downarrow0\) 单调增加；它的极限却是零，所以每个积分
都为零。连续性遂给出 \(\widehat g_m\equiv0\)，再由 Fourier 唯一性得
\(g_m\equiv0\)，矛盾。因此
\[
\boxed{\exists\,\xi_m\in\mathbb R:\quad
 \Re[\zeta(i\xi_m)K_m(i\xi_m)]<0.}
\tag{6}
\]
这对每个固定 \(m\ge1\) 都成立，不使用任何有限频率数值证书。

## 3. 任意有限线性组合也不能走普通 Bochner 正化

取任意有限实系数 \(a_1,\ldots,a_M\)，令
\[
 V=\sum_{m=1}^M a_mV_m,\qquad
 P=\sum_{m=1}^M a_mP_m,\qquad
 g=\sum_{m=1}^M a_m g_m.
\]
若 \(V\not\equiv0\)，则同样有 \(P(1)=0\)、\(g(0)=0\)，且在 \(1<y<2\)
 时 \(P(y)=V(1/y)\not\equiv0\)。每个 \(V_m\) 都满足 (2)，故 \(g\in L^1\)；
对 \(g\) 使用同一个 Gaussian 正则化反证给出
\[
 \boxed{\widehat g(\xi)=
 \Re\!\left[\zeta(i\xi)\sum_{m=1}^Ma_mK_m(i\xi)\right]
 \text{ 不可能全频非负}.}
\tag{7}
\]
唯一例外是 \(V\equiv0\) 的平凡组合。

## 4. 对 Weil/Schur 路线的含义

这排除了“选择一个 growing \(m\) detector，或固定有限线性组合，使
 log-Fourier/Mellin 符号成为全频非负，再直接使用 Bochner PSD Gram”的捷径。
note 172 中 \(V_{15}\) 在 \(\xi=2\) 的严格负值只是该结构性定理的一个
显式锚点，并非孤立数值现象。

要得到平方根级 signed 估计，必须保留至少一个不正定的结构：prime/reflection
非对角 block、parity Krein sign，或其他 genuine Feshbach cancellation。
普通全频 PSD 化即使在 detector 层级的任意有限混合中也不存在。

本文不声称 RH，也不排除带有额外非 Toeplitz signed compensation 的 Weil
算子分解。
