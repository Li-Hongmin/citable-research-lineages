> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正零频阻止有限频段正 Gram 的算子级节省

日期：2026-08-15。

本 note 链接 note 206/203，只给出一个严格的有限频段反例。
它不把一般向量结论外推到 Möbius 向量。

## 1. 低频 Gram 下界

若 \(w=|h|\) 且 \(h(0)>0\)，连续性给出某些 \(\delta,c>0\) 使
\[
w(t)\ge c\qquad(|t|\le\delta).
\tag{1}
\]
定义
\[
G_{N,\delta}[m,n]
=\frac1{2\pi}\int_{-\delta}^{\delta}
w(t)(m/n)^{it}\,dt,\qquad 1\le m,n\le N.
\tag{2}
\]
这是正半定 Gram。取 \(a_n=N^{-1/2}\)，则
\[
a^*G_{N,\delta}a
\ge\frac c{2\pi N}\int_{-\delta}^{\delta}
\left|\sum_{n\le N}n^{it}\right|^2dt.
\tag{3}
\]
对固定 \(\delta\)，Riemann 和在 \(|t|\le\delta\) 上一致满足
\[
N^{-1}\sum_{n\le N}n^{it}
=N^{it}\left(\frac1N\sum_{n\le N}(n/N)^{it}\right)
\quad\text{and}\quad
\left|\frac1N\sum_{n\le N}(n/N)^{it}\right|^2
\longrightarrow \frac1{1+t^2}.
\tag{4}
\]
因此
\[
\liminf_{N\to\infty}a^*G_{N,\delta}a
\ge\frac c{2\pi}\int_{-\delta}^{\delta}\frac{dt}{1+t^2}>0.
\tag{5}
\]
未归一化向量 \(a_n=1\) 给出二次型
\(\gg_{h,\delta}N^2\)，从而
\[
\boxed{\|G_{N,\delta}\|_{\rm op}\gg_{h,\delta}N.}
\tag{6}
\]

## 2. 边界

任何把 \(w\) 分解为有限个非负频段的方案，只要有一个频段包含
零的邻域，就继承 (6) 的线性算子范数下界；若全部频段避开零，则它们
不再重构当前 \(w=|h|\) 在零频的正质量。因此 PSD finite-band 分解不能
把一般向量的能量统一降到 \(O(N^\varepsilon)\) 算子界。

对实际 Möbius 向量，(6) 不给出下界；它只说明
\[
\int w(t)\left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt
\ll N^{1+\varepsilon}
\]
是新的 signed twisted-Mertens cancellation 命题，不能由 \(h(0)\)、
有限频段划分或正 Gram 谱分解自动推出。
