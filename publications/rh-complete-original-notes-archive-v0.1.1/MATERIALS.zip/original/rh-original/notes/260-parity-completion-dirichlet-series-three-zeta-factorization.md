> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Parity completion 的 Dirichlet 级数与 three-zeta 因子化

日期：2026-08-16。

本 note 把完整 squarefree parity completion 在固定 Mellin 频率上的
Euler 乘积进一步因子化。结果给出一个精确的 three-zeta 坐标，但它
仍然保留 \(1/\zeta(s)\) 的 RH 算术门；因此这是新的结构接口，而不是
RH 证明。

## 1. 固定频率的完整 squarefree 系数

令 \(t\in\mathbb R\)，并令
\[
a_X(t):=\mu(X)\prod_{p\mid X}(1-p^{-it})^2
\]
（\(X\) 只取 squarefree）。相应的 Dirichlet 级数为
\[
F(s,t):=\sum_{X\ {\rm squarefree}}a_X(t)X^{-s}
       =\prod_p\left[1-p^{-s}(1-p^{-it})^2\right],
\qquad \Re s>1.
\tag{1}
\]
这里的系数正是 note 259 式 (5) 中完整层
\[
\sum_{a,b\mid X}\mu(a)\mu(b)(ab)^{-it}
\]
再乘 parity 权 \(\mu(X)\) 后得到的系数。

## 2. 提取 three-zeta 主因子

写
\[
x=p^{-s},\qquad z=p^{-it}.
\]
定义
\[
G(s,t):=\frac{\zeta(s+it)^2}{\zeta(s)\zeta(s+2it)}.
\tag{2}
\]
其 \(p\)-局部因子为
\[
g_p(s,t)=\frac{(1-x)(1-xz^2)}{(1-xz)^2}.
\]
于是有逐素数的精确分解
\[
F(s,t)=G(s,t)R(s,t),
\tag{3}
\]
其中
\[
R(s,t)=\prod_p r_p(s,t),\qquad
r_p(s,t)=
\frac{[1-x(1-z)^2](1-xz)^2}
     {(1-x)(1-xz^2)}.
\tag{4}
\]

分子与分母的常数项及一次项完全抵消。直接展开得到
\[
[1-x(1-z)^2](1-xz)^2-(1-x)(1-xz^2)
=2z(1-z)^2x^2+O(x^3).
\tag{5}
\]
在 \(\Re s\ge \tfrac12+\eta\) 且 \(t\in\mathbb R\) 时，
\(|z|=1\)、\(x=O_\eta(p^{-1/2-\eta})\)，故
\[
r_p(s,t)=1+O_\eta(p^{-1-2\eta}).
\]
因此 \(R(s,t)\) 在半平面 \(\Re s>\tfrac12\) 上局部一致绝对收敛，
并在那里定义全纯函数。这里不声称 \(R\) 无零点：局部因子
\(1-x(1-z)^2\) 可能产生零点；可用的结论只是残余 Euler 乘积的
收敛性与全纯性。

综上，固定 \(t\) 的完整 parity 系数具有精确的形式
\[
\boxed{
F(s,t)=
\frac{\zeta(s+it)^2}{\zeta(s)\zeta(s+2it)}
R(s,t),
\qquad \Re s>1,
}
\tag{6}
\]
并由右侧解析延拓到 \(\Re s>\tfrac12\) 中避开显式 zeta 极点或零点的区域。
当 \(t=0\) 时 \(F(s,0)=R(s,0)=1\)，与
\(\zeta(s)^2/(\zeta(s)\zeta(s))=1\) 相符；这也说明零频率本身
不会产生新的 Möbius cancellation。

## 3. 与物理端完整层及 cutoff 的关系

若 \(P\) 有 Mellin--Fourier 表示
\[
P(y)=\frac1{2\pi}\int_{\mathbb R}H(t)y^{it}\,dt,
\]
则完整 squarefree parity completion 的频率端为
\[
\mathcal C_B^P(x)
=\frac1{2\pi}\int_{\mathbb R}H(t)x^{it}
\sum_{\substack{X\le B\\X\ {\rm squarefree}}}a_X(t)\,dt.
\tag{7}
\]
无截断的 Dirichlet 级数由 (6) 控制；有限 \(X\le B\) 的和则是其
部分和，不能直接替换成 \(F(s,t)\) 的值。更重要的是，原始
reciprocal-product 半格只包含 \(a,b\le\sqrt{x}\)，而完整
squarefree 层含有所有 \(a,b\mid X\)。因此 note 205 所述的
completion/boundary remainder 仍然存在，(6) 不会自动给出原半格的
平方根估计。

## 4. 路线裁决

这一步确实把 parity completion 的跨层算术门从一个形式 Euler 乘积
压缩为三个 zeta 因子的组合加一个在 \(\Re s>\tfrac12\) 收敛的残余：

* \(1/\zeta(s)\) 仍然直接存在；
* \(\zeta(s+it)^2/\zeta(s+2it)\) 只是在频率方向重新分配零点；
* 残余 \(R(s,t)\) 的收敛不消除 zeta 零点，也不解决 half-lattice
  cutoff completion。

所以当前最小未闭合命题仍是统一的 signed estimate：既要控制这些
three-zeta 系数的有限部分和，又要支付半格 completion。若能在
\(\Re s>\tfrac12\) 无条件得到所需平方根界，将立即进入 note 212
所述的 RH-equivalent 门；本 note 本身不提供该界。
