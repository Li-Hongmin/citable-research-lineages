> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 临界线上零点强迫有限尺度尾能量的指数至少为一

本 note 与 notes/403--404 配合，说明 \(Y^{1+\varepsilon}\) 尾能量指数在
\(P(z)=1-2z\) 的判据中不仅足以推出 RH，而且在幂次上已经不可再降。

## 命题

令 \(P\) 为固定有限尺度多项式，并令 \(E_P(Y)\) 与 note 402 一致。若存在无穷多个
\(\zeta\) 零点 \(\rho\) 满足
\[
\Re\rho=\frac12,
\qquad P(2^{-\rho})\ne0,
\tag{1}
\]
则不可能存在某个 \(\theta<1\)，使得对每个 \(\varepsilon>0\) 有
\[
E_P(Y)\ll_{P,\varepsilon}Y^{\theta+\varepsilon}.
\tag{2}
\]

特别地，对 \(P(z)=1-2z\)，条件 (1) 对每一个临界线上零点自动成立，因为
\[
|2^{-\rho}|=2^{-1/2}\ne\frac12.
\]
由于 Hardy 定理给出无穷多个临界线上零点，故该滤波器的能量指数必满足
\[
\inf\{\theta:E_P(Y)\ll_{\varepsilon}Y^{\theta+\varepsilon}\}\ge1.
\tag{3}
\]

## 证明

假设 (2) 对某个 \(\theta<1\) 成立。note 404 的 dyadic Cauchy--Schwarz 估计将
离散 Mellin 变换延拓到
\[
\Re z>\frac\theta2-1.
\tag{4}
\]
因为 \(\theta<1\)，右端界线严格位于 \(\Re z=-1/2\) 的左侧；于是所有满足
\(\Re\rho=1/2\) 的点 \(z=\rho-1\) 都落在 (4) 的全纯域内。但 note 402 的精确
恒等式给出
\[
\mathcal F_P(z)=\frac{P(2^{-(z+1)})}{\zeta(z+1)}.
\]
在满足 (1) 的零点处，右端有不可去极点，与 (4) 的全纯性矛盾。故
\(\theta<1\) 不可能。\(\square\)

结合 note 403，在 RH 下
\(E_P(Y)\ll_{P,\varepsilon}Y^{1+\varepsilon}\)，可见 \(P(z)=1-2z\) 的自然尾能量门
的临界幂次恰为一：既不能无条件降到该幂次，也不能在 RH 下把幂次降到小于一。
