> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 频率局部化不能消除正能量门的 Mellin 对偶代价

本 note 记录一个简单但严格的归一化障碍：把正频率权做成
\(N\)-依赖的宽频权、从而把其反 Fourier 核压到对角线，并不能仅靠
平凡对角估计推出 Möbius 平方根界。

## 1. 一个加权不确定性不等式

令 \(w\ge0\) 且 \(w\in L^1(\mathbb R)\)，并令 \(\Psi\) 满足
\(\Psi\in L^1\) 及 \(\Psi/\sqrt w\in L^2\)。Cauchy--Schwarz 给出

\[
\left(\int_{\mathbb R}|\Psi(t)|\,dt\right)^2
\le
\left(\int_{\mathbb R}w(t)\,dt\right)
\left(\int_{\mathbb R}\frac{|\Psi(t)|^2}{w(t)}\,dt\right).
\tag{1}
\]

若

\[
K(u)=\int_{\mathbb R}w(t)e^{itu}\,dt,
\]

则 \(K(0)=\int w\)，所以

\[
\boxed{
K(0)\,\|\Psi\|_{L^2(w^{-1})}^2
\ge \|\Psi\|_{L^1}^2 .
}
\tag{2}
\]

这个不等式与 \(w\) 是否依赖 \(N\) 无关。

## 2. 对“把核压到对角线”的含义

若选择 \(w_N\) 使 \(K_N(u)\) 集中在 \(|u|\lesssim N^{-1}\)，
则确实可以让一般系数向量的核二次型主要看见对角线；但 (2) 表明，
任何固定 Mellin 测试 \(\Psi\) 的对偶范数不能同时随 \(N\) 消失。
用平凡估计

\[
E_N(w_N)\le K_N(0)\sum_{m,n\le N}|\mu(m)\mu(n)|
\le K_N(0)N^2
\]

代入 Mellin Cauchy--Schwarz 后只得到

\[
|S_\psi(N)|^2
\le N^2K_N(0)\|\Psi\|_{L^2(w_N^{-1})}^2.
\]

由 (2)，这个 Cauchy 因子不能因局部化而趋于零；因此仅靠平凡对角估计
不能推出 \(N^{1/2+\varepsilon}\)。要改善这个量级，必须使用
\(\mu\) 的 signed cancellation；正权局部化本身不会制造它。

## 3. 对当前主线的裁决

因此，\(N\)-依赖 detector 的“窄核—平凡对角”捷径不能绕过
\(E_N(|h|)\ll N^{1+\varepsilon}\) 型算术门。任何成功的局部化方案还必须
同时给出一个统一的、零自由 Mellin 测试空间，并证明相应 Möbius 双线性
估计；这仍是 RH-strength 输入。

本文只是一个归一化不等式，不声称给出 RH 或排除所有带相位的
arithmetic intertwiner。
