> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Prime-free 奇扇区的半区正性改善与无不可见零核

日期：2026-08-11。本文使用 note 007 的真实极点分解、note 008 的约化纯跳表示及 note 012 的
秩一惯性分类，证明在第一个 prime-shift 阈值以前，首次退化的奇扇区不存在不可见约化零核。因此
该范围内的奇零模态严格等价于一个标量 Schur 等号。

## 1. 定理

令

\[
s(x)=\sinh(x/2),
\qquad
A_a^-=M_a^--2|s\rangle\langle s|.
\]

则

\[
\boxed{
0<a\le \frac{\log2}{2},\quad A_a^-\succeq0
\quad\Longrightarrow\quad
M_a^->0.}
\]

这里 \(M_a^->0\) 表示

\[
\inf\sigma(M_a^-)>0.
\]

因此在同一范围内，若 \(A_a^-\succeq0\)，则

\[
\boxed{
0\in\sigma(A_a^-)
\iff
1-2\langle(M_a^-)^{-1}s,s\rangle=0,}
\]

且发生等号时

\[
\ker A_a^-
=\operatorname{span}\{(M_a^-)^{-1}s\}.
\]

特别地，note 012 中的不可见分支

\[
\ker M_a^-\subset s^\perp
\]

在 prime-free 全范围内被排除。

## 2. 奇函数折叠到半区间

记

\[
k(t)=\frac{e^{-t/2}}{1-e^{-2t}},\qquad t>0.
\]

对 \(f\in L^2(0,a)\)，定义酉映射

\[
(U_-f)(x)=
\begin{cases}
2^{-1/2}f(x),&0<x<a,\\
-2^{-1/2}f(-x),&-a<x<0.
\end{cases}
\]

它把 \(L^2(0,a)\) 映到 \(L^2_{\rm odd}(-a,a)\)。连续纯跳能量为

\[
\mathcal E_a(u)
=\frac12\iint_{\mathbb R^2}
k(|x-y|)|u(x)-u(y)|^2\,dx\,dy,
\]

其中 \(u\) 在 \((-a,a)\) 外零延拓。先在光滑奇 core 上分解四个象限，再由闭包延拓，得到

\[
\boxed{
\begin{aligned}
\mathcal E_a^-(f)
={}&\frac12\int_0^a\int_0^a
K_-(x,y)|f(x)-f(y)|^2\,dx\,dy\\
&+\int_0^aV_-(x)|f(x)|^2\,dx,
\end{aligned}}
\]

其中

\[
K_-(x,y)=k(|x-y|)-k(x+y),
\]

\[
\boxed{
\begin{aligned}
V_-(x)
={}&\int_{a-x}^{\infty}k(t)\,dt
+\int_{a+x}^{\infty}k(t)\,dt\\
&+2\int_0^a k(x+y)\,dy>0.
\end{aligned}}
\]

承重代数恒等式为

\[
\frac12k(x+y)|f(x)+f(y)|^2
=-\frac12k(x+y)|f(x)-f(y)|^2
+k(x+y)(|f(x)|^2+|f(y)|^2).
\]

其中最后一个积分产生的 killing 势不能省略。

## 3. 半区间半群 positivity improving

直接微分得

\[
k'(t)
=-\frac{e^{-t/2}(1+3e^{-2t})}
{2(1-e^{-2t})^2}<0.
\]

对 \(x,y\in(0,a)\)、\(x\ne y\)，

\[
|x-y|<x+y,
\]

故

\[
\boxed{K_-(x,y)>0\quad\text{a.e. on }(0,a)^2.}
\]

闭性由完整奇形式经 \(U_-\) 的酉等价继承；显式表示中的 \(K_-\ge0\) 与 \(V_-\ge0\) 给出
normal-contraction Markov 性。若 \(B\subset(0,a)\) 是非平凡不变集，则对分别支撑于 \(B,B^c\)
的非零 \(f,g\ge0\)，不变集判据要求交叉形式为零，但

\[
\mathcal E_a^-(f,g)
=-\int_B\int_{B^c}K_-(x,y)f(x)g(y)\,dx\,dy<0.
\]

矛盾。因此半区形式不可约，相应半群 positivity improving。约化形式与该纯跳形式只相差标量倍
\(L^2\) 范数，故

\[
\boxed{e^{-tM_a^-}\text{ 在半区正锥上 positivity improving}.}
\]

## 4. 阈值等号

当 \(2a<\log2\) 时没有 prime-power shift。当

\[
2a=\log2,
\]

唯一刚出现的 \(n=2\) 位移等于区间直径。零延拓函数与其 \(2a\)-平移仅在端点相交，因而

\[
\langle\tau_{2a}u,u\rangle=0,
\qquad
\|u-\tau_{2a}u\|_2^2=2\|u\|_2^2.
\]

prime jump 的 \(2\alpha_2\|u\|^2\) 与约化形式常数中的
\(-2\alpha_2\|u\|^2\) 精确抵消。因此半区表示和 positivity improving 结论在

\[
0<a\le\frac12\log2
\]

上均成立，阈值包含等号。

## 5. 排除不可见奇零核

假设 \(A_a^-\succeq0\)。由真实奇秩一符号，

\[
M_a^-=A_a^-+2|s\rangle\langle s|\succeq0.
\]

若 \(0\ne u\in\ker M_a^-\)，则 \(0\) 是 \(M_a^-\) 的奇扇区谱底。紧预解式与半区 positivity
improving 迫使其半区基态在乘一个常相位后满足

\[
f=U_-^*u>0\quad\text{a.e.}
\]

又因 \(\sinh(x/2)>0\) 于 \((0,a)\)，

\[
\langle u,s\rangle
=\sqrt2\int_0^af(x)\sinh(x/2)\,dx>0.
\]

另一方面，

\[
0
=\langle M_a^-u,u\rangle
=\langle A_a^-u,u\rangle
+2|\langle u,s\rangle|^2
\]

强制 \(\langle u,s\rangle=0\)，矛盾。因此

\[
\ker M_a^-=\{0\}.
\]

紧预解式与 \(M_a^-\succeq0\) 再给出

\[
\inf\sigma(M_a^-)>0.
\]

标准秩一 Schur 补随即给出第 1 节的标量等价和一维核公式。

## 6. 结果边界

本文排除的是

\[
A_a^-\succeq0
\]

背景下的 prime-free 奇扇区不可见核；它没有证明 Schur 标量严格为正，也没有处理

\[
a>\frac12\log2
\]

时反射 prime-shift 在半区产生的符号相反原子。下一项奇扇区承重点已经从“cyclicity 加标量”缩短为

\[
\boxed{
1-2\langle(M_a^-)^{-1}s,s\rangle>0
\quad
\left(0<a\le\tfrac12\log2\right).}
\]

承重来源为 Masatoshi Suzuki, *Weil's quadratic form via the screw function*,
[arXiv:2606.09096](https://arxiv.org/abs/2606.09096) 的局部 Weil 形式；极点签名与约化纯跳表示分别见
[note 007](007-indefinite-polar-splitting-and-reduced-markov-form.md) 和
[note 008](008-reduced-ground-state-and-odd-spectral-gap.md)。半区折叠、严格核差与无不可见奇零核是本文
对这些公式的新推论。
