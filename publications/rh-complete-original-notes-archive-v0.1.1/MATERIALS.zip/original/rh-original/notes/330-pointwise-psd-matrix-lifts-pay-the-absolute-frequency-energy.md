> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 逐频率 PSD 矩阵提升的最小代价

日期：2026-08-16。

本 note 判定一个自然的“矩阵提升”捷径：把有符号的 reciprocal
Hankel 项 \(h(\xi)F_N(\xi)^2\) 放进一个逐频率正半定 \(2\times2\)
矩阵，希望既保留相位信息又获得正能量估计。结论是，若提升逐频率
保持原来的 off-diagonal 系数，它至少支付同等大小的
\(|h(\xi)|\,|F_N(\xi)|^2\) 对角能量；这正是已有的 RH-equivalent 正能量门。

## 1. 代数命题

令 \(b(\xi)\in\mathbb C\)，并考虑 Hermitian 矩阵
\[
 \mathcal M(\xi)=
 \begin{pmatrix}a(\xi)&b(\xi)\\
 \overline{b(\xi)}&c(\xi)\end{pmatrix},
 \qquad a,c\in\mathbb R.
\]
逐点正半定等价于
\[
 a\ge0,\qquad c\ge0,\qquad a c\ge |b|^2.
\tag{1}
\]
对向量 \(v=(z,\overline z)^T\)，其二次型为
\[
 v^*\mathcal Mv=(a+c)|z|^2
       +2\operatorname{Re}(b\,\overline z^{\,2}).
\tag{2}
\]
由算术--几何平均和 (1)，
\[
 a+c\ge 2\sqrt{ac}\ge2|b|.
\tag{3}
\]
因此在保持给定 off-diagonal \(b\) 的所有逐频率 PSD 提升中，
对角质量的最小值是 \(2|b|\,|z|^2\)，且由
\[
 \mathcal M_{\min}=|b|
 \begin{pmatrix}1&e^{i\arg b}\\
 e^{-i\arg b}&1\end{pmatrix}
\tag{4}
\]
达到。逐频率 PSD 化不能免费保留一个 signed square；它必然同时加入
同量级的 modulus-square channel。

## 2. 应用于 reciprocal detector

对实 Möbius 截断
\[
 F_N(\xi)=\sum_{n\le N}\mu(n)n^{i\xi},
\]
原始 product/Hankel 通道的实部可写成
\[
 Q_h(N)=\frac1{2\pi}\int h(\xi)
       \operatorname{Re}\!\big(F_N(\xi)^2\big)\,d\xi.
\tag{5}
\]
若一个逐频率 PSD 矩阵提升要求 (2) 的 off-diagonal 正好重构 (5)，
则取 \(b=h\)（或取其共轭，不影响绝对值）。由 (3)，其二次型至少含有
\[
 \frac1\pi\int |h(\xi)|\,|F_N(\xi)|^2d\xi.
\tag{6}
\]
常数因约定可变，但权正是已有的
\(w(\xi)=|h(\xi)|/(2\pi)\) 正能量权。

当前 endpoint-flat detector 满足 \(h(0)>0\) 且
\(\int(1+\xi^2)|h(\xi)|\,d\xi<\infty\)。因此 note 212/246 的严格结果适用：
\[
 \forall\varepsilon>0,\quad
 \int |h(\xi)|\,|F_N(\xi)|^2d\xi
 \ll_\varepsilon N^{1+\varepsilon}
 \quad\Longleftrightarrow\quad \mathrm{RH}.
\tag{7}
\]
所以任何逐频率、uniform-in-\(N\) 的 PSD 矩阵提升，只要其估计足以
控制原 off-diagonal channel 到平方根尺度，就已经是 RH 的另一种表述；
它不是绕开 RH 的弱化证明。

## 3. 何时该判定不适用

本结论只排除“逐频率 PSD + 原 off-diagonal 系数”的局部矩阵化。
它不排除两类真正不同的对象：

1. 在不同频率之间保留 signed cancellation 的非局部算术算子；
2. 改变 off-diagonal 系数并另行证明一个新的 arithmetic intertwiner。

但第一类对象不再是逐频率正 Gram，第二类对象必须说明它如何恢复
原 \(1/\zeta\) 通道。正 periodization 的因果/偶卷积分叉（note 329）
表明，仅凭正卷积本身不能完成这两点。

## 4. 结论

“把 \(hF_N^2\) 嵌入一个 \(2\times2\) PSD 矩阵”确实可作形式恒等式，
例如矩阵 (4)；但它的最小对角补偿恰为 \(|h||F_N|^2\)。于是矩阵提升
没有产生新的算术不等式，只是把 signed Hankel 门显式退化为 note 212
的正能量门。要取得 RH 之外的新信息，必须提供跨频率的 signed
intertwiner，而不是继续增加逐频率 PSD 通道。
