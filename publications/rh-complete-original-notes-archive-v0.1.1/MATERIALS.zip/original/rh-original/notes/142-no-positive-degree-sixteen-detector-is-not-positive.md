> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 更正通知：撤回旧的次数十五 no-go 草稿

日期：2026-08-15。

此路径对应的旧草稿把非整数 y 的截断和误作 Faulhaber 的解析延拓，因而其
“次数十五不正”的符号结论无效，现正式撤回。定义中必须先取 N=floor(y)，再在
y=N+r 上使用移位 Faulhaber 恒等式。

正确结果见 [note 144](144-a-positive-degree-fifteen-detector-removes-four-collective-residues.md)：
次数十五确有全半轴正 detector；更高次数十六的独立正 detector 见
[note 143](143-a-positive-degree-sixteen-detector-removes-four-collective-residues.md)。
