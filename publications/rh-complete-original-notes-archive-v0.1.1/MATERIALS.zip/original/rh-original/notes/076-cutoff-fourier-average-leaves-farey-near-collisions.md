> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# cutoff Fourier 平均保留 Farey near-collisions

日期：2026-08-13。

依赖：[note 069](069-gcd-completion-cancels-the-fixed-slice-antidiagonal.md)、
[note 070](070-sawtooth-cell-boundaries-add-instead-of-telescope.md)、
[note 074](074-mellin-poles-force-dyadic-mean-shell-growth.md)。

## 1. 弄清问题

新目标是

\[
\sum_{Y<N\le2Y}I_N\ll_\varepsilon Y^{3+\varepsilon}.
\tag{1}
\]

单个 \(N\) 的 Bernoulli Fourier kernel 含

\[
\Delta:=\frac hd-\frac ke=\frac{he-kd}{de}.
\tag{2}
\]

本 note 只判别：对 endpoint/cutoff \(N\) 再求和，是否自动补回所缺的一整幂。

```mermaid
flowchart LR
  A["sum over cutoff N"] --> B["endpoint difference S(2Δ)-S(Δ)"]
  B --> C["|Δ|≫1/Y: decay"]
  B --> D["|Δ|≤1/Y: kernel ≍Y²"]
  D --> E["0<|he-kd|≤de/Y"]
  E --> F["one power still missing"]
```

## 2. 精确 \(N\)-average kernel

固定 \(d,e,h,k\)，令

\[
A:=\max(Y+1,d,e),
\qquad B:=2Y,
\tag{3}
\]

\[
\nu_{d,e}(x):=
\frac{\log(x/d)\log(x/e)}{\log^2x}.
\tag{4}
\]

对应 Fourier 模在 \(N\)-sum 中的标量核为

\[
\mathscr P_{A,B;\nu}(\Delta)
:=\sum_{N=A}^BN\nu_{d,e}(N)\Phi(N\Delta),
\qquad
\Phi(\xi):=\int_1^2e(\xi t)dt.
\tag{5}
\]

因为

\[
N\Phi(N\Delta)
=\frac{e(2N\Delta)-e(N\Delta)}{2\pi i\Delta},
\tag{6}
\]

故有精确公式

\[
\boxed{
\mathscr P_{A,B;\nu}(\Delta)
=
\begin{cases}
\displaystyle\sum_{N=A}^BN\nu_{d,e}(N),&\Delta=0,\\[1ex]
\displaystyle\frac{S_\nu(2\Delta)-S_\nu(\Delta)}{2\pi i\Delta},&\Delta\ne0,
\end{cases}
}
\tag{7}
\]

其中

\[
S_\nu(\theta):=\sum_{N=A}^B\nu_{d,e}(N)e(N\theta).
\tag{8}
\]

Selberg taper 随 \(N\) 的变化没有幂次增益。事实上

\[
\nu'_{d,e}(x)
=\frac{\log d+\log e}{x\log^2x}
-\frac{2\log d\log e}{x\log^3x},
\tag{9}
\]

所以在 \(x\asymp Y\) 上

\[
\|\nu\|_\infty\le1,
\qquad
\operatorname{Var}\nu\ll\frac1{\log Y}.
\tag{10}
\]

分部求和只给

\[
|S_\nu(\theta)|
\ll\min\!\left(Y,\|\theta\|^{-1}\right).
\tag{11}
\]

## 3. 唯一整幂阻塞区

当 \(|\Delta|\le1/4\) 时，(7)--(11) 给出

\[
\boxed{
|\mathscr P_{A,B;\nu}(\Delta)|
\ll\min(Y^2,|\Delta|^{-2}).
}
\tag{12}
\]

更精确地，若 \(|\Delta|Y\ll1\)，则

\[
\mathscr P_{A,B;\nu}(\Delta)
=\sum_{N=A}^BN\nu_{d,e}(N)
+O(|\Delta|Y^3),
\tag{13}
\]

所以

\[
\boxed{
0<|he-kd|\lesssim\frac{de}{Y}
\quad\Longrightarrow\quad
\mathscr P\asymp Y^2
}
\tag{14}
\]

在固定 high block 上没有 \(N\)-相消。\(N\)-平均只解决远碰撞；它只是一个 endpoint
Dirichlet 核差，不是第二个独立振荡变量。

## 4. exact resonance 已安全

\(\Delta=0\) 的全部表示聚合为

\[
\sum_{\substack{h,k\ne0\\h/d=k/e}}
\frac1{4\pi^2hk}
=\frac{(d,e)^2}{12de}.
\tag{15}
\]

因此其 cutoff 总贡献为

\[
\sum_{Y<N\le2Y}\frac N{12}Q_2(N),
\tag{16}
\]

而 note 069 已证明

\[
Q_2(N)\ll\frac{N\log\log(3N)}{\log N}.
\tag{17}
\]

故

\[
\boxed{
\sum_{Y<N\le2Y}\frac N{12}Q_2(N)
\ll\frac{Y^3\log\log Y}{\log Y},
}
\tag{18}
\]

已满足 (1)。未知部分严格为非零 Farey near-collisions (14)。

## 5. 普通 spacing/large sieve 的尖锐缺口

聚合同频表示，写

\[
F_N(y)=\sum_\alpha b_{\alpha,N}e(\alpha y).
\tag{19}
\]

分母不超过 \(N\) 的不同有理频率只保证

\[
|\alpha-\alpha'|\ge N^{-2}.
\tag{20}
\]

连续 large sieve 因而给出

\[
\int_N^{2N}|F_N(y)|^2dy
\ll(N+N^2)\sum_\alpha|b_{\alpha,N}|^2
\ll N^2Q_2(N),
\tag{21}
\]

从而

\[
\boxed{
\sum_{Y<N\le2Y}I_N^{(\ne0)}
\ll\frac{Y^4\log\log Y}{\log Y}
=Y^{4+o(1)}.
}
\tag{22}
\]

这对纯 spacing 方法是尖锐的。取

\[
h=k=1,
\qquad
d,e\in[\alpha Y,\eta Y],
\qquad0<\alpha<\eta<1;
\tag{23}
\]

则全部 \(Y^2\) 个有序对都满足

\[
\left|\frac1d-\frac1e\right|\lesssim Y^{-1},
\tag{24}
\]

且非对角核保持 \(Y^{2+o(1)}\)。普通 Dirichlet-kernel 优化无法从 (22) 再省一幂。

## 6. packetwise 路线的最小 PSD 原子

固定 \(I=[\alpha,\eta]\Subset(0,1)\)，只观察 \(h=k=1\) packet。令

\[
u=d/Y,
\qquad v=e/Y.
\tag{25}
\]

其主尺度核为

\[
W_I(u,v)
:=\int_1^2x\log(x/u)\log(x/v)
\Phi\!\left(x\left(\frac1u-\frac1v\right)\right)dx.
\tag{26}
\]

任何逐 Fourier-packet 的正估计若要达到 (1)，必须至少证明

\[
\boxed{
\sum_{d,e\in IY}\mu(d)\mu(e)W_I(d/Y,e/Y)
\ll Y^{1+o(1)};
}
\tag{27}
\]

spacing 只给 \(Y^{2+o(1)}\)。而该核本身为 PSD：

\[
\begin{aligned}
&\sum_{d,e\in IY}\mu(d)\mu(e)W_I(d/Y,e/Y)\\
&\quad=
\int_1^2\int_1^2x
\left|
\sum_{d\in IY}\mu(d)
\log\frac{xY}{d}
e\!\left(\frac{xtY}{d}\right)
\right|^2dt\,dx.
\end{aligned}
\tag{28}
\]

因此 (27) 仍是宏观区间上的 smooth reciprocal weighted-Mertens 平方根均方，不是新的
endpoint 正交。这里的 (27) 只是 **packetwise 估计策略** 的必要输入；完整 Bernoulli packet
仍可能在不同 \(h\) 之间发生联合抵消，不能把单 packet 当作原能量的下界。

## 7. 回顾

\[
\boxed{
N\text{-average}
\Rightarrow
\text{far collisions decay}
\quad\text{but}\quad
0<|he-kd|\lesssim de/Y
\text{ retains the full power gap}.
}
\tag{29}
\]

所以继续优化普通 large sieve、Farey spacing 或 endpoint Dirichlet 核不会改变下一步。若沿
Fourier 路线继续，只能：

\[
\text{证明 (27) 的 Möbius square-root mean}
\quad\text{或}\quad
\text{保留全部 }h\text{ 后寻找跨 packet 消去}.
\tag{30}
\]

本 note 没有完成任一输入，因而没有证明 RH。
