> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 截断倍数链的精确不完全 Möbius 除数 residual

日期：2026-08-17。

note 457 给出完整倍数链的 completion。本 note 把任意截断链与完整链之间的差写成显式不完全 Möbius 除数和。

## 1. 截断链的逐行公式

令

$$
M_d=\left\lfloor\frac Nd\right\rfloor,
\qquad C_{d,A}=\sum_{a=1}^{A}e_{ad},
\qquad 1\le A\le M_d.
$$

将 n=aj 代入 T_N 的定义，得到

$$
(T_NC_{d,A})_k
=\frac{\sqrt{2k+1}}d
\sum_{\lfloor k/d\rfloor<n\le M_d}
\frac1n\sum_{\substack{a\mid n\\a\le A}}\mu(n/a).
\tag{1}
$$

定义不完全除数系数

$$
\eta_A(n):=\sum_{\substack{a\mid n\\a>A}}\mu(n/a).
\tag{2}
$$

利用完整除数和 \(\sum_{a\mid n}\mu(n/a)=\mathbf1_{n=1}\)，且 A≥1，有精确 residual

$$
\boxed{
R_Ne_d-T_NC_{d,A}
=\frac{\sqrt{2k+1}}d
\sum_{\substack{\max(A,\lfloor k/d\rfloor)<n\le M_d}}
\frac{\eta_A(n)}n.
}
\tag{3}
$$

右侧只含 n>A 的不完全 Möbius 除数和。令 \(\mathcal R_{d,A}:=R_Ne_d-T_NC_{d,A}\)，则

$$
\boxed{
\|\mathcal R_{d,A}\|_2^2
=\frac1{d^2}\sum_{k=1}^{N-1}(2k+1)
\left(\sum_{\substack{\max(A,\lfloor k/d\rfloor)<n\le M_d}}
\frac{\eta_A(n)}n\right)^2.
}
\tag{4}
$$

OMEN 用精确有理数核验了 N=20,31,64 的全部 d,A,k。

## 2. 两条截断链的精确展开

由完整链式与 (3)，两条截断链的 Gram completion 满足

$$
\begin{aligned}
\sum_{a\le A}\sum_{b\le B}(G_N)_{ad,be}
&=\langle R_Ne_d-\mathcal R_{d,A},R_Ne_e-\mathcal R_{e,B}\rangle\\
&=\frac{(\min(d,e)^2-1)_+}{de}
-\langle R_Ne_d,\mathcal R_{e,B}\rangle
-\langle\mathcal R_{d,A},R_Ne_e\rangle
+\langle\mathcal R_{d,A},\mathcal R_{e,B}\rangle.
\end{aligned}
\tag{5}
$$

完整链的正几何项正是 note 457 的右端；所有截断误差被分解成两个线性边界项和一个 residual Gram 项。

## 3. 算术缺口

若取 A 接近平方根尺度，式 (3) 的 residual 支持集中在大于该尺度的 n 上，但 η_A(n) 是不完全除数 Möbius 和，不能由普通正性或逐项 Cauchy 自动变小。要得到平方根级 completion 误差，至少需要对这些 η_A(n) 的加权平方和及两条边界交叉项建立统一 signed 估计。

这把截断倍数 completion 严格改写为不完全 Möbius 除数相关问题；它不提供 RH 证明，但排除了把 completion 误差当作未定义的低阶边界项。
