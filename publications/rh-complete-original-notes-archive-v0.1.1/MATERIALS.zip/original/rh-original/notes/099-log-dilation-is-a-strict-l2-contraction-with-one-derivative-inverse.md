> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 对数 dilation 是严格 \(L^2\) contraction，其反演必损失一阶导数

日期：2026-08-14。

依赖：
[note 097](097-continuous-log-dilation-removes-the-endpoint-without-losing-the-detector.md)、
[note 098](098-continuous-scale-mean-square-is-an-exact-mellin-hardy-rh-criterion.md)。

证据等级：精确积分核、Fourier 乘子范数与有限壳反例。本文确定
note 097 的 endpoint-free gate 在软 \(L^2\) 意义下确实比原始 gate 弱，
但不改变其 RH 零点探测能力。

## 1. 连续平均与精确 leakage 核

固定 \(R>1\)，令 \(L=\log R\)，并在实尺度上定义

\[
\boxed{
(\mathcal A_RU)(x)
:=\frac1L\int_1^R U(\lambda x)\frac{d\lambda}{\lambda}
=\frac1L\int_x^{Rx}U(t)\frac{dt}{t}.
}
\tag{1}
\]

对 note 098 的 \(U\)，逐项 Fubini 给出

\[
(\mathcal A_RU)(x)
=\sum_{d\ge1}\mu(d)G_R(d/x),
\qquad
(\mathcal A_RU)(N)=S_{N,R}.
\tag{2}
\]

置

\[
M_U(Y):=\frac1Y\int_Y^{2Y}|U(x)|^2\,dx.
\tag{3}
\]

Minkowski 不等式与对概率测度 \(d\lambda/(L\lambda)\) 的 Jensen
不等式分别给出

\[
\boxed{
M_{\mathcal A_RU}(Y)^{1/2}
\le\frac1L\int_1^R M_U(\lambda Y)^{1/2}
\frac{d\lambda}{\lambda},
}
\tag{4}
\]

\[
\boxed{
M_{\mathcal A_RU}(Y)
\le\frac1L\int_1^R M_U(\lambda Y)
\frac{d\lambda}{\lambda}.
}
\tag{5}
\]

若 \(U\) 在整个 leakage 区间上为常数，则取等，故 (4)--(5) 的常数
\(1\) 不能改善。

另一方面，在 (1) 中先用 Cauchy--Schwarz，再交换 \(x,t\)
积分，得到精确的正 leakage 界

\[
\boxed{
\int_Y^{2Y}|\mathcal A_RU(x)|^2\,dx
\le\frac1L\int_Y^{2RY}|U(t)|^2
\frac{\ell_{Y,R}(t)}{t}\,dt,
}
\tag{6}
\]

其中

\[
\ell_{Y,R}(t)
:=\bigl[\min(2Y,t)-\max(Y,t/R)\bigr]_+.
\tag{7}
\]

## 2. \(L^2(dx)\) 上的精确严格 contraction

变量代换 \(x=e^y\) 下的幺正共轭是

\[
V(y):=e^{y/2}U(e^y),
\qquad
\|V\|_{L^2(dy)}=\|U\|_{L^2(dx)}.
\tag{8}
\]

在该坐标中，\(\mathcal A_R\) 的 Fourier 乘子为

\[
m_R(\xi)
=\frac1L\int_0^L e^{-t/2}e^{i\xi t}\,dt
=\frac{R^{-1/2+i\xi}-1}{(-1/2+i\xi)L}.
\tag{9}
\]

三角不等式在 \(\xi=0\) 取等，因而

\[
\boxed{
\|\mathcal A_R\|_{L^2(dx)\to L^2(dx)}
=\kappa_R
:=\frac{2(1-R^{-1/2})}{\log R}<1.
}
\tag{10}
\]

对任意 \(U\)，\(\mathcal A_RU\) 在 \([Y,2Y]\) 上只依赖 \(U\) 在
\([Y,2RY]\) 上的值。将 \(U\) 在这个区间外截断后应用 (10)，得

\[
\boxed{
\int_Y^{2Y}|\mathcal A_RU(x)|^2\,dx
\le\kappa_R^2\int_Y^{2RY}|U(x)|^2\,dx.
}
\tag{11}
\]

若 \(J=\lceil\log_2R\rceil\)，则右边可再以

\[
\kappa_R^2\sum_{j=0}^{J}
\int_{2^jY}^{2^{j+1}Y}|U(x)|^2\,dx
\tag{12}
\]

控制。故原始 dyadic gate 软性地推出平滑 gate。

## 3. 任意有限壳反向界都失败

给定任意有限个被观测的 dyadic shells \(I_j=[Y_j,2Y_j]\)。选取
\(\chi\in C_c^\infty(0,\infty)\)，使它在所有 \([Y_j,2RY_j]\) 上等于 \(1\)，
并令

\[
\xi=\frac{2\pi}{L},
\qquad
U(x)=\chi(x)x^{i\xi}.
\tag{13}
\]

对每个 \(x\in I_j\)，

\[
(\mathcal A_RU)(x)
=x^{i\xi}\frac{e^{i\xi L}-1}{i\xi L}=0,
\tag{14}
\]

但 \(U\) 在每个 \(I_j\) 上非零。取实部还可得实值反例。所以不存在
任何固定 \(C,J\) 的通用不等式

\[
M_U(Y)\le C\sum_{|j|\le J}M_{\mathcal A_RU}(2^jY).
\tag{15}
\]

即使将精确核 (14) 限制在 \(\Re s=0\)，正半平面仍然存在高频近核。
对任意固定 \(\sigma>0\)，取

\[
t_n=\frac{2\pi n}{L},
\qquad
U_n(x)=\chi(x)x^{\sigma+it_n}.
\tag{16}
\]

在所有被观测壳上，

\[
\mathcal A_RU_n
=b_R(\sigma+it_n)U_n,
\qquad
b_R(s):=\frac{R^s-1}{sL},
\tag{17}
\]

且

\[
|b_R(\sigma+it_n)|
=\frac{R^\sigma-1}{L\sqrt{\sigma^2+t_n^2}}
=O_{R,\sigma}(n^{-1}).
\tag{18}
\]

因而任何仅用有限个相邻输出壳的反向常数都被 \(n\to\infty\)
击穿。平滑 gate 不是原始 gate 的有界可逆改写。

## 4. 精确的一阶导数反演

对 (1) 的两个变上限求导，得

\[
\boxed{
Lx(\mathcal A_RU)'(x)=U(Rx)-U(x).
}
\tag{19}
\]

在加权空间

\[
H_\sigma:=L^2\!\left((0,\infty),x^{-2\sigma-1}dx\right),
\qquad \sigma>0,
\tag{20}
\]

缩放满足

\[
\|U(R\,\cdot)\|_{H_\sigma}=R^\sigma\|U\|_{H_\sigma}.
\tag{21}
\]

将 (19) 与反三角不等式结合，得到

\[
\boxed{
\|U\|_{H_\sigma}
\le\frac{\log R}{R^\sigma-1}
\|x(\mathcal A_RU)'\|_{H_\sigma}.
}
\tag{22}
\]

(18) 说明没有导数的同类反向界必然失败，而 (22) 说明一阶
对数导数已经足够。因而对数均匀 dilation 精确增加了一阶对数平滑。

## 5. 结论边界

note 097 的平滑 gate 在 raw dyadic \(L^2\) 上严格更弱：它是严格
contraction，有精确对数周期核与正半平面高频近核，并且反演必损失
一阶导数。另一方面，\(b_R(s)\ne0\;(\Re s>0)\)，所以每个
\(\Re\rho>1/2\) 的离线零点仍产生不可消去的 Mellin 极点。平滑 gate
之所以仍与 RH 等价，依靠的是这个非消零性，而不是有限壳范数的
软反向控制。
