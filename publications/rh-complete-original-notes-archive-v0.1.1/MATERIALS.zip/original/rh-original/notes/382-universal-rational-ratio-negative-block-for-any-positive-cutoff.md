> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 任意非零正 cutoff 核的平方自由有理比负块

## 命题

设 \(\phi:[0,\infty)\to\mathbb R\) 连续、满足
\[
\phi(u)=0\quad(u\ge1),\qquad \phi(0)=0,\qquad \phi\ge0,
\]
且 \(\phi\not\equiv0\) 于 \((0,1)\)。则存在互素平方自由整数 \(r,q\)、
\(0<r<q\)，使 \(\phi(r/q)>0\)。对任意固定 \(k\ge1\)，存在一列
\[
X_t=qrY_t,\qquad
Y_t=\prod_{i=1}^k \ell_i(t),
\]
其中 \(Y_t\) 与 \(qr\) 互素、\(\ell_i(t)\) 为超分离奇素数，使得在除数子集
\[
\mathcal I_t=\{rs:s\mid Y_t\}\subset D_{X_t}
\]
上的 reciprocal 矩阵
\[
H_t(rs,rt)=\phi\!\left(\frac{r^2st}{qrY_t}\right)
\]
满足
\[
H_t\longrightarrow \phi(r/q)\,R_k
\tag{1}
\]
（算子范数收敛）。故
\[
n_-(H_t)\ge2^{k-1}
\tag{2}
\]
对充分大的 \(t\) 成立。

## 有理比的存在

取 \(\phi(u_*)>0\) 的小区间 \(I\Subset(0,1)\)。平方自由整数具有正密度
\(6/\pi^2\)，所以先取足够大的素数 \(q\)，再在区间 \(qI\) 中选取平方自由
\(r\)；可令 \(r<q\)，且 \((r,q)=1\)。于是 \(r/q\in I\) 且
\(\phi(r/q)>0\)。

## 超分离极限

对 \(s=\prod_{i\in A}\ell_i\)、\(t=\prod_{i\in B}\ell_i\)，有
\[
\frac{r^2st}{qrY_t}
=\frac rq\,
 \frac{\prod_{i\in A\cap B}\ell_i}
      {\prod_{i\notin A\cup B}\ell_i}.
\tag{3}
\]
若 \(B=A^c\)，则第二因子为 1，条目恰为 \(\phi(r/q)\)。若
\(B\ne A^c\)，选择同时出现在分子或分母中的最大指标，并令
\(\ell_{i+1}>(\ell_1\cdots\ell_i)^t\)，则第二因子趋于 0 或 \(+\infty\)。
由 \(\phi(0)=0\) 及 \(\phi|_{[1,\infty)}=0\)，其条目趋于 0。因
\(\dim\mathcal I_t=2^k\) 固定，得到 (1)。

补集反射 \(R_k\) 的正负特征空间各维 \(2^{k-1}\)，从而 (2) 由 Weyl 扰动不等式
得到。此结论适用于任意非零正 cutoff 核，而非只适用于
\(\phi(1/2)>0\) 的特殊情形。

## 实际 Möbius 模式

在同一子集上取
\[
v_t(rs)=\mu(rs)=\mu(r)\mu(s).
\]
由于 \(R_kv_t=(-1)^kv_t\) 且 \(\|v_t\|_2^2=2^k\)，有
\[
\boxed{
v_t^\top H_t v_t\longrightarrow
(-1)^k\,2^k\phi(r/q).}
\tag{4}
\]
将 \(v_t\) 零延拓到完整 \(D_{X_t}\)，它仍是完整 reciprocal 矩阵的合法测试向量。
因此奇数 \(k\) 时，任意非零正 cutoff 核都在实际 Möbius parity 模式上产生指数大小
的负门；把核在 \(1/2\) 处置零并不能消除这一障碍，只会把负比移到另一个平方自由有理点。

该命题不声称 RH；它严格排除“选择特殊零点/特殊 beta 核即可恢复 full PSD”
的普适路线，剩余仍是带 parity 的 signed intertwiner。

