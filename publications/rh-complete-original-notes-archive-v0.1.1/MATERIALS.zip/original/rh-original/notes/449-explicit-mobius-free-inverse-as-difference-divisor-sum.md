> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(B_N^{-1}\) 的显式差分—除数和公式

日期：2026-08-17。

note 448 把近似列消去压缩为

\[
\alpha-\mathbf1_{N-1}=B_N^{-1}\rho.
\]

本 note 将右侧完全展开为“归一化行差分先取一次，再作除数和”。这给出近似桥的第一个逐坐标可审计公式。

## 1. 归一化残差与一次差分

令 \(\rho=(\rho_1,\ldots,\rho_{N-1})^{\mathsf T}\)，并定义

\[
z_k:=\frac{\rho_k}{\sqrt{2k+1}},
\qquad 1\le k<N.
\]

对原除数指标 \(e=2,\ldots,N\)，定义

\[
\Delta_e(z):=
\begin{cases}
e\bigl(z_{e-1}-z_e\bigr),&2\le e<N,\\[2mm]
Nz_{N-1},&e=N.
\end{cases}
\tag{1}
\]

这里最后一项是上三角矩阵 \(U_N^{-1}\) 的末端边界项，不能省略。

## 2. 精确差分—除数和

由 note 448 的分解

\[
B_N
=\operatorname{diag}\bigl(\sqrt{2k+1}\bigr)\,
U_N\,
\operatorname{diag}\bigl((e)^{-1}\bigr)\,
\bigl(D_N^{-1}\bigr)_{2:N,2:N},
\]

及

\[
(U_N^{-1})_{k,j}=\mathbf1_{j=k}-\mathbf1_{j=k+1},
\]

可得

\[
\boxed{
\bigl(B_N^{-1}\rho\bigr)_d
=\sum_{\substack{e\mid d\\e\ge2}}\Delta_e(z),
\qquad 2\le d\le N.
}
\tag{2}
\]

因此任意近似列消去

\[
T_Ne_1+B_N\alpha=\rho
\]

都满足逐坐标恒等式

\[
\boxed{
\alpha_d=1+\sum_{\substack{e\mid d\\e\ge2}}\Delta_e(z),
\qquad 2\le d\le N.
}
\tag{3}
\]

OMEN 上用精确有理数对 \(N=6,10,20\) 直接代回矩阵，(2) 全部成立。

## 3. 一个无条件的粗范数代价

令 \(D^{(2)}_N\) 为指标 \(2,\ldots,N\) 上的除数 incidence 矩阵。式 (2) 即

\[
B_N^{-1}\rho=D^{(2)}_N\Delta(z).
\]

由于

\[
\|D^{(2)}_N\|_{\mathrm{op}}^2
\le \|D^{(2)}_N\|_{\mathrm{HS}}^2
=\sum_{e=2}^{N}\left\lfloor\frac Ne\right\rfloor
\ll N\log(2N),
\]

有显式但粗糙的上界

\[
\boxed{
\|\alpha-\mathbf1_{N-1}\|_2^2
\ll N\log(2N)\sum_{e=2}^{N}|\Delta_e(z)|^2.
}
\tag{4}
\]

这说明有界系数近似桥至少需要归一化残差的一次差分在除数权下足够小；单纯让 \(\rho\) 小而不控制其逐行差分，并不能保证系数稳定。式 (4) 不是 RH 方向的充分估计，而是把“系数—余项”代价写成明确的算子不等式。

## 4. 边界

公式 (3) 仍不提供平方根级算术估计：\(\Delta_e(z)\) 对真实 Möbius 边界余项的大小与符号尚未得到统一控制。它排除了把 \(B_N^{-1}\) 当作抽象有界算子的一步跳跃，并把下一道问题精确化为

\[
\text{控制 }\quad
\sum_{e\mid d}e\bigl(z_{e-1}-z_e\bigr)
\quad\text{及其末端项 }Nz_{N-1}.
\]

这是一条可继续研究的 signed 差分—除数接口；当前仍不能宣称 RH 已证明。
