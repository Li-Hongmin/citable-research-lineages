> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Reciprocal 边界平台迫使内部 completion 支付 \(M\) 级能量

日期：2026-08-17。

本 note 将 notes/459、461、462 中的边界观察合并为一个严格的平台恒等式。它说明：内部截断并非只留下少数边界行；在一整段行平台上，residual 都由同一个 reciprocal Möbius 常数控制。

## 1. 平台恒等式

令

$$
M=\left\lfloor\frac Nd\right\rfloor,\qquad
B=\left\lfloor\frac{M}{A+1}\right\rfloor,
$$

并定义

$$
Z_{M,A}:=
\sum_{b\le B}\frac{\mu(b)}b
\left(H_{\lfloor M/b\rfloor}-H_A\right).
$$

在 note 459 的双曲线公式中，令 \(q=\lfloor k/d\rfloor\)。若
\(q\le A\)，则 \(\lfloor q/b\rfloor\le A\) 对所有 \(b\) 成立，故下限不再依赖 \(q\)。于是对每个

$$
1\le k<d(A+1)
$$

都有精确恒等式

$$
\boxed{
(\mathcal R_{d,A})_k
=\frac{\sqrt{2k+1}}d\,Z_{M,A}.
}
\tag{1}
$$

令

$$
K_{d,A}:=\min\{N-1,d(A+1)-1\}.
$$

对平台行求平方和，得到

$$
\boxed{
\|\mathcal R_{d,A}\|_2^2
\ge
\frac{K_{d,A}(K_{d,A}+2)}{d^2}\,Z_{M,A}^2.
}
\tag{2}
$$

特别地，若 \(d(A+1)\le N\)，则

$$
\|\mathcal R_{d,A}\|_2^2
\ge\left((A+1)^2-d^{-2}\right)Z_{M,A}^2.
\tag{3}
$$

## 2. Reciprocal 边界常数的无条件渐近

记

$$
S(B)=\sum_{b\le B}\frac{\mu(b)}b,\qquad
L(B)=\sum_{b\le B}\frac{\mu(b)\log b}{b}.
$$

调和数的标准展开在 \(b\le B\) 上给出

$$
H_{\lfloor M/b\rfloor}-H_A
=\log(M/A)-\log b
+O\!\left(\frac bM+\frac1A\right).
$$

因此

$$
Z_{M,A}
=\log(M/A)S(B)-L(B)
+O\!\left(\frac BM+\frac{\log(2B)}A\right).
\tag{4}
$$

若 \(A\to\infty\) 且 \(B=\lfloor M/(A+1)\rfloor\to\infty\)，则
\(\log(M/A)=\log B+o(1)\)。经典零点自由区给出
\(S(B)=o(1/\log B)\)，而 \(1/\zeta(s)=(s-1)+O((s-1)^2)\) 的 Abel 极限给出
\(L(B)\to-1\)。式 (4) 遂推出

$$
\boxed{Z_{M,A}=1+o(1).}
\tag{5}
$$

这一步无条件成立；它只使用经典的 PNT/零点自由区级估计，不使用 RH。

## 3. 平方根截断的能量代价

取 \(A\asymp M^{1/2}\)。此时 \(A\to\infty\)、\(B\asymp M^{1/2}\to\infty\)，故由 (3)、(5)，在
\(d(A+1)\le N\) 的尺度上

$$
\boxed{
\|\mathcal R_{d,A}\|_2^2
\ge (1+o(1))\,M.
}
\tag{6}
$$

更一般地，若 \(A\asymp M^\beta\)，其中 \(0<\beta<1\)，则同样有

$$
\|\mathcal R_{d,A}\|_2^2
\ge (1+o(1))\,M^{2\beta}.
\tag{7}
$$

这说明内部截断残差在一个完整行平台上携带宏观能量；它不是可以由“少数边界行”或逐链正性忽略的低阶项。

## 4. 对 RH 路线的边界

若 \(A\le M^\alpha\)（固定 \(\alpha<1\)），note 463 已给出 \(Z_{M,A}\to1\) 的更直接版本；若 \(A>M/2\)，note 459 给出同号调和尾下界。现在式 (1)--(7) 又排除了整个内部区间把 residual 当作稀疏边界的解释。

因此，倍数链 completion 若要达到平方根级目标，必须把 \(A\) 推到近完整链，并同时处理非平台行的跨尺度 signed cancellation。任何只使用链内正 Gram、Cauchy 或固定深度截断的证明都不能关闭 RH-strength 门。

本 note 是严格的结构性 no-go 与能量下界，不是 RH 证明。
