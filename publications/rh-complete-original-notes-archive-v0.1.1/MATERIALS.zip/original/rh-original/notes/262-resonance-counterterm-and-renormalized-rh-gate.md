> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 共振反项与 renormalized parity 的 RH 门

日期：2026-08-16。

note 261 证明了固定非零频率的完整 parity 系数不能直接满足平方根
部分和界。本 note 把 \(s=1-it\) 的二阶极点显式减去，得到一个
可检验的 renormalized 序列；它不再有主共振，但剩余算术门仍是
\(1/\zeta(s)\)。

## 1. 精确反项

沿用 note 261 的记号，令
\[
s_0=1-it,\qquad
C(s,t):=\frac{R(s,t)}{\zeta(s)\zeta(s+2it)}.
\]
在 \(s_0\) 附近写
\[
C(s,t)=C_0(t)+C_1(t)(s-s_0)+O((s-s_0)^2).
\]
由 \(\zeta(1+u)=u^{-1}+\gamma_0+O(u)\)，
\[
F(s,t)=\frac{C_0(t)}{(s-s_0)^2}
+\frac{D_0(t)}{s-s_0}+O(1),
\qquad
D_0(t):=C_1(t)+2\gamma_0C_0(t).
\tag{1}
\]
定义
\[
b_n(t):=
a_n(t)-n^{-it}\bigl(C_0(t)\log n+D_0(t)\bigr),
\qquad \log 1:=0.
\tag{2}
\]
因为
\[
\sum_{n\ge1}n^{-s-it}\log n=-\zeta'(s+it),
\]
其 Dirichlet 级数为
\[
B(s,t):=\sum_{n\ge1}b_n(t)n^{-s}
=F(s,t)+C_0(t)\zeta'(s+it)-D_0(t)\zeta(s+it).
\tag{3}
\]
把 (1) 代入 (3)，二阶和一阶极点逐项抵消。因此 \(B(s,t)\)
在 \(s=1-it\) 有可去奇点。

## 2. 余下的 zeta 门

反项只含 \(\zeta(s+it)\) 的极点及其导数，不能消掉
\(1/\zeta(s)\) 在 zeta 非平凡零点处的极点。更具体地，取 \(t\)
避开以下可数异常集合：

1. \(\zeta(\rho+it)=0\)，其中 \(\rho\) 遍历 zeta 零点；
2. \(R(\rho,t)=0\)；
3. 使上述局部因子退化的极点或重合情形。

对这样的 generic \(t\)，若存在零点 \(\rho\) 满足
\(\Re\rho>\tfrac12\)，则 \(B(s,t)\) 在 \(s=\rho\) 仍有极点：
\(\zeta(s+it)^2\) 不提供抵消，而反项在 \(s=\rho\) 全纯。

因此，若 renormalized 部分和满足
\[
\sum_{n\le B}b_n(t)\ll_{\varepsilon,t}B^{1/2+\varepsilon},
\tag{4}
\]
Abel 延拓会使 \(B(s,t)\) 在
\(\Re s>\tfrac12+\varepsilon\) 全纯，从而排除所有
\(\Re\rho>\tfrac12\) 的 zeta 零点。这个推论是 RH-strength 的；
它不是无条件估计。

## 3. 物理解释

原 parity completion 的固定频率部分可分解为
\[
\sum_{n\le B}a_n(t)
=C_0(t)\sum_{n\le B}n^{-it}\log n
+D_0(t)\sum_{n\le B}n^{-it}
+\sum_{n\le B}b_n(t).
\tag{5}
\]
前两项是显式 Euler--Maclaurin 共振反项，规模为
\(B^{1-it}\log B\) 与 \(B^{1-it}\)；最后一项才是可与
\(1/\zeta(s)\) 关联的 renormalized channel。

故任何想把 parity completion 推到平方根级的方案，至少要同时完成：

* 在物理端精确扣除 (5) 的两个显式大尺度项；
* 对 \(b_n(t)\) 的有限部分和建立统一的 signed estimate；
* 在 \(t\) 上控制反项与余项的交叉频率，而不是逐频率取绝对值。

## 4. 路线裁决

共振反项提供了一个清晰的下一步对象，但没有绕开 RH：

* 原始 \(a_n(t)\) 的平方根界被真实二阶极点严格排除；
* renormalized \(b_n(t)\) 消除了该极点，却把问题准确地集中到
  \(1/\zeta(s)\) 的零点；
* 对 generic \(t\)，\(b_n(t)\) 的平方根部分和界会推出 RH；
* 目前没有无条件方法证明 (4)，也没有证明物理端的跨频率交叉项
  自动提供所需补偿。

这把“共振主项”和“RH 算术门”分离成两个可独立核验的对象。
