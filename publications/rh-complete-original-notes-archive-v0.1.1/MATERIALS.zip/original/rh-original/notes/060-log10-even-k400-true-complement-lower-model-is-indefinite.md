> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(\frac12\log 10\) 偶扇区的 K400 true-complement 下模型严格不定

## 1. 结论与范围

固定

\[
 a=\frac12\log10,\qquad N=500,\qquad R=280,\qquad K=400,
\]

令 \(B_0\) 只包含 active prime blocks、\(n<500\) 的 Yukawa atoms
和偶 polar 项。本文保留补空间中的真实模
\(q=280,\ldots,399\)，并只对 \(q\ge400\) 使用对角下界。由此得到的
K400 true-complement 下模型具有严格惯性

\[
 \boxed{\operatorname{inertia}(G_{400})=(399,1,0).}
 \tag{1}
\]

因此，保留前 120 个真实补空间模仍不足以证明
\(A^+_{\frac12\log10}>0\)。式 (1) 只关闭这一固定下模型路线；由于
\(G_{400}\preceq A^+_{\frac12\log10}\)，它不推出原偶算子或完整算子不定。

## 2. 合法的全块下算子

写

\[
 E=P_{280},\qquad F=P_{400}-P_{280},\qquad G=I-P_{400},
\]

并令 \(L=D+B_0\)。在 \(E\oplus F\oplus G\) 分解下，保留
\(P_{400}LP_{400}\) 及其与 \(G\) 的全部 cross，而只把 \(GLG\) 换成

\[
 T_2=\sum_{q\ge400}t_q|e_q\rangle\langle e_q|,
 \qquad t_q=d_q-\rho>0.
\]

于是

\[
 \mathcal L_{400}=
 \begin{pmatrix}
 A&H&X\\ H^*&C&Y\\ X^*&Y^*&T_2
 \end{pmatrix}\preceq L,
 \tag{2}
\]

因为差恰为

\[
 L-\mathcal L_{400}=0_{P_{400}}\oplus G(B_0+\rho I)G\succeq0.
\]

这里没有加入任何 \(n\ge500\) Yukawa 压缩；该完整正尾被整体删除。
这避免了孤立加入 \(PYP\oplus0\) 所导致的 Loewner 错误。

## 3. 联合 covariance 的有限支付

令

\[
 c_q=P_{400}B_0e_q,
 \qquad
 \mathcal C_{400}=\sum_{q\ge400}c_qc_q^*.
\]

取 \(J=2000\)，由 \(t_q\ge t_J\) 对 \(q\ge J\) 成立，得到联合的
Loewner 上界

\[
 \sum_{q\ge400}\frac{c_qc_q^*}{t_q}
 \preceq
 \sum_{400\le q<J}\frac{c_qc_q^*}{t_q}
 +\frac1{t_J}
 \left(\mathcal C_{400}-\sum_{400\le q<J}c_qc_q^*\right).
 \tag{3}
\]

式 (3) 一次保留 \(E\)-\(F\) 的全部 covariance cross；不能把两个
对角块和 mixed block 分别界定后再代入 Schur 补。用 (3) 从
\(P_{400}LP_{400}\) 扣除，所得有限矩阵仍是 (2) 的合法 Schur 下界。

## 4. True-Schur 证书

对前 280 个坐标施加权威 N500 graph 中的七个 Householder 合同。最终
计算显式读取 N500 权威缓存，而不依赖历史 N400 文件名。坐标顺序为

\[
 \mathbf R^7\oplus\mathbf R^{273}\oplus\mathbf R^{120}.
\]

写最终 400 维矩阵为

\[
 \widetilde G_{400}=
 \begin{pmatrix}A_7&X_7\\X_7^*&C_{393}\end{pmatrix}.
\]

192-bit Arb--Cholesky 给出 393 维补块的最小 pivot

\[
 p_{\min}(C_{393})
 \in[0.1108902836949406\pm7.75\times10^{-47}]>0.
\]

对七个右端作 verified solve 后，true Schur 补

\[
 S_7=A_7-X_7C_{393}^{-1}X_7^*
\]

的前六个 pivot 严格为正，最后一个 pivot 的显式区间为

\[
 \begin{aligned}
 p_7\in[&-5.3124473784214958892\times10^{-44},\\
        &-5.3123946078792354976\times10^{-44}],
 \end{aligned}
 \tag{4}
\]

故 \(S_7\) 的严格惯性为 \((6,1,0)\)。结合 \(C_{393}>0\)，Schur
惯性加法给出 (1)。

权威产物为

```text
scratch/log10_even_K400_N500_clean_full_contract_base_arb_192.npz
scratch/log10_even_K400_N500_clean_sharp_full393_arb_192.npz
```

二者 metadata 均记录 `N=500` 与 `clean=true`，后者同时记录 N500
Householder 来源。`clean` 分支明确跳过所有孤立 Yukawa compression。

## 5. 决策含义

note 059 已证明完整 weighted scalar-complement N500 下模型惯性为
\((5,2,0)\)；本文进一步证明，即使真实保留补空间的前 120 个模并共同
支付所有 cross，该 clean K400 下模型仍有一个严格负方向。所以下一步若
继续推进 \(\frac12\log10\)，不能只增加这一有限 true-complement 块；必须
引入合法的全空间 PSD 子因子或更强的补空间结构，同时保留其 cross。
