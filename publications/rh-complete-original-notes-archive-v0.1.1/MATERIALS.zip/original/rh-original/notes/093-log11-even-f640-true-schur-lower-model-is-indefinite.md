> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(\frac12\log11\) 处 even \(F_{640}\) 真 Schur 下模型不定

日期：2026-08-14。

本 note 关闭 [note 092](092-variable-q-tail-gates-are-monotone-but-log11-l8000-remains-indefinite.md)
尚未判定的 fixed-\(F_{640}\) true-Schur 门；它不对完整 Weil 算子作反向推论。

## 命题

令

\[
a=\frac12\log11,\qquad P=P_{400}^+,qquad
F_{640}=(r_{500}^+,\ldots,r_{639}^+)=B_F\oplus V,
\]

并沿 note 092 记

\[
\mathscr S_F
=\mathcal B-\sum_{q\ge400}\frac{U_qU_q^*}{t_q},
\qquad
t_q=\Re\psi\!\left(\frac14+\frac{iq\pi}{2a}\right)-\log\pi-2.931158.
\tag{1}
\]

则

\[
\boxed{\mathscr S_F\not\succeq0.}
\tag{2}
\]

因而 note 089 的 fixed-\(F_{640}\) cutoff-free Loewner 下算子
\(\underline L_{F_{640}}^+\) 有负方向。

## 证明

取 note 092 的 \(L=8000\) 门

\[
G_L=\mathcal B-
\sum_{400\le q<L}\frac{U_qU_q^*}{t_q}
-\frac{R_{\rm tot}-R_L}{t_L}.
\tag{3}
\]

它与真实 Schur 补的差为

\[
D_L:=\mathscr S_F-G_L
=\sum_{q\ge L}\left(\frac1{t_L}-\frac1{t_q}\right)U_qU_q^*\succeq0.
\tag{4}
\]

由 \(G_{8000}\) 的 \(7\oplus393\) verified Schur--LDL，先在七维末负 pivot
上作极小 graph lift，随后将完整 400 维 contracted vector 以 \(224\)-bit dyadic
坐标冻结为 \(x\)。重新在 256-bit Arb 中代回完整 \(G_{8000}\) 给出

\[
\gamma:=\frac{x^*G_{8000}x}{\|x\|^2}
=[-6.43530356625703565542\cdot10^{-48}
\pm3.85\cdot10^{-69}]<0.
\tag{5}
\]

写 \(c_q=x^*U_q\)。由于 \(t_q\) 严格递增，(4) 在该 ray 上满足

\[
0\le\frac{x^*D_{8000}x}{\|x\|^2}
\le \frac1{t_{8000}\|x\|^2}\sum_{q\ge8000}|c_q|^2.
\tag{6}
\]

为界定右侧，先把七个 Householder 的相反次序作用于 \(x\)，得到物理
representative \(h_x\)。在十个实际 prime-cell endpoints 上合并 prime、\(n<500\)
Yukawa、polar 和全部 \(F_{640}\) source 后，\(c_q=\langle h_x,e_q^+\rangle\)。
实现中直接核验了

\[
q=0,1,7,400,7999,8000,8191,20000
\tag{7}
\]

的 cell integral 与原 contracted \(U_q\) response 均为相交 Arb balls。

对合并后的 piecewise exponential \(h_x\)，保留 16 阶 endpoint expansion。
零阶内部 jump 的 signed sine square 由 \(8000\le q<200000\) 直接 Arb 求和；
余下非零 phase 对用 Abel 界，零 phase 对用 Hurwitz \(\zeta\)；其余 15 阶和指数几何
remainder 用 \(\ell^2\) Minkowski 支付。这给出

\[
\frac1{t_{8000}\|x\|^2}\sum_{q\ge8000}|c_q|^2
\le
[1.798986587628545218869376637\cdot10^{-48}
\pm2.35\cdot10^{-98}].
\tag{8}
\]

将 (5)、(6)、(8) 相加，得到

\[
\frac{x^*\mathscr S_Fx}{\|x\|^2}
\le-4.636316978628490436546773363\cdot10^{-48}<0.
\tag{9}
\]

故 (2) 成立。

完整冻结 vector、parent hash、phase-tail certificate 与重放入口见
[`log11-even-f640-true-schur-obstruction`](../computations/bundles/log11-even-f640-true-schur-obstruction/README.md)。

## 边界

\[
\underline L_{F_{640}}^+\not\succeq0
\quad\not\Rightarrow\quad
A_{\frac12\log11}^+\not\succeq0.
\tag{10}
\]

原因是 \(\underline L_{F_{640}}^+\preceq A_{\frac12\log11}^+\)。因此本结果严格关闭的
只是该 fixed-family true-Schur **下模型正性**路线；它不否定 note 090 的主压缩正性，
不否定完整 \(A_{\frac12\log11}^+\) 的正性，也不涉及 RH 的真假。
