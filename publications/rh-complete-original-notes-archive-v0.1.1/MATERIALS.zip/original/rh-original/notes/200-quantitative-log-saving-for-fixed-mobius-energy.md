> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定 Möbius 能量的一个无条件 subpower 节省

日期：2026-08-15。

本 note 把 note 199 的无速率 \(E_N=o(N^2)\) 提升为
\(N^2\exp[-c'\Lambda(N)]\) 型的无条件 subpower 节省。它仍远未达到
RH 所需的 \(N^{1+\varepsilon}\)；关键是 Bernstein 阶数必须取为
\(\exp(\alpha\Lambda(N))\)，而远比值截断也必须取为 \(\asymp\Lambda(N)\)。

## 1. 命题

令 \(w\ge0\)，并设
\[
 K(u)=\frac1{2\pi}\int_{\mathbb R}w(t)e^{itu}\,dt .
\]
假设
\[
 w\in L^1(\mathbb R),\qquad
 \int_{\mathbb R}|t|w(t)\,dt<\infty .
\tag{1}
\]
则 \(K\) 有界且 Lipschitz。对所有充分大的 \(N\)，
\[
 E_N(w)=\int_{\mathbb R}w(t)
 \left|\sum_{n\le N}\mu(n)n^{it}\right|^2dt
\]
有无条件估计
\[
\boxed{
 E_N(w)\ll_w N^2\exp[-c_w'\Lambda(N)]},
\qquad
\Lambda(N)=(\log N)^{3/5}(\log\log N)^{-1/5},
\tag{2}
\]
其中 \(c_w'>0\) 只依赖于零自由区常数与 \(w\) 的一阶频率矩。

这里使用的唯一算术输入是经典零自由区给出的
\[
 M(x):=\sum_{n\le x}\mu(n)
 \ll x e^{-c\Lambda(x)}.
\tag{3}
\]

## 2. Dyadic 比值分解

由有限和与积分交换，
\[
 E_N(w)=\sum_{m,n\le N}\mu(m)\mu(n)K(\log(m/n)).
\tag{4}
\]
令 \(I_j=(2^j,2^{j+1}]\)。对 \(m\in I_j\)、\(n\in I_{j+d}\)
\((d\ge0)\)，写
\[
 m=2^j x,\qquad n=2^{j+d}y,\qquad 1\le x,y\le2.
\]
对应核为
\[
F_d(x,y)=K\!\left(\log(2^{-d}x/y)\right).
\tag{5}
\]
由 (1)，\(K\) 有界且 Lipschitz；而
\(\partial_x\log(2^{-d}x/y)=1/x\)、\(\partial_y\log(2^{-d}x/y)=-1/y\)
在 \([1,2]^2\) 上一致有界。因此所有 \(F_d\) 在 \([1,2]^2\) 上具有统一
Lipschitz 常数。
这里只写 \(n\) 所在 dyadic 块不小于 \(m\) 的半块；反向块由
\(K(-u)=\overline{K(u)}\) 给出同样的估计，\(d=0\) 只计一次。
单独的整数 \(1\) 未包含在 \(I_j\) 中；含 \(1\) 的行列至多贡献
\(O_w(N)\)，以下均可吸收。

固定 \(\beta>0\)，取
\[
 D=\left\lceil\frac{\beta\Lambda(N)}{\log2}\right\rceil,\qquad
 R=\left\lceil e^{\alpha\Lambda(N)}\right\rceil ,
\tag{6a}
\]
其中 \(\alpha>0\) 稍后选择。注意 \(D\asymp\Lambda(N)\)，而不是
\(O(\log\log N)\)；这是把远比值尾压到同一 subpower 尺度所必需的。
当 \(0\le d\le D\) 时，用二维 Bernstein 多项式
\[
 \mathcal B_{R,d}(x,y)=
 \sum_{r,s=0}^{R}
 F_d\!\left(1+\frac rR,1+\frac sR\right)
 b_{R,r}(x-1)b_{R,s}(y-1),
\]
其中 \(b_{R,r}(u)=\binom Rr u^r(1-u)^{R-r}\)。
Bernstein 逼近给出
\[
\|F_d-\mathcal B_{R,d}\|_{\infty,[1,2]^2}
\ll_w R^{-1/2},
\tag{6}
\]
且系数绝对值 \(\ll_w1\)；该界对 \(d\le D\) 一致。

因此所有近比值块的逼近误差总和满足
\[
 \sum_{\substack{j,d\\d\le D}}
 \left|\sum_{\substack{m\in I_j\\n\in I_{j+d}}}
 \mu(m)\mu(n)(F_d-\mathcal B_{R,d})(m/2^j,n/2^{j+d})\right|
\ll_w R^{-1/2}N^2 .
\tag{7}
\]
这里用了
\(\sum_{j\le\log_2N-d}2^{2j+d}\ll N^2 2^{-d}\)，再对 \(d\) 求和。

## 3. Bernstein 项的因子化

每个 Bernstein 基函数 \(b_{R,r}\) 满足
\[
 0\le b_{R,r}\le1,\qquad
 \operatorname{Var}_{[0,1]}(b_{R,r})\le2.
\]
对任意固定 \(r\)，\(b_{R,r}(m/2^j-1)\) 在 \(I_j\) 上的总变差至多为
常数（端点跳跃也包含在内）。部分求和与 (3) 因而给出，对
\(2^j\ge N^{1/2}\)，
\[
 \left|\sum_{m\in I_j}\mu(m)b_{R,r}(m/2^j-1)\right|
 \ll 2^j e^{-c_1\Lambda(2^j)}.
\tag{8}
\]
对 \(2^j<N^{1/2}\) 使用平凡界 \(O(2^j)\)。由于
\(\Lambda(x)\) 在充分大的 \(x\) 上递增，且
\(\Lambda(2^j)\ge c_0\Lambda(N)\)（当 \(2^j\ge N^{1/2}\)），
其中 \(c_1>0\) 只取决于 (3)，与 \(N,j,r,d\) 无关。

令 \(\kappa<2^{-3/5}\) 固定。对 \(2^j\ge N^{1/2}\) 且 \(N\) 足够大，
\(\Lambda(2^j)\ge\kappa\Lambda(N)\)；若 (3) 的零自由区常数为 \(c\)，
则可取 \(\gamma=c_1\kappa/2>0\)，使 (8) 右端统一替换为
\(O(2^j e^{-\gamma\Lambda(N)})\)。Bernstein 逼近项是有限个一次和的乘积，
故所有 \(d\le D\) 的主项满足
\[
 \ll_w R^2D\left(
 N^2e^{-\gamma\Lambda(N)}
 +N\,e^{\beta\Lambda(N)}\right).
\tag{9}
\]
第二项来自 \(2^j<N^{1/2}\) 的平凡界与
\(\sum_{d\le D}2^d\ll e^{\beta\Lambda(N)}\)。连同
\(R^2D=e^{(2\alpha+o(1))\Lambda(N)}\) 后，它相对于 \(N^2\) 仍可吸收进任意
固定的 \(\exp[-\eta\Lambda(N)]\)，因为 \(\log N\gg\Lambda(N)\)。

## 4. 远比值尾

对 \(d>D\)，只用 \(K\) 的有界性和块大小：
\[
 \sum_{\substack{j,d>D\\j+d\le\log_2N}}
 \sum_{\substack{m\in I_j\\n\in I_{j+d}}}
 |K(\log(m/n))|
\ll_w N^2\sum_{d>D}2^{-d}
\ll_w N^2e^{-\beta\Lambda(N)}.
\tag{10}
\]
合并 (7)、(9)、(10)。取
\[
\alpha=\frac{2\gamma}{5},\qquad \beta\ge\frac{\gamma}{5}.
\tag{10a}
\]
则
\[
R^{-1/2}=e^{-\gamma\Lambda(N)/5+o(\Lambda(N))},
\qquad
R^2e^{-\gamma\Lambda(N)}
=e^{-\gamma\Lambda(N)/5+o(\Lambda(N))}.
\]
多项式因子 \(D\asymp\Lambda(N)\) 可吸收进稍弱的指数常数，得到 (2)。

## 5. 对 RH 路线的意义

对 \(V_{15}\) 的 \(w=|h|/(2\pi)\)，由
\(h(\xi)=O_\varepsilon(|\xi|^{-19/2+\varepsilon})\)，条件 (1) 成立。
所以 (2) 是当前路线的一个严格无条件定量改善。

但它仍只有 subpower 节省：
\[
 N^2\exp[-c'_w\Lambda(N)]\gg N^{1+\varepsilon}
 \qquad(\text{每个固定 }\varepsilon>0),
\]
因为 \(\Lambda(N)=o(\log N)\)。
因此它不能关闭 note 192 的平方根能量门，也不能单独推出 RH。
要继续下降到 \(N^{1+\varepsilon}\)，必须取得真正的 Möbius 二点相关
幂次节省，或构造保留 signed prime/reflection cancellation 的新 intertwiner。
