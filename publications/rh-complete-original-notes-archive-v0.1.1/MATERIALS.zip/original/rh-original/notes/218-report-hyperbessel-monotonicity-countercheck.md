> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 报告中 hyper-Bessel 单调性式的反例核验

日期：2026-08-15。

ChatGPT Pro 里程碑报告 145--152 将大尺度剩余门写成

\[
 \frac{d}{d\xi}\left[
 \xi^3\,{}_1F_2\!\left(m+2;\frac{3m+7}{2},\frac{3m+8}{2};-\frac{\xi^2}{4}\right)
 \right]\le 0,
 \qquad \xi\ge 4\sqrt m.
\tag{1}
\]

按式 (1) 原样用 SymPy 60 位精度直接计算，在边界 \(\xi=4\sqrt m\) 得：

\[
\begin{array}{c|c}
m & \text{左侧导数}\mid_{\xi=4\sqrt m}\\ \hline
1&21.6429364161641878809799521453708745\\
2&24.1055050230190580961834141952741296\\
3&22.7022481175103662629701675381675197\\
4&20.4265813910351081337586976996887995\\
5&18.0104708116546004727853395586603089\\
6&15.6478849759000462696469176324896475\\
7&13.3838745466430796614489406353400474\\
8&11.2196181968715966398424789697680778\\
9&9.14411567330712780945252516667252392\\
10&7.14425485206284378888849584422509863
\end{array}
\]

这些高精度值均为正，故 (1) 按当前参数和阈值表述至少不能作为已建立的大尺度正性引理；在将其升级为形式化反例前，仍应使用区间算术复核该单点值。复现实验脚本为
[check_report_hyperbessel_bound.py](../computations/check_report_hyperbessel_bound.py)。

其中 \(m=1,\xi=4\) 还可完全用交错超几何级数给出有理下界。写
\[
H_1={}_1F_2(3;5,11/2;-4),\qquad
H_2={}_1F_2(4;6,13/2;-4),
\]
则左侧导数为 \(48H_1-(768/55)H_2\)。两级数的项幅在首项后单调下降，
24 项交错余项估计给出严格下界
\[
\frac{
2798644006163237149705686222654706640483498323352472288745424
}{
129309810478075846312439556958270117543803396994169677734375
}>0.
\]
因此至少 \(m=1\) 的边界反例不依赖浮点舍入。

这不否定可能存在的修正版（例如不同参数、不同归一化或更大的阈值），但在完成精确推导和符号核验前，不能把报告的 hyper-Bessel 单调性吸收到 detector 全 \(m\) 正性证明中。
