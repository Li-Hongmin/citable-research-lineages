> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 离线零点迫使 Lehmer 尾能量增长

日期：2026-08-17。

令 \(I_N\) 为 note 343--347 的指数尾能量，令
\[
Q_N=\frac43+\sum_{k=2}^{N-1}\frac1{2k+1}\ll\log(2N).
\]
note 347 的有限维评价不等式是
\[
|M(N)-1|^2\le \frac{I_N}{\pi}Q_N,
\qquad M(N)=\sum_{n\le N}\mu(n).
\tag{1}
\]

## 定理

若 \(\zeta(\rho)=0\) 且 \(\beta:=\Re\rho>1/2\)，则
\[
\limsup_{N\to\infty}\frac{\log I_N}{\log N}\ge 2\beta.
\tag{2}
\]
更具体地，对任意 \(\delta>0\)，存在无穷多个 \(N\) 使
\[
I_N\gg_{\rho,\delta}\frac{N^{2\beta-2\delta}}{\log(2N)}.
\tag{3}
\]

## 证明

对 \(\Re s>1\)，部分和公式给出
\[
\frac1{\zeta(s)}=s\int_1^\infty M(x)x^{-s-1}\,dx.
\tag{4}
\]
若存在某个 \(\delta>0\) 使 \(M(x)=O(x^{\beta-\delta})\)，右侧将延拓为
\(\Re s>\beta-\delta\) 的全纯函数。这与 \(s=\rho\) 处的极点矛盾。因此对每个
\(\delta>0\)，\(M(x)\not=O(x^{\beta-\delta})\)；可取无穷序列 \(N_j\to\infty\)
使
\[
|M(N_j)|\ge N_j^{\beta-\delta}.
\tag{5}
\]
丢弃有限多个 \(j\) 后，\(|M(N_j)-1|\ge |M(N_j)|/2\)。代入 (1)，并用
\(Q_{N_j}\ll\log(2N_j)\)，得到 (3)。令 \(\delta\downarrow0\) 即得 (2)。

## 含义

这不是新的 RH 证明，而是一个精确的反向障碍：任何统一上界
\[
I_N\ll N^{1+\varepsilon}
\]
都会排除所有 \(\beta>1/2\) 的零点；反之，若存在离线零点，尾门不会只是在
某个局部参数上失败，而会沿无穷子列出现对应的幂次增长。该结论只使用
有限维 Lehmer 评价常数和 Mellin 延拓，不依赖零点简单性或显式公式的残差不消失。
