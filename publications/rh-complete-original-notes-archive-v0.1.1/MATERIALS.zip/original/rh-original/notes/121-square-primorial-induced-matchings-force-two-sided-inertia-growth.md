> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 平方 primorial induced matching 强制双侧惯性增长

日期：2026-08-14。

依赖：
[note 118](118-an-endpoint-flat-detector-gives-an-exact-positive-reciprocal-product-rh-gate.md)、
[note 119](119-the-positive-reciprocal-product-rh-kernel-is-uniformly-indefinite.md)、
[note 120](120-the-centered-rh-kernel-has-growing-positive-inertia-and-infinitely-many-cusps.md)。

证据等级：精确 block-diagonal 主子式与有限秩惯性交错。

note 120 证明 centered reciprocal-product 核的正惯性无界，但只得到
一个负方向，并把负惯性是否增长留为边界。本文用平方 primorial 构造
彼此完全解耦的 \(2\times2\) 负块，解决该边界。结果同时排除任意固定秩
deflation，而不再局限于保持 Mellin--Hankel 结构的指数项。

## 1. 核

沿用

\[
P(y)=
\frac{\lfloor y\rfloor(\lfloor y\rfloor+1)}{y^3}
\{y\}(1-\{y\}),
\tag{1}
\]

\[
P_x(a,b)=P\left(\frac{x}{ab}\right),
\qquad
C_x(a,b)=P_x(a,b)-\frac{ab}{6x}.
\tag{2}
\]

注意

\[
P(y)=0\iff y\in\mathbb N
\qquad(y\ge1).
\tag{3}
\]

## 2. 平方 primorial 指标族

令

\[
Q=p_1p_2\cdots p_m,\qquad x=Q^2,
\tag{4}
\]

其中 \(p_1<\cdots<p_m\) 为前 \(m\) 个素数。对每个 \(k\)，取两个指标

\[
a_k=p_k,\qquad b_k=p_k^2.
\tag{5}
\]

当 \(m\) 充分大时，

\[
a_k,b_k\le Q=\sqrt x
\tag{6}
\]

对所有 \(k\) 成立。

若 \(k\ne\ell\)，则四种跨块乘积

\[
a_ka_\ell,\quad a_kb_\ell,\quad
b_ka_\ell,\quad b_kb_\ell
\tag{7}
\]

都整除 \(Q^2=x\)。由 (3)，所有跨块 entry 精确为零。

## 3. 每块恰有一正一负方向

块内第一个对角参数为

\[
\frac{x}{a_k^2}
=\left(\frac Q{p_k}\right)^2\in\mathbb N,
\tag{8}
\]

所以

\[
P_x(a_k,a_k)=0.
\tag{9}
\]

交叉参数为

\[
\frac{x}{a_kb_k}
=\frac{(Q/p_k)^2}{p_k}.
\tag{10}
\]

因 \(\gcd(Q/p_k,p_k)=1\)，(10) 不是整数；由 (6) 它至少为 \(1\)。
故

\[
c_k:=P_x(a_k,b_k)>0.
\tag{11}
\]

最后置

\[
d_k:=P_x(b_k,b_k)\ge0.
\tag{12}
\]

在全部 \(2m\) 个指标上，主子式因此精确为

\[
\boxed{
\bigoplus_{k=1}^m
\begin{pmatrix}
0&c_k\\
c_k&d_k
\end{pmatrix}.}
\tag{13}
\]

每个块的行列式是

\[
-c_k^2<0,
\tag{14}
\]

故恰有一个正特征值和一个负特征值。因此

\[
\boxed{
n_+(P_x)\ge m,\qquad n_-(P_x)\ge m.}
\tag{15}
\]

这是真正的 induced matching：不同块完全解耦，而不是把若干耦合的
局部负向量形式相加。

## 4. Centering 后的惯性

在该主子式上，

\[
C_x=P_x-\frac1{6x}vv^*,
\tag{16}
\]

其中 \(v\) 是相应整数指标向量。第二项为 rank-one PSD，且以负号加入。
由 Loewner 单调性，负惯性不能减少：

\[
\boxed{n_-(C_x)\ge m.}
\tag{17}
\]

rank-one 扰动至多损失一个正特征值，所以

\[
\boxed{n_+(C_x)\ge m-1.}
\tag{18}
\]

由素数乘积渐近

\[
\log x=2\log Q=(2+o(1))m\log m,
\tag{19}
\]

沿平方 primorial 子序列得到

\[
\boxed{
n_\pm(P_x)\gg\frac{\log x}{\log\log x},}
\tag{20}
\]

\[
\boxed{
n_\pm(C_x)\gg\frac{\log x}{\log\log x}.}
\tag{21}
\]

## 5. 任意固定秩 deflation 均不足

设 \(R_x\) 是任意实对称矩阵，满足

\[
\operatorname{rank}R_x\le r
\tag{22}
\]

且 \(r\) 与 \(x\) 无关。有限秩惯性交错给出

\[
n_\pm(P_x+R_x)\ge n_\pm(P_x)-r,
\tag{23}
\]

\[
n_\pm(C_x+R_x)\ge n_\pm(C_x)-r.
\tag{24}
\]

由 (20)--(21)，对每个固定 \(r\)，沿平方 primorial 子序列，

\[
n_+(P_x+R_x),\ n_-(P_x+R_x)\to\infty,
\tag{25}
\]

且 centered 核同样成立。因此：

\[
\boxed{
\text{任何固定秩 deflation 都不能把这些核最终变成 PSD 或 NSD}.}
\tag{26}
\]

这里 \(R_x\) 不必保持 reciprocal-product、Mellin--Hankel、解析性或
separable power 结构；只使用其秩有统一上界。这严格加强了 note 120
的 cusp 边界。

## 6. 组合边界

相交图的零模式本身不足以推出负惯性增长：incidence Gram
\(|S\cap T|\) 具有相同的“相交为正、不交为零”支撑，却是 PSD。
真正承重的是：

\[
\boxed{
\text{跨块完全不交}
+
\text{每块 }K_{12}^2>K_{11}K_{22}.}
\tag{27}
\]

平方 primorial 选择 (5) 使

\[
K_{11}=0,\qquad K_{12}>0,
\tag{28}
\]

所以逐块负行列式自动成立。

## 7. 结论

note 120 的剩余惯性分类现已闭合：

\[
\boxed{
\text{原核与 centered 核的正、负惯性都无界}.}
\tag{29}
\]

因此 note 118 的 RH 等价二次型不能被“有限个坏 mode 加单侧正尾”
解释。任何有效谱分解必须具有增长的正负空间，并利用 Möbius 向量与这些
空间之间的特殊算术位置；固定秩 Schur、有限 mode deflation 或单侧 Gram
尾均不足。这是一般惯性定理，不是 RH 的证明。
