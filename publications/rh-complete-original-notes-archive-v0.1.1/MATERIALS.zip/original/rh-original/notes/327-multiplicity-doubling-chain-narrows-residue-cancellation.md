> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 共振残数消零会产生重数翻倍链

日期：2026-08-16。

本 note 在 note 326 的复频率门上再推进一步。它不假设共振平方根界
已经成立，而是说明：若该界成立，离线零点的残数消零必须满足一个很强的
重数递推；结合经典零点重数上界，剩余可能性只能落在一个显式的二进实部集合。

## 1. 局部极点的重数

设 \(\rho=\beta+i\gamma\) 是 zeta 的零点，\(\beta>1/2\)，重数为 \(m\)，
并令 \(t_\rho=-i(\rho-1)\)。note 326 已证明，在该点
\[
K(it_\rho)\ne0,\qquad \zeta(it_\rho)=\zeta(\rho-1)\ne0,\qquad
S(\rho,t_\rho)\ne0.
\]
因此正向共振振幅的唯一可能消零因子是
\(\zeta(1+2it_\rho)=\zeta(2\rho-1)\)。

若 \(m'\) 是 \(\zeta(2\rho-1)\) 的零点重数，则
\[
\operatorname{ord}_{t=t_\rho}Q_+=m'-2m.
\]
所以要完全移除该极点，必要条件是
\[
\boxed{m'\ge 2m.}\tag{1}
\]
若 \(m'<2m\)，轮廓移位产生
\(B^\beta e^{i\gamma\log B}\) 乘以一个非零的对数多项式，不能满足
统一的 \(O_\varepsilon(B^{1/2+\varepsilon})\) 界。

## 2. 函数方程与二进 tent 链

记
\[
T(s)=2s-1,\qquad C(s)=1-\overline{s}.
\]
若 \(T(\rho)\) 仍在右半临界带 \(\Re s>1/2\)，令
\(\rho_1=T(\rho)\)；若它落在左半边，则由函数方程令
\(\rho_1=C(T(\rho))\)。函数方程保持零点重数，故由 (1)
\[
\operatorname{mult}(\rho_1)\ge 2\,\operatorname{mult}(\rho).
\tag{2}
\]
只要 \(\rho_n\) 尚未落到临界线，这一构造可继续。

令
\[
u_n=2\Re(\rho_n)-1\in(0,1).
\]
则
\[
u_{n+1}=|2u_n-1|,\qquad
|\Im\rho_n|=2^n|\gamma|,\qquad
\operatorname{mult}(\rho_n)\ge 2^n m.
\tag{3}
\]
这里的 tent-map 公式只是把 \(T\) 与函数方程反射 \(C\) 的两种情况合并。

## 3. 经典重数上界迫使有限终止

经典 Riemann--von Mangoldt 零点计数公式给出，对 \(|T|\) 足够大，
\[
N(T+1)-N(T-1)=O(\log(2+|T|)).
\]
因此任意高度为 \(T\) 的单个零点的重数满足
\[
\operatorname{mult}(\sigma+iT)=O(\log(2+|T|)).
\tag{4}
\]
若 (3) 中的链无限且 \(\gamma\ne0\)，则同一零点的重数同时满足
\[
2^n m\le O(\log(2^n|\gamma|))=O(n),
\]
矛盾。因此链必须在有限步 \(n\) 命中
\(u_n=1/2\)，即 \(\Re(\rho_n)=3/4\)；下一次 \(T\) 正好落在临界线。

等价地，若共振平方根界与 note 326 的轮廓条件成立，则任何没有直接被
排除的离线零点都必须满足
\[
u_0\in T^{-n}(\{1/2\})\quad\text{对某个 }n\ge0,
\]
也就是
\[
u_0=\frac{2k+1}{2^{n+1}},\qquad
\beta=\frac{1+u_0}{2}
\]
是一个显式二进有理数。这个结论仍是条件性的：它使用了共振界，并不等于
已证明 RH。

## 4. 剩余缺口

该链论证把 note 326 中的 non-cancellation 条件大幅收紧，但没有处理
\(\beta=3/4\) 及其二进前像对应的临界线终止情形。要继续排除这些离散实部，
需要一个具有不同移位比的第二共振通道，或直接证明实际 half-lattice
边界估计能够检测临界线上的高重数对数项。当前 note 不声称这些额外输入
已经存在。
