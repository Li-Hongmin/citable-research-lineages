> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Barban--Vehov 的 \(H^{-1}\) 障碍与 incomplete-lcm 边界

日期与检索截止：2026-08-12。

依赖：[note 064](064-selberg-affine-first-shell-rh-criterion.md)。

## 1. 弄清问题

记

\[
L:=\log N,
\qquad
\lambda_{d,N}:=\mu(d)\left(1-\frac{\log d}{L}\right)\quad(d\le N),
\qquad
A_N:=\sum_{d\le N}\frac{\lambda_{d,N}}d,
\tag{1}
\]

以及 Selberg--Barban--Vehov 除数和

\[
q_N(n):=\sum_{\substack{d\mid n\\d\le N}}\lambda_{d,N}.
\tag{2}
\]

note 064 的首壳误差可改写为

\[
\boxed{
D_N(y)=1+A_Ny-\sum_{n\le y}q_N(n)
}
\qquad(N\le y\le2N).
\tag{3}
\]

令

\[
I_N:=\int_N^{2N}|D_N(y)|^2\,dy,
\qquad
\mathcal E_N^{\rm Sel}
=\int_N^{2N}|D_N(y)|^2\frac{dy}{y^2}.
\tag{4}
\]

则

\[
\frac{I_N}{4N^2}\le \mathcal E_N^{\rm Sel}\le\frac{I_N}{N^2},
\qquad
\mathcal E_N^{\rm Sel}\to0\iff I_N=o(N^2).
\tag{5}
\]

本轮原子问题：Graham 的 Barban--Vehov 二次均值能否推出 \(I_N=o(N^2)\)？

```mermaid
flowchart LR
  A["Selberg taper λ(d,N)"] --> B["Barban–Vehov 除数和 q_N"]
  B --> C["Graham: ‖q_N‖² ≍ N/log N"]
  B --> D["首壳: D_N = 累计中心化 q_N"]
  D --> E["三角核 K(j,k)=N-max(j,k)"]
  C -. "只给 h=0" .-> E
  E --> F["缺口: 全移位的低频抵消"]
  F --> G["最薄形: incomplete-lcm 边界"]
```

## 2. 拟定计划

\[
\text{Descartes 分解}\quad
\begin{cases}
q_N\text{ 的精确标准形},\\
I_N\text{ 的精确累计核},\\
\text{Graham 定理可控制的项},\\
\text{不能控制的最小反例},\\
M,\Psi\text{ 的历史充分条件}.
\end{cases}
\tag{6}
\]

## 3. 实现计划

### 3.1 标准 Barban--Vehov 形

**定理 1（除数和表示）。** 对 \(N\le y\le2N\)，(3) 精确成立；并且

\[
q_N(1)=1,
\qquad
q_N(n)=\frac{\Lambda(n)}L\quad(2\le n\le N),
\tag{7}
\]

\[
\boxed{
q_N(n)=\frac{\Lambda(n)}L
-\mu(n)\left(1-\frac{\log n}L\right)
}
\quad(N<n\le2N).
\tag{8}
\]

**证明。** 交换有限求和得

\[
\sum_{n\le y}q_N(n)
=\sum_{d\le N}\lambda_{d,N}\left\lfloor\frac yd\right\rfloor,
\tag{9}
\]

故 (3) 即 note 064 的分数部分恒等式。若 \(2\le n\le N\)，所有因子均被保留，利用

\[
\sum_{d\mid n}\mu(d)=0,
\qquad
\sum_{d\mid n}\mu(d)\log d=-\Lambda(n)
\tag{10}
\]

即得 (7)。若 \(N<n\le2N\)，唯一可能大于 \(N\) 的因子是 \(n\) 本身；从完整卷积中删去

\(\mu(n)(1-\log n/L)\) 即得 (8)。\(\square\)

因此

\[
D_N(m)-D_N(m-1)=A_N-q_N(m).
\tag{11}
\]

### 3.2 首壳是 \(H^{-1}\) 量，不是普通二次均值

令

\[
C_m:=D_N(N+m)\quad(0\le m\le N-1),
\qquad
b_j:=A_N-q_N(N+j)\quad(1\le j\le N-1).
\tag{12}
\]

则

\[
C_m=C_0+\sum_{j=1}^m b_j,
\qquad
D_N(N+m+v)=C_m+A_Nv\quad(0\le v<1),
\tag{13}
\]

从而有精确公式

\[
\boxed{
I_N=\sum_{m=0}^{N-1}
\left(C_m^2+A_NC_m+\frac{A_N^2}{3}\right).
}
\tag{14}
\]

其主累计项为

\[
\begin{aligned}
\sum_{m=0}^{N-1}C_m^2
={}&NC_0^2
+2C_0\sum_{j=1}^{N-1}(N-j)b_j\\
&+\sum_{j,k=1}^{N-1}
\bigl(N-\max(j,k)\bigr)b_jb_k.
\end{aligned}
\tag{15}
\]

最后一项等于

\[
\sum_{j=1}^{N-1}(N-j)b_j^2
+2\sum_{h=1}^{N-2}\sum_{j=1}^{N-1-h}
(N-j-h)b_jb_{j+h}.
\tag{16}
\]

所以目标不是 \(b\) 的 \(H^0\) 能量，而是离散积分算子后的 \(H^{-1}\) 能量；它精确包含
所有移位 \(1\le h<N\) 的一个三角加权聚合。

### 3.3 Graham 定理到达哪里

Murty 记载的 Graham 1978 渐近取 \(z_1=1,z_2=N\) 后正是

\[
\sum_{n\le X}q_N(n)^2
=\frac{X}{L}+O\!\left(\frac{X}{L^2}\right)
\qquad(X\ge N).
\tag{17}
\]

分别取 \(X=N,2N\)，得到

\[
\sum_{N<n\le2N}q_N(n)^2
=\frac{N}{L}+O\!\left(\frac{N}{L^2}\right).
\tag{18}
\]

经典极限 \(LA_N\to1\)、Cauchy--Schwarz 及 \(q_N(2N)=O(1)\) 进一步给出

\[
\boxed{
\sum_{j=1}^{N-1}b_j^2\sim\frac{N}{L}.
}
\tag{19}
\]

这纠正了一个候选误判：对该特殊权重，\(X\asymp N\) 本身没有筛长平方根壁垒。
Graham 已在首壳尺度给出尖锐的普通二次均值；缺失的是 (16) 的低频、全移位抵消。

而且 (19) 单独在逻辑上不可能推出目标。令 \(N\) 为偶数，并取均值为零的块序列

\[
b_j=
\begin{cases}
L^{-1/2},&1\le j\le N/2,\\
-L^{-1/2},&N/2<j\le N.
\end{cases}
\tag{20}
\]

则

\[
\sum_jb_j=0,
\qquad
\sum_jb_j^2=\frac NL,
\qquad
\sum_{m\le N}\left|\sum_{j\le m}b_j\right|^2
\asymp\frac{N^3}{L}.
\tag{21}
\]

故 Barban--Vehov/Graham/Ramaré--Zuniga-Alterman 型 \(H^0\) 估计，即使尖锐且没有
尺度损失，也不能作为黑箱推出 \(I_N=o(N^2)\)。

### 3.4 完整 lcm 周期主项已经可控

全移位核还能再薄一层。令

\[
B_d(y):=\left\{\frac yd\right\}-\frac12,
\qquad
c_N:=1+\frac12\sum_{d\le N}\lambda_{d,N}.
\tag{22a}
\]

由 \(D_N(y)=1+\sum_{d\le N}\lambda_{d,N}\{y/d\}\)，

\[
D_N(y)=c_N+\sum_{d\le N}\lambda_{d,N}B_d(y).
\tag{22b}
\]

记

\[
E_d(N):=\int_N^{2N}B_d(y)\,dy,
\tag{22c}
\]

\[
E_{d,e}(N):=
\int_N^{2N}B_d(y)B_e(y)\,dy
-\frac{N(d,e)^2}{12de}.
\tag{22d}
\]

由于 \(B_dB_e\) 的周期为 \([d,e]\)，直接在一个完整周期积分得

\[
\boxed{
\frac1{[d,e]}\int_0^{[d,e]}B_d(y)B_e(y)\,dy
=\frac{(d,e)^2}{12de}.
}
\tag{22e}
\]

因而

\[
E_d(N)=O(d),
\qquad
E_{d,e}(N)=O([d,e]),
\tag{22f}
\]

且有精确分解

\[
\boxed{
I_N=
\frac N{12}Q_2(N)+\mathcal B_N,
}
\tag{22g}
\]

其中

\[
Q_2(N):=\sum_{d,e\le N}\lambda_{d,N}\lambda_{e,N}
\frac{(d,e)^2}{de},
\tag{22h}
\]

\[
\mathcal B_N:=
Nc_N^2
+2c_N\sum_{d\le N}\lambda_{d,N}E_d(N)
+\sum_{d,e\le N}\lambda_{d,N}\lambda_{e,N}E_{d,e}(N).
\tag{22i}
\]

周期主项并不是新障碍。定义

\[
Q_1(N):=\sum_{d,e\le N}\lambda_{d,N}\lambda_{e,N}
\frac{(d,e)}{de}.
\tag{22j}
\]

令 \(X\to\infty\) 于 Graham 公式 (17) 的固定 \(N\) floor 展开，得到

\[
Q_1(N)=\frac1L+O\!\left(\frac1{L^2}\right).
\tag{22k}
\]

Jordan 恒等式给出两个正平方和

\[
Q_1(N)=\sum_{k\le N}\varphi(k)
\left(\sum_{k\mid d}\frac{\lambda_{d,N}}d\right)^2,
\tag{22l}
\]

\[
Q_2(N)=\sum_{k\le N}J_2(k)
\left(\sum_{k\mid d}\frac{\lambda_{d,N}}d\right)^2.
\tag{22m}
\]

又

\[
\frac{J_2(k)}{\varphi(k)}
=k\prod_{p\mid k}\left(1+\frac1p\right)
\ll N\log\log(3N),
\tag{22n}
\]

故

\[
\boxed{
Q_2(N)\ll\frac{N\log\log(3N)}{\log N}=o(N),
\qquad
\frac N{12}Q_2(N)=o(N^2).
}
\tag{22o}
\]

由 (22g)、(22o)，得到本轮最薄的严格归约：

\[
\boxed{
I_N=o(N^2)
\iff
\mathcal B_N=o(N^2).
}
\tag{22p}
\]

所以完整周期的 gcd/Jordan 正二次型已经足够小；真正未知的是区间
\([N,2N]\) 没有走完整 lcm 周期时留下的**有符号边界余项**。逐项使用

\[
|E_{d,e}(N)|\ll[d,e]
\tag{22q}
\]

会完全丢失 Möbius 符号；下一步必须直接控制 (22i) 的 signed incomplete-lcm 聚合。

### 3.5 精确 \(M\)--\(\Psi\) 分解

记

\[
M(x):=\sum_{n\le x}\mu(n),
\qquad
J(x):=\sum_{n\le x}\mu(n)\log n,
\qquad
\Psi(x):=\sum_{n\le x}\Lambda(n).
\tag{22}
\]

Abel 求和给出

\[
J(y)=M(y)\log y-\int_1^y\frac{M(t)}t\,dt.
\tag{23}
\]

代入 note 064 的首壳恒等式，得到

\[
\boxed{
LD_N(y)
=(y-\Psi(y))+y(LA_N-1)
-\log\frac yN\,M(y)
+\int_N^y\frac{M(t)}t\,dt.
}
\tag{24}
\]

另一方面，

\[
LA_N
=\int_1^N M(t)\frac{1+\log(N/t)}{t^2}\,dt.
\tag{25}
\]

由 \(1/(s\zeta(s))=\int_1^\infty M(t)t^{-s-1}dt\) 在 \(s=1\) 的值与导数，或由标准
零点自由区给出的收敛，可得

\[
\boxed{
1-LA_N
=\int_N^\infty M(t)\frac{1+\log(N/t)}{t^2}\,dt.
}
\tag{26}
\]

式 (24) 显示：需要的不是单独压低 \(M\) 或 \(\Psi-y\)，而是控制它们与边界标量

\[
\Delta_N:=1-LA_N
\tag{27}
\]

在同一 dyadic 壳上的联合低频量。

### 3.6 弱 Mertens 均值确实足够，但不比 RH 更弱

**定理 2（弱 Mertens 桥）。** 假设

\[
\boxed{
\int_2^X\frac{M(t)^2}{t^2}\,dt\ll\log X.
}
\tag{WMH}
\]

则

\[
\boxed{
I_N\ll\frac{N^2}{\log N},
\qquad
\mathcal E_N^{\rm Sel}\ll\frac1{\log N}.
}
\tag{28}
\]

**证明。** 设 \(W(X):=\int_2^X M(t)^2t^{-2}dt\)。由 (26) 分解为

\([2^kN,2^{k+1}N]\)，逐块 Cauchy--Schwarz 得

\[
|\Delta_N|
\ll\sum_{k\ge0}
\frac{k+1}{\sqrt{2^kN}}\sqrt{\log(2^{k+1}N)}
\ll\sqrt{\frac{L}{N}}.
\tag{29}
\]

又因 \(0\le\log(y/N)\le\log2\)，

\[
\int_N^{2N}M(y)^2\,dy
\le4N^2W(2N)\ll N^2L,
\tag{30}
\]

且

\[
\left|\int_N^y\frac{M(t)}t\,dt\right|^2
\le(y-N)\int_N^y\frac{M(t)^2}{t^2}\,dt
\le NW(2N).
\tag{31}
\]

因此 (24) 中两个 Möbius 项的平方积分均为 \(O(N^2L)\)，而

\[
\int_N^{2N}y^2|\Delta_N|^2dy\ll N^2L.
\tag{32}
\]

历史上 (WMH) 蕴含 RH；Cramér 在 RH 下证明

\[
\int_N^{2N}|\Psi(y)-y|^2dy\ll N^2.
\tag{33}
\]

对 (24) 使用 \(|u_1+\cdots+u_4|^2\le4\sum|u_i|^2\)，得到

\[
L^2I_N\ll N^2L,
\tag{34}
\]

即 (28)。\(\square\)

定理 2 是精确桥梁，不是 RH 的证明：(WMH) 本身已经蕴含 RH、零点单性以及一个
reciprocal-
\(\zeta'\) 加权和的收敛。它的价值是把 note 064 的壳判据接回 Titchmarsh--Ng 的历史
Mertens 均值链，并给出正确的量纲 \(N^2/L\)。

## 4. 直接验算

对 \(N=5,10,31,100,257\)，从 (2) 直接筛出 \(q_N\)，再独立计算 (14)、(15)、(24)。
三组累计恒等式的最大浮点误差分别为

\[
6.2\cdot10^{-14},
\qquad
5.7\cdot10^{-14},
\qquad
3.6\cdot10^{-13}.
\tag{35}
\]

低内存筛法至 \(N=2^{19}\) 得

\[
\frac{\sum_{N<n\le2N}q_N(n)^2}{N/\log N}=0.95110,
\qquad
\frac{\sum_{N<n\le2N}(q_N(n)-A_N)^2}{N/\log N}=0.90256,
\tag{36}
\]

与 (18)--(19) 相符；同时

\[
\mathcal E_N^{\rm Sel}\log^2N=0.01698.
\tag{37}
\]

式 (22e) 另以有理数精确积分逐对核验至 \(1\le d,e\le24\)，误差严格为零。对
\(N=2^{19},2^{20}\)，(22g) 的归一化分量为

\[
\begin{array}{c|ccccc}
N&I_N/N^2&Q_2(N)/(12N)&c_N^2/N
&2c_N\sum_d\lambda_dE_d/N^2
&\sum_{d,e}\lambda_d\lambda_eE_{d,e}/N^2\\ \hline
2^{19}&1.85888\cdot10^{-4}&1.80997\cdot10^{-4}
&1.80680\cdot10^{-7}&-9.18984\cdot10^{-7}&5.62973\cdot10^{-6}\\
2^{20}&2.06766\cdot10^{-4}&1.63346\cdot10^{-4}
&3.03936\cdot10^{-9}&-4.30920\cdot10^{-8}&4.34600\cdot10^{-5}
\end{array}
\tag{37a}
\]

此尺度上 \(c_N\) 的两项很小，双重 incomplete-lcm 项主导边界并发生符号振荡。这只改变
下一步的实验选择；它不是 (22p) 右侧的证明。

## 5. 回顾：关闭的路线与新的最简单元

```mermaid
flowchart TD
  A["已知: ∑b_j² ~ N/log N"] --> B{"能否推出 ∑|累计 b|²=o(N²)?"}
  B -->|"否：块反例"| C["关闭 H⁰ 黑箱路线"]
  B -->|"需新增结构"| D["三角加权全移位相关"]
  D --> E["完整 lcm 周期主项 = o(N²)"]
  E --> F["signed incomplete-lcm 边界"]
  F --> G["结合 c_N 与一重边界项"]
  G --> H["I_N=o(N²) ⇒ RH"]
```

当前最小的新命题不是改进 (17) 的常数，而是证明实际算术序列

\[
b_j=A_N-\frac{\Lambda(N+j)}L
+\mu(N+j)\left(1-\frac{\log(N+j)}L\right)
\tag{38}
\]

满足

\[
\boxed{
\sum_{m=0}^{N-1}
\left|C_0+\sum_{j=1}^m b_j\right|^2=o(N^2).
}
\tag{39}
\]

由 (16)，这等价于一个三角加权的全移位相关定理；由 (22p)，又精确等价于

\[
\boxed{
Nc_N^2
+2c_N\sum_d\lambda_{d,N}E_d(N)
+\sum_{d,e}\lambda_{d,N}\lambda_{e,N}E_{d,e}(N)
=o(N^2).
}
\tag{40}
\]

Graham 控制 \(h=0\)，现有固定移位 Selberg-sieve correlation 结果没有覆盖权重层 \(z=N\)、
全部 \(h<N\) 及端点的一致聚合。下一轮只测并攻击 (40)，尤其最后的 signed
incomplete-lcm 项；不再改进普通 \(L^2\) 常数，也不再处理已关闭的完整周期主项。

## 6. 证据与新判断边界

文献直接支持：

- Barban--Vehov 权重及 Graham 在样本长度 \(X\ge z_2\) 的二次均值渐近：V. Kumar Murty,
  *The Barban-Vehov Theorem in Arithmetic Progressions*,
  [期刊全文](https://hrj.episciences.org/5118)，
  [本地全文](<[unbundled local reference]>)。
- 显式 harmonic \(L^2\) 上界仍是普通除数和二次均值：Olivier Ramaré and Sebastian
  Zuniga-Alterman, *An \(L^2\)-bound for the Barban--Vehov weights*,
  [arXiv:2405.12662](https://arxiv.org/abs/2405.12662)，
  [本地全文](<[unbundled local reference]>)。
- 现代 sieve-weight shifted correlations 与零点分布的接口及其 level 限制：Aled Walker,
  *Correlations of sieve weights and distributions of zeros*,
  [arXiv:2101.04418](https://arxiv.org/abs/2101.04418)，
  [本地全文](<[unbundled local reference]>)。
- (WMH) 的历史后果及 RH 加 \(J_{-1}(T)\ll T\) 下的条件证明：Nathan Ng,
  *The distribution of the summatory function of the Möbius function*,
  [arXiv:math/0310381](https://arxiv.org/abs/math/0310381)，
  [本地全文](<[unbundled local reference]>)。
- Cramér 的 RH 条件均方界及其显式改进：Richard P. Brent, David J. Platt and Tim Trudgian,
  *The mean square of the error term in the prime number theorem*,
  [作者全文](https://maths-people.anu.edu.au/brent/pd/rpb274-final.pdf)，
  [本地全文](<[unbundled local reference]>)。

本 note 新增 (3)、(14)--(16)、(22g)--(22p)、(24)--(26) 的统一首壳标准形，定理 2 的
弱 Mertens 定量桥，并严格关闭“普通 Barban--Vehov 二次均值直接推出首壳 RH 判据”的黑箱
路线。这里没有证明 (WMH)、(39)--(40) 或 RH；“现有文献未覆盖 (40)”仅限截至检索日核对的
上述语料，不作绝对首创声明。
