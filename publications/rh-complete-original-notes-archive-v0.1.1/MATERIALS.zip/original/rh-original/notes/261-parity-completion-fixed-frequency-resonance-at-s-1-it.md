> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定频率 parity completion 的 \(s=1-it\) 共振主项

日期：2026-08-16。

note 260 的 three-zeta 因子化还有一个直接后果：固定非零频率时，
完整 squarefree parity 系数并不天然具有平方根级部分和。其 Dirichlet
级数在 \(s=1-it\) 保留一个二阶极点，产生 \(B^{1-it}\log B\) 的主项。
这给出了跨层 parity 路线必须支付的具体共振补偿。

## 1. 极点位置

固定 \(t\in\mathbb R\setminus\{0\}\)，记
\[
a_X(t)=\mu(X)\prod_{p\mid X}(1-p^{-it})^2,
\qquad
F(s,t)=\sum_{X\ {\rm squarefree}}a_X(t)X^{-s}.
\]
由 note 260，
\[
F(s,t)=
\frac{\zeta(s+it)^2}{\zeta(s)\zeta(s+2it)}R(s,t),
\tag{1}
\]
其中 \(R\) 在 \(\Re s>\tfrac12\) 局部一致绝对收敛。

令
\[
s_0=1-it,\qquad
C_0(t):=
\frac{R(1-it,t)}
     {\zeta(1-it)\zeta(1+it)}.
\tag{2}
\]
只要 \(C_0(t)\ne0\)，\(F(s,t)\) 在 \(s=s_0\) 有二阶极点。事实上，
用
\[
\zeta(1+u)=u^{-1}+\gamma_0+O(u)
\]
及 \(u=s-s_0\)，可写成
\[
F(s,t)=\frac{C_0(t)}{u^2}
+\frac{C_1(t)+2\gamma_0C_0(t)}{u}+O(1).
\tag{3}
\]
这里 \(C_1(t)\) 是
\(R(s,t)/[\zeta(s)\zeta(s+2it)]\) 在 \(s_0\) 处的一阶 Taylor 系数。

在 \(t\) 的充分小的非零邻域内，\(R(1-it,t)\) 连续趋于
\(R(1,0)=1\)，而 \(\zeta(1\pm it)\) 没有零点，因此 \(C_0(t)\ne0\)。
故该共振不是特殊频率的偶然现象。

## 2. 固定频率平方根界的严格不可能性

令
\[
A_B(t):=\sum_{X\le B}a_X(t).
\]
若对某个固定 \(t\) 有
\[
A_B(t)\ll_{\varepsilon,t}B^{1/2+\varepsilon},
\tag{4}
\]
则 Abel 部分求和给出
\[
F(s,t)=s\int_1^\infty A_u(t)u^{-s-1}\,du
\]
（加上有限初始项），并在 \(\Re s>\tfrac12+\varepsilon\) 全纯。
这与 (3) 在 \(s_0=1-it\) 的二阶极点矛盾。故只要
\(C_0(t)\ne0\)，固定频率的平方根部分和界 (4) 严格不可能成立。

这个结论不需要假设 RH，也不需要估计 Perron 误差；它只是把
three-zeta 因子的极点与部分和的解析延拓直接比较。

若在 Perron 积分中保留 \(s=s_0\) 的局部项，其留数为
\[
\operatorname{Res}_{s=s_0}
\frac{F(s,t)B^s}{s}
=
\frac{C_0(t)}{s_0}B^{s_0}\log B
+O_t(B).
\tag{5}
\]
更精确地，若
\[
Q(s)=B^s/s,
\]
则留数的完整表达式为
\[
C_0(t)Q'(s_0)
+\bigl(C_1(t)+2\gamma_0C_0(t)\bigr)Q(s_0),
\]
而 \(Q'(s_0)=B^{s_0}(\log B/s_0-1/s_0^2)\)。

式 (5) 只是任意轮廓分解中的局部共振贡献；把它升级为完整的
\(A_B(t)\) 渐近式，还需要对其余轮廓和 zeta 零点作定量估计。
可审计且无条件的结论是：任何试图给固定频率 \(A_B(t)\) 施加
平方根级界的路线，必须先消除这个真实极点，而局部残余 \(R\)
并不提供这种消除。

零频 \(t=0\) 是退化例外：此时
\(a_1(0)=1\)、\(a_X(0)=0\)（\(X>1\)），所以 \(F(s,0)=1\)；
式 (5) 不应在 \(t=0\) 直接取极限。

## 3. 对物理端 parity completion 的含义

若
\[
P(y)=\frac1{2\pi}\int_{\mathbb R}H(t)y^{it}\,dt,
\]
则完整 parity completion 的频率表达为
\[
\mathcal C_B^P(x)
=\frac1{2\pi}\int H(t)x^{it}A_B(t)\,dt.
\tag{6}
\]
把 (5) 的共振项代入，得到形式主项
\[
\frac{B\log B}{2\pi}
\int H(t)\frac{C_0(t)}{1-it}
\left(\frac{x}{B}\right)^{it}dt.
\tag{7}
\]
因此跨层求和若要达到 \(B^{1/2+\varepsilon}\)，必须证明 (7) 与
所有同尺度项发生足够精确的频率抵消。完整 divisor-lattice 的
parity 或 PSD 结构本身并不提供这种抵消；它只把问题转移成了
\(H(t)C_0(t)\) 的 Fourier 型补偿。

## 4. 路线裁决

这条计算把 note 259--260 的缺口具体化：

* 固定频率的 parity 系数不是平方根级序列，而带有 \(s=1-it\) 共振；
* three-zeta 因子化没有消掉该极点，因为 \(R(1-it,t)\) 在小非零
  \(t\) 邻域不为零；
* 物理端只有在频率积分中实现跨 \(t\) 的 signed cancellation，
  才可能降低 \(B\log B\) 主项；
* 这正是新的 arithmetic intertwiner 所需控制，不能由逐层 Schur
  或有限维 parity 正性推出。

所以本 note 不是 RH 证明，而是一个可审计的负结果：它排除了“先做
完整 parity completion，再对每个固定频率使用平方根部分和”的捷径。
