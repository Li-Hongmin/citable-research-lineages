> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Dyadic covariance 预印本：两个可审计的分析闭合缺口

日期：2026-08-16。

## 来源与范围

核验对象是 Zenodo 记录
[`10.5281/zenodo.20082725`](https://zenodo.org/records/20082725) 中的
`An_unconditional_Riemann_type_bound_for_the_Mertens_Function.pdf`（390 页，
记录日期 2026-05-08）。稿件声称由有限 dyadic covariance 分解、BDH、Kuznetsov
和 shifted-convolution 输入推出

\[
M(N)\ll_\varepsilon N^{1/2+\varepsilon}.
\]

这里不重新审查全部有限组合部分，只检查声称把标准-subcritical packet 关闭的
分析接口，尤其是 Theorem 19.216 和 Theorem 19.218（PDF pp. 310--311）。

## 缺口一：Theorem 19.216 的模乘频率比较不成立

Theorem 19.216 的证明先把 Lemma 19.215 应用于

\[
\theta=-hC_{\eta,\ell}/q_\eta,
\]

随后使用 `gcd(C_{\eta,\ell},q_\eta)=1`，声称

\[
\left\|\frac{hC_{\eta,\ell}}{q_\eta}\right\|
\asymp
\left\|\frac h{q_\eta}\right\|.
\tag{1}
\]

互素只说明乘以 \(C_{\eta,\ell}\) 是有限环上的置换，并不保持每个 residue
的距离到零。反例可以完全取整数：令 \(C>1\) 为偶数，

\[
q=Ct-1,\qquad h=t.
\]

则 \(q\) 为奇数，\(Ch=q+1\)，从而

\[
\left\|\frac hq\right\|=\frac{t}{Ct-1}\longrightarrow \frac1C,
\qquad
\left\|\frac{Ch}{q}\right\|=\frac1q.
\]

比值随 \(q\) 线性发散。最简单的实例是

\[
C=2, q=2t-1, h=t,
\]

即 \(h=(q+1)/2\)。这与稿件所用的“\(C\) 是 2 的非零幂、\(q\) 为奇模数”
完全相容。

该错误不是纯记号问题。取

\[
F(u)=\mathbf 1_{1\le u\le L},
\qquad L=\lfloor q^{1/2}\rfloor.
\]

则 \(\sup|F|+\operatorname{TV}(F)\le3\)，而

\[
\left|\sum_{u=1}^{L}F(u)e(-Chu/q)\right|
 =\frac{|\sin(\pi L/q)|}{|\sin(\pi/q)|}
 \asymp L.
\]

若按 (1) 把频率替换成 \(h/q\)，Lemma 19.215 会给出
\(O(\|h/q\|^{-1})=O_C(1)\)，与左边的 \(\asymp q^{1/2}\) 矛盾。
正确的估计只能保留 \(\|Ch/q\|^{-1}\)，或者把整个 residue 集合重新分块；
逐个 dyadic \(H<\|h\|_q\le2H\) 的结论不能由有限环置换直接得到。

因此 Theorem 19.216 的 displayed energy bound 尚未由 Lemma 19.215 推出。
一个可行的修补必须额外证明“乘以 \(C\) 后的 residue 区间失真账本”，或放弃
逐块估计而在全 residue 集合上重新聚合；两者都不是当前稿件中的一句置换论证。

### 缺口一的更早版本：后续 harmonic estimate 也不由已列假设推出

即使把 (1) 暂时替换成正确的 \(\|hC/q\|\)，稿件仍把

\[
\frac1q\sum_{H<|h|\le2H}
 \min\!\left(L,\frac q{|h|}\right)^2
\]

直接估成 \(LH/q+O(\log q/q)\)，其中 \(L=Y/A^{\rm eff}\)。这个估计在低频块
并不成立。取任意固定 \(C\)，令

\[
F(u)=\mathbf 1_{1\le u\le L},
\qquad 1\le L\ll q,
\]

则 \(F(0)=0\)，所以它已经没有被“分离 \(u=0\) 对角项”的解释覆盖；同时
\(\sum|F|=L\)、\(\sup|F|+\operatorname{TV}(F)\le3\)。在 \(H=1\) 且 \(q\gg CL\)
时，

\[
\left|\sum_{u=1}^{L}F(u)e(-Chu/q)\right|\asymp L,
\]

故对应的归一化能量为 \(\asymp L^2/q\)，而稿件的 displayed bound 只有
\(O((L+\log q)/q)\)（忽略其 polylog 因子）。令 \(L\) 超过任意固定的
polylog，即得到任意大的矛盾因子。

因此，单凭 Lemma 19.212 给出的 \(\ell^1\)-质量、sup 和总变差，不能得到
Theorem 19.216 所需的低频能量；还必须证明每个 \(\Gamma_{\eta,r,\ell}\) 的
零频和有额外消失/抵消，或改用一个真正的 \(\ell^2\)（而非 \(\ell^1\)）账本。
这与模乘频率比较错误相互独立。

## 置换真正保留的内容：只能做全 residue 重聚合

对任意有限序列 \(F\) 和 \((C,q)=1\)，正确定理是 Parseval 恒等式

\[
\frac1q\sum_{h\bmod q}
 \left|\sum_uF(u)e(-hCu/q)\right|^2
 =\sum_{a\bmod q}\left|\sum_{u\equiv a\,(q)}F(u)\right|^2.
\tag{4}
\]

对一个 dyadic residue 块 \(S_H=\{h:H<\|h\|_q\le2H\}\)，乘法置换只给出

\[
\frac1q\sum_{h\in S_H}|\widehat F(Ch/q)|^2
 =\frac1q\sum_{k\in C S_H}|\widehat F(k/q)|^2,
\]

而 \(CS_H\) 一般不是 dyadic 块，甚至可以把 \(S_H\) 中的高频 residue 映到
最低频 \(k=\pm1\)。因此 (4) 只有在所有 \(H\) 先合并时才消除 \(C\)；它不能
修复 Theorem 19.216 所需的逐块 packet law。

若只使用稿件已有的质量界，(4) 至多给出粗略上界

\[
\sum_{a\bmod q}\left|\sum_{u\equiv a(q)}F(u)\right|^2
 \le \left(1+\frac{L}{q}\right)\sum_u|F(u)|^2,
\]

在 \(\operatorname{supp}F\) 长度为 \(L\) 且 \(\sup|F|\ll(\log N)^B\) 时为
\(\ll L(1+L/q)(\log N)^{2B}\)。这既不是 Theorem 19.216 的
\(LH/q\) 逐块界，也没有和其 dual-energy 因子建立所需的匹配。故“全 residue
Parseval 修复”必须重写 packet 聚合，而非补一行置换说明。

## 一个可能的粗修补（尚未接入原稿的完整 shell 记账）

若只在 Theorem 19.216 的 displayed normalized-energy 层面使用
\(|\widehat\Gamma|\le\|\Gamma\|_1\)，而不使用错误的频率衰减，则对
\(A=A^{\rm eff}\)、\(L=Y/A\) 和一个含 \(O(H)\) 个 residue 的块，有

\[
E_X(H)\ \ll\ \frac{H}{Aq}L^2(\log N)^{O(1)}
 =\frac{H Y^2}{A^3q}(\log N)^{O(1)}.
\tag{5}
\]

这里用到的是 Proposition 19.214 的 \(A^{-1}\) 平均、每个 frozen class
的 \(\ell^1\)-质量 \(\ll L\operatorname{polylog}N\)，以及每个 residue
块的长度 \(O(H)\)；因而不依赖 \(C\) 对 residue 距离的错误比较。若同时保留
稿件的 dual-energy 界 \(E_Y(H)\ll M^{-1}\)，并对所有 dyadic \(H\le q/2\)
做 Cauchy--Schwarz，则

\[
\sum_H\sqrt{E_X(H)E_Y(H)}
 \ll \frac{Y\sqrt q}{A M}(\log N)^{O(1)}.
\tag{6}
\]

在稿件的参数关系 \(A m\asymp M\)、\(q=Q_*m\)、
\(m\ll_{Q_*}\sqrt M\) 下，右端为

\[
\ll_{Q_*}\frac{Y}{M^{5/4}}(\log N)^{O(1)}.
\tag{7}
\]

因此若全局 packet 聚合允许把 \(\kappa\) 收紧到
\(0<\kappa<1/5\)，且 shell 计数没有额外的 \(M\)-依赖损失，(5)--(7)
有可能替代错误的 \(LH/(Aq)\) 逐块估计。这不是当前稿件中的证明：还需要逐项核对
\(E_X(H)\) 的 shell 定义、跨 \(H\) 的 disjointness、对角项归属以及 capacity
因子；但它把第一个缺口从“错误的频率置换”降成一个可检验的参数/聚合命题。

### 还需核对的归一化接口

上述粗修补只适用于 Theorem 19.216 已经建立了

\[
E^X_{\nu,H,K}
 =\frac1{q_\eta}\sum_{H<|h|\le2H}|c_\eta(h)|^2
\tag{8}
\]

或等价的 shell--residue 加权恒等式。可是 Definition 20.12 的字面定义是

\[
E^X_{\nu,H,K}=\sum_{\eta\in\mathcal E^{\rm reg}_{\nu,H,K}}|c_\eta|^2,
\]

而 Definition 19.173 将 \(c_\eta\) 定义为未显示带 \(q_\eta^{-1/2}\) 权的
\(\sum_{\xi\in X_\eta}w_\xi e(\phi_\xi)\)。因此 (8) 不能只靠“normalized
energy”字样使用；必须补出 shell 频率 \(h_\eta\) 的精确多重度和归一化，或证明
这些因子已经包含在 \(w_\xi\) 中。若 (8) 不成立，(5)--(7) 只是在另一种归一化
下的形式计算，不能直接修复原定理。

## 缺口二：Theorem 19.218 没有支付无界 exact-level capacity

稿件的 Theorem 19.202 给出的变量级谱大筛本身包含

\[
A_\eta(T)=T^2+1+c_{\rm cusp}(\eta)\frac{N^X_\eta}{q_\eta},
\qquad
B_\eta(T)=T^2+1+c_{\rm cusp}(\eta)\frac{N^Y_\eta}{q_\eta}.
\tag{2}
\]

Lemma 19.205--19.206 明确承认：只有在额外的 bounded low-divisor cutoff
\(m_\eta\le C_{\rm ldg}\) 下，\(c_{\rm cusp}(\eta)\) 才能被常数吸收；
在 cutoff 外它必须留在 capacity-weighted ledger 中。

但 Definition 19.90 的 standard-subcritical 集合只要求

\[
Q_*m_\kappa(ac)^2\le4Q_*^2M,
\]

并没有 \(m_\kappa(ac)\le C_{\rm ldg}\) 的统一上界。Lemma 19.94 也只给一般的

\[
T_{\nu,H,K}\ll_{Q_*}1+M^{1/4},
\]

只有在 bounded low-divisor 子范围才给 \(T_{\nu,H,K}\ll1\)。

然而 Theorem 19.218 的证明在说明 cutoff 外 capacity “remains in the explicit
capacity-weighted ledger” 后，立即把整个贡献写成

\[
Y^\varepsilon
\sqrt{E^{X,\mathrm{std-sub}}_{\nu,H,K}}
\sqrt{E^{Y,\mathrm{std-sub}}_{\nu,H,K}},
\]

并据此取 \(o(1)\)。这一步没有给出任何不等式，把 (2) 中的
\(c_{\rm cusp}(\eta)N_\eta/q_\eta\) 从无界 cutoff 外的谱和中支付掉。

所以这里存在量词缺口：证明覆盖了 bounded low-divisor closure，但定理标题和
Definition 19.90 所定义的 sector 是无界的。要恢复结论，至少需要一个明确的
capacity-weighted energy 估计，例如对 cutoff 外的 shell 证明

\[
\sum_\eta \sqrt{A_\eta(T)B_\eta(T)}
   \sqrt{E^X_\eta E^Y_\eta}
\ll Y^\varepsilon,
\tag{3}
\]

或给出等价的加权能量定义及其闭合证明。当前稿件没有 (3)。

## 裁决

这两个缺口彼此独立：即使补上 exact-level capacity，Theorem 19.216 的 residue
频率错误仍未修复；即使修复频率分块，Theorem 19.218 仍需支付无界 capacity。
因此该 Zenodo 版本是一个值得继续重建的研究框架和候选算术路线，但目前不能
作为 \(M(N)\ll N^{1/2+\varepsilon}\) 或 RH 的证明。

对本项目的决策没有改变：当前承重门仍是包含零频的 Möbius signed-energy
估计；该预印本没有提供一个已经闭合的、可替代该门的无条件算术不等式。
