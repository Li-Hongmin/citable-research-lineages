> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 局部 Weil 谱底与第一次退化的文献归约

检索日期：2026-08-11。本文只回答一个问题：第一次退化标准形是否有足够的原始文献基础，以及它还
缺少哪个严格接口。

> **2026-08-11 进展更新。** note 004 已通过精确 logarithmic-Laplacian 归一化证明
> \(D(Q_W^a)=H((-a,a))\)，并把 finite prime-shift 公式延拓为完整 form-domain 弱方程。因此本文
> “定义域接口”一节提出的第二条路径已经完成；note 007 又完成了 finite-shift \(L^\infty\) 正则性
> 与最优边界阶上界。

## 已由原文核对的结果

下列陈述来自 Masatoshi Suzuki, *Weil's quadratic form via the screw function*,
arXiv:2606.09096（2026-06-09 版本）的正文，而不是搜索摘要：

1. 对每个 \(a>0\)，局部闭 Weil 形式 \(Q_W^a\) 对应一个典范的稠密定义自伴算子 \(A_a\)。
   Suzuki 的 Theorem 1.1 将其刻画为
   \[
   B_a=D^*G_aD,\qquad D(B_a)=H_0^1(-a,a)
   \]
   的 Friedrichs 扩张。
2. \(A_a\) 的谱下有界且离散，唯一可能的聚点为 \(+\infty\)。因此谱底 \(\lambda_a\) 是本征值，
   Rayleigh 商的下确界由某个非零 \(v_a\in D(A_a)\) 取到。零模态存在性不再是额外假设。
3. Theorem 1.3 证明 \(a\mapsto\lambda_a\) 在 \((0,\infty)\) 连续。
4. Theorem 1.4 证明充分小的 \(a>0\) 上 \(\lambda_a>0\)，并给出
   \[
   \lambda_a=\log(1/a)+\mu_1-\log(2\pi)+\psi(2)-1+O(a),\qquad \mu_1>0.
   \]
5. 论文在 Theorem 1.3 后明确使用已有的 Weil/Yoshida 等价关系：RH 失败等价于存在 \(a>0\)
   使 \(\lambda_a<0\)。结合小尺度正性与连续性，RH 失败将产生某个退化尺度。

因此，在这些原文结果下可以无条件地作如下逻辑归约：若 RH 为假，令

\[
a_*:=\inf\{a>0:\lambda_a\le0\}.
\]

则连续性和小尺度正性给出 \(a_*>0\) 与 \(\lambda_{a_*}=0\)；离散谱给出非零
\(v_*\in D(A_{a_*})\) 满足

\[
A_{a_*}v_*=0.
\]

由于 \(Q_W^{a_*}\) 半正定，极化进一步给出

\[
Q_W^{a_*}(v_*,w)=0
\quad\text{对所有 }w\in D(Q_W^{a_*}).
\]

这使“第一次退化零模态”成为严格的条件性反例标准形，而不只是研究叙事。

## 精确的有限 prime-shift 公式

Suzuki 的公式 (2.5) 对 \(v\in H_0^1(-a,a)=D(B_a)\) 写成

\[
\begin{aligned}
\langle B_av,v\rangle
={}&L_a(v)-(2A+1)\lVert v\rVert_2^2\\
&-\sum_{n\le e^{2a}}\frac{\Lambda(n)}{\sqrt n}
\left(
\int_{-a}^{a-\log n}v(x+\log n)\overline{v(x)}\,dx
+\int_{-a+\log n}^{a}v(x-\log n)\overline{v(x)}\,dx
\right)\\
&-\int_{-a}^{a}\int_{-a}^{a}r''(x-y)v(y)\overline{v(x)}\,dx\,dy .
\end{aligned}
\]

有限 cutoff \(n\le e^{2a}\) 来自平移长度 \(\log n\) 不超过区间直径 \(2a\)。这里
\(L_a\) 是含 \(|x-y|^{-1}\) 差分项和边界对数势的 Archimedean 形式；\(r\) 是局部展开中的偶
\(C^2\) 余项。

## 尚未跨越的定义域接口

不能直接把上式逐项代入首次退化本征函数。论文明确指出

\[
D(B_a)=H_0^1(-a,a)\subsetneq D(A_a),
\]

而 ground state 只保证属于 \(D(A_a)\)，并可由 \(C_c^\infty(-a,a)\) 在 form norm 下逼近。
因此，“零模态同时满足有限平移方程和经典 Dirichlet 边界条件”比文献已经证明的内容更强。

当前最薄的严格接口是下列二选一：

- 证明首次退化 ground state 实际属于 \(H_0^1(-a_*,a_*)\)，从而可使用 \(B_a\) 的强形式；或
- 在完整 form domain 上推导有限 prime-shift 公式的闭形式/弱 Euler–Lagrange 方程，并精确识别其
  边界迹与正则性。

若二者都不成立，则“紧支撑边界刚性”不能作为主线输入，研究对象必须改写为 Friedrichs form-domain
中的非局部零模态。这个接口会直接决定下一步是做正则性证明，还是放弃经典边界刚性路线。

## 文献边界

ResearchLibrary 项目矩阵：
`projects/riemann-local-weil-first-degeneration/literature-matrix.csv`。

同次检索纳入了 Suzuki 2023 的 screw-function 基础、Connes–Consani 2023 的局部算子基础、
Connes–Consani–Moscovici 2025 的有限谱近似，以及 Yoshida 1992 的历史定位。它们分别用于来源图和
备用桥梁；本 note 的新增判断只以已全文核对的 Suzuki 2026 为直接依据。Connes 等人的行列式收敛
仍是未证明的备用路线，数值谱吻合不能支持第一次退化刚性。
