> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(H^{-2}\) observation 与路径能量插值必损失三分之二个指数

日期：2026-08-14。

依赖：
[note 099](099-log-dilation-is-a-strict-l2-contraction-with-one-derivative-inverse.md)、
[note 105](105-the-cell-detector-is-zero-free-to-the-imaginary-axis.md)。

证据等级：尖锐有限维 Fourier 插值、单频最优性与 Mertens 尺度核算。
有限 dyadic 算子的 leakage observability 仍未证明。

## 1. 尖锐 spectral interpolation

固定 \(Y\ge2\)。对长度 \(\asymp Y\) 的去常数向量，写

\[
x_k=|\widehat q(k)|^2,\qquad1\le k\le Y,
\]

\[
Q=\sum_kx_k,\qquad
O=\sum_ka_kx_k,\quad a_k\asymp k^{-4},
\]

\[
D=\sum_kb_kx_k,\quad b_k\asymp(k/Y)^2.
\tag{1}
\]

\(O\) 是 note 105 的 hybrid \(H^{-2}\) observation 的高频模型，
\(D\) 是路径一阶差分能量。

**定理 1。**

\[
\boxed{Q\ll Y^{4/3}O^{1/3}D^{2/3}.}
\tag{2}
\]

事实上，

\[
x_k=(a_kx_k)^{1/3}(b_kx_k)^{2/3}
a_k^{-1/3}b_k^{-2/3},
\]

\[
\sup_ka_k^{-1/3}b_k^{-2/3}\asymp Y^{4/3},
\tag{3}
\]

故 Hölder 直接给出 (2)。

若一般 homogeneous 式写成

\[
Q\ll Y^\gamma O^aD^{1-a},
\tag{4}
\]

单频测试强制

\[
-4a+2(1-a)=0,\qquad
\gamma-2(1-a)=0.
\]

所以唯一尺度一致的三元组是

\[
\boxed{(a,1-a,\gamma)=\left(\frac13,\frac23,\frac43\right).}
\tag{5}
\]

若不去常数，则 \(O=D=0<Q\)，乘法式立即失败。可改为投影
\(\sum q=0\)，或使用含两个端点跳跃的零延拓 Dirichlet 能量

\[
D_0=|q(d_0)|^2+\sum_d|q(d+1)-q(d)|^2+|q(d_1)|^2.
\tag{6}
\]

端点 trace 会直接支付纯 Mellin carrier；因此 note 105 的单波不能
不经修改就作为 (6) 下的最优性反例。定理 1 的严格对象是去常数模型。

## 2. Mertens 指数核算

对 shell 上的 Mertens 向量，

\[
D=\sum|\Delta M|^2=\sum|\mu|^2\asymp Y.
\tag{7}
\]

若某个完整 observation \(O\) 满足定理 1 的 spectral 假设，则

\[
\boxed{Q_M(Y)\ll Y^2O(Y)^{1/3}.}
\tag{8}
\]

因此

\[
\begin{array}{c|c}
\text{输入} & \text{由 (8) 得到的 }Q_M\\
\hline
O\ll Y^{2+\varepsilon}
&Q_M\ll Y^{8/3+\varepsilon/3}\\
O\ll Y^{3-\delta}
&Q_M\ll Y^{3-\delta/3}\\
O\ll Y^{o(1)}
&Q_M\ll Y^{2+o(1)}.
\end{array}
\tag{9}
\]

所以即使赠予 RH-scale observation \(O\ll Y^{2+\varepsilon}\)，
仍达不到 RH 等价的 \(Q_M\ll Y^{2+\varepsilon}\)。该 black box
要达到 RH-scale，反而需要远强的 \(O\ll Y^{o(1)}\)。

经典零自由区给

\[
|M(x)|\ll x\Delta(x),\qquad
\Delta(x)=
\exp[-c(\log x)^{3/5}(\log\log x)^{-1/5}].
\tag{10}
\]

逐点 Abel 界遂给

\[
O\ll Y^3\Delta(Y)^2.
\tag{11}
\]

代入 (8) 只有

\[
Q_M\ll Y^3\Delta(Y)^{2/3},
\tag{12}
\]

弱于从同一个固定 envelope (10) 直接平方所得的

\[
Q_M\ll Y^3\Delta(Y)^2.
\tag{13}
\]

若允许重新缩小 (10) 中未显式的 \(c\)，不同正幂仍属同一类
零自由区衰减，不能包装成新渐近类型。形式地若
\(O\ll Y^3\Delta^\beta\)，要让 (8) 优于 (13)，至少需

\[
\boxed{\beta>6;}
\tag{14}
\]

现有输入只有 \(\beta=2\)。

## 3. 更早的有限窗断点

note 105 的正 frame 是 full-line Mellin statement；真实 dyadic Gram
只观察 \(Y<N\le2Y\)。应用 (2) 前还需

\[
\text{full-line output}
\lesssim
\text{dyadic output}
+\text{合法 boundary/derivative term}.
\tag{15}
\]

该 leakage/observability 命题目前未证。在临界频率
\(k\asymp Y^{1/3}\)，floor error 与 \(k^{-2}\) 主符号同阶，
逐项三角估计也不能替代 (15)。

所以边界有两层：

1. 有限窗尚缺 (15)；
2. 即使无偿假设 (15)，尖锐式 (8) 仍损失 \(2/3\) 个
   \(Y\)-指数。

这关闭的是“仅以负二阶 observation 加一阶路径能量作黑箱插值”
的主桥，不排除 Mertens 向量特有的非线性、算术非集中或多频
covariance 结构。
