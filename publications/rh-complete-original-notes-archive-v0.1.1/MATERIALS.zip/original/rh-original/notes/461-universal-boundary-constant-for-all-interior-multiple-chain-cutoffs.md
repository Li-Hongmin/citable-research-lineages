> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 所有内部倍数链截断都保留同一个 reciprocal 边界常数

日期：2026-08-17。

note 460 处理 $M=A^2$。同一机制实际上适用于所有满足
$A\to\infty$ 且 $B=\lfloor M/(A+1)\rfloor\to\infty$ 的内部截断。

## 1. 统一展开

由 note 459 的双曲线公式，令

\[
B=\left\lfloor\frac{M}{A+1}\right\rfloor,
\qquad
S(B)=\sum_{b\le B}\frac{\mu(b)}b,
\qquad
L(B)=\sum_{b\le B}\frac{\mu(b)\log b}{b}.
\]

对 $b\le B$，有 $M/b\ge A+1$，从而

\[
H_{\lfloor M/b\rfloor}-H_A
=\log(M/A)-\log b
+O\left(\frac bM+\frac1A\right).
\tag{1}
\]

加权求和得到精确的渐近形式

\[
\boxed{
Z_{M,A}
=\log(M/A)S(B)-L(B)
+O\left(\frac{\log(2B)}A\right).
}
\tag{2}
\]

当 $A\to\infty$、$B\to\infty$ 时，$M/A$ 与 $B$ 的比值趋于 1，
所以 $\log(M/A)=\log B+o(1)$。经典零自由区给出

\[
S(B)=o(1/\log B),
\qquad
L(B)\longrightarrow-1,
\tag{3}
\]

后者由 $1/\zeta(s)=(s-1)+O((s-1)^2)$ 和
$-\bigl(1/\zeta\bigr)'(1+)=\sum\mu(n)\log n/n$ 的 Abel 极限得到。因此

\[
\boxed{Z_{M,A}=1+o(1)}
\qquad(A\to\infty,\;M/(A+1)\to\infty).
\tag{4}
\]

## 2. 截断策略的硬边界

式 (4) 表明，不仅平方根截断，所有真正的内部截断都会在 rank-one
completion residual 中保留同一个常数 1。若希望 $Z_{M,A}$ 趋于零，至少不能让
$B=\lfloor M/(A+1)\rfloor$ 趋于无穷；也就是说，必须把 A 推到 M 的固定比例
甚至更接近完整链的尺度。此时所谓“截断”已经不再提供大幅的倍数压缩。

OMEN 对 $M=2^{10},\ldots,2^{18}$ 和 $A\asymp M^{1/3},M^{1/2},M^{2/3}$
作了浮点诊断，所得 $Z$ 均在 1 附近（最小样本为 0.99275），与式 (4) 一致。

这不是 RH 证明，而是对 completion 设计空间的统一边界：任何内部倍数链
截断都必须显式处理 reciprocal 边界常数及其非零-q signed residual。
