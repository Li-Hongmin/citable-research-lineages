> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一个十八次正 detector 同时消去五个 collective residues

日期：2026-08-15。

相关文件：[note 144](144-a-positive-degree-fifteen-detector-removes-four-collective-residues.md)、
[note 145](145-degree-fifteen-is-minimal-for-four-residue-positive-detectors.md)。

证据等级：精确 Mellin 变换与固定 floor 截断的 Bernstein 正证书。

## 1. Detector 与 Mellin 变换

令

\[
V_{18}(u)=\frac{u^2(1-u)^{11}}{8151}
\bigl(8151u^5+3645u^4+198u^3-262u^2-77u-7\bigr).
\tag{1}
\]

直接展开给出

\[
\int_0^1V_{18}(u)\,du=0,
\qquad v_1=v_3=v_5=v_7=v_9=0.
\tag{2}
\]

其 Mellin 变换为

\[
K_{18}(s)=
\frac{1083801600(s-1)}{19
(s+2)(s+4)(s+6)(s+8)(s+10)(s+11)(s+12)(s+13)
(s+14)(s+15)(s+16)(s+17)(s+18)}.
\tag{3}
\]

这里分母表示所有显示线性因子的乘积；因此除零点 s=1 外没有临界带零点。

## 2. 全半轴 Bernstein 正性

定义

\[
P_{18}(y)=\sum_{c\le y}V_{18}(c/y),\qquad y\ge1.
\tag{4}
\]

写 y=N+r，其中 N=floor(y)>=1、0<=r<1。精确求和得到

\[
P_{18}(N+r)=\frac{N(N+1)}{(N+r)^{18}}Q_N(r),
\tag{5}
\]

其中 Q_N 为十六次多项式。令

\[
\beta_{k,16}(r)=\binom{16}{k}r^k(1-r)^{16-k}.
\tag{6}
\]

若 N=1，其 Bernstein 系数为

\[
b_0=\cdots=b_{10}=0,
\qquad
(b_{11},\ldots,b_{16})=
\left(\frac4{24453},\frac{28}{13585},\frac{189}{13585},
\frac{8122}{122265},\frac{1357}{5434},\frac{4227}{5434}\right)>0.
\tag{7}
\]

若 N>=2，令 t=N-2>=0。对 k=1,...,16，
b_k(t+2) 是正数除以下列各行多项式的结果；表中系数按
t^5,t^4,t^3,t^2,t,1 排列：

\[
\begin{array}{c|r|rrrrrr}
k&D_k&c_5&c_4&c_3&c_2&c_1&c_0\\ \hline
1&570570&1746848&16398812&45847764&33396073&2448668&248395\\
2&12837825&39240380&383636520&1146319999&1012925500&220326411&9324770\\
3&4279275&13037660&132666490&423688589&441930505&143021591&5150845\\
4&4279275&12978580&137486620&469237708&564266320&228009592&8472940\\
5&2567565&7747276&85497408&311556284&422928132&197417400&8295420\\
6&855855&2570152&29568736&114798368&172629344&89301720&4472160\\
7&1426425&4269120&51211920&211087376&345846000&193638384&11936960\\
8&12837825&38375040&479688000&2089268992&3677317440&2199529728&170168320\\
9&1426425&4269120&55516080&254128976&475076640&301771584&29576960\\
10&855855&2570152&34685064&165961648&326725776&220242880&27363840\\
11&2567565&7747276&108184492&538427124&1109899928&796390880&124481280\\
12&4279275&12978580&186977880&964150308&2074531300&1592926992&308555520\\
13&4279275&13037660&193275010&1029773789&2310499830&1909803216&448899360\\
14&12837825&39240380&597372980&3283684599&7686871485&6872998836&1912532160\\
15&570570&1746848&27272388&154583524&378058587&366564238&117706120\\
16&570570&1746848&27949568&163386864&418062432&439374073&158939620
\end{array}
\tag{8}
\]

除 k=0 外表中所有系数均为正。对 k=0，有

\[
b_0(N)=\frac{(N-1)(1746848N^4-14791632N^2+31364905)}{570570}>0
\qquad(N\ge2).
\tag{9}
\]

最后一个不等式在 N=2 时分子内括号为 147945，而其导数在
(N\ge3) 为正。因此所有 Bernstein 系数非负，得到严格的全半轴结论

\[
\boxed{P_{18}(y)\ge0\qquad(y\ge1).}
\tag{10}
\]

## 3. RH 等价门与五个 residue 的移位

置

\[
U_{18}(x)=\sum_{n\ge1}\mu(n)V_{18}(n/x),
\qquad
T_{18}(x)=\sum_{a,b\le\sqrt x}\mu(a)\mu(b)P_{18}(x/(ab)).
\tag{11}
\]

由于 V18(u)=O(u^2) 于零，精确截断卷积给出

\[
T_{18}(x)=-U_{18}(x)+O(x^{-1/2}).
\tag{12}
\]

结合 (3) 的 zero-free Mellin detector 定理，

\[
\boxed{\mathrm{RH}\iff
T_{18}(x)\ll_\varepsilon x^{1/2+\varepsilon}.}
\tag{13}
\]

首批非零 odd 系数为 v11,v13,v15,v17，故 collective skeleton 为

\[
T_{18}(x)=
\frac{707584}{233415}\frac{S_{11}(\sqrt x)^2}{x^{11}}
-\frac{50176}{1881}\frac{S_{13}(\sqrt x)^2}{x^{13}}
+\frac{25926656}{415701}\frac{S_{15}(\sqrt x)^2}{x^{15}}
-\frac{44919808}{1393821}\frac{S_{17}(\sqrt x)^2}{x^{17}}
+T_{18}^{(0)}(x),
\tag{14}
\]

其中 T18^(0) 的周期系数均值为零。该层进一步减少一个显式 collective
residue，但没有消除完整 signed Möbius cancellation；(13) 仍是 RH-strength 的
未决门。

## 4. 次数下界

在 P_V>=0、端点条件及五个 moment 条件下，式 (2) 的 k=2,...,11
项同样强迫

\[
u^2(1-u)^{11}\mid V(u).
\tag{15}
\]

若 deg(V)<=17，写商为 a0+a1*u+a2*u^2+a3*u^3+a4*u^4。四个
odd moment 与零均值给出的精确系统为

\[
\begin{aligned}
v_3&=-11a_0+a_1,\\
v_5&=-165a_0+55a_1-11a_2+a_3,\\
v_7&=-11(42a_0-30a_1+15a_2-5a_3+a_4),\\
v_9&=-33(10a_0-14a_1+14a_2-10a_3+5a_4),\\
\int_0^1V&=(1020a_0+204a_1+51a_2+15a_3+5a_4)/1113840.
\end{aligned}
\tag{16}
\]

其有理矩阵满秩，唯一解为零。因此次数十八是该自然端点平坦多项式类中
同时消去五个 odd residues 的最小次数；(1) 取的是唯一非零方向的正 orientation。
