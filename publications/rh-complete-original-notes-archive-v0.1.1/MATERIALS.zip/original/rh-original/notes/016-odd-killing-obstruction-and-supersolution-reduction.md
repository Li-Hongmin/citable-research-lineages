> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Prime-free 奇扇区的负 killing 障碍与 supersolution 归约

> **后续闭合（2026-08-11）：** [note 017](017-prime-free-odd-yukawa-gap.md) 用
> digamma--Yukawa 分解与十五项 Robin 证书直接证明
> \(A_a^-\succeq0.0102973827753I\) 于全部 \(0<a\le\frac12\log2\)。
> 因而本文的 Barta 归约仍然正确，但已不再是 prime-free 奇扇区的未闭合铰链。

日期：2026-08-11。本文继续 note 014 的半区折叠，检验能否把奇扇区完整算子直接写成“正跳核加
非负 killing”。结果是否定的：负极点秩一项确实增强跳核，但同时降低 killing 势；后者在合法的
prime-free 尺度内已经变号。本文给出精确反例，并把剩余正性问题归约为一个非局部
ground-state/Barta 不等式。

## 1. 完整奇算子的半区表示

记

\[
k(t)=\frac{e^{-t/2}}{1-e^{-2t}},
\qquad
s(x)=\sinh(x/2),
\]

\[
J(r)=\int_r^\infty k(t)\,dt
=\frac12\log\frac{1+e^{-r/2}}{1-e^{-r/2}}
+\arctan(e^{-r/2}),
\]

\[
C_0=\psi(1/4)-\log\pi
=-\gamma-\frac{\pi}{2}-\log(8\pi).
\]

在 note 014 的酉折叠下，

\[
q_{M,a}^-(f)
=
\frac12\iint_{(0,a)^2}
K_-(x,y)|f(x)-f(y)|^2\,dx\,dy
+\int_0^a(V_-(x;a)+C_0)|f(x)|^2\,dx,
\]

其中

\[
K_-(x,y)=k(|x-y|)-k(x+y),
\]

\[
V_-(x;a)=J(a-x)+2J(x)-J(a+x).
\]

又

\[
\langle U_-f,s\rangle
=\sqrt2\int_0^af(x)s(x)\,dx.
\]

令

\[
S_a=\int_0^as(y)\,dy=2(\cosh(a/2)-1).
\]

恒等式

\[
\begin{aligned}
-4\left|\int_0^afs\right|^2
={}&
\frac12\iint_{(0,a)^2}
4s(x)s(y)|f(x)-f(y)|^2\,dx\,dy\\
&-4S_a\int_0^as(x)|f(x)|^2\,dx
\end{aligned}
\]

给出

\[
\boxed{
q_{A,a}^-(f)
=
\frac12\iint_{(0,a)^2}
K_A(x,y)|f(x)-f(y)|^2\,dx\,dy
+\int_0^aW_a(x)|f(x)|^2\,dx,}
\]

其中

\[
\boxed{
K_A(x,y)
=k(|x-y|)-k(x+y)+4s(x)s(y)>0,}
\]

\[
\boxed{
\begin{aligned}
W_a(x)
={}&J(a-x)+2J(x)-J(a+x)+C_0\\
&-8\sinh(x/2)(\cosh(a/2)-1).
\end{aligned}}
\]

因此负秩一项同时产生：

\[
K_-\longmapsto K_-+4s\otimes s,
\qquad
V_-+C_0\longmapsto W_a.
\]

前者严格增强正跳跃，后者则严格降低点态势。

## 2. 点态 killing 非负命题为假

取

\[
a=\frac13,
\qquad
x=\frac5{24}.
\]

因为

\[
\frac13<\frac{\log2}{2},
\]

该尺度严格位于 prime-free 区间。把 \(a,x\) 代入上一节的初等闭式，用 Arb 有向球算术在
60 位十进制精度直接求值得到

\[
W_{1/3}(5/24)
\in
[-0.1283246165633783107296636031834407635221284437157536375354
\pm1.94\times10^{-59}],
\]

因而

\[
\boxed{
-0.129<W_{1/3}(5/24)<-0.128.}
\]

因此

\[
\boxed{
W_a(x)\ge0
\quad
\forall\,0<x<a\le\frac{\log2}{2}}
\]

为假。特别地，不能仅凭

\[
K_A>0,\qquad W_a\ge0
\]

把 \(A_a^-\) 识别成全范围 Dirichlet form；第二个前提已经被显式反例否定。

这个反例不说明 \(A_{1/3}^-\) 有负谱，因为正 jump 项可能吸收局部负势。真正剩余的是非局部补偿
不等式。

## 3. 正 supersolution 的精确归约

设固定尺度 \(a\le\frac12\log2\)，且存在

\[
h\in D(A_a^-),\qquad h(x)>0\quad(0<x<a),
\]

使得

\[
\frac{A_a^-h}{h}\ge\delta
\quad\text{a.e.}
\]

对某个 \(\delta>0\) 成立。对 \(\varphi\in C_c^\infty(0,a)\)，令 \(g=\varphi/h\)。直接展开二次型
得到

\[
\boxed{
\begin{aligned}
q_{A,a}^-(\varphi)
&-\int_0^a\frac{A_a^-h}{h}|\varphi|^2\,dx\\
&=
\frac12\iint_{(0,a)^2}
K_A(x,y)h(x)h(y)|g(x)-g(y)|^2\,dx\,dy
\ge0.
\end{aligned}}
\]

由 form-core 闭包，

\[
\boxed{
\frac{A_a^-h}{h}\ge\delta>0
\quad\Longrightarrow\quad
A_a^-\succeq\delta I.}
\]

这正是非局部 ground-state/Barta 机制。Frank--Seiringer 的一般非负对称核
ground-state representation 给出同一抽象接口；这里的 \(K_A,W_a\) 和候选 \(h\) 是 Weil
算子特有的数据。

## 4. 端点尺度只需一次认证

note 003 的零延拓域单调性保持奇偶性；把同一 min--max 论证限制到奇子空间，得到

\[
0<a<b
\quad\Longrightarrow\quad
\lambda_1^-(b)\le\lambda_1^-(a).
\]

因此要证明

\[
A_a^->0
\qquad
\left(0<a\le\frac12\log2\right),
\]

只需在

\[
a_*=\frac12\log2
\]

构造一个满足

\[
\frac{A_{a_*}^-h}{h}\ge\delta>0
\]

的正 supersolution。端点严格正与奇谱底单调不增即推出所有较小尺度严格正，无需同时认证全部尺度。

探索层已经找到具有明显正余量的显式候选；在完成全区间有向舍入积分以前，它不构成定理，保留于
scratch/。本文的永久结论仅包括：

\[
\boxed{\text{点态 killing 非负路线失败；}}
\]

\[
\boxed{\text{prime-free 奇正性降为端点上的单个 supersolution 证书。}}
\]

### 4.1 端点轮廓的尖锐必要阈值

令 \(d=a_*-x\downarrow0\)、\(L=\log(1/d)\)，并设正候选在右端满足

\[
h(a_*-d)=C L^{-\beta}(1+o(1)),
\qquad 0<\beta<1.
\]

由

\[
k(t)=\frac1{2t}+O(1),
\qquad
W_{a_*}(a_*-d)=\frac12L+O(1),
\]

以及变换 \(r=a_*-y,\ u=\log(1/r)\)，奇异 jump 项给出

\[
\begin{aligned}
\frac1{h(a_*-d)}
\int_0^{a_*}K_A(a_*-d,y)
\bigl(h(a_*-d)-h(y)\bigr)\,dy
&=-\frac{\beta}{2(1-\beta)}L+o(L).
\end{aligned}
\]

因此

\[
\boxed{
\frac{(A_{a_*}^-h)(a_*-d)}{h(a_*-d)}
=
\frac{1-2\beta}{2(1-\beta)}L+o(L).}
\]

这给出当前 Barta 构造的尖锐端点分叉：

\[
\boxed{
\beta>\frac12\Longrightarrow\frac{A^-h}{h}\to-\infty,
\qquad
\beta<\frac12\Longrightarrow\frac{A^-h}{h}\to+\infty.}
\]

临界值 \(\beta=1/2\) 由次阶项决定。此前使用 \(\beta=11/20\) 的候选必然失败；有限网格遗漏了
指数薄的负端点 collar。修正后的探索候选取 \(\beta=9/20\)，其右端主系数为 \(1/11\)，左端主
系数为 \(1\)。高精度非认证求积给出内部最小值约 \(0.0658414\)，但这仍不能替代覆盖整个开区间的
有向舍入证书；在该证书完成前，不宣称 \(A_{a_*}^->0\)。

## 5. 来源与边界

- Masatoshi Suzuki, *Weil's quadratic form via the screw function*,
  [arXiv:2606.09096](https://arxiv.org/abs/2606.09096)：局部 Weil 形式与 prime-shift 阈值。
- Rupert L. Frank and Robert Seiringer,
  *Non-linear ground state representations and sharp Hardy inequalities*,
  [arXiv:0803.0503](https://arxiv.org/abs/0803.0503)，Proposition 2.3：一般非负对称核在
  \(p=2\) 时的精确 ground-state representation。
- [note 014](014-prime-free-odd-schur-reduction.md)：半区严格正核与不可见奇零核的排除。

本文没有把浮点 supersolution 预检升级为证明，也没有宣称 prime-free 奇 Schur 标量已经严格为正。
