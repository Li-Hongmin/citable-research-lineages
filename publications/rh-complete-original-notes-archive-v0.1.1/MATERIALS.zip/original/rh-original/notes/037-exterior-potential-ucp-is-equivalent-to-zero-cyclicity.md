> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exterior-potential UCP 与 zero-cyclicity 的等价性

日期：2026-08-11。

note 036 提出把不可见核排除归约为外侧 Archimedean 势在开区间消失。本文证明该外侧命题与
zero-cyclicity 本身等价，而不是更弱的中间引理；同时说明 Wiener--Hopf、Paley--Wiener 和
extension/jump 表示为何不自动提供所需的外侧齐次条件。

## 1. 外侧消失等价于 (u=0)

对支撑于 ([-a,a]) 的 (u)，note 036 给出

\[
(\mathcal Ku)(x)
=e^{-x/2}\sum_{m\ge0}U_m^+e^{-2mx},
\qquad x>a.
\]

因此

\[
\mathcal Ku=0\ \text{于任一右外侧开区间}
\iff U_m^+=0\quad\forall m.
\]

变量替换 (w=e^{2y}) 和多项式稠密性随即给出 (u=0)。左侧同理。故

\[
\boxed{
\mathcal Ku=0\ \text{于任一非空外侧开区间}
\iff u=0.}
\tag{1}
\]

所以在 (ker M_a^sigma\cap\phi_sigma^perp) 上证明外侧势消失，逻辑上已经等同于证明该交集
为零。

## 2. 压缩方程保留自由外侧数据

令 (I=(-a,a))，(T) 表示相应全线 multiplier 与有限 shifts 的和。压缩零方程

\[
P_ITP_Iu=0
\]

只说明

\[
g:=Tu,
\qquad \operatorname{supp}g\subset I^c.
\tag{2}
\]

把 (g) 分成左右外侧部分 (g_+,g_-)，Fourier 侧得到 Wiener--Hopf 关系

\[
m_a(\xi)\widehat u(\xi)
=\widehat g_+(\xi)+\widehat g_-(\xi).
\tag{3}
\]

(g_pm) 是未知的外侧 Hardy 数据，而不是零。polar orthogonality 只给

\[
U_0^pm=0
\iff
\widehat u(\mp i/2)=0.
\tag{4}
\]

两个离散采样条件不能由 (3) 消去无限维的 (g_pm)，也不能强迫其余
(widehat u(\mp i\rho_m)) 消失。

## 3. Extension 与 finite shifts 不改变障碍

logarithmic extension 或边界 jump relation 把 (g_pm) 表示为非局部 Neumann flux，但压缩
方程没有给出零 flux。式 (4) 只把最远场的 (e^{-|x|/2}) 系数杀掉，使首个可能项变成
(e^{-5|x|/2})；它不令完整 flux 消失。

固定尺度的 finite prime shifts 只把全线符号增加一个有限三角多项式，并改变 (3) 的有限延迟
部分；它们不会消除外侧 Hardy 数据，也不会把两个采样条件升级成无限采样条件。

## 4. 最终不可再拆的命题

没有上述一般表示可以证明外侧势消失，除非已经使用了真实算子核的额外特性。当前最薄的等价目标
因此应直接写成 leading exterior flux 非退化：

\[
\boxed{
0\ne u\in\ker M_a^sigma
\Longrightarrow
U_0^+\ne0\ \text{或}\ U_0^-\ne0.}
\tag{5}
\]

在固定奇偶扇区，两者由奇偶性相互决定，所以 (5) 正是

\[
\ker M_a^+\cap\cosh(x/2)^\perp=\{0\},
\qquad
\ker M_a^-\cap\sinh(x/2)^\perp=\{0\}.
\]

因此 exterior-potential UCP、完整指数矩消失和 zero-cyclicity 是同一难度层级。后续若无新的
真实算子结构，不应继续在这三种等价表述之间循环。
