> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有限整数系数空间不能实现 Möbius mode 的频率反射

日期：2026-08-16。

note 337 把 reciprocal-Hankel 核写成
\(\mathcal F_N^*M_hR\mathcal F_N\)。本 note 证明一个简单但严格的
有限维障碍：频率反射 \(R\) 不能由任何有限 \(N\times N\) 整数系数矩阵
在 Möbius mode 上逐点实现。

## 命题

令
\[
 (\mathcal F_Nx)(t)=\sum_{n\le N}x_n e^{it\log n},
 \qquad
 \mu_N=(\mu(1),\ldots,\mu(N))^T.
\]
若 \(N\ge2\)，不存在矩阵 \(J_N\in M_N(\mathbb C)\) 使
\[
 \mathcal F_N(J_N\mu_N)(t)
 =(\mathcal F_N\mu_N)(-t)
 \qquad\text{对所有 }t\in\mathbb R.
\tag{1}
\]

## 证明

设 \(c=J_N\mu_N\)。式 (1) 等价于
\[
 \sum_{m\le N}c_m e^{it\log m}
 =
 \sum_{n\le N}\mu(n)e^{-it\log n}.
\tag{2}
\]
有限个具有互异实频率的指数函数 \(e^{i\lambda t}\) 在线性上独立。左侧
的频率集合为
\[
\{\log m:1\le m\le N\}\subset[0,\infty),
\]
右侧的频率集合为
\[
\{-\log n:1\le n\le N\}\subset(-\infty,0].
\]
除了零频率 \(m=n=1\) 外，两集合互不相交。因此 (2) 强迫
\[
 c_m=0\quad(m>1),\qquad \mu(n)=0\quad(n>1).
\]
但 \(N\ge2\) 时 \(\mu(2)=-1\)，矛盾。命题得证。

## 含义

这排除了最直接的有限维实现：

* 不能用一个 \(N\times N\) 算术矩阵把 \(R\mathcal F_N\mu_N\) 精确变成
  \(\mathcal F_N(J_N\mu_N)\)；
* note 337 式 (6) 若只要求某个固定权 \(M_h\) 下的单个二次型相等，
  可能存在偶然的有限投影，但那不是逐点 intertwiner，也不能自动在
  不同 \(h\)、不同 \(N\) 或开参数域上相容；
* 真正的 \(J_N\) 必须是无限维频率算子、具有随 \(N\) 增长的非局部支撑，
  或只给出带有可审计误差的近似反射。

因此，要沿 note 337 继续推进，最小可检验命题应改为：构造
\(J_N^{\mathrm{approx}}\) 及误差 \(E_N(t)\)，满足
\[
 \mathcal F_N(J_N^{\mathrm{approx}}\mu_N)(t)
 =F_N(-t)+E_N(t),
\]
并证明误差在 \(M_h\) 配对中小于平方根级余量。仅有有限矩阵的
exact coefficient-space factorization 不可能完成这一任务。
