> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Averaged-Chowla 不提供 dyadic 相关的二阶门

日期：2026-08-16。

## 目标二阶门

令
\[
C_h(X)=\sum_{n\le X-h}\mu(n)\mu(n+h),
\qquad
D_H(X)=\sum_{H\le h<2H}C_h(X).
\]
Fourier/Bessel 路线最自然需要的是
\[
\sum_{H<X}|D_H(X)|^2\ll_\varepsilon X^{2+\varepsilon},
\tag{1}
\]
或更强但结构更直接的
\[
\sum_{h\le X}|C_h(X)|^2\ll_\varepsilon X^{2+\varepsilon}.
\tag{2}
\]
(1) 才能通过 dyadic Cauchy--Schwarz 给出
\(\sum_H|D_H(X)|\ll X^{1+\varepsilon}\)，再关闭 Mertens/RH 门。

## 现有平均结果的量词

Lichtman 的 averaged-Chowla 结果（[QJM 论文](https://academic.oup.com/qjmath/article/73/2/729/6446139)）
给出的是移位的 \(L^1\) 型估计，例如
\[
\sum_{h\le H}
\left|\sum_{n\le X}\mu(n+h)G(n)\right|
\ll XH\,\rho(X,H),
\]
其中 \(\rho\) 只有对数级衰减，且 \(G\) 属于其允许的测试类。
这不是同一相关序列 \(C_h(X)\) 的二阶平均。

即便把它特化为 \(G(n)=\mu(n)\)，再用
\[
\sum_{h\le H}|C_h(X)|^2
\le X\sum_{h\le H}|C_h(X)|,
\]
也只得到
\[
\sum_{h\le H}|C_h(X)|^2
\ll X^2H\,\rho(X,H).
\tag{3}
\]
在宏观 \(H\asymp X\) 时，这是 \(X^{3-o(1)}\)，而不是 (2) 所需的
\(X^{2+\varepsilon}\)。

## 为什么不能用一次 Cauchy 修复

对任意有限序列，已知 \(\sum_h C_h^2\ll X^2\) 也不能推出 (1)：
\[
|D_H|^2
\le H\sum_{H\le h<2H}|C_h|^2
\]
会在最大的 \(H\) 处重新损失一个 \(H\) 因子。要得到 (1)，必须控制
同一 dyadic 壳内的跨移位 signed covariance，而不是只控制各个 \(C_h\)
的平方和。

一个抽象模型已经说明这一区别：取一个独立的对角噪声序列，再加入振幅
\(X^{-1/4}\) 的单一 Fourier mode。该 mode 可使宏观壳内每个 \(C_h\)
贡献约 \(X^{1/2}\)，于是 \(D_H\asymp X^{3/2}\)，但
\(\sum_h|C_h|^2\asymp X^2\)。因此 (2) 本身仍不足以替代真正的
block-square 门 (1)。

## 裁决

当前公开 averaged-Chowla 输入没有关闭 (1)，也没有给出 (2) 的固定幂次
改进；它至多提供 \(X^{2-o(1)}\) 级别的平均基线。要沿 Fourier/相关路线
继续，最小新算术命题应直接针对
\[
\sum_H\left|\sum_{H\le h<2H}
\sum_{n\le X-h}\mu(n)\mu(n+h)\right|^2
\]
保留跨 \(h\) 符号的平方和，而不是再对单个移位应用 Cauchy。
本记录不声称 RH。

