> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Guth--Maynard 大值定理不能直接关闭固定 Mellin 能量门

日期：2026-08-17。

## 1. 可用的外部定理

Guth--Maynard 的论文
[New large value estimates for Dirichlet polynomials](https://doi.org/10.4007/annals.2026.203.2.6)
的主定理处理
\[
S(t)=\sum_{N<n\le 2N} b_n n^{it},\qquad |b_n|\le1,
\]
并对区间 \([0,T]\) 中的 \(1\)-分离点集给出大值点数上界。该结果的主要新应用是
零密度估计和短区间素数问题；它不是固定有界频带上的 \(L^2\) Möbius 估计。

## 2. 当前能量门需要的不同尺度

本项目的门是
\[
E_N(w)=\int_{\mathbb R}w(t)
\left|\sum_{n\le N}\mu(n)n^{it}\right|^2\,dt,
\]
其中 \(w\) 在固定有界频带内有正质量。若想由点值控制积分，最直接的
Lipschitz 估计是
\[
\left|\frac{d}{dt}\sum_{n\le N}\mu(n)n^{it}\right|
\le \sum_{n\le N}\log n\ll N\log N.
\]
因此固定 \(t\)-区间需要的采样间距是 \(O(1/\log N)\)，而不是定理中的
常数级 \(1\)-分离间距；采样点数为 \(O(\log N)\)。

把 \(t\) 重标为 \(u=t\log N\) 也不能直接套用该定理，因为相位变成
\[
\sum_{n\le N}\mu(n)\exp\!\left(iu\frac{\log n}{\log N}\right),
\]
这不是标准形式 \(\sum b_n n^{iu}\)。因此仍缺一个针对密集
\(\log n/\log N\) 频率的、固定窗口的 large-values/energy theorem。

## 3. 路线裁决

Guth--Maynard 的结果不能从现有形式推出
\[
E_N(w)\ll_\varepsilon N^{1+\varepsilon}.
\]
即便建立相应的频率归一化版本，还必须在低频窗口保留 Möbius 的 signed
cancellation；这正是 note 246 已证明与 RH 等价的门，而不是一般 Dirichlet
多项式的大值估计可以自动提供的结论。

所以该文献是当前零密度和大值路线的重要进展，但对本项目的固定
Mellin--Möbius 能量只形成一个明确的适用边界，不改变 RH 的未决状态。
