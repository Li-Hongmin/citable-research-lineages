> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Renormalized logarithmic Pohozaev 铰链与 prime virial 障碍

日期：2026-08-11。

本文从已发表的 fractional Pohozaev identity 与可直接验证的 Fourier scaling law 锁定 pure
logarithmic Laplacian 的候选边界恒等式，并精确计算 finite prime jumps 的尺度修正。候选恒等式
尚未证明；prime 修正则严格无定号。

## 1. Pure logarithmic 候选恒等式

在 \((0,1)\) 上，restricted fractional eigenpair 满足

\[
(-\Delta)^su_s=\Lambda_su_s,
\qquad u_s=0\text{ on }\mathbf R\setminus(0,1).
\]

fractional Pohozaev identity 给出

\[
2s\Lambda_s\|u_s\|_2^2
=\Gamma(1+s)^2b_{s,R}^2,
\qquad
b_{s,R}=\lim_{x\uparrow1}(1-x)^{-s}u_s(x).
\tag{1}
\]

若 \(\Lambda_s=1+s\lambda+o(s)\)、\(u_s\to u\)，则形式极限锁定

\[
\frac{b_{s,R}^2}{s}\longrightarrow2\|u\|_2^2.
\tag{2}
\]

因此自然的 logarithmic boundary gauge 是

\[
\mathcal B_Ru
=\lim_{x\uparrow1}\sqrt{\log\frac1{1-x}}\,u(x),
\tag{3}
\]

候选 renormalized identity 为

\[
\boxed{|\mathcal B_Ru|^2=2\|u\|_2^2.}
\tag{RP}
\]

常数 \(2\) 还由全线 scaling law 独立锁定。若

\[
(U_tu)(x)=e^{t/2}u(e^tx),
\]

则

\[
U_t^{-1}L_\Delta U_t=L_\Delta+2tI.
\tag{4}
\]

对区间本征函数，dilation generator 不属于 Dirichlet form domain；边界截断产生的 defect 必须
支付 (4) 中的 \(2\|u\|_2^2\)。式 (4) 本身尚未把该 defect 识别成 (3) 的平方。

## 2. 为什么 (RP) 会证明 pure log 全谱简单

若 \(\mathcal B_R\) 是任一 logarithmic 本征空间 \(E_\lambda\) 上的线性泛函，且 (RP) 对所有
\(u\in E_\lambda\) 成立，则极化给出

\[
\operatorname{Re}\bigl(\mathcal B_Ru\overline{\mathcal B_Rv}\bigr)
=2\operatorname{Re}\langle u,v\rangle.
\]

一维边界数据不可能等距嵌入二维本征空间，故

\[
\dim E_\lambda\le1.
\]

所以真正缺少的最小定理是：一般变号 logarithmic eigenfunction 的精确线性 gauge trace (3)
存在，并满足 (RP)。现有文献只给

\[
|u(x)|\le C\bigl(\log(1/\delta(x))\bigr)^{-1/2}
\]

及正解的 Hopf 型 liminf，尚不足以定义该 trace。

不能仅由 \(s\downarrow0\) 推出 (RP)：零阶算子 \((-\Delta)^0=I\) 无限重，fractional 高阶分裂
可能只选择 logarithmic 退化空间的一组基；单个简单分支的 (1) 不自动覆盖该空间的所有线性组合。

特别需要记录：arXiv:2411.15985 曾声称 logarithmic Pohozaev identity，但官方元数据已将其标为
withdrawn，并明确注明撤回原因为其 Pohozaev identity 证明存在关键错误。它不能作为 (RP) 的证据。

## 3. Prime jump 的精确 virial

将 \(u\) 零延拓，固定 \(0<d<2a\)，令

\[
q_d(u)=\alpha\|u-T_du\|_2^2
=2\alpha\|u\|_2^2-2\alpha\operatorname{Re}C_u(d).
\]

对 \(L^2\)-保持缩放 \((V_su)(x)=e^{-s/2}u(e^{-s}x)\)，有

\[
q_d(V_su)=q_{e^{-s}d}(u),
\]

从而

\[
\boxed{
\left.\frac d{ds}\right|_{s=0}q_d(V_su)
=-d\,\partial_dq_d(u)
=-2\alpha d\int_{\mathbf R}\xi\sin(\xi d)|\widehat u(\xi)|^2\,d\xi.}
\tag{5}
\]

对 \(H_0^1\) 数据，物理侧等价为

\[
2\alpha d\operatorname{Re}
\int_{-a}^{a-d}u'(x+d)\overline{u(x)}\,dx.
\]

若允许非零端点迹，还必须加入显式 collar term
\(-u(a)\overline{u(a-d)}\)。在 logarithmic form domain 上，(5) 的合法化本身需要边界逼近。

## 4. Prime virial 无定号且不能由能量消去

式 (5) 的 multiplier

\[
-2\alpha\xi d\sin(\xi d)
\]

在连续频带间反复换号。窄频包可分别实现正、负 virial；奇偶限制不改变这一点。一个 parity sector
中的 polar orthogonality 只是一项线性约束，可通过加入小的第二频包满足，同时保持原 virial 符号。

prime energy multiplier 与 virial multiplier 分别为

\[
2\alpha(1-\cos(\xi d)),
\qquad
-2\alpha\xi d\sin(\xi d).
\]

二者不成比例，其比值换号并在不同频带无界。因此总零能量方程不能消去 prime virial；多个 delays
也没有共同符号。

## 5. 对 A 线的精确判定

Pure logarithmic Pohozaev 路线保留为一个明确 boundary-trace 定理，而不是已证结果。加入 active
primes 后，pure-log 的正边界 defect 不能直接继承；必须证明对真实零模态的联合估计

\[
2\|u\|_2^2
+\sum_{\log n<2a}V_{\log n}(u)
+\text{其他有界项}
>0,
\]

或找到能由本征方程精确改写该和的恒等式。对任意测试函数，prime virial 已严格没有符号。

## 6. 来源

- M. Kwaśnicki, *Simplicity of eigenvalues of the fractional Laplace operator in an interval*,
  arXiv:2311.00713.
- X. Ros-Oton and J. Serra, *The Pohozaev Identity for the Fractional Laplacian*, Arch. Rational
  Mech. Anal. 213 (2014), 587--628.
- H. Chen and T. Weth, *The Dirichlet Problem for the Logarithmic Laplacian*, arXiv:1710.03416.
- V. Hernández-Santamaría, L. F. López Ríos and A. Saldaña, *Optimal boundary regularity and a
  Hopf-type lemma for Dirichlet problems involving the logarithmic Laplacian*, arXiv:2401.18033.

