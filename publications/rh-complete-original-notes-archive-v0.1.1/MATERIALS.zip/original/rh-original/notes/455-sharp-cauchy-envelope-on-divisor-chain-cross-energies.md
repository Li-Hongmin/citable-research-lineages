> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 除数链交叉项的精确 Cauchy 包络与无收缩结论

日期：2026-08-17。

note 453 给出 \(e=ad\) 时的精确交叉公式。本 note 计算其中抽样尾的完整
Lehmer 加权范数，说明链上的显式 \(1/a\) 因子不会自动带来总体收缩。

## 1. 抽样尾范数

沿用

\[
M=\left\lfloor\frac Nd\right\rfloor,\qquad
M'=\left\lfloor\frac N{ad}\right\rfloor,
\]

\[
A_q(M)=\sum_{q<n\le M}\frac{\mu(n)}n,
\qquad S(M)=A_0(M).
\]

定义抽样序列 \(Y_q=A_{\lfloor q/a\rfloor}(M')\)，\(1\le q<M\)。将
\(q=ar+s\) 分块后，得到

\[
\boxed{
\sum_{q=1}^{M-1}(2q+1)Y_q^2
=a^2\mathcal E_{M'}
+(a^2-1)S(M')^2,
}
\tag{1}
\]

其中 \(\mathcal E_{M'}=I_{M'}/\pi\)。OMEN 已用精确有理数对
\(N=20,31,64\) 的全部 \(d,a\) 核验 (1)。

## 2. 链交叉项的 sharp Cauchy 包络

由 note 453，

\[
(G_N)_{d,ad}
=\frac1a\left[
\left(1-\frac1{d^2}\right)S(M)S(M')
+\sum_{q=1}^{M-1}(2q+1)A_q(M)Y_q
\right].
\]

对第二项应用 Cauchy--Schwarz 和 (1)，得到

\[
\boxed{
\left|(G_N)_{d,ad}\right|
\le
\frac{1-d^{-2}}a\,|S(M)S(M')|
+\sqrt{\mathcal E_M}\,
\sqrt{\mathcal E_{M'}+\left(1-a^{-2}\right)S(M')^2}.
}
\tag{2}
\]

第二项的主量没有 \(1/a\) 衰减：抽样重复的 \(a^2\) 个权重正好抵消了
外部的 \(1/a\)。因此只靠除数链的 dilation 因子，不能把非对角 signed
相关自动压成可求和的小误差。

## 3. 边界

式 (2) 是不使用符号抵消的 sharp 包络；真正的 RH-strength 路线必须利用
\(\sum_q A_q(M)A_{\lfloor q/a\rfloor}(M')\) 的 signed cancellation，或在
lcm 残类之间建立额外的相消。该 note 因而排除一个简单的收缩猜想，但不提供
RH 证明。
