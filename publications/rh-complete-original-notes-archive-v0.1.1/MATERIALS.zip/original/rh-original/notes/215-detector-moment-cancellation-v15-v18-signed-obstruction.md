> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# V15/V18 有符号组合可消去零频，但不能无条件改善正能量门

日期：2026-08-15。

本 note 检查一个最便宜的“多 detector 消去低阶 Taylor 项”方案。结论是：
有符号线性组合确实可以把 Mellin/Fourier 符号在 (t=0) 的首项消掉，
并且不在开临界带引入新的 Mellin 零点；但是正 detector 的逐项非负性必然丢失，
而把符号取绝对值后，低频 Mertens 通道的直接控制反而变弱。该构造没有给出
任何无条件的能量幂次改善，也不构成 RH 证明。

## 1. 一个精确的一阶消零组合

沿用 notes 144、146 的两个正 detector。其 Mellin 变换为

\[
 K_{15}(s)=\frac{415134720(s-1)}{(s+2)(s+4)(s+6)(s+8)(s+9)\cdots(s+15)},
\]

\[
 K_{18}(s)=\frac{1083801600(s-1)}{19(s+2)(s+4)(s+6)(s+8)(s+10)(s+11)\cdots(s+18)}.
\]

在 (s=0) 有

\[
 K_{15}(0)=-\frac1{30},\qquad K_{18}(0)=-\frac7{831402}.
\]

因此取

\[
 K_*(s):=K_{15}(s)-\frac{138567}{35}K_{18}(s)
\tag{1}
\]

可精确消去 (K_*(0))。通分并约去公因子后，

\[
 K_*(s)=
 \frac{415134720\,s(s-1)(s^2+51s+322)}{
 (s+2)(s+4)(s+6)(s+8)(s+9)(s+10)\cdots(s+18)}.
\tag{2}
\]

二次因子的根为

\[
 \frac{-51\pm\sqrt{1313}}2=-7.382329068\ldots,
 -43.617670931\ldots .
\]

故除原有边界零点 (s=1) 外，新增零点只有 (s=0) 和上述两个负实数；在
开临界带 (1/2<\Re s<1) 没有零点。换言之，这一步低频消零并未破坏
Mellin detector 的临界带无零接口。

## 2. Fourier 符号的 Taylor 展开

令

\[
 h_*(t)=\operatorname{Re}\!\left[\zeta(it)K_*(it)\right].
\]

由 (2)，

\[
 K_*(s)=k_1s+k_2s^2+O(s^3),
\quad
 k_1=-\frac{161}{73440},
\quad
 k_2=\frac{49982807}{4284783360}.
\]

使用 (zeta(0)=-1/2)、(zeta'(0)=-\tfrac12\log(2\pi))，并利用偶性，得到

\[
 h_*(t)=A t^2+O(t^4),
\qquad
 A=\frac{k_2+k_1\log(2\pi)}2
 =0.00381803690191976\ldots>0.
\tag{3}
\]

所以 (h_*(0)=0)，但零点是二阶的；这确实消掉了原正 detector 的常数
零频质量，而不是把 (h_*) 变成一个在零频附近严格正的权。

## 3. 为什么必须付出 signed 代价

每个非零逐项非负 detector (V_j) 都满足

\[
 h_j(0)=-\frac12K_j(0)>0
\]

（见 note 196）。因此任何系数 (a_j\ge0) 的非零正组合都有

\[
 \left(\sum_j a_jh_j\right)(0)>0,
\]

不可能消去常数项。式 (1) 中的负系数不是归一化选择，而是逻辑上必需的。
相应 (V_*=V_{15}-(138567/35)V_{18})、(P_*=P_{15}-(138567/35)P_{18})
不再有 (P_*(y)\ge0) 的正 detector 结构。

这一点也可从 Fourier 端严格看出。每个 (g_j) 在 (t=0) 为零，故组合
\(g_*(0)=0\)；同时 (h_*\not\equiv0) 且可积。若 (h_*\ge0) 在整个实轴成立，
则 Fourier 反演给出

\[
 0=2\pi g_*(0)=\int_{\mathbb R}h_*(t)\,dt,
\]

从而 (h_*\equiv0)，矛盾。因此 (h_*) 必须在某处严格变号。式 (3) 说明
其零频邻域取正号，负号必在别的频段出现；不能把它当作全频 PSD symbol。

若改用 (w_*=|h_*|)，则确实得到一个非负能量权，并且 note 192 的一般
半格 Schur 压缩仍可形式上应用；但这已经不是 (P_*\ge0) 的原 detector，
且 (|h_*|) 的反 Fourier 核不再由 (1) 的 signed periodization 给出。因而
必须重新证明该新权与 arithmetic 双和之间的接口，不能把正 detector 的原有
正性恒等式直接沿用。

## 4. 低频局部化没有带来更强的 Mertens 控制

由 (3) 存在 (c,C,\delta>0)，使 (c t^2\le |h_*(t)|\le Ct^2)（
\(|t|\le\delta)）。令

\[
 F_N(t)=\sum_{n\le N}\mu(n)n^{it},
 \qquad |F_N'(t)|\le N\log N.
\]

在 (delta_N=|F_N(0)|/(2N\log N)) 内有
\(|F_N(t)|\ge|F_N(0)|/2)，从而

\[
 \int |h_*(t)|,|F_N(t)|^2dt
 \ \gg\ \frac{|M(N)|^5}{N^3(\log N)^3}.
\tag{4}
\]

若假设能量上界 (E_N(|h_*|)\ll N^{1+\varepsilon})，(4) 至多给出

\[
 |M(N)|\ll N^{4/5+\varepsilon}(\log N)^{3/5},
\]

比 (h(0)>0) 时的 (N^{2/3+\varepsilon}) 局部化结论更弱。故“消掉零频质量”
不是从正能量上界提取平方根 Mertens 估计的捷径。

这里必须区分固定 \(N\) 的局部化与统一截断门：式 (4) 只在给定 \(N\) 上
围绕 \(F_N(0)\) 估计，因此出现 \(N^{4/5}\) 指数。若同一个权
(|h_*|) 的能量界对所有截断 \(X\) 统一成立，则可在
\(\max_{x\le X}|M(x)|\) 的最大点 \(X_0\) 使用 Abel 部分求和；由于
\(|h_*(t)|\asymp t^2\)，小频率积分只损失
\((\log X_0)^5\)，从而仍得到
\(M(X)\ll_\varepsilon X^{1/2+\varepsilon}\)。这个统一量词版本见
note 271；它不改变本节对 signed detector 不能直接 PSD 化的结论。

## 5. 结论与下一步边界

式 (1)--(3) 证明了低阶零频 Taylor 消去在解析上可行，并保留开临界带无零；
但它同时证明了三点限制：

1. 非负 detector 组合不可能消去 (h(0))，必须引入负系数；
2. signed 组合的 Fourier symbol 必变号，不能直接成为 PSD Gram；
3. 取绝对值后低频局部化对 (M(N)) 的控制变差，且新的权需要独立算术估计。

因此，该构造只是一项可复核的低频诊断，不提供无条件能量幂次改善。要推进平方根
门，仍需处理完整 signed Möbius 双和（包括 note 210--212 的 reciprocity/Chowla
子结构），而不是继续增加有限 detector 的 Taylor 消零阶数。
