> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 任意非零正 cutoff 核在完整 Möbius 向量上都有负 reciprocal 门

## 命题

设 \(\phi:[0,\infty)\to\mathbb R\) 连续，满足
\[
\phi\ge0,\qquad \phi(0)=0,\qquad \phi(u)=0\quad(u\ge1),
\]
且 \(\phi\not\equiv0\) 于 \((0,1)\)。则存在任意大的平方自由整数
\(X\)，使完整除数格 \(D_X\) 上的 reciprocal 矩阵
\[
H_X(a,b)=\phi(ab/X)
\]
在实际完整 Möbius 向量 \(c_X(a)=\mu(a)\) 上满足
\[
c_X^\top H_Xc_X<0.
\tag{1}
\]
更精确地，对每个固定奇数 \(k\ge1\)，存在 \(X_j\to\infty\) 使
\[
c_{X_j}^\top H_{X_j}c_{X_j}
\longrightarrow -\,2^k\phi(u_0)
\tag{2}
\]
对某个 \(u_0\in(0,1)\) 且 \(\phi(u_0)>0\) 成立。

## 选择固定有理比的平方自由基底

取 \(u_0\) 的小邻域 \(I\Subset(0,1)\)，使 \(\phi>0\) 于 \(I\)。
由素数定理，可选取互异素数 \(r_j<q_j\)，且
\[
\frac{r_j}{q_j}\longrightarrow u_0,\qquad r_j,q_j\longrightarrow\infty.
\tag{3}
\]
令 \(B_j=r_jq_j\)。在 \(D_{B_j}\) 上定义固定基底的 Möbius reciprocal
和
\[
S(B_j):=\sum_{d,e\mid B_j}\mu(d)\mu(e)\,
\phi\!\left(\frac{de}{B_j}\right).
\tag{4}
\]
由于 \(\phi(1)=0\) 及 \(\phi(u)=0\)（\(u\ge1\)），逐项展开四个除数
\(1,r_j,q_j,r_jq_j\) 得
\[
S(B_j)
=\phi\!\left(\frac1{r_jq_j}\right)
-2\phi\!\left(\frac1{q_j}\right)
-2\phi\!\left(\frac1{r_j}\right)
+\phi\!\left(\frac{r_j}{q_j}\right).
\tag{5}
\]
由连续性、\(\phi(0)=0\) 和 (3)，
\[
S(B_j)\longrightarrow\phi(u_0)>0.
\tag{6}
\]

## 加入超分离辅助素因子

固定 \(k\)。对每个 \(j\)，选取 \(k\) 个奇素数
\(\ell_{j,1},\ldots,\ell_{j,k}\)，与 \(B_j\) 互素，并令
\[
Y_j=\prod_{i=1}^k\ell_{j,i},\qquad X_j=B_jY_j.
\]
要求它们超分离，例如递归满足
\[
\ell_{j,1}>B_j^j,\qquad
\ell_{j,i+1}>
\bigl(B_j\ell_{j,1}\cdots\ell_{j,i}\bigr)^j.
\tag{7}
\]
把 \(a=d s,\ b=e t\) 代入完整二次型，其中
\(d,e\mid B_j\)、\(s,t\mid Y_j\)，得到
\[
c_{X_j}^{\top}H_{X_j}c_{X_j}
=\sum_{d,e\mid B_j}\mu(d)\mu(e)
\sum_{s,t\mid Y_j}\mu(s)\mu(t)\,
\phi\!\left(\frac{de}{B_j}\frac{st}{Y_j}\right).
\tag{8}
\]
对固定 \(d,e\)，只有 \(t=Y_j/s\) 的补集配对在 \(j\to\infty\)
时保留非零极限；其他配对中，超分离条件使 \(st/Y_j\to0\) 或
\(+\infty\)，其 \(\phi\)-值分别趋于 \(\phi(0)=0\) 或恒为零。因此
\[
\sum_{s,t\mid Y_j}\mu(s)\mu(t)
\phi\!\left(\frac{de}{B_j}\frac{st}{Y_j}\right)
=(-1)^k2^k\phi\!\left(\frac{de}{B_j}\right)+o_j(1).
\tag{9}
\]
这里求和只有 \(2^{2k}\) 项；对固定 \(k\) 误差可逐项控制，且不需要
任何数值近似。

将 (9) 代回 (8)，并使用 (4)--(6)，得到
\[
c_{X_j}^{\top}H_{X_j}c_{X_j}
=(-1)^k2^kS(B_j)+o_j(1)
\longrightarrow (-1)^k2^k\phi(u_0).
\tag{10}
\]
取奇数 \(k\) 即得 (1)--(2)。

## 含义

这是对实际完整 Möbius 向量的负性，而不只是某个零延拓的主子块测试。
因此即使把正 cutoff 核在 \(1/2\) 或任何预先选定的比值处置零，仍可
通过一个趋近于 \(\phi(u_0)>0\) 的平方自由有理比构造负 reciprocal 门。
结合 note 382 的反射惯性结论，full-PSD、固定秩 Schur 或逐点正化路线
均不能绕过这一障碍；剩余的必要对象仍是保留 Möbius parity 的 signed
intertwiner。

本命题不声称 RH；它严格关闭的是“非负 cutoff 核本身可自动产生
完整 Möbius 正 Gram”这一候选路线。

## 有限有理校准

取 \(\phi(u)=u(1-u)\mathbf 1_{[0,1)}(u)\)、\(r=97\)、\(q=251\)、
\(Y=1000003\)，直接在 \(D_{qrY}\) 上枚举全部八个除数，得到
\[
S(qr)=\frac{123775296}{592776409}>0,
\]
以及
\[
\sum_{a,b\mid qrY}\mu(a)\mu(b)\phi(ab/(qrY))
=-\frac{233879461265779955328}
{592779965663788987681}<0.
\]
这是有限精确有理校准；定理本身只依赖上述极限论证，不依赖该数值例。
