> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 平滑乘积窗口的双 Mellin 分解显露 reciprocal-square 通道

日期：2026-08-16。

本 note 把 note 311 的“完整 λ(n)d(n) 模型”推广为一个严格的
双 Mellin 恒等式，并说明实际三角 divisor-window 与该模型之间缺少的
正是一个跨频率 signed intertwiner。

## 1. 平滑乘积窗口

令
\(G\in C_c^\infty((0,\infty))\)，\(H\in\mathcal S(\mathbb R)\)，并定义
\[
 S_{R}[G,H]
 :=\sum_{a,b\ge1}\lambda(a)\lambda(b)
 G\!\left(\frac{ab}{R}\right)H\!\left(\log\frac ab\right),
 \qquad R\ge1.
\]
取 Mellin/Fourier 约定
\[
 G(x)=\frac1{2\pi i}\int_{(c)}\widehat G(s)x^{-s}\,ds,
 \quad
 H(v)=\frac1{2\pi}\int_{\mathbb R}\widehat H(\tau)e^{i\tau v}\,d\tau,
\]
其中 \(c>1\)。令
\[
 F(s):=\sum_{n\ge1}\frac{\lambda(n)}{n^s}
      =\frac{\zeta(2s)}{\zeta(s)},
 \qquad \Re s>1.
\]
由于 \(G\) 紧支、\(H\) Schwartz，三重求和/积分在 \(c>1\) 绝对收敛，
可逐项交换，得到严格恒等式
\[
\boxed{
 S_R[G,H]
 =\frac1{(2\pi i)(2\pi)}
 \int_{(c)}\widehat G(s)R^s
 \int_{\mathbb R}\widehat H(\tau)
 F(s-i\tau)F(s+i\tau)\,d\tau\,ds .
 }
\tag{1}
\]
这里 \(\tau\) 是对数比值 \(\log(a/b)\) 的频率，而 \(s\) 是乘积
变量 \(ab\) 的 Mellin 变量。

## 2. \(\tau=0\) 的平方 reciprocal 通道

在零比值频率上，(1) 的算术因子严格为
\[
 F(s)^2
 =\frac{\zeta(2s)^2}{\zeta(s)^2}.
\tag{2}
\]
这也可直接由完全乘法性验证：
\[
 \sum_{r\ge1}\frac{\lambda(r)d(r)}{r^s}
 =\prod_p(1+p^{-s})^{-2}
 =\frac{\zeta(2s)^2}{\zeta(s)^2}.
\tag{3}
\]
因此若 \(\rho\) 是 \(\zeta\) 的零点且 \(\Re\rho>1/2\)，则
\(\zeta(2\rho)\ne0\)，而 (2) 在 \(s=\rho\) 含有相应的二阶 reciprocal
极点（按零点重数计）。这不是对实际截断和的直接反证；它是该类产品窗口的
精确零点响应通道。

更具体地，取宽比值窗口
\(H_L(v)=H(v/L)\)。则
\(\widehat H_L(\tau)=L\widehat H(L\tau)\)，故对固定
\(c>1\)，由 Schwartz 衰减和支配收敛，
\[
 \int_{\mathbb R}\widehat H_L(\tau)
 F(c-i\tau)F(c+i\tau)\,d\tau
 \longrightarrow
 \widehat H(0)F(c)^2
 \quad(L\to\infty).
\tag{4}
\]
所以平方通道不是形式上的单点：在乘积变量固定而逐渐放宽比值窗口时，
双 Mellin 积分确实收敛到 (2)。

## 3. 与长移位三角窗口的精确差别

note 310--311 的尾项在平滑后仍可写成
\[
 \sum_{a,b}\lambda(a)\lambda(b)W_{U,X}(a,b),
\]
其中 \(W_{U,X}\) 支持在 \(a\asymp U\)、\(b\asymp X\) 的三角区域，
而不是只依赖 \(ab\)。在对数坐标中，对任意足够光滑的局部展开，
其每个乘积剖面都具有 (1) 的算术因子
\[
 F(s-i\tau)F(s+i\tau).
\tag{5}
\]
当剖面退化为纯产品权时，\(\tau=0\) 给出 (2)；对真实三角权，
\(\tau\ne0\) 的积分可以带符号抵消零频项。故不能从 (3) 直接推出
实际 \(B_U\) 的 RH 等价性，也不能用“完整模型有 reciprocal-square
极点”替代截断权的证明。

反过来，这也精确定位了当前缺口：任何统一的
\(B_U(X)\ll X^{1+\varepsilon}\) 估计若要避开固定 \(q\) 的 RH 等价边界，
必须提供一个同时控制
\[
 \int \widehat H(\tau)F(s-i\tau)F(s+i\tau)\,d\tau
\]
中跨 \(\tau\) signed cancellation 的算术算子；逐频率取绝对值、普通
\(\ell^2\) 正性或把三角权替换成正产品权都会丢掉这一信息。

## 4. 结论与范围

1. (1) 是对平滑乘积窗口的严格双 Mellin 恒等式；(2)--(3) 是其零比值
   频率的精确 reciprocal-square 通道。
2. 它把 note 311 的 Dirichlet 级数观察提升为可参数化的频率分解，但不把
   实际长移位三角权误认为完整 \(d(r)\) 权。
3. 当前可继续的最小新输入不是新的局部正性，而是对 (5) 的跨频率 signed
   控制；若该控制能在一族宽比值窗口上保持到临界带，则会直接进入
   \(1/\zeta(s)^2\) 的 RH-strength 门。

本 note 不声称证明 RH；它严格关闭了“把截断 divisor-window 直接当作
完整 \(\lambda(r)d(r)\) Dirichlet 级数”这一步，同时保留了真正可检验的
双 Mellin 接口。
