> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 三点仿射门的 Fourier 因子化只给对数级节省

日期：2026-08-16。

本 note 对 notes 314--316 中的
\[
T_{U,Q}=\sum_{q=1}^{Q}\sum_{U<x<2U}
\lambda(x)\lambda(x+q)\lambda(2U+q-1)
\]
作一个直接 Fourier 化。结论是：该二维仿射和确实可写成三个有限 Liouville 指数多项式的三线性积分；结合 Davenport 的统一指数和估计，最多得到对数级节省，在 \(Q\asymp U\) 时仍是
\(U^2\) 量级，不能关闭所需的 \(U^{1+\varepsilon}\) 门。

## 精确恒等式

令
\[
 I=\{U+1,\ldots,2U-1\},\qquad J=\{1,\ldots,Q\},
\]
并定义
\[
 A(t)=\sum_{x\in I}\lambda(x)e(tx),\quad
 B(t)=\sum_{q=1}^{Q}\lambda(2U+q-1)e(tq),
\]
\[
 C(t)=\sum_{n\in I+J}\lambda(n)e(tn),
 \qquad e(t)=e^{2\pi i t}.
\]
由于 \(x+q\in I+J\)，正交关系给出严格恒等式
\[
 T_{U,Q}=\int_0^1 A(t)B(t)C(-t)\,dt. \tag{1}
\]
这里没有使用任何平均或极限；(1) 只是条件 \(n=x+q\) 的 Fourier 指示函数。

Parseval 与 Cauchy--Schwarz 立即给出
\[
 |T_{U,Q}|
 \le \|B\|_{\infty}
 \left(\int_0^1|A(t)|^2dt\right)^{1/2}
 \left(\int_0^1|C(t)|^2dt\right)^{1/2}
 =\|B\|_{\infty}\sqrt{|I|\,|I+J|}. \tag{2}
\]
因此 Fourier 化本身并没有产生第三个平方根：两个 Parseval 因子恰好只抵消了两个支撑长度。

## 可插入的统一指数和界

Davenport 的经典估计（对任意固定 \(A_0>0\)）为
\[
 \sup_{\alpha\in\mathbb R}
 \left|\sum_{n\le X}\lambda(n)e(\alpha n)\right|
 \ll_{A_0}X(\log(2X))^{-A_0}; \tag{3}
\]
参见 Tao 对 Liouville 局部 Fourier 一致性的说明
<https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/>。
在本 note 的范围 \(1\le Q\le U\) 内，把 \(B(t)\) 写成两个从原点开始的部分和之差，(3) 只给出
\[
 \|B\|_\infty\ll_{A_0} U(\log(2U))^{-A_0},
 \qquad\text{同时}\qquad \|B\|_\infty\le Q. \tag{4}
\]
注意 (3) 是全区间部分和估计；它不能无条件地替换成长度为 \(Q\)、起点为 \(2U\) 的
\(Q(\log Q)^{-A_0}\) 界。后者是一个额外的短区间 Fourier 输入。

由 (2)--(4)，得到无条件的直接上界
\[
 |T_{U,Q}|
 \ll \sqrt{U(U+Q)}\,\min\{Q,\ U(\log(2U))^{-A_0}\}. \tag{5}
\]
当 \(Q\asymp U\) 时，(5) 只是
\[
 |T_{U,Q}|\ll_{A_0}U^2(\log U)^{-A_0},
\]
即对数级节省；当 \(Q\ll U\) 时，(5) 退化为原始的 \(O(UQ)\) 量级。它没有达到端点望远镜所需的 \(U^{1+\varepsilon}\) 级估计。

## 与 averaged--Chowla 的关系

MRT 的 averaged--Chowla 估计可以在 \(q\) 上先取绝对值，给出 notes 315--316 中的
\(o(UQ)\) 对数级节省；它不改变 (1) 中三因子相乘的频率结构。若想从 (1) 达到平方根尺度，至少需要下列某一种新输入：

1. 对平移区间 \([2U,2U+Q]\) 的统一短区间 Fourier 界。单独插入 (2) 时，甚至
   \(\|B\|_\infty\ll U^{1/2+\varepsilon}\) 也只给
   \(U^{3/2+\varepsilon}\)；若不同时改善 \(A,C\) 的耦合，必须达到近乎
   \(\|B\|_\infty\ll U^{\varepsilon}\) 才能由 (2) 直接闭合，这显然不是现有指数和定理的形态。
2. 一个同时利用 \(A,B,C\) 三个因子的三线性 signed 估计，取得额外的
   \(U^{-1/2+\varepsilon}\) 级耦合增益，不能先对任一因子取绝对值；或
3. 一个把移动仿射平面 \(x,y,x+y-(2U-1)\) 映射到保留 Liouville 符号的算术 intertwiner。

现有 MRT 定理的量词仍是固定一维基变量上的移位平均；它不提供以上任一移动平面上的平方根界。故 (1) 是一个精确的结构化重写和最便宜的否证测试，但不是 RH 的新证明。

## 可复核的有限检查

对任意小的 \(U,Q\)，直接枚举 \(\lambda(n)\) 并在离散 Fourier 网格上验证 (1) 可检查符号约定；网格积分不是证明，精确数学内容是正交关系本身。后续若要继续该方向，最有信息量的实验不是扩大网格，而是测试是否存在对三因子乘积的非平凡三线性平均，而非分别控制三个指数和。
