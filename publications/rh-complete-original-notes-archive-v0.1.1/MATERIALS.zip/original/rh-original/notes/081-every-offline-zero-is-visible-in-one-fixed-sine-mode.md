> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 每个离线零都被某个固定正弦模看见

日期：2026-08-13。

依赖：[note 074](074-mellin-poles-force-dyadic-mean-shell-growth.md)、
[note 079](079-path-dst-reduces-the-centered-defect-to-sqrtN-low-modes.md)、
[note 080](080-centered-path-energy-alone-is-an-rh-criterion.md)。

## 1. 问题

note 080 的充分条件仍同时含

\[
1\le k\le K_N\asymp\sqrt{N/\log N}.
\tag{1}
\]

现在问：离线零点的质量是否必须分散到增长的模数集合，还是某个固定模已经看见它？

```mermaid
flowchart LR
  A["fixed sine w_k"] --> B["continuous cutoff mode"]
  B --> C["exact Mellin multiplier"]
  C --> D["ζ-zero pole"]
  D --> E["sine completeness"]
  E --> F["some fixed k detects every ρ"]
```

## 2. 连续 cutoff 模及其整数值

令

\[
w_k(t):=\sin\pi k(t-1),
\qquad
c_k:=\int_1^2w_k(t)dt=\frac{1-(-1)^k}{\pi k},
\tag{2}
\]

\[
W_k(s):=\int_1^2w_k(t)t^{s-1}dt.
\tag{3}
\]

对实数 \(X\ge1\)，定义

\[
B(X):=\sum_{d\le X}\frac{\mu(d)}d\log\frac Xd,
\tag{4}
\]

\[
\boxed{
\mathscr R_k(X):=
c_kXB(X)-
\sum_{X<n<2X}
\left[\Lambda(n)+\mu(n)\log\frac nX\right]w_k(n/X).
}
\tag{5}
\]

在整数 \(X=N\) 上，note 079 的 \(\mathcal R_{N,k}\) 满足

\[
\boxed{
\mathcal R_{N,k}-\mathscr R_k(N)
=B_N\left(S_{N,k}-Nc_k\right).
}
\tag{6}
\]

若 \(k\) 为偶数，右边严格为零；若 \(k\) 为奇数，则

\[
S_{N,k}-Nc_k
=\cot\frac{\pi k}{2N}-\frac{2N}{\pi k}
=O_k(N^{-1}).
\tag{7}
\]

由平凡界 \(B_N\ll\log^2N\)，

\[
\boxed{
\mathcal R_{N,k}=\mathscr R_k(N)+O_k(\log^2N/N).
}
\tag{8}
\]

## 3. 精确 Mellin 像

对 \(\Re s>1\)，交换绝对收敛积分与和。首先

\[
\begin{aligned}
\int_1^\infty XB(X)X^{-s-1}dX
&=\sum_{d\ge1}\frac{\mu(d)}d
\int_d^\infty\log(X/d)X^{-s}dX\\
&=\frac1{(s-1)^2\zeta(s)}.
\end{aligned}
\tag{9}
\]

若 \(\sigma=\Re s\) 且
\(\sum_{n\ge2}|a_n|n^{-\sigma}<\infty\)，则变量替换 \(t=n/X\) 与绝对收敛交换给出

\[
\int_1^\infty
\sum_{X<n<2X}a_nw_k(n/X)X^{-s-1}dX
=W_k(s)\sum_{n\ge2}\frac{a_n}{n^s}.
\tag{10}
\]

带 \(\log(n/X)=\log t\) 时，\(W_k(s)\) 换为 \(W_k'(s)\)。由

\[
\sum\frac{\Lambda(n)}{n^s}=-\frac{\zeta'(s)}{\zeta(s)},
\qquad
\sum_{n\ge2}\frac{\mu(n)}{n^s}=\frac1{\zeta(s)}-1,
\tag{11}
\]

得到

\[
\boxed{
\int_1^\infty\mathscr R_k(X)X^{-s-1}dX
=
\frac{c_k/(s-1)^2-W_k'(s)}{\zeta(s)}
+W_k(s)\frac{\zeta'(s)}{\zeta(s)}+W_k'(s).
}
\tag{12}
\]

最后的 \(W_k'(s)\) 是窗 \(X\ge1\) 排除 \(n=1\) 所产生的显式整函数；它不改变任何
\(\zeta\)-零点处的极点。

## 4. 正弦完备性禁止所有固定模同时漏掉一个零

设 \(\rho\) 是 \(q\) 重零点，

\[
\zeta(s)=a_\rho(s-\rho)^q+O((s-\rho)^{q+1}),
\qquad a_\rho\ne0.
\tag{13}
\]

若 \(q\ge2\)，令

\[
C_k(\rho):=\frac{c_k}{(\rho-1)^2}-W_k'(\rho)
=\int_1^2w_k(t)
\left[\frac1{(\rho-1)^2}-t^{\rho-1}\log t\right]dt.
\tag{14}
\]

则真正的最高阶 Laurent 系数为

\[
\operatorname{coeff}_{(s-\rho)^{-q}}
\widehat{\mathscr R}_k(s)=\frac{C_k(\rho)}{a_\rho}.
\tag{14a}
\]

方括号中的函数不恒为零。由于
\(\{w_k:k\ge1\}\) 完备于 \(L^2(1,2)\)，存在某个固定 \(k\) 使
\(C_k(\rho)\ne0\)；于是 (12) 在 \(\rho\) 有 \(q\) 阶极点。

若 \(q=1\)，(12) 的留数乘以 \(a_\rho\) 为

\[
\begin{aligned}
C_k(\rho)+a_\rho W_k(\rho)
=\int_1^2w_k(t)
\left[
\frac1{(\rho-1)^2}
+t^{\rho-1}(a_\rho-\log t)
\right]dt.
\end{aligned}
\tag{15}
\]

方括号同样不可能恒为零：若
\(t^{\rho-1}(a_\rho-\log t)\) 为常数，则求导要求

\[
(\rho-1)(a_\rho-\log t)-1=0
\quad(1<t<2),
\tag{16}
\]

不可能。再由正弦完备性，存在固定 \(k=k(\rho)\) 使留数非零。

因此：

\[
\boxed{
\forall\rho\in Z(\zeta),\quad
\exists k(\rho)\in\mathbb N:
\widehat{\mathscr R}_{k(\rho)}(s)
\text{ 在 }s=\rho\text{ 有极点}.
}
\tag{17}
\]

## 5. 从连续质量到整数固定模

对固定 \(k\)，(5) 在全部激活点 \(X=n,n/2\) 连续，因为
\(w_k(1)=w_k(2)=0\)。离开这些点，

\[
(XB(X))'=B(X)+\sum_{d\le X}\frac{\mu(d)}d=O(\log^2X),
\]

而每个窗口项的导数为 \(O_k(\log N/N)\)，活跃项共 \(O(N)\) 个。因此在每个
\(X\in(N-1,N]\) 上积分得到

\[
\boxed{
\mathscr R_k(X)-\mathscr R_k(N)=O_k(\log^2(2N)).
}
\tag{18}
\]

note 074 的 dyadic Mellin-pole 引理可逐字用于 (12)。结合 (8)、(18)，若
\(\rho=\beta+i\gamma\)、\(\beta>1/2\)，则对 (17) 选出的固定 \(k(\rho)\)，某个
dyadic 子列满足

\[
\boxed{
\sum_{Y<N\le2Y}|\mathcal R_{N,k(\rho)}|^2
\gg_\rho Y^{2\beta+1}(\log Y)^{2m_\rho-2},
}
\tag{19}
\]

其中 \(m_\rho\ge1\) 是 (12) 在 \(\rho\) 的实际极点阶数；当 \(q\ge2\) 时上述选择可取
\(m_\rho=q\)。误差总平方只有 \(O_k(Y\log^4Y)\)，不影响 (19)。

## 6. 固定模族 RH 判据

**定理（fixed-sine family criterion）。** 若对每个固定整数 \(k\ge1\) 和每个
\(\varepsilon>0\)，

\[
\boxed{
\sum_{Y<N\le2Y}|\mathcal R_{N,k}|^2
\ll_{k,\varepsilon}Y^{2+\varepsilon},
}
\tag{20}
\]

则 RH 成立。

**证明。** 若有 \(\beta>1/2\)，取 (17) 的 \(k(\rho)\) 及
\(0<\varepsilon<2\beta-1\)；(19) 与 (20) 矛盾。功能方程完成结论。\(\square\)

## 7. 决策意义

note 080 要求一个随 \(N\) 增长的加权低模族；本 note 证明更弱的充分条件：

\[
\boxed{
\text{不需 }k\le\sqrt{N/\log N}\text{ 的一致控制；}
\quad
\text{只需逐个固定 }k\text{ 的 cutoff 均方。}
}
\tag{21}
\]

下一原子变为最简单的 \(k=1\) cutoff Gram，并同时研究能否证明一个有限集合
\(1\le k\le k_0\) 对全部 \(\zeta\)-零点都是 universal detector。现阶段只证明了“每个零点
存在某个固定模”，没有证明统一有限 \(k_0\)，也没有证明 (20)，故尚未证明 RH。
