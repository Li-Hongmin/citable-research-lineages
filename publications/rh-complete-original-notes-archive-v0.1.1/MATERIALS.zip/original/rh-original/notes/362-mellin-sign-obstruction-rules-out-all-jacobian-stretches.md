> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mellin 符号障碍排除所有 \(a>1\) Jacobian detector 伸缩

日期：2026-08-16。

## 定理

令 \(V_m\) 为统一 Euler--beta detector，且令

\[
 \widetilde V_{m,a}(u):=a\,u^{a-1}V_m(u^a),\qquad a>1.
\]

定义

\[
 \widetilde P_{m,a}(y):=
 \sum_{n\le y}\widetilde V_{m,a}(n/y).
\]

则 \(\widetilde P_{m,a}\) 不可能在所有 \(y\ge1\) 上非负。

## 端点衰减与 Mellin 延拓

由统一构造，

\[
 V_m(u)=v_{m,2}u^2+O(u^3)\quad(u\downarrow0),
\qquad
 V_m(u)=O((1-u)^{2m+1})\quad(u\uparrow1).
\]

故

\[
 \widetilde V_{m,a}(u)=O(u^{\lambda}),
\qquad \lambda:=3a-1>2,
\]

且右端至少有 \(q:=2m+1\ge3\) 阶零点。广义 Euler--Maclaurin
展开（先减去两端的 leading power，再对余项作普通展开）给出：对任意

\[
 2<\delta<\min(\lambda,q),
\]

\[
 \widetilde P_{m,a}(y)=O_{m,a,\delta}(y^{-\delta}).
\tag{1}
\]

特别地，

\[
 I_{m,a}(s):=\int_1^\infty \widetilde P_{m,a}(y)y^{-s-1}\,dy
\]

在 \(\Re s>-\delta\) 全纯。对 \(\Re s>1\) 逐项换元，并使用
\(\int_0^1\widetilde V_{m,a}(u)\,du=K_{V_m}(1)=0\)，得到

\[
 I_{m,a}(s)
 =\zeta(s)K_{V_m}\!\left(1+\frac{s-1}{a}\right).
\tag{2}
\]

由解析延拓，(2) 在 \(\Re s>-\delta\) 继续成立；\(s=1\) 处的
\(\zeta\) 极点由 \(K_{V_m}(1)=0\) 可去。

## 选取负值

因为 \(\delta>2\)，可以取实数

\[
 \sigma\in\bigl(\max\{-\delta,-4\},-2\bigr).
\]

于是 \(\zeta(\sigma)>0\)：由功能方程，在 \(-4<\sigma<-2\) 时
\(\sin(\pi\sigma/2)>0\)，其余因子也为正。

另一方面，令

\[
 r:=1+\frac{\sigma-1}{a}.
\]

由 \(\sigma>-\delta>-(3a-1)\) 得 \(r>-2\)，而 \(\sigma<1\) 给出
\(r<1\)。当前层级的精确 Mellin 形状为

\[
 K_{V_m}(r)=
 \frac{(3m+1)!(r-1)}
 {C_m\prod_{j=1}^{m}(r+2j)
 \prod_{k=2m+1}^{3m+3}(r+k)}.
\tag{3}
\]

在 \(-2<r<1\) 上，分母和 \(C_m\) 均为正，而 \(r-1<0\)，所以
\(K_{V_m}(r)<0\)。由 (2)

\[
 I_{m,a}(\sigma)<0.
\tag{4}
\]

若 \(\widetilde P_{m,a}(y)\ge0\) 对所有 \(y\ge1\)，则定义域内的积分
\(I_{m,a}(\sigma)\) 应为非负，和 (4) 矛盾。

## 结论与范围

因此所有 \(a>1\) 的 Jacobian 伸缩都被排除，而不只是 note 361 中的
\(1<a<4/3\) 小区间。note 361 的负尾是同一符号机制在
\(\sigma\to-(3a-1)^+\) 一侧的局部表现；本 note 用 Mellin 符号把
\(a\ge4/3\) 也一并关闭。

这只排除“对现有 \(V_m\) 做 Jacobian 尺度伸缩”。它不排除完全重新
设计左端 jet、右端 jet 和修正多项式的 detector；但此时 Mellin
分母、periodization 正性和零频消去必须全部重新证明，不能再视为
尺度变换的免费收益。
