> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 低频 Mellin 消零的显式线性组合：改进不可转化为正能量门

日期：2026-08-15。

本 note 检查把两个已正化 detector 做有符号线性组合，试图消去
\(\xi=0\) 的低频质量，是否能改善正能量路线。结论是：可以精确消零，
但所得核必变号；取绝对值恢复正能量时，低频局部化反而变弱，不能关闭
平方根门。

## 1. 一个精确消零组合

取 notes 144、146 的 Mellin 乘子
\[
K_{15}(s)=
\frac{415134720(s-1)}
{(s+2)(s+4)(s+6)(s+8)(s+9)(s+10)(s+11)(s+12)(s+13)(s+14)(s+15)}
\]
和
\[
K_{18}(s)=
\frac{1083801600(s-1)}
{19\prod_{j\in\{2,4,6,8,10,11,12,13,14,15,16,17,18\}}(s+j)}.
\]
由于
\[
K_{15}(0)=-\frac1{30},\qquad K_{18}(0)=-\frac7{831402},
\]
令
\[
K_*(s)=K_{15}(s)-\frac{138567}{35}K_{18}(s)
\]
便有 \(K_*(0)=0\)。直接通分得到
\[
K_*(s)=
\frac{415134720\,s(s-1)(s^2+51s+322)}{\mathcal D_*(s)},
\tag{1}
\]
其中 \(\mathcal D_*(s)\) 是上述分母的正因子乘积。额外两个零点为
\[
s=\frac{-51\pm\sqrt{1313}}2,
\]
均在左半平面；故 \(K_*\) 在 \(1/2<\Re s<1\) 仍无零。

## 2. 实频符号必变号

令
\[
h_*(t)=\Re\{\zeta(it)K_*(it)\}.
\]
则 \(h_*\) 为实偶函数且 \(h_*(0)=0\)。直接在 \(t=0\) 展开得到
\[
h_*(t)=A t^2+O(t^4),\qquad
A\approx 3.8180369\times10^{-3}>0.
\tag{2}
\]
对应的对数核 \(g_*(u)\) 满足 \(g_*(0)=0\)。若 \(h_*\ge0\) 于全实轴，
Fourier 反演将给出
\[
0=2\pi g_*(0)=\int_{\mathbb R}h_*(t)\,dt,
\]
从而连续性迫使 \(h_*\equiv0\)，与 \(K_*\ne0\) 矛盾。因此 \(h_*\) 必须
在某处严格为负；这与正 detector 的 \(|h|\)-Gram 路线不相容。

## 3. 取绝对值后的局部代价

若把 \(h_*\) 换成 \(|h_*|\) 以恢复 PSD 正能量，则 (2) 给出
\[
|h_*(t)|\asymp t^2\quad(t\to0).
\]
设 \(F_N(t)=\sum_{n\le N}\mu(n)n^{it}\)，并以
\(|F_N(t)-F_N(0)|\le |t|\,N\log N\) 作最基本局部化。令
\(\delta=|M(N)|/(2N\log N)\)，便有
\[
\int_{|t|\le\delta}|h_*(t)|\,|F_N(t)|^2dt
\gg \frac{|M(N)|^5}{N^3(\log N)^3}.
\tag{3}
\]
所以即使假设该绝对值能量为 \(O(N^{1+\varepsilon})\)，由 (3) 得到的
只是
\[
|M(N)|\ll N^{4/5+O(\varepsilon)}(\log N)^{3/5},
\]
比 \(h(0)>0\) 时的 \(2/3\)-型局部化更弱。消去更多低阶频率只会继续
提高这个局部指数，不能产生平方根界。

## 4. 结论

有限个正 detector 的有符号线性组合可以消去 \(h(0)\)，但有两个不可同时
回避的代价：

1. 原 reciprocal kernel 失去正/PSD 结构，必须重新控制 signed cross-frequency；
2. 取绝对值恢复正性后，低频质量变小，Möbius 零频的可观测性变弱。

因此低频 Taylor 消零不是当前算术平方根门的突破口；剩余缺口仍是保留
signed cancellation 的全频 Möbius 能量估计。
