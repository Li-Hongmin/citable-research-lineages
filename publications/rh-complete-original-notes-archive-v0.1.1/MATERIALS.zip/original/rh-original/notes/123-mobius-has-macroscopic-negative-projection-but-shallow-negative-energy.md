> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Möbius 有宏观负谱投影，但负能量很浅

日期：2026-08-14。

依赖：[note 122](122-squarefree-primorial-stars-have-codimension-one-negative-inertia.md)。

证据等级：rank-one secular 恒等式、素数和渐近与精确二指标计算。

## 1. Star 的精确 rank-one 形式

沿 note 122，令 \(x=p_m^\#\)，指标 \(a_j=2p_j\)，\(2\le j\le m\)。写

\[
K=dd^T-A,\qquad d=x^{-1/2}(p_2,\ldots,p_m)^T,\qquad A=DED\succ0.
\tag{1}
\]

故 \(K\) 恰有一个正特征值 \(\lambda_+\)，其余 \(m-2\) 个均负。若

\[
R_\lambda=(A+\lambda I)^{-1},
\tag{2}
\]

则

\[
d^TR_{\lambda_+}d=1,\qquad
v_+=\frac{R_{\lambda_+}d}{(d^TR_{\lambda_+}^2d)^{1/2}}.
\tag{3}
\]

对真实限制 Möbius 向量 \(u=\mathbf1\)，

\[
|\langle u,v_+\rangle|^2
=\frac{(u^TR_{\lambda_+}d)^2}{d^TR_{\lambda_+}^2d},
\qquad
\|P_-u\|^2=m-1-|\langle u,v_+\rangle|^2.
\tag{4}
\]

这是所需谱投影的精确 scalar-resolvent 接口。

## 2. 投影宏观，能量却浅

由 note 122 的界，

\[
\|A\|\ll p_m^2/x,\qquad
\|d\|^2=x^{-1}\sum_{j=2}^m p_j^2,
\tag{5}
\]

故 \(\|A\|/\|d\|^2=O(m^{-1})\)。唯一正特征向量因而与
\(d/\|d\|\) 相差 \(O(m^{-1})\)。利用

\[
\sum_{j\le m}p_j\sim\frac12m^2\log m,\qquad
\sum_{j\le m}p_j^2\sim\frac13m^3(\log m)^2,
\tag{6}
\]

得到

\[
\frac{|\langle u,v_+\rangle|^2}{\|u\|^2}\to\frac34,\qquad
\boxed{\frac{\|P_-u\|^2}{\|u\|^2}\to\frac14.}
\tag{7}
\]

所以 Möbius 并不在欧氏意义下避开增长负空间。

但若

\[
\mathcal E_-=-\langle P_-u,KP_-u\rangle,
\tag{8}
\]

则 \(K=dd^T-A\) 给出

\[
\mathcal E_-\le\|A\|\|u\|^2
\ll\frac{mp_m^2}{x}.
\tag{9}
\]

另一方面，

\[
u^TKu=\frac{(\sum p_j)^2}{x}\bigl(1+O(m^{-1})\bigr)>0.
\tag{10}
\]

因此

\[
\boxed{\frac{\mathcal E_-}{u^TKu}=O(m^{-1}).}
\tag{11}
\]

宏观负投影与很小负能量可以同时成立；承重对象是谱投影乘特征值，而非惯性
或投影维数。

## 3. 真实 Möbius 符号的最小负门

负能量并非完全缺失。仍令 \(x=p_m^\#\)，取 squarefree 指标

\[
a=3,\qquad b=6,\qquad (\mu(a),\mu(b))=(-1,1).
\tag{12}
\]

写 \(z=x/36=n+r\)。因 \(x/6\) 与 \(6\) 互素，
\(r\in\{1/6,5/6\}\)，且

\[
\mathcal Q_x=P(4z)+P(z)-2P(2z).
\tag{13}
\]

直接代入精确核得

\[
\mathcal Q_x=
\begin{cases}
-\dfrac{3n(2n-3)}{(6n+1)^3},&r=1/6,\\[6pt]
-\dfrac{3(n+1)(2n+5)}{(6n+5)^3},&r=5/6.
\end{cases}
\tag{14}
\]

故对 \(m\ge5\)，

\[
\boxed{\mathcal Q_x<0,\qquad \mathcal Q_x=-x^{-1}+O(x^{-2}).}
\tag{15}
\]

centered 核还增加

\[
-\frac1{6x}(-3+6)^2=-\frac3{2x},
\tag{16}
\]

所以相应二次型为 \(-5/(2x)+O(x^{-2})\)。这是实际 Möbius 符号上的严格负
Rayleigh 门，但尺度只有 \(x^{-1}\)，且尚未与其他坐标解耦。

## 4. 决策边界

\[
\boxed{
\text{squarefree Möbius 支撑既有增长负谱，也有真实负二次型；
但已见负能量比 collective 正能量低至少一阶}.}
\tag{17}
\]

下一步不应继续计数负特征值，而应寻找能累积到平方根尺度、同时保存 Möbius
符号抵消的增长块或完整 Schur 恒等式。这不是 RH 的证明。
