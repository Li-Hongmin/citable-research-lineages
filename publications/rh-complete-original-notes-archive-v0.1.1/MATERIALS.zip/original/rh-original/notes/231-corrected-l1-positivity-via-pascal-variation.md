> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 【更正】L=1 Pascal 变差草稿的权重错误

日期：2026-08-16。

本文件原先把 q-shift 权重写成

\[
w_q=(q+1)c_{m-1,q}.
\]

这是错误的对象。note 156--157 的精确 q-shift 恒等式使用的是

\[
w_q=c_{m-1,q}\binom{D}{q},
\qquad D=3m+3.
\]

因此原文件中的 \(K_q\)、符号变化、端点值和 Pascal 变差论证不能作为 L=1
全 \(m\) 证明；对应脚本 `computations/check_l1_pascal_variation.py` 的旧版本
也只检查了错误权重，已不再作为证据。

## 已确认的修正范围

用正确权重时，反向 Bessel Beta 表示确实成立：

\[
W(z)=\sum_{q=2}^{m+1}c_{m-1,q}\binom Dq z^q
=A_mz^2\int_0^1t^{m-1}(1-t)^{m+2}(t+2z)^{m-1}\,dt,
\]

见 `notes/230-correction-beta-qshift-weight-alignment.md`。例如 \(m=4\) 的
正确系数为 \((15,195,936,1716))，不是旧草稿中的
\((3/7,12/7,24/7,24/7))。

这项更正解释了旧审计为何得到“Beta 反例”。它撤回的是错误的比较，不能自动
恢复旧 Pascal 证明。note 162 的 Beta 累计核使用了正确权重，并已对照精确
q-shift 公式做有限范围恒等式核验；当前 L=1 结论应引用 note 162 的 Beta
证明，而不应引用本文件旧版本。

无论 detector 的 L=1 层最终如何裁决，都不改变 Möbius signed-energy 的
平方根级 RH 门尚未闭合这一主结论。
