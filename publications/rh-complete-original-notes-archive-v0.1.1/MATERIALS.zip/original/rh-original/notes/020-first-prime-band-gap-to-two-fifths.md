> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 首个 prime band 的正谱隙推进至 \(a=2/5\)

日期：2026-08-11。

## 定理

对全部 \(0<a\le 2/5\)，局部 Weil 算子的两个奇偶扇区满足

\[
A_a^+\succeq10^{-6}I,
\qquad
A_a^-\succeq10^{-4}I.
\]

因而

\[
\boxed{A_a\succeq10^{-6}I\qquad(0<a\le2/5).}
\]

特别地，若首次退化尺度存在，则它严格大于 \(2/5\)。

## 精确下模型

令 \(d=\log2\)、\(p=\log2/\sqrt2\)。由于

\[
2a=\frac45<\log3,
\]

在端点 \(a=2/5\) 仍只有 \(n=2\) 的 prime shift 活跃。沿用 note 019 的半区反射

\[
(J_af)(x)=\mathbf1_{(d-a,a)}(x)f(d-x),
\qquad J_a^2=P_{(d-a,a)},
\]

prime 项在偶、奇扇区分别精确为 \(-pJ_a\) 与 \(+pJ_a\)。因此没有用其不随 collar 宽度衰减的
算子范数作粗估计。

Archimedean 部分采用 notes 017--019 的正 Yukawa 分解。每个被保留的 summand 用第三个 Robin
本征值作标量底，并显式保留前两个低模 deficit；其余 Yukawa 尾项为正，可以删除。所有 Robin
根、初等积分、矩阵元与 \(LDL^{\mathsf T}\) 运算均使用 Arb 有向区间完成。

## 偶扇区证书

取前 \(60\) 个 Yukawa summand 的两个低模 deficit，并用前 \(400\) 个正项构造标量底。令

\[
\delta_+=10^{-6},
\qquad
B_+=(\alpha_+-\delta_+)I-pJ_a.
\]

区间计算得到

\[
\alpha_+=1.02027081550606624584\ldots,
\]

\[
(\alpha_+-\delta_+)-p
>0.53014074377179264998.
\]

保留正极点向量 \(2\cosh(x/2)\) 后，所得 \(120\) 维 Woodbury--Schur 矩阵的全部区间
\(LDL^{\mathsf T}\) pivot 严格为正，最小 pivot 下界为

\[
0.08274368450863951331\ldots>0.
\]

故 \(A_{2/5}^+\succeq10^{-6}I\)。

## 奇扇区证书

取前 \(8\) 个 Yukawa summand 的两个低模 deficit，并把负极点向量 \(2\sinh(x/2)\) 作为第
\(17\) 个 Schur 列。令

\[
\delta_-=10^{-4},
\qquad
B_-=(\alpha_--\delta_-)I+pJ_a.
\]

区间计算得到

\[
\alpha_-=0.77364774426737616352\ldots,
\]

\[
(\alpha_--\delta_-)-p
>0.28341867253310256766.
\]

对应 \(17\) 维 Schur 矩阵的最小区间 pivot 下界为

\[
0.25533428648183277023\ldots>0.
\]

故 \(A_{2/5}^-\succeq10^{-4}I\)。

## 全区间传播与复现

由 note 003 的零延拓 min--max 单调性，端点的两个下界分别传播到全部较小尺度。认证命令为

~~~bash
uv run --with python-flint python computations/verify_first_band_even_at_040.py
uv run --with python-flint python computations/verify_first_band_odd_at_040.py
~~~

相应文件：

- [偶扇区证书](../computations/verify_first_band_even_at_040.py)；
- [奇扇区证书](../computations/verify_first_band_odd_at_040.py)。

Schur pivot 仅认证有限矩阵正定，不被解释为无限维算子的谱隙；定理中的 \(10^{-6}\) 与
\(10^{-4}\) 来自直接对 \(A_{2/5}^{\pm}-\delta_\pm I\) 的 Schur 检验。
