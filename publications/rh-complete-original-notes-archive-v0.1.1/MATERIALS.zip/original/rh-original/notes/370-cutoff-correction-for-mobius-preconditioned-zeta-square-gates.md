> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 截断校正：完整 ζ-幂次恒等式不等于原始 \(\sqrt x\) 双和

本 note 更正 notes 239、368、369 中一个重要的截断混淆。
若原始 reciprocal-product 定义为
\[
T_b^{\mathrm{cut}}(x)=
\sum_{a,b\le\sqrt x}\mu(a)\mu(b)P_b(x/(ab)),
\]
则不能直接把它重排成一个完整的 Dirichlet 卷积。完整卷积只对应另一个
不截断的对象
\[
T_b^{\mathrm{full}}(x)=
\sum_{ab<x}\mu(a)\mu(b)P_b(x/(ab)).
\]

## 一般边界恒等式

若 \(P_b(y)=\sum_{k\le y}c_k\phi(k/y)\)，则
\[
T_b^{\mathrm{cut}}(x)
 =\sum_{n<x}\phi(n/x)
   \sum_{\substack{a,b\le\sqrt x\\ab\mid n}}
   \mu(a)\mu(b)c_{n/(ab)}.
\tag{1}
\]
而完整对象满足
\[
T_b^{\mathrm{full}}(x)
 =\sum_{n<x}(\mu*\mu*c)(n)\phi(n/x),
\tag{2}
\]
其 Mellin 变换才是
\[
\int_1^\infty T_b^{\mathrm{full}}(x)x^{-s-1}\,dx
 =\Phi(s)\frac{B(s)}{\zeta(s)}.
\tag{3}
\]
两者的差是显式 incomplete-lcm 边界
\[
T_b^{\mathrm{full}}(x)-T_b^{\mathrm{cut}}(x)
 =\sum_{n<x}\phi(n/x)
   \sum_{\substack{ab\mid n\\\max(a,b)>\sqrt x}}
   \mu(a)\mu(b)c_{n/(ab)}.
\tag{4}
\]
因此 (3) 不能直接给原始 \(\sqrt x\)-截断对象一个 ζ-幂次 Mellin
表示；恰恰是 (4) 需要跨尺度 signed cancellation。

## 最小有理反例

取 \(\phi(u)=u(1-u)\mathbf1_{(0,1)}(u)\)，并取 Möbius 预条件
\(b=\mu\)，于是 \(P_b(y)=\phi(1/y)\)。在 \(x=3\) 时，
\(\lfloor\sqrt3\rfloor=1\)，所以
\[
T_\mu^{\mathrm{cut}}(3)=\phi(1/3)=\frac29.
\]
但完整卷积为
\[
T_\mu^{\mathrm{full}}(3)
 =\sum_{n<3}(\mu*\mu)(n)\phi(n/3)
 =-\frac29.
\]
两者相差 \(4/9\)。同样，对未预条件 \(b=\delta_1\)，
\[
T_{\delta}^{\mathrm{cut}}(3)=\phi(1/3)+\phi(2/3)=\frac49,
\qquad
T_{\delta}^{\mathrm{full}}(3)=\sum_{n<3}\mu(n)\phi(n/3)=0.
\]
这些都是有限有理计算，不依赖数值近似。

## 裁决

1. notes 239、368、369 中的 ζ-幂次恒等式，若写成完整卷积，数学上成立；
2. 它们不能直接替代原始 \(a,b\le\sqrt x\) 的 reciprocal-product 门；
3. 原始问题的真实剩余项是 (4) 的 incomplete-lcm boundary，而不是已被
   Mellin-Fubini 自动消掉的卷积尾。

这项校正不提供 RH 证明，但排除了一个虚假的“已得到完整 ζ-门”的捷径，
并把下一步准确收束到跨 lcm 层的 signed arithmetic intertwiner。
