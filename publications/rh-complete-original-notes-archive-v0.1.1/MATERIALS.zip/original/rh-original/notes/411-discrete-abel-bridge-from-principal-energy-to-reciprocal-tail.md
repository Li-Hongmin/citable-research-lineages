> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 411. 从主部能量到 reciprocal 尾的离散 Abel 桥

## 引理

令
\[
U(n)=\sum_{j\le n}j\mu(j),
\qquad B(k)=\sum_{j\le k}\frac{\mu(j)}j,
\qquad m_k=\lfloor k/2\rfloor.
\]
定义 note 403 的 reciprocal 尾能量
\[
E(Y)=\sum_{k\le Y}k\,|B(k)-B(m_k)|^2.
\]
则存在绝对常数 $C$，使得对所有 $Y\ge2$，
\[
E(Y)\le C\sum_{n\le Y}\frac{|U(n)|^2}{n^3}.
\tag{1}
\]

结合 note 410，若主部满足
\[
Q_w(\mu_{\le Y})\ll_\varepsilon Y^{1+\varepsilon},
\tag{2}
\]
则无需额外的 endpoint 假设即可得到
\[
E(Y)\ll_\varepsilon Y^{1+\varepsilon}.
\tag{3}
\]

## 1. 精确的离散 Abel 公式

因为 $j\mu(j)=U(j)-U(j-1)$，两次 Abel 分部求和给出
\[
B(k)=\frac{U(k)}{k^2}
+\sum_{j<k}U(j)\left(\frac1{j^2}-\frac1{(j+1)^2}\right).
\tag{4}
\]
因此，对 $k\ge2$，
\[
B(k)-B(m_k)
=\frac{U(k)}{k^2}-\frac{U(m_k)}{m_k^2}
+\sum_{m_k\le j<k}U(j)\Delta_j,
\qquad
\Delta_j:=\frac1{j^2}-\frac1{(j+1)^2}.
\tag{5}
\]
$k=1$ 只贡献一个绝对常数，可并入 $C$。

## 2. 加权 Cauchy--Schwarz 与局部重叠

对 (5) 使用三项平方不等式。第一项求和给出
\[
\sum_{k\le Y}k\frac{|U(k)|^2}{k^4}
=\sum_{k\le Y}\frac{|U(k)|^2}{k^3}.
\tag{6}
\]
第二项中 $m_k=\lfloor k/2\rfloor$，每个 $m$ 只被 $k=2m,2m+1$ 命中，故
\[
\sum_{k\le Y}k\frac{|U(m_k)|^2}{m_k^4}
\ll\sum_{m\le Y}\frac{|U(m)|^2}{m^3}.
\tag{7}
\]

对第三项写
\[
\sum_{m_k\le j<k}U(j)\Delta_j
=\sum_{m_k\le j<k}
\frac{U(j)}{j^{3/2}}\,j^{3/2}\Delta_j.
\]
由于 $j^3\Delta_j^2\ll j^{-3}$，且 $j\asymp k$ 在该区间内，
\[
\left|\sum_{m_k\le j<k}U(j)\Delta_j\right|^2
\ll \frac1{k^2}\sum_{m_k\le j<k}\frac{|U(j)|^2}{j^3}.
\tag{8}
\]
乘以 $k$ 后对 $k\le Y$ 求和。交换次序时，固定 $j$ 只对应
$j<k\le2j+1$，并且
\[
\sum_{j<k\le2j+1}\frac1k\le C_0.
\]
所以第三项总和也被 $C_0\sum_{j\le Y}|U(j)|^2/j^3$ 控制。这与 (6)--(7) 合并即得 (1)。

## 3. 对主线的含义

note 407 的正 Mellin 主部给出 note 409 的 $M_1$ dyadic 能量；note 411 进一步证明原始 reciprocal 尾是同一个加权 $M_1$ 能量下的有界离散 Abel 像。因此当前问题可以严格缩减为单一算术门：
\[
\sum_{n\le Y}\frac{|M_1(n)-M_1(\lfloor n/2\rfloor)|^2}{n^3}
\ll_\varepsilon Y^{1+\varepsilon}.
\]
这仍与 RH 等价（note 410），但不再需要把主部和 endpoint 尾作为两个独立的未解命题。

对 $Y\le100$ 的有理数数据，(4)--(5) 与直接定义的 $B(k)$ 逐项一致；有限核验不外推为全称估计。
