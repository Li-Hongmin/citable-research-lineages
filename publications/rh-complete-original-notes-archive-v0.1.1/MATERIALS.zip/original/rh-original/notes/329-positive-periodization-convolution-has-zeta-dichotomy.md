> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 正 periodization 卷积的 ζ 二择一

日期：2026-08-16。

本 note 给出一个精确的卷积分叉，说明为什么从 \(P_V\ge0\) 自动构造
第二个同时具有“正 Fourier 符号”和“regular detector Mellin 乘子”的对象
并不成立。

## 1. 因果对数卷积：正性保留，但 \(1/\zeta\) 被相消

令
\[
p(t)=P_V(e^t),\qquad t\ge0,
\]
并假设 \(p\in L^1(0,\infty)\)。定义因果卷积
\[
p_2(t)=\int_0^t p(u)p(t-u)\,du\ge0.
\]
其 Laplace 变换满足
\[
I_2(s):=\int_0^\infty p_2(t)e^{-st}\,dt=I(s)^2,
\qquad
I(s)=\int_0^\infty p(t)e^{-st}\,dt=\zeta(s)K_V(s).
\]
因此若把 \(P_2(e^t):=p_2(t)\) 作为新的 periodization，形式上的
Mellin 反演给出
\[
K_2(s)=\frac{I_2(s)}{\zeta(s)}
      =\zeta(s)K_V(s)^2,
\qquad
\frac{K_2(s)}{\zeta(s)}=K_V(s)^2.
\tag{1}
\]
所以 \(P_2\ge0\) 且因果卷积完全合法，但新的 Möbius 输出不再含
\(1/\zeta(s)\)；它属于 note 234 的“\(\zeta K\) 易坍缩通道”，不能检测 RH。

## 2. 偶卷积：Fourier 符号正，但 regularity 变成 RH 门

令
\[
g(t)=\frac12P_V(e^{|t|}),\qquad t\in\mathbb R,
\]
并记 \(h=\widehat g\)。由于 \(P_V\ge0\)，有 \(g\ge0\)。令
\[
g_2=g*g.
\]
则
\[
g_2\ge0,\qquad \widehat{g_2}(\xi)=h(\xi)^2\ge0.
\tag{2}
\]
把 \(P_2(e^t):=2g_2(t)\)（\(t\ge0\)）视作新的一侧 periodization，则其
**对称的一侧 Mellin 变换**满足
\[
I_2^{\mathrm{sym}}(i\xi)
:=2\int_0^\infty g_2(t)\cos(\xi t)\,dt
=\widehat{g_2}(\xi)=h(\xi)^2.
\tag{3}
\]
注意普通一侧 Mellin 变换还含有 sine 部分；因此不能把 (3) 误写成
\(I_2(i\xi)=h(\xi)^2\)。若要求一个 regular detector 的偶化符号恰为
\(h^2\)，必须解
\[
\operatorname{Re}\{\zeta(i\xi)K_2(i\xi)\}=h(\xi)^2.
\tag{4}
\]
若进一步强行匹配完整 bilateral 变换，则形式上会出现
\(K_2(i\xi)=h(\xi)^2/\zeta(i\xi)\)，在 zeta 零点处产生潜在极点；
而从 (4) 恢复一侧解析 \(K_2\) 本身是 Wiener--Hopf/Riemann--Hilbert
问题，不能作为 RH 的无条件前置步骤。

## 3. 一般交叉卷积

更一般地，对两个非负一侧 periodization \(p_1,p_2\)，因果交叉卷积满足
\[
I_{12}(s)=I_1(s)I_2(s)
       =\zeta(s)^2K_1(s)K_2(s),
\]
其 periodization 乘子为
\[
K_{12}(s)=\zeta(s)K_1(s)K_2(s),
\qquad
K_{12}(s)/\zeta(s)=K_1(s)K_2(s).
\tag{4}
\]
所以所有只使用正 periodization 的因果卷积组合，都沿同一条路径
消除 Möbius 的 \(1/\zeta\) 门；有限线性组合不能改变这个因子化。

## 4. 算术含义

这不是说明不存在新的 signed intertwiner，而是精确排除了一个自然捷径：

- 因果卷积：保留 \(P\ge0\)，但丢失 RH 的 \(1/\zeta\)；
- 偶卷积：保留正 Fourier 符号，但 regular detector 的 Mellin 反演本身
  遇到 zeta 零点；
- 原始对象：保留 \(K_V/\zeta\)，但 Fourier 符号有正有负。

因此要解决 RH，必须同时处理负频率/half-lattice 的 signed 算术结构，
不能只靠正 periodization 的卷积闭包。
