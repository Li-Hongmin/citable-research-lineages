> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Weil 极点项的奇偶秩一归约：下一阶段路线决策

> **后续纠正（2026-08-11）：** 本文提出的“正秩二”候选分解不成立。真实极点项签名为
> \((1,1)\)，奇扇区是负秩一；约化形式的绝对值收缩则确实成立。严格公式与证明见
> [note 007](007-indefinite-polar-splitting-and-reduced-markov-form.md)。本文保留为提出判别问题时的
> 路线记录，不再作为公式来源。

日期：2026-08-11。本文记录下一阶段的研究路线判断，不把尚未逐式核验的分解、文献接口或候选
非消失命题晋级为已证结果。其上游是首次退化归约（note 001）、全谱单调性（note 003）、精确
logarithmic-Laplacian 定义域对应（note 004）以及完整 Weil 形式绝对值收缩失败的反例（note 005）。

## 1. 唯一终点

目标仍是证明

\[
\lambda_1(a)\ge 0\qquad\forall a>0,
\]

从而由 Weil 判据推出 RH。Suzuki 2026 已将 RH 失败严格归约为某个首次退化尺度上的非零零模态；
因此下一阶段必须产生能够排除该零模态的结构，而不是只描述 spectral flow 或提高数值零点吻合精度。

## 2. 推荐主路线：极点秩二变成奇偶扇区秩一

首先应从 Weil 公式的精确归一化出发，逐式核验候选分解

\[
Q_W^a(v)
=q_a^{\mathrm{red}}(v)
+|\langle v,e^{x/2}\rangle|^2
+|\langle v,e^{-x/2}\rangle|^2.
\]

后两项预期来自 zeta 完备化中的两个极点，并构成正的秩二扰动。若该分解在完整闭形式定义域
\(H((-a,a))\) 上成立，则按偶、奇空间分解可写成

\[
A_a^+
=M_a^+
+2|\cosh(x/2)\rangle\langle\cosh(x/2)|,
\]

\[
A_a^-
=M_a^-
+2|\sinh(x/2)\rangle\langle\sinh(x/2)|.
\]

于是每个奇偶扇区只剩一个秩一扰动问题。该结构可能与 Connes--Consani--Moscovici 2025 的秩一
算子机制发生直接联系，但这里的目标是 Suzuki 算子族的首次退化，而不是未经证明地移植 CCM 的
极限结论。

这一步应同时核验：常数和内积归一化、\(q_a^{\mathrm{red}}\) 的闭性与下有界性、奇偶约化后的定义域，
以及分解是否对完整 form domain 而非仅对测试函数成立。

## 3. 最便宜的决定性检查：约化形式的绝对值收缩

对约化形式直接判断

\[
q_a^{\mathrm{red}}(|v|)\le q_a^{\mathrm{red}}(v).
\]

这是当前最重要的快速分叉：

- 若成立，则研究 \(M_a^\pm\) 的 Markov/正性保持结构、最低本征函数的定号性，以及秩一交错对各
  奇偶扇区负谱维数的严格限制；随后进入秩一 resolvent 路线。
- 若不成立，则立即构造最小显式反例，并停止把 Hopf 引理或正基态作为主工具。

note 005 已证明完整 Weil 形式在 \(a>1/6\) 时不满足绝对值收缩；这不自动判定
\(q_a^{\mathrm{red}}\)，因为被移除的极点项本身会改变 \(q(|v|)-q(v)\)。因此本节提出的是一个新的、
尚待计算的判别问题。纯 Dirichlet logarithmic Laplacian 的第一本征函数定号与简单性也不能直接
移植到含算术扰动或极点秩一项的 Weil 算子。

## 4. Schur 补：把零模态降为标量方程

令

\[
\phi_+=\cosh(x/2),\qquad \phi_-=\sinh(x/2).
\]

若 \(M_a^\pm-z\) 可逆，则秩一 resolvent 恒等式给出候选判别函数

\[
F_a^\pm(z)
=1+2\left\langle
\phi_\pm,(M_a^\pm-z)^{-1}\phi_\pm
\right\rangle,
\]

以及

\[
0\in\sigma(A_a^\pm)
\iff F_a^\pm(0)=0
\]

（这里要求 \(0\in\rho(M_a^\pm)\)）。因此潜在 RH 反例可望从无限维零模态降为

\[
\boxed{F_a^+(0)=0\quad\text{或}\quad F_a^-(0)=0.}
\]

必须另外处理 \(M_a^\pm\) 在零点不可逆的情形，特别是与 \(\phi_\pm\) 正交、因而不被秩一扰动
看见的核。排除这种“不可见核”才可能需要唯一延拓、cyclicity 或别的结构输入。最终的 RH 铰链是

\[
\boxed{F_a^\pm(0)\ne0\qquad\forall a>0,}
\]

连同不可见核的排除。

## 5. 标量非消失问题的优先接口

在精确分解和可逆性条件建立后，优先研究：

1. \(F_a^\pm(0)\) 随 \(a\) 的单调性或固定符号；
2. prime-power 阈值之间的 resolvent 变分公式；
3. 阈值处的连续性；
4. \(\phi_\pm\) 是否为 \(M_a^\pm\) 的 cyclic vector；
5. \(F_a^\pm\) 能否识别为显式行列式或已知正函数。

只要全尺度标量非消失和不可见核排除同时成立，首次退化便不可能出现。

## 6. 认证计算的角色

在投入长证明前，先计算有限维近似

\[
F_{a,N}^\pm(0)
=1+2\langle\phi_{\pm,N},M_{a,N}^{\pm,-1}\phi_{\pm,N}\rangle,
\]

并用区间算术和显式尾项上界检验候选符号或尽快寻找反例。计算的目的不是绘制更多本征值曲线，
而是决定“固定符号/单调性”猜想是否值得继续。Groskin 2026 的有限 Guinand--Weil 工作被报告为
可能提供 Archimedean 尾项预算；在其精确定理、归一化和适用范围完成全文核验前，不把它当作认证
误差界的既成来源。

## 7. PDE 与 CCM 的降级位置

PDE 只在秩一归约需要排除不可见核、证明 cyclicity 或控制 resolvent 边界值时按需启用。note 004
已完成 Weil 闭形式与 Dirichlet logarithmic Laplacian 能量空间的对应；但现有 Hopf/Hölder/Harnack
结果对一维、初始仅有 \(L^2\) 的变号零模态仍有接口缺口，note 005 又排除了从完整形式的标准
Beurling--Deny 判据直接取得正基态。因此不再把一般边界 PDE 框架作为主线。

若标量路线失败，CCM 作为备线，次序应为：先在固定尺度 \(\lambda\) 下证明 Galerkin ground state
随 \(N\to\infty\) 收敛；再证明 Fourier 变换构成正规族；最后才处理 \(\lambda\to\infty\) 并尝试
识别极限为 \(\Xi\)。不同时处理 \(N,\lambda\to\infty\)。

## 8. 明确停止投入的方向

- 未证明零模态定号前直接套 Hopf 引理；
- 只证明 spectral flow 存在而不能排除 crossing；
- 继续提高数值零点吻合位数；
- 用 pair correlation 或 density-one 结果排除稀疏离线零点；
- 建立与 RH 闭合链无直接接口的一般 PDE 大框架。

## 9. 成果升级阶梯

- 已有基础：首次退化零模态归约、完整闭形式定义域纠错、全谱单调性，以及完整形式的标准正性路线
  反例。
- 下一项实质成果：严格的“极点秩二—奇偶秩一”分解、首次退化 Schur 补定理，以及与既有全谱
  单调性的兼容性。
- 重大成果：证明 \(F_a^\pm(0)\) 全尺度非消失并排除不可见核。
- 最终成果：排除首次退化，证明全部局部 Weil 形式非负，从而由 Weil 判据推出 RH。

## 10. 本轮证据边界

下列文献是本路线判断的待核验或已知背景入口：

- Masatoshi Suzuki, *Weil's quadratic form via the screw function*,
  [arXiv:2606.09096](https://arxiv.org/abs/2606.09096)：首次退化归约已在 note 001 全文核对。
- Connes--Consani--Moscovici 2025,
  [arXiv:2511.22755](https://arxiv.org/abs/2511.22755)：秩一算子联系尚需逐定理核对。
- Arora--Mukherjee--Vaishnavi 2026,
  [arXiv:2605.13513](https://arxiv.org/abs/2605.13513)：纯 logarithmic Laplacian 基态结果仅作邻接背景，
  不能直接移植。
- Chen--Weth, [arXiv:1710.03416](https://arxiv.org/abs/1710.03416)：能量空间与稠密性已在 note 004
  用于定义域对应。
- Biswas 等 2026, [arXiv:2608.07315](https://arxiv.org/abs/2608.07315)：其一维适用性、解的有界性
  假设与具体定理尚待全文核验。
- Groskin 2026, [arXiv:2607.02828](https://arxiv.org/abs/2607.02828)：认证尾项接口尚待全文核验。

本轮最重要的新路线判断是：现有 PDE 文献没有消除一维 \(L^2\to L^\infty\) 与基态符号缺口，
而极点项可能在奇偶分解后把首次退化压缩为每扇区一个秩一问题。因此下一里程碑应改为严格核验该
分解，并以 \(q_a^{\mathrm{red}}\) 的绝对值收缩作为最便宜的决定性观测。
