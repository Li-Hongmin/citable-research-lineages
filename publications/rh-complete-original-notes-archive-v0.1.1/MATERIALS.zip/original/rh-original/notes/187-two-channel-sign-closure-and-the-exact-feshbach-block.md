> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two-channel sign closure and the exact finite Feshbach block

## Sign-channel doubling

令 \(h\) 是 note 184 的偶实 symbol，取

\[
\mathcal H=L^2(\mathbb R,|h(\xi)|\,d\xi),
\qquad
\Sigma f=\operatorname{sgn}(h)f.
\]

对 divisor 指数映射 \(T_Xe_a=e^{i\xi\log a}\)，不要只使用
\(\operatorname{Ran}T_X\)，而定义二通道映射

\[
\mathcal T_X=[\,T_X,\ \Sigma T_X\,]:
\mathbb C^{D_X}\oplus\mathbb C^{D_X}\longrightarrow\mathcal H.
\]

令 \(\mathsf S\) 为交换两个 channel 的矩阵，令
\(\mathsf R=\operatorname{diag}(R_X,R_X)\)。则有精确闭性

\[
\boxed{\Sigma\mathcal T_X=\mathcal T_X\mathsf S},
\qquad
\boxed{J_{\log X}\mathcal T_X=\mathcal T_X\mathsf R}.
\]

这里 \(\mathsf S^2=\mathsf R^2=I\)，并且 \(\mathsf S\) 与 \(\mathsf R\) 对易。
这不是对连续乘法算子的有限秩修补：每个 channel 都包含整个 divisor
指数族，所以不违反 note 182 的无限负惯性 no-go。

## 正 Gram 的 \(2\times2\) channel block

在这个加权 Hilbert 空间中令 \(A=I\)。二通道 Gram 为

\[
\mathcal G_X=\mathcal T_X^*\mathcal T_X
=
\begin{pmatrix}
G_{|h|}&G_h\\
G_h&G_{|h|}
\end{pmatrix}\succeq0,
\]

其中

\[
G_{|h|}=T_X^*M_{|h|}T_X,\qquad
G_h=T_X^*M_hT_X.
\]

其 channel 对称/反对称 Schur 块是

\[
G_{|h|}+G_h=2G_{h_+}\succeq0,
\qquad
G_{|h|}-G_h=2G_{h_-}\succeq0.
\]

因此 sign splitting 本身已经变成一个精确的正 \(2\times2\) Gram，而不是
逐频绝对值估计。

## Reciprocal block 的恢复

由于 \(\mathsf S\mathsf R\) 在第一 channel 的压缩是 \(R_X\)，有

\[
\Pi_0\mathcal G_X\mathsf S\mathsf R\Pi_0^*
=G_hR_X
=T_X^*M_hJ_{\log X}T_X
=H_X,
\]

其中 \(\Pi_0\) 投影到第一 channel。这给出 exact finite Feshbach block：
原 reciprocal Hankel 是正 channel Gram 与交换/反射矩阵的压缩，而不是一个
孤立的 scalar complement。

若 \(c_X\) 是 Möbius divisor 向量且
\(R_Xc_X=\mu(X)c_X\)，定义

\[
z_\pm=(c_X,\pm c_X).
\]

则 \(\mathsf Sz_\pm=\pm z_\pm\)、\(\mathsf Rz_\pm=\mu(X)z_\pm\)，并且

\[
z_\pm^*\mathcal G_Xz_\pm
=2\,c_X^*(G_{|h|}\pm G_h)c_X
=4\,c_X^*G_{h_\pm}c_X\ge0.
\]

原始 reciprocal 二次型正是这两个 channel 能量的 signed 组合；二通道块没有
消除 parity 符号，但把需要控制的对象压成了两个明确的正能量。

## 对 A 线的最小接口

这说明 A/Feshbach 若要与实际 Weil 格匹配，最薄的对象不是单个
\(T_X\)，而是

\[
\mathcal T_X=[T_X,\operatorname{sgn}(h)T_X]
\]

及其正 Gram \(\mathcal G_X\)，同时保留 channel swap \(\mathsf S\) 与 divisor
reflection \(\mathsf R\)。剩余的算术命题是同一 Möbius 状态上两个正 channel
能量的 parity-相容比较；普通 \(G_{|h|}\succeq0\) 不足以给出该比较。

本 note 给出可计算的二通道 exact block，不是 RH 证明。
