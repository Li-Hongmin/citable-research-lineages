> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 单侧 reciprocal detector 的 divisor 半格边界恒等式

日期：2026-08-15。

本 note 把 note 169 的完整 divisor 反射格与实际 reciprocal detector 的
\(a,b<\sqrt X\) 截断精确接起来。关键区别是论文中的 \(P(y)\) 只定义在
\(y\ge1\)，因此对应的 log-kernel 是单侧的，不能直接套用偶核的
\(H=GR\) 恒等式。

## 1. 记号

令 \(P:[1,\infty)\to\mathbb R\)，并作单侧延拓

\[
p(t)=\begin{cases}P(e^t),&t\ge0,\\0,&t<0,\end{cases}
\qquad
g(t)=\frac{p(t)+p(-t)}2.
\]

取 squarefree、非平方的 \(X\)，令
\[
L_X=\{d:d\mid X,\ d<\sqrt X\},
\qquad \varepsilon_X=\mu(X).
\]
因为 \(X\) squarefree，divisor complement \(d\mapsto X/d\) 把 \(L_X\)
双射到上半格 \(U_X=\{d\mid X:d>\sqrt X\}\)，且
\[
\mu(X/d)=\varepsilon_X\mu(d).
\tag{1}
\]

定义实际 reciprocal 半格二次型与对称 Toeplitz 边界项
\[
Q_X=\sum_{a,b\in L_X}\mu(a)\mu(b)\,P\!\left(\frac X{ab}\right),
\qquad
G_X=\sum_{a,b\in L_X}\mu(a)\mu(b)\,g\!\left(\log\frac ab\right).
\tag{2}
\]

## 2. 精确半格恒等式

在完整 divisor 格 \(D(X)=L_X\sqcup U_X\) 上定义单侧 reciprocal 二次型
\[
H_X=\sum_{a,b\mid X}\mu(a)\mu(b)\,
p\!\left(\log\frac X{ab}\right).
\tag{3}
\]

把求和按 \(L_X\) 与 \(U_X\) 分块。若 \(a,b\in L_X\)，则 \(ab<X\)，
故该块正好是 \(Q_X\)。若 \(a=X/u,b=X/v\in U_X\)，则
\(X/(ab)=uv/X<1\)，单侧延拓使该块为零。交叉块给出
\[
\begin{aligned}
&\sum_{u,v\in L_X}\mu(u)\mu(X/v)
 \left[p\!\left(\log\frac vu\right)+p\!\left(\log\frac uv\right)\right]\\
&\hspace{2cm}=2\varepsilon_XG_X.
\end{aligned}
\]
因此有严格恒等式
\[
\boxed{H_X=Q_X+2\varepsilon_XG_X.}
\tag{4}
\]

这就是单侧 detector 的最薄 boundary correction；没有使用 RH，也没有把
\(P\) 假设成偶函数。

## 3. 与 Weil/反射接口的含义

若 \(g\) 恰好是正定 log-kernel，则 \(G_X\ge0\)；但这只是一个附加的
Fourier/Bochner 条件，不能由 \(P(y)\ge0\) 推出。实际 detector 的 Mellin
symbol 往往变号，故 \(G_X\) 一般是 signed Toeplitz 边界项。

若另有完整 divisor 格上的 Weil 正性 \(H_X\ge0\)，(4) 只给出
\[
Q_X\ge -2G_X\quad(\varepsilon_X=+1),
\qquad
Q_X\ge 2G_X\quad(\varepsilon_X=-1),
\]
并不自动给出所有 \(X\) 的 \(Q_X\ge0\)。后者仍需要控制 \(G_X\) 的符号
或大小；这正是从完整反射格回到实际半格 detector 的边界缺口。

对于偶的理想化 kernel，\(p(t)=p(-t)\)，上半格块不再为零，恢复的是
note 169 的完整 \(H=GR\) 结构，而不是 (4)。因此不能用偶核惯性结论
直接替代论文中单侧 \(P\) 的算术门。

更一般地写 \(p=g+o\)，其中 \(g\) 偶、\(o\) 奇。完整 divisor 格上的
ordinary kernel \(G_g(a,b)=g(\log(a/b))\) 与 complement reflection \(R_X\)
对易，而 \(G_o(a,b)=o(\log(a/b))\) 与之反对易。于是单侧 reciprocal 矩阵
可写成
\[
H=(G_g-G_o)R_X,
\tag{5}
\]
其中偶部分保持两个反射 parity，奇部分只连接两个 parity。对满足
\(R_Xc=\mu(X)c\) 的 Möbius divisor mode，因 \(c^{T}G_oc=0\)，有
\[
c^{T}Hc=\mu(X)c^{T}G_gc.
\tag{6}
\]
式 (5)--(6) 是单侧边界恒等式 (4) 的完整格版本；它明确指出真正缺口是
控制奇部分与半格截断，而不是再寻找一个普通 PSD Gram。

## 4. 单侧完整格不可能直接 PSD 化

还有一个与 $P$ 的具体形状无关的 $2×2$ 障碍。令 $X$ 至少含两个
不同素因子，取其最小素因子 ℓ，满足 ℓ<√X，并令 $a=X/ℓ$。对完整单侧矩阵
\[
\mathcal H_{u,v}=p\!\left(\log\frac X{uv}\right)
\qquad(u,v\mid X)
\]
考虑指标 $(1,a)$。因为 ℓ²<X，有
\[
\mathcal H_{1,1}=P(X),\qquad
\mathcal H_{1,a}=P(ℓ),\qquad
\mathcal H_{a,a}=P(ℓ^2/X)=0.
\]
所以
\[
\det\mathcal H|_{\{1,a\}}=-P(ℓ)^2.
\tag{7}
\]
只要某个素数处 $P(ℓ)\ne0$，该完整单侧 reciprocal 矩阵就严格不定。
因此 (3) 中的 $H_X\ge0$ 不能作为一般的“单侧 detector Weil 正性”假设；
必须加入其它 archimedean/prime block，或保留 signed Schur 补来支付这个
边界负方向。这也解释了为什么 (4) 只应被视为边界接口，而不是正性结论。

本文只建立 (4) 及其边界解释，不声称 RH。
