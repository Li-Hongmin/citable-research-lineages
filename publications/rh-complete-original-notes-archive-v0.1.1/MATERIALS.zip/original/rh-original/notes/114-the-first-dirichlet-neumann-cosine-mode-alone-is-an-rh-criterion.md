> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 第一 Dirichlet--Neumann 余弦模单独构成 RH 判据

日期：2026-08-14。

依赖：
[note 101](101-a-bv-mellin-detector-sees-exactly-uncancelled-zeta-multiplicity.md)、
[note 113](113-rh-is-equivalent-to-square-root-many-explicit-low-mobius-cosine-modes.md)。

证据等级：显式 Mellin 递推、整个右半平面的解析零自由性，
以及移动余弦和与固定 BV detector 之间的 \(O(1)\) 比较。

note 113 将 RH 等价于前 \(\sqrt m\) 个低频 Möbius 余弦模的加权能量。
本文证明其中第一模的权函数本身已是零自由 Mellin detector。
因此对 RH 的双向等价性而言，余下的 \(\sqrt m-1\) 个模出现为冗余。

## 1. 余弦 detector 的右半平面零自由性

令

\[
b=\frac\pi2,
\qquad
W(u)=\cos(bu)\mathbf1_{(0,1)}(u),
\tag{1}
\]

并定义

\[
K_W(s)=\int_0^1\cos(bu)u^{s-1}du,
\qquad \Re s>0.
\tag{2}
\]

### 定理 1

\[
\boxed{K_W(s)\ne0\qquad(\Re s>0).}
\tag{3}
\]

**证明。** 由 \(\cos b=0\)，第一次分部积分给出

\[
K_W(s)=\frac b{s}\int_0^1u^s\sin(bu)du.
\tag{4}
\]

对右边再分部积分，并用 \(\sin b=1\)，得

\[
\boxed{
K_W(s)=\frac b{s(s+1)}
\left[1-bK_W(s+2)\right].}
\tag{5}
\]

若 \(\sigma=\Re s>0\)，由 \(\cos(bu)\ge0\) on \([0,1]\)，

\[
\begin{aligned}
|bK_W(s+2)|
&\le b\int_0^1u^{\sigma+1}\cos(bu)du\\
&<b\int_0^1u\cos(bu)du\\
&=1-\frac1b
=1-\frac2\pi
<1.
\end{aligned}
\tag{6}
\]

因此 (5) 中的方括号不为零，而 \(s(s+1)\ne0\)。这证明 (3)。\(\square\)

这个证明不使用数值穷尽；零自由区域比 RH 所需的
\(1/2<\Re s<1\) 更强。

## 2. 第一离散余弦模

对 \(m\ge1\)，定义

\[
\theta_m=\frac\pi{2m+1},
\tag{7}
\]

\[
\mathcal C_m
=\sum_{n\le m}\mu(n)
\cos\left((n-\tfrac12)\theta_m\right).
\tag{8}
\]

这正是 note 113 的 \(k=1\) 未归一化 Dirichlet--Neumann 余弦模。
置

\[
x_m=m+\frac12.
\tag{9}
\]

则 \(\theta_m=\pi/(2x_m)\)，而 note 101 的 detector 和为

\[
U_W(x_m)
=\sum_{n\le m}\mu(n)
\cos\left(\frac{\pi n}{2x_m}\right).
\tag{10}
\]

由余弦函数的 Lipschitz 常数为 \(b\)，

\[
\begin{aligned}
|\mathcal C_m-U_W(x_m)|
&\le\sum_{n\le m}
\frac b{2x_m}|\mu(n)|\\
&\le\frac{bm}{2x_m}
\le\frac b2.
\end{aligned}
\tag{11}
\]

因此两个移动和的平方根界完全等价。

## 3. 单模 RH 等价定理

### 定理 2

以下两命题等价：

1. 黎曼猜想成立；
2. 对每个 \(\varepsilon>0\)，

   \[
   \boxed{
   |\mathcal C_m|
   \ll_\varepsilon m^{1/2+\varepsilon}
   \qquad(m\ge1).}
   \tag{12}
   \]

**RH \(\Rightarrow\) (12)。** \(W\) 的零延拓属于 BV，因此对 \(U_W\) 作 Abel 求和并使用
经典 RH 等价界 \(M(x)\ll_\varepsilon x^{1/2+\varepsilon}\)，得

\[
U_W(x)\ll_\varepsilon x^{1/2+\varepsilon}.
\tag{13}
\]

与 (11) 合并即得 (12)。

**(12) \(\Rightarrow\) RH。** 函数 \(U_W(x)\) 在每个整数入口处连续，因为新项的入口值是
\(W(1)=0\)。在两个相邻整数之间，

\[
\begin{aligned}
|U_W'(x)|
&\le\frac b{x^2}\sum_{n\le x}n|\mu(n)|\\
&\le C_b.
\end{aligned}
\tag{14}
\]

所以 \(U_W\) 在 \([1,\infty)\) 上一致 Lipschitz。每个 \(x\ge1\) 距某个半整数 \(x_m\) 至多
\(1/2\)。由 (11)--(12)，

\[
U_W(x)\ll_\varepsilon x^{1/2+\varepsilon}.
\tag{15}
\]

它立即推出 note 101 的 dyadic mean-square 界。由定理 1，\(K_W\) 在
\(1/2<\Re s<1\) 零自由；因此 note 101 的零自由 detector 定理给出 RH。\(\square\)

## 4. 精确意义

note 113 的加权平均判据仍有独立价值：它允许不同低模之间的能量分配，
并与 finest-scale Gram 的谱尾直接对接。但对“是否与 RH 等价”这一二值问题，
它的第一非负项已足够：

\[
\boxed{
\text{RH}
\iff
\text{第一移动 DN 余弦和具有平方根界}.}
\]

这是一个等价判据，不是对 (12) 的无条件证明。
