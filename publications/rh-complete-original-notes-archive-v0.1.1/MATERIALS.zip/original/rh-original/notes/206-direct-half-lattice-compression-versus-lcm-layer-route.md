> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 直接半格压缩与 lcm 分层路线的范围校正

日期：2026-08-15。

## 1. 直接半格压缩不需要 lcm completion

令
\[
 p(t)=\mathbf 1_{t\ge0}P(e^t),\qquad
 g(t)=\frac{p(t)+p(-t)}2,
\]
并设 \(h=\widehat g\)。令 \(\widetilde g\) 为把 \(h\) 换成
\(|h|\) 后的逆 Fourier 变换。对任意有限标签集 \(S\)，定义
\[
 A_S(a,b)=\widetilde g(\log(a/b)),\qquad
 B_S(a,b)=g(\log(a/b)).
\]
指数向量的 Gram 表示给出
\[
 \begin{pmatrix}A_S&B_S\\B_S&A_S\end{pmatrix}\succeq0.
 \tag{1}
\]

固定任意实数 \(X>1\)，取
\[
 L_X=\{1,\ldots,\lfloor\sqrt X\rfloor\},qquad
 R_X(a)=X/a,qquad S_X=L_X\cup R_X(L_X).
\]
反射 \(R_X\) 保持 \(S_X\)，且与差核矩阵交换。令
\[
 H_S=B_SR_X.
\]
由 (1) 对反射块作共轭，再取 \(L_X\) 的主压缩，得到
\[
 \begin{pmatrix}A_L&H_L\\H_L&A_L\end{pmatrix}\succeq0,
 \qquad
 A_L-H_LA_L^{\dagger}H_L\succeq0,
 \tag{2}
\]
其中奇异情形使用 Moore--Penrose 逆及其 range 条件。这里的主压缩是
任意实标签的主压缩，完全不要求 \(a\mid X\)。

若 \(a,b\le\sqrt X\)，则 \(ab\le X\)，所以
\[
 (H_L)_{ab}=g\!\left(\log\frac{ab}{X}\right)
 =\frac12P\!\left(\frac X{ab}\right).
\]
因此对 \(c_a=\mu(a)\)，原 reciprocal-product 二次型满足精确恒等式
\[
 T_P(X):=\sum_{a,b\le\sqrt X}\mu(a)\mu(b)P\!\left(\frac X{ab}\right)
 =2c^*H_Lc,
\]
并有
\[
 |T_P(X)|
 \le 2c^*A_Lc
 =\frac1\pi\int_{\mathbb R}|h(\xi)|
 \left|\sum_{a\le\sqrt X}\mu(a)a^{i\xi}\right|^2d\xi .
 \tag{3}
\]
所以从 divisor lattice 到 common-scale 整数半格的 completion 并不是原
二次型的必要缺口；直接半格压缩已经给出精确接口。

## 2. note205 的正确范围

note205 研究的是另一件事：先按 \(\operatorname{lcm}(a,b)=X\) 分层，再试图
用完整 divisor 层逐层替换。对素数层 \(\sqrt x<p\le x\)，完整层
\[
-2P(x/p)+P(x/p^2)
\]
非零而 cutoff 层为零，故该逐层 completion 替换确实失败；互补 Gram block
公式需要保留 cutoff 内部反射块，已在 note205 修正；这不改变逐层替换
失败的结论。

这不否定 (2)--(3)，因为 (3) 从一开始就在完整的整数半格
\(1\le a,b\le\sqrt X\) 上工作，并没有把 common-scale 二次型分解成 lcm
层后再拼接。故 note205 应被解释为“lcm 分层替代路线关闭”，而不是“原
半格压缩仍有 completion 缺口”。

## 3. 经过校正后的唯一承重命题

当前真正需要证明的是正能量界
\[
 \int_{\mathbb R}|h(\xi)|
 \left|\sum_{a\le\sqrt X}\mu(a)a^{i\xi}\right|^2d\xi
 \ll_\varepsilon X^{1/2+\varepsilon}.
 \tag{4}
\]
note200--202 只给无条件 \(X^{1-o(1)}\) 型能量上界；若 (4) 成立，(3)
再结合既有 Mellin 等价即可进入 RH。因而后续工作应集中在 (4) 的 signed
Möbius cancellation，而不再把 lcm completion 当作独立障碍。
