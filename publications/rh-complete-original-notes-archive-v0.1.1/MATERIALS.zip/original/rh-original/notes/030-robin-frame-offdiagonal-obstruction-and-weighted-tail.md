> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Robin frame 的 off-diagonal 障碍与 deficit-weighted 尾定理

日期：2026-08-11。

本文修正 note 024 之后一个自然但错误的 almost-orthogonality 猜想，并证明把统一 frame 问题缩到
有限 \(n\)-核心所需的严格加权尾估计。

固定区间长度 \(a\)，令 \(g_{n,j}\) 为归一化 even/odd Robin 模式，
\(b_n=n+1/4\)。本文只讨论 note 024 中

\[
B_M=E_M-W_MW_M^*,\qquad E_M\geq\delta I
\]

所需的 frame 估计。

## 1. \(n-m\) 衰减是错误目标

对每个固定 \(j\)，Robin 根满足

\[
z_{n,j}=\theta_j+O_j(b_n^{-1}),
\]

归一化模式因而在 \(L^2(0,a)\) 中满足

\[
g_{n,j}=u_j+O_j(b_n^{-1}),
\]

其中 \(u_j\) 是对应的 ND 极限 cosine/sine 模式。若 \(E_M^{-1}\) 有界，则

\[
\langle g_{n,j},E_M^{-1}g_{m,j}\rangle
=\langle u_j,E_M^{-1}u_j\rangle
+O_j(b_n^{-1}+b_m^{-1}).
\]

因为 \(E_M\geq\delta I\) 且 \(E_M\) 有界正定，右端极限严格为正。
取 \(n_r=r, m_r=2r\)，则

\[
|n_r-m_r|\to\infty
\]

但矩阵元不趋零。这给出精确 Robin frame 内部的显式不衰减序列。

## 2. 单独的 coercivity 也不推出 \(j-k\) 衰减

令 \(\{u_j\}\) 为 ND 正交基。选取两两不交、距离趋于无穷的指标对
\((p_r,q_r)\)，并令自伴酉算子 \(U\) 交换 \(u_{p_r},u_{q_r}\)，在其余
方向取恒等或符号。对 \(0<\varepsilon<1\)，置

\[
T=I+\varepsilon U,\qquad E=T^{-1}.
\]

则 \(E\) 有界且一致正定，但

\[
|\langle u_{p_r},E^{-1}u_{q_r}\rangle|=\varepsilon,
\qquad |p_r-q_r|\to\infty.
\]

所以假设“固定 active prime graph 且 \(E_M\geq\delta I\)”若只使用
coercivity，本身不足以证明频率 off-diagonal 衰减。必须额外利用 exact
prime graph 的正则性或 commutator 结构。

## 3. 可证明的最小加权尾引理

把 deficit 列写为

\[
w_{n,j}=d_{n,j}^{1/2}g_{n,j},\qquad
d_{n,j}=\ell_{n,M}-\ell_{n,j},\quad j<M.
\]

对固定 \(M\)，精确根界直接给出

\[
0\le d_{n,j}\le \ell_{n,M}
\le C_a\theta_M^2 b_n^{-3}.
\tag{1}
\]

令 \(W_{>N}\) 是只保留 \(n>N\) 的 synthesis operator。无需任何
off-diagonal cancellation，正算子 trace 界给出

\[
\boxed{
\|W_{>N}\|^2
=\|W_{>N}W_{>N}^*\|
\le \sum_{n>N}\sum_{j<M}d_{n,j}
\le C_a M\theta_M^2 N^{-2}.}
\tag{2}
\]

从而

\[
\boxed{
\|W_{>N}^*E_M^{-1}W_{>N}\|
\le \delta^{-1}C_a M\theta_M^2N^{-2}.}
\tag{3}
\]

并且若 \(W_{\le N}\) 表示其余列，则交叉块满足

\[
\boxed{
\|W_{>N}^*E_M^{-1}W_{\le N}\|
\le \delta^{-1}\|W_{>N}\|\|W_{\le N}\|.}
\tag{4}
\]

这里所需的总 trace 界可以直接从 Robin 根严格推出，而不需依赖
note 024 的数值诊断。令

\[
f_b(x)=\frac{x}{b(4b^2+x)}.
\]

对 \(x\ge y\ge0\) 有精确恒等式

\[
f_b(x)-f_b(y)
=\frac{4b(x-y)}{(4b^2+x)(4b^2+y)}.
\tag{5}
\]

even 根位于 \((j\pi,(j+1/2)\pi)\)（\(j=0\) 时下端为零），odd 根位于
\(((j+1/2)\pi,(j+1)\pi)\)。因此，对两个奇偶扇区都存在只依赖
\(a\) 的常数，使得对 \(M\ge1\)、\(0\le j<M\)，

\[
\mu_{n,M}^2-\mu_{n,j}^2\le C_aM^2,
\quad
4b_n^2+\mu_{n,M}^2\ge c_a(b_n^2+M^2),
\quad
4b_n^2+\mu_{n,j}^2\ge c_a(b_n^2+j^2).
\]

将它们代入 (5) 得

\[
d_{n,j}
\le C_a\frac{b_nM^2}{(b_n^2+M^2)(b_n^2+j^2)}.
\tag{6}
\]

由于 \(b_n\ge1/4\)，积分比较给出

\[
\sum_{j=0}^{M-1}\frac1{b_n^2+j^2}\le \frac{C}{b_n}.
\]

故

\[
\sum_{j<M}d_{n,j}\le C_a\frac{M^2}{b_n^2+M^2},
\qquad
\boxed{\sum_{n\ge0}\sum_{j<M}d_{n,j}\le C_aM.}
\tag{7}
\]

最后一步仍是对 \(\sum_{n\ge0}M^2/(b_n^2+M^2)\) 作积分比较。
因此 (4) 严格给出

\[
\|\text{cross}\|\lesssim_{a,\delta}M^2N^{-1}
\tag{8}
\]

（使用 \(\theta_M\asymp M\)）。因此选择 \(N(M)/M^2\to\infty\) 可使
大 \(n\) frame 尾及其交叉块在算子范数下趋零；这不证明完整的
\(\eta_M\|E_M\|\to0\)，但把困难缩成有限的 \(n\le N(M)\) 核心，而不是
追求事实上不存在的 \(n-m\) 衰减。

## 4. 真正可能的 \(j-k\) 引理

以下 commutator 是本 note 得出的最小候选；note 031 随后证明它已被单个 partial reflection 的
端点 jump 否定。保留本节是为了明确被关闭的接口。

若能对 exact prime-orbit resolvent 证明某个一阶参考频率算子 \(D\) 下

\[
\sup_M\|[D,E_M^{-1}]\|<\infty,
\tag{9}
\]

则对 \(D u_j=\omega_j u_j\)，

\[
(\omega_j-\omega_k)\langle u_j,E_M^{-1}u_k\rangle
=\langle u_j,[D,E_M^{-1}]u_k\rangle,
\]

故

\[
|\langle u_j,E_M^{-1}u_k\rangle|
\le C|\omega_j-\omega_k|^{-1}\quad(j\ne k).
\tag{10}
\]

Robin 位移 \(g_{n,j}-u_j=O(\theta_j/(ab_n))\) 再给出相应带误差版本。
式 (9) 是比抽象 coercivity 强、又足以产生所需频率衰减的最小结构命题。
但截断 reflection 在 collar 边界有跳跃，预期最多先得到 \(1/|j-k|\)，且
该衰减在二维 Schur 求和中不是绝对可和；要闭合还需 deficit 权重或二阶
commutator/分块 almost-orthogonality。

## 5. 决策

* 放弃按 \(|n-m|\) 的 unweighted decay：它被固定 \(j\)、\(n,m\to\infty\)
  的共极限模式直接否定。
* 不可从 \(E_M\ge\delta I\) 单独推出 \(|j-k|\) 衰减。
* 当前无需额外解析结构即可证明的推进是 (2)--(4) 及 (7)--(8)：先以
  \(N(M)/M^2\to\infty\) 删除大 \(n\) 加权尾。
* 本 note 提出的 commutator 界 (9) 已被 note 031 严格否定；后续只能使用
  \(|s|<1/2\) 的 Sobolev multiplier、允许导数损失的估计或 deficit-weighted dyadic blocks。
