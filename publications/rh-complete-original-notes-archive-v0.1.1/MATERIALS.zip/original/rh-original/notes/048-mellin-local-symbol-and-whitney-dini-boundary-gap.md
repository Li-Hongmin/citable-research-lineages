> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mellin-local symbol 与一维 Whitney--Dini 边界缺口

日期：2026-08-11；文献检索截止同日。

本文计算 [note 047](047-volterra-boundary-indicial-root-and-mellin-local-hinge.md) 中同尺度环算子的
精确 Mellin symbol，排除所有 regularly-varying 单相位抵消，并说明现有正则性文献为什么尚不能
给出所需的一维端点估计。

## 1. 精确 Mellin symbol

在 \(t=\log(1/r)\) 坐标中，同尺度环 \(s\in[r/2,2r]\) 变成长度

\[
L=\log2
\]

的 translation-local 算子。对 Fourier 模 \(e^{i\xi t}\)，其 symbol 为

\[
\boxed{
m(\xi)
=\int_0^L(1-\cos(\xi h))\coth(h/2)\,dh
-i\frac{1-\cos(\xi L)}{\xi}.}
\tag{1}
\]

于是

\[
\operatorname{Re}m(\xi)\ge0,
\]

且等号只在 \(\xi=0\) 取得。低频展开为

\[
m(\xi)=c_2\xi^2-i\frac{L^2}{2}\xi+O(\xi^3),
\tag{2}
\]

高频展开为

\[
\boxed{
m(\xi)=2\log|\xi|+O(1)+O(i/|\xi|).}
\tag{3}
\]

因此 Mellin-local 部分是正的 logarithmic-order 算子加一个低阶 skew drift；它没有能与 Volterra
主部抵消的负高频 symbol。

## 2. WKB 生死分类

取临界振幅单相位

\[
U(t)=t^{-1/2}e^{i\phi(t)},
\qquad \xi(t)=\phi'(t).
\]

Volterra 主部

\[
\mathcal VU=2tU-\int^tU
\]

与 Mellin-local 部分有以下分类：

1. 若 \(\xi=\omega/t\)，Volterra 系数为
   \[
   2-\frac1{1/2+i\omega},
   \]
   仅 \(\omega=0\) 消失；而 Mellin 项为 \(O(t^{-3/2})\)。
2. 若 \(\log|\xi|=o(t)\) 且不属上式慢相位，\(\mathcal VU\asymp\sqrt t\)，Mellin 项为
   \(o(\sqrt t)\)。
3. 若 \(\log|\xi|\sim ct\)、\(c>0\)，两者的实主部同号，总量约为
   \(2(1+c)tU\)。
4. 超指数频率由式 (3) 的正 Mellin symbol 主导。

故不存在 regularly-varying 单相位的无 trace 解使

\[
(\mathcal V+\mathcal M)U\in L^\infty.
\]

这不是任意多频数据的完整定理；它严格关闭的是单相位/WKB 抵消机制。

## 3. 最薄充分正则性

一个直接充分条件是 uniform Whitney--Dini 模：对 \(s\in[r/2,2r]\)，

\[
|u(a-r)-u(a-s)|
\le C\omega(|r-s|/r),
\tag{4}
\]

其中

\[
\int_0^1\frac{\omega(\tau)}\tau\,d\tau<\infty.
\tag{5}
\]

则

\[
\sup_{0<r<r_0}
\int_{r/2}^{2r}
\frac{|u(a-r)-u(a-s)|}{|r-s|}\,ds<\infty,
\]

从而 note 047 的 Volterra 引理给出 signed gauge trace。特别地，任意尺度不变 Hölder 模

\[
|u(a-r)-u(a-s)|\le C(|r-s|/r)^\kappa
\]

都足够。

## 4. 文献边界

截至 2026-08-11，Biswas--Roy--Sen--Sharma 的 *Hölder regularity and Harnack inequality for
the logarithmic Laplacian*（arXiv:2608.07315）已缓存全文。其 Schauder/Hölder 主定理：

- 明确假设 \(n\ge2\)，证明使用 \(\rho_n\ge0\)；一维有 \(\rho_1=-2\gamma<0\)；
- 是 interior estimate，常数依赖到边界的距离；
- Hölder 改善要求右端本身 Hölder，而非仅有界。

因此它不能推出 (4)--(5) 的一维、尺度一致、边界 Whitney 估计。现有最优
\(1/\sqrt{\log}\) 边界上界的普通 Dini 积分仍发散。弱方程只控制 signed singular integral，
Caccioppoli 估计只控制 \(L^2\) jump energy，也都不能直接升级为绝对 Whitney--Dini。

## 5. 当前判定

没有发现满足 bounded logarithmic equation 的真正反例；精确 symbol 与 WKB 分类反而支持 trace
存在。尚缺的命题是任意多频数据上的 weighted coercive estimate：把式 (1) 的正 symbol 与非平稳
Volterra 系数 \(2t\) 联合起来，推出 (4)--(5) 或足以替代它的平均 Dini 控制。

所以当前状态是一个精确 PDE 缺口，不是反例，也不是已证边界正则性。

