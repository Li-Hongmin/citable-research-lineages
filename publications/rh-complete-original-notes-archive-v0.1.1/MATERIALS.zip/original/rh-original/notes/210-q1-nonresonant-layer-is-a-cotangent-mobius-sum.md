> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(q=1\) 非共振层的 cotangent--Möbius 形式

日期：2026-08-15。

本 note 从 note 209 的 Fourier--Bernoulli 双和中抽出最危险的
\(q=re+sd=1\) 层，给出精确的 cotangent 系数。它不提供估计，但把
非共振缺口压成一个可直接研究的 reciprocity 型算术对象。

## 1. 精确系数

设 \(d,e>1\) 且 \((d,e)=1\)。记
\[
 C_{d,e}(q):=
 \sum_{re+sd=q}\widehat B(r)\widehat B(s),\qquad
 \widehat B(r)=-\frac1{2\pi i r},\quad r,s\ne0,
\]
和式按 Abel 正则化理解。取 Bezout 解
\[
 r_0e+s_0d=1.
\]
所有解为 \(r=r_0+dt,\ s=s_0-et\)。因
\[
 \frac1{rs}=\frac d{r(1-er)}
 =d\left(\frac1r+\frac e{1-er}\right),
\]
以及
\[
 \sum_{t\in\mathbb Z}\frac1{r_0+dt}
 =\frac\pi d\cot\frac{\pi r_0}d,\qquad
 \sum_{t\in\mathbb Z}\frac1{s_0-et}
 =\frac\pi e\cot\frac{\pi s_0}e,
\]
得到
\[
 \boxed{
 C_{d,e}(1)=
 -\frac1{4\pi}
 \left(\cot\frac{\pi r_0}d+\cot\frac{\pi s_0}e\right).}
 \tag{1}
\]
右端与 Bezout 解的选择无关，因为 cotangent 的周期性抵消了整数平移。

更一般地，若 \(g=(d,e)\) 且 \(g\mid q\)，令
\(d'=d/g,e'=e/g,q'=q/g\)，在没有 \(r=0\) 或 \(s=0\) 的极点时同样有
\[
 C_{d,e}(q)=
 -\frac1{4\pi q'}
 \left(\cot\frac{\pi r_0}{d'}+\cot\frac{\pi s_0}{e'}\right),
 \qquad r_0e'+s_0d'=q'.
 \tag{2}
\]
若 \(g\nmid q\)，则 \(C_{d,e}(q)=0\)。当 \(q'\) 使某个端点解为零时，
需将该项从 Fourier 和中删去后取相应的有限部；本 note 只使用没有极点的
\(q=1,(d,e)=1,d,e>1\) 情形。

## 2. \(q=1\) 边界双和

令
\[
 \mathcal I_N(\alpha)=\int_N^{2N}e^{2\pi i\alpha y}\,dy.
\]
note 209 的非共振边界包含精确子项
\[
 \boxed{
 \mathcal B_{N}^{(q=1)}
 =\sum_{\substack{2\le d,e\le N\\(d,e)=1}}
 \lambda_{d,N}\lambda_{e,N}
 C_{d,e}(1)\,\mathcal I_N\!\left(\frac1{de}\right),}
 \tag{3}
\]
另有 \(q=-1\) 的共轭项及 one-boundary 项。对 \(de\gg N\)，
\[
 \mathcal I_N\!\left(\frac1{de}\right)
 =N e^{2\pi i N/(de)}
 \bigl(1+O(N/(de))\bigr),
 \tag{4}
\]
故该层在宏观 \(d,e\asymp N\) 区间没有由积分本身产生的幂次衰减。

代入 (1)，最小未控对象是
\[
 \sum_{(d,e)=1}
 \mu(d)\mu(e)\left(1-\frac{\log d}{\log N}\right)
 \left(1-\frac{\log e}{\log N}\right)
 \left(\cot\frac{\pi r_0}d+\cot\frac{\pi s_0}e\right)
 e^{2\pi iN/(de)}.
 \tag{5}
\]
这不是固定加法移位相关；它同时含有 modular inverse、互素约束和
reciprocal phase。普通 Jordan、MRT 或逐项 large-sieve 估计不直接覆盖 (5)。

结论：\(q=1\) 已给出非共振门的显式 reciprocity 形态。若能对 (5) 获得
平方根级 signed 估计，便可推进 note 208/209 的边界门；当前尚无该估计，
本文不声称 RH。

