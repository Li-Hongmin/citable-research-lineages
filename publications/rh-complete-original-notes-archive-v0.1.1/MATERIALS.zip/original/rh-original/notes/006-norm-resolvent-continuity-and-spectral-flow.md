> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定区间上的 norm-resolvent 连续性、全谱连续性与 spectral flow

日期：2026-08-11。本文把 Suzuki 对最低本征值的连续性提升到完整离散谱，并建立尺度族的
gap/norm-resolvent 连续自伴 Fredholm 实现。结合 note 003 的全谱单调性，尺度 crossing 现在具有
严格的整数 spectral-flow 解释。

## 1. 固定 Hilbert 空间与公共 form domain

令

\[
(U_av)(x):=a^{1/2}v(ax),\qquad
U_a:L^2(-a,a)\longrightarrow L^2(-1,1)
\]

为酉缩放，并定义

\[
\widetilde A_a:=U_aA_aU_a^{-1},\qquad
\widetilde q_a(w):=Q_W^a(U_a^{-1}w).
\]

note 004 已证明

\[
D(Q_W^a)=H((-a,a)).
\]

缩放后，这给出与 \(a\) 无关的公共定义域

\[
\boxed{D(\widetilde q_a)=\mathcal D:=H((-1,1))\qquad(a>0).}
\]

取固定的正形式范数

\[
\lVert w\rVert_{\mathcal D}^2
:=\mathcal L(w)+c\lVert w\rVert_2^2,
\]

其中 \(c\) 足够大，\(\mathcal L\) 是 Suzuki 公式 (4.4) 的固定 Archimedean 形式。Suzuki 的
Proposition 4.1 与 note 004 的定义域识别给出紧嵌入

\[
j:\mathcal D\hookrightarrow L^2(-1,1).
\]

## 2. 缩放形式的显式分解

把函数在 \((-1,1)\) 外延为零，并记

\[
(S_h w)(x):=\mathbf 1_{(-1,1)}(x)w(x+h),\qquad h\in\mathbb R.
\]

Suzuki 的公式 (4.5) 经酉归一化后可写成

\[
\begin{aligned}
\widetilde q_a(w,w)
={}&\mathcal L(w,w)-\bigl(\log a+2A+1\bigr)\lVert w\rVert_2^2\\
&-\sum_{n\le e^{2a}}\frac{\Lambda(n)}{\sqrt n}
\left\langle (S_{\log n/a}+S_{-\log n/a})w,w\right\rangle\\
&-a\int_{-1}^1\int_{-1}^1
r''\bigl(a(x-y)\bigr)w(y)\overline{w(x)}\,dx\,dy.
\end{aligned}
\]

在 \(a_0\) 的一个紧邻域 \(I\Subset(0,\infty)\) 内，可把 prime sum 写成一个固定有限和：
只取 \(n\le e^{2\max I}\)，并约定 \(|h|\ge2\) 时 \(S_h=0\)。这样 prime-power 阈值只是
\(S_{\log n/a}\) 的支撑从零测交叠连续开启，不需要改变求和指标集。

## 3. 平移项在 form norm 下连续

\(h\mapsto S_h\) 在 \(L^2(-1,1)\) 上强连续，且其伴随

\[
S_h^*=S_{-h}
\]

也强连续。它不按 \(L^2\) 算子范数连续，但这不是闭形式所需的拓扑。

由于 \(j:\mathcal D\to L^2\) 紧，\(\mathcal D\) 单位球的像在 \(L^2\) 中相对紧。强连续且一致有界的
算子族在紧集上一致连续，因此

\[
\lVert(S_h-S_{h_0})j\rVert_{\mathcal D\to L^2}\longrightarrow0
\qquad(h\to h_0).
\]

从而

\[
\sup_{\lVert u\rVert_{\mathcal D},\lVert v\rVert_{\mathcal D}\le1}
\left|\left\langle(S_h-S_{h_0})u,v\right\rangle_{L^2}\right|
\longrightarrow0.
\]

这正是 prime-shift 双线性形式在
\(\mathcal B(\mathcal D,\mathcal D^*)\) 中的范数连续性，包括 \(|h|=2\) 的开启阈值。

## 4. 其余项的连续性

- \(a\mapsto-\log a\,\lVert w\rVert_2^2\) 显然按有界形式范数连续；
- 在 \(a\in I\) 上，核
  \[
  k_a(x,y):=a\,r''(a(x-y))
  \]
  由 \(r''\) 的连续性在 \([-2\max I,2\max I]\) 上一致连续，并在
  \(L^2((-1,1)^2)\) 中连续。因此相应积分算子按 Hilbert--Schmidt 范数连续。

于是

\[
\boxed{
\lVert\widetilde q_a-\widetilde q_{a_0}\rVert_
{\mathcal B(\mathcal D,\mathcal D^*)}\longrightarrow0
\qquad(a\to a_0).}
\]

在每个紧尺度区间上，这些形式还具有一致下界。

## 5. norm-resolvent 连续性

在固定紧尺度区间上取 \(c>0\)，使

\[
\widetilde q_a+c\langle\cdot,\cdot\rangle
\]

一致 coercive。由表示定理或 Lax--Milgram，\((\widetilde A_a+c)^{-1}\) 是从 \(L^2\) 经
\(\mathcal D^*\) 到 \(\mathcal D\) 再嵌回 \(L^2\) 的解算子。上一节的形式算子范数连续性和逆算子恒等式
给出

\[
\boxed{
\left\|(\widetilde A_a+c)^{-1}
-(\widetilde A_{a_0}+c)^{-1}\right\|_{\mathcal B(L^2)}
\longrightarrow0.}
\]

因此 \(a\mapsto\widetilde A_a\) 是 norm-resolvent 连续的自伴算子族；等价地，它在自伴算子的
gap topology 中连续。每个 \(\widetilde A_a\) 具有紧预解式，故也是自伴 Fredholm 算子。

## 6. 全部本征值都连续

记按重数排列的本征值为

\[
\lambda_1(a)\le\lambda_2(a)\le\cdots\to+\infty.
\]

在局部一致下界平移后，紧自伴预解式的本征值为

\[
\bigl(\lambda_k(a)+c\bigr)^{-1}.
\]

紧自伴算子的本征值对算子范数扰动连续，因此对每个固定 \(k\ge1\)，

\[
\boxed{a\longmapsto\lambda_k(a)\quad\text{在 }(0,\infty)\text{ 上连续}.}
\]

结合 note 003，

\[
\boxed{\lambda_k(a)\ \text{对每个 }k\text{ 都连续且单调不增}.}
\]

所以负指标不能通过本征值跳跃增加；每次增加必经过真实的零本征空间。prime-power 阈值处也没有
谱跳跃，但仍不能据此断言经典导数或 crossing form 存在。

## 7. 严格的 spectral-flow 结论

由于 \(\widetilde A_a\) 是固定 Hilbert 空间上的 gap-continuous 自伴 Fredholm 路径，任意紧尺度区间
\([a_0,a_1]\) 上的 spectral flow 已有标准定义。若两个端点都可逆，并采用“负到正 crossing 计为
正”的约定，则全谱向下单调给出

\[
\boxed{
\operatorname{sf}\bigl(\widetilde A_a;\ a\in[a_0,a_1]\bigr)
=N_-(a_0)-N_-(a_1)\le0.}
\]

因此 spectral flow 不再只是候选框架：它已等同于尺度区间两端负 Morse 指标之差。若 RH 为假，
从一个小尺度正定端点走到任一已有负谱的可逆端点，spectral flow 为严格负整数。

当前仍未得到单个 crossing 的横截性。若某条本征值在零处形成平台，spectral flow 只记录平台前后
净负指标变化；要得到局部 crossing form，仍需更强的尺度可微性。

## 8. 来源与新结论边界

直接输入为：

- Masatoshi Suzuki, *Weil's quadratic form via the screw function*,
  [arXiv:2606.09096](https://arxiv.org/abs/2606.09096)，公式 (4.4)、(4.5)、Proposition 4.1 与
  Theorem 1.3；
- note 004 的 \(D(Q_W^a)=H((-a,a))\) 定义域识别；
- 闭形式表示、紧自伴算子 min--max 与 norm-resolvent 连续性的标准泛函分析。

Suzuki 原文只显式证明 \(\lambda_1(a)\) 连续。公共 form domain、夹紧平移的形式范数连续、全部
\(\lambda_k\) 连续和 spectral-flow 公式是本项目的新推论。
