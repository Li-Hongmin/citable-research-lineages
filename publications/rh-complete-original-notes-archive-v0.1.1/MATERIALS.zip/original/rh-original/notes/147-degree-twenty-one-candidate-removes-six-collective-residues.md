> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 次数二十一候选：六个 collective residues 的下一层

日期：2026-08-15。

这是 note 146 之后的精确候选层。正性证书以整数 cutoff N=floor(y) 的
falling-factorial 系数给出；完整整数表由
`computations/verify_degree21_candidate.py` 逐项有理复核。

令

\[
V_{21}(u)=\frac{u^2(1-u)^{13}}{11264}
\bigl(11264u^6+7865u^5+1893u^4-130u^3-178u^2-39u-3\bigr).
\tag{1}
\]

精确展开给出

\[
\int_0^1V_{21}=0,
\qquad v_1=v_3=v_5=v_7=v_9=v_{11}=0,
\tag{2}
\]

及

\[
K_{21}(s)=
\frac{11427998400(s-1)}{(s+2)(s+4)(s+6)(s+8)(s+10)(s+12)
(s+13)(s+14)(s+15)(s+16)(s+17)(s+18)(s+19)(s+20)(s+21)}.
\tag{3}
\]

分母表示显示线性因子的乘积，故临界带无额外零点。

## 1. 固定 floor cutoff 的 Bernstein 结构

写 y=N+r，N=floor(y)>=1，0<=r<1。直接有限求和给出

\[
P_{21}(N+r)=\frac{N(N+1)}{(N+r)^{21}}Q_N(r).
\tag{4}
\]

其中 Q_N 为十九次多项式，且

\[
Q_N(r)=\sum_{k=0}^{19}b_k(N)\binom{19}{k}r^k(1-r)^{19-k}.
\tag{5}
\]

当 N=1 时，b0=...=b12=0，而

\[
(b_{13},\ldots,b_{19})=
\left(\frac1{29568},\frac{13}{25344},\frac{35}{8448},
\frac{133}{5632},\frac{3589}{33792},\frac{8997}{22528},\frac{1329}{1024}\right)>0.
\tag{6}
\]

当 N>=2，令 t=N-2。将每个 b_k(t+2) 写成

\[
b_k(t+2)=D_k^{-1}\sum_{j=0}^{5}d_{k,j}t^{\underline j}.
\tag{7}
\]

所有 D_k>0 且 d_{k,j}>0。脚本输出的完整整数表逐项断言这些符号，因此
对每个整数 N>=2，所有 Bernstein 系数严格为正。注意 t 只取非负整数，
不能把定义域错误地扩大为连续实数 t>=0。

## 2. RH-strength 门

若将表格证书纳入正式 note，则 V21 将给出

\[
T_{21}(x)=-U_{21}(x)+O(x^{-1/2}),
\qquad
\mathrm{RH}\iff T_{21}(x)\ll_\varepsilon x^{1/2+\varepsilon}.
\tag{8}
\]

首批非零 collective 项为

\[
\frac{4199}{132}\frac{S_{13}^2}{x^{13}}
-\frac{68723}{165}\frac{S_{15}^2}{x^{15}}
+\frac{745739}{462}\frac{S_{17}^2}{x^{17}}
-\frac{3317609}{1815}\frac{S_{19}^2}{x^{19}},
\tag{9}
\]

另有均值为零的周期 remainder。和前几层一样，这只是把 signed Möbius 门再
向后推一层，不是 RH 的证明。
