> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定偏移的长移位尾项族都包含同一个 RH 等价门

日期：2026-08-16。

沿用 note 311 的
\[
B_U(X)=\sum_{a=U+1}^{2U-1}
       \sum_{b=X-2U+a+1}^{X-1}\lambda(ab).
\]
令 \(q\ge0\) 为固定整数，并取 \(X=2U+q\)。由于 \(\lambda(ab)=\lambda(a)\lambda(b)\)，令
\[
I_{U,q}=\{U+1,\ldots,2U+q-1\},
\qquad N_{U,q}=|I_{U,q}|=U+q-1,
\]
以及
\[
S_{U,q}=\sum_{n\in I_{U,q}}\lambda(n).
\]
原来的区域恰好是 \(I_{U,q}\) 中满足 \(b-a\ge q+1\) 的有序对。因此
\[
B_U(2U+q)
=\sum_{\substack{a<b\\a,b\in I_{U,q}\\b-a\ge q+1}}
  \lambda(a)\lambda(b).
\tag{1}
\]
把所有无序非对角对按距离 \(d=b-a\) 分层，得到完全精确的恒等式
\[
\boxed{
B_U(2U+q)
=\frac{S_{U,q}^2-N_{U,q}}{2}
-\sum_{d=1}^{q}
  \sum_{\substack{a,a+d\in I_{U,q}}}
  \lambda(a)\lambda(a+d).
}
\tag{2}
\]
当 \(q=1\) 时，这正好退化为 note 312 的式 (2)。

## 固定 \(q\) 的 RH 等价性

每个内层相关和的绝对值至多为 \(N_{U,q}\)，故固定 \(q\) 时
\[
\left|B_U(2U+q)\right|\ll_\varepsilon U^{1+\varepsilon}
\quad\Longrightarrow\quad
|S_{U,q}|\ll_\varepsilon U^{1/2+\varepsilon}.
\tag{3}
\]
由于 \(I_{U,q}\) 与 \((U,2U]\) 只相差固定数目的端点，(3) 给出
\[
\sum_{U<n\le2U}\lambda(n)\ll_\varepsilon U^{1/2+\varepsilon}.
\]
对 \(U=\lfloor x/2\rfloor\) 递归分解，得到
\[
\sum_{n\le x}\lambda(n)\ll_\varepsilon x^{1/2+\varepsilon}.
\tag{4}
\]
而
\[
\sum_{n\ge1}\frac{\lambda(n)}{n^s}
=\frac{\zeta(2s)}{\zeta(s)}
\]
与 (4) 的 Abel 延拓说明：若 \(\zeta(\rho)=0\) 且 \(\Re\rho>1/2\)，则右侧在 \(\rho\) 有极点，因为 \(\zeta(2\rho)\ne0\)，矛盾。因此固定 \(q\) 的统一尾项界蕴含 RH。

反向地，RH 下的标准 Liouville 平方根界给出
\(S_{U,q}=O_\varepsilon(U^{1/2+\varepsilon})\)，而每个被扣除的相关和至多 \(O(U)\)。由 (2) 得
\[
B_U(2U+q)\ll_{q,\varepsilon}U^{1+\varepsilon}.
\tag{5}
\]
所以对每一个固定 \(q\ge0\)，
\[
\boxed{
\ |B_U(2U+q)|\ll_{q,\varepsilon}U^{1+\varepsilon}
\ \text{对所有 }U
\quad\Longleftrightarrow\quad \mathrm{RH}.
}
\]

这说明 note 310--312 的 RH 等价边界不是单点现象：任何固定偏移的长移位尾项族都保留同一 dyadic Liouville 平方根门。要避免该门，必须利用 \(q\) 随 \(U\) 增长的真正跨尺度 signed cancellation；固定偏移的局部估计不能绕过 RH。
