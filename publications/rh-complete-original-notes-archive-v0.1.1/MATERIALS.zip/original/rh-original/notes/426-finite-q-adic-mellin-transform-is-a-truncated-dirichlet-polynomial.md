> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 426. 有限 q-进制尾的 Mellin 变换仍是截断 Dirichlet 多项式

## 精确恒等式

令
$$
B_X(y)=\sum_{\lceil y\rceil\le n\le X}\frac{\mu(n)}n,
\qquad
T_{P,X}(k)=\sum_j c_jq^{-j}B_X(k/q^j),
$$
其中 $P(z)=\sum_jc_jz^j$。对 $\Re z>0$ 定义有限离散 Mellin 变换
$$
\mathcal F_{P,X}(z)=\sum_{k\ge1}T_{P,X}(k)
\bigl(k^{-z}-(k-1)^{-z}\bigr).
$$
有限交换和 telescoping 给出
$$
\boxed{
\mathcal F_{P,X}(z)=
P\bigl(q^{-(z+1)}\bigr)\sum_{n\le X}\mu(n)n^{-(z+1)}.
}
\tag{1}
$$
这里求和实际上在 $k\le q^JX$ 处终止，因此 (1) 不涉及任何极限交换。

## 与无限尾的区别

令 $s=z+1$。无限尾时，PNT/Dirichlet 级数才给出
$$
P(q^{-s})/\zeta(s).
$$
有限尾的右侧却是
$$
P(q^{-s})D_X(s),
\qquad D_X(s)=\sum_{n\le X}\mu(n)n^{-s}.
$$
所以一个有限能量界首先只提供对截断 Dirichlet 多项式的控制；它不自动给出
$D_X(s)\to1/\zeta(s)$ 在 $\Re s>1/2$ 的局部一致收敛。

## 零模滤波器的内部精确抵消

上述区别并不意味着固定零模滤波器没有 RH 接口。若 $P(q^{-1})=0$，则对
$k\le X$，有限尾和无限尾的差为
$$
-P(q^{-1})R_X=0.
$$
故有限能量直接控制无限尾的前 $X$ 项；若该界对所有 $X$ 且滤波器 $P$ 固定，
note 420 的 Mellin 延拓即可使用。moving-kink 缺口只对 $k>X$ 的边界项存在，
而不妨碍固定滤波器提取内部无限尾能量。

## 对 q-进制能量路线的裁决

notes 422--425 的有限链恒等式与 Cauchy 下界仍然正确，但要把有限能量升级为
RH，至少需要下列之一：

1. 对有限尾到无限尾的 moving-kink 边界给出保持 $Y^{1+\varepsilon}$ 量级的统一转移；或
2. 直接证明 $D_X(s)$ 在 $\Re s>1/2$ 的统一解析延拓/收敛，且滤波多项式的零点不遮蔽该区域。

因此，固定滤波器的最薄接口已经是精确的内部抵消；真正未解决的是
$P=P_X$ 随 $X$ 变化时的一族截断 Dirichlet 多项式，如何统一转成同一个
$1/\zeta$ 的临界带延拓。此处不能把固定滤波器结论直接外推到增长阶族。
