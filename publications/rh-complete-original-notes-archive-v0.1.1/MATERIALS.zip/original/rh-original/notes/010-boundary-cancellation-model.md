> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 最优边界上界不足以排除平台：一个能量域内的振荡抵消模型

日期：2026-08-11。note 009 把谱底平台压缩为端点 Cauchy--Dini 抵消。本文件完成该条件的最便宜
判别：构造一个连续、属于 logarithmic 能量域、达到 \(\ell(d)^{1/2}\) 振幅且外侧 Stieltjes
变换一致有界的显式变号函数。这证明 M2-R1 的边界上界本身不能排除平台；后续必须使用 Weil
方程的特殊结构。

## 1. 模型

固定右端点 \(a\)，令 \(s=a-x\)。取光滑 cutoff \(\chi\in C_c^\infty([0,e^{-2}))\)，使
\(\chi=1\) 于 \([0,e^{-3}]\)。定义

\[
u(a-s)=
\begin{cases}
\displaystyle
\chi(s)\frac{\sin(\log(1/s))}{\sqrt{\log(1/s)}},&s>0,\\[1ex]
0,&s=0,
\end{cases}
\]

并在远离右端点处光滑截断。则 \(u\) 连续，且

\[
|u(a-s)|\le \ell(s)^{1/2}
\]

对充分小的 \(s\) 成立。另一方面，在

\[
s_k=\exp\!\left(-\frac\pi2-2\pi k\right),
\qquad
s'_k=\exp\!\left(-\frac{3\pi}2-2\pi k\right)
\]

上分别有

\[
\frac{u(a-s_k)}{\ell(s_k)^{1/2}}=1,
\qquad
\frac{u(a-s'_k)}{\ell(s'_k)^{1/2}}=-1.
\]

所以它不是严格更快的边界消失；它以最优振幅无限次换号，且 signed 边界系数不存在。

## 2. 外侧 Stieltjes 变换仍一致有界

考虑 note 009 中控制外侧 \(L_\Delta\) 的局部积分

\[
I(t)=\int_0^\delta\frac{u(a-s)}{t+s}\,ds.
\]

令 \(T=\log(1/t)\)、\(r=\log(1/s)\)，得到

\[
I(t)=\int_{\log(1/\delta)}^\infty
\chi(e^{-r})\frac{r^{-1/2}\sin r}{1+e^{r-T}}\,dr.
\]

对每个 \(T\)，振幅

\[
a_T(r)=\chi(e^{-r})\frac{r^{-1/2}}{1+e^{r-T}}
\]

除固定 cutoff 过渡区外单调不增；其上确界和总变差可由与 \(T\) 无关的常数控制。对
\(\sin r\) 使用 Dirichlet 判别或分部积分，得到

\[
\boxed{\sup_{0<t<\delta}|I(t)|<\infty.}
\]

事实上，当 \(t\downarrow0\) 时，\(I(t)\) 收敛到条件收敛积分

\[
\int_{\log(1/\delta)}^\infty
\chi(e^{-r})r^{-1/2}\sin r\,dr.
\]

因此最优 \(\ell^{1/2}\) 振幅与有界外侧 logarithmic flux 可以同时成立；关键是 log 尺度上的
交替抵消。

## 3. 模型确实属于能量域

这个例子不是只在点态层面伪造的。对任意 \(0<\alpha<1/2\)，它属于一维
\(H^\alpha\)，因而属于 logarithmic 能量空间。

一个直接估计如下。把端点邻域分成

\[
I_k=(e^{-(k+1)},e^{-k}),\qquad k\ge k_0.
\]

在 \(I_k\) 上，模型的振幅和 Lipschitz 常数分别满足

\[
\lVert u\rVert_{L^\infty(I_k)}\le Ck^{-1/2},
\qquad
\lVert u'\rVert_{L^\infty(I_k)}\le Ce^kk^{-1/2}.
\]

同一块及相邻块对 \(H^\alpha\) Gagliardo 半范数的贡献由

\[
C\frac{e^{-(1-2\alpha)k}}{k}
\]

控制。对相隔至少一块的 \(I_k,I_j\)，用块间距离和振幅界求和，得到同阶上界。由于
\(1-2\alpha>0\)，这些贡献可和。因此 \(u\in H^\alpha\)。最后利用

\[
\log(1+|\xi|)\le C_\alpha(1+|\xi|^{2\alpha})
\]

可知 \(H^\alpha\) 连续嵌入 logarithmic 能量空间 \(H((-a,a))\)。

## 4. 路线判决

这个模型严格否定以下推理：

\[
u\in H((-a,a)),\quad
|u(a-s)|=O(\ell(s)^{1/2})
\quad\Longrightarrow\quad
\text{外侧 }L_\Delta u\text{ 必然发散}.
\]

正确结论是：只有非零 signed 系数、最终固定符号的同阶下界，或其他排除 log-scale 抵消的结构，
才能由 note 009 推出发散。

因此 M2-R 的下一步不再尝试从 M2-R1 上界单独抽取 Hopf 下界。值得继续的只剩两种
equation-specific 机制：

1. 利用完整 Weil 本征方程证明此类无限 log-scale 振荡不可能；
2. 直接证明 note 008 的局部平移核族在相关基态类上具有零湮灭子。

## 5. 结论边界

该模型不是 Weil 本征函数，也没有构造谱底平台。它只证明“能量域 + 最优边界上界 + 有界外侧
Stieltjes 变换”三者相容，从而关闭一条仅靠正则性自动得到边界非退化的路线。模型、能量估计和
一致有界的 Stieltjes 变换是本项目的新构造。
