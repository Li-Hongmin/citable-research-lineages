> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 425. 更正：有限 q-进制能量下界尚不能推出 RH

## 1. 保留的精确事实

notes 422--424 使用的有限链恒等式是正确的。若
$$
A_X=\sum_{n\le X}\frac{\mu(n)}n
$$
且 $T_{r,q,X}$ 是相应的有限 reciprocal 尾，则
$$
A_X=(-1)^r\sum_{j=1}^{J+r-1}
\binom{j}{r-1}T_{r,q,X}(q^j)
$$
以及
$$
|A_X|^2\le C_{r,q}E_{r,q,X}
$$
都成立。对增长阶 $r=o(\log X)$，note 424 给出的
$C_{r,q}=X^{o(1)}$ 上界也成立。

## 2. 必须撤回的推论

若只假设
$$
E_{r,q,X}\ll (q^rX)^{1+\varepsilon},
$$
上述不等式至多给出
$$
|A_X|\ll X^{1/2+\varepsilon+o(1)}.
$$
这不是 RH 所需的
$A_X\ll X^{-1/2+\varepsilon}$。因此不能由此再用 Abel 变换推出
$M(X)\ll X^{1/2+\varepsilon}$；notes 422、423、424 中把该有限能量界称为
“RH-strength”或“严格推出 RH”的句子均不成立，现予撤回。

这不是记号问题：$A_X$ 是 reciprocal Möbius 和，而不是
$M(X)=\sum_{n\le X}\mu(n)$ 或 $\sum_{n\le X}n\mu(n)$。

## 3. 固定滤波器的正确 RH 接口

设 $P(q^{-1})=0$，并令 $B_\infty(y)=\sum_{n\ge\lceil y\rceil}\mu(n)/n$。
对 $k\le X$，有限尾与无限尾之差是同一个常数 $R_X$，所以
$$
T_{P,X}(k)-T_P(k)=-R_X\sum_jc_jq^{-j}
=-R_XP(q^{-1})=0.
$$
因此
$$
\sum_{k\le X}k|T_P(k)|^2
\le \sum_{k\le q^JX}k|T_{P,X}(k)|^2.
$$
若固定 $P$ 的右端对所有 $X$ 满足 $\ll X^{1+\varepsilon}$，则无限尾的部分能量
满足同样的界。此时 note 420 的 Mellin 论证可以使用：只要
$P(q^{-s})$ 不在临界带 $1/2<\Re s<1$ 的 ζ 零点处消失，就能排除右侧零点。
对于 $P_r(z)=(1-qz)^r$，其零点满足 $\Re s=1$；结合 ζ 在 $\Re s=1$ 的零点自由，
固定 $q,r$ 的有限能量界确实推出 RH。

这条证明不使用第 2 节中不足以产生平方根的 Cauchy--Abel 推理。

## 4. 增长阶仍未关闭

对于无限尾 $T_P$，note 420 的 Mellin 论证仍然有效：若
$$
\sum_{k\le Y}k|T_P(k)|^2\ll Y^{1+\varepsilon}
$$
且 $P(q^{-s})$ 在 $\Re s>1/2$ 无零点，则 Mellin 变换延拓到
$\Re s>1/2$，从而排除 ζ 的右侧零点。

对一般的 $P$，有限截断尾 $T_{P,X}$ 要使用同一结论，确实还必须另证一个保持能量量级的
moving-kink 边界转移。可是对本节的零模滤波器 $P(q^{-1})=0$，不需要支付这项边界：
对每个 $k\le X$，有限尾与无限尾逐项相等，因而有限能量的前半段已经直接控制无限尾的部分能量。
只有当 $P$ 不满足该零模条件，或阶数 $r=r(X)$ 随 $X$ 变化时，才必须另外证明统一的边界转移或临界带延拓。
notes 421--424 没有给出后一种统一证明。

## 5. 当前裁决

q-进制链仍是一个正确的边界恒等式和有用的重构工具。固定滤波器的
有限到无限转移已经由内部常数抵消精确完成；未关闭的只剩阶数随 $X$ 变化时，
如何从一族不同的 $P_{r(X)}$ 提取统一的临界带 Mellin 延拓。不能再把
Cauchy 下界本身误读为 RH 证明。
