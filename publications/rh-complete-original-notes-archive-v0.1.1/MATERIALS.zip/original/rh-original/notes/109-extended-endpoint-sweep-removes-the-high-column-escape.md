> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 扩展 endpoint sweep 消除高列带逃逸并归约到 minimum modulus

日期：2026-08-14。

依赖：
[note 105](105-the-cell-detector-is-zero-free-to-the-imaginary-axis.md)、
[note 107](107-growing-scale-mellin-frame-fails-at-additive-nyquist-sampling.md)、
[note 108](108-growing-scale-observation-plus-path-energy-still-has-high-column-escape.md)。

证据等级：分布导数的精确分解、显式 endpoint sweep 下界，
以及剩余 minimum-modulus 门的严格归约。

note 108 的反例依赖行窗 \(Y<N\le2Y\) 遗留的高列盲区。
本文将同一尺度 \(Y\) 上的观测行窗扩大为

\[
Y<N\le3eY.
\tag{1}
\]

这不增加新核，只让最细尺度的下端跳跃轨道扫过原共同列域。
结果是：note 108 的宏观几何逃逸被严格消除；一般 uniform gap
仅剩 endpoint 主部与正则部的系统性相消问题。

## 1. 最细核的精确 endpoint--regular 分解

令

\[
a=\frac23,
\qquad
F(t)=\log\frac1t\left(\frac2{\pi t}+\sin2\pi t\right)
\mathbf1_{(a,1)}(t),
\tag{2}
\]

并转到对数坐标

\[
f(x)=F(e^x),\qquad \alpha=\log a.
\tag{3}
\]

\(f\) 在 \(\alpha\) 有唯一值跳跃

\[
\kappa=f(\alpha+)=F(a+)>0,
\tag{4}
\]

其余分布导数具有 BV 密度：

\[
Df=\kappa\delta_\alpha+h(x)\,dx,
\qquad h\in BV_c(\mathbb R).
\tag{5}
\]

对 \(L>0\) 令

\[
b_L=L^{-1}\mathbf1_{[0,L]}.
\tag{6}
\]

log-dilation 平均就是 \(f*b_L\)，因此在分布意义下有精确恒等式

\[
\boxed{
\frac d{dx}(f*b_L)(x)
=\frac\kappa L\mathbf1_{[\alpha,\alpha+L]}(x)
+(h*b_L)(x).}
\tag{7}
\]

第一项是正 endpoint box；第二项的 BV 范数一致受控：

\[
\|h*b_L\|_{BV}\le\|h\|_{BV}.
\tag{8}
\]

因此最细离散 block 可精确写成

\[
\boxed{B_J=S_J+H_J,}
\tag{9}
\]

其中 \(S_J\) 是由 (7) 第一项生成的正局部平均，
\(H_J\) 由一致 BV 的正则项生成。

## 2. endpoint sweep 严格杀死 note 108 逃逸模

令

\[
J=\lceil\log_2Y\rceil,
\qquad
\frac1{2Y}\le L_J\le\frac1Y,
\tag{10}
\]

并沿用 note 108 的

\[
I_Y=[2.2Y,2.3Y]\cap\mathbb Z,
\qquad
\xi=Y^{1/2},
\qquad
v_Y(d)=(d/Y)^{i\xi}\mathbf1_{I_Y}(d).
\tag{11}
\]

记 \(d_-,d_+\) 为 \(I_Y\) 端点。考虑满足

\[
\frac{d_-+3}{a}\le N\le
\frac{d_+-3}{ae^{L_J}}
\tag{12}
\]

的整数行。这样的行有

\[
\left(\frac{2.3-2.2}{a}+o(1)\right)Y
=(0.15+o(1))Y
\tag{13}
\]

个，且

\[
3.3Y+O(1)\le N\le3.45Y+O(1)<3eY.
\tag{14}
\]

对每个这样的 \(N\)，transported endpoint box

\[
[aN,ae^{L_J}N]
\tag{15}
\]

连同一个 cell 余量都落入 \(I_Y\)。该行的 \(S_J\) 权重非负，
总质量为 \(\kappa\)，且只支撑在

\[
O(NL_J+1)=O(1)
\tag{16}
\]

个相邻整数上。又

\[
|v_Y(d+1)-v_Y(d)|\ll\frac\xi Y=Y^{-1/2},
\tag{17}
\]

所以对某个 \(d_N=aN+O(1)\)，

\[
(S_Jv_Y)_N=-\kappa v_Y(d_N)+O(Y^{-1/2}).
\tag{18}
\]

对正则项使用 (8) 与硬截断 Fourier--Stieltjes 估计，得

\[
|(H_Jv_Y)_N|
\ll\xi^{-1}+\frac\xi Y
\ll Y^{-1/2}.
\tag{19}
\]

因此，对充分大的 \(Y\)，

\[
|(B_Jv_Y)_N|
\ge\kappa-O(Y^{-1/2})
\ge\frac\kappa2
\tag{20}
\]

在 \(\gg Y\) 个扩展行上成立。结果是

\[
\boxed{
\|B_Jv_Y\|_{\ell^2(Y<N\le3eY)}^2
\gg Y
\asymp\|v_Y\|_2^2.}
\tag{21}
\]

为得到 mean-zero 向量，令 \(\mathcal D_Y\) 为 note 108 的列域，并置

\[
c_Y=|\mathcal D_Y|^{-1}\sum_{\mathcal D_Y}v_Y,
\qquad q_Y=v_Y-c_Y\mathbf1_{\mathcal D_Y}.
\tag{22}
\]

note 108 已给出 \(|c_Y|\ll Y^{-1/2}\) 和 \(\|q_Y\|_2^2\asymp Y\)。
在扩展行窗上，\(B_J\mathbf1_{\mathcal D_Y}\) 不必逐行为零，但其行值一致有界，故

\[
\|c_YB_J\mathbf1_{\mathcal D_Y}\|_2^2
\ll |c_Y|^2Y\ll1.
\tag{23}
\]

它不能消去 (21) 的 \(\gg Y\) 能量，所以

\[
\boxed{
\|B_Jq_Y\|_{\ell^2(Y<N\le3eY)}^2
\gg Y
\asymp\|q_Y\|_2^2.}
\tag{24}
\]

这里特别修正一个容易混淆的边界：扩展行窗后，
\(B_J\mathbf1_{\mathcal D_Y}\) 一般不再为零；但 (23) 已足以保持主下界。

## 3. 一般 coercivity 的最小剩余门

由 endpoint box 的正局部性和轨道覆盖，并允许一阶路径能量支付
\(O(1)\) cell 内的差异，主部 \(S_J\) 满足局部采样下界

\[
\|q\|_2^2
\lesssim
\|S_Jq\|_2^2+D(q)+\text{boundary term}.
\tag{25}
\]

实际上，每个内部列 \(d\) 都可选一个 \(N=3d/2+O(1)\) 使
endpoint box 落在 \(d\) 及其 \(O(1)\) 个相邻 cell 上。这些行均落入 (1)，
而 \(d\mapsto N\) 的重数有统一上下界。非负权的总质量为 \(\kappa\)，故

\[
|(S_Jq)_N+\kappa q(d)|^2
\lesssim
\sum_{|r-d|\le C}|q(r+1)-q(r)|^2.
\]

对选定的行求和，再用有界重叠，即得 (25)；只有列域两端
\(O(1)\) 个 cell 留入 boundary term。

从 (25) 到真实 block \(B_J=S_J+H_J\) 的唯一承重步是

\[
\boxed{
\|S_Jq\|_2^2
\stackrel{?}{\lesssim}
\|(S_J+H_J)q\|_2^2+D(q)+\text{boundary term}.}
\tag{26}
\]

这是一个 uniform minimum-modulus/Fredholm 命题。note 105 的虚轴零自由性说明
全线 Mellin 极限没有非零频精确核，但它本身不证明有限行窗与整数采样的
参数一致 minimum modulus。

路线边界因此是：

\[
\boxed{
\text{扩展 endpoint sweep 已消除宏观几何盲区；
剩余问题是主部--正则部相消，不是更多尺度。}}
\tag{27}
\]

(21)--(24) 只证明 note 108 的具体逃逸族被消除，不是 (26) 的一般证明。
