> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 乘法自相关是 Toeplitz 平方，不是 reciprocal-product Hankel 平方

日期：2026-08-15。

证据等级：精确 Mellin 恒等式、有限支撑插值、核几何首断点。

本文检查把测试函数替换成乘法自相关、从而让 Mellin 变换成为模平方的想法。结论是：
它给出严格的 Weil 自相关判据；但在 Möbius reciprocal-product 门上，它把 ab 型 Hankel
核改成 a/b 型 Toeplitz 核，不能在保持原算术对象的同时免费消除 signed obstruction。

## 1. 精确的乘法自相关 Mellin 平方

在乘法群 G=(0,∞) 上取 Haar 测度 dx/x。对 f∈C_c^∞(G)，令

    C_f(y) = ∫₀∞ f(yx) · overline(f(x)) dx/x.

单位 Mellin 变换为

    Mf(ξ) = ∫₀∞ f(x) x^(−iξ) dx/x.

令 u=yx，Fubini 直接给出

    M C_f(ξ) = Mf(ξ) · overline(Mf(ξ)) = |Mf(ξ)|² ≥ 0.       (1)

若以中心变量 q=s−1/2 表示，并记 Mellin 变换的解析延拓为 F(q)，反射为

    F#(q) = overline(F(−conj(q))),
    H(q)  = F(q) F#(q),

则临界线上 H(it)=|F(it)|²。这里的平方只来自自相关结构，并没有使用 RH。

## 2. Weil 配对中的 off-line 首断点

设显式公式的零点项写作 Σρ H(ρ−1/2)，并把函数方程配对写成 q↔−conj(q)。一对零点
的自相关贡献是

    H(q)+H(−conj(q)) = 2 Re( F(q) · overline(F(−conj(q))) ).       (2)

当 q=it 时，(2) 等于 2|F(it)|²；但若 Re(q)≠0，它不是模平方。两个不同点 q 与
−conj(q) 的 Mellin 取值可以由两个紧支撑 smooth bump 独立插值：取 f₁,f₂ 使 2×2
取值矩阵可逆，再令 F(q)=1、F(−conj(q))=−1，则该零点对贡献 −2。

因此自相关结构本身并不使 off-line 零点对正定：它仍给出任意符号的
2 Re［F(q)·overline{F(−conj(q))}］。若要把“所有自相关测试均非负”推出 RH，
还必须补上一个全局 Mellin 插值/分离引理，保证该局部负配对不会被其余零点与
archimedean 项抵消；这个引理正是通常 Weil 判据的实质，不由 (1) 自动提供。

## 3. 与 Möbius reciprocal-product 核的几何差异

原 reciprocal-product 门为

    T_P(x) = Σ_{a,b≤z} μ(a) μ(b) P(x/(ab)).                         (4)

令 u_a=log a，则矩阵 Kᴴ_ab=P(exp(log x−u_a−u_b)) 是加法 log 坐标上的 Hankel
核 k(u_a+u_b)。

乘法自相关只能产生差核。例如

    Tᴛ_P(x) = Σ_{a,b} c_a · overline(c_b) · P(xa/b),

在 t=log x 的 Fourier/Mellin 侧为

    P̂(ξ) · |Σ_a c_a a^(iξ)|².                                      (5)

若 P̂≥0，(5) 对任意系数由 Bochner/Parseval 自动非负，与 RH 无关。取
c_a=μ(a)a^(−σ) 只得到有限 Dirichlet 多项式的模平方；它没有恢复 (4) 的 A(s)²
Hankel 因子。

更直接地，自相关的 log 支撑是 u_a−u_b，而 (4) 的支撑是 u_a+u_b。把一个槽反射
成差核需要 −u_b=−log b 的倒数算术支撑；在有限正整数集上会引入额外 reciprocal 点，
不再等于原 Möbius 门。

## 4. 最薄不可能性判据

若对原 Kᴴ_ab=P(x/(ab)) 声称存在统一自相关 Gram 表示 Kᴴ_ab=⟨φ_a,φ_b⟩，则 Kᴴ
必须 PSD。但项目已有严格例子（V15，x=4）：

    det Kᴴ_{ {2,3} } = −(473/16384)² < 0,
    T₁₅(4) = −7600627/134217728 < 0.                              (6)

故任何保持该 detector 与 ab 采样的平方自相关/有限 Gram 化都不可能。若换 detector
强制 PSD，得到的只是 (5) 型平凡 Toeplitz 正性；要重新获得 RH 信息，仍必须证明它
控制 (4) 或 1/ζ(s) 的 off-line 评价，这正是 arithmetic intertwiner 缺口。

结论：乘法自相关是严格的 Weil 等价测试族和临界线模平方表示，但不能同时保留
reciprocal-product 的 ab-Hankel 算术结构并绕过其 signed/indefinite 障碍。
