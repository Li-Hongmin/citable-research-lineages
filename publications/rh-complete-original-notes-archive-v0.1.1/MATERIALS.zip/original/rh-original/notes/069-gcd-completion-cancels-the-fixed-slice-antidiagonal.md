> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# gcd completion 消去固定切片的反对角因子

日期与检索截止：2026-08-12。

依赖：[note 064](064-selberg-affine-first-shell-rh-criterion.md)、
[note 065](065-barban-vehov-hminus1-obstruction-and-weak-mertens-bridge.md)、
[note 067](067-balanced-physical-scaling-and-antidiagonal-mobius-zero.md)。

## 1. 弄清问题

note 067 对固定

\[
d=gb,\qquad e=ga,\qquad (a,b)=1
\tag{1}
\]

得到

\[
\sum_{\substack{(a,b)=1\\(ab,g)=1}}
\frac{\mu(a)\mu(b)}{a^sb^t}
=\prod_{p\nmid g}(1-p^{-s}-p^{-t})
=\frac{\mathcal A_g(s,t)}
{\zeta(s)\zeta(t)\zeta(s+t)}.
\tag{2}
\]

本轮唯一判别：

\[
\boxed{
\text{先固定 }g\text{ 所见的 }1/\zeta(s+t)
\text{ 是否仍存在于完整 }d,e\text{ 聚合？}
}
\tag{3}
\]

```mermaid
flowchart LR
  A["fixed gcd: states 1, −x, −y"] --> B["complete gcd: add +xy"]
  B --> C["1−x−y+xy"]
  C --> D["(1−x)(1−y)"]
  D --> E["1/(ζ(s)ζ(t))"]
  E --> F["one-variable Selberg–Möbius Gram"]
```

## 2. 拟定计划

\[
\begin{array}{c|c}
\text{原子}&\text{最便宜观测}\\
\hline
E_{d,e}&\text{直接缩放 }y=Nt\\
g,a,b&\text{列出每个素数的四种状态}\\
\lambda_d&\log(N/d)\text{ 吸收入物理核}\\
(d,e)^2/de&\text{检查是否也命中 }z=s+t\\
\beta(Nt/d)&\text{分成有限个 moving Mertens cells}
\end{array}
\tag{4}
\]

## 3. 实现计划

### 3.1 完整主积分块本来就是一个 Gram 平方

置

\[
L:=\log N,\qquad
\lambda_d:=\mu(d)\frac{\log(N/d)}L,
\tag{5}
\]

\[
\mathscr K(u,v):=
\int_1^2\beta(t/u)\beta(t/v)\,dt,
\qquad
\beta(x)=\{x\}-\frac12.
\tag{6}
\]

**定理 1（complete physical Gram）。** 对任意 \(d,e\le N\)，

\[
\boxed{
E_{d,e}(N)
=N\mathscr K(d/N,e/N)
-\frac{N(d,e)^2}{12de}.
}
\tag{7}
\]

若

\[
F_N(t):=\sum_{d\le N}\lambda_d\beta(Nt/d),
\tag{8}
\]

则

\[
\boxed{
\mathcal S_N
:=\sum_{d,e\le N}\lambda_d\lambda_eE_{d,e}(N)
=N\int_1^2|F_N(t)|^2dt-\frac N{12}Q_2(N),
}
\tag{9}
\]

\[
Q_2(N):=
\sum_{d,e\le N}\lambda_d\lambda_e\frac{(d,e)^2}{de}.
\tag{10}
\]

**证明。** 置 \(y=Nt\)：

\[
\int_N^{2N}\beta(y/d)\beta(y/e)\,dy
=N\mathscr K(d/N,e/N),
\tag{11}
\]

即得 (7)。有限双和与积分交换后，

\[
\sum_{d,e}\lambda_d\lambda_e
\mathscr K(d/N,e/N)
=
\int_1^2
\left(\sum_d\lambda_d\beta(Nt/d)\right)^2dt.
\tag{12}
\]

代入 (7) 得 (9)。\(\square\)

更完整地，note 065 的

\[
c_N:=1+\frac12\sum_{d\le N}\lambda_d
\tag{13}
\]

满足

\[
\boxed{
I_N
=N\int_1^2|c_N+F_N(t)|^2dt.
}
\tag{14}
\]

所以 complete boundary 的最终对象从未离开 note 064 的一维仿射首壳。

### 3.2 gcd completion 逐素数消去 \(1/\zeta(s+t)\)

在 \(\Re z,\Re s,\Re t>1\) 定义

\[
\mathfrak D(z;s,t):=
\sum_{g,a,b\ge1}
\frac{\mu^2(gab)\mu(a)\mu(b)}
{g^zb^sa^t}.
\tag{15}
\]

每个素数只有四种互斥状态：

\[
\begin{array}{c|c}
\text{状态}&\text{局部单项}\\
\hline
p\nmid gab&1\\
p\mid g&+p^{-z}\\
p\mid b&-p^{-s}\\
p\mid a&-p^{-t}
\end{array}
\tag{16}
\]

故

\[
\boxed{
\mathfrak D(z;s,t)
=\prod_p(1+p^{-z}-p^{-s}-p^{-t}).
}
\tag{17}
\]

物理核中的 Mellin 单项为

\[
\left(\frac{gb}{N}\right)^{-s}
\left(\frac{ga}{N}\right)^{-t}
=N^{s+t}g^{-(s+t)}b^{-s}a^{-t}.
\tag{18}
\]

因此不是任意三变量点，而是

\[
\boxed{z=s+t.}
\tag{19}
\]

令 \(x=p^{-s},y=p^{-t}\)。在 (19) 上，

\[
1+p^{-z}-p^{-s}-p^{-t}
=1+xy-x-y
=(1-x)(1-y).
\tag{20}
\]

于是

\[
\boxed{
\mathfrak D(s+t;s,t)
=\frac1{\zeta(s)\zeta(t)}.
}
\tag{21}
\]

固定 \(g\) 时，\(p\mid g\) 的 \(+xy\) 状态被冻结，局部因子才成为
\(1-x-y\)。完整 gcd 求和精确补回 \(+xy\)，故

\[
\boxed{
\text{fixed-}g\quad \frac1{\zeta(s+t)}
\quad\text{是条件化切片因子，不是 complete 主积分因子。}
}
\tag{22}
\]

### 3.3 taper 与 cutoff 不破坏分离

对固定物理块 \(I,J\Subset(0,1)\)，置

\[
W_{I,J}(u,v):=
\mathbf1_I(u)\mathbf1_J(v)
\log(1/u)\log(1/v)\mathscr K(u,v).
\tag{23}
\]

其主积分块为

\[
\boxed{
\mathcal I_{I,J}(N)
=\frac N{L^2}
\sum_{d,e\ge1}\mu(d)\mu(e)
W_{I,J}(d/N,e/N).
}
\tag{24}
\]

在任一平滑 cell 上，双 Mellin 反演给出

\[
\boxed{
\mathcal I_{I,J}(N)
=\frac N{L^2(2\pi i)^2}
\iint
\widehat W_{I,J}(s,t)
\frac{N^{s+t}}{\zeta(s)\zeta(t)}
\,ds\,dt.
}
\tag{25}
\]

硬块由有限 cell 分解或平滑逼近恢复。两个 taper 对数已进入 \(W_{I,J}\)；
support \(d,e\le N\) 已由 \(I,J\subset(0,1)\) 强制，均不产生新的交叉 Euler 因子。

也可在 gcd 坐标中核对。对基单项，

\[
(L+\partial_z+\partial_s)
g^{-z}b^{-s}a^{-t}
=\log(N/gb)g^{-z}b^{-s}a^{-t},
\tag{26}
\]

\[
(L+\partial_z+\partial_t)
g^{-z}b^{-s}a^{-t}
=\log(N/ga)g^{-z}b^{-s}a^{-t}.
\tag{27}
\]

\(\partial_s+\partial_z,\partial_t+\partial_z\) 正是曲面 \(z=s+t\) 的两个切向导数；
故 taper 后 (21) 仍分离为两个一变量 reciprocal-zeta 因子。

### 3.4 gcd 周期校正是例外，但已经低阶

\(Q_2\) 的共同素因子状态不位于 (19)。事实上

\[
\sum_{d,e\ge1}
\mu(d)\mu(e)\frac{(d,e)^2}{de}
d^{-w_1}e^{-w_2}
=
\prod_p
\left(
1+p^{-(w_1+w_2)}
-p^{-(w_1+1)}
-p^{-(w_2+1)}
\right).
\tag{28}
\]

这里共同状态的指数为 \(w_1+w_2\)，而两个独立变量之和为
\(w_1+w_2+2\)；故 (20) 不适用。

这不恢复新障碍。note 065 已证明

\[
\boxed{
Q_2(N)\ll\frac{N\log\log(3N)}L=o(N),
\qquad
\frac N{12}Q_2(N)=o(N^2).
}
\tag{29}
\]

后续 [note 078](078-full-fourier-packets-form-a-finite-ramanujan-antiderivative-frame.md)
把全部 reduced numerators 聚合后得到

\[
Q_2(N)=\sum_{q\le N}J_2(q)
\left|\frac{\mu(q)\check m_q(N/q)}{q\log N}\right|^2
\ll\frac{N}{\log^2N},
\tag{29a}
\]

故 (29) 的完整周期对角可加强为 \(O(N^2/\log^2N)\)。

对固定 \(I,J\Subset(0,1)\)，还有直接绝对界

\[
\boxed{
\frac N{12}|Q_{2;I,J}(N)|
\ll_{I,J}\frac{N^2}{L^2}.
}
\tag{30}
\]

证明只需写 \(d=gr,e=gs\)，去掉 \((r,s)=1\)，并用

\[
\sum_{r\asymp N/g}\frac1r\ll_{I,J}1,
\qquad
g\ll_{I,J}N.
\tag{31}
\]

### 3.5 complete high block 是有限个 moving Mertens cells

定义

\[
F_{I,N}(t):=
\frac1L
\sum_{\substack{d\le N\\d/N\in I}}
\mu(d)\log(N/d)\beta(Nt/d).
\tag{32}
\]

令 \(I=[\alpha,\eta]\Subset(0,1)\)。对几乎处处的 \(t\in[1,2]\)，

\[
\boxed{
\begin{aligned}
F_{I,N}(t)
=\frac1L\sum_n
\sum_{\substack{
d\in[\alpha N,\eta N]\\
tN/(n+1)<d\le tN/n
}}
\mu(d)\log(N/d)
\left(\frac{tN}{d}-n-\frac12\right),
\end{aligned}
}
\tag{33}
\]

其中

\[
\frac t\eta-1<n\le\frac t\alpha
\tag{34}
\]

只给出 \(O_I(1)\) 个整数。等价地，每个 cell 只是

\[
\frac1L
\left[
tN\sum_{A<d\le B}\frac{\mu(d)\log(N/d)}d
-\left(n+\frac12\right)
\sum_{A<d\le B}\mu(d)\log(N/d)
\right].
\tag{35}
\]

所以 complete balanced high block 没有剩余的 variable-product Kloosterman
模数；它严格退化为有限个移动端点的加权 Mertens 和。

## 4. 回顾反思

### 4.1 改变的数学判断

\[
\boxed{
\text{complete incomplete-lcm 主积分}
\equiv
\text{independent Möbius Gram}
\equiv
\text{one-variable weighted Mertens cells}.
}
\tag{36}
\]

note 067 的固定-\(g\) 公式仍正确；被关闭的是它作为完整主积分之必要机制的地位：

\[
\begin{array}{c|c}
\text{陈述}&\text{裁决}\\
\hline
E_{gb,ga}(N)=gE_{b,a}(N/g)&\text{保留}\\
\text{fixed-}g\ 1/\zeta(s+t)&\text{保留于切片}\\
\text{uniform fixed-}g\ (DM)&\text{过强充分条件}\\
\text{anti-diagonal AP0}&\text{非 complete 必要条件}\\
\text{complete Euler factor}&1/(\zeta(s)\zeta(t))\\
\text{complete high block}&\text{有限 moving Mertens cells}
\end{array}
\tag{37}
\]

### 4.2 历史文献到达边界

2026-08-12 的定向检索以
Selberg sieve weights + shifted correlations + Barban--Vehov + weighted Mertens mean square
为边界。Walker 的 shifted Selberg-weight correlations 依赖
Bettin--Chandee 且不覆盖 endpoint triangular \(H^{-1}\) 聚合；
Ramaré--Zuniga-Alterman 2024 控制的是 \(H^0\) 二次均值。

Menon 2026 的 Theorem 1.1 是当前 Matomäki--Radziwiłł 方法对 Liouville/
Möbius short averages 的强化。令 \(X\ge h\ge10\)，其 Möbius 版本给出

\[
\frac1X\int_X^{2X}
\left|\frac1h\sum_{x<n\le x+h}\mu(n)\right|^2dx
\ll
\frac{(\log\log h)^2}{(\log h)^2}
+\frac{(\log\log X)^4}{(\log X)^2}.
\tag{MR}
\]

当 \(h\asymp X\asymp N\) 时，右端为
\(O((\log\log N)^4/L^2)\)。即使乐观地把固定-\(h\) 估计无损转移到
(33) 的有限 moving-endpoint family，再支付 Selberg taper 的 \(L^{-2}\)，也至多得到

\[
\int_1^2|F_{I,N}(t)|^2dt
\ll_I \frac{N^2(\log\log N)^4}{L^4},
\qquad
\frac{N^2(\log\log N)^4/L^4}{N}
\longrightarrow\infty.
\tag{Gap}
\]

故该方法的最新对数改进仍未到达 (MI) 的平方根均方尺度；差距不是 moving endpoint
技术细节，而是整整一个 \(N\) 次幂（仅附对数修正）。

原始入口：
[Walker](https://arxiv.org/abs/2101.04418)、
[Ramaré--Zuniga-Alterman](https://arxiv.org/abs/2405.12662)、
[Báez-Duarte](https://arxiv.org/abs/math/0202141)、
[Bettin--Conrey--Farmer](https://arxiv.org/abs/1211.5191)、
[Menon](https://arxiv.org/abs/2607.15574)。

### 4.3 下一最简单元

记

\[
\mathcal S_{I,J}(N):=
\sum_{\substack{d/N\in I\\e/N\in J}}
\lambda_d\lambda_eE_{d,e}(N).
\tag{38a}
\]

对固定 high block \(I\)，由 (30)，

\[
\boxed{
\mathcal S_{I,I}(N)
=N\int_1^2|F_{I,N}(t)|^2dt
+O_I(N^2/L^2).
}
\tag{38}
\]

故自然临界命题为

\[
\boxed{
\int_1^2|F_{I,N}(t)|^2dt=o(N).
}
\tag{MI}
\]

(33)--(35) 表明 (MI) 不是新的 Kloosterman 问题，而是有限 moving-window
Mertens/Riesz 和的联合平方根均值。note 064 已证明任何离线零
\(\beta>1/2\) 都会强制相应首壳子列放大；note 065 的弱 Mertens 均值足以推出目标，
但本身已蕴含 RH。

因此下一次进攻只能改变一个判断：历史上的 moving-interval Möbius mean-square
技术能否利用 (35) 中两个 Riesz 和的**联合系数**，得到比单独弱 Mertens 更弱的输入。
若不能，(MI) 只是 RH 级判据而非证明。

本 note 没有证明 (MI) 或 RH。
