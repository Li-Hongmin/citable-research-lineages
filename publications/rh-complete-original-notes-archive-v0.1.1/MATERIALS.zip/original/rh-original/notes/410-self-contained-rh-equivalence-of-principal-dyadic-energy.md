> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 410. 主部 dyadic 能量的自包含 RH 等价性

本 note 把 note 409 的望远镜恒等式与 Mellin 延拓拼成一个完整的等价定理。

## 定理

令

$$
U(x):=M_1(x)=\sum_{n\le x}n\mu(n),
\qquad D(n):=U(n)-U(\lfloor n/2\rfloor).
$$

则以下两条命题等价：

1. RH 成立；
2. 对每个 $\varepsilon>0$，note 407 的主部满足

$$
Q_w(\mu_{\le Y})\ll_\varepsilon Y^{1+\varepsilon}
\qquad(Y\ge2).
\tag{1}
$$

更精确地，下面的 dyadic 差能量界本身也等价于 RH：

$$
\sum_{n\le Y}\frac{|D(n)|^2}{n^3}
\ll_\varepsilon Y^{1+\varepsilon}.
\tag{2}
$$

## 1. $Q_w$ 与 dyadic 差能量

由 note 409，存在绝对常数 $c_1,c_2>0$，使得

$$
c_1\sum_{n\le Y}\frac{|D(n)|^2}{n^3}
\le Q_w(\mu_{\le Y})
\le c_2\sum_{n<2Y}\frac{|D_Y(n)|^2}{n^3},
\tag{3}
$$

其中

$$
D_Y(n)=
\begin{cases}
U(n)-U(\lfloor n/2\rfloor),&n\le Y,\\
U(Y)-U(\lfloor n/2\rfloor),&Y<n<2Y.
\end{cases}
$$

上界中的第二段是 moving-cutoff 端点。因而主部的平方根级估计首先给出 (2)。下文证明 (2) 蕴含 RH，而 RH 又由第 4 节给出 (1)；所以二者最终等价，但不把端点段误当作 (2) 的直接逐项控制。

下面只证明 (1) 蕴含 RH；RH 蕴含 (1) 是标准的 Abel 估计，最后一节给出细节。

## 2. 从 (1) 到 $U$ 的加权均方界

设

$$
A(Y):=\sum_{n\le Y}\frac{|U(n)|^2}{n^3},
\qquad
B(Y):=\sum_{n\le Y}\frac{|D(n)|^2}{n^3}.
$$

由 $U(n)=D(n)+U(\lfloor n/2\rfloor)$ 及 $|x+y|^2\le2|x|^2+2|y|^2$，

$$
A(Y)\le2B(Y)+2\sum_{n\le Y}
\frac{|U(\lfloor n/2\rfloor)|^2}{n^3}.
$$

把 $n=2m,2m+1$ 配对，得到

$$
\sum_{n\le Y}\frac{|U(\lfloor n/2\rfloor)|^2}{n^3}
\le\frac14 A(\lceil Y/2\rceil).
$$

故

$$
A(Y)\le2B(Y)+\frac12A(\lceil Y/2\rceil).
\tag{4}
$$

若 (1) 成立，由 (3) 得 $B(Y)\ll_\varepsilon Y^{1+\varepsilon}$。迭代 (4) 即得

$$
A(Y)\ll_\varepsilon Y^{1+\varepsilon}.
\tag{5}
$$

## 3. Mellin 延拓排除临界带右侧零点

对 $\Re s>2$，Dirichlet 级数与部分和公式给出

$$
\frac1{\zeta(s-1)}
=\sum_{n\ge1}\frac{n\mu(n)}{n^s}
=s\int_1^\infty U(x)x^{-s-1}\,dx.
\tag{6}
$$

由 (5)，在任意 dyadic 区间 $X\le x<2X$ 上 Cauchy--Schwarz 给出

$$
\int_X^{2X}|U(x)|x^{-\sigma-1}\,dx
\ll_\varepsilon X^{3/2+\varepsilon/2-\sigma}.
\tag{7}
$$

因此对每个 $\sigma>3/2$，选取 $\varepsilon<2\sigma-3$，右端按 dyadic $X$ 求和收敛，并在紧子带上一致收敛。式 (6) 从 $\Re s>2$ 延拓为 $\Re s>3/2$ 的全纯函数。

若 $\zeta(w)$ 在 $\Re w>1/2$ 有零点，取 $s=w+1$，则 $1/\zeta(s-1)$ 在 $\Re s>3/2$ 有极点，与上述全纯延拓矛盾。因此 $\zeta$ 在 $\Re w>1/2$ 无零点。由函数方程的对称性，非平凡零点也不可能位于 $\Re w<1/2$，故 RH 成立。

## 4. RH 反向蕴含

RH 给出经典界

$$
M(x)=\sum_{n\le x}\mu(n)\ll_\varepsilon x^{1/2+\varepsilon}.
$$

Abel 分部求和于是给出

$$
U(x)=xM(x)-\int_1^xM(t)\,dt
\ll_\varepsilon x^{3/2+\varepsilon}.
$$

所以 $D_Y(n)\ll_\varepsilon n^{3/2+\varepsilon}$（端点段同样成立）。代入 note 409 的式 (4)，并将 $\varepsilon$ 缩小一半，得到

$$
Q_w(\mu_{\le Y})\ll_\varepsilon Y^{1+\varepsilon}.
$$

**结论。** 主部 PSD 并没有绕开 RH；它给出的平方根级估计与 RH 严格等价。真正未解决的不是核符号，而是证明 (1) 的无条件 signed Möbius 均方界。
