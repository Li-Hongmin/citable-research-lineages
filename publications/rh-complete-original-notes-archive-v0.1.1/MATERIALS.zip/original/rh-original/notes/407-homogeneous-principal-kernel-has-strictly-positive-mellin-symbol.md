> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 二进制尾能量的齐次主核与严格正 Mellin 符号

note 406 的核在去掉右端 \(Y\) 截断后有一个严格正的齐次主部。
这个分解把真正的困难压缩到端点截断，而不是主核的符号。

## 1. 齐次主核

令 \(s=\min(m,n)\)、\(r=\max(m,n)/s\in[1,2)\)。把无限上端的整数和写成
\[
K_\infty(m,n)=\sum_{k=\max(m,n)+1}^{2s}k.
\]
直接计算得到
\[
\frac{K_\infty(m,n)}{mn}
=w(\log r)+\frac{2-r}{2rs},
\qquad
w(t)=\left(2e^{-|t|}-\frac12e^{|t|}\right)\mathbf 1_{|t|<\log2}.
\tag{1}
\]
第二项的绝对值在全部 \(m,n\le Y\) 上求和为 \(O(Y)\)：固定 \(s\) 时只有 \(O(s)\) 个允许的 \(r\)，每项为 \(O(1/s)\)。

## 2. 严格正的 Mellin 符号

取 Fourier 变换
\[
\widehat w(\xi)=\int_{\mathbb R}w(t)e^{-i\xi t}\,dt.
\]
令 \(a=\log2\)。直接积分给出
\[
\boxed{
\widehat w(\xi)=\frac{5-4\cos(a\xi)}{1+\xi^2}
=\frac{|2-2^{i\xi}|^2}{1+\xi^2}>0.
}
\tag{2}
\]
因此对任意有限系数列 \(c_n\)，齐次主部二次型严格因子化为
\[
\sum_{m,n}c_mc_nw\!\left(\log\frac mn\right)
=\frac1{2\pi}\int_{\mathbb R}
\frac{\left|(2-2^{i\xi})\sum_n c_nn^{i\xi}\right|^2}{1+\xi^2}\,d\xi\ge0.
\tag{3}
\]
对于 \(c_n=\mu(n)\mathbf 1_{n\le Y}\)，这正是一个带 dyadic 高通因子的
Mellin--\(H^1\) 能量。

## 3. 端点截断是唯一大项

令 \(E_\infty(Y)\) 表示用 \(K_\infty\) 而非 \(K_Y\) 的二次型。由 (1)--(3)，
\[
E_\infty(Y)=Q_w(\mu_{\le Y})+O(Y),
\tag{4}
\]
其中 \(Q_w\ge0\) 是 (3) 的主部。
另一方面，交换求和可写成
\[
E_\infty(Y)=E(Y)+
\sum_{Y<k\le2Y}k
\left|\sum_{k/2\le n<k,\ n\le Y}\frac{\mu(n)}n\right|^2.
\tag{5}
\]
第二项是非负的端点尾。因此若能证明
\[
Q_w(\mu_{\le Y})\ll_\varepsilon Y^{1+\varepsilon},
\tag{6}
\]
便立即得到 note 402--405 的 RH-equivalent 尾能量界。

式 (5) 也说明不能仅凭主核的 PSD 符号完成证明：端点尾是一个同量级的
moving-cutoff 量，必须利用 Möbius 的 signed cancellation。齐次主核本身
没有负方向；剩余难点完全是端点与主核之间的算术耦合。
