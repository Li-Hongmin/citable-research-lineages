> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# incomplete-lcm 边界的 reciprocal-frequency 双和

日期：2026-08-15。

本 note 把 note 065/208 的 \(\mathcal B_N\) 完全展开到 sawtooth 的
reciprocal frequencies，明确 Jordan 正主项与真正未控的非零频率。所有等式
先按 Abel 因子 \(\rho^{|r|+|s|}\)（\(0<\rho<1\)）解释，再令
\(\rho\uparrow1\)；因此避免了 Fourier 级数在跳点的点态问题。

## 1. 单边界与双边界

置
\[
 B_d(y)=\left\{\frac yd\right\}-\frac12,\qquad
 \mathcal I_N(\alpha)=\int_N^{2N}e^{2\pi i\alpha y}\,dy .
\]
在非整数点
\[
 B_d(y)=\sum_{r\ne0}\widehat B(r)e^{2\pi iry/d},
\qquad
 \widehat B(r)=-\frac1{2\pi i r}.
\tag{1}
\]
故
\[
 \boxed{
 E_d(N)=\sum_{r\ne0}\widehat B(r)\,
 \mathcal I_N(r/d).}
\tag{2}
\]
对双边界，令 \(g=(d,e)\)。乘积中的零频率条件是
\[
 \frac rd+\frac se=0
\quad\Longleftrightarrow\quad
 r=kd/g,\quad s=-ke/g .
\]
它的总贡献为
\[
 N\sum_{k\ne0}\frac1{4\pi^2k^2(d/g)(e/g)}
 =\frac{Ng^2}{12de}.
\tag{3}
\]
因此扣掉完整 lcm 周期主项后，恰有
\[
 \boxed{
 E_{d,e}(N)=
 \sum_{\substack{r,s\ne0\\re+sd\ne0}}
 \widehat B(r)\widehat B(s)\,
 \mathcal I_N\!\left(\frac{re+sd}{de}\right).}
\tag{4}
\]
(4) 是非零 reciprocal-frequency 的精确双和。

## 2. \(\mathcal B_N\) 的完整频率形式

沿用 \(c_N,\lambda_{d,N}\) 的记号，note 065 的边界余项变成
\[
 \boxed{\begin{aligned}
 \mathcal B_N={}&Nc_N^2
 +2c_N\sum_{d\le N}\lambda_{d,N}
 \sum_{r\ne0}\widehat B(r)\mathcal I_N(r/d)\\
 &+\sum_{d,e\le N}\lambda_{d,N}\lambda_{e,N}
 \sum_{\substack{r,s\ne0\\re+sd\ne0}}
 \widehat B(r)\widehat B(s)
 \mathcal I_N\!\left(\frac{re+sd}{de}\right).
 \end{aligned}}
\tag{5}
\]
这把 one-boundary 项与 incomplete-lcm 双边界项放在同一频率框架中。

## 3. 对角/非对角分裂

当 \(d=e\) 时，令 \(k=r+s\)。Bernoulli 恒等式
\[
 \left(\{x\}-\frac12\right)^2
 =\frac1{12}
 +\sum_{k\ne0}\frac{e^{2\pi ikx}}{2\pi^2k^2}
\]
给出扣掉 \(N/12\) 后的精确对角式
\[
 \boxed{
 E_{d,d}(N)=
 \sum_{k\ne0}\frac1{2\pi^2k^2}\,
 \mathcal I_N(k/d).}
\tag{6}
\]
因此对角边界不是正项：\(\mathcal I_N(k/d)\) 有振荡相位。

当 \(d\ne e\) 时，按
\[
 q=re+sd\ne0
\]
分组，定义绝对收敛（或 Abel 极限）的卷积系数
\[
 C_{d,e}(q)
 :=\sum_{\substack{r,s\ne0\\re+sd=q}}
 \widehat B(r)\widehat B(s).
\tag{7}
\]
则
\[
 \boxed{
 E_{d,e}(N)=\sum_{q\ne0}
 C_{d,e}(q)\,
 \mathcal I_N(q/(de)).}
\tag{8}
\]
非对角低频 \(q=\pm1,\pm2,\ldots\) 在 \(de\gg N\) 时满足
\[
 |\mathcal I_N(q/(de))|
 \asymp N
\]
（只要 \(qN/(de)\) 落在固定小区间）；这正是逐频率取绝对值无法获得
幂次节省的区间。

## 4. MRT/Jordan 输入实际只控制到哪里

式 (3) 说明 Jordan 正主项正是 \(q=0\) 共振的完整 lcm 平均：
\[
 \frac N{12}Q_2(N)
 =\frac N{12}\sum_{d,e\le N}\lambda_d\lambda_e
 \frac{(d,e)^2}{de}.
\]
现有 Barban--Vehov/Ramaré--Zuniga-Alterman 的 \(H^0\) 均方输入和
Jordan 正平方和能给
\[
 Q_2(N)\ll\frac{N\log\log N}{\log N},
\qquad
 \frac N{12}Q_2(N)=O\!\left(\frac{N^2\log\log N}{\log N}\right).
\tag{9}
\]
但它们不含 (7)--(8) 的 \(q\ne0\) 低频系数。对 (8) 使用
\[
 |\mathcal I_N(q/(de))|
 \le \min\!\left(N,\frac{de}{\pi|q|}\right)
\tag{10}
\]
并逐项取模，会留下 \(N^2\) 量纲的 harmonic reciprocal-frequency 总和；
没有固定幂次节省。因而 MRT/Jordan 的可严格继承改善至多是 (9) 的
对数级别，不能替代
\[
 \mathcal B_N+\frac N{12}Q_2(N)=O(N^{2-\delta}).
\tag{11}
\]

式 (11) 是最小 arithmetic input：它必须同时保留 \(q\) 的符号、
\(d,e\) 的 Möbius taper 与 \(\mathcal I_N\) 的相位，不能拆成对角、
非对角或各移位的绝对值估计。

本文未证明 (11)，也不把 Jordan 的对数节省外推为固定幂次或 RH。
