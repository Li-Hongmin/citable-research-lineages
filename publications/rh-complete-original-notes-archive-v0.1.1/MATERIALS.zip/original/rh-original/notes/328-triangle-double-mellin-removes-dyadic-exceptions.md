> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 三角双 Mellin 通道去除二进实部例外

日期：2026-08-16。

本 note 把 note 324 的双 Mellin恒等式与 note 327 的重数链比较。
结论是：三角通道在 \(z=\rho\) 处的零点因子为
\(\zeta(2\rho)\)，所以对所有 \(\Re\rho>1/2\) 都不消失；若能在
一个开参数域内证明相应 Mellin 延拓/增长界，便不需要 note 327 的二进
实部例外分析。

## 1. 双 Mellin通道

沿用 note 324：
\[
\mathcal M(p,q)
=\frac{2^p-1}{pq}F(p)F(q)
-\frac{2^p}{q}\frac1{2\pi i}
\int_{(\sigma)}
\widehat\Phi_{p,q}(z)F(z)F(p+q-z)\,dz,
\]
其中
\[
F(s)=\frac{\zeta(2s)}{\zeta(s)},\qquad p,q>2.
\]
假设 \(\rho\) 是重数 \(m\) 的 zeta 零点，\(1/2<\Re\rho<1\)。
在 \(z=\rho\) 附近，
\[
F(z)=\frac{\zeta(2\rho)+O(z-\rho)}
 {(\zeta^{(m)}(\rho)/m!)(z-\rho)^m+O((z-\rho)^{m+1})}.
\]
因为 \(\Re(2\rho)>1\)，Euler 乘积给出
\[
\zeta(2\rho)\ne0.
\]
又因为 \(p+q-\rho\) 的实部大于 \(1\)，
\(F(p+q-\rho)\) 绝对收敛且不为零。

## 2. 窗口系数不会在所有参数上消失

由 note 324，
\[
\widehat\Phi_{p,q}(\rho)
=B(\rho,q-\rho)
\frac{{}_2F_1(p+1,\rho-q+1;\rho-q+2;-1)}
{\rho-q+1}.
\]
固定任意 \(q>2\) 后，去掉与 \(p\) 无关的显式因子，
右侧关于 \(p\) 是非零解析函数；若恒等为零，延拓到 \(p=-1\)
会与其端点积分表达式矛盾。因此其正实轴零点至多离散。

所以对每一个给定的离线零点 \(\rho\)，可以选择任意
\(q>2\)，再选择 \(p>2\) 避开该离散零集，使
\[
\widehat\Phi_{p,q}(\rho)\ne0.
\]
此时 \(z=\rho\) 的 integrand 有确切的 \(m\) 阶极点，且其主部系数非零；
不存在 note 327 中由 \(\zeta(2\rho-1)\) 造成的二进 tent 例外。

## 3. 需要的真正估计

上述事实本身仍不是 RH 证明，因为原始双 Mellin恒等式只在绝对收敛域
成立。若存在一个开集 \(\mathcal U\subset\{(p,q):p,q>2\}\)，使实际三角尾
\(\mathscr B(U,X)\) 的 Mellin变换具有：

1. 足以把 (1) 的 \(z\)-轮廓移到 \(\Re z>1/2\) 的亚纯延拓；
2. 在参数 \((p,q)\in\mathcal U\) 内局部一致的轮廓增长界；
3. 对应的部分和/截断误差不超过 \(B^{1/2+\varepsilon}\) 量级；

那么对任意 \(\rho\) 可选取 \((p,q)\in\mathcal U\) 使窗口系数非零，
轮廓移位的非零极点即与该界矛盾，从而推出 RH。

这是一条比 note 327 更强的“全零点检测”接口：它不要求排除
\(\zeta(2\rho-1)=0\)，但代价是必须建立实际三角尾的开参数域
Mellin intertwiner。当前 notes 310--314、323--324 尚未提供该估计。

## 4. 结论

二进重数链是固定共振振幅的收缩结果；三角双 Mellin通道则提供一个
理论上覆盖所有离线零点的第二通道。两者共同表明：剩余问题不是零点
响应是否存在，而是能否从正 detector 的 half-lattice 边界分解中建立
跨 \(z\) 的 signed arithmetic intertwiner。

