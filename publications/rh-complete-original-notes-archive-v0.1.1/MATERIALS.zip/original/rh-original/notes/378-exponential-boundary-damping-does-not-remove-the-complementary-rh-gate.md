> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 指数边界阻尼只控制互补核：\((1-u)^z\) 的严格界与剩余 RH 门

## 严格的阻尼界

令 \(z\ge2\) 为整数，并定义
\[
\rho_J(u)=(1-u)^J\mathbf1_{(0,1)}(u).
\]
在 \(x=z^2\) 的原始 cutoff 上，
\[
R_J(z):=\sum_{a,b\le z}\mu(a)\mu(b)
\left(1-\frac{ab}{z^2}\right)^J .
\tag{1}
\]
由于 \(0\le(1-ab/z^2)^J\le e^{-Jab/z^2}\)，且 \(|\mu|\le1\)，有
\[
|R_J(z)|
\le\sum_{a,b\le z}e^{-Jab/z^2}.
\tag{2}
\]
对固定 \(a\)，积分比较给出
\[
\sum_{b\le z}e^{-Jab/z^2}
\le 1+\int_0^\infty e^{-Jat/z^2}\,dt
=1+\frac{z^2}{Ja}.
\tag{3}
\]
所以
\[
\boxed{
|R_J(z)|\le z+\frac{z^2}{J}H_z.}
\tag{4}
\]
特别地，取 \(J=z\) 得
\[
|R_z(z)|\ll z\log(2z).
\tag{5}
\]
这是真正无条件的边界阻尼估计，不使用 PNT 或 RH。

## 与 Mertens 模式的精确关系

互补核
\[
\psi_J(u)=1-(1-u)^J
\]
满足
\[
\sum_{a,b\le z}\mu(a)\mu(b)\psi_J(ab/z^2)
=M(z)^2-R_J(z).
\tag{6}
\]
因此 (5) 只能说明 \(\rho_z\) 这一侧的 cutoff 二次型很小；若能另外证明
\[
\sum_{a,b\le z}\mu(a)\mu(b)\psi_z(ab/z^2)
\ll_\varepsilon z^{1+\varepsilon},
\tag{7}
\]
才可由 (6) 得到平方根级 Mertens。可是 \(\psi_z(u)\) 在绝大多数 \(u\) 上接近 1，其二次型仍包含 \(M(z)^2\) 的完整低频模式；(7) 正是原始 RH-strength signed 门，而不是由 (5) 自动推出的结论。

## 结论

指数边界阻尼可以把“互补小乘积”部分严格压到 \(O(z\log z)\)，但不能同时压低其互补核。任何声称仅靠 \((1-u)^z\) 的边界衰减就得到 RH 的论证，都会在 (6) 处重新引入 \(\psi_z\) 的 Möbius signed cancellation。要继续推进，必须给 (7) 一个新的跨尺度 intertwiner，或证明它与 incomplete-lcm boundary 的交叉项发生额外抵消。

