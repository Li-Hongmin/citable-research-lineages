> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# quotient-difference kernel 没有自动零频矩消失

日期：2026-08-16。

## 源码定义

在 `main (19).tex` 的 same-residue slicing 中，源码定义

\[
 \Gamma_{\eta,r,\ell}(u)
 :=
 \sum_{
   \substack{(\xi_1,\xi_2)\text{ in the frozen pair class }\ell\\
   s_{\xi_1}=k_1\mathfrak A^{\rm eff}+r,\;
   s_{\xi_2}=k_2\mathfrak A^{\rm eff}+r\\
   k_1-k_2=u}}
 W_{\xi_1,\xi_2}.
\tag{1}
\]

其后只证明了 support、\(\ell^1\)-mass、sup 和 total variation 的上界。源码没有
证明

\[
 \sum_u\Gamma_{\eta,r,\ell}(u)=0,
 \qquad
 \sum_u u^j\Gamma_{\eta,r,\ell}(u)=0,
\tag{2}
\]

也没有给出任何等价的 signed moment identity。

## 系数来源比零矩问题更早缺一层

在同一份 `main (19).tex` 的 Definition
`completed-frontier-data-current-paper` 中，\(w_\xi\) 只被文字定义为
“exact outer packet/sign/root coefficient produced before divisor completion”。源码没有
给出它的显式公式、共轭规则、对 shift 参数的依赖，或与前面 packet 权重的精确恒等式。
随后 `same-residue-quotient-difference-correlations-current-paper` 直接使用
\(W_{\xi_1,\xi_2}\)，但全文检索不到该符号的独立定义。于是目前不能从正文推出
\[
 W_{\xi_1,\xi_2}=w_{\xi_1}\overline{w_{\xi_2}},
 \qquad \mathrm{or}\qquad
 W_{\xi_1,\xi_2}=W_{\xi_2,\xi_1}^{\,*},
\]
更不能推出任何正定性、共轭对称性或零频消失。

这也排除了一个常见但未获授权的补步：把 \(\Gamma\) 自行补成自然自相关。
若确实定义
\(W_{\xi_1,\xi_2}=a_{\xi_1}\overline{a_{\xi_2}}\)，则零频项反而满足
\[
 \sum_u\Gamma(u)=\left|\sum_k a_k\right|^2\ge0,
\]
通常不等于零；它提供的是正平方质量，而不是所需的低频消失。因而该补定义
不能修复 Theorem 19.216 的低频因子，除非再加入新的算术抵消。

## 形式上不能从定义推出消失

由 (1) 直接求和只得到

\[
 \sum_u\Gamma_{\eta,r,\ell}(u)
 =
 \sum_{(\xi_1,\xi_2)\text{ in the class }\ell}W_{\xi_1,\xi_2},
\tag{3}
\]

而不是零。以一个只有单个有序 pair、权重
\(W_{\xi_1,\xi_2}=1\)、差值 \(u=u_0\) 的 frozen class 为例，
\(\Gamma(u_0)=1\) 且其余值为零。它满足源码列出的有限 support、有限 mass 和
有限 total variation 条件，但

\[
 \sum_u\Gamma(u)=1,
 \qquad
 \sum_u u^j\Gamma(u)=u_0^j.
\]

即使禁止自配对，只要允许一个非零有序 pair，这个例子仍成立。因而任何零频
抵消都必须来自未写出的实际 arithmetic identity，而不能由 quotient-difference
重参数化本身自动产生。

## 与低频估计的关系

若没有 (2)，对任意 block (H\ll q/L)，summation-by-parts 只给

\[
 \left|\sum_u\Gamma(u)e(-hCu/q)\right|
 \le \|\Gamma\|_1
 \asymp L,
\]

低频平方能量便是 (\asymp HL^2/q)，正如 note 252 的两区 harmonic law。
若有一次零矩消失且能控制一阶矩，才可能把振幅改善为
\(O(L\,|h|/q)\) 或相应的 variation-weighted 量；更高阶改善需要更高矩
消失和同阶矩预算。

源码中确实有某些特殊 color branch 的显式 vanishing，但那是另一个已经单独
分离的 structural branch；它没有被证明适用于 19.216 所用的全部 generic
\(\Gamma_{\eta,r,\ell}\)。相反，generic ledger 的文字明确把质量估计描述为
不使用 Möbius cancellation 的确定性账本。

## 必须新增的输入

要修复低频 (L) 因子，至少需要下列一种可审计命题：

1. 对每个实际 frozen class，证明 (2) 的零矩或高阶零矩；
2. 直接给出 \(\Gamma\) 的 Fourier transform 在 (h/q\to0) 时的统一小量；
3. 放弃逐 class 的绝对值，建立跨 class 的 signed \(\ell^2\) 或 spectral
   cancellation。

三者都超出目前 Proposition 19.214、same-residue multiplicity lemma 和
Theorem 19.216 的现有假设。故 quotient-difference slicing 本身不能修复
低频 harmonic estimate。

## 裁决

低频缺口不是“还没有把 Abel summation 写得足够精细”，而是缺少一个新的
算术零矩/谱输入。没有它，源码允许的 kernel 类仍包含低频质量为 (L) 的对象；
因此不能从现有确定性账本推出 packet bound，更不能推出 RH。

本次源码审计还把缺口前移为一个独立接口条件：必须先给出 \(w_\xi\) 与
\(W_{\xi_1,\xi_2}\) 的可复核定义及其归一化，随后才能讨论零矩、正定性或
cross-class cancellation。仅凭当前的符号占位不能把任何一种结构当作已证明。
