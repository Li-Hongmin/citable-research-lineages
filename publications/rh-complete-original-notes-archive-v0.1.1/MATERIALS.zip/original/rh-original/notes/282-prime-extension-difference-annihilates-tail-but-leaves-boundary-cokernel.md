> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 素数扩张差分消掉尾项，但留下一个 boundary 余核

日期：2026-08-16。

依赖：[note 177](177-mobius-parity-intertwiner-for-one-sided-reciprocal-boundary.md)、
[note 179](179-fixed-core-prime-extension-gives-half-lattice-signed-asymptotic.md)。

本 note 把“加入一个大素数再做差分”写成一个严格的跨尺度接口。它确实
消掉固定 squarefree 核的 boundary mode，但差分方向有一个不可见的常数核；
这个余核正是不能由 reciprocal 尾部估计替代的 signed 算术门。

## 1. 固定核心与素数扩张

令 $q\ge2$ 为固定 squarefree 整数，令 $\ell>q$ 为素数且 $\ell\nmid q$，
并置 $X=q\ell$。记单侧 reciprocal 核为

$$
\mathcal H_X
:=\sum_{a,b\mid X}\mu(a)\mu(b)
 p\!\left(\log\frac{X}{ab}\right),
$$

其中 $p(t)=0$ 于 $t<0$、$p(0)=0$，且 $P(y)=p(\log y)$；因此这里沿用
当前 detector 的端点条件 $P(1)=0$。由于

$$
L_{q\ell}:=\{d\mid q\ell:d<\sqrt{q\ell}\}=D(q):=\{d:d\mid q\},
$$

定义

$$
Q_q(\ell):=\sum_{a,b\mid q}\mu(a)\mu(b)P\!\left(\frac{q\ell}{ab}\right),
$$

以及固定核心的 ordinary boundary energy

$$
G_q:=\sum_{a,b\mid q}\mu(a)\mu(b)
 g\!\left(\log\frac ab\right),
\qquad
g(t)=\frac{p(t)+p(-t)}2.
$$

note 177 的完整 divisor parity 恒等式给出精确公式

$$
\boxed{\mathcal H_{q\ell}=Q_q(\ell)-2\mu(q)G_q.}
\tag{1}
$$

这里 $Q_q(\ell)$ 是随 $\ell$ 衰减的 half-lattice 尾，而第二项与 $\ell$
无关。

## 2. 素数差分的精确消除

取两个不同的素数 $\ell_1,\ell_2>q$。由 (1) 立即得到

$$
\boxed{
\mathcal H_{q\ell_1}-\mathcal H_{q\ell_2}
 =Q_q(\ell_1)-Q_q(\ell_2).}
\tag{2}
$$

因此任意有限系数 $(c_j)$ 满足 $\sum_jc_j=0$ 时，都有

$$
\boxed{
\sum_jc_j\mathcal H_{q\ell_j}
 =\sum_jc_jQ_q(\ell_j).}
\tag{3}
$$

这是真正的 signed cross-scale cancellation：固定核心的 boundary mode 被
完全消掉，而不是被逐项取绝对值。

若 detector 满足已核验的尾界

$$
|P(y)|\le C_Py^{-2}\qquad(y\ge1),
$$

则

$$
|Q_q(\ell)|
\le C_Pq^{-2}\ell^{-2}
\left(\sum_{a\mid q}a^2\right)^2,
\tag{4}
$$

从而

$$
\left|\sum_jc_j\mathcal H_{q\ell_j}\right|
\ll_{P,q}\sum_j|c_j|\ell_j^{-2}
\qquad\left(\sum_jc_j=0\right).
\tag{5}
$$

这说明差分通道本身是容易控制的；困难没有消失，而是被集中到被差分
消掉的常数 mode。

## 3. 一维余核与不可逆性

把 $\ell\mapsto\mathcal H_{q\ell}$ 看成定义在大素数集合上的函数。由 (1)，

$$
\mathcal H_{q\ell}=B_q+Q_q(\ell),
\qquad B_q:=-2\mu(q)G_q.
\tag{6}
$$

素数差分 $\Delta_{\ell_1,\ell_2}f=f(\ell_1)-f(\ell_2)$ 的核包含所有常数，
而 (6) 的唯一不衰减部分恰是 $B_q$。所以由所有差分值重建
$\mathcal H_{q\ell}$ 时，至少还要给出一个独立的 boundary normalization，
例如 $B_q$ 或一个等价的极限：

$$
B_q=\lim_{\ell\to\infty}\mathcal H_{q\ell},
$$

在 $P(y)=O(y^{-2})$ 下该极限存在。差分恒等式本身不能确定这个常数。

对 $q=2$，$G_2=-P(2)$，故

$$
B_2=-2P(2)<0,
$$

而所有 $\mathcal H_{2\ell_1}-\mathcal H_{2\ell_2}$ 只看到衰减的
$Q_2(\ell)$ 差值。这个例子把“差分已正化”与“原 reciprocal 门已正化”
严格区分开来。

## 4. 对跨尺度 intertwiner 的最小要求

任何试图用素数扩张差分构造全局 signed intertwiner 的方案，必须同时满足：

1. 在零和系数子空间 $\sum c_j=0$ 上，实现 (3) 的 boundary cancellation；
2. 在每个固定核心 $q$ 上，额外控制一个独立的 $B_q=-2\mu(q)G_q$；
3. 证明这些 $q$-indexed boundary modes 在原始 half-lattice 总和中有统一的
   signed 组合，而不能把它们逐 $q$ 取绝对值。

只证明 (5) 不能关闭 RH：它处理的是差分的像空间，完全没有处理差分的常数余核。
后者在 $q=2$ 已经是严格非零且为负的 mode；对一般 $q$，它就是完整 ordinary
Toeplitz Möbius energy $G_q$。

## 5. 裁决

素数扩张差分是一个合法、可计算的跨尺度 signed 接口，但它不是完整
intertwiner。其精确结构是

$$
\text{prime differences}
\quad\oplus\quad
\text{one boundary normalization per core }q.
$$

差分部分由 detector 的 $P(y)=O(y^{-2})$ 尾部控制；真正的未决问题被压缩为
如何统一处理这些 boundary modes，并将它们与原始 reciprocal-product 总和的
cutoff completion 配对。本文不声称 RH 已被证明。
