> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 415. 固定频带 Möbius 能量的当前文献边界（2026-08-17）

## 1. 本项目的最小算术门

主部的严格恒等式（notes 407--410）把目标压缩为

\[
 E_Y(w)=\int_{\mathbb R}w(t)\left|\sum_{n\le Y}\mu(n)n^{it}\right|^2dt,
\qquad w(t)\asymp (1+t^2)^{-1}|2-2^{it}|^2.
\]

要到达 RH 等价的平方根门，需要
\[
E_Y(w)\ll_\varepsilon Y^{1+\varepsilon}.
\]
任何固定幂次的改进 \(E_Y(w)\ll Y^{2-\delta}\) 至少给出一条固定零自由线；见 note 412。

## 2. 直接相关的已知输入

Matomäki--Radziwiłł--Tao 的 *An averaged form of Chowla's conjecture*
（arXiv:1503.05121）证明的是对加性移位
\[
\sum_{h_1,\ldots,h_k\le H}
\left|\sum_{n\le X}\lambda(n+h_1)\cdots\lambda(n+h_k)\right|
 =o(H^kX)
\]
（并给出可量化但本质为对数级的衰减）。相关短区间结果同样以移位平均或短区间平均为变量。

截至 2026-08-17，Menon 的 *Improved bounds for multiplicative functions in almost all
short intervals*（arXiv:2607.15574）进一步改进了这一路线，并明确把 Liouville
短区间衰减称为在 Matomäki--Radziwiłł 方法内“essentially optimal”；其摘要仍只给
短区间/平均 Chowla 类型结果，没有固定幂次的全尺度 Möbius ratio-energy 估计。
论文引言中的定量形状仍是
\[
\frac{1}{X}\int_X^{2X}
\left|\frac1h\sum_{x\le n\le x+h}\lambda(n)\right|^2dx
\ll \frac{(\log\log h)^2}{(\log h)^2}+\frac1{(\log X)^c},
\]
即对数级衰减；它没有把本项目所需的固定幂次 \(Y^{-\delta}\) 引入。

这些结论不能直接替代本项目的门，原因有三点：

1. 本核按 \(\log(m/n)\) 加权，是固定 multiplicative ratio，而不是固定 additive shift；
2. dyadic 分块后 ratio 权随外变量移动，不能在取绝对值前冻结为一个固定 shift 权；
3. 即使把权平滑并无损转移到移位平均，现有量级仍是
   \(Y^2\rho(Y)\)，其中 \(\rho(Y)\to0\) 仅为对数级，不能产生固定 \(Y^{-\delta}\) 节省。

因此，当前文献没有提供可直接插入 notes 410/412 的固定幂次或平方根估计。缺口仍是一个新的 signed Möbius 二次均方/跨尺度 intertwiner，而不是缺少一次标准平均移位引用。

## 3. 证据边界

这里的结论是“现有定理不能直接闭合本门”，不是对所有未来方法的不可行性证明；若出现同时处理移动 ratio 权、全尺度边界和 Möbius 符号的强定理，应重新审查 notes 413 的分解。

## 4. 近期原始来源的交叉核验

Martin--Yip, *Oscillation results for the summatory functions of fake μ's*
（Canadian Journal of Mathematics，2025，DOI
<https://doi.org/10.4153/S0008414X25101314>）的 Theorem 1.16(b) 对 Möbius-type
函数给出无条件上界
\[
E_f(x)\ll x^{1/k}
\exp\!\left(-c\frac{(\log x)^{3/5}}{(\log\log x)^{1/5}}\right),
\]
并在 Remark 1.17 明确指出：对经典 \(f=\mu\)（\(k=1\)），这类估计没有幂次
节省，仍是 Mertens 和的最佳已知无条件尺度。该结论与本项目 notes 412、438 的
零自由区基线一致；它不涉及本项目固定 multiplicative-ratio 核的加权均方，因而
既不能证明也不能反驳 notes 438 的 RH 等价门。

Nathan Ng 的 *The distribution of the summatory function of the Möbius function*
（arXiv:math/0310381，<https://arxiv.org/abs/math/0310381>）则明确把其分布和
极值结论置于 RH 及 Gonek--Hejhal 负矩猜想之下，不能作为无条件输入。

检索到的另一类“mean square of Möbius”结果是对二次特征扭曲的平均，例如
*Mean squares of quadratic twists of the Möbius function*
（Journal of Number Theory，2023，<https://doi.org/10.1016/j.jnt.2023.01.006>）。
其平均变量是扭曲参数，不是固定的 \(\mu(n)\)；因此它不控制
\[
\sum_{n\le Y}\frac{|M_1(n)|^2}{n^3}
\quad\text{或}\quad
\int w(t)\left|\sum_{n\le Y}\mu(n)n^{it}\right|^2dt.
\]
这一区分排除了把“存在 Möbius 均方论文”直接当作本项目平方根输入的误读。

## 5. 固定频带的均方瓶颈

相关文献中反复使用的经典 Dirichlet 多项式均方公式是
\[
\int_{-T}^{T}\left|\sum_{n\le Y}a_n n^{-it}\right|^2dt
\ll (T+Y)\sum_{n\le Y}|a_n|^2.
\tag{5.1}
\]
对 \(a_n=\mu(n)\) 且固定 \(T=O(1)\)，右侧只有 \(O(Y^2)\) 量级；它在
\(T\) 足够长时能产生正交性，但在本项目所需的固定乘法频带内不能产生
\(Y^{1+\varepsilon}\) 的平方根节省。

例如 *Averages of the Möbius Function on Shifted Primes* 的预备部分把该
均方公式用于加性移位与短区间平均，而不是固定
\(\int_{-T}^{T}|\sum_{n\le Y}\mu(n)n^{it}|^2dt\)；参见
<https://academic.oup.com/qjmath/article/73/2/729/6446139>。同样，
*Mean squares of quadratic twists of the Möbius function* 的平均变量是
二次特征参数 \(d\)，不是 \(t\) 或固定的 \(\mu(n)\) 比值核；参见
<https://doi.org/10.1016/j.jnt.2023.01.006>。

因此这次核查把“标准 Dirichlet 多项式均方可直接关闭固定 ratio-energy”
排除为错误捷径；仍需新的固定频带 Möbius signed cancellation 或等价的
算术 intertwiner。
