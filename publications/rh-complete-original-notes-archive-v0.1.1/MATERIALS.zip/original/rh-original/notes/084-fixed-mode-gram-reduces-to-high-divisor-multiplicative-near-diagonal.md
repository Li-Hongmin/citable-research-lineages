> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定模 Gram 的两种坐标与高除数截断边界

日期：2026-08-13。

依赖：[note 079](079-path-dst-reduces-the-centered-defect-to-sqrtN-low-modes.md)、
[note 081](081-every-offline-zero-is-visible-in-one-fixed-sine-mode.md)、
[note 083](083-two-sine-modes-reduce-universal-detection-to-compact-nonvanishing.md)。

## 1. 保留 Möbius--prime 联合系数

令

\[
w_k(t):=\sin\pi k(t-1),
\qquad
B_N:=\sum_{d\le N}\frac{\mu(d)}d\log\frac Nd.
\tag{1}
\]

对 \(N<n<2N\)，

\[
q_N(n):=\sum_{\substack{d\mid n\\d\le N}}
\mu(d)\log\frac Nd
=\Lambda(n)+\mu(n)\log\frac nN.
\tag{2}
\]

定义中心化联合系数

\[
\boxed{
g_N(n):=B_N-q_N(n)
=\sum_{d\le N}\mu(d)\log\frac Nd
\left(\frac1d-\mathbf1_{d\mid n}\right).
}
\tag{3}
\]

则固定模有最短公式

\[
\boxed{
\mathcal R_{N,k}
=\sum_{N<n<2N}g_N(n)w_k(n/N).
}
\tag{4}
\]

特别地，若 \(N<p<2N\) 为素数，则

\[
q_N(p)=\log N.
\tag{5}
\]

式 (2)、(5) 说明不能把 \(\Lambda\) 与 \(\mu\log(n/N)\) 分开估计。

## 2. 精确 divisor Gram

沿用 note 079 的求积差

\[
\Delta_{N,d,k}:=
\frac{S_{N,k}}d-
\sum_{N<dm<2N}w_k(dm/N),
\qquad
S_{N,k}:=\sum_{j=1}^{N-1}\sin\frac{\pi kj}{N}.
\tag{6}
\]

则

\[
\mathcal R_{N,k}
=\sum_{d\le N}\mu(d)\log\frac Nd\,\Delta_{N,d,k}.
\tag{7}
\]

所以

\[
\boxed{
\sum_{Y<N\le2Y}|\mathcal R_{N,k}|^2
=\sum_{d,e\le2Y}\mu(d)\mu(e)\mathfrak K_{k,Y}(d,e),
}
\tag{8}
\]

\[
\mathfrak K_{k,Y}(d,e):=
\sum_{\substack{Y<N\le2Y\\d,e\le N}}
\log\frac Nd\log\frac Ne\,
\Delta_{N,d,k}\Delta_{N,e,k}.
\tag{9}
\]

固定 \(k\) 的 Euler--Maclaurin 求积给出

\[
\boxed{
|\Delta_{N,d,k}|\ll_k d/N.
}
\tag{10}
\]

故 divisor 对角已经安全：

\[
\sum_{Y<N\le2Y}\sum_{d\le N}
\log^2\frac Nd\,|\Delta_{N,d,k}|^2
\ll_kY^2.
\tag{11}
\]

## 3. 低除数在 divisor 坐标中无条件支付

由 (10) 与绝对求和，对任意 \(D\le Y\)，

\[
\boxed{
\sum_{Y<N\le2Y}
\left|
\sum_{d\le D}\mu(d)\log\frac Nd\,\Delta_{N,d,k}
\right|^2
\ll_k\frac{D^4}{Y}\log^2Y.
}
\tag{12}
\]

定义

\[
L_{N,k}^{\le D}:=
\sum_{d\le D}\mu(d)\log\frac Nd\,\Delta_{N,d,k},
\qquad
H_{N,k}^{>D}:=
\sum_{D<d\le N}\mu(d)\log\frac Nd\,\Delta_{N,d,k}.
\tag{13}
\]

则 \(\mathcal R_{N,k}=L_{N,k}^{\le D}+H_{N,k}^{>D}\)。取
\(D=Y^{3/4}\)，(12) 给出

\[
\sum_{N\asymp Y}|L_{N,k}^{\le D}|^2
\ll_kY^2\log^2Y.
\tag{14}
\]

因此，为证明目标均方，充分证明

\[
\boxed{
\sum_{Y<N\le2Y}|H_{N,k}^{>D}|^2
\ll_{k,\varepsilon}Y^{2+\varepsilon},
\qquad D=Y^{3/4}.
}
\tag{15}
\]

这里没有宣称低--高交叉项逐项消失；只使用

\[
\sum_N|L_{N,k}^{\le D}+H_{N,k}^{>D}|^2
\le2\sum_N|L_{N,k}^{\le D}|^2+2\sum_N|H_{N,k}^{>D}|^2.
\tag{15a}
\]

所以 (15) 是 divisor--\(\Delta\) 坐标中的充分截断，不是与下面 product 坐标共同的正交分解。

## 4. Shell Gram 的几何支撑

交换到 \((n,m)\) 后，令

\[
\mathcal I_Y(n,m):=
\{N\in\mathbb Z:Y<N\le2Y,\ N<n,m<2N\}.
\tag{16}
\]

若暂时忽略 \(g_N\) 对 \(N\) 的依赖，窗乘积对应纯几何核

\[
\boxed{
\kappa_{k,Y}(n,m)
=\frac12\sum_{N\in\mathcal I_Y(n,m)}
\left[
\cos\frac{\pi k(n-m)}N
-\cos\frac{\pi k(n+m)}N
\right].
}
\tag{17}
\]

其支撑严格满足

\[
Y<n,m<4Y,
\qquad
\max(n,m)<2\min(n,m).
\tag{18}
\]

但真实和中 \(g_N(n)g_N(m)\) 仍位于内层 \(N\)-和，不能从 (17) 提出。product diagonal
\(n=m\) 是安全的。Graham--Barban--Vehov 的 \(H^0\) 界给出

\[
\sum_{N<n<2N}|g_N(n)|^2\ll N\log N,
\tag{19}
\]

故

\[
\sum_{Y<N\le2Y}\sum_{N<n<2N}
|g_N(n)|^2w_k(n/N)^2
\ll Y^2\log Y.
\tag{20}
\]

## 5. 两个正确但不可拼接的剩余坐标

### 5.1 完整 product off-diagonal

去掉 (20) 后，完整 \(g_N\) 的 off-diagonal 为

\[
\boxed{
\begin{aligned}
\mathcal O_k(Y):={}&\frac12
\sum_{\substack{Y<n,m<4Y\\n\ne m}}
\sum_{N\in\mathcal I_Y(n,m)}g_N(n)g_N(m)\\
&\times\left[
\cos\frac{\pi k(n-m)}N
-\cos\frac{\pi k(n+m)}N
\right].
\end{aligned}}
\tag{21}
\]

一个正确的充分目标是

\[
\boxed{
|\mathcal O_k(Y)|\ll_{k,\varepsilon}Y^{2+\varepsilon}.
}
\tag{22}
\]

固定 \(k\) 时，相位在 \(N\asymp Y\) 上只转 \(O_k(1)\) 圈；当
\(|n-m|\ll Y/k\) 时，(17) 可为 \(\asymp Y\)。因此普通 cutoff 正交、Davenport--Halberstam
well-spaced-point 大筛及双大筛不能支付 (22)。这里的 \(g_N\) 是完整系数；(22) 不能与
(15) 拼接后再宣称只含 \(d,e>D\)。

不能把 (15) 与完整 \(g_N\) 的 (21) 直接拼接。下式只描述 \(k=2\) 的局部结构，以及
\(k=1\) 的 local--local 子块；它不描述完整余项：

\[
\boxed{
\begin{gathered}
d,e\gtrsim Y^{3/4-o(1)},\qquad
n=da,\quad m=eb,\\
a,b\lesssim Y^{1/4+o(1)},qquad
n\ne m,\quad \max(n,m)<2\min(n,m).
\end{gathered}}
\tag{23}
\]

```mermaid
flowchart LR
  G["fixed-k Gram"] --> A["divisor coordinates"]
  A --> L["low d: paid"]
  A --> H["full high-d Δ sum"]
  G --> B["product coordinates"]
  B --> P["complete g_N diagonal: paid"]
  B --> O["complete g_N off-diagonal"]
  H --> T["either target suffices"]
  O --> T
```

### 5.2 截断 divisor Gram

若要真正使用 divisor 截断 (15)，定义

\[
\begin{aligned}
B_{N,>D}&:=\sum_{D<d\le N}\frac{\mu(d)}d\log\frac Nd,\\
q_{N,>D}(n)&:=\sum_{\substack{D<d\le N\\d\mid n}}
\mu(d)\log\frac Nd,\\
g_{N,>D}(n)&:=B_{N,>D}-q_{N,>D}(n).
\end{aligned}
\tag{24}
\]

则精确地

\[
\boxed{
H_{N,k}^{>D}
=B_{N,>D}S_{N,k}
-\sum_{N<n<2N}q_{N,>D}(n)w_k(n/N).
}
\tag{25}
\]

局部项可写为

\[
\sum_{D<d\le N}\mu(d)\log\frac Nd
\sum_{N<da<2N}w_k(da/N),
\qquad a<\frac{2N}{D}\ll Y^{1/4}.
\tag{26}
\]

模态在此分叉：

\[
S_{N,2}=0,
\qquad
S_{N,1}=\cot\frac{\pi}{2N}\asymp N.
\tag{27}
\]

故 \(k=2\) 的高除数截断是纯 high-divisor/short-cofactor 乘法和；\(k=1\) 仍含全局项
\(B_{N,>D}S_{N,1}\)，必须与 (26) 联合抵消。当前两个可选原子为

\[
\boxed{
\begin{array}{ll}
(A)&\displaystyle
\sum_{N\asymp Y}|H_{N,k}^{>Y^{3/4}}|^2\ll Y^{2+\varepsilon},\quad k=1,2;\\[2mm]
(B)&\displaystyle
|\mathcal O_k(Y)|\ll Y^{2+\varepsilon},\quad k=1,2.
\end{array}}
\tag{28}
\]

(A)、(B) 是两套替代坐标，不能混合删除其对角或低除数。前者对 \(k=1\) 必须保留
global--local 联合消去；后者必须保留完整
\(g_N=B_N-\Lambda-\mu\log(n/N)\) 的联合符号。分项取绝对值都会重新损失一个 \(Y\) 次幂。
