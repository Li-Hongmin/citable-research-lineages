> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Full-divisor reciprocal block is a relative Schur contraction

## Channel Gram 的 Schur complement

沿用 note 187，令

\[
A_X:=G_{|h|},\qquad B_X:=G_h,
\]

则二通道 Gram 为

\[
\mathcal G_X=
\begin{pmatrix}
A_X&B_X\\
B_X&A_X
\end{pmatrix}\succeq0.
\]

若 \(A_X\) 可逆，Schur complement 给出精确不等式

\[
\boxed{
A_X-B_XA_X^{-1}B_X\succeq0.
}
\tag{1}
\]

若 \(A_X\) 奇异，则将 \(A_X^{-1}\) 换成 Moore--Penrose 逆，并加上
\(\operatorname{Ran}B_X\subseteq\operatorname{Ran}A_X\) 的标准闭性条件。

## 加入 divisor reflection

在完整 divisor 格上，\(R_X\) 与 \(A_X,B_X\) 对易，且

\[
H_X=B_XR_X,\qquad R_X^2=I.
\]

因此 (1) 等价于

\[
\boxed{
A_X-H_XA_X^{-1}H_X\succeq0.
}
\tag{2}
\]

换言之，完整 reciprocal block 是 \(A_X\)-度量下的 self-adjoint
contraction：

\[
\bigl\|A_X^{-1/2}H_XA_X^{-1/2}\bigr\|\le1.
\]

对任意 divisor 向量 \(c\)，特别是 Möbius 向量，都有

\[
|c^*H_Xc|\le c^*A_Xc.
\tag{3}
\]

这不是逐 entry 的绝对值估计，而是二通道正 Gram 的严格 Feshbach/Schur
结论。

## 与半格 completion 的关系

论文实际只保留 \(a,b<\sqrt X\) 的半格。虽然 \(R_X\) 不把半格保持不变，
但一般 Hilbert 空间事实是：若 \(A-H A^{-1}H\succeq0\)，则其任意主压缩
也满足相应的 relative contraction。具体地，令 \(E_L\) 为半格嵌入，
\(A_L=E_L^*AE_L\)、\(H_L=E_L^*HE_L\)，则

\[
A_L^{-1/2}H_LA_L^{-1/2}
=V^*(A^{-1/2}HA^{-1/2})V
\]

其中 \(V=A^{1/2}E_LA_L^{-1/2}\) 是等距映射。因此

\[
\boxed{A_L-H_LA_L^{-1}H_L\succeq0.}
\]

对单侧 detector 的偶化核 \(g(t)=P(e^{|t|})/2\)，有
\(H_L=Q_X/2\)。所以 half-lattice 仍有一个精确 Schur contraction；反射
cross block 的作用是识别这个压缩并决定 \(A_L\)，而不是破坏不等式本身。

真正未解决的是如何对实际 Möbius 半格向量控制
\(c_L^*A_Lc_L\)，以及如何把它与 common-scale 壳匹配；不能只凭
\(A_L\succeq0\) 得到 \(\sqrt X\) 级上界。

## 最小判别

若某个 proposed completion/intertwiner 能给出半格矩阵
\(\widetilde A_X,\widetilde H_X\) 满足

\[
\widetilde A_X-\widetilde H_X\widetilde A_X^{-1}
\widetilde H_X\succeq0
\]

且误差为 \(O(X^{1/2+\varepsilon})\)，则它正好补上完整 divisor Schur
contraction 与 common-scale detector 之间的缺口。相反，只有
\(\widetilde A_X\succeq0\) 或固定 rank-one 正增益，不能推出该式。

本 note 给出完整 divisor 格上的精确 Schur contraction，以及半格所需的
最小 cross-block 条件；它不是 RH 证明。
