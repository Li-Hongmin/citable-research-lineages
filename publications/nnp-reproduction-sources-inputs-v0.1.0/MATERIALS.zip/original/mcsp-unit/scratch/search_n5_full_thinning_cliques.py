#!/usr/bin/env python3
"""Heuristic falsification search for N=5 mixed row-star full thinning.

The candidate space is exact; the optimiser uses a fixed Monte-Carlo table
only to prioritize pairwise-intersecting cliques.  Every printed incumbent is
then recomputed exactly by a Boolean-DNF recursion before it is reported.
No result from this script is a general theorem or a proof of optimality.
"""

from __future__ import annotations

import argparse
import random
import sys
from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache

sys.path.insert(0, str(__import__("pathlib").Path(__file__).parent))
from exact_row_star_candidate_space import candidates


@dataclass(frozen=True)
class Candidate:
    values: tuple[int, ...]
    kind: str
    column_mask: int
    active_r: tuple[int, ...]


def make_candidates() -> list[Candidate]:
    universe, raw = candidates(5, 1, 2)
    index = {value: position for position, value in enumerate(universe)}
    out = []
    for values, kind in raw:
        column_mask = sum(1 << index[value] for value in values)
        active_r = tuple(
            r for r in range(32)
            if all(((r & value).bit_count() & 1) for value in values)
        )
        out.append(Candidate(values, kind, column_mask, active_r))
    return out


def normalize(terms: tuple[int, ...]) -> tuple[int, ...]:
    answer: list[int] = []
    for term in sorted(set(terms), key=int.bit_count):
        if not any(old & term == old for old in answer):
            answer.append(term)
    return tuple(answer)


def dnf_probability(terms: tuple[int, ...]) -> Fraction:
    """Exact Pr[V contains some term], for independent fair bits of V."""
    @lru_cache(maxsize=None)
    def recurse(current: tuple[int, ...]) -> Fraction:
        if not current:
            return Fraction(0)
        if current[0] == 0:
            return Fraction(1)
        frequency: dict[int, int] = {}
        for term in current:
            rest = term
            while rest:
                low = rest & -rest
                frequency[low] = frequency.get(low, 0) + 1
                rest ^= low
        bit = max(frequency, key=frequency.__getitem__)
        absent = normalize(tuple(term for term in current if not (term & bit)))
        present = normalize(tuple(term ^ bit if term & bit else term for term in current))
        return (recurse(absent) + recurse(present)) / 2

    return recurse(normalize(terms))


def exact_mass(selected: tuple[int, ...], items: list[Candidate]) -> Fraction:
    total = Fraction(0)
    for r in range(32):
        terms = tuple(items[index].column_mask for index in selected if r in items[index].active_r)
        total += dnf_probability(terms)
    return total / 32


def sample_events(items: list[Candidate], samples: int, rng: random.Random) -> list[int]:
    rows = [rng.randrange(32) for _ in range(samples)]
    retained = [rng.getrandbits(30) for _ in range(samples)]
    answer = []
    for item in items:
        active = set(item.active_r)
        bits = 0
        for position, (r, v) in enumerate(zip(rows, retained)):
            if r in active and item.column_mask & ~v == 0:
                bits |= 1 << position
        answer.append(bits)
    return answer


def common_core(selected: list[int], items: list[Candidate]) -> int:
    core = (1 << 30) - 1
    for index in selected:
        core &= items[index].column_mask
    return core


def no_core_seed(
    all_vertices: tuple[int, ...], adjacent: list[tuple[int, ...]], items: list[Candidate], rng: random.Random
) -> list[int]:
    """A pairwise-intersecting 3-clique with empty total intersection."""
    for _ in range(10_000):
        first = rng.choice(all_vertices)
        if not adjacent[first]:
            continue
        second = rng.choice(adjacent[first])
        overlap = items[first].column_mask & items[second].column_mask
        third_pool = [
            index for index in adjacent[first]
            if index != second and index in set(adjacent[second]) and not (items[index].column_mask & overlap)
        ]
        if third_pool:
            return [first, second, rng.choice(third_pool)]
    raise RuntimeError("could not sample an empty-core triple")


def search(items: list[Candidate], samples: int, restarts: int, seed: int, require_no_core: bool) -> None:
    rng = random.Random(seed)
    event = sample_events(items, samples, rng)
    adjacent = [
        tuple(other for other, compare in enumerate(items)
              if other != index and item.column_mask & compare.column_mask)
        for index, item in enumerate(items)
    ]
    all_vertices = tuple(range(len(items)))
    best_sample = -1
    best_exact = Fraction(-1)
    seen: set[tuple[int, ...]] = set()

    # Higher-order candidates are individually weak, but diversify the first
    # seed so that the search does not collapse only to common-core stars.
    seed_pool = sorted(all_vertices, key=lambda i: (len(items[i].values), rng.random()))
    for restart in range(restarts):
        if require_no_core:
            selected = no_core_seed(all_vertices, adjacent, items, rng)
            selected_set = set(selected)
            available = set(adjacent[selected[0]])
            for index in selected[1:]:
                available.intersection_update(adjacent[index])
            available.difference_update(selected_set)
            covered = 0
            for index in selected:
                covered |= event[index]
        else:
            seed_index = seed_pool[restart % len(seed_pool)] if restart < len(seed_pool) else rng.choice(all_vertices)
            selected = [seed_index]
            selected_set = {seed_index}
            available = set(adjacent[seed_index])
            covered = event[seed_index]
        # Permit a finite greedy clique; candidates with no sampled marginal
        # gain are not added, because they cannot improve the sampled union.
        for _ in range(36):
            if not available:
                break
            probe = tuple(available)
            if len(probe) > 220:
                probe = tuple(rng.sample(probe, 220))
            scored = sorted(
                (((covered | event[index]).bit_count(), rng.random(), index) for index in probe),
                reverse=True,
            )
            # Select among a narrow top band occasionally; this makes the
            # resulting clique less dependent on a single greedy tie break.
            band = scored[: min(6, len(scored))]
            score, _, chosen = band[0] if rng.random() < 0.78 else rng.choice(band)
            selected.append(chosen)
            selected_set.add(chosen)
            covered |= event[chosen]
            available.intersection_update(adjacent[chosen])
            available.difference_update(selected_set)
        signature = tuple(sorted(selected))
        sample_score = covered.bit_count()
        if require_no_core and common_core(selected, items):
            raise AssertionError("no-core seed unexpectedly gained a core")
        if signature in seen:
            continue
        seen.add(signature)
        if sample_score > best_sample:
            best_sample = sample_score
        # Exact work is reserved for the empirical frontier and every few
        # diversified cliques; it is not used as a fake exhaustive proof.
        if sample_score >= best_sample - max(6, samples // 600) or restart % 250 == 0:
            exact = exact_mass(signature, items)
            if exact > best_exact:
                best_exact = exact
                print(
                    "INCUMBENT",
                    {"restart": restart, "sample": f"{sample_score}/{samples}", "exact": str(exact), "size": len(signature), "no_common_core": require_no_core},
                    flush=True,
                )
                for index in signature:
                    item = items[index]
                    print({"type": item.kind, "values": item.values}, flush=True)
        if restart and restart % 250 == 0:
            print("PROGRESS", {"restart": restart, "unique": len(seen), "best_sample": f"{best_sample}/{samples}", "best_exact": str(best_exact), "no_common_core": require_no_core}, flush=True)
    print("FINAL", {"restarts": restarts, "unique": len(seen), "best_sample": f"{best_sample}/{samples}", "best_exact": str(best_exact), "no_common_core": require_no_core}, flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples", type=int, default=32768)
    parser.add_argument("--restarts", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260814)
    parser.add_argument("--no-common-core", action="store_true")
    args = parser.parse_args()
    items = make_candidates()
    print({"candidates": len(items), "samples": args.samples, "restarts": args.restarts, "seed": args.seed}, flush=True)
    search(items, args.samples, args.restarts, args.seed, args.no_common_core)


if __name__ == "__main__":
    main()
