#!/usr/bin/env python3
"""Independent exhaustive check of the 16-witness N=5 clean certificate.

The check uses a direct (r,t) satisfiability enumeration and then enumerates
all retained subsets of each active column set.  It is intentionally separate
from the original certificate's routines.
"""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations


N = 5
SPOILER = (1, 2)
FAMILY = (
    ("C", (8, 14, 26, 30)),
    ("R", (6, 25, 30)),
    ("R", (14, 22, 25)),
    ("R", (9, 22, 30)),
    ("R", (6, 9, 14)),
    ("C", (6, 8, 22, 26)),
    ("C", (6, 12, 22, 30)),
    ("P", (6, 8, 22, 27)),
    ("P", (8, 14, 27, 30)),
    ("C", (6, 14, 22, 28)),
    ("P", (6, 14, 22, 29)),
    ("C", (4, 14, 22, 30)),
    ("P", (6, 14, 21, 30)),
    ("P", (5, 14, 22, 30)),
    ("P", (6, 13, 22, 30)),
    ("C", (6, 14, 20, 30)),
)
Y = tuple(sorted({2, *(d for _, values in FAMILY for d in values)}))
TARGET = {"R": 1, "C": 2, "P": 3}


def dot(r: int, x: int) -> int:
    return (r & x).bit_count() & 1


def xor_sum(values: tuple[int, ...]) -> int:
    answer = 0
    for value in values:
        answer ^= value
    return answer


def rank(values: tuple[int, ...]) -> int:
    pivots: set[int] = set()
    basis: dict[int, int] = {}
    for value in values:
        while value:
            pivot = value.bit_length() - 1
            if pivot not in pivots:
                pivots.add(pivot)
                basis[pivot] = value
                break
            value ^= basis[pivot]
    return len(pivots)


def compatible(cells: tuple[tuple[int, int], ...]) -> bool:
    return any(
        all(dot(r, row) == t and dot(r, column) == (t ^ 1) for row, column in cells)
        for r in range(1 << N)
        for t in range(2)
    )


def check_witnesses() -> None:
    assert {0, 1}.isdisjoint(Y)
    for kind, values in FAMILY:
        cells = tuple((0, d) for d in values)
        assert xor_sum(values) == TARGET[kind]
        assert (len(values) & 1) == (kind == "R")
        assert rank(values) == len(values)
        assert compatible(cells)
        assert not compatible(cells + (SPOILER,))
        for size in range(len(values)):
            for proper in combinations(values, size):
                assert compatible(tuple((0, d) for d in proper) + (SPOILER,))
    assert all(set(left) & set(right) for (_, left), (_, right) in combinations(FAMILY, 2))


def conditional_mass() -> tuple[Fraction, dict[int, Fraction]]:
    per_r: dict[int, Fraction] = {}
    total = Fraction(0)
    for r in range(1 << N):
        active = tuple(d for d in Y if dot(r, d))
        active_index = {d: i for i, d in enumerate(active)}
        active_witnesses = [
            sum(1 << active_index[d] for d in values)
            for _, values in FAMILY
            if set(values).issubset(active_index)
        ]
        hit_count = sum(
            any(witness & ~retained == 0 for witness in active_witnesses)
            for retained in range(1 << len(active))
        )
        per_r[r] = Fraction(hit_count, 1 << len(active))
        total += per_r[r]
    return total / (1 << N), per_r


def main() -> None:
    check_witnesses()
    mass, per_r = conditional_mass()
    print("N=5; |Y|=", len(Y), "; witnesses=", len(FAMILY))
    print("direct affine feasibility/minimality/target/rank/intersection: passed")
    print("Pr[r,V: exists S subseteq B_r intersection V] =", mass)
    print("after center affine and center-row thinning =", mass / 4)
    print("nonzero r terms:", {r: str(q) for r, q in per_r.items() if q})


if __name__ == "__main__":
    main()
