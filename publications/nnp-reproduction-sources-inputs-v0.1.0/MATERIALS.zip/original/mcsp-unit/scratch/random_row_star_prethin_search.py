#!/usr/bin/env python3
"""Search for a normalized mixed-target pre-thinning counterexample.

Every printed family is checked by construction to be pairwise intersecting.
The reported mass is an exact count over all r in F_2^N; this program is only
a counterexample finder, not an upper-bound proof.
"""

from __future__ import annotations

import argparse
import random
import time

from exact_row_star_candidate_space import candidates


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dimension", type=int, default=5)
    parser.add_argument("--trials", type=int, default=100_000)
    parser.add_argument("--seconds", type=float, default=600.0)
    parser.add_argument("--seed", type=int, default=20260814)
    args = parser.parse_args()
    randomizer = random.Random(args.seed)
    universe, witness_list = candidates(args.dimension, 1, 2)
    masks = [sum(1 << universe.index(value) for value in values) for values, _ in witness_list]
    supports: list[int] = []
    for witness in masks:
        support = 0
        for r in range(1 << args.dimension):
            active = sum(1 << index for index, value in enumerate(universe) if (r & value).bit_count() % 2)
            if witness & ~active == 0:
                support |= 1 << r
        supports.append(support)
    neighbors = [
        [other for other, comparison in enumerate(masks) if other != index and witness & comparison]
        for index, witness in enumerate(masks)
    ]
    best_support = 0
    best_family: list[int] = []
    started = time.monotonic()
    for trial in range(args.trials):
        if time.monotonic() - started >= args.seconds:
            break
        seed = randomizer.randrange(len(masks))
        family = [seed]
        support = supports[seed]
        pool = neighbors[seed].copy()
        while pool:
            sample_count = min(24, len(pool))
            proposal = randomizer.sample(pool, sample_count)
            candidate = max(
                proposal,
                key=lambda index: ((supports[index] & ~support).bit_count(), randomizer.random()),
            )
            family.append(candidate)
            support |= supports[candidate]
            pool = [index for index in pool if index != candidate and masks[index] & masks[candidate]]
            if randomizer.random() < 0.06:
                randomizer.shuffle(pool)
        if support.bit_count() > best_support.bit_count():
            best_support = support
            best_family = family
            print(
                {
                    "trial": trial,
                    "covered_r": support.bit_count(),
                    "denominator": 1 << args.dimension,
                    "family_size": len(family),
                    "elapsed_seconds": round(time.monotonic() - started, 2),
                },
                flush=True,
            )
            for index in family:
                values, kind = witness_list[index]
                print({"type": kind, "values": values}, flush=True)
            if support.bit_count() > (1 << (args.dimension - 1)):
                print("COUNTEREXAMPLE", flush=True)
                return
    print(
        {
            "status": "no counterexample found",
            "covered_r": best_support.bit_count(),
            "denominator": 1 << args.dimension,
            "family_size": len(best_family),
            "trials_completed": trial + 1,
            "elapsed_seconds": round(time.monotonic() - started, 2),
        },
        flush=True,
    )


if __name__ == "__main__":
    main()
