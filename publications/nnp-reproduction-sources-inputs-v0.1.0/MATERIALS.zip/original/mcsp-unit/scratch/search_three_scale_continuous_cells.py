import itertools, math
import numpy as np
from scipy.optimize import linprog

def pats(C,A,n):
 r=[range(C//a+1) for a in A[:n]]
 return np.array([z for z in itertools.product(*r) if any(z) and np.dot(z,A[:n])<=C]).T
def bp(P,x):
 return linprog(np.ones(P.shape[1]),A_ub=-P,b_ub=-x,bounds=(0,None),method='highs').fun
rng=np.random.default_rng(9)
for C in (40,60,80,100,140,200):
 h=C*C//3;U=C+1+int(math.log2(C+1));best=(-1e9,None); best_many=(-1e9,None); feasible=0
 for _ in range(50):
  A=tuple(sorted((int(rng.integers(max(2,C//8),C//3)),int(rng.integers(C//4,C//2+1)),int(rng.integers(C//2+1,5*C//6)))))
  if len(set(A))<3 or A[0]>=math.ceil(h/C):continue
  Ps=[pats(C,A,n) for n in (1,2,3)]
  for _ in range(100):
   x=np.maximum(1,np.floor(rng.dirichlet(np.ones(3))*(2*C*C/3)/np.array(A)).astype(int))
   if np.dot(x,A)>2*C*C/3+2*C:continue
   Bs=[]
   for n in (1,2,3):
    Bs.append(max(bp(Ps[n-1],x[:n]),(h+np.dot(x[:n],A[:n]))/C))
   if Bs[0]<=A[1] or Bs[1]<=A[2]:continue
   feasible+=1
   gap=Bs[2]-U
   if gap>best[0]:best=(gap,(A,tuple(x),tuple(Bs)))
   if x[2]>=int(math.log2(C+1)) and gap>best_many[0]:best_many=(gap,(A,tuple(x),tuple(Bs)))
 print(C,'feasible',feasible,'best',best,'best_many',best_many,flush=True)
