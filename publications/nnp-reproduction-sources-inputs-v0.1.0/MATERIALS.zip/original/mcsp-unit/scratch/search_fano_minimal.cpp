// Exact, low-memory Fano search for minimal affine-collision triples.
// Build: c++ -O3 -std=c++20 search_fano_minimal.cpp -o /tmp/search-fano
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <random>
#include <unordered_map>
#include <vector>

using std::array; using std::uint32_t; using std::uint64_t; using std::vector;
struct Cell { int x, y; };
struct Edge { int a,b,c; unsigned typ; };
constexpr array<array<int,3>,7> FANO{{{{0,1,2}},{{0,3,4}},{{0,5,6}},{{1,3,5}},{{1,4,6}},{{2,3,6}},{{2,4,5}}}};

int gf_rank(vector<uint32_t> a, int width) {
  int k=0;
  for (int bit=width-1; bit>=0; --bit) {
    int p=k; while (p<(int)a.size() && !(a[p]>>bit&1)) ++p;
    if (p==(int)a.size()) continue;
    std::swap(a[k],a[p]);
    for(int i=0;i<(int)a.size();++i) if(i!=k && (a[i]>>bit&1)) a[i]^=a[k];
    ++k;
  }
  return k;
}
bool compatible(const vector<Cell>& cs,int n) {
  vector<uint32_t> a; a.reserve(2*cs.size());
  for(auto [x,y]:cs) { a.push_back(x|(1u<<n)); a.push_back(y|(1u<<n)|(1u<<(n+1))); }
  return gf_rank(a,n+1)==gf_rank(a,n+2);
}
unsigned separator(const vector<Cell>& cs,Cell s,int n) {
  unsigned out=0;
  for(int j=0;j<3;++j) {
    int coeff=j==0 ? (s.x|(1<<n)) : j==1 ? (s.y|(1<<n)) : (s.x^s.y);
    int rhs=j==0 ? 1:0;
    vector<uint32_t> pos,neg;
    for(auto [x,y]:cs) { pos.push_back(x|(1u<<n));pos.push_back(y|(1u<<n)|(1u<<(n+1))); }
    neg=pos;pos.push_back(coeff|(rhs<<(n+1)));neg.push_back(coeff|((rhs^1)<<(n+1)));
    if(gf_rank(pos,n+1)==gf_rank(pos,n+2) && gf_rank(neg,n+1)!=gf_rank(neg,n+2)) out|=1u<<j;
  }
  return out;
}
bool minwit(const vector<Cell>& c,Cell s,int n,unsigned &typ) {
  if(!compatible(c,n))return false; auto d=c;d.push_back(s);if(compatible(d,n))return false;
  for(int i=0;i<3;++i) { vector<Cell> e; for(int j=0;j<3;++j)if(j!=i)e.push_back(c[j]);e.push_back(s);if(!compatible(e,n))return false; }
  return (typ=separator(c,s,n))!=0;
}
uint64_t key3(int a,int b,int c) { if(a>b)std::swap(a,b);if(b>c)std::swap(b,c);if(a>b)std::swap(a,b);return ((uint64_t)a<<32)|((uint64_t)b<<16)|c; }
uint64_t key2(int a,int b) {if(a>b)std::swap(a,b);return ((uint64_t)a<<32)|b;}
bool inleaf(const vector<Cell>& T,int r,int t){for(auto [x,y]:T)if((__builtin_parity(r&x)!=t)||(__builtin_parity(r&y)!=(1^t)))return false;return true;}
std::pair<uint64_t,uint64_t> probability(const vector<vector<Cell>>& fam,int n) {
  int local=1<<(n-1); uint64_t num=0;
  for(int r=1;r<(1<<n);++r)for(int t=0;t<2;++t){
    int ri[32],ci[32];std::fill(ri,ri+32,-1);std::fill(ci,ci+32,-1);int a=0,b=0;
    for(int x=0;x<(1<<n);++x)if(__builtin_parity(r&x)==t)ri[x]=a++;
    for(int y=0;y<(1<<n);++y)if(__builtin_parity(r&y)==(1^t))ci[y]=b++;
    vector<std::pair<uint32_t,uint32_t>> need;
    for(auto&T:fam)if(inleaf(T,r,t)){uint32_t rm=0,cm=0;for(auto[x,y]:T){rm|=1u<<ri[x];cm|=1u<<ci[y];}need.push_back({rm,cm});}
    vector<unsigned char> hit(1u<<(2*local),0); uint32_t full=(1u<<local)-1;
    for(auto[rm,cm]:need) {
      uint32_t ru=(~rm)&full, cv=(~cm)&full;
      for(uint32_t du=ru;;du=(du-1)&ru) { for(uint32_t dv=cv;;dv=(dv-1)&cv) { hit[((rm|du)<<local)|(cm|dv)]=1; if(!dv)break; } if(!du)break; }
    }
    for(auto z:hit) num+=z;
  }
  return {num,1ull<<(n+1+2*local)};
}
int main(int argc,char**argv){
 int n=argc>1?std::stoi(argv[1]):4; long long trials=argc>2?std::stoll(argv[2]):2000000; uint64_t seed=argc>3?std::stoull(argv[3]):20260813;
 int N=1<<n; Cell s{0,1}; vector<Cell> pts;for(int x=0;x<N;++x)for(int y=0;y<N;++y)if(x!=y&&!(x==s.x&&y==s.y))pts.push_back({x,y});
 vector<Edge> es; std::unordered_map<uint64_t,unsigned> edge_type; vector<vector<int>> through(pts.size());
 for(int a=0;a<(int)pts.size();++a)for(int b=a+1;b<(int)pts.size();++b)for(int c=b+1;c<(int)pts.size();++c){vector<Cell>T{pts[a],pts[b],pts[c]};unsigned typ;if(minwit(T,s,n,typ)){es.push_back({a,b,c,typ});edge_type[key3(a,b,c)]=typ;through[a].push_back(es.size()-1);through[b].push_back(es.size()-1);through[c].push_back(es.size()-1);}}
 std::cerr<<"n="<<n<<" cells="<<pts.size()<<" edges="<<es.size()<<"\n";
 std::mt19937_64 rng(seed);uint64_t bestn=0,bestd=1; vector<int> bestp; unsigned besttyp=0;
 // The common-kernel branch is the densest easy intersecting construction.
 for(unsigned ty : {1u,2u,4u}) {
   vector<std::pair<int,int>> deg; for(int v=0;v<(int)pts.size();++v){int d=0;for(int ei:through[v])if(es[ei].typ==ty)++d;deg.push_back({d,v});}
   std::sort(deg.rbegin(),deg.rend());
   for(int q=0;q<10;++q){int v=deg[q].second;vector<vector<Cell>>fam;for(int ei:through[v])if(es[ei].typ==ty){auto e=es[ei];fam.push_back({pts[e.a],pts[e.b],pts[e.c]});}auto[num,den]=probability(fam,n);std::cout<<"STAR type="<<ty<<" degree="<<fam.size()<<" at=("<<pts[v].x<<","<<pts[v].y<<") prob="<<num<<"/"<<den<<"\n";if(num*bestd>bestn*den){bestn=num;bestd=den;}}
 }
 for(long long it=0;it<trials;++it){
  const Edge&e0=es[rng()%es.size()];array<int,7> p{e0.a,e0.b,e0.c,-1,-1,-1,-1};
  auto pick=[&](int common,const array<int,7>&cur){ vector<int> cand; for(int ei:through[common]){auto e=es[ei];int z[3]{e.a,e.b,e.c};bool good=true;for(int q:z)for(int old:cur)if(old==q&&old!=common)good=false;if(good)cand.push_back(ei);}if(cand.empty())return -1;return cand[rng()%cand.size()];};
  int e1=pick(p[0],p);if(e1<0)continue;auto A=es[e1];int q1[3]{A.a,A.b,A.c};for(int q:q1)if(q!=p[0]){if(p[3]<0)p[3]=q;else p[4]=q;}
  int e2=pick(p[0],p);if(e2<0)continue;auto B=es[e2];int q2[3]{B.a,B.b,B.c};for(int q:q2)if(q!=p[0]){if(p[5]<0)p[5]=q;else p[6]=q;}
  if(std::find(p.begin(),p.end(),-1)!=p.end())continue;
  unsigned common=~0u;bool ok=true;for(auto line:FANO){auto f=edge_type.find(key3(p[line[0]],p[line[1]],p[line[2]]));if(f==edge_type.end()){ok=false;break;}common&=f->second;} if(!ok||!common)continue;
  vector<vector<Cell>>fam;for(auto line:FANO)fam.push_back({pts[p[line[0]]],pts[p[line[1]]],pts[p[line[2]]]});auto[num,den]=probability(fam,n);if(num*bestd>bestn*den){bestn=num;bestd=den;bestp.assign(p.begin(),p.end());besttyp=common;std::cout<<"BEST "<<num<<"/"<<den<<" separator="<<besttyp<<" points";for(int v:p)std::cout<<" ("<<pts[v].x<<","<<pts[v].y<<")";std::cout<<" iter="<<it<<"\n";}
 }
 std::cout<<"FINAL "<<bestn<<"/"<<bestd<<" seed="<<seed<<" trials="<<trials<<"\n";
}
