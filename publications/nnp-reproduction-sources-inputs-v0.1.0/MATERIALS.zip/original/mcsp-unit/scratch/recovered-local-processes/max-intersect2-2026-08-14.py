import itertools, sys
from functools import lru_cache
from collections import defaultdict

def dot(r,x): return (r&x).bit_count()%2

def run(N,X,Y):
 cells=[(x,y) for x in X for y in Y]; m=len(cells); idx={c:i for i,c in enumerate(cells)}
 cnt=defaultdict(float); sample_count=0
 for r in range(1<<N):
  for b in range(2):
   rows=[i for i,x in enumerate(X) if dot(r,x)^b==0]
   cols=[j for j,y in enumerate(Y) if dot(r,y)^b==1]
   w0=1/((1<<(N+1))*(1<<len(rows))*(1<<len(cols)))
   for um in range(1<<len(rows)):
    for vm in range(1<<len(cols)):
     W=0
     for ii,i in enumerate(rows):
      if um>>ii&1:
       for jj,j in enumerate(cols):
        if vm>>jj&1: W|=1<<idx[(X[i],Y[j])]
     cnt[W]+=w0; sample_count+=1
 subsets=list(range(1,1<<m))
 # Sort larger first? clique search
 # only minimal subsets? For any family, if S subset T and both, T redundant. Maximum event can use antichain minimal sets; intersecting condition on minimal sets.
 # enumerate cliques via pivot Bron Kerbosch and evaluate union upsets
 compat={s:0 for s in subsets}
 for i,s in enumerate(subsets):
  mask=0
  for t in subsets[i+1:]:
   if s&t: mask|=1<<t
  compat[s]=mask
 # use recursive growing index to avoid duplicates, with memo maybe
 best=(0,[]); nodes=0
 # enumerate all cliques with candidate list bit mask and monotonic lower bound
 allmask=(1<<len(subsets))-1
 def prob(fam):
  return sum(w for W,w in cnt.items() if any((W&s)==s for s in fam))
 def rec(cand,fam):
  nonlocal best,nodes
  nodes+=1
  p=prob(fam)
  if p>best[0]+1e-12:
   best=(p,fam.copy()); print('best',p,'size',len(fam),'nodes',nodes)
  while cand:
   low=cand & -cand; cand-=low; idxv=low.bit_length()-1; s=subsets[idxv]
   # candidates after idx; compat all by direct mask of indices > idx
   new=0
   rest=cand
   while rest:
    bit=rest & -rest; rest-=bit; j=bit.bit_length()-1
    if subsets[j]&s: new|=bit
   rec(new,fam+[s])
 # m up to 7
 if m>7:
  print('skip m',m); return
 rec(allmask,[])
 print('RESULT N',N,'m',m,'samples',sample_count,'nodes',nodes,'best',best[0],'fam',best[1])
for X,Y in [([0],list(range(1,8))),([0,1],list(range(2,8))),([0,1,2],[3,4,5])]:
 run(3,X,Y)
