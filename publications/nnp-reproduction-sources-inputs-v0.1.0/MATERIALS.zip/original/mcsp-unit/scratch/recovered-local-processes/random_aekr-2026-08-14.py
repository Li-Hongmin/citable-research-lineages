from itertools import combinations
import random, numpy as np, time
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix

def parity(x): return x.bit_count() & 1

def solve(X,Y,n,s,maxk=4,limit=3):
 C=[(x,y) for x in X for y in Y]; si=C.index(s); M=len(C)
 leaves=[]
 for r in range(1<<n):
  for t in (0,1): leaves.append({i for i,(x,y) in enumerate(C) if parity(r&x)==t and parity(r&y)==1-t})
 inds=[i for i in range(M) if i!=si]; cands=[]
 for k in range(2,maxk+1):
  for tup in combinations(inds,k):
   T=set(tup)
   if any(T <= L for L in leaves) and not any(T|{si} <= L for L in leaves): cands.append(T)
 if not cands: return 0,[]
 probs={}
 for L in leaves:
  rows=sorted({C[i][0] for i in L}); cols=sorted({C[i][1] for i in L})
  for mr in range(1<<len(rows)):
   U={rows[j] for j in range(len(rows)) if mr>>j&1}
   for mc in range(1<<len(cols)):
    V={cols[j] for j in range(len(cols)) if mc>>j&1}
    R=frozenset(i for i,(x,y) in enumerate(C) if i in L and x in U and y in V)
    probs[R]=probs.get(R,0)+1/(2**(n+1+len(rows)+len(cols)))
 events=[]
 for R,p in probs.items():
  ev=[i for i,T in enumerate(cands) if T <= R]
  if ev: events.append((ev,p))
 m=len(cands); q=len(events)
 rows=[]; lo=[]; hi=[]
 for i in range(m):
  for j in range(i):
   if not cands[i]&cands[j]: rows.append({i:1,j:1}); lo.append(-np.inf); hi.append(1)
 for jj,(ev,p) in enumerate(events): rows.append({m+jj:1,**{i:-1 for i in ev}}); lo.append(-np.inf); hi.append(0)
 A=lil_matrix((len(rows),m+q))
 for ri,row in enumerate(rows):
  for ci,v in row.items(): A[ri,ci]=v
 obj=np.zeros(m+q)
 for jj,(ev,p) in enumerate(events): obj[m+jj]=-p
 res=milp(obj,integrality=np.r_[np.ones(m),np.zeros(q)],bounds=Bounds(np.zeros(m+q),np.ones(m+q)),constraints=LinearConstraint(A.tocsr(),lo,hi),options={'time_limit':limit,'mip_rel_gap':0})
 chosen=[cands[i] for i,x in enumerate(res.x[:m]) if x>.5]
 return -res.fun, chosen

for n in [4,5]:
 vals=list(range(1<<n)); best=0
 for trial in range(100):
  sx=random.randint(3,7); sy=random.randint(2,5)
  X=random.sample(vals,sx); Y=random.sample([a for a in vals if a not in X],sy); s=(random.choice(X),random.choice(Y))
  t=time.time(); val,f=solve(X,Y,n,s,maxk=4,limit=2)
  if val>best:
   best=val; print('n',n,'trial',trial,'val',val,'target',1/16,'sizes',sx,sy,'dt',round(time.time()-t,2),'X',X,'Y',Y,'s',s,'nfam',len(f),flush=True)
  if val>1/16+1e-8:
   print('FOUND',n,val,X,Y,s,[[ (X:=None) ]],flush=True);raise SystemExit
 print('DONE',n,best,flush=True)
