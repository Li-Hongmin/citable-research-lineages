from itertools import combinations
import numpy as np
from scipy.optimize import milp,LinearConstraint,Bounds
from scipy.sparse import lil_matrix

def parity(x):return x.bit_count()&1

def solve(X,Y,n,kmax=3,time=60):
 C=[(x,y) for x in X for y in Y]; mC=len(C)
 leaves=[]
 for z in range(1<<(n+1)):
  r,t=z>>1,z&1
  L=sum(1<<i for i,(x,y) in enumerate(C) if parity(r&x)==t and parity(r&y)==1-t)
  leaves.append(L)
 cand=[]
 for k in range(1,kmax+1):
  for I in combinations(range(mC),k):
   cand.append(sum(1<<i for i in I))
 samples={}
 for L in leaves:
  rows=sorted({C[i][0] for i in range(mC) if L>>i&1}); cols=sorted({C[i][1] for i in range(mC) if L>>i&1})
  w=1/((1<<(n+1))*(1<<len(rows))*(1<<len(cols)))
  for mr in range(1<<len(rows)):
   U={rows[j] for j in range(len(rows)) if mr>>j&1}
   for mc in range(1<<len(cols)):
    V={cols[j] for j in range(len(cols)) if mc>>j&1}
    R=sum(1<<i for i,(x,y) in enumerate(C) if L>>i&1 and x in U and y in V)
    samples[R]=samples.get(R,0)+w
 samples=list(samples.items());q=len(samples);m=len(cand)
 rows=[];lo=[];hi=[]
 for i in range(m):
  for j in range(i):
   if cand[i]&cand[j]==0:
    rows.append({i:1,j:1});lo.append(-np.inf);hi.append(1)
 for j,(R,w) in enumerate(samples):
  row={m+j:1}
  for i,T in enumerate(cand):
   if T&~R==0:row[i]=-1
  rows.append(row);lo.append(-np.inf);hi.append(0)
 A=lil_matrix((len(rows),m+q))
 for ri,row in enumerate(rows):
  for ci,v in row.items():A[ri,ci]=v
 obj=np.r_[np.zeros(m),[-w for R,w in samples]]
 res=milp(obj,integrality=np.r_[np.ones(m),np.zeros(q)],bounds=Bounds(np.zeros(m+q),np.ones(m+q)),constraints=LinearConstraint(A.tocsr(),np.array(lo),np.array(hi)),options={'time_limit':time,'mip_rel_gap':0})
 ch=[cand[i] for i in range(m) if res.x[i]>.5]
 return -res.fun,[[C[i] for i in range(mC) if T>>i&1] for T in ch]
