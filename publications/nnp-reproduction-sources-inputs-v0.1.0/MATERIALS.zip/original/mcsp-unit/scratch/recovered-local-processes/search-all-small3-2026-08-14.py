from itertools import combinations, product
import networkx as nx, random

def span(vals):
 if not vals:return set()
 b=vals[0];out={0}
 for d in [v^b for v in vals[1:]]:out|={u^d for u in list(out)}
 return {b^u for u in out}
def coll(T,s):
 C=list(T)+[s];return bool(span([x for x,y in C])&span([y for x,y in C]))
def best_for(X,Y,s,maxk=2):
 C=[(x,y) for x in X for y in Y]
 zlist=list(product(range(1<<N),range(2)))
 leaves=[]
 for r,t in zlist:
  A=[x for x in X if ((r&x).bit_count()&1)==t]
  B=[y for y in Y if ((r&y).bit_count()&1)==1^t]
  leaves.append((A,B))
 V=[frozenset(T) for k in range(2,maxk+1) for T in combinations([c for c in C if c!=s],k) if coll(T,s)]
 if not V:return (0,[])
 G=nx.Graph();G.add_nodes_from(range(len(V)))
 for i in range(len(V)):
  for j in range(i):
   if V[i]&V[j]:G.add_edge(i,j)
 best=(0,None)
 for cl in nx.find_cliques(G):
  fam=[V[i] for i in cl];total=0
  for A,B in leaves:
   fs=[T for T in fam if all(x in A and y in B for x,y in T)]
   if not fs:continue
   p=0;den=1<<(len(A)+len(B))
   for ma in range(1<<len(A)):
    Ar={A[i] for i in range(len(A)) if ma>>i&1}
    for mb in range(1<<len(B)):
     Br={B[i] for i in range(len(B)) if mb>>i&1}
     if any(all(x in Ar and y in Br for x,y in T) for T in fs):p+=1
   total += p/den
  total/=len(zlist)
  if total>best[0]+1e-12:best=(total,fam)
 return best

N=3; U=list(range(1<<N)); rng=random.Random(0)
# random disjoint X,Y; prioritize sizes >=2
best=(0,None)
for trial in range(50):
 perm=rng.sample(U,len(U)); a=rng.randint(2,5); b=rng.randint(2,5)
 X=perm[:a];Y=perm[a:a+b]
 for s in [(x,y) for x in X for y in Y]:
  p,f=best_for(X,Y,s,3)
  if p>best[0]:
   best=(p,(X,Y,s,f)); print('BEST',best)
print('FINAL',best)
