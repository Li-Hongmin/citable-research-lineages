"""Exhaustive q=4,8 check for the two-unit four-point quotient formula."""

from collections import Counter
from itertools import combinations


def gf_mul(a, b, n):
    # Primitive irreducibles x^2+x+1 and x^3+x+1.
    mod = {2: 0b111, 3: 0b1011}[n]
    out = 0
    aa, bb = a, b
    while bb:
        if bb & 1:
            out ^= aa
        bb >>= 1
        aa <<= 1
        if aa & (1 << n):
            aa ^= mod
    return out


def run(n):
    q = 1 << n
    points = [(x, y) for x in range(q) for y in range(q)]
    pidx = {p: i for i, p in enumerate(points)}
    add = lambda u, v: (u[0] ^ v[0], u[1] ^ v[1])
    # All q+1 F_q-lines in F_q^2; canonical direction (1,m), plus (0,1).
    dirs = [(1, m) for m in range(q)] + [(0, 1)]
    lines = []
    for d in dirs:
        lines.append(tuple(sorted(pidx[(gf_mul(t, d[0], n), gf_mul(t, d[1], n))] for t in range(q))))

    # Four-point H = span_F2{(1,0),(0,1)}.
    H = {pidx[p] for p in [(0, 0), (1, 0), (0, 1), (1, 1)]}
    cosets = {}
    reps = []
    for x in range(q):
        for y in range(q):
            w = pidx[(x, y)]
            if w in cosets:
                continue
            C = frozenset(pidx[add((x, y), points[h])] for h in H)
            r = min(C)
            reps.append(r)
            for z in C:
                cosets[z] = r
    reps.sort()
    ridx = {r: i for i, r in enumerate(reps)}
    Q = len(reps)
    # Quotient group operation and coefficient-mask multiplication.
    qadd = [[0] * Q for _ in range(Q)]
    for i, r in enumerate(reps):
        a = points[r]
        for j, s in enumerate(reps):
            b = points[s]
            qadd[i][j] = ridx[cosets[pidx[add(a, b)]]]

    def image_masks(line):
        # All odd source subsets, mapped to quotient coset parity.
        out = Counter()
        ell = len(line)
        for mask in range(1 << ell):
            if mask.bit_count() & 1 == 0:
                continue
            z = 0
            for k, w in enumerate(line):
                if (mask >> k) & 1:
                    z ^= 1 << ridx[cosets[w]]
            out[z] += 1
        return out

    def mul_mask(a, b):
        out = 0
        aa = a
        while aa:
            low = aa & -aa
            i = low.bit_length() - 1
            bb = b
            while bb:
                low2 = bb & -bb
                j = low2.bit_length() - 1
                out ^= 1 << qadd[i][j]
                bb ^= low2
            aa ^= low
        return out

    images = [image_masks(L) for L in lines]
    total_pairs = (1 << (q - 1)) ** 2
    rows = []
    for i in range(len(lines)):
        for j in range(len(lines)):
            good = 0
            for x, cx in images[i].items():
                for y, cy in images[j].items():
                    if mul_mask(x, y) == 1:  # identity coefficient mask
                        good += cx * cy
            h1 = len(set(lines[i]) & H)
            h2 = len(set(lines[j]) & H)
            if i == j:
                predicted = 2 ** (1 - q // h1)
            else:
                tsize = 4 // (h1 * h2)
                predicted = 2 ** (tsize + 1 - q // h1 - q // h2)
            actual = good / total_pairs
            if actual != predicted:
                raise AssertionError((n, i, j, h1, h2, actual, predicted))
            rows.append((i == j, h1, h2, actual))
    print(f"q={q}: Q-size={Q}, lines={len(lines)}, ordered-pairs={len(rows)}; all exact")
    for key in sorted(set((same, h1, h2) for same, h1, h2, _ in rows)):
        vals = {p for same, h1, h2, p in rows if (same, h1, h2) == key}
        print("  ", key, vals)


if __name__ == "__main__":
    run(2)
    run(3)
