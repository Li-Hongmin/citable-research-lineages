#!/usr/bin/env python3
"""Independent exhaustive check of the note-063 N=5 family, including V.

This is disposable exploration.  It deliberately represents affine
compatibility by enumerating (r,t), and the thinning experiment by the full
2^Y cube, rather than reusing the permanent bundle's linear-system routine.
"""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations


N = 5
X0 = 0
SPOILER = (1, 2)
FAMILY = (
    ("R", (8, 13, 4)),
    ("R", (16, 4, 21)),
    ("R", (4, 24, 29)),
    ("P", (8, 16, 6, 29)),
    ("P", (8, 6, 24, 21)),
    ("P", (16, 6, 13, 24)),
    ("P", (6, 13, 29, 21)),
    ("C", (8, 16, 29, 7)),
    ("C", (8, 24, 21, 7)),
    ("C", (16, 13, 24, 7)),
    ("C", (13, 29, 21, 7)),
)
Y = (8, 16, 6, 13, 4, 24, 29, 21, 2, 7)
Y_INDEX = {d: index for index, d in enumerate(Y)}
TARGET = {"R": 1, "C": 2, "P": 3}


def dot(r: int, x: int) -> int:
    return (r & x).bit_count() & 1


def xor_sum(values: tuple[int, ...]) -> int:
    out = 0
    for value in values:
        out ^= value
    return out


def rank(values: tuple[int, ...]) -> int:
    basis: dict[int, int] = {}
    for value in values:
        while value:
            pivot = value.bit_length() - 1
            if pivot not in basis:
                basis[pivot] = value
                break
            value ^= basis[pivot]
    return len(basis)


def affine_compatible(cells: tuple[tuple[int, int], ...]) -> bool:
    """Exists (r,t) with r.x+t=0 and r.y+t=1 for every cell (x,y)."""
    return any(
        all(dot(r, x) == t and dot(r, y) == (t ^ 1) for x, y in cells)
        for r in range(1 << N)
        for t in range(2)
    )


def all_proper_subsets(values: tuple[int, ...]):
    for size in range(len(values)):
        yield from combinations(values, size)


def verify_structure() -> None:
    assert set((X0, SPOILER[0])).isdisjoint(Y)
    for kind, values in FAMILY:
        witness = tuple((X0, d) for d in values)
        assert xor_sum(values) == TARGET[kind]
        assert (len(values) & 1) == (kind == "R")
        assert rank(values) == len(values)
        assert affine_compatible(witness)
        assert not affine_compatible(witness + (SPOILER,))
        assert all(
            affine_compatible(tuple((X0, d) for d in subset) + (SPOILER,))
            for subset in all_proper_subsets(values)
        )
    assert all(set(left) & set(right) for (_, left), (_, right) in combinations(FAMILY, 2))


def mask(values: tuple[int, ...]) -> int:
    return sum(1 << Y_INDEX[d] for d in values)


def full_mass() -> tuple[Fraction, dict[int, Fraction]]:
    witness_masks = tuple(mask(values) for _, values in FAMILY)
    total_hits = 0
    contribution: dict[int, Fraction] = {}
    for r in range(1 << N):
        active = sum(1 << Y_INDEX[d] for d in Y if dot(r, d))
        hit = 0
        for v in range(1 << len(Y)):
            retained_active = active & v
            if any(witness & ~retained_active == 0 for witness in witness_masks):
                hit += 1
        total_hits += hit
        contribution[r] = Fraction(hit, 1 << len(Y))
    return Fraction(total_hits, (1 << N) * (1 << len(Y))), contribution


def main() -> None:
    verify_structure()
    mass, contribution = full_mass()
    print("N", N, "Y", Y, "family_size", len(FAMILY))
    print("all affine/minimal/three-target/rank/intersection checks: passed")
    print("Pr[r,V: exists S subseteq B_r intersection V] =", mass)
    print("full row-star AEKR factor (center affine+retention) =", mass / 4)
    print("nonzero r contributions =", {r: str(q) for r, q in contribution.items() if q})


if __name__ == "__main__":
    main()
