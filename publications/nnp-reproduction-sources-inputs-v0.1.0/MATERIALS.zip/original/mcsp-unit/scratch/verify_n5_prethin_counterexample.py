#!/usr/bin/env python3
"""Exact verification of the N=5 normalized mixed-target pre-thinning example."""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations


N = 5
X = (0, 1)
SPOILER = (1, 2)
FAMILY = (
    ("C", (8, 14, 26, 30)),
    ("R", (6, 25, 30)),
    ("R", (14, 22, 25)),
    ("R", (9, 22, 30)),
    ("R", (6, 9, 14)),
    ("C", (6, 8, 22, 26)),
    ("C", (6, 12, 22, 30)),
    ("P", (6, 8, 22, 27)),
    ("P", (8, 14, 27, 30)),
    ("C", (6, 14, 22, 28)),
    ("P", (6, 14, 22, 29)),
    ("C", (4, 14, 22, 30)),
    ("P", (6, 14, 21, 30)),
    ("P", (5, 14, 22, 30)),
    ("P", (6, 13, 22, 30)),
    ("C", (6, 14, 20, 30)),
)
Y = tuple(sorted({SPOILER[1], *(value for _, values in FAMILY for value in values)}))


def parity(value: int) -> int:
    return value.bit_count() & 1


def xor_all(values: tuple[int, ...]) -> int:
    result = 0
    for value in values:
        result ^= value
    return result


def rank(values: tuple[int, ...]) -> int:
    basis: dict[int, int] = {}
    for value in values:
        reduced = value
        while reduced:
            pivot = reduced.bit_length() - 1
            if pivot not in basis:
                basis[pivot] = reduced
                break
            reduced ^= basis[pivot]
    return len(basis)


def leaf_contains(cells: tuple[tuple[int, int], ...], r: int, t: int) -> bool:
    return all(parity(r & row) == t and parity(r & column) == 1 - t for row, column in cells)


def compatible(cells: tuple[tuple[int, int], ...]) -> bool:
    return any(leaf_contains(cells, r, t) for r in range(1 << N) for t in range(2))


def collision(cells: tuple[tuple[int, int], ...]) -> bool:
    return not compatible(cells)


def family_mass() -> tuple[Fraction, Fraction, dict[int, Fraction]]:
    per_r: dict[int, Fraction] = {}
    prethin_count = 0
    for r in range(1 << N):
        active = [value for value in Y if parity(r & value)]
        active_set = set(active)
        active_witnesses = [values for _, values in FAMILY if set(values) <= active_set]
        if active_witnesses:
            prethin_count += 1
        hits = 0
        for bits in range(1 << len(active)):
            retained = {active[index] for index in range(len(active)) if (bits >> index) & 1}
            if any(set(values) <= retained for values in active_witnesses):
                hits += 1
        per_r[r] = Fraction(hits, 1 << len(active))
    return sum(per_r.values(), Fraction()) / (1 << N), Fraction(prethin_count, 1 << N), per_r


def main() -> None:
    witnesses = [tuple((0, value) for value in values) for _, values in FAMILY]
    print({"X": X, "Y": Y, "spoiler": SPOILER, "family_size": len(witnesses)})
    print("X_disjoint_Y", not set(X) & set(Y))
    checks = []
    for index, ((kind, values), witness) in enumerate(zip(FAMILY, witnesses), start=1):
        minimal = all(compatible(tuple(cell for position, cell in enumerate(witness) if position != removed) + (SPOILER,)) for removed in range(len(witness)))
        checks.append(
            {
                "index": index,
                "type": kind,
                "values": values,
                "xor": xor_all(values),
                "size": len(values),
                "rank": rank(values),
                "compatible": compatible(witness),
                "collision_with_spoiler": collision(witness + (SPOILER,)),
                "minimal": minimal,
            }
        )
    print("witness_checks", checks)
    print("pairwise_intersecting", all(set(left) & set(right) for _, left in FAMILY for _, right in FAMILY if left < right))
    mass, prethin, per_r = family_mass()
    print("prethin_mass", prethin)
    print("conditional_row_star_mass", mass)
    print("full_AEKR_row_star_mass", mass / 4)
    print("r_contributions", {r: str(value) for r, value in per_r.items() if value})


if __name__ == "__main__":
    main()
