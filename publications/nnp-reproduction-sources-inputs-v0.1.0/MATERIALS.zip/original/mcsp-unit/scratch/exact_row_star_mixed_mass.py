#!/usr/bin/env python3
"""Exact exhaustive mass for normalized row-star mixed-target witnesses.

The normalized instance has x_0=0, spoiler row a and spoiler column b.
Every candidate is a minimal binary circuit deletion with target a, b, or
a^b.  Maximal intersecting families are enumerated directly, so no floating
point optimizer is used.  This is an exploratory falsification tool, not a
general proof bundle.
"""

from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction

from exact_row_star_candidate_space import candidates


def active_mask(r: int, universe: list[int]) -> int:
    return sum(1 << index for index, value in enumerate(universe) if (r & value).bit_count() % 2)


def conditional_hit_weight(family: tuple[int, ...], active: int) -> Fraction:
    """Exact Pr_V[exists S in family: S subseteq active cap V]."""
    available = [index for index in range(active.bit_length()) if (active >> index) & 1]
    hit = 0
    total = 1 << len(available)
    for retained_index in range(total):
        retained = sum(1 << available[position] for position in range(len(available)) if (retained_index >> position) & 1)
        if any(candidate & ~retained == 0 for candidate in family):
            hit += 1
    return Fraction(hit, total)


def family_mass(family: tuple[int, ...], active_masks: list[int]) -> Fraction:
    return sum((conditional_hit_weight(family, active) for active in active_masks), Fraction()) / len(active_masks)


def prethin_mass(family: tuple[int, ...], active_masks: list[int]) -> Fraction:
    return Fraction(sum(any(candidate & ~active == 0 for candidate in family) for active in active_masks), len(active_masks))


def bron_kerbosch(
    clique: tuple[int, ...],
    candidates_left: int,
    excluded: int,
    neighbor_masks: list[int],
):
    if candidates_left == 0 and excluded == 0:
        yield clique
        return
    union = candidates_left | excluded
    pivot = max(
        (index for index in range(len(neighbor_masks)) if (union >> index) & 1),
        key=lambda index: (candidates_left & neighbor_masks[index]).bit_count(),
        default=None,
    )
    extension = candidates_left if pivot is None else candidates_left & ~neighbor_masks[pivot]
    while extension:
        low_bit = extension & -extension
        vertex = low_bit.bit_length() - 1
        yield from bron_kerbosch(
            clique + (vertex,),
            candidates_left & neighbor_masks[vertex],
            excluded & neighbor_masks[vertex],
            neighbor_masks,
        )
        candidates_left &= ~low_bit
        excluded |= low_bit
        extension &= ~low_bit


def render(mask: int, universe: list[int]) -> tuple[int, ...]:
    return tuple(universe[index] for index in range(len(universe)) if (mask >> index) & 1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dimension", type=int, default=4)
    parser.add_argument("--a", type=int, default=1)
    parser.add_argument("--b", type=int, default=2)
    parser.add_argument("--max-candidates", type=int, default=42)
    args = parser.parse_args()
    universe, witness_list = candidates(args.dimension, args.a, args.b)
    if len(witness_list) > args.max_candidates:
        raise SystemExit(f"candidate count {len(witness_list)} exceeds --max-candidates")
    witness_masks = tuple(sum(1 << universe.index(value) for value in values) for values, _ in witness_list)
    types = tuple(kind for _, kind in witness_list)
    neighbor_masks: list[int] = []
    for index, witness in enumerate(witness_masks):
        neighbor_masks.append(
            sum(1 << other for other, comparison in enumerate(witness_masks) if other != index and witness & comparison)
        )
    active_masks = [active_mask(r, universe) for r in range(1 << args.dimension)]
    best_mass = Fraction(-1)
    best_family: tuple[int, ...] = ()
    best_no_common_mass = Fraction(-1)
    best_no_common_family: tuple[int, ...] = ()
    best_prethin = Fraction(-1)
    best_prethin_family: tuple[int, ...] = ()
    count = 0
    sizes = Counter()
    full = (1 << len(witness_masks)) - 1
    for family_indices in bron_kerbosch((), full, 0, neighbor_masks):
        count += 1
        family = tuple(witness_masks[index] for index in family_indices)
        mass = family_mass(family, active_masks)
        sizes[len(family)] += 1
        if mass > best_mass:
            best_mass = mass
            best_family = family_indices
        prethin = prethin_mass(family, active_masks)
        if prethin > best_prethin:
            best_prethin = prethin
            best_prethin_family = family_indices
        common = family[0]
        for witness in family[1:]:
            common &= witness
        if common == 0 and mass > best_no_common_mass:
            best_no_common_mass = mass
            best_no_common_family = family_indices
    print(
        {
            "dimension": args.dimension,
            "a": args.a,
            "b": args.b,
            "candidate_count": len(witness_masks),
            "maximal_intersecting_families": count,
            "clique_sizes": dict(sorted(sizes.items())),
            "best_mass": str(best_mass),
            "best_no_common_mass": str(best_no_common_mass),
            "best_prethin_mass": str(best_prethin),
            "target": "1/4",
        },
        flush=True,
    )
    for label, family_indices in (("BEST", best_family), ("NO_COMMON", best_no_common_family), ("PRETHIN", best_prethin_family)):
        print(label, flush=True)
        for index in family_indices:
            print({"type": types[index], "values": render(witness_masks[index], universe)}, flush=True)


if __name__ == "__main__":
    main()
