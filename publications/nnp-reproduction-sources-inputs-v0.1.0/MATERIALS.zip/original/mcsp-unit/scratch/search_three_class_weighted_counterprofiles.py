"""Exploratory exact search for three-size weighted bin-packing profiles.

Finite hits or misses are route-selection evidence only, not a proof.
"""

from __future__ import annotations

import itertools
import math
import random

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp


def patterns(capacity: int, sizes: tuple[int, ...]) -> np.ndarray:
    rows = []
    limits = [capacity // size for size in sizes]
    for row in itertools.product(*(range(limit + 1) for limit in limits)):
        if any(row) and sum(x * size for x, size in zip(row, sizes)) <= capacity:
            rows.append(row)
    return np.asarray(rows, dtype=float).T


def core_opt(capacity: int, sizes: tuple[int, ...], counts: tuple[int, ...]) -> int:
    matrix = patterns(capacity, sizes)
    result = milp(
        c=np.ones(matrix.shape[1]),
        integrality=np.ones(matrix.shape[1]),
        bounds=Bounds(0, np.inf),
        constraints=LinearConstraint(matrix, np.asarray(counts), np.inf),
        options={"time_limit": 2.0},
    )
    if not result.success:
        raise RuntimeError(result.message)
    return math.ceil(result.fun - 1e-7)


def endpoint(capacity: int, head: int, sizes: tuple[int, ...], counts: tuple[int, ...]) -> int:
    core_bins = core_opt(capacity, sizes, counts)
    volume_bins = math.ceil((head + sum(s * n for s, n in zip(sizes, counts))) / capacity)
    return max(core_bins, volume_bins)


def activity(endpoint_bins: int, sizes: tuple[int, ...], counts: tuple[int, ...], oversized: int, capacity: int) -> float:
    terms = [math.ldexp(n, endpoint_bins - size) for size, n in zip(sizes, counts) if n]
    if oversized:
        terms.append(math.ldexp(oversized, endpoint_bins - (capacity + 1)))
    return sum(terms)


def search(seed: int = 797) -> None:
    rng = random.Random(seed)
    for capacity in (20, 24, 28, 32, 36, 40):
        d = (capacity + 2) ** 2
        head = d // 3
        oversized = 1
        nonlinear = d - head - oversized * (capacity + 1)
        ceiling = capacity + 1 + int(math.log2(capacity + 1))
        head_bins = math.ceil(head / capacity)
        best_ratio = 0.0
        checked_crossings = 0
        for _ in range(200):
            sizes = tuple(sorted(rng.sample(range(2, capacity + 1), 3)))
            weights = [rng.expovariate(1.0) for _ in range(3)]
            budget = rng.randint(max(capacity, nonlinear // 2), nonlinear)
            counts = tuple(max(1, int(budget * w / sum(weights) / size)) for w, size in zip(weights, sizes))
            while sum(s * n for s, n in zip(sizes, counts)) > nonlinear:
                j = max(range(3), key=lambda i: sizes[i] * counts[i])
                if counts[j] == 1:
                    break
                counts = counts[:j] + (counts[j] - 1,) + counts[j + 1 :]
            endpoints = [head_bins]
            for i in range(1, 4):
                endpoints.append(endpoint(capacity, head, sizes[:i], counts[:i]))
            if endpoints[-1] <= ceiling:
                continue
            checked_crossings += 1
            ratios = []
            for i in range(4):
                tail_sizes = sizes[i:]
                tail_counts = counts[i:]
                ratios.append(activity(endpoints[i], tail_sizes, tail_counts, oversized, capacity) / d)
            score = min(ratios)
            best_ratio = max(best_ratio, score)
            if score > 1.0:
                print("HIT", capacity, sizes, counts, endpoints, ratios)
                return
        print("C", capacity, "crossings", checked_crossings, "best_min_ratio", best_ratio)


if __name__ == "__main__":
    search()
