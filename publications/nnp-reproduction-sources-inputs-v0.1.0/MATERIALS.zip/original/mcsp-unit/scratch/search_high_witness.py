#!/usr/bin/env python3
"""Low-memory exact search for high-order AEKR thinning families over F_2^n.

The search is intentionally restricted to minimal collision witnesses and
pairwise-intersecting Fano-line families.  It prints reproducible records only.
"""
from __future__ import annotations

import argparse
import itertools
import random
from collections import defaultdict


FANO = ((0, 1, 2), (0, 3, 4), (0, 5, 6),
        (1, 3, 5), (1, 4, 6), (2, 3, 6), (2, 4, 5))


def rank(rows: list[int], width: int) -> int:
    rows = rows[:]
    ans = 0
    for bit in range(width - 1, -1, -1):
        pivot = next((i for i in range(ans, len(rows)) if rows[i] >> bit & 1), None)
        if pivot is None:
            continue
        rows[ans], rows[pivot] = rows[pivot], rows[ans]
        for i in range(len(rows)):
            if i != ans and rows[i] >> bit & 1:
                rows[i] ^= rows[ans]
        ans += 1
    return ans


def compatible(cells, n: int) -> bool:
    # q=(x,1) has rhs 0; p=(y,1) has rhs 1.  Bit n+1 is augmentation.
    rows = []
    for x, y in cells:
        rows += [x | (1 << n), y | (1 << n) | (1 << (n + 1))]
    return rank(rows, n + 1) == rank(rows, n + 2)


def separator_types(cells, s, n: int) -> tuple[str, ...]:
    x, y = s
    # Test that specified affine form is constant as asserted on L(cells).
    out = []
    # q_s=1; p_s=0; q_s+p_s=0
    for name, coeff, rhs in (
        ("R", x | (1 << n), 1),
        ("C", y | (1 << n), 0),
        ("P", x ^ y, 0),
    ):
        # homogeneous/affine equation is consistent first; opposite inconsistent.
        base = []
        for a, b in cells:
            base += [a | (1 << n), b | (1 << n) | (1 << (n + 1))]
        pos = base + [coeff | (rhs << (n + 1))]
        neg = base + [coeff | ((rhs ^ 1) << (n + 1))]
        if rank(pos, n + 1) == rank(pos, n + 2) and rank(neg, n + 1) != rank(neg, n + 2):
            out.append(name)
    return tuple(out)


def minimal_witness(cells, s, n: int) -> tuple[str, ...] | None:
    if not compatible(cells, n) or compatible(tuple(cells) + (s,), n):
        return None
    if any(not compatible(tuple(c for j, c in enumerate(cells) if j != i) + (s,), n)
           for i in range(len(cells))):
        return None
    return separator_types(cells, s, n)


def leaf_contains(cells, r, t) -> bool:
    return all(((r & x).bit_count() & 1) == t and ((r & y).bit_count() & 1) == (1 ^ t)
               for x, y in cells)


def exact_probability(family, n: int) -> tuple[int, int]:
    """Returns numerator/denominator, enumerating only leaf-local thinnings."""
    total_num = 0
    # Global denominator: 2^(n+1) parameter choices and 2^(2^n) each full thinning.
    # Local U,V restrictions have 2^(n-1) free bits per nonempty leaf; outside cancels.
    local = 1 << (n - 1)
    for r in range(1, 1 << n):
        rows = [x for x in range(1 << n) if ((r & x).bit_count() & 1) == 0]
        cols = rows[:]  # label changes t, so enumerate both below
        for t in (0, 1):
            rows = [x for x in range(1 << n) if ((r & x).bit_count() & 1) == t]
            cols = [y for y in range(1 << n) if ((r & y).bit_count() & 1) == (1 ^ t)]
            ri = {x: i for i, x in enumerate(rows)}
            ci = {y: i for i, y in enumerate(cols)}
            need = []
            for T in family:
                if leaf_contains(T, r, t):
                    rm = sum(1 << ri[x] for x, _ in T)
                    cm = sum(1 << ci[y] for _, y in T)
                    need.append((rm, cm))
            if not need:
                continue
            hit = 0
            for um in range(1 << local):
                for vm in range(1 << local):
                    if any((rm & um) == rm and (cm & vm) == cm for rm, cm in need):
                        hit += 1
            total_num += hit
    return total_num, (1 << (n + 1 + 2 * local))


def search_fano(n: int, trials: int, seed: int, fixed_s: tuple[int, int] | None) -> None:
    rng = random.Random(seed)
    pts = [p for p in itertools.product(range(1 << n), repeat=2) if p[0] != p[1]]
    spoilers = [fixed_s] if fixed_s else pts
    best = (0, 1, None)
    for attempt in range(trials):
        s = spoilers[attempt % len(spoilers)]
        # Rejection sampling over seven labelled points.  A Fano line must be minimal.
        point = rng.sample([p for p in pts if p != s], 7)
        types = []
        ok = True
        for line in FANO:
            typ = minimal_witness(tuple(point[i] for i in line), s, n)
            if not typ:
                ok = False
                break
            types.append(typ)
        if not ok:
            continue
        common = set(types[0]).intersection(*map(set, types[1:]))
        if not common:
            continue
        family = tuple(tuple(point[i] for i in line) for line in FANO)
        num, den = exact_probability(family, n)
        if num * best[1] > best[0] * den:
            best = (num, den, (s, point, tuple(sorted(common)), types))
            print("BEST", n, "seed", seed, "attempt", attempt, "prob", f"{num}/{den}",
                  "s", s, "points", point, "common", sorted(common), "types", types, flush=True)
    if best[2] is None:
        print("NONE", n, "seed", seed, "trials", trials, flush=True)
    else:
        print("FINAL", n, "seed", seed, "trials", trials, "prob", f"{best[0]}/{best[1]}",
              "record", best[2], flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=3)
    ap.add_argument("--trials", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=20260813)
    ap.add_argument("--s", type=str, default=None, help="x,y integers")
    args = ap.parse_args()
    fixed = tuple(map(int, args.s.split(","))) if args.s else None
    search_fano(args.n, args.trials, args.seed, fixed)
