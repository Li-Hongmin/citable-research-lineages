#!/usr/bin/env python3
"""Exact small-field RS incidence characters; exploratory, not a proof bundle."""

from fractions import Fraction
from itertools import combinations, product
from collections import Counter


def gf_mul(a, b, n, modulus):
    out = 0
    while b:
        if b & 1:
            out ^= a
        b >>= 1
        a <<= 1
        if a & (1 << n):
            a ^= modulus
    return out


def gf_pow(a, e, n, modulus):
    out = 1
    while e:
        if e & 1:
            out = gf_mul(out, a, n, modulus)
        a = gf_mul(a, a, n, modulus)
        e >>= 1
    return out


def eval_poly(coeffs, x, n, modulus):
    out = 0
    for c in reversed(coeffs):
        out = gf_mul(out, x, n, modulus) ^ c
    return out


def exact_character(n, modulus, points, T):
    q = 1 << n
    k = len(points)
    edges = []
    for coeffs in product(range(q), repeat=T):
        edges.append(tuple(eval_poly(coeffs, x, n, modulus) for x in points))
    plus = 0
    total = 1 << (q * k)
    for assignment in range(total):
        phase = 0
        for edge in edges:
            term = 1
            for role, value in enumerate(edge):
                term &= (assignment >> (role * q + value)) & 1
            phase ^= term
        plus += 1 if phase == 0 else -1
    return Fraction(plus, total)


def all_unordered_point_sets(n, modulus):
    q = 1 << n
    for k in range(2, q + 1):
        for pts in combinations(range(q), k):
            for T in range(1, k):
                yield pts, T, exact_character(n, modulus, pts, T)


def group_algebra_mul(x, y, q):
    out = 0
    for a in range(q):
        if (x >> a) & 1:
            for b in range(q):
                if (y >> b) & 1:
                    out ^= 1 << (a ^ b)
    return out


def rho_one_distribution(q, max_t):
    elements = range(1 << q)
    table = [[group_algebra_mul(x, y, q) for y in elements] for x in elements]
    dist = Counter({x: 1 for x in elements})
    denom = 1 << q
    yield 1, Fraction(dist[0], denom), len(dist)
    for t in range(2, max_t + 1):
        nxt = Counter()
        for x, count in dist.items():
            for y in elements:
                nxt[table[x][y]] += count
        dist = nxt
        denom *= 1 << q
        yield t, Fraction(dist[0], denom), len(dist)


def binary_rank(rows):
    rows = [r for r in rows if r]
    rank = 0
    while rows:
        rows = [r for r in rows if r]
        if not rows:
            break
        pivot = max(rows)
        rows.remove(pivot)
        bit = 1 << (pivot.bit_length() - 1)
        rows = [r ^ pivot if r & bit else r for r in rows]
        rank += 1
    return rank


def t2_rho2_character(n, modulus, points):
    q = 1 << n
    y0, y1, z0, z1 = points
    invden = gf_pow(y0 ^ y1, q - 2, n, modulus)
    def coeff(z):
        # p(z) = alpha*p(y0) + beta*p(y1), subtraction is XOR.
        return (gf_mul(z ^ y1, invden, n, modulus),
                gf_mul(z ^ y0, invden, n, modulus))
    a0, b0 = coeff(z0)
    a1, b1 = coeff(z1)
    image = [[None] * q for _ in range(q)]
    for a in range(q):
        for b in range(q):
            image[a][b] = (gf_mul(a0, a, n, modulus) ^ gf_mul(b0, b, n, modulus),
                           gf_mul(a1, a, n, modulus) ^ gf_mul(b1, b, n, modulus))
    rank_counts = Counter()
    for xa in range(1 << q):
        active_a = [a for a in range(q) if xa >> a & 1]
        for xb in range(1 << q):
            rows = [0] * q
            for a in active_a:
                for b in range(q):
                    if xb >> b & 1:
                        c, d = image[a][b]
                        rows[c] ^= 1 << d
            rank_counts[binary_rank(rows)] += 1
    numerator = sum(count * (1 << (q-rank)) for rank, count in rank_counts.items())
    return Fraction(numerator, (1 << (2*q)) * (1 << q)), rank_counts


if __name__ == "__main__":
    for n, modulus in [(1, 0b11), (2, 0b111)]:
        print(f"q={1<<n}")
        grouped = {}
        for pts, T, chi in all_unordered_point_sets(n, modulus):
            grouped.setdefault((len(pts), T), {}).setdefault(chi, []).append(pts)
        for (k, T), vals in sorted(grouped.items()):
            rho = k - T
            print(f"T={T} rho={rho}: " + "; ".join(
                f"{chi} ({len(sets)} sets: {sets})" for chi, sets in vals.items()))
    print("q=8, rho=1 exact group-algebra DP")
    for t, chi, support in rho_one_distribution(8, 7):
        print(f"T={t} rho=1: {chi} (distribution support {support})")
    print("q=8, T=2 rho=2 across evaluation 4-sets")
    vals = {}
    for pts in combinations(range(8), 4):
        chi, ranks = t2_rho2_character(3, 0b1011, pts)
        vals.setdefault(chi, []).append((pts, ranks))
    for chi, records in vals.items():
        print(f"chi={chi}: {len(records)} sets; examples={records[:3]}")
