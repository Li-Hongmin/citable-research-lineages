import itertools
import math

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, linprog, milp


def pattern_matrix(C, sizes):
    columns = []
    ranges = [range(C // s + 1) for s in sizes]
    for z in itertools.product(*ranges):
        if any(z) and sum(a * b for a, b in zip(z, sizes)) <= C:
            columns.append(z)
    return np.asarray(columns, dtype=float).T


def fractional_bp(patterns, counts):
    result = linprog(
        np.ones(patterns.shape[1]),
        A_ub=-patterns,
        b_ub=-np.asarray(counts),
        bounds=(0, None),
        method="highs",
    )
    return result.fun


def exact_bp(patterns, counts):
    result = milp(
        np.ones(patterns.shape[1]),
        integrality=np.ones(patterns.shape[1]),
        bounds=Bounds(0, np.inf),
        constraints=LinearConstraint(patterns, np.asarray(counts), np.inf),
        options={"time_limit": 2.0},
    )
    return None if not result.success else int(round(result.fun))


def prefix_patterns(patterns, prefix):
    keep = np.all(patterns[prefix:, :] == 0, axis=0)
    return patterns[:prefix, keep]


def main():
    rng = np.random.default_rng(20260901)
    hits = []
    best = []
    for C in range(30, 201):
        h = C * C // 3
        U = C + 1 + int(math.log2(C + 1))
        for _ in range(80):
            c1 = int(rng.integers(max(1, C // 10), max(2, C // 3)))
            c2 = int(rng.integers(c1 + 1, max(c1 + 2, C // 2 + 1)))
            c3 = int(rng.integers(max(c2 + 1, C // 2 + 1), C + 1))
            sizes = (c1, c2, c3)
            patterns = pattern_matrix(C, sizes)
            prefix = [prefix_patterns(patterns, i) for i in (1, 2, 3)]
            volume_budget = (2 * C * C) // 3 + 2 * C
            for _ in range(100):
                weights = rng.dirichlet(np.ones(3))
                volume = int(rng.integers(max(1, C * C // 2), volume_budget + 1))
                counts = np.maximum(1, np.floor(weights * volume / np.asarray(sizes)).astype(int))
                while np.dot(counts, sizes) > volume_budget:
                    j = int(np.argmax(counts * np.asarray(sizes)))
                    counts[j] -= 1
                if counts[0] <= 0 or counts[1] <= 0 or counts[2] <= 0:
                    continue
                frac = fractional_bp(patterns, counts)
                best.append((frac - U, C, sizes, tuple(counts)))
                if frac <= U - 2:
                    continue
                exact = []
                gates = True
                for i in range(3):
                    bp = exact_bp(prefix[i], counts[: i + 1])
                    if bp is None:
                        gates = False
                        break
                    total = math.ceil((h + int(np.dot(counts[: i + 1], sizes[: i + 1]))) / C)
                    exact.append(max(bp, total))
                if not gates:
                    continue
                if h // C <= c1 and exact[0] > c2 and exact[1] > c3 and exact[2] > U:
                    hits.append((C, sizes, tuple(counts), tuple(exact), frac))
                    print("HIT", hits[-1], flush=True)
                    return
        if C % 20 == 0:
            print("C", C, "best_gap", max(x[0] for x in best[-8000:]), flush=True)
    print("NO_HIT")
    for row in sorted(best, reverse=True)[:20]:
        print("BEST", row)


if __name__ == "__main__":
    main()
