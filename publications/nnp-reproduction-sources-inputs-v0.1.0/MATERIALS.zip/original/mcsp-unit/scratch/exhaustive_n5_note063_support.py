#!/usr/bin/env python3
"""Complete N=5 check on the ten-column support of note 063.

Scope only: x0=0, a=1, b=2, and
    D=(8,16,6,13,4,24,29,21,2,7).
It enumerates every normalized minimal R/C/P row-star candidate whose columns
are contained in D, every subfamily of those candidates, and tests
pairwise column intersection exactly.  It then computes

    Pr_{r,V}[ exists S in F: S subseteq B_r intersection V]

by enumerating all r and all V subseteq D.  This is a finite observation;
it says nothing about other N=5 supports or arbitrary dimension.
"""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations

from exact_row_star_candidate_space import candidates


N, A, B = 5, 1, 2
D = (8, 16, 6, 13, 4, 24, 29, 21, 2, 7)


def dot(r: int, d: int) -> int:
    return (r & d).bit_count() & 1


def to_mask(values: tuple[int, ...]) -> int:
    return sum(1 << D.index(value) for value in values)


def affine_compatible(cells: tuple[tuple[int, int], ...]) -> bool:
    """Directly enumerate (r,t), independently of the circuit reduction."""
    return any(
        all(dot(r, row) == t and dot(r, column) == (t ^ 1) for row, column in cells)
        for r in range(1 << N)
        for t in range(2)
    )


def directly_minimal(values: tuple[int, ...]) -> bool:
    cells = tuple((0, value) for value in values)
    spoiler = ((A, B),)
    return (
        affine_compatible(cells)
        and not affine_compatible(cells + spoiler)
        and all(
            affine_compatible(tuple((0, value) for value in proper) + spoiler)
            for size in range(len(values))
            for proper in combinations(values, size)
        )
    )


def exact_mass(family: tuple[int, ...]) -> Fraction:
    hits = 0
    for r in range(1 << N):
        active = sum(1 << index for index, value in enumerate(D) if dot(r, value))
        for v in range(1 << len(D)):
            retained = active & v
            hits += any(mask & ~retained == 0 for mask in family)
    return Fraction(hits, (1 << N) * (1 << len(D)))


def main() -> None:
    _, raw = candidates(N, A, B)
    raw = [(values, kind) for values, kind in raw if set(values).issubset(D)]
    masks = tuple(to_mask(values) for values, _ in raw)
    assert len(raw) == 13
    assert all(directly_minimal(values) for values, _ in raw)
    # Note 046 gives |S|<=N for genuine row-star witnesses.  Exhausting every
    # subset of D up to that size directly confirms that the circuit listing
    # neither loses nor adds an actual affine-minimal witness on this support.
    direct = {
        values
        for size in range(1, N + 1)
        for values in combinations(D, size)
        if directly_minimal(values)
    }
    assert {frozenset(values) for values in direct} == {
        frozenset(values) for values, _ in raw
    }

    # All 2^13 families are tested, not merely maximal cliques.
    intersecting = 0
    no_core_intersecting = 0
    best = Fraction(-1)
    best_family: tuple[int, ...] = ()
    best_no_core = Fraction(-1)
    best_no_core_family: tuple[int, ...] = ()
    for selector in range(1, 1 << len(raw)):
        chosen = tuple(index for index in range(len(raw)) if selector >> index & 1)
        if not all(masks[left] & masks[right] for left, right in combinations(chosen, 2)):
            continue
        intersecting += 1
        family = tuple(masks[index] for index in chosen)
        mass = exact_mass(family)
        if mass > best:
            best, best_family = mass, chosen
        core = (1 << len(D)) - 1
        for mask in family:
            core &= mask
        if core == 0:
            no_core_intersecting += 1
            if mass > best_no_core:
                best_no_core, best_no_core_family = mass, chosen

    print("support", D)
    print("candidate_count", len(raw))
    print("direct_affine_minimal_candidates", len(direct))
    print("pairwise_intersecting_subfamilies", intersecting)
    print("no_common_column_subfamilies", no_core_intersecting)
    print("max_full_mass", best)
    for index in best_family:
        print("BEST", raw[index][1], raw[index][0])
    print("max_no_common_column_full_mass", best_no_core)
    for index in best_no_core_family:
        print("NO_CORE", raw[index][1], raw[index][0])


if __name__ == "__main__":
    main()
