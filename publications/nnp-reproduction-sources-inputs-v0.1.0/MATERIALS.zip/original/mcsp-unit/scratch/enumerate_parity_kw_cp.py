#!/usr/bin/env python3
"""Tiny exact parity-KW protocol DP (N <= 4 only)."""

from functools import lru_cache
from itertools import combinations
import random


def affine_hull(points, n):
    if not points:
        return 0
    p = points[0]
    basis = []
    for q in points[1:]:
        v = p ^ q
        for b in basis:
            v = min(v, v ^ b)
        if v:
            pivot = v.bit_length() - 1
            basis = [min(b, b ^ v) if (b >> pivot) & 1 else b for b in basis]
            basis.append(v)
            basis.sort(reverse=True)
    out = 0
    for choice in range(1 << len(basis)):
        q = p
        for i, b in enumerate(basis):
            if (choice >> i) & 1:
                q ^= b
        out |= 1 << q
    return out


def min_affine_codim(points, domain_mask, n):
    # Minimum codimension of an affine subspace through a domain point and
    # contained in domain_mask. Brute force affine hulls of point subsets.
    best = n
    pts = list(points)
    for r in range(1, len(pts) + 1):
        for sub in combinations(pts, r):
            h = affine_hull(list(sub), n)
            if h & ~domain_mask == 0:
                dim = h.bit_count().bit_length() - 1
                best = min(best, n - dim)
    return best


def exact_cp(xs, ys, n):
    hx = [0] * (1 << len(xs))
    hy = [0] * (1 << len(ys))
    for m in range(1, len(hx)):
        hx[m] = affine_hull([xs[i] for i in range(len(xs)) if (m >> i) & 1], n)
    for m in range(1, len(hy)):
        hy[m] = affine_hull([ys[i] for i in range(len(ys)) if (m >> i) & 1], n)

    @lru_cache(None)
    def cp(a, b):
        if not a or not b or not (hx[a] & hy[b]):
            return 1
        ans = a.bit_count() * b.bit_count()
        anchor = a & -a
        sub = (a - 1) & a
        while sub:
            if sub & anchor:
                ans = min(ans, cp(sub, b) + cp(a ^ sub, b))
            sub = (sub - 1) & a
        anchor = b & -b
        sub = (b - 1) & b
        while sub:
            if sub & anchor:
                ans = min(ans, cp(a, sub) + cp(a, b ^ sub))
            sub = (sub - 1) & b
        return ans

    return cp((1 << len(xs)) - 1, (1 << len(ys)) - 1), cp.cache_info()


def report(name, n, zeros, ones):
    zm = sum(1 << x for x in zeros)
    om = sum(1 << x for x in ones)
    cp, info = exact_cp(zeros, ones, n)
    k0 = min_affine_codim(zeros, zm, n)
    k1 = min_affine_codim(ones, om, n)
    print(name, "n=", n, "sizes=", (len(zeros), len(ones)), "CP=", cp,
          "kappa=", (k0, k1), "product=", k0*k1, "states=", info.currsize)


def affine_dim(mask):
    size = mask.bit_count()
    return size.bit_length() - 1 if size else -1


def signature(n, zeros, ones):
    hz = affine_hull(zeros, n)
    ho = affine_hull(ones, n)
    zm = sum(1 << x for x in zeros)
    om = sum(1 << x for x in ones)
    return (len(zeros), len(ones), affine_dim(hz), affine_dim(ho),
            affine_dim(hz & ho), min_affine_codim(zeros, zm, n),
            min_affine_codim(ones, om, n))


for n in range(2, 5):
    universe = list(range(1 << n))
    report("OR", n, [0], universe[1:])
    report("PARITY", n, [x for x in universe if x.bit_count() % 2 == 0],
           [x for x in universe if x.bit_count() % 2])

rng = random.Random(20260813)
for i in range(8):
    ones = rng.sample(range(16), 8)
    zeros = [x for x in range(16) if x not in ones]
    report(f"RANDOM{i}", 4, zeros, ones)
    print("  ones=", sorted(ones), "signature=", signature(4, zeros, ones))

# Partial relations: low Hamming weight against high Hamming weight.
for n in range(3, 5):
    for a in range(n):
        zeros = [x for x in range(1 << n) if x.bit_count() <= a]
        ones = [x for x in range(1 << n) if x.bit_count() >= a + 1]
        if len(zeros) <= 10 and len(ones) <= 10:
            report(f"WT<={a} vs WT>={a+1}", n, zeros, ones)

# Exhaust n=3 and find the first pair where all basic affine-dimension data
# agree but recursive protocol complexity differs.
seen = {}
for table in range(1, (1 << 8) - 1):
    ones = [x for x in range(8) if (table >> x) & 1]
    zeros = [x for x in range(8) if not ((table >> x) & 1)]
    sig = signature(3, zeros, ones)
    cp, _ = exact_cp(zeros, ones, 3)
    if sig in seen and seen[sig][0] != cp:
        print("MINIMAL_SIGNATURE_COLLISION", "sig=", sig,
              "first=", seen[sig], "second=", (cp, hex(table)))
        break
    seen[sig] = (cp, hex(table))
else:
    print("NO_SIGNATURE_COLLISION_N3")
