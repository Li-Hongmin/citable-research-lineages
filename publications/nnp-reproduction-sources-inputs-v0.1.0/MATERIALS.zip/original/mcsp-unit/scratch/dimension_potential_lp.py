#!/usr/bin/env python3
"""Search tiny counterexamples to coordinate-leaf Delta >= 0."""
from itertools import product
import numpy as np
from scipy.optimize import linprog


def adim(points):
    if not points:
        raise ValueError
    p, basis = points[0], []
    for q in points[1:]:
        v = p ^ q
        for b in basis:
            v = min(v, v ^ b)
        if v:
            basis.append(v)
            basis.sort(reverse=True)
    return len(basis)


def solve(n, table):
    xs = [x for x in range(1 << n) if not ((table >> x) & 1)]
    ys = [x for x in range(1 << n) if (table >> x) & 1]
    if not xs or not ys: return None
    M = len(xs)*len(ys)
    vars_ = [(p,q) for p in range(n+1) for q in range(n+1)]
    vi = {z:i for i,z in enumerate(vars_)}
    subsets = lambda z: [[z[i] for i in range(len(z)) if (m>>i)&1]
                         for m in range(1,1<<len(z))]
    XA, YB = subsets(xs), subsets(ys)
    dims = {tuple(a):adim(a) for a in XA+YB}
    rows = set()
    # K(U,V)=(M-|U||V|)h(dimU,dimV); enforce K(children)>=K(parent).
    for A in XA:
      for B in YB:
        parent=(M-len(A)*len(B), dims[tuple(A)], dims[tuple(B)])
        # canonical nontrivial bipartitions
        for mask in range(1,1<<(len(A)-1)):
          A1=[A[i] for i in range(len(A)) if (mask>>i)&1]
          A2=[x for x in A if x not in A1]
          if not A1 or not A2: continue
          row=[0]*(n+1)**2
          row[vi[(parent[1],parent[2])]] += parent[0]
          row[vi[(dims[tuple(A1)],dims[tuple(B)])]] -= M-len(A1)*len(B)
          row[vi[(dims[tuple(A2)],dims[tuple(B)])]] -= M-len(A2)*len(B)
          rows.add(tuple(row))
        for mask in range(1,1<<(len(B)-1)):
          B1=[B[i] for i in range(len(B)) if (mask>>i)&1]
          B2=[y for y in B if y not in B1]
          if not B1 or not B2: continue
          row=[0]*(n+1)**2
          row[vi[(parent[1],parent[2])]] += parent[0]
          row[vi[(dims[tuple(A)],dims[tuple(B1)])]] -= M-len(A)*len(B1)
          row[vi[(dims[tuple(A)],dims[tuple(B2)])]] -= M-len(A)*len(B2)
          rows.add(tuple(row))
    c=np.zeros((n+1)**2)
    leaves=[]
    for j,t in product(range(n),range(2)):
      A=[x for x in xs if ((x>>j)&1)==t]
      B=[y for y in ys if ((y>>j)&1)==1-t]
      if A and B:
        coef=M-len(A)*len(B)
        c[vi[(adim(A),adim(B))]] += coef
        leaves.append((j,t,len(A),len(B),adim(A),adim(B),coef))
    res=linprog(c,A_ub=np.array(list(rows),float) if rows else None,
                b_ub=np.zeros(len(rows)),bounds=[(-1,1)]*len(c),method='highs')
    return res.fun, res.x, vars_, xs, ys, leaves, len(rows)


for n in (2,3):
  best=None
  for table in range(1,(1<<(1<<n))-1):
    ans=solve(n,table)
    if best is None or ans[0]<best[0]: best=(ans[0],table,ans)
  val,table,ans=best
  print('BEST',n,val,hex(table),'X',ans[3],'Y',ans[4],'constraints',ans[6])
  print('h',[(z,round(ans[1][i],8)) for i,z in enumerate(ans[2]) if abs(ans[1][i])>1e-8])
  print('leaves',ans[5])
