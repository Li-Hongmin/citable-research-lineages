import math
import random


def ceil_div(x: int, y: int) -> int:
    return (x + y - 1) // y


def pattern_bins(x: int, y: int, q: int, r: int) -> int:
    best = 10**18
    for u in range(y & 1, y + 1, 2):
        value = (y + u) // 2 + ceil_div(max(0, x - r * u), q)
        best = min(best, value)
    return best


def log2sum(terms: list[tuple[int, int]]) -> float:
    terms = [(n, exponent) for n, exponent in terms if n > 0]
    if not terms:
        return -math.inf
    peak = max(exponent + math.log2(n) for n, exponent in terms)
    return peak + math.log2(
        sum(2 ** (exponent + math.log2(n) - peak) for n, exponent in terms)
    )


def test_candidate(C: int, s: int, b: int, a: int, H: int):
    d = (C + 2) ** 2
    h = d // 3
    ell = int(math.log2(C + 1))
    U = C + 1 + ell
    q = C // s
    r = C // (2 * s)
    B = pattern_bins(a, H, q, r)
    N = U + 1 - B
    if N <= 0 or h + a * s + H * C // 2 + N * b > d:
        return None
    threshold = math.log2(d)
    margin = math.inf
    for x in range(a + 1):
        p = max(ceil_div(x, q), ceil_div(h + x * s, C))
        margin = min(
            margin,
            log2sum([(a - x, p - s), (H, p - C // 2), (N, p - b)])
            - threshold,
        )
    for y in range(H + 1):
        p = max(pattern_bins(a, y, q, r), ceil_div(h + a * s + y * C // 2, C))
        margin = min(
            margin,
            log2sum([(H - y, p - C // 2), (N, p - b)]) - threshold,
        )
    for m in range(N):
        p = max(B + m, ceil_div(h + a * s + H * C // 2 + m * b, C))
        if p <= U:
            margin = min(margin, math.log2(N - m) + p - b - threshold)
    return margin, (C, s, b, a, H, N, B)


def main() -> None:
    rng = random.Random(800)
    for C in (60, 120, 240):
        best = (-math.inf, None)
        d = (C + 2) ** 2
        h = d // 3
        budget = d - h
        for _ in range(30_000):
            s = rng.randrange(1, C // 2)
            b_lo = max(C // 2 + 1, C - s + 1)
            if b_lo > C:
                continue
            b = rng.randrange(b_lo, C + 1)
            a = rng.randrange(0, budget // s + 1)
            remaining = budget - a * s
            H = rng.randrange(0, 2 * remaining // C + 1)
            result = test_candidate(C, s, b, a, H)
            if result is not None and result[0] > best[0]:
                best = result
        print({"C": C, "best_margin_log2_over_d": best[0], "params": best[1]})


if __name__ == "__main__":
    main()
