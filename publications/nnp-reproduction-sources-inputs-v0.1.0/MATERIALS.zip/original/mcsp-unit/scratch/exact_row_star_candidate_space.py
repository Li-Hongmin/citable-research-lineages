#!/usr/bin/env python3
"""Enumerate minimal mixed-target row-star witnesses over GF(2).

Exploratory only.  It normalizes x_0=0 and independent targets a,b to
e_1,e_2, but deliberately retains b in the column universe: b is the
spoiler column and may also occur in a center-row witness.
"""

from __future__ import annotations

import argparse
from collections import Counter
from itertools import combinations


def xor_all(values: tuple[int, ...]) -> int:
    total = 0
    for value in values:
        total ^= value
    return total


def gf2_rank(values: tuple[int, ...], dimension: int) -> int:
    basis = [0] * dimension
    rank = 0
    for value in values:
        pivot_value = value
        while pivot_value:
            pivot = pivot_value.bit_length() - 1
            if basis[pivot] == 0:
                basis[pivot] = pivot_value
                rank += 1
                break
            pivot_value ^= basis[pivot]
    return rank


def target_type(target: int, size: int, a: int, b: int) -> str | None:
    if target == a and size % 2 == 1:
        return "R"
    if target == b and size % 2 == 0:
        return "C"
    if target == a ^ b and size % 2 == 0:
        return "P"
    return None


def is_minimal(values: tuple[int, ...], a: int, b: int) -> bool:
    for proper_size in range(1, len(values)):
        for subset in combinations(values, proper_size):
            if target_type(xor_all(subset), proper_size, a, b) is not None:
                return False
    return True


def candidates(dimension: int, a: int, b: int) -> tuple[list[int], list[tuple[tuple[int, ...], str]]]:
    if a == 0 or b == 0 or a == b:
        raise ValueError("a and b must be distinct nonzero vectors")
    universe = [value for value in range(1, 1 << dimension) if value != a]
    if b not in universe:
        raise AssertionError("the spoiler column b must remain available")
    out: list[tuple[tuple[int, ...], str]] = []
    for size in range(2, dimension + 1):
        for values in combinations(universe, size):
            target = xor_all(values)
            kind = target_type(target, size, a, b)
            if kind is None:
                continue
            if gf2_rank(values, dimension) != size:
                continue
            if is_minimal(values, a, b):
                out.append((values, kind))
    return universe, out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dimension", type=int, default=4)
    parser.add_argument("--a", type=int, default=1)
    parser.add_argument("--b", type=int, default=2)
    args = parser.parse_args()
    universe, witness_list = candidates(args.dimension, args.a, args.b)
    by_size = Counter(len(values) for values, _ in witness_list)
    by_type = Counter(kind for _, kind in witness_list)
    print(
        {
            "dimension": args.dimension,
            "a": args.a,
            "b": args.b,
            "universe_size": len(universe),
            "candidate_count": len(witness_list),
            "by_size": dict(sorted(by_size.items())),
            "by_type": dict(sorted(by_type.items())),
        },
        flush=True,
    )


if __name__ == "__main__":
    main()
