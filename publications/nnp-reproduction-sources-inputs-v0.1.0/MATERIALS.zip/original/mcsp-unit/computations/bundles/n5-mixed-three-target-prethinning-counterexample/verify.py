#!/usr/bin/env python3
"""Exact certificate for the N=5 mixed-target row-star counterexample.

Run with ``python3 verify.py``.  The script uses only the Python standard
library and checks the affine collision semantics directly, not merely the
binary-matroid proxy.
"""

from __future__ import annotations

from itertools import combinations
from functools import reduce
from operator import xor


N = 5
A, B = 1, 2
X = (0, A)
D = (8, 16, 6, 13, 4, 24, 29, 21, 2, 7)
Y = D
SPOILER = (A, B)
FAMILY = {
    "R1": (8, 13, 4),
    "R2": (16, 4, 21),
    "R3": (4, 24, 29),
    "P1": (8, 16, 6, 29),
    "P2": (8, 6, 24, 21),
    "P3": (16, 6, 13, 24),
    "P4": (6, 13, 29, 21),
    "C1": (8, 16, 29, 7),
    "C2": (8, 24, 21, 7),
    "C3": (16, 13, 24, 7),
    "C4": (13, 29, 21, 7),
}


def dot(left: int, right: int) -> int:
    return (left & right).bit_count() & 1


def xor_sum(values: tuple[int, ...]) -> int:
    return reduce(xor, values, 0)


def rank(vectors: tuple[int, ...]) -> int:
    basis: dict[int, int] = {}
    for value in vectors:
        reduced = value
        while reduced:
            pivot = reduced.bit_length() - 1
            if pivot in basis:
                reduced ^= basis[pivot]
            else:
                basis[pivot] = reduced
                break
    return len(basis)


def consistent(cells: list[tuple[int, int]]) -> bool:
    """Test q_x z=0 and p_y z=1 for consistency over F_2."""
    equations: list[tuple[int, int]] = []
    for row, column in cells:
        equations.extend(((row | (1 << N), 0), (column | (1 << N), 1)))
    basis: dict[int, tuple[int, int]] = {}
    for mask, rhs in equations:
        while mask:
            pivot = mask.bit_length() - 1
            if pivot in basis:
                old_mask, old_rhs = basis[pivot]
                mask ^= old_mask
                rhs ^= old_rhs
            else:
                basis[pivot] = (mask, rhs)
                break
        if not mask and rhs:
            return False
    return True


def verify_witnesses() -> None:
    targets = {"R": A, "P": A ^ B, "C": B}
    assert set(X).isdisjoint(Y)
    for name, values in FAMILY.items():
        kind = name[0]
        cells = [(0, value) for value in values]
        assert xor_sum(values) == targets[kind]
        assert (len(values) & 1) == (kind == "R")
        assert rank(values) == len(values)
        assert consistent(cells)
        assert not consistent(cells + [SPOILER])
        for size in range(len(cells)):
            for positions in combinations(range(len(cells)), size):
                assert consistent([cells[index] for index in positions] + [SPOILER])
    assert all(
        set(left) & set(right)
        for left, right in combinations(FAMILY.values(), 2)
    )


def active_columns(r: int) -> set[int]:
    return {value for value in D if dot(r, value)}


def main() -> None:
    verify_witnesses()
    hit_sets = {
        name: {r for r in range(1 << N) if set(values) <= active_columns(r)}
        for name, values in FAMILY.items()
    }
    hit = set().union(*hit_sets.values())
    assert len(hit) == 18
    print("affine minimality, target XORs, ranks, and intersections: verified")
    for name, values in hit_sets.items():
        print(f"{name}: {sorted(values)}")
    print(f"hit r: {sorted(hit)}")
    print(f"pre-thinning probability: {len(hit)}/{1 << N}")


if __name__ == "__main__":
    main()
