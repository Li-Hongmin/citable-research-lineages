# (N=5) mixed-three-target pre-thinning counterexample

This bundle is the finite certificate used by note 063.  It has no external
dependencies.  Its scope is solely the pre-thinning assertion

\[
\Pr_r[\exists S\subseteq B_r]\le\frac12;
\]

it does not test the full AEKR row/column-thinning event.

Run from this directory:

```sh
python3 verify.py
```

The verifier directly checks the affine row/column equation systems for all
witnesses and all their proper subsets, then enumerates the 32 choices of
\(r\in\mathbb F_2^5\).

Frozen verification environment: macOS, Python 3.14.6 at
/opt/homebrew/bin/python3; no packages beyond the standard library.  On
2026-08-14 it ran in 0.05 seconds (real, rounded to 0.01 seconds).  The
captured output is verification-output.txt.  The SHA-256 of verify.py at that
run was
9bbae20dfde7f49f4af3f2b5725a4fa2082828128afde77bd6723fba20653aa0.
