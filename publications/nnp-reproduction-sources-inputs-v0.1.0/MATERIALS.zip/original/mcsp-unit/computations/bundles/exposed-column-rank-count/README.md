# Exact exposed-column rank counts

This bundle verifies the finite interface of [note 917](../../../notes/917-arbitrary-slope-singleton-cross-line-has-average-row-rank-2026-09-02.md),
as stated in the pre-computation [SPEC.md](SPEC.md). Its mathematical statement
and complete count table are incorporated in Section 8 of
[Line Gates and Orbit Bounds in Binary Group Algebras](../../../papers/line-gates-and-orbit-bounds-in-binary-group-algebras/line-gates-and-orbit-bounds-in-binary-group-algebras.tex).

The domain is all 224 ordered normalized nonparallel slopes (d1,d2,1) over
GF(16), rho=3, E={0,1}, and all three nonzero row relations: 672 cases.
Increasing-label greedy selection in the full-E collision graph fixes the
exposed set. All counts agree with independently obtained local truth-table
probabilities and satisfy the bound. General fields and row sets are covered
by the paper's analytic proof, not by this enumeration.

## Reproduction

From this directory, using a C++17 compiler with 128-bit integer support:

```sh
mkdir -p ../../../scratch/exposed-column-reproduction
clang++ -std=c++17 -O3 -Wall -Wextra -Wconversion exposed_column_rank_counter.cpp -o ../../../scratch/exposed-column-reproduction/rank-counter
../../../scratch/exposed-column-reproduction/rank-counter --q 4 > ../../../scratch/exposed-column-reproduction/q4.jsonl
../../../scratch/exposed-column-reproduction/rank-counter --q 16 > ../../../scratch/exposed-column-reproduction/q16.jsonl
```

Both commands must exit zero. q=4 additionally enumerates all input pairs
and compares their count with conditional elimination for every case. A
summary is VALIDATED only after all specified cases are complete. For example,
`--q 16 --max-slopes 1` intentionally exits one with UNKNOWN and lists the
669 missing cases. A file truncated before its summary is incomplete.

The driver is self-contained: it has no transitive project-source or external
library dependencies. Every case stores its exposed set, full conditional
rank histogram, exact numerator out of 2^(2q), independent reference fraction,
bound, and verdict. Histogram counts sum to 2^q and determine the numerator
by N=sum_r histogram[r]*2^(q-r). Comparisons use integers, not tolerances.

## Environment and raw results

- Compiler: Apple clang 21.0.0 (clang-2100.0.123.102), C++17, `-O3`, arm64.
- Host: macOS 27.0; one CPU process; the measured q=16 peak resident memory
  was about 2 MiB. No table of input pairs is allocated.
- Raw complete outputs: [q4.jsonl](q4.jsonl), [q16.jsonl](q16.jsonl).
  Their final records contain elapsed runtime and complete coverage counts.
  [q16-timing.txt](q16-timing.txt) preserves the final run's system timing.
- The original full q=16 run took approximately 0.34 seconds wall time;
  timing is descriptive and has no role in mathematical acceptance.

The finite result is 672 VALIDATED cases, zero counterexamples and zero
remaining UNKNOWN cases. This says nothing about the open generic critical
density window, random three-line configurations outside the defining
secants, or any object not quantified in SPEC.md.
