"""Exact q=4/q=8 checks for Note 917's exposed-column bound.

The first two role arrays are enumerated exactly.  The script tests every
nonzero row relation on E={0,1}; q=4 tests all non-scalar slope vectors and
q=8 tests a fixed representative list.
"""

from itertools import product


def gf_tables(n, irreducible):
    q = 1 << n
    mul = [[0] * q for _ in range(q)]
    for a in range(q):
        for b in range(q):
            aa, bb, value = a, b, 0
            for _ in range(n):
                if bb & 1:
                    value ^= aa
                high = aa & (1 << (n - 1))
                aa <<= 1
                if high:
                    aa ^= irreducible
                bb >>= 1
            mul[a][b] = value & (q - 1)
    inv = [0] * q
    for a in range(1, q):
        inv[a] = next(b for b in range(1, q) if mul[a][b] == 1)
    return q, mul, inv


def check(n, irreducible, slopes):
    q, mul, inv = gf_tables(n, irreducible)
    E = (0, 1)
    mask = (1 << q) - 1
    total = 1 << (2 * q)
    cases = 0
    max_ratio = 0.0
    for v in slopes:
        if v[0] == v[1] == v[2]:
            continue
        d = [mul[v[j]][inv[v[2]]] for j in range(2)]
        J = [j for j in range(2) if d[j] != 1]
        I = [j for j in range(2) if d[j] == 1]
        s, t = len(J), len(I)
        p = 2.0 ** -2

        # Forbidden-column graph from (917.10), with all a,b in E.
        neighbors = [set() for _ in range(q)]
        for x in range(q):
            for j in J:
                kappa = mul[inv[d[j]]][1 ^ d[j]]
                for a in E:
                    for b in E:
                        if a != b:
                            y = x ^ mul[kappa][a ^ b]
                            if y != x:
                                neighbors[x].add(y)

        for relation in (1, 2, 3):
            C = [a for i, a in enumerate(E) if relation & (1 << i)]
            available = [x for x in range(q) if x not in E]
            exposed = []
            while available:
                x = available.pop(0)
                exposed.append(x)
                available = [y for y in available if y not in neighbors[x]]
            R = len(exposed)
            zeros = 0
            for code in range(total):
                first = (code & mask, (code >> q) & mask)
                vanishes = True
                for x in exposed:
                    parity = 0
                    for a in C:
                        value = 1
                        for j in J:
                            index = mul[1 ^ d[j]][a] ^ mul[d[j]][x]
                            value &= (first[j] >> index) & 1
                        for j in I:
                            value &= (first[j] >> x) & 1
                        parity ^= value
                    if parity:
                        vanishes = False
                        break
                zeros += vanishes
            probability = zeros / total
            bound = (1.0 - p) ** R
            assert probability <= bound + 1e-12, (
                q, v, relation, exposed, probability, bound
            )
            max_ratio = max(max_ratio, probability / bound)
            cases += 1
    print(f"q={q}, vectors={len(slopes)}, cases={cases}, max_ratio={max_ratio:g}")


if __name__ == "__main__":
    check(
        2,
        0b111,
        [v for v in product(range(1, 4), repeat=3) if len(set(v)) > 1],
    )
    check(
        3,
        0b1011,
        [(1, 2, 3), (1, 2, 4), (1, 3, 5), (2, 4, 7),
         (1, 7, 2), (2, 3, 6), (3, 5, 7), (4, 6, 7)],
    )
