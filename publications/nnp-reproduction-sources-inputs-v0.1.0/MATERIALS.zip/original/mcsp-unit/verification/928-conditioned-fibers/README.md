# Note 928 的独立实现校验

这些是已晋级有限引理／范围反例的复现材料。数学证明和适用边界见
[note 928](../../notes/928-conditioned-fiber-hardness-boundaries-2026-09-13.md)。
只用 Python 3 标准库。生成器使用投影、组合公式或球删除；校验器不导入生成器，
使用直接补全、整数熵比较、文字项枚举／集合覆盖、逐对距离分别核对。
不是实际小 N MCSP 穷举，也不是实际 CJW 编码实例化。

从仓库根运行下列命令，将全部生成数据保留在 scratch：

```sh
mkdir -p scratch/recheck-928-conditioned-fibers
cp units/mcsp-hardness-magnification/verification/928-conditioned-fibers/*.py scratch/recheck-928-conditioned-fibers/
python3 scratch/recheck-928-conditioned-fibers/generate.py
python3 scratch/recheck-928-conditioned-fibers/check.py 1
python3 scratch/recheck-928-conditioned-fibers/check.py 2
python3 scratch/recheck-928-conditioned-fibers/check.py 3
python3 scratch/recheck-928-conditioned-fibers/distance-witness.py
python3 scratch/recheck-928-conditioned-fibers/check.py 4
python3 scratch/recheck-928-conditioned-fibers/ball-predictions.py
python3 scratch/recheck-928-conditioned-fibers/check.py 5
```

预期输出见 `check-pulse1.txt` 至 `check-pulse5.txt`。脉冲4检查 134217664 对码字，
运行时间比其他四项长。没有随机种子或第三方库依赖。
