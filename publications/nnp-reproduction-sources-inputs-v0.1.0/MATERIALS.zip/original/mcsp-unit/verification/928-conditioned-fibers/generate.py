"""Fiber/projection implementation. Generic cube dimension d, not MCSP N."""
import itertools
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path


def partitions(d):
    if not d:
        yield []
        return
    for p in partitions(d - 1):
        yield p + [[d - 1]]
        for i in range(len(p)):
            yield p[:i] + [p[i] + [d - 1]] + p[i + 1:]


rows = []
for d in range(1, 4):
    for mask in range(1, 1 << (1 << d)):
        A = [x for x in range(1 << d) if mask >> x & 1]
        B = [x for x in A if x]
        if not B:
            continue
        for blocks in partitions(d):
            hist = Counter()
            for choices in itertools.product(*blocks):
                t = sum(1 << j for j in choices)
                fibers = Counter(x & ~t for x in A)
                anchors = Counter(x & ~t for x in B)
                for key, b in anchors.items():
                    hist[fibers[key]] += b
            pair_sum = Fraction(0)
            for x in B:
                for y in A:
                    if x == y:
                        continue
                    z = x ^ y
                    w = Fraction(1)
                    for block in blocks:
                        s = sum(bool(z >> j & 1) for j in block)
                        if s >= 2:
                            w = 0
                            break
                        if s == 1:
                            w /= len(block)
                    pair_sum += w
            pair_sum /= len(B)
            rows.append(dict(d=d, mask=mask, blocks=blocks,
                             hist=dict(hist), pair_mean=[pair_sum.numerator, pair_sum.denominator]))
Path(__file__).with_name('fibers.json').write_text(json.dumps(rows) + '\n')
print(f'GENERATED {len(rows)} generic language/partition configurations')
