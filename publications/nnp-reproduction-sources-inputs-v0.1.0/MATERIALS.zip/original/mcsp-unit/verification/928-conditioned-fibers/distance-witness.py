"""Greedy two-ball deletion; verifier checks distances independently."""
import itertools
import json
from pathlib import Path

rows = []
for d in (8, 16):
    radius = d // 16
    full = (1 << d) - 1
    forbidden_offsets = [sum(1 << j for j in support)
                         for s in range(radius + 1)
                         for support in itertools.combinations(range(d), s)]
    available = bytearray([1]) * (1 << d)
    code = []
    for c in range(1 << d):
        if available[c]:
            code.append(c)
            for offset in forbidden_offsets:
                available[c ^ offset] = 0
                available[c ^ full ^ offset] = 0
    rows.append(dict(d=d, radius=radius, code=code))
Path(__file__).with_name('distance-witness.json').write_text(json.dumps(rows) + '\n')
print('GENERATED distance witnesses:', [(r['d'], len(r['code'])) for r in rows])
