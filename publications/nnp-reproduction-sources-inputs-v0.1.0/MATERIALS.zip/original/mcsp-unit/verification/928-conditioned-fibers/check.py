"""Independent direct truth-table checker; never imports generate.py or probe code."""
import itertools
import json
import math
import sys
from collections import Counter
from fractions import Fraction
from pathlib import Path


def completions(x, selected):
    for values in itertools.product((0, 1), repeat=len(selected)):
        y = x
        for j, bit in zip(selected, values):
            if bool(y >> j & 1) != bool(bit):
                y ^= 1 << j
        yield y


def run(pulse):
    rows = json.loads(Path(__file__).with_name('fibers.json').read_text())
    cases = 0
    if pulse == 1:
        for row in rows:
            d, mask, blocks = row['d'], row['mask'], row['blocks']
            anchors = [x for x in range(1, 1 << d) if mask >> x & 1]
            hist = Counter()
            for selected in itertools.product(*blocks):
                for x in anchors:
                    hist[sum(bool(mask >> y & 1) for y in completions(x, selected))] += 1
            assert dict(hist) == {int(k): v for k, v in row['hist'].items()}
            assert Fraction(sum((k - 1) * v for k, v in hist.items()), sum(hist.values())) == Fraction(*row['pair_mean'])
            cases += 1
        print(f'PASS pulse 1: {cases} direct-completion histograms and weighted pair identities')
    elif pulse == 2:
        for row in rows:
            hist = {int(k): v for k, v in row['hist'].items()}
            k = row['mask'].bit_count()
            bmin = min(map(len, row['blocks']))
            draws = math.prod(map(len, row['blocks']))
            # Exponentiation turns the entropy inequality into an EXACT integer comparison.
            lhs = math.prod(h ** (bmin * count) for h, count in hist.items())
            rhs = k ** (k * draws)
            assert lhs <= rhs
            for threshold in range(2, (1 << len(row['blocks'])) + 1):
                tail = sum(v for h, v in hist.items() if h >= threshold)
                assert threshold ** (tail * bmin) <= rhs
            cases += 1
        print(f'PASS pulse 2: {cases} exact-integer entropy bounds and all integer-size tails')
    elif pulse == 3:
        pairs = 0
        for m in range(1, 4):
            points = range(1 << m)
            for truth in range(1 << (1 << m)):
                yes = [x for x in points if truth >> x & 1]
                # Implementation A: all ternary conjunctions, evaluated as literals.
                implicants = []
                for literals in itertools.product((-1, 0, 1), repeat=m):
                    covered = sum(1 << x for x in points if all(
                        bit == -1 or ((x >> j) & 1) == bit for j, bit in enumerate(literals)))
                    if covered & ~truth == 0:
                        implicants.append(covered)
                # Exact set-cover DP, independent of the incompatibility graph.
                cost = {0: 0}
                for covered in range(1 << (1 << m)):
                    if covered not in cost:
                        continue
                    for term in implicants:
                        new = covered | term
                        cost[new] = min(cost.get(new, 100), cost[covered] + 1)
                tau = cost[truth]
                bad = set()
                for x, y in itertools.combinations(yes, 2):
                    # Implementation B: the Boolean interval between intersection and union.
                    hull = [z for z in points if z & (x & y) == (x & y) and z | (x | y) == (x | y)]
                    compatible = all(truth >> z & 1 for z in hull)
                    assert compatible == any(term >> x & 1 and term >> y & 1 for term in implicants)
                    if not compatible:
                        bad.add((x, y))
                    pairs += 1
                clique = 0
                for selector in range(1 << len(yes)):
                    chosen = [x for j, x in enumerate(yes) if selector >> j & 1]
                    if all(pair in bad for pair in itertools.combinations(chosen, 2)):
                        clique = max(clique, len(chosen))
                isolated = sum(all(not (truth >> (x ^ (1 << j)) & 1) for j in range(m)) for x in yes)
                assert isolated <= clique <= tau <= len(yes)
                if isolated == len(yes):
                    assert tau == len(yes)
                cases += 1
        print(f'PASS pulse 3: {cases} languages, {pairs} YES pairs; exact DNF covers versus hull graph and isolation')
    elif pulse == 4:
        witnesses = json.loads(Path(__file__).with_name('distance-witness.json').read_text())
        pair_checks = 0
        assert 15 ** 15 > 2 ** 58  # h(1/16) < 3/8, exact integer certificate.
        for witness in witnesses:
            d, r, code = witness['d'], witness['radius'], witness['code']
            m = d + 1
            assert len(code) == len(set(code))
            volume = sum(math.comb(d, j) for j in range(r + 1))
            assert len(code) * 2 * volume >= 2 ** d
            assert len(code) ** 2 >= 2 ** m
            for c in code:
                yes = (1 << d) | c
                no = yes ^ ((1 << m) - 1)
                assert yes >> d == 1 and no >> d == 0
                assert (yes ^ no).bit_count() == m
            for c, e in itertools.combinations(code, 2):
                dist = (c ^ e).bit_count()
                assert r < dist < d - r
                assert m - dist > r
                pair_checks += 1
            # All truth-table values equal the single positive literal at coordinate d.
            assert sum(bool(x >> d & 1) for x in range(1 << m)) == 2 ** d
            cases += 1
        print(f'PASS pulse 4: {cases} greedy witnesses; {pair_checks} distinct-code pairs; one-literal counterexample')
    elif pulse == 5:
        predictions = json.loads(Path(__file__).with_name('ball-predictions.json').read_text())
        completions_checked = 0
        for row in predictions:
            n, m, q = row['n'], row['m'], row['q']
            # Nonconsecutive coordinate order; no binomial formulas in this enumeration.
            order = list(range(0, n, 2)) + list(range(1, n, 2))
            selected = order[:m]
            anchors = [x for x in range(1, 1 << n) if x.bit_count() <= q]
            event_counts = Counter()
            sizes = {}
            for x in anchors:
                if x.bit_count() != q:
                    continue
                r = sum((x >> j) & 1 for j in selected)
                event_counts[r] += 1
                size = 0
                for y in completions(x, selected):
                    size += y.bit_count() <= q
                    completions_checked += 1
                assert r not in sizes or sizes[r] == size
                sizes[r] = size
            for r, numerator, denominator, predicted_size in row['events']:
                assert Fraction(event_counts[r], len(anchors)) == Fraction(numerator, denominator)
                if event_counts[r]:
                    assert sizes[r] == predicted_size
            cases += 1
        threshold_cases = 0
        for m in range(1, 7):
            for r in range(m):
                yes = [x for x in range(1 << m) if x.bit_count() <= r]
                boundary = [x for x in yes if x.bit_count() == r]
                canonical = []
                for literals in itertools.product((-1, 0, 1), repeat=m):
                    covered = [x for x in range(1 << m) if all(
                        bit == -1 or ((x >> j) & 1) == bit for j, bit in enumerate(literals))]
                    if all(x in yes for x in covered):
                        assert sum(x in boundary for x in covered) <= 1
                        if 1 not in literals and literals.count(-1) == r:
                            canonical.append(set(covered))
                assert len(canonical) == len(boundary) == math.comb(m, r)
                assert set().union(*canonical) == set(yes)
                threshold_cases += 1
        print(f'PASS pulse 5: {cases} Hamming-ball configurations; {completions_checked} direct completions; {threshold_cases} exact threshold DNF covers')


if __name__ == '__main__':
    run(int(sys.argv[1]))
