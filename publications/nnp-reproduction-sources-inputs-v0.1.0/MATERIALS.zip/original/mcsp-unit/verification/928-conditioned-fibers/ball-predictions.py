"""Closed-form probabilities, separate from direct enumeration in check.py."""
import json
import math
from fractions import Fraction
from pathlib import Path


def choose(n, k):
    return math.comb(n, k) if 0 <= k <= n else 0


rows = []
for n in range(1, 9):
    for m in range(1, n + 1):
        for q in range(1, n + 1):
            denominator = sum(choose(n, j) for j in range(1, q + 1))
            events = []
            for r in range(m + 1):
                probability = Fraction(choose(m, r) * choose(n - m, q - r), denominator)
                events.append([r, probability.numerator, probability.denominator,
                               sum(choose(m, j) for j in range(r + 1))])
            rows.append(dict(n=n, m=m, q=q, events=events))
Path(__file__).with_name('ball-predictions.json').write_text(json.dumps(rows) + '\n')
print(f'GENERATED {len(rows)} Hamming-ball configurations')
