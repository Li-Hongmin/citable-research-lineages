#include <array>
#include <cstdlib>
#include <iostream>
#include <map>
#include <tuple>

static int chi(int q, int p) {
  return (__builtin_popcount(static_cast<unsigned>(q & p)) & 1) ? -1 : 1;
}

int main() {
  const std::array<int, 4> high = {3, 5, 6, 7};
  for (int zeros = 0; zeros <= 4; ++zeros) {
    std::array<int, 8> spectrum{};
    const std::array<int, 4> low = {0, 1, 2, 4};
    for (int a = 0; a < 4; ++a) spectrum[low[a]] = a < zeros ? 0 : 4;

    long long feasible = 0;
    std::map<int, long long> by_support;
    std::array<int, 8> first{};
    bool have_first = false;
    for (int y0 = -32; y0 <= 32; y0 += 2)
      for (int y1 = -32; y1 <= 32; y1 += 2)
        for (int y2 = -32; y2 <= 32; y2 += 2)
          for (int y3 = -32; y3 <= 32; y3 += 2) {
            spectrum[high[0]] = y0;
            spectrum[high[1]] = y1;
            spectrum[high[2]] = y2;
            spectrum[high[3]] = y3;
            std::array<int, 8> mass{};
            int l1 = 0;
            bool integral = true;
            for (int p = 0; p < 8; ++p) {
              int numerator = 0;
              for (int q = 0; q < 8; ++q) numerator += spectrum[q] * chi(q, p);
              if (numerator % 8 != 0) {
                integral = false;
                break;
              }
              mass[p] = numerator / 8;
              l1 += std::abs(mass[p]);
            }
            if (!integral || l1 != 32) continue;

            bool covered = true;
            for (int p = 0; p < 8 && covered; ++p) {
              if (mass[p] == 0) continue;
              for (int q = p; q < 8; ++q) {
                if (mass[q] == 0 || (p == q && std::abs(mass[p]) < 2)) continue;
                bool witnessed = false;
                for (int a = 0; a < 4; ++a) {
                  const int vp = (mass[p] > 0 ? 1 : -1) * chi(low[a], p);
                  const int vq = (mass[q] > 0 ? 1 : -1) * chi(low[a], q);
                  if (vp == vq && (spectrum[low[a]] == 0 ||
                                   spectrum[low[a]] == 4 * vp)) {
                    witnessed = true;
                    break;
                  }
                }
                if (!witnessed) {
                  covered = false;
                  break;
                }
              }
            }
            if (!covered) continue;
            ++feasible;
            int support = 0;
            for (int x : mass) support += x != 0;
            ++by_support[support];
            if (!have_first) {
              first = mass;
              have_first = true;
            }
          }
    std::cout << "zero_baselines=" << zeros << " feasible=" << feasible;
    for (const auto &[support, count] : by_support)
      std::cout << " support" << support << "=" << count;
    if (have_first) {
      std::cout << " first=";
      for (int x : first) std::cout << x << ',';
    }
    std::cout << '\n';
  }
}
