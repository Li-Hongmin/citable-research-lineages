#!/usr/bin/env python3
"""Temporary raw-coordinate check of the normalized four-active branch."""

from __future__ import annotations

from d3_arbitrary_sat_probe import (
    add_exact_count_dp,
    build,
    decode,
    forbid_assignment,
)


def chi(g: int, block: int) -> int:
    return -1 if (g & block).bit_count() & 1 else 1


def verify(rows: list[str]) -> None:
    centers = [[1 if symbol == "+" else -1 for symbol in row] for row in rows]
    totals = [
        [sum(centers[a][i] * chi(g, i // 4) for i in range(32)) for g in range(8)]
        for a in range(5)
    ]
    assert totals[0][0] == totals[1][0] == 0
    assert totals[2][0] in (0, 4) and totals[3][0] in (0, 4)
    assert totals[4][0] not in (-4, 0, 4)
    checked = 0
    for g in range(8):
        for left in range(32):
            for right in range(left + 1, 32):
                witnesses = []
                for a in range(5):
                    vl = centers[a][left] * chi(g, left // 4)
                    vr = centers[a][right] * chi(g, right // 4)
                    if vl == vr and totals[a][g] in (0, 4 * vl):
                        witnesses.append(a)
                assert witnesses, (g, left, right, totals)
                checked += 1
    assert checked == 3968
    print("verified_requirements=3968")
    print("totals=")
    for total in totals:
        print(" ".join(map(str, total)))


def add_projective_reduction(cnf, center: list[list[int]]) -> None:
    # Sort columns inside each block after all row normalizations have been chosen.
    for block in range(8):
        start = 4 * block
        for slot in range(3):
            left = [center[a][start + slot] for a in range(5)]
            right = [center[a][start + slot + 1] for a in range(5)]
            for left_code in range(32):
                for right_code in range(left_code + 1, 32):
                    values = [
                        *((left_code >> a) & 1 for a in range(5)),
                        *((right_code >> a) & 1 for a in range(5)),
                    ]
                    forbid_assignment(cnf, left + right, values)

    # Proposition 37: equal projective classes cannot cross blocks, and a
    # class has only one orientation inside a block.
    for left in range(32):
        for right in range(left + 1, 32):
            same_block = left // 4 == right // 4
            pair = [center[a][left] for a in range(5)] + [center[a][right] for a in range(5)]
            for code in range(32):
                bits = [(code >> a) & 1 for a in range(5)]
                forbid_assignment(cnf, pair, bits + [1 - bit for bit in bits])
                if not same_block:
                    forbid_assignment(cnf, pair, bits + bits)


def main() -> None:
    from pysat.solvers import Solver

    cnf, center = build(symmetry=False)
    add_projective_reduction(cnf, center)
    counts = [add_exact_count_dp(cnf, center[a]) for a in range(5)]
    cnf.add(counts[0][16])
    cnf.add(counts[1][16])
    cnf.add(counts[2][16], counts[2][18])
    cnf.add(counts[3][16], counts[3][18])
    for forbidden in (14, 16, 18):
        cnf.add(-counts[4][forbidden])

    print(f"variables={cnf.nvars} clauses={len(cnf.clauses)} requirements=3968")
    with Solver(name="cadical153", bootstrap_with=cnf.clauses) as solver:
        sat = solver.solve()
        print("s SATISFIABLE" if sat else "s UNSATISFIABLE")
        if sat:
            rows = decode(solver.get_model(), center)
            print(*rows, sep="\n")
            verify(rows)


if __name__ == "__main__":
    main()
