#!/usr/bin/env python3
"""Exploratory exact projective-type model for the d=3, m=4, P=5 cell."""

from __future__ import annotations

import argparse

from ortools.sat.python import cp_model


def sign(code: int, row: int) -> int:
    return 1 if (code >> row) & 1 else -1


def chi(g: int, block: int) -> int:
    return -1 if (g & block).bit_count() & 1 else 1


def build(
    zero_count: int, coverage_bases: tuple[int, ...] = tuple(range(8))
) -> tuple[cp_model.CpModel, dict[tuple[int, int], cp_model.IntVar]]:
    model = cp_model.CpModel()
    blocks, codes, rows = range(8), range(32), range(5)

    multiplicity: dict[tuple[int, int], cp_model.IntVar] = {}
    present: dict[tuple[int, int], cp_model.IntVar] = {}
    doubled: dict[tuple[int, int], cp_model.IntVar] = {}
    for block in blocks:
        for code in codes:
            key = block, code
            multiplicity[key] = model.NewIntVar(0, 4, f"n_{block}_{code}")
            present[key] = model.NewBoolVar(f"p_{block}_{code}")
            doubled[key] = model.NewBoolVar(f"d_{block}_{code}")
            model.Add(multiplicity[key] >= present[key])
            model.Add(multiplicity[key] <= 4 * present[key])
            model.Add(multiplicity[key] >= 2 * doubled[key])
            model.Add(multiplicity[key] <= 1 + 3 * doubled[key])
        model.Add(sum(multiplicity[block, code] for code in codes) == 4)

    # Proposition 37: a projective class occurs in at most one block and in
    # only one of its two orientations.
    for projective in range(16):
        mate = 31 - projective
        model.Add(
            sum(present[block, code] for block in blocks for code in (projective, mate)) <= 1
        )

    baseline: dict[tuple[int, int], cp_model.IntVar] = {}
    cover_plus: dict[tuple[int, int], cp_model.IntVar] = {}
    cover_minus: dict[tuple[int, int], cp_model.IntVar] = {}
    table = [
        (value, int(value in (0, 4)), int(value in (0, -4)))
        for value in range(-32, 33, 2)
    ]
    for row in rows:
        for g in blocks:
            baseline[row, g] = model.NewIntVar(-32, 32, f"T_{row}_{g}")
            model.Add(
                baseline[row, g]
                == sum(
                    multiplicity[block, code] * sign(code, row) * chi(g, block)
                    for block in blocks
                    for code in codes
                )
            )
            cover_plus[row, g] = model.NewBoolVar(f"cp_{row}_{g}")
            cover_minus[row, g] = model.NewBoolVar(f"cm_{row}_{g}")
            model.AddAllowedAssignments(
                [baseline[row, g], cover_plus[row, g], cover_minus[row, g]], table
            )

    # At g=0 there are exactly four active rows.  Row signs and permutations
    # normalize zero baselines first, then +4 baselines, and the inactive row
    # to a positive value.
    for row in range(zero_count):
        model.Add(baseline[row, 0] == 0)
    for row in range(zero_count, 4):
        model.Add(baseline[row, 0] == 4)
    model.Add(baseline[4, 0] >= 2)
    model.Add(baseline[4, 0] != 4)

    types = [(block, code) for block in blocks for code in codes]
    for g in coverage_bases:
        for index, left in enumerate(types):
            left_block, left_code = left
            # Two coordinates of one type require the same exact witness.
            self_cover = []
            for row in rows:
                signed = sign(left_code, row) * chi(g, left_block)
                self_cover.append(
                    cover_plus[row, g] if signed == 1 else cover_minus[row, g]
                )
            model.Add(doubled[left] <= sum(self_cover))

            for right in types[index + 1 :]:
                right_block, right_code = right
                literals = []
                for row in rows:
                    left_signed = sign(left_code, row) * chi(g, left_block)
                    right_signed = sign(right_code, row) * chi(g, right_block)
                    if left_signed == right_signed:
                        literals.append(
                            cover_plus[row, g]
                            if left_signed == 1
                            else cover_minus[row, g]
                        )
                model.Add(present[left] + present[right] <= 1 + sum(literals))

    return model, multiplicity


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zero-count", type=int, choices=(2, 3, 4), required=True)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--bases", default="0,1,2,3,4,5,6,7")
    args = parser.parse_args()

    coverage_bases = tuple(sorted({int(item) for item in args.bases.split(",") if item}))
    if not coverage_bases or any(g not in range(8) for g in coverage_bases):
        raise ValueError("bases must be a nonempty subset of 0,...,7")
    model, multiplicity = build(args.zero_count, coverage_bases)
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.time_limit
    solver.parameters.num_workers = 1
    solver.parameters.log_search_progress = False
    status = solver.Solve(model)
    print("status", solver.StatusName(status))
    print(solver.ResponseStats())
    if status in (cp_model.FEASIBLE, cp_model.OPTIMAL):
        for block in range(8):
            selected = [
                (code, solver.Value(multiplicity[block, code]))
                for code in range(32)
                if solver.Value(multiplicity[block, code])
            ]
            print("block", block, selected)


if __name__ == "__main__":
    main()
