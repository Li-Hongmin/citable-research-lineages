#!/usr/bin/env python3
"""Exploratory exact CNF for five arbitrary centers on the d=3, m=4 Walsh stars."""

from __future__ import annotations

import argparse
from pathlib import Path


class CNF:
    def __init__(self) -> None:
        self.nvars = 0
        self.clauses: list[list[int]] = []

    def var(self) -> int:
        self.nvars += 1
        return self.nvars

    def add(self, *lits: int) -> None:
        if not lits:
            raise ValueError("empty clause")
        self.clauses.append(list(lits))

    def write(self, path: Path) -> None:
        with path.open("w", encoding="ascii") as stream:
            stream.write(f"p cnf {self.nvars} {len(self.clauses)}\n")
            for clause in self.clauses:
                stream.write(" ".join(map(str, clause)))
                stream.write(" 0\n")


def bit_dot(x: int, y: int) -> int:
    return (x & y).bit_count() & 1


def signed_literal(center_var: int, g: int, block: int) -> int:
    """Literal true iff c_i x_i^g=+1."""
    return center_var if bit_dot(g, block) == 0 else -center_var


def add_exact_count_dp(cnf: CNF, literals: list[int]) -> list[int]:
    """Return variables e[k] equivalent to exactly k input literals being true."""
    previous = [cnf.var()]
    cnf.add(previous[0])
    for index, literal in enumerate(literals, start=1):
        current = [cnf.var() for _ in range(index + 1)]
        for count, state in enumerate(current):
            same = previous[count] if count < len(previous) else None
            raised = previous[count - 1] if count > 0 else None

            if same is not None:
                cnf.add(-same, literal, state)
            if raised is not None:
                cnf.add(-raised, -literal, state)

            if same is None:
                cnf.add(-state, literal)
            else:
                cnf.add(-state, literal, same)
            if raised is None:
                cnf.add(-state, -literal)
            else:
                cnf.add(-state, -literal, raised)
        previous = current
    return previous


def forbid_assignment(cnf: CNF, variables: list[int], values: list[int]) -> None:
    cnf.add(*(-var if value else var for var, value in zip(variables, values)))


def add_numeric_leq(cnf: CNF, left: list[int], right: list[int]) -> None:
    """Enforce the little-endian bit vector left <= right."""
    prefix_equal = cnf.var()
    cnf.add(prefix_equal)
    for lbit, rbit in zip(reversed(left), reversed(right)):
        # Equal higher bits may not be followed by 1 < 0.
        cnf.add(-prefix_equal, -lbit, rbit)
        next_equal = cnf.var()
        cnf.add(-next_equal, prefix_equal)
        cnf.add(-next_equal, -lbit, rbit)
        cnf.add(-next_equal, lbit, -rbit)
        cnf.add(-prefix_equal, -lbit, -rbit, next_equal)
        cnf.add(-prefix_equal, lbit, rbit, next_equal)
        prefix_equal = next_equal


def add_block_ordering(cnf: CNF, center: list[list[int]]) -> None:
    rows = len(center)
    block_size = 4
    blocks = len(center[0]) // block_size

    # Permute the four coordinates inside each block so their column codes
    # are nonincreasing.  Enumerating the 496 forbidden five-bit code pairs
    # is small and leaves no comparator semantics to trust.
    for block in range(blocks):
        start = block * block_size
        for slot in range(block_size - 1):
            left = [center[row][start + slot] for row in range(rows)]
            right = [center[row][start + slot + 1] for row in range(rows)]
            for left_code in range(32):
                for right_code in range(left_code + 1, 32):
                    values = [
                        *((left_code >> row) & 1 for row in range(rows)),
                        *((right_code >> row) & 1 for row in range(rows)),
                    ]
                    forbid_assignment(cnf, left + right, values)


def add_projective_lemmas(cnf: CNF, center: list[list[int]]) -> None:
    """Add Proposition 37's exact projective-support consequences."""
    coordinates = len(center[0])
    for left in range(coordinates):
        left_bits = [center[row][left] for row in range(len(center))]
        for right in range(left + 1, coordinates):
            right_bits = [center[row][right] for row in range(len(center))]
            same_block = left // 4 == right // 4
            for code in range(32):
                values = [(code >> row) & 1 for row in range(5)]
                # Opposite orientations are impossible even within one block.
                forbid_assignment(cnf, left_bits + right_bits, values + [1 - x for x in values])
                if not same_block:
                    # Distinct blocks also cannot share the same orientation.
                    forbid_assignment(cnf, left_bits + right_bits, values + values)


def build(symmetry: bool = False, normalized_z: int | None = None) -> tuple[CNF, list[list[int]]]:
    cnf = CNF()
    rows = 5
    blocks = 8
    block_size = 4
    coordinates = blocks * block_size

    center = [[cnf.var() for _ in range(coordinates)] for _ in range(rows)]

    add_projective_lemmas(cnf, center)

    if symmetry:
        add_block_ordering(cnf, center)
        if normalized_z is None:
            for row in range(rows):
                cnf.add(center[row][0])

    exact: dict[tuple[int, int], list[int]] = {}
    for row in range(rows):
        for g in range(blocks):
            signed = [
                signed_literal(center[row][coordinate], g, coordinate // block_size)
                for coordinate in range(coordinates)
            ]
            exact[row, g] = add_exact_count_dp(cnf, signed)

    if normalized_z is not None:
        if normalized_z not in (2, 3, 4):
            raise ValueError("normalized_z must be 2, 3, or 4")
        # At g=0 rows 0,...,3 are exactly the active rows.  The first z have
        # zero baseline.  Negate each remaining active row so its baseline is
        # +4; zero and inactive rows retain the safe first-column sign fixing.
        for row in range(normalized_z):
            cnf.add(exact[row, 0][16])
            cnf.add(center[row][0])
        for row in range(normalized_z, 4):
            cnf.add(exact[row, 0][18])
        for count in (14, 16, 18):
            cnf.add(-exact[4, 0][count])
        cnf.add(center[4][0])

        # This normalized problem is only the four/five-active branch of
        # Proposition 38: at every Walsh base at most one row is inactive.
        for g in range(blocks):
            active = []
            for row in range(rows):
                indicator = cnf.var()
                active.append(indicator)
                for count in (14, 16, 18):
                    cnf.add(-exact[row, g][count], indicator)
                cnf.add(-indicator, exact[row, g][14], exact[row, g][16], exact[row, g][18])
            for left in range(rows):
                for right in range(left + 1, rows):
                    cnf.add(active[left], active[right])

    requirements = 0
    for g in range(blocks):
        for left in range(coordinates):
            for right in range(left + 1, coordinates):
                alternatives: list[int] = []
                for row in range(rows):
                    zl = signed_literal(center[row][left], g, left // block_size)
                    zr = signed_literal(center[row][right], g, right // block_size)

                    # Weight 16 and an equal signed pair: base or neighbor is zero.
                    equal_at_16 = cnf.var()
                    alternatives.append(equal_at_16)
                    cnf.add(-equal_at_16, exact[row, g][16])
                    cnf.add(-equal_at_16, -zl, zr)
                    cnf.add(-equal_at_16, zl, -zr)

                    # Weight 18 with a ++ pair: the neighbor is zero.
                    plus_at_18 = cnf.var()
                    alternatives.append(plus_at_18)
                    cnf.add(-plus_at_18, exact[row, g][18])
                    cnf.add(-plus_at_18, zl)
                    cnf.add(-plus_at_18, zr)

                    # Weight 14 with a -- pair: the neighbor is zero.
                    minus_at_14 = cnf.var()
                    alternatives.append(minus_at_14)
                    cnf.add(-minus_at_14, exact[row, g][14])
                    cnf.add(-minus_at_14, -zl)
                    cnf.add(-minus_at_14, -zr)
                cnf.add(*alternatives)
                requirements += 1

    assert requirements == blocks * (coordinates * (coordinates - 1) // 2) == 3968
    return cnf, center


def decode(model: list[int], center: list[list[int]]) -> list[str]:
    positive = {literal for literal in model if literal > 0}
    return ["".join("+" if var in positive else "-" for var in row) for row in center]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dimacs", type=Path)
    parser.add_argument("--solve", action="store_true")
    parser.add_argument("--symmetry", action="store_true")
    parser.add_argument("--normalized-z", type=int, choices=(2, 3, 4))
    parser.add_argument("--solver", default="cadical153")
    args = parser.parse_args()

    cnf, center = build(symmetry=args.symmetry, normalized_z=args.normalized_z)
    print(f"variables={cnf.nvars} clauses={len(cnf.clauses)} requirements=3968")
    if args.dimacs:
        cnf.write(args.dimacs)
    if args.solve:
        from pysat.solvers import Solver

        with Solver(name=args.solver, bootstrap_with=cnf.clauses) as solver:
            satisfiable = solver.solve()
            print("s SATISFIABLE" if satisfiable else "s UNSATISFIABLE")
            if satisfiable:
                for row in decode(solver.get_model(), center):
                    print(row)


if __name__ == "__main__":
    main()
