#!/usr/bin/env python3
"""Exact projective-type model for the normalized d=3, m=4, P=5 branch.

This is disposable exploration code.  A projective class is represented by
``r=(r_1,...,r_4,+1)``.  A selected state ``(block, orientation)`` and a
positive multiplicity determine one coordinate type.  Proposition 37 is
encoded by allowing each of the sixteen classes in at most one state.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass

from ortools.sat.python import cp_model


ROWS = 5
BLOCKS = 8
CLASSES = 16


def chi(g: int, block: int) -> int:
    return -1 if (g & block).bit_count() & 1 else 1


def representative(projective_class: int, row: int) -> int:
    if row == 4:
        return 1
    return 1 if (projective_class >> row) & 1 else -1


@dataclass
class TypeModel:
    model: cp_model.CpModel
    multiplicity: list[list[list[cp_model.IntVar]]]
    selected: list[list[list[cp_model.IntVar]]]
    used: list[cp_model.IntVar]
    multiple: list[cp_model.IntVar]
    vplus: list[list[list[cp_model.IntVar]]]
    total: list[list[cp_model.IntVar]]


def build() -> TypeModel:
    model = cp_model.CpModel()

    # The final index is 0 for orientation -1 and 1 for orientation +1.
    selected = [
        [
            [model.new_bool_var(f"y_{p}_{block}_{side}") for side in range(2)]
            for block in range(BLOCKS)
        ]
        for p in range(CLASSES)
    ]
    multiplicity = [
        [
            [model.new_int_var(0, 4, f"n_{p}_{block}_{side}") for side in range(2)]
            for block in range(BLOCKS)
        ]
        for p in range(CLASSES)
    ]
    used = [model.new_bool_var(f"used_{p}") for p in range(CLASSES)]
    multiple = [model.new_bool_var(f"multiple_{p}") for p in range(CLASSES)]

    for p in range(CLASSES):
        states = []
        masses = []
        for block in range(BLOCKS):
            for side in range(2):
                y = selected[p][block][side]
                n = multiplicity[p][block][side]
                model.add(n >= y)
                model.add(n <= 4 * y)
                states.append(y)
                masses.append(n)
        # One projective class occurs in at most one block and one orientation.
        model.add(sum(states) == used[p])
        mass = sum(masses)
        model.add(mass >= 2).only_enforce_if(multiple[p])
        model.add(mass <= 1).only_enforce_if(~multiple[p])

    # Every Walsh block contains exactly four coordinates.
    for block in range(BLOCKS):
        model.add(
            sum(
                multiplicity[p][block][side]
                for p in range(CLASSES)
                for side in range(2)
            )
            == 4
        )

    total = [
        [model.new_int_var(-32, 32, f"T_{row}_{g}") for g in range(BLOCKS)]
        for row in range(ROWS)
    ]
    for row in range(ROWS):
        for g in range(BLOCKS):
            terms = []
            for p in range(CLASSES):
                rp = representative(p, row)
                for block in range(BLOCKS):
                    for side in range(2):
                        orientation = 1 if side else -1
                        coefficient = orientation * rp * chi(g, block)
                        terms.append(coefficient * multiplicity[p][block][side])
            model.add(total[row][g] == sum(terms))

    # Truth variables for the only totals that can witness tau_0 separation.
    equals: dict[tuple[int, int, int], cp_model.IntVar] = {}
    for row in range(ROWS):
        for g in range(BLOCKS):
            for value in (-4, 0, 4):
                literal = model.new_bool_var(f"T_{row}_{g}_eq_{value}")
                model.add(total[row][g] == value).only_enforce_if(literal)
                model.add(total[row][g] != value).only_enforce_if(~literal)
                equals[row, g, value] = literal

    # vplus[p][g][row] is the signed value of the selected type, when used.
    vplus = [
        [
            [model.new_bool_var(f"vp_{p}_{g}_{row}") for row in range(ROWS)]
            for g in range(BLOCKS)
        ]
        for p in range(CLASSES)
    ]
    for p in range(CLASSES):
        for g in range(BLOCKS):
            for row in range(ROWS):
                positive_states = []
                for block in range(BLOCKS):
                    for side in range(2):
                        orientation = 1 if side else -1
                        value = orientation * representative(p, row) * chi(g, block)
                        if value == 1:
                            positive_states.append(selected[p][block][side])
                # Since at most one state is selected, this sum is Boolean.
                model.add(vplus[p][g][row] == sum(positive_states))

    def enforce_witness(
        witness: cp_model.IntVar,
        p: int,
        g: int,
        row: int,
        q: int | None = None,
    ) -> None:
        model.add_implication(witness, used[p])
        if q is not None:
            model.add_implication(witness, used[q])
            model.add(vplus[p][g][row] == vplus[q][g][row]).only_enforce_if(witness)
        vp = vplus[p][g][row]
        # Exact condition: T in {0,4t}, with t the common signed value.
        model.add_bool_or(equals[row, g, 0], equals[row, g, 4]).only_enforce_if(
            [witness, vp]
        )
        model.add_bool_or(equals[row, g, 0], equals[row, g, -4]).only_enforce_if(
            [witness, ~vp]
        )

    # Distinct selected projective types.  Each condition stands for every
    # one of the n_p*n_q coordinate pairs represented by the two types.
    for p in range(CLASSES):
        for q in range(p + 1, CLASSES):
            for g in range(BLOCKS):
                witnesses = []
                for row in range(ROWS):
                    witness = model.new_bool_var(f"sep_{p}_{q}_{g}_{row}")
                    enforce_witness(witness, p, g, row, q)
                    witnesses.append(witness)
                model.add_bool_or(~used[p], ~used[q], *witnesses)

    # A repeated type contributes C(n_p,2) coordinate pairs.  Its two signed
    # values are identical, so only T in {0,4v} remains to be checked.
    for p in range(CLASSES):
        for g in range(BLOCKS):
            witnesses = []
            for row in range(ROWS):
                witness = model.new_bool_var(f"selfsep_{p}_{g}_{row}")
                enforce_witness(witness, p, g, row)
                witnesses.append(witness)
            model.add_bool_or(~multiple[p], *witnesses)

    # Proposition 38 normalization at g=0.
    model.add(total[0][0] == 0)
    model.add(total[1][0] == 0)
    model.add_allowed_assignments([total[2][0]], [(0,), (4,)])
    model.add_allowed_assignments([total[3][0]], [(0,), (4,)])
    model.add_forbidden_assignments([total[4][0]], [(-4,), (0,), (4,)])

    return TypeModel(model, multiplicity, selected, used, multiple, vplus, total)


def decode(instance: TypeModel, solver: cp_model.CpSolver) -> list[list[int]]:
    columns: list[list[int]] = []
    for block in range(BLOCKS):
        block_columns = []
        for p in range(CLASSES):
            for side in range(2):
                n = solver.value(instance.multiplicity[p][block][side])
                orientation = 1 if side else -1
                column = [orientation * representative(p, row) for row in range(ROWS)]
                block_columns.extend([column] * n)
        assert len(block_columns) == 4
        columns.extend(block_columns)
    return columns


def verify(columns: list[list[int]]) -> None:
    assert len(columns) == 32 and all(len(column) == 5 for column in columns)
    totals = [
        [sum(columns[i][row] * chi(g, i // 4) for i in range(32)) for g in range(8)]
        for row in range(5)
    ]
    assert totals[0][0] == totals[1][0] == 0
    assert totals[2][0] in (0, 4) and totals[3][0] in (0, 4)
    assert totals[4][0] not in (-4, 0, 4)

    # Directly recheck the original coordinate quantifier, not the compressed
    # conditions used by the solver.
    requirements = 0
    witness_histogram = [0] * 6
    for g in range(8):
        for left in range(32):
            for right in range(left + 1, 32):
                witness_count = 0
                for row in range(5):
                    vl = columns[left][row] * chi(g, left // 4)
                    vr = columns[right][row] * chi(g, right // 4)
                    if vl == vr and totals[row][g] in (0, 4 * vl):
                        witness_count += 1
                assert witness_count > 0, (g, left, right)
                witness_histogram[witness_count] += 1
                requirements += 1
    assert requirements == 8 * (32 * 31 // 2) == 3968

    # Independently verify Proposition 37's projective-support interface.
    owner: dict[tuple[int, ...], int] = {}
    orientation: dict[tuple[int, tuple[int, ...]], tuple[int, ...]] = {}
    for index, column in enumerate(columns):
        block = index // 4
        canonical = tuple(value * column[4] for value in column[:4])
        if canonical in owner:
            assert owner[canonical] == block
        else:
            owner[canonical] = block
        key = (block, canonical)
        if key in orientation:
            assert orientation[key] == tuple(column)
        else:
            orientation[key] = tuple(column)

    print("verified_requirements=3968")
    print("witness_histogram=" + ",".join(map(str, witness_histogram[1:])))
    print("projective_classes=" + str(len(owner)))
    print("totals=")
    for row_totals in totals:
        print(" ".join(map(str, row_totals)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seconds", type=float, default=300.0)
    parser.add_argument("--log", action="store_true")
    args = parser.parse_args()

    instance = build()
    print(instance.model.model_stats())
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.seconds
    solver.parameters.num_search_workers = 1
    solver.parameters.log_search_progress = args.log
    status = solver.solve(instance.model)
    print("status=" + solver.status_name(status))
    print(f"wall_time={solver.wall_time():.6f}")
    print(f"branches={solver.num_branches} conflicts={solver.num_conflicts}")
    if status in (cp_model.FEASIBLE, cp_model.OPTIMAL):
        columns = decode(instance, solver)
        for row in range(ROWS):
            print("".join("+" if column[row] == 1 else "-" for column in columns))
        verify(columns)


if __name__ == "__main__":
    main()
