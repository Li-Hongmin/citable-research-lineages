#!/bin/sh
set -eu

bundle_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$bundle_dir"

shasum -a 256 -c SHA256SUMS
profile_json=$(mktemp "${TMPDIR:-/tmp}/three-active-profiles.XXXXXX")
classifier_output=$(mktemp "${TMPDIR:-/tmp}/three-active-classifier.XXXXXX")
binary_path=$(mktemp "${TMPDIR:-/tmp}/three-active-lifts.XXXXXX")
pruned_output=$(mktemp "${TMPDIR:-/tmp}/three-active-pruned.XXXXXX")
direct_output=$(mktemp "${TMPDIR:-/tmp}/three-active-direct.XXXXXX")
trap 'rm -f "$profile_json" "$classifier_output" "$binary_path" "$pruned_output" "$direct_output"' EXIT HUP INT TERM

python3 classify_three_active_base0.py --output "$profile_json" > "$classifier_output"
diff -u expected-classifier-output.txt "$classifier_output"

c++ -O3 -std=c++17 verify_three_active_global_lifts.cpp -o "$binary_path"
"$binary_path" --input "$profile_json" > "$pruned_output"
"$binary_path" --direct --input "$profile_json" > "$direct_output"
diff -u expected-pruned-output.txt "$pruned_output"
diff -u expected-direct-output.txt "$direct_output"
echo VERIFIED
