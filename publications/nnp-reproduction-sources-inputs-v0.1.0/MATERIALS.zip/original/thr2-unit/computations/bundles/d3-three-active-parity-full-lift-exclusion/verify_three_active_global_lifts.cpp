#include <algorithm>
#include <array>
#include <cctype>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <iterator>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

struct Item {
  int head;
  int tail;
  int mass;
  std::array<int, 5> value;
};

static constexpr std::array<std::array<int, 3>, 4> HEADS{{
    {{+1,+1,+1}}, {{+1,-1,-1}}, {{-1,+1,-1}}, {{-1,-1,+1}},
}};
static constexpr std::array<std::array<int, 2>, 4> TAILS{{
    {{+1,+1}}, {{+1,-1}}, {{-1,+1}}, {{-1,-1}},
}};

static int chi(int base, int block) {
  return (__builtin_popcount(static_cast<unsigned>(base & block)) & 1) ? -1 : +1;
}

static bool active(int total) {
  return total == -4 || total == 0 || total == 4;
}

static std::vector<std::array<int, 8>> label_representatives() {
  std::set<std::array<int, 8>> affine_group;
  for (int x = 1; x < 8; ++x)
    for (int y = 1; y < 8; ++y)
      if (y != x)
        for (int z = 1; z < 8; ++z)
          if (z != x && z != y && z != (x ^ y))
            for (int shift = 0; shift < 8; ++shift) {
              std::array<int, 8> affine{};
              for (int point = 0; point < 8; ++point)
                affine[point] = shift
                    ^ ((point & 1) ? x : 0)
                    ^ ((point & 2) ? y : 0)
                    ^ ((point & 4) ? z : 0);
              affine_group.insert(affine);
            }
  std::set<std::array<int, 8>> remaining;
  std::array<int, 8> permutation{{0,1,2,3,4,5,6,7}};
  do remaining.insert(permutation);
  while (std::next_permutation(permutation.begin(), permutation.end()));
  std::vector<std::array<int, 8>> representatives;
  while (!remaining.empty()) {
    const auto representative = *remaining.begin();
    representatives.push_back(representative);
    for (const auto& affine : affine_group) {
      std::array<int, 8> member{};
      for (int index = 0; index < 8; ++index)
        member[index] = affine[representative[index]];
      remaining.erase(member);
    }
  }
  if (affine_group.size() != 1344 || representatives.size() != 30)
    throw std::runtime_error("AGL quotient construction failed");
  return representatives;
}

static std::vector<std::array<int, 16>> read_profiles(const std::string& path) {
  std::ifstream input(path);
  if (!input) throw std::runtime_error("cannot open profile JSON");
  const std::string text((std::istreambuf_iterator<char>(input)),
                         std::istreambuf_iterator<char>());
  std::vector<std::array<int, 16>> profiles;
  std::size_t position = 0;
  const std::string marker = "\"matrix_rows\"";
  while ((position = text.find(marker, position)) != std::string::npos) {
    position = text.find('[', position + marker.size());
    if (position == std::string::npos) throw std::runtime_error("malformed matrix_rows");
    int depth = 0;
    std::vector<int> values;
    for (; position < text.size(); ++position) {
      const char character = text[position];
      if (character == '[') ++depth;
      else if (character == ']') {
        --depth;
        if (depth == 0) {
          ++position;
          break;
        }
      } else if (std::isdigit(static_cast<unsigned char>(character))) {
        int value = 0;
        while (position < text.size() &&
               std::isdigit(static_cast<unsigned char>(text[position]))) {
          value = 10 * value + (text[position] - '0');
          ++position;
        }
        --position;
        values.push_back(value);
      }
    }
    if (values.size() != 16) throw std::runtime_error("matrix_rows does not have 16 entries");
    std::array<int, 16> profile{};
    std::copy(values.begin(), values.end(), profile.begin());
    profiles.push_back(profile);
  }
  if (profiles.size() != 2214) throw std::runtime_error("expected exactly 2214 profiles");
  return profiles;
}

struct Search {
  Search(const std::vector<std::array<int, 16>>& input_profiles, bool direct_mode)
      : profiles(input_profiles), labels(label_representatives()), direct(direct_mode) {}

  const std::vector<std::array<int, 16>>& profiles;
  std::vector<std::array<int, 8>> labels;
  bool direct;
  bool found = false;
  bool saw_base_zero_feasible = false;

  uint64_t input_profiles = 0;
  uint64_t packable_profiles = 0;
  uint64_t all_partitions = 0;
  uint64_t all_labelings = 0;
  uint64_t tailcover_profiles = 0;
  uint64_t tailcover_partitions = 0;
  uint64_t tailcover_labelings = 0;
  uint64_t full_prop39_profiles = 0;
  uint64_t full_prop39_partitions = 0;
  uint64_t full_prop39_labelings = 0;
  uint64_t full_checks = 0;
  uint64_t pair_base_checks = 0;

  int profile_index = -1;
  std::array<int, 16> profile{};
  std::vector<Item> items;
  std::vector<int> order;
  std::array<std::vector<int>, 8> bins;
  std::array<int, 8> loads{};
  int bin_count = 0;
  uint64_t profile_partitions = 0;
  bool profile_has_tailcover = false;
  bool profile_has_full_prop39 = false;

  std::array<int, 16> witness_profile{};
  std::vector<Item> witness_items;
  std::vector<int> witness_blocks;
  std::array<std::array<int, 8>, 5> witness_totals{};

  bool pair_is_covered(int left, int right, int base,
      const std::vector<int>& block,
      const std::array<std::array<int, 8>, 5>& totals) {
    ++pair_base_checks;
    const int left_walsh = chi(base, block[left]);
    const int right_walsh = chi(base, block[right]);
    for (int row = 0; row < 5; ++row) {
      const int left_value = left_walsh * items[left].value[row];
      const int right_value = right_walsh * items[right].value[row];
      if (left_value == right_value &&
          (totals[row][base] == 0 || totals[row][base] == 4 * left_value))
        return true;
    }
    return false;
  }

  bool check_full(const std::vector<int>& block,
      const std::array<std::array<int, 8>, 5>& totals) {
    ++full_checks;
    for (int left = 0; left < static_cast<int>(items.size()); ++left) {
      const int first_right = items[left].mass >= 2 ? left : left + 1;
      for (int right = first_right; right < static_cast<int>(items.size()); ++right)
        for (int base = 0; base < 8; ++base)
          if (!pair_is_covered(left, right, base, block, totals)) return false;
    }
    return true;
  }

  bool verify_label(const std::array<int, 8>& labeling,
      bool& passes_tailcover, bool& passes_full_prop39) {
    ++all_labelings;
    std::vector<int> block(items.size());
    std::array<std::array<int, 8>, 5> block_sums{};
    for (int bin = 0; bin < 8; ++bin) {
      const int label = labeling[bin];
      for (int item : bins[bin]) {
        block[item] = label;
        for (int row = 0; row < 5; ++row)
          block_sums[row][label] += items[item].mass * items[item].value[row];
      }
    }
    std::array<std::array<int, 8>, 5> totals{};
    for (int row = 0; row < 5; ++row)
      for (int base = 0; base < 8; ++base)
        for (int label = 0; label < 8; ++label)
          totals[row][base] += chi(base, label) * block_sums[row][label];

    if (totals[0][0] || totals[1][0] || totals[2][0] ||
        active(totals[3][0]) || active(totals[4][0]))
      throw std::runtime_error("base-zero invariant failed");

    if (!saw_base_zero_feasible) {
      bool passes = true;
      for (int left = 0; left < static_cast<int>(items.size()) && passes; ++left) {
        const int first_right = items[left].mass >= 2 ? left : left + 1;
        for (int right = first_right; right < static_cast<int>(items.size()); ++right)
          if (!pair_is_covered(left, right, 0, block, totals)) {
            passes = false;
            break;
          }
      }
      saw_base_zero_feasible = passes;
    }

    passes_tailcover = true;
    passes_full_prop39 = false;
    for (int base = 1; base < 8; ++base) {
      if (!active(totals[3][base]) && !active(totals[4][base]))
        passes_tailcover = false;
      int active_count = 0;
      for (int row = 0; row < 5; ++row)
        if (active(totals[row][base])) ++active_count;
      if (active_count >= 4) passes_full_prop39 = true;
    }
    passes_full_prop39 = passes_tailcover && passes_full_prop39;
    if (passes_tailcover) ++tailcover_labelings;
    if (passes_full_prop39) ++full_prop39_labelings;

    if (!direct && !passes_full_prop39) return false;
    if (!check_full(block, totals)) return false;

    found = true;
    witness_profile = profile;
    witness_items = items;
    witness_blocks = block;
    witness_totals = totals;
    return true;
  }

  void pack(int position) {
    if (found) return;
    if (position == static_cast<int>(order.size())) {
      if (bin_count != 8) return;
      for (int bin = 0; bin < 8; ++bin)
        if (loads[bin] != 4) return;
      ++profile_partitions;
      ++all_partitions;
      bool partition_tailcover = false;
      bool partition_full_prop39 = false;
      for (const auto& labeling : labels) {
        bool label_tailcover = false;
        bool label_full_prop39 = false;
        if (verify_label(labeling, label_tailcover, label_full_prop39)) return;
        partition_tailcover = partition_tailcover || label_tailcover;
        partition_full_prop39 = partition_full_prop39 || label_full_prop39;
      }
      if (partition_tailcover) {
        ++tailcover_partitions;
        profile_has_tailcover = true;
      }
      if (partition_full_prop39) {
        ++full_prop39_partitions;
        profile_has_full_prop39 = true;
      }
      return;
    }

    const int item = order[position];
    const int mass = items[item].mass;
    for (int bin = 0; bin < bin_count; ++bin) {
      if (loads[bin] + mass > 4) continue;
      bins[bin].push_back(item);
      loads[bin] += mass;
      pack(position + 1);
      loads[bin] -= mass;
      bins[bin].pop_back();
      if (found) return;
    }
    if (bin_count < 8) {
      bins[bin_count].push_back(item);
      loads[bin_count] = mass;
      ++bin_count;
      pack(position + 1);
      --bin_count;
      loads[bin_count] = 0;
      bins[bin_count].pop_back();
    }
  }

  void run_profile(int index) {
    profile_index = index;
    profile = profiles[index];
    ++input_profiles;
    items.clear();
    for (auto& bin : bins) bin.clear();
    loads.fill(0);
    bin_count = 0;
    profile_partitions = 0;
    profile_has_tailcover = false;
    profile_has_full_prop39 = false;

    for (int head = 0; head < 4; ++head)
      for (int tail = 0; tail < 4; ++tail) {
        const int mass = profile[4 * head + tail];
        if (mass == 0) continue;
        if (mass > 4) throw std::runtime_error("item mass exceeds four");
        Item item{head, tail, mass, {}};
        for (int row = 0; row < 3; ++row) item.value[row] = HEADS[head][row];
        item.value[3] = TAILS[tail][0];
        item.value[4] = TAILS[tail][1];
        items.push_back(item);
      }
    order.resize(items.size());
    for (int item = 0; item < static_cast<int>(items.size()); ++item) order[item] = item;
    std::stable_sort(order.begin(), order.end(), [&](int left, int right) {
      return items[left].mass > items[right].mass;
    });
    pack(0);
    if (profile_partitions > 0) ++packable_profiles;
    if (profile_has_tailcover) ++tailcover_profiles;
    if (profile_has_full_prop39) ++full_prop39_profiles;
  }

  void run() {
    for (int index = 0; index < static_cast<int>(profiles.size()); ++index) {
      run_profile(index);
      if (found) return;
    }
    if (!saw_base_zero_feasible)
      throw std::runtime_error("no base-zero feasible state generated");
  }

  void print_result() const {
    std::cout << (found ? "FULL_WITNESS" : "VERIFIED_INFEASIBLE")
              << " direct=" << (direct ? 1 : 0)
              << " input_profiles=" << input_profiles
              << " packable_profiles=" << packable_profiles
              << " all_partitions=" << all_partitions
              << " all_labelings=" << all_labelings
              << " tailcover_profiles=" << tailcover_profiles
              << " tailcover_partitions=" << tailcover_partitions
              << " tailcover_labelings=" << tailcover_labelings
              << " full_prop39_profiles=" << full_prop39_profiles
              << " full_prop39_partitions=" << full_prop39_partitions
              << " full_prop39_labelings=" << full_prop39_labelings
              << " full_checks=" << full_checks
              << " pair_base_checks=" << pair_base_checks
              << " base0_feasible=" << (saw_base_zero_feasible ? 1 : 0)
              << "\n";
    if (!found) return;
    std::cout << "profile_index=" << profile_index << " matrix=";
    for (int value : witness_profile) std::cout << value << ',';
    std::cout << "\nitems=";
    for (int item = 0; item < static_cast<int>(witness_items.size()); ++item)
      std::cout << '(' << witness_items[item].head << ',' << witness_items[item].tail
                << ',' << witness_items[item].mass << ",b" << witness_blocks[item] << ')';
    std::cout << "\nbaselines=";
    for (int row = 0; row < 5; ++row) {
      std::cout << " row" << (row + 1) << '=';
      for (int base = 0; base < 8; ++base) std::cout << witness_totals[row][base] << ',';
    }
    std::cout << "\n";
  }
};

int main(int argc, char** argv) {
  bool direct = false;
  std::string input = "three_active_base0_orbits.json";
  for (int index = 1; index < argc; ++index) {
    const std::string argument = argv[index];
    if (argument == "--direct") direct = true;
    else if (argument == "--input" && index + 1 < argc) input = argv[++index];
    else throw std::runtime_error("usage: verify_three_active_global_lifts [--direct] [--input PATH]");
  }
  const auto profiles = read_profiles(input);
  Search search(profiles, direct);
  search.run();
  search.print_result();
}
