import argparse
import itertools
import json
import math
from collections import Counter
from pathlib import Path


HEADS = ((1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1))
TAILS = ((1, 1), (1, -1), (-1, 1), (-1, -1))


def tail_group():
    index = {tail: i for i, tail in enumerate(TAILS)}
    permutations = set()
    for swap in (False, True):
        for sign_0 in (-1, 1):
            for sign_1 in (-1, 1):
                image = []
                for tail in TAILS:
                    coordinates = (tail[1], tail[0]) if swap else tail
                    transformed = (sign_0 * coordinates[0], sign_1 * coordinates[1])
                    image.append(index[transformed])
                permutations.add(tuple(image))
    assert len(permutations) == 8
    return tuple(sorted(permutations))


D8 = tail_group()
ROW_TYPES = tuple(
    row for row in itertools.product(range(5), repeat=4) if sum(row) == 8
)


def transform_row(row, permutation):
    transformed = [0] * 4
    for old_column, new_column in enumerate(permutation):
        transformed[new_column] = row[old_column]
    return tuple(transformed)


def transform_matrix(matrix, permutation):
    return tuple(sorted(transform_row(row, permutation) for row in matrix))


def canonical(matrix):
    return min(transform_matrix(matrix, permutation) for permutation in D8)


def tail_baselines(matrix):
    positive_row_4 = sum(row[0] + row[1] for row in matrix)
    positive_row_5 = sum(row[0] + row[2] for row in matrix)
    return 2 * positive_row_4 - 32, 2 * positive_row_5 - 32


def deletion_profiles(matrix):
    delete_row_4 = tuple(
        value
        for row in matrix
        for value in (row[0] + row[2], row[1] + row[3])
    )
    delete_row_5 = tuple(
        value
        for row in matrix
        for value in (row[0] + row[1], row[2] + row[3])
    )
    return delete_row_4, delete_row_5


def prop54_profile_is_valid(profile):
    if max(profile) > 6:
        return False
    if 6 in profile:
        six_index = profile.index(6)
        return all(value <= 4 for index, value in enumerate(profile) if index != six_index)
    return True


def row_permutation_count(matrix):
    multiplicities = Counter(matrix)
    count = math.factorial(4)
    for multiplicity in multiplicities.values():
        count //= math.factorial(multiplicity)
    return count


def record_for(matrix):
    baseline_4, baseline_5 = tail_baselines(matrix)
    deletion_4, deletion_5 = deletion_profiles(matrix)
    d8_images = {transform_matrix(matrix, permutation) for permutation in D8}
    orbit_size = len(d8_images) * row_permutation_count(matrix)
    return {
        "matrix_rows": [list(row) for row in matrix],
        "tail_column_order": ["++", "+-", "-+", "--"],
        "tail_baselines": [baseline_4, baseline_5],
        "delete_row4_masses": list(deletion_4),
        "delete_row5_masses": list(deletion_5),
        "support_size": sum(value > 0 for row in matrix for value in row),
        "row_permutation_count": row_permutation_count(matrix),
        "d8_image_count": len(d8_images),
        "orbit_size": orbit_size,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    total_row_multisets = 0
    inactive_row_multisets = 0
    feasible_row_multisets = 0
    raw_feasible_count = 0
    fixed_counts = [0] * len(D8)
    representatives = set()

    for row_indices in itertools.combinations_with_replacement(range(len(ROW_TYPES)), 4):
        total_row_multisets += 1
        matrix = tuple(ROW_TYPES[index] for index in row_indices)
        baselines = tail_baselines(matrix)
        if any(value in (-4, 0, 4) for value in baselines):
            continue
        inactive_row_multisets += 1
        profiles = deletion_profiles(matrix)
        if not all(prop54_profile_is_valid(profile) for profile in profiles):
            continue
        feasible_row_multisets += 1
        raw_feasible_count += row_permutation_count(matrix)
        representatives.add(canonical(matrix))
        for index, permutation in enumerate(D8):
            if transform_matrix(matrix, permutation) == matrix:
                fixed_counts[index] += 1

    burnside_orbit_count = sum(fixed_counts) // len(D8)
    assert sum(fixed_counts) % len(D8) == 0
    assert burnside_orbit_count == len(representatives)

    records = [record_for(matrix) for matrix in sorted(representatives)]
    for identifier, record in enumerate(records, start=1):
        record["id"] = identifier
    orbit_sum = sum(record["orbit_size"] for record in records)
    assert orbit_sum == raw_feasible_count

    result = {
        "head_order": ["+++", "+--", "-+-", "--+"],
        "tail_column_order": ["++", "+-", "-+", "--"],
        "row_type_count": len(ROW_TYPES),
        "row_multiset_count": total_row_multisets,
        "inactive_row_multiset_count": inactive_row_multisets,
        "prop54_feasible_row_multiset_count": feasible_row_multisets,
        "raw_labeled_head_solution_count": raw_feasible_count,
        "safe_group_size": 192,
        "tail_group_size": len(D8),
        "tail_burnside_fixed_counts": fixed_counts,
        "burnside_orbit_count": burnside_orbit_count,
        "canonical_orbit_count": len(records),
        "orbit_sum_raw_count_check": orbit_sum,
        "orbit_size_histogram": dict(sorted(Counter(r["orbit_size"] for r in records).items())),
        "support_size_histogram": dict(sorted(Counter(r["support_size"] for r in records).items())),
        "records": records,
    }
    output = Path(args.output)
    output.write_text(json.dumps(result, indent=2) + "\n")
    summary = {key: value for key, value in result.items() if key != "records"}
    print(json.dumps(summary, indent=2))
    print("first_record", json.dumps(records[0]))
    print("last_record", json.dumps(records[-1]))


if __name__ == "__main__":
    main()
