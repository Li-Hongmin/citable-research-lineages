# Full-lift exclusion for the three-active parity branch

This bundle closes the second branch isolated by Proposition 37. Translate a Walsh base with
exactly three active rows to (0), normalize the active rows to (1,2,3), and write

[
 H=(+++,+--,-+-,--+)
]

for their four positive-parity signed columns. Each head type has total mass eight. Splitting
each head type by the two tail signs gives a (4\times4) matrix whose rows sum to eight and
whose entries lie in ({0,ldots,4}). The last bound is block capacity: every nonempty
five-bit projective class lies intact in one mass-four block.

The classifier enumerates all (2{,}331{,}890) multisets of four such rows. It retains the
(1{,}034{,}308) matrices for which both tail rows are inactive at the selected base, then
applies Proposition 54 after deleting row 4 and after deleting row 5. This is only a relaxation
of the full Proposition 54 test, so the retained set is a superset of every global candidate.
The resulting (315{,}572) labeled states have (2{,}214) orbits under the safe group

[
 S_4(H)\times D_8(\text{tails}),qquad |G|=192.
]

Burnside's lemma independently returns the same orbit count from fixed counts

[
 (15{,}868,922,0,0,0,0,922,0).
]

For each canonical profile the C++ verifier treats every positive-mass signed five-bit type as
one indivisible item. Restricted-growth recursion generates every partition into eight unlabeled
mass-four blocks, and the (30=8!/|operatorname{AGL}(3,2)|) representatives label those
blocks. It then computes all five baselines at all eight Walsh bases and checks (33jd) for every
pair of distinct items and for the diagonal of every item of mass at least two.

The direct run uses no Proposition 39 tail-cover pruning. Its complete domain is

[
egin{array}{c|r}
	ext{canonical input profiles}&2{,}214\
	ext{packable profiles}&1{,}580\
	ext{unlabeled block partitions}&2{,}478{,}569\
	ext{label states entering (33jd)}&74{,}357{,}070\
	ext{executed pair--base checks}&224{,}374{,}293.
end{array}
]

No state satisfies all pair conditions. The second run first requires the simultaneous
Proposition 39 tail cover and a nonzero base with at least four active rows; it reaches the same
conclusion on 91,464 states. The direct run is the proof path; the pruned run is a cross-check.
The guard `base0_feasible=1` confirms that the generated domain is not vacuously rejected at the
selected base.

Relabeling by the two quotient groups loses no condition. Signed permutations of the three head
rows induce all permutations of (H); signed permutations of the two tail rows induce (D_8).
Affine relabeling of blocks permutes Walsh bases and may reverse all signed columns and baselines
at a base simultaneously, preserving equality of signed entries and
(T_a(g)in{0,4t}).

Run the frozen classification and both global checks with

    ./verify.sh

The bundle was frozen on arm64 macOS. A full run takes about 22 seconds and uses about 10 MB peak
resident memory.
