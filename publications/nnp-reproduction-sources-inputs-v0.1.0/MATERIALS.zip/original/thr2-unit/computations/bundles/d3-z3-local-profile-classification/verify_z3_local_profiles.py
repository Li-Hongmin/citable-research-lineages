#!/usr/bin/env python3
"""Independent finite check of the z=3 four-row projected profiles."""

from __future__ import annotations

import itertools
from collections import Counter
from platform import python_version
from time import perf_counter


VERTICES = tuple(range(16))
TARGET = (32, 16, 16, 16, 18)


def bit(code: int, row: int) -> int:
    return (code >> row) & 1


def compatible(left: int, right: int) -> bool:
    return any(bit(left, row) == bit(right, row) for row in (0, 1, 2)) or (
        bit(left, 3) == bit(right, 3) == 1
    )


ADJACENCY = tuple(
    sum(1 << right for right in VERTICES if right != left and compatible(left, right))
    for left in VERTICES
)


def maximal_cliques() -> list[tuple[int, ...]]:
    result: list[tuple[int, ...]] = []

    def bron_kerbosch(chosen: int, candidates: int, excluded: int) -> None:
        if not candidates and not excluded:
            result.append(tuple(v for v in VERTICES if (chosen >> v) & 1))
            return
        union = candidates | excluded
        pivot = max(
            (v for v in VERTICES if (union >> v) & 1),
            key=lambda v: (candidates & ADJACENCY[v]).bit_count(),
            default=0,
        )
        remaining = candidates & ~ADJACENCY[pivot]
        while remaining:
            vertex_bit = remaining & -remaining
            vertex = vertex_bit.bit_length() - 1
            bron_kerbosch(
                chosen | vertex_bit,
                candidates & ADJACENCY[vertex],
                excluded & ADJACENCY[vertex],
            )
            candidates &= ~vertex_bit
            excluded |= vertex_bit
            remaining &= ~vertex_bit

    bron_kerbosch(0, (1 << 16) - 1, 0)
    return result


def contribution(code: int, multiplicity: int) -> tuple[int, ...]:
    return (multiplicity,) + tuple(
        multiplicity * bit(code, row) for row in range(4)
    )


def add(left: tuple[int, ...], right: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(x + y for x, y in zip(left, right))


def half_assignments(codes: tuple[int, ...]) -> dict[tuple[int, ...], list[tuple[int, ...]]]:
    totals: dict[tuple[int, ...], list[tuple[int, ...]]] = {}
    for values in itertools.product(range(9), repeat=len(codes)):
        total = (0, 0, 0, 0, 0)
        for code, value in zip(codes, values):
            total = add(total, contribution(code, value))
        if all(x <= y for x, y in zip(total, TARGET)):
            totals.setdefault(total, []).append(values)
    return totals


def labelled_profiles(cliques: list[tuple[int, ...]]) -> set[tuple[int, ...]]:
    result: set[tuple[int, ...]] = set()
    for clique in cliques:
        split = len(clique) // 2
        left_codes, right_codes = clique[:split], clique[split:]
        left, right = half_assignments(left_codes), half_assignments(right_codes)
        for left_total, left_values in left.items():
            needed = tuple(target - seen for target, seen in zip(TARGET, left_total))
            for lv in left_values:
                for rv in right.get(needed, ()):
                    profile = [0] * 16
                    for code, value in zip(left_codes, lv):
                        profile[code] = value
                    for code, value in zip(right_codes, rv):
                        profile[code] = value
                    result.add(tuple(profile))
    return result


def symmetry_maps() -> list[tuple[int, ...]]:
    result = []
    for permutation in itertools.permutations(range(3)):
        for flips in itertools.product((0, 1), repeat=3):
            image = []
            for code in VERTICES:
                old = [bit(code, row) for row in range(4)]
                new = [old[permutation[row]] ^ flips[row] for row in range(3)]
                new.append(old[3])
                image.append(sum(value << row for row, value in enumerate(new)))
            result.append(tuple(image))
    assert len(set(result)) == 48
    return result


def transform(profile: tuple[int, ...], mapping: tuple[int, ...]) -> tuple[int, ...]:
    result = [0] * 16
    for source, target in enumerate(mapping):
        result[target] = profile[source]
    return tuple(result)


SYMMETRIES = symmetry_maps()


def canonical(profile: tuple[int, ...]) -> tuple[int, ...]:
    return min(transform(profile, mapping) for mapping in SYMMETRIES)


def code(head: tuple[int, int, int], tail: int) -> int:
    signs = head + (tail,)
    return sum((sign == 1) << row for row, sign in enumerate(signs))


def analytic_profiles() -> set[tuple[int, ...]]:
    tetrahedron = ((1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1))
    result: set[tuple[int, ...]] = set()
    for orientation in (1, -1):
        heads = tuple(tuple(orientation * sign for sign in head) for head in tetrahedron)
        for plus_counts in itertools.product(range(9), repeat=4):
            if sum(plus_counts) != 18:
                continue
            profile = [0] * 16
            for head, plus_count in zip(heads, plus_counts):
                profile[code(head, 1)] = plus_count
                profile[code(head, -1)] = 8 - plus_count
            result.add(tuple(profile))
        for special in itertools.combinations(range(4), 2):
            profile = [0] * 16
            for index, head in enumerate(heads):
                if index in special:
                    opposite = tuple(-sign for sign in head)
                    profile[code(head, 1)] = 8
                    profile[code(opposite, 1)] = 1
                else:
                    profile[code(head, -1)] = 7
            result.add(tuple(profile))
    return result


def main() -> None:
    started = perf_counter()
    cliques = maximal_cliques()
    profiles = labelled_profiles(cliques)
    analytic = analytic_profiles()
    orbit_members: dict[tuple[int, ...], int] = Counter(canonical(p) for p in profiles)
    assert len(cliques) == 81
    assert set(map(len, cliques)) == {8}
    assert len(profiles) == 924
    assert profiles == analytic
    assert len(orbit_members) == 32
    print(f"python={python_version()}")
    print("parameters=baselines=(0,0,0,4),pattern_cap=8")
    print("maximal_cliques=81 (all size 8)")
    print("labelled_profiles=924")
    print("analytic_parameterization_match=yes")
    print("safe_symmetry_group_order=48")
    print("symmetry_orbits=32")
    print("orbit_size_distribution=" + repr(dict(sorted(Counter(orbit_members.values()).items()))))
    print(f"elapsed_seconds={perf_counter() - started:.6f}")


if __name__ == "__main__":
    main()
