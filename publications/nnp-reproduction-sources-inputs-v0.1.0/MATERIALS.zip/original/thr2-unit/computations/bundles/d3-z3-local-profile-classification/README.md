# Local profile classification for the four-active \(z=3\) branch

This bundle independently checks the finite classification used in Proposition 41 of the active
paper. Normalize a four-active Walsh base to

\[
 (T_1(0),T_2(0),T_3(0),T_4(0))=(0,0,0,4).
\]

A projected four-bit pattern records the signs in these rows. The 32 columns have plus-counts
\((16,16,16,18)\), and Proposition 37 bounds every pattern multiplicity by eight. Two occurring
patterns are compatible exactly when they agree in one of the first three coordinates or are
both positive in the fourth coordinate.

The verifier obtains all profiles in two independent ways. First, it enumerates every maximal
clique of the exact 16-vertex compatibility graph and solves the five mass equations by
meet-in-the-middle. Second, it generates the two analytic families from Proposition 41:

- the tetrahedral family, with four head types of total mass eight and fourth-row plus
  multiplicities \(\alpha_i\in\{0,\ldots,8\}\) satisfying \(\sum_i\alpha_i=18\);
- the exceptional family, with two negative head types of mass seven and two all-positive
  antipodal pairs of masses \((8,1)\).

The two sets agree exactly. There are 924 labelled profiles. The safe normalization-preserving
group consists of independent sign changes and permutations of the three zero rows, has order
48, and yields 32 orbits. The tetrahedral family contributes 31 orbits, indexed by unordered
bounded partitions of 18 into four parts; the exceptional family contributes one orbit.

Run from the repository root:

```text
uv run --no-project python units/thr2-lower-bounds/computations/bundles/d3-z3-local-profile-classification/verify_z3_local_profiles.py
```

The classification is local to the selected Walsh base. It neither assigns the two possible
five-bit projective lifts to the eight blocks nor imposes separation at another Walsh base. In
particular, it does not prove that a \(z=3\) five-row family exists or is impossible; it reduces
that global question to 32 safe profile branches.
