#!/usr/bin/env python3
"""Regenerate and verify the five DRAT certificates for the z=2 branch."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
from platform import python_version
import shutil
import subprocess
import sys
import tempfile
from time import perf_counter


BUNDLE = Path(__file__).resolve().parent
PROFILES = range(1, 6)
EXPECTED_CLAUSES = {
    1: 1_230_269,
    2: 1_230_269,
    3: 1_233_966,
    4: 1_230_269,
    5: 1_237_663,
}
EXPECTED_VARIABLES = 19_545


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def check_hashes() -> None:
    checksum_file = BUNDLE / "SHA256SUMS"
    for line in checksum_file.read_text(encoding="ascii").splitlines():
        expected, relative = line.split(maxsplit=1)
        path = BUNDLE / relative.lstrip("*")
        actual = sha256(path)
        if actual != expected:
            raise RuntimeError(f"checksum mismatch for {path.name}: {actual}")
    print("proof_checksums=verified")


def run_checked(command: list[str], *, stdout=None) -> str:
    completed = subprocess.run(
        command,
        check=False,
        stdout=stdout or subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=stdout is None,
    )
    output = "" if stdout is not None else completed.stdout
    if completed.returncode != 0:
        if output:
            print(output, end="", file=sys.stderr)
        raise RuntimeError(
            f"command failed with exit code {completed.returncode}: {' '.join(command)}"
        )
    return output


def main() -> None:
    started = perf_counter()
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--drat-trim",
        type=Path,
        help="path to the drat-trim executable (otherwise resolved from PATH)",
    )
    parser.add_argument(
        "--zstd",
        type=Path,
        help="path to the zstd executable (otherwise resolved from PATH)",
    )
    parser.add_argument(
        "--profile",
        action="append",
        type=int,
        choices=PROFILES,
        help="verify only this profile; repeat to select several",
    )
    args = parser.parse_args()

    drat_trim = str(args.drat_trim) if args.drat_trim else shutil.which("drat-trim")
    zstd = str(args.zstd) if args.zstd else shutil.which("zstd")
    if not drat_trim:
        parser.error("drat-trim was not found; pass --drat-trim /path/to/drat-trim")
    if not zstd:
        parser.error("zstd was not found; pass --zstd /path/to/zstd")

    print(f"python={python_version()}")
    print(f"drat_trim={drat_trim}")
    print(run_checked([zstd, "--version"]).strip())
    check_hashes()
    classification = run_checked([sys.executable, str(BUNDLE / "classify_z2_profiles.py")])
    print(classification, end="")
    if "encoded_profiles_match=yes" not in classification:
        raise RuntimeError("the classified profile orbits do not match the encoded profiles")

    profiles = sorted(set(args.profile or PROFILES))
    with tempfile.TemporaryDirectory(prefix="d3-z2-five-base-") as temporary:
        work = Path(temporary)
        for profile in profiles:
            cnf = work / f"profile-{profile}.cnf"
            proof = work / f"profile-{profile}.drat"
            generated = run_checked(
                [
                    sys.executable,
                    str(BUNDLE / "generate_z2_five_base_cnf.py"),
                    "--bases",
                    "0,4,5,6,7",
                    "--profile",
                    str(profile),
                    "--dimacs",
                    str(cnf),
                ]
            )
            expected = (
                f"variables={EXPECTED_VARIABLES} clauses={EXPECTED_CLAUSES[profile]} "
                "bases=(0, 4, 5, 6, 7)"
            )
            if expected not in generated:
                raise RuntimeError(
                    f"unexpected CNF dimensions for profile {profile}: {generated.strip()}"
                )

            compressed = BUNDLE / "proofs" / f"profile-{profile}.drat.zst"
            run_checked([zstd, "-d", "-q", "-f", "-o", str(proof), str(compressed)])
            verified = run_checked([drat_trim, str(cnf), str(proof), "-i"])
            if "s VERIFIED" not in verified:
                print(verified, end="", file=sys.stderr)
                raise RuntimeError(f"profile {profile} was not verified")
            print(
                f"profile={profile} variables={EXPECTED_VARIABLES} "
                f"clauses={EXPECTED_CLAUSES[profile]} result=VERIFIED"
            )
            cnf.unlink()
            proof.unlink()

    print(f"result=PASS verified_profiles={','.join(map(str, profiles))}")
    print(f"elapsed_seconds={perf_counter() - started:.6f}")


if __name__ == "__main__":
    main()
