#!/usr/bin/env python3
"""Proof-capable CNF for the normalized z=2 projective-type branch.

The formula is a relaxation when ``--bases`` omits Walsh bases: every model
still has eight blocks of mass four, Proposition 37's one-state-per-projective
class property, the exact z=2 normalization at g=0, and complete type-pair
coverage on every listed base.
"""

from __future__ import annotations

import argparse
from pathlib import Path


ROWS = range(5)
BLOCKS = range(8)
CLASSES = range(16)


def chi(g: int, block: int) -> int:
    return -1 if (g & block).bit_count() & 1 else 1


def representative(projective: int, row: int) -> int:
    if row == 4:
        return 1
    return 1 if (projective >> row) & 1 else -1


class CNF:
    def __init__(self) -> None:
        self.nvars = 0
        self.clauses: list[list[int]] = []

    def var(self) -> int:
        self.nvars += 1
        return self.nvars

    def add(self, *literals: int) -> None:
        self.clauses.append(list(literals))

    def exactly_one(self, literals: list[int]) -> None:
        self.add(*literals)
        for index, left in enumerate(literals):
            for right in literals[index + 1 :]:
                self.add(-left, -right)

    def write(self, path: Path) -> None:
        with path.open("w", encoding="ascii") as stream:
            stream.write(f"p cnf {self.nvars} {len(self.clauses)}\n")
            for clause in self.clauses:
                stream.write(" ".join(map(str, clause)) + " 0\n")


# State zero is unused.  Every other state is (block, orientation, mass).
STATES: list[tuple[int | None, int, int]] = [(None, 0, 0)] + [
    (block, orientation, mass)
    for block in BLOCKS
    for orientation in (-1, 1)
    for mass in range(1, 5)
]


def add_categorical_sum(
    cnf: CNF,
    choice: list[list[int]],
    contribution,
    maximum: int,
    target: int | None = None,
) -> list[list[int]]:
    """Exact DP for a sum of contributions chosen by categorical variables."""
    stages = [[cnf.var() for _ in range(maximum + 1)] for _ in range(17)]
    for stage in stages:
        cnf.exactly_one(stage)
    cnf.add(stages[0][0])
    for value in range(1, maximum + 1):
        cnf.add(-stages[0][value])

    for projective in CLASSES:
        for previous in range(maximum + 1):
            for state_index, state in enumerate(STATES):
                value = previous + contribution(projective, state)
                if value <= maximum:
                    cnf.add(
                        -stages[projective][previous],
                        -choice[projective][state_index],
                        stages[projective + 1][value],
                    )
                else:
                    cnf.add(-stages[projective][previous], -choice[projective][state_index])
    if target is not None:
        cnf.add(stages[16][target])
    return stages


PROFILE_PATTERNS = (4, 7, 9, 10, 12, 13, 14, 15)
PROFILES = (
    (6, 8, 6, 8, 2, 2, 0, 0),
    (6, 8, 7, 7, 3, 0, 0, 1),
    (6, 8, 7, 7, 2, 1, 1, 0),
    (7, 7, 7, 7, 0, 2, 2, 0),
    (7, 7, 7, 7, 1, 1, 1, 1),
)


def build(
    bases: tuple[int, ...], profile_index: int | None = None
) -> tuple[CNF, list[list[int]], dict[tuple[int, int, int], int]]:
    cnf = CNF()
    choice = [[cnf.var() for _ in STATES] for _ in CLASSES]
    for states in choice:
        cnf.exactly_one(states)

    if profile_index is not None:
        targets = dict(zip(PROFILE_PATTERNS, PROFILES[profile_index]))
        # Orientation + of class p projects to p on the first four rows;
        # orientation - projects to its complement 15-p.  A compatible
        # clique contains at most one member of each complementary pair.
        for projective in CLASSES:
            for state_index, state in enumerate(STATES[1:], start=1):
                projected = projective if state[1] == 1 else 15 - projective
                if targets.get(projected, 0) == 0:
                    cnf.add(-choice[projective][state_index])
        # For each surviving projected pattern x, exactly its two canonical
        # classes x and 15-x can realize it.  Forbid every mass pair that does
        # not sum to the prescribed aggregate profile.
        for projected, target in targets.items():
            if target == 0:
                continue
            left, right = projected, 15 - projected
            for left_index, left_state in enumerate(STATES):
                left_mass = (
                    left_state[2]
                    if left_state[0] is not None and left_state[1] == 1
                    else 0
                )
                for right_index, right_state in enumerate(STATES):
                    right_mass = (
                        right_state[2]
                        if right_state[0] is not None and right_state[1] == -1
                        else 0
                    )
                    if left_mass + right_mass != target:
                        cnf.add(-choice[left][left_index], -choice[right][right_index])

    # Exactly four coordinates in every Walsh block.
    for block in BLOCKS:
        add_categorical_sum(
            cnf,
            choice,
            lambda _p, state, block=block: state[2] if state[0] == block else 0,
            maximum=4,
            target=4,
        )

    final_count: dict[tuple[int, int, int], int] = {}
    for row in ROWS:
        for g in bases:
            stages = add_categorical_sum(
                cnf,
                choice,
                lambda p, state, row=row, g=g: (
                    state[2]
                    if state[0] is not None
                    and state[1] * representative(p, row) * chi(g, state[0]) == 1
                    else 0
                ),
                maximum=32,
            )
            for count in range(33):
                final_count[row, g, count] = stages[16][count]

    # Exact z=2 normalization.  The inactive fifth row can independently be
    # negated, so fix its nonzero baseline positive (plus count > 16).
    cnf.add(final_count[0, 0, 16])
    cnf.add(final_count[1, 0, 16])
    cnf.add(final_count[2, 0, 18])
    cnf.add(final_count[3, 0, 18])
    cnf.add(*[final_count[4, 0, count] for count in range(17, 33) if count != 18])

    value_plus: dict[tuple[int, int, int], int] = {}
    for projective in CLASSES:
        for g in bases:
            for row in ROWS:
                literal = cnf.var()
                value_plus[projective, g, row] = literal
                for state_index, state in enumerate(STATES):
                    if state[0] is None:
                        positive = False
                    else:
                        positive = (
                            state[1]
                            * representative(projective, row)
                            * chi(g, state[0])
                            == 1
                        )
                    cnf.add(-choice[projective][state_index], literal if positive else -literal)

    def add_witness_conditions(witness: int, p: int, g: int, row: int, q: int | None) -> None:
        # A witness may only refer to selected types.
        cnf.add(-witness, -choice[p][0])
        if q is not None:
            cnf.add(-witness, -choice[q][0])
            vp, vq = value_plus[p, g, row], value_plus[q, g, row]
            cnf.add(-witness, -vp, vq)
            cnf.add(-witness, vp, -vq)
        vp = value_plus[p, g, row]
        # vp=+1 requires T in {0,+4}; vp=-1 requires T in {0,-4}.
        cnf.add(-witness, -vp, final_count[row, g, 16], final_count[row, g, 18])
        cnf.add(-witness, vp, final_count[row, g, 16], final_count[row, g, 14])

    for p in CLASSES:
        for q in range(p + 1, 16):
            for g in bases:
                witnesses = []
                for row in ROWS:
                    witness = cnf.var()
                    witnesses.append(witness)
                    add_witness_conditions(witness, p, g, row, q)
                cnf.add(choice[p][0], choice[q][0], *witnesses)

    # Repeated coordinates of one selected type also require a witness.
    for p in CLASSES:
        nonrepeated = [choice[p][0]] + [
            choice[p][state_index]
            for state_index, state in enumerate(STATES)
            if state_index and state[2] == 1
        ]
        for g in bases:
            witnesses = []
            for row in ROWS:
                witness = cnf.var()
                witnesses.append(witness)
                add_witness_conditions(witness, p, g, row, None)
            cnf.add(*nonrepeated, *witnesses)

    return cnf, choice, final_count


def decode(choice: list[list[int]], model: list[int]) -> list[list[int]]:
    positive = {literal for literal in model if literal > 0}
    columns: list[list[int]] = []
    for block in BLOCKS:
        block_columns = []
        for projective in CLASSES:
            selected = [index for index, literal in enumerate(choice[projective]) if literal in positive]
            assert len(selected) == 1
            state = STATES[selected[0]]
            if state[0] == block:
                column = [state[1] * representative(projective, row) for row in ROWS]
                block_columns.extend([column] * state[2])
        assert len(block_columns) == 4
        columns.extend(block_columns)
    return columns


def verify(columns: list[list[int]], bases: tuple[int, ...]) -> None:
    totals = [
        [sum(columns[i][row] * chi(g, i // 4) for i in range(32)) for g in range(8)]
        for row in ROWS
    ]
    assert [totals[row][0] for row in range(4)] == [0, 0, 4, 4]
    assert totals[4][0] > 0 and totals[4][0] not in (-4, 0, 4)
    checked = 0
    for g in bases:
        for left in range(32):
            for right in range(left + 1, 32):
                assert any(
                    (vl := columns[left][row] * chi(g, left // 4))
                    == columns[right][row] * chi(g, right // 4)
                    and totals[row][g] in (0, 4 * vl)
                    for row in ROWS
                ), (g, left, right)
                checked += 1
    print(f"verified_requirements={checked}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bases", default="0,4,5,6,7")
    parser.add_argument("--dimacs", type=Path)
    parser.add_argument("--solve", action="store_true")
    parser.add_argument("--profile", type=int, choices=range(1, 6))
    args = parser.parse_args()
    bases = tuple(sorted({int(item) for item in args.bases.split(",") if item}))
    if 0 not in bases or any(g not in range(8) for g in bases):
        raise ValueError("bases must contain 0 and lie in 0,...,7")
    profile_index = None if args.profile is None else args.profile - 1
    cnf, choice, _ = build(bases, profile_index)
    print(f"variables={cnf.nvars} clauses={len(cnf.clauses)} bases={bases}")
    if args.dimacs:
        cnf.write(args.dimacs)
    if args.solve:
        from pysat.solvers import Solver

        with Solver(name="cadical195", bootstrap_with=cnf.clauses) as solver:
            satisfiable = solver.solve()
            print("s SATISFIABLE" if satisfiable else "s UNSATISFIABLE")
            if satisfiable:
                columns = decode(choice, solver.get_model())
                verify(columns, bases)
                for row in ROWS:
                    print("".join("+" if column[row] == 1 else "-" for column in columns))


if __name__ == "__main__":
    main()
