#!/usr/bin/env python3
"""Exhaustively classify the local four-row profiles for the z=2 branch.

Rows 0 and 1 have baseline zero, rows 2 and 3 have baseline +4.  A projected
four-bit pattern has at most eight occurrences: it has two five-bit
projective lifts, and Proposition 37 lets each lift occur in only one block
with multiplicity at most four.

The search uses only Python integers.  It enumerates the maximal cliques of
the exact local compatibility graph and solves the four row-sum equations by
a meet-in-the-middle enumeration.  The 30 labelled solutions form the five
orbits hard-coded in generate_z2_five_base_cnf.py.
"""

from __future__ import annotations

import itertools
import sys

sys.dont_write_bytecode = True
import generate_z2_five_base_cnf as generator


VERTICES = range(16)
TARGET = (32, 16, 16, 18, 18)


def bit(code: int, row: int) -> int:
    return (code >> row) & 1


def compatible(left: int, right: int) -> bool:
    zero_row_agreement = any(bit(left, row) == bit(right, row) for row in (0, 1))
    positive_row_agreement = any(
        bit(left, row) == bit(right, row) == 1 for row in (2, 3)
    )
    return zero_row_agreement or positive_row_agreement


ADJACENCY = [
    sum(1 << right for right in VERTICES if right != left and compatible(left, right))
    for left in VERTICES
]


def maximal_cliques() -> list[tuple[int, ...]]:
    result: list[tuple[int, ...]] = []

    def bron_kerbosch(chosen: int, candidates: int, excluded: int) -> None:
        if not candidates and not excluded:
            result.append(tuple(v for v in VERTICES if (chosen >> v) & 1))
            return
        union = candidates | excluded
        pivot = max(
            (v for v in VERTICES if (union >> v) & 1),
            key=lambda v: (candidates & ADJACENCY[v]).bit_count(),
            default=0,
        )
        remaining = candidates & ~ADJACENCY[pivot]
        while remaining:
            vertex_bit = remaining & -remaining
            vertex = vertex_bit.bit_length() - 1
            bron_kerbosch(
                chosen | vertex_bit,
                candidates & ADJACENCY[vertex],
                excluded & ADJACENCY[vertex],
            )
            candidates &= ~vertex_bit
            excluded |= vertex_bit
            remaining &= ~vertex_bit

    bron_kerbosch(0, (1 << 16) - 1, 0)
    return result


def contribution(code: int, multiplicity: int) -> tuple[int, ...]:
    return (multiplicity,) + tuple(
        multiplicity * bit(code, row) for row in range(4)
    )


def add_vectors(left: tuple[int, ...], right: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(x + y for x, y in zip(left, right))


def half_assignments(codes: tuple[int, ...]) -> dict[tuple[int, ...], list[tuple[int, ...]]]:
    totals: dict[tuple[int, ...], list[tuple[int, ...]]] = {}
    bounds = [8 if compatible(code, code) else 1 for code in codes]
    for values in itertools.product(*(range(bound + 1) for bound in bounds)):
        total = (0, 0, 0, 0, 0)
        for code, value in zip(codes, values):
            total = add_vectors(total, contribution(code, value))
        if all(total[index] <= TARGET[index] for index in range(5)):
            totals.setdefault(total, []).append(values)
    return totals


def labelled_profiles() -> set[tuple[int, ...]]:
    solutions: set[tuple[int, ...]] = set()
    for clique in maximal_cliques():
        assert len(clique) == 8
        left_codes, right_codes = clique[:4], clique[4:]
        left = half_assignments(left_codes)
        right = half_assignments(right_codes)
        for left_total, left_values in left.items():
            needed = tuple(TARGET[index] - left_total[index] for index in range(5))
            if needed not in right:
                continue
            for left_value in left_values:
                for right_value in right[needed]:
                    profile = [0] * 16
                    for code, value in zip(left_codes, left_value):
                        profile[code] = value
                    for code, value in zip(right_codes, right_value):
                        profile[code] = value
                    solutions.add(tuple(profile))
    return solutions


def symmetry_maps() -> list[tuple[int, ...]]:
    maps = []
    for zero_flips in range(4):
        for swap_zero in (False, True):
            for swap_positive in (False, True):
                image = []
                for code in VERTICES:
                    bits = [bit(code, row) for row in range(4)]
                    bits[0] ^= zero_flips & 1
                    bits[1] ^= (zero_flips >> 1) & 1
                    if swap_zero:
                        bits[0], bits[1] = bits[1], bits[0]
                    if swap_positive:
                        bits[2], bits[3] = bits[3], bits[2]
                    image.append(sum(bits[row] << row for row in range(4)))
                maps.append(tuple(image))
    return maps


SYMMETRIES = symmetry_maps()


def canonical(profile: tuple[int, ...]) -> tuple[int, ...]:
    return min(tuple(profile[image[code]] for code in VERTICES) for image in SYMMETRIES)


def encoded_profiles() -> set[tuple[int, ...]]:
    result = set()
    for values in generator.PROFILES:
        profile = [0] * 16
        for code, value in zip(generator.PROFILE_PATTERNS, values):
            profile[code] = value
        result.add(canonical(tuple(profile)))
    return result


def main() -> None:
    solutions = labelled_profiles()
    orbits = {canonical(profile) for profile in solutions}
    expected = encoded_profiles()
    assert len(maximal_cliques()) == 36
    assert len(solutions) == 30
    assert len(orbits) == 5
    assert orbits == expected
    print("maximal_cliques=36")
    print("labelled_profiles=30")
    print("symmetry_orbits=5")
    print("encoded_profiles_match=yes")
    for index, profile in enumerate(sorted(orbits), start=1):
        entries = ",".join(f"{code}:{value}" for code, value in enumerate(profile) if value)
        print(f"orbit_{index}={entries}")


if __name__ == "__main__":
    main()
