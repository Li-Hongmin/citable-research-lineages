# Five-base DRAT certificates for the four-active \(z=2\) branch

This bundle verifies the finite certificate used in Proposition 40 of the active paper. Under
the assumptions of Proposition 37, fix a Walsh base with exactly four active rows, negate its
nonzero active baselines to \(+4\), and let \(z\) be the number of zero active baselines. The
bundle rules out \(z=2\). Together with the elementary exclusion of \(z=0,1\) in Proposition 38,
this proves that every four-active base has at least three zero active baselines.

## Exhaustive local profiles

After translating the chosen base to \(0\), the four active baselines have the normalized form

\[
 (T_1(0),T_2(0),T_3(0),T_4(0))=(0,0,4,4).
\]

Projecting the 32 signed columns to these four rows gives plus-counts \((16,16,18,18)\). Any two
projected patterns must either agree in a zero-baseline row or both be positive in a
\(+4\)-baseline row. Each four-bit pattern has at most eight occurrences: it has two five-bit
projective lifts, and Proposition 37 allows each lift in only one block with multiplicity at most
four.

`classify_z2_profiles.py` exhausts this finite system. It enumerates the 36 maximal compatible
cliques and solves the exact row sums by meet-in-the-middle. There are 30 labelled profiles and
five orbits under independent negation and interchange of the two zero rows and interchange of
the two \(+4\) rows. In the fixed pattern order

```text
(4, 7, 9, 10, 12, 13, 14, 15)
```

the five representatives encoded by the CNF generator are

```text
(6, 8, 6, 8, 2, 2, 0, 0)
(6, 8, 7, 7, 3, 0, 0, 1)
(6, 8, 7, 7, 2, 1, 1, 0)
(7, 7, 7, 7, 0, 2, 2, 0)
(7, 7, 7, 7, 1, 1, 1, 1)
```

## Certified five-base relaxation

For each profile, `generate_z2_five_base_cnf.py` retains only the Walsh bases

\[
 G_*=\{0,4,5,6,7\}.
\]

The omitted bases \(1,2,3\) impose no separation or activity conditions, so each formula is a
strict relaxation of the original eight-base branch. The formula uses the 16 projective
five-row column classes. A class is either unused or assigned a unique block, orientation, and
multiplicity in \(\{1,2,3,4\}\); every block has total mass four. The clauses impose the full
distinct-class and repeated-class type-pair separation conditions on every base in \(G_*\), as
well as the normalized \(z=2\) baselines. The five deterministic CNFs have these dimensions:

```text
profile  variables  clauses
1        19545      1230269
2        19545      1230269
3        19545      1233966
4        19545      1230269
5        19545      1237663
```

All five relaxations are UNSAT. The binary DRAT proofs in `proofs/` were generated with CaDiCaL
3.0.1 at commit `c60730422e758ef1cebe7aeddf2dda31c996bf04`, trimmed and independently checked
with `drat-trim` at commit `2e3b2dc0ecf938addbd779d42877b6ed69d9a985`, and compressed with zstd. `SHA256SUMS` fixes the
compressed proof bytes. `verification-output.txt` records the complete five-profile verification
run, tool versions, and timing from 2026-08-23.

## Verification

Build `drat-trim` at the recorded commit and make `zstd` available, then run from the repository
root:

```text
uv run --no-project python units/thr2-lower-bounds/computations/bundles/d3-z2-five-base-unsat/verify_bundle.py \
  --drat-trim /path/to/drat-trim
```

The verifier checks the proof hashes, reruns the exhaustive profile classification, regenerates
one CNF at a time, decompresses its proof into a temporary directory, and requires `s VERIFIED`
from `drat-trim`. Use `--profile 1` for a quick single-certificate check. Sequential regeneration
keeps only one CNF and one decompressed proof on disk at a time.

The conclusion is limited to the \(z=2\) four-active branch. It neither resolves the remaining
\(z=3,4\) type assignments nor decides the global three-active parity branch, and therefore does
not by itself prove
\(\nu_{3,0}(4,4,4,4,4,4,4,4)=6\).
