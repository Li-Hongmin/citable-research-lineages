# Full-lift exclusion for the final four \(z=4\) profiles

This bundle exhausts every global eight-block lift of the three profiles left by Proposition 54
and, redundantly, the additional mass-\(6\)/mass-\(5\) profile excluded analytically in its
proof. In the common projected-pattern order

\[
 \texttt{--+-},\ \texttt{--++},\ \texttt{-+--},\ \texttt{-+-+},\
 \texttt{+---},\ \texttt{+--+},\ \texttt{+++-},\ \texttt{++++},
\]

their multiplicity vectors are

\[
\begin{array}{c|c}
\text{id}&(m_0,\ldots,m_7)\\ \hline
26&(2,6,4,4,5,3,5,3)\\
27&(3,5,3,5,5,3,5,3)\\
28&(3,5,4,4,4,4,5,3)\\
29&(4,4,4,4,4,4,4,4).
\end{array}
\]

For every projected type the verifier enumerates every split between its tail-positive and
tail-negative five-row lifts. Each nonempty lift is an indivisible projective class of mass at
most four. Negating row 5 covers negative selected-base baselines, so the direct run enumerates
every reachable positive even \(T_5(0)\), excluding the active value \(4\). In particular, the
uniform profile includes the all-positive \(T_5(0)=32\) split.

For every split the verifier:

1. generates each partition of the lift items into eight unlabeled mass-four blocks exactly once
   by restricted-growth recursion;
2. assigns block labels through the \(30=8!/|\operatorname{AGL}(3,2)|\) representatives;
3. computes all five row baselines at all eight Walsh bases;
4. checks (33jd) for every pair of distinct lift types and for the diagonal of every type whose
   multiplicity is at least two.

The direct exhaustive domains are

\[
\begin{array}{c|r|r|r|r}
\text{id}&\text{splits}&\text{partitions}&\text{label states}
  &\text{executed pair--base checks}\\ \hline
26&19{,}465&7{,}455{,}927&223{,}677{,}810&848{,}107{,}776\\
27&21{,}994&14{,}090{,}460&422{,}713{,}800&2{,}161{,}028{,}047\\
28&56{,}310&19{,}519{,}527&585{,}585{,}810&3{,}195{,}234{,}899\\
29&142{,}230&27{,}105{,}279&813{,}158{,}370&6{,}073{,}560{,}521.
\end{array}
\]

No state satisfies the complete pair conditions. The direct run disables both the
Proposition 49 early rejection and the Proposition 54 selected-base split rejection, so all
\(2{,}045{,}135{,}790\) label states enter the complete (33jd) loop. A second run enables both
safe analytic rejections and reaches the same conclusion. Each profile also passes a guard
confirming that the generated domain contains a state satisfying all selected-base type-pair
conditions.

The affine quotient loses no condition. Relabeling blocks by
\(\operatorname{AGL}(3,2)\) permutes the Walsh bases and may reverse simultaneously all signed
columns and baselines at a base; equality of signed columns and the condition
\(T_a(g)\in\{0,4t\}\) are invariant.

Run both frozen classifications with

    ./verify.sh

The bundle was frozen with Apple clang 21.0.0 on arm64 macOS. The direct run takes about
152 seconds in total and uses less than 5 MB peak RSS.
