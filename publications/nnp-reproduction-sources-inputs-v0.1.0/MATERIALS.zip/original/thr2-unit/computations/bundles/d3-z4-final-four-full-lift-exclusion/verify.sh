#!/bin/sh
set -eu

bundle_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$bundle_dir"

shasum -a 256 -c SHA256SUMS
binary_path=$(mktemp "${TMPDIR:-/tmp}/z4-final-four-full-lifts.XXXXXX")
pruned_output=$(mktemp "${TMPDIR:-/tmp}/z4-final-four-pruned.XXXXXX")
direct_output=$(mktemp "${TMPDIR:-/tmp}/z4-final-four-direct.XXXXXX")
trap 'rm -f "$binary_path" "$pruned_output" "$direct_output"' EXIT HUP INT TERM

c++ -O3 -std=c++17 verify_z4_final_four_full_lifts.cpp -o "$binary_path"
for id in 26 27 28 29; do
  "$binary_path" --id "$id" >> "$pruned_output"
  "$binary_path" --id "$id" --direct >> "$direct_output"
done
diff -u expected-pruned-output.txt "$pruned_output"
diff -u expected-direct-output.txt "$direct_output"
echo VERIFIED
