#!/usr/bin/env python3
"""Exhaust the Proposition-49 tail-row block-sum relaxation."""

from __future__ import annotations

import argparse
import itertools
from dataclasses import dataclass


PROFILES = {
    19: (2, 3, 6, 7),
    21: (2, 4, 5, 7),
    22: (3, 3, 5, 7),
    23: (3, 4, 4, 7),
    26: (2, 4, 6, 6),
    27: (3, 3, 6, 6),
    28: (2, 5, 5, 6),
    29: (3, 4, 5, 6),
    30: (4, 4, 4, 6),
    31: (3, 5, 5, 5),
    32: (4, 4, 5, 5),
}
EXPECTED_FEASIBLE = {30, 31, 32}
BLOCK_SUMS = (-4, -2, 0, 2, 4)
BASE_ZERO_TOTALS = {8, 12, 16, 20, 24, 28}


@dataclass(frozen=True)
class Witness:
    block_sums: tuple[int, ...]
    totals: tuple[int, ...]
    masses: tuple[int, ...]
    placements: tuple[tuple[int, int | None, int, int | None], ...]


def chi(base: int, block: int) -> int:
    return -1 if (base & block).bit_count() & 1 else 1


CHARACTERS = tuple(
    tuple(chi(base, block) for block in range(8)) for base in range(8)
)


def walsh_transform(block_sums: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(
        sum(CHARACTERS[base][block] * block_sums[block] for block in range(8))
        for base in range(8)
    )


def allowed_overfull_pairs(totals: tuple[int, ...]) -> frozenset[tuple[int, int]]:
    allowed = set()
    for positive_block in range(8):
        for negative_block in range(8):
            if positive_block == negative_block:
                continue
            difference = positive_block ^ negative_block
            if all(
                totals[base] in (0, 4 * CHARACTERS[base][positive_block])
                for base in range(1, 8)
                if CHARACTERS[base][difference] == -1
            ):
                allowed.add((positive_block, negative_block))
    return frozenset(allowed)


def candidate_spectra():
    for block_sums in itertools.product(BLOCK_SUMS, repeat=8):
        if sum(block_sums) not in BASE_ZERO_TOTALS:
            continue
        totals = walsh_transform(block_sums)
        allowed = allowed_overfull_pairs(totals)
        if allowed:
            yield block_sums, totals, allowed


def pattern_masses(partition: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(value for alpha in partition for value in (alpha, 8 - alpha))


def search_profile(
    partition: tuple[int, ...],
    spectra: tuple[tuple[tuple[int, ...], tuple[int, ...], frozenset[tuple[int, int]]], ...],
) -> tuple[Witness | None, int]:
    masses = pattern_masses(partition)
    order = tuple(
        sorted(range(8), key=lambda pattern: (masses[pattern] > 4, masses[pattern]), reverse=True)
    )
    nodes = 0

    for block_sums, totals, allowed in spectra:
        positive_capacity = tuple((4 + value) // 2 for value in block_sums)
        negative_capacity = tuple(4 - value for value in positive_capacity)
        placements: list[tuple[int, int | None, int, int | None] | None] = [None] * 8

        def visit(
            position: int,
            positive_left: tuple[int, ...],
            negative_left: tuple[int, ...],
        ) -> bool:
            nonlocal nodes
            nodes += 1
            if position == 8:
                return positive_left == negative_left == (0,) * 8

            pattern = order[position]
            mass = masses[pattern]
            for positive_mass in range(max(0, mass - 4), min(4, mass) + 1):
                negative_mass = mass - positive_mass
                positive_blocks = (
                    (None,)
                    if positive_mass == 0
                    else tuple(
                        block
                        for block, capacity in enumerate(positive_left)
                        if capacity >= positive_mass
                    )
                )
                negative_blocks = (
                    (None,)
                    if negative_mass == 0
                    else tuple(
                        block
                        for block, capacity in enumerate(negative_left)
                        if capacity >= negative_mass
                    )
                )
                for positive_block in positive_blocks:
                    for negative_block in negative_blocks:
                        if mass > 4 and (positive_block, negative_block) not in allowed:
                            continue
                        next_positive = list(positive_left)
                        next_negative = list(negative_left)
                        if positive_block is not None:
                            next_positive[positive_block] -= positive_mass
                        if negative_block is not None:
                            next_negative[negative_block] -= negative_mass
                        placements[pattern] = (
                            positive_mass,
                            positive_block,
                            negative_mass,
                            negative_block,
                        )
                        if visit(position + 1, tuple(next_positive), tuple(next_negative)):
                            return True
            placements[pattern] = None
            return False

        if visit(0, positive_capacity, negative_capacity):
            assert all(placement is not None for placement in placements)
            return (
                Witness(
                    block_sums=block_sums,
                    totals=totals,
                    masses=masses,
                    placements=tuple(placements),  # type: ignore[arg-type]
                ),
                nodes,
            )
    return None, nodes


def format_placement(placement: tuple[int, int | None, int, int | None]) -> str:
    positive_mass, positive_block, negative_mass, negative_block = placement
    return f"+{positive_mass}@{positive_block},-{negative_mass}@{negative_block}"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile", type=int, choices=tuple(PROFILES))
    args = parser.parse_args()

    spectra = tuple(candidate_spectra())
    print(f"candidate_spectra={len(spectra)}")
    selected = (args.profile,) if args.profile else tuple(PROFILES)
    feasible = set()
    for profile in selected:
        witness, nodes = search_profile(PROFILES[profile], spectra)
        if witness is None:
            print(
                f"profile={profile} partition={PROFILES[profile]} "
                f"VERIFIED_INFEASIBLE nodes={nodes}"
            )
            continue
        feasible.add(profile)
        print(
            f"profile={profile} partition={PROFILES[profile]} ROW5_WITNESS "
            f"nodes={nodes} block_sums={witness.block_sums} totals={witness.totals}"
        )
        for pattern, placement in enumerate(witness.placements):
            print(
                f"  pattern={pattern} mass={witness.masses[pattern]} "
                f"{format_placement(placement)}"
            )

    if args.profile is None:
        assert feasible == EXPECTED_FEASIBLE
        print(f"VERIFIED_CLASSIFICATION feasible={tuple(sorted(feasible))}")


if __name__ == "__main__":
    main()
