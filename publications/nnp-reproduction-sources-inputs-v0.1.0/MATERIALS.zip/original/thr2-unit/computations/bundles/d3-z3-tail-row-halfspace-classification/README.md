# Tail-row affine-halfspace classification

This bundle exhausts the row-5 relaxation induced by Proposition 49 for the eleven surviving
tetrahedral \(z=3\) profiles.

For a profile \((\alpha_1,\ldots,\alpha_4)\), the eight projected-pattern masses are

\[
 (\alpha_1,8-\alpha_1,\ldots,\alpha_4,8-\alpha_4).
\]

Each pattern of mass \(m\) is split between its tail-positive and tail-negative five-row lifts.
Either lift is an intact projective class of mass at most four and is assigned to one of eight
labeled mass-four blocks. If \(S_\lambda\in\{-4,-2,0,2,4\}\) is the fifth-row sum in block
\(\lambda\), the verifier enumerates all \(5^8\) block-sum vectors. Proposition 49 and the
inactive-positive normalization restrict

\[
 T_5(0)=\sum_\lambda S_\lambda\in\{8,12,16,20,24,28\}.
\]

For every projected mass \(m>4\), both lifts occur in distinct blocks
\(\lambda_+,\lambda_-\). The verifier imposes the exact necessary condition

\[
 g\cdot(\lambda_++\lambda_-)=1
 \Longrightarrow
 T_5(g)\in\{0,4\chi_g(\lambda_+)\}.
\]

The recursion enumerates every admissible lift split, every assignment of each intact lift to a
labeled block, and every exact filling of the positive and negative capacities determined by
\((S_\lambda)\). No block-label symmetry quotient is used.

The exhaustive result is

\[
 \begin{array}{c|c}
 \text{row-5 relaxation infeasible}
 & (2,3,6,7),(2,4,5,7),(2,4,6,6),(2,5,5,6),\\
 & (3,3,5,7),(3,3,6,6),(3,4,4,7),(3,4,5,6)\\ \hline
 \text{row-5 relaxation feasible}
 & (3,5,5,5),(4,4,4,6),(4,4,5,5).
 \end{array}
\]

The three displayed witnesses certify only feasibility of this relaxation. They do not satisfy,
and are not claimed to satisfy, the first four rows' complete eight-base pair conditions.

Run the frozen verification with

```bash
./verify.sh
```

The bundle was frozen with `uv 0.12.3` and `Python 3.13.15` on arm64 macOS. Its classification
was independently cross-checked against a restricted-growth enumeration of unlabeled mass-four
block partitions followed by all \(8!/|\operatorname{AGL}(3,2)|=30\) block-label orbits.
