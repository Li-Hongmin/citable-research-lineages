#!/bin/sh
set -eu

bundle_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$bundle_dir"

shasum -a 256 -c SHA256SUMS
actual_output=$(mktemp "${TMPDIR:-/tmp}/tail-row-halfspace.XXXXXX")
trap 'rm -f "$actual_output"' EXIT HUP INT TERM
uv run --no-project python verify_tail_row_halfspaces.py > "$actual_output"
diff -u expected-output.txt "$actual_output"
echo VERIFIED
