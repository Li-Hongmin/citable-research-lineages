#!/bin/sh
set -eu

bundle_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$bundle_dir"

shasum -a 256 -c SHA256SUMS
output_path=$(mktemp "${TMPDIR:-/tmp}/z4-selected-base.XXXXXX")
trap 'rm -f "$output_path"' EXIT HUP INT TERM

uv run python classify_z4_selected_base.py > "$output_path"
diff -u expected-orbits.json "$output_path"
echo VERIFIED
