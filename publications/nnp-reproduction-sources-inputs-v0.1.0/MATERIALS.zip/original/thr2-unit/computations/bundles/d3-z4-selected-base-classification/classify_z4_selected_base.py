#!/usr/bin/env python3
"""Exact orbit classification for four-active z=4 selected-base profiles.

A profile is m:{-1,1}^4 -> {0,...,8} with total mass 32, zero
coordinate margins, and antipodal-free support.  We encode it by signed
coefficients n on the eight representatives whose first coordinate is +1.
"""

from collections import Counter, defaultdict
from itertools import permutations, product
import json


PATTERNS = tuple(product((-1, 1), repeat=4))
PATTERN_INDEX = {p: i for i, p in enumerate(PATTERNS)}
PAIR_REPS = tuple(p for p in PATTERNS if p[0] == 1)


def half_table(points):
    table = defaultdict(list)
    for coeffs in product(range(-8, 9), repeat=4):
        mass = sum(abs(x) for x in coeffs)
        if mass > 32:
            continue
        balance = tuple(sum(x * p[j] for x, p in zip(coeffs, points)) for j in range(4))
        table[(mass, *balance)].append(coeffs)
    return table


def signed_coeffs_to_profile(coeffs):
    m = [0] * 16
    for n, p in zip(coeffs, PAIR_REPS):
        if n > 0:
            m[PATTERN_INDEX[p]] = n
        elif n < 0:
            m[PATTERN_INDEX[tuple(-x for x in p)]] = -n
    return tuple(m)


def enumerate_profiles():
    left = half_table(PAIR_REPS[:4])
    right = half_table(PAIR_REPS[4:])
    for (mass, *balance), left_coeffs in left.items():
        target = (32 - mass, *(-x for x in balance))
        for a in left_coeffs:
            for b in right.get(target, ()):
                yield signed_coeffs_to_profile(a + b)


def group_image_maps():
    maps = []
    for perm in permutations(range(4)):
        for signs in product((-1, 1), repeat=4):
            image = []
            for p in PATTERNS:
                q = tuple(signs[j] * p[perm[j]] for j in range(4))
                image.append(PATTERN_INDEX[q])
            maps.append(tuple(image))
    assert len(maps) == 384 and len(set(maps)) == 384
    return tuple(maps)


def transform(m, image_map):
    out = [0] * 16
    for old, new in enumerate(image_map):
        out[new] = m[old]
    return tuple(out)


def canonical(m, group):
    return min(transform(m, g) for g in group)


def pattern_word(p):
    return "".join("+" if x == 1 else "-" for x in p)


def support_geometry(m):
    support = [PATTERNS[i] for i, x in enumerate(m) if x]
    # Signed-coordinate permutations preserve all pairwise dot products.
    dots = Counter()
    for i, p in enumerate(support):
        for q in support[i + 1 :]:
            dots[sum(x * y for x, y in zip(p, q))] += 1
    return tuple(sorted(dots.items()))


def tail_split_info(m):
    bounds = [(max(0, x - 4), min(4, x)) for x in m if x]
    lo = sum(a for a, _ in bounds)
    hi = sum(b for _, b in bounds)
    assert hi == 32 - lo
    reachable = {0}
    for a, b in bounds:
        reachable = {old + new for old in reachable for new in range(a, b + 1)}
    assert reachable == set(range(lo, hi + 1))
    admissible_sums = sorted(reachable - {14, 16, 18})
    return lo, hi, admissible_sums


def pack_items_into_eight_blocks(items):
    """Return eight capacity-4 bins, or None; items are (label, size)."""
    items = sorted((item for item in items if item[1]), key=lambda x: -x[1])
    bins = [[] for _ in range(8)]
    loads = [0] * 8

    def place(i):
        if i == len(items):
            return [list(bucket) for bucket in bins]
        label, size = items[i]
        seen_loads = set()
        for b in range(8):
            if loads[b] in seen_loads or loads[b] + size > 4:
                continue
            seen_loads.add(loads[b])
            bins[b].append((label, size))
            loads[b] += size
            answer = place(i + 1)
            if answer is not None:
                return answer
            loads[b] -= size
            bins[b].pop()
        return None

    answer = place(0)
    if answer is not None:
        assert all(sum(size for _, size in bucket) == 4 for bucket in answer)
    return answer


def selected_base_lift_witness(m):
    occurring = [(i, x) for i, x in enumerate(m) if x]
    ranges = [range(max(0, x - 4), min(4, x) + 1) for _, x in occurring]
    for positive_counts in product(*ranges):
        positive_sum = sum(positive_counts)
        if positive_sum in {14, 16, 18}:
            continue
        items = []
        for (i, x), p in zip(occurring, positive_counts):
            word = pattern_word(PATTERNS[i])
            items.extend(((word + "+", p), (word + "-", x - p)))
        blocks = pack_items_into_eight_blocks(items)
        if blocks is not None:
            return positive_counts, blocks
    return None


def validate(m):
    assert sum(m) == 32
    assert max(m) <= 8
    assert all(sum(m[i] * PATTERNS[i][j] for i in range(16)) == 0 for j in range(4))
    assert all(not (m[i] and m[PATTERN_INDEX[tuple(-x for x in p)]]) for i, p in enumerate(PATTERNS))


def main():
    group = group_image_maps()
    raw = list(enumerate_profiles())
    assert len(raw) == len(set(raw))
    for m in raw:
        validate(m)
    raw_tail = [tail_split_info(m) for m in raw]
    assert all((not admissible) == (lo == 16)
               for lo, _hi, admissible in raw_tail)

    orbit_members = Counter(canonical(m, group) for m in raw)
    assert sum(orbit_members.values()) == len(raw)
    assert all(size in {1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 384}
               for size in orbit_members.values())

    records = []
    covered = set()
    for orbit_id, (rep, orbit_size) in enumerate(sorted(orbit_members.items()), 1):
        images = {transform(rep, g) for g in group}
        assert len(images) == orbit_size
        assert covered.isdisjoint(images)
        covered.update(images)
        support = [(pattern_word(PATTERNS[i]), x) for i, x in enumerate(rep) if x]
        tail_lo, tail_hi, admissible_sums = tail_split_info(rep)
        block_lift = selected_base_lift_witness(rep)
        assert (block_lift is not None) == bool(admissible_sums)
        records.append({
            "id": orbit_id,
            "orbit_size": orbit_size,
            "stabilizer_size": 384 // orbit_size,
            "support_size": len(support),
            "multiplicity_partition": sorted((x for x in rep if x), reverse=True),
            "pair_dot_histogram": dict(support_geometry(rep)),
            "tail_sum_interval": [tail_lo, tail_hi],
            "tail_inactive_admissible": bool(admissible_sums),
            "first_admissible_tail_plus_sum": admissible_sums[0] if admissible_sums else None,
            "selected_base_block_lift_exists": block_lift is not None,
            "one_tail_split": list(block_lift[0]) if block_lift is not None else None,
            "one_block_packing": block_lift[1] if block_lift is not None else None,
            "support": support,
            "tuple_lex_patterns": list(rep),
        })
    assert covered == set(raw)

    fixed_counts = [sum(transform(m, g) == m for m in raw) for g in group]
    assert sum(fixed_counts) % 384 == 0
    assert sum(fixed_counts) // 384 == len(records)

    invariant_buckets = Counter(
        (r["support_size"], tuple(r["multiplicity_partition"]),
         tuple(sorted(r["pair_dot_histogram"].items())))
        for r in records
    )
    support_size_orbits = Counter(r["support_size"] for r in records)
    support_size_raw = Counter()
    for r in records:
        support_size_raw[r["support_size"]] += r["orbit_size"]
    orbit_size_hist = Counter(r["orbit_size"] for r in records)
    tail_l_orbits = Counter(r["tail_sum_interval"][0] for r in records)
    tail_l_raw = Counter()
    for r in records:
        tail_l_raw[r["tail_sum_interval"][0]] += r["orbit_size"]
    admissible_records = [r for r in records if r["tail_inactive_admissible"]]

    # The orbit partition supplies a second raw-count check: each canonical
    # representative's full group image is an orbit and the orbit sizes sum
    # to the independently joined labelled count.
    orbit_sum_check = sum(r["orbit_size"] for r in records)
    admissible_orbit_sum_check = sum(r["orbit_size"] for r in admissible_records)

    output = {
        "pattern_order": [pattern_word(p) for p in PATTERNS],
        "group_size": len(group),
        "raw_solution_count": len(raw),
        "orbit_count": len(records),
        "burnside_fixed_sum": sum(fixed_counts),
        "burnside_orbit_count_check": sum(fixed_counts) // 384,
        "fixed_point_count_histogram": dict(sorted(Counter(fixed_counts).items())),
        "representative_images_equal_raw_set": True,
        "orbit_sum_raw_count_check": orbit_sum_check,
        "tail_admissible_raw_count": admissible_orbit_sum_check,
        "tail_admissible_orbit_count": len(admissible_records),
        "tail_rejected_raw_count": len(raw) - admissible_orbit_sum_check,
        "tail_rejected_orbit_count": len(records) - len(admissible_records),
        "verified_every_tail_failure_has_L_16": True,
        "tail_L_orbit_histogram": dict(sorted(tail_l_orbits.items())),
        "tail_L_raw_histogram": dict(sorted(tail_l_raw.items())),
        "orbit_size_histogram": dict(sorted(orbit_size_hist.items())),
        "support_size_orbit_histogram": dict(sorted(support_size_orbits.items())),
        "support_size_raw_histogram": dict(sorted(support_size_raw.items())),
        "invariant_bucket_count": len(invariant_buckets),
        "colliding_invariant_buckets": sum(x > 1 for x in invariant_buckets.values()),
        "records": records,
    }
    print(json.dumps(output, indent=2, sort_keys=False))


if __name__ == "__main__":
    main()
