# Selected-base classification for the four-zero branch

This bundle classifies the local projected profiles at a four-active Walsh base whose four
active baselines all vanish. A projected profile is a function

\[
 m:\{-1,1\}^4\longrightarrow\{0,\ldots,8\}
\]

such that

\[
 \sum_v m(v)=32,\qquad
 \sum_v m(v)v=0,\qquad
 m(v)m(-v)=0.
\]

The last condition is exactly the selected-base pair condition: two projected signed columns
must not be antipodal. The bound eight is the total capacity of the two five-row projective
lifts above one projected type.

Choose the representative of each antipodal pair whose first coordinate is positive, and give
its multiplicity a sign recording which orientation occurs. This produces eight signed
coefficients. The verifier enumerates the zero-margin solutions by a meet-in-the-middle join,
acts by all

\[
 |(C_2)^4\rtimes S_4|=384
\]

signed coordinate permutations, constructs canonical representatives, and checks the same
orbit count by Burnside's lemma and by the disjoint union of all representative images.

The projected classification is

\[
 4{,}560\ \text{labeled profiles}
 \quad\longrightarrow\quad
 29\ \text{orbits}.
\]

To lift a projected type of mass \(m_v\), its tail-positive mass must lie in

\[
 \max(0,m_v-4)\le p_v\le\min(4,m_v).
\]

Writing \(L=\sum_v\max(0,m_v-4)\), every integer total
\(\sum_vp_v\in[L,32-L]\) is reachable. Row 5 is inactive at the selected base exactly when
\(\sum_vp_v\notin\{14,16,18\}\). Exactly one projected orbit fails: the four occurring types
all have mass eight, so \(L=16\). The remaining classification is therefore

\[
 4{,}536\ \text{labeled profiles}
 \quad\longrightarrow\quad
 28\ \text{orbits}.
\]

For each of the 28 orbits, the frozen JSON also contains one admissible tail split and one
partition of its nonempty five-row lift types into eight blocks of mass four. Thus no further
orbit is lost at the selected-base block-packing interface.

Run the frozen classification with

    ./verify.sh

The bundle was frozen with uv 0.12.3 and Python 3.13.15 on arm64 macOS.
