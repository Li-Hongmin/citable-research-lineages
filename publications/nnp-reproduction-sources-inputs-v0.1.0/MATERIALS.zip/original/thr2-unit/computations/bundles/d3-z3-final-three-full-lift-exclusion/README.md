# Full-lift exclusion for the final three \(z=3\) profiles

This bundle exhausts every global eight-block lift of the three tetrahedral profiles left by
Proposition 50:

\[
 (4,4,4,6),\qquad(3,5,5,5),\qquad(4,4,5,5).
\]

In the fixed tetrahedral pattern order, their eight projected four-row multiplicities are

\[
\begin{array}{c|c}
\text{profile}&(m_0,\ldots,m_7)\\ \hline
(4,4,4,6)&(4,4,4,4,4,4,6,2)\\
(3,5,5,5)&(3,5,5,3,5,3,5,3)\\
(4,4,5,5)&(4,4,4,4,5,3,5,3).
\end{array}
\]

For each projected pattern, the verifier enumerates every split between its tail-positive and
tail-negative five-row lifts. A nonempty lift is an indivisible projective class of mass at most
four. Negating row 5 makes its selected-base inactive baseline positive, and Propositions 49--50
give the complete target set

\[
 T_5(0)\in\{8,12,16,20,24,28\}.
\]

For each profile the verifier:

1. generates every admissible tail split;
2. generates each unlabeled partition of the resulting lift items into eight mass-four blocks
   exactly once by restricted-growth recursion;
3. assigns block labels through the \(30=8!/|\operatorname{AGL}(3,2)|\) representatives;
4. computes all five row baselines at all eight Walsh bases;
5. checks (33jd) for every pair of distinct lift types and for the diagonal of every type with
   multiplicity at least two.

The exhaustive domains are

\[
\begin{array}{c|r|r|r}
\text{profile}&\text{splits}&\text{unlabeled partitions}&\text{label states}\\ \hline
(4,4,4,6)&14{,}568&2{,}424{,}888&72{,}746{,}640\\
(3,5,5,5)&5{,}610&2{,}932{,}380&87{,}971{,}400\\
(4,4,5,5)&16{,}310&4{,}247{,}851&127{,}435{,}530.
\end{array}
\]

No state satisfies the complete pair conditions. The default run applies Proposition 49 to
every projected type of mass greater than four before entering the full pair loop. The second
frozen run disables all such pruning and sends every label state to the complete (33jd) loop.
It reaches the same \(\texttt{VERIFIED\_INFEASIBLE}\) conclusion for all three profiles, so
the exclusions do not rely on the pruning implementation. A separate guard confirms that the
generated domain contains a state satisfying every selected-base type-pair condition for each
profile; hence the projected-pattern encoding is not rejecting the known local \(z=3\)
feasibility.

The affine quotient loses no condition. Relabeling blocks by
\(\operatorname{AGL}(3,2)\) permutes the Walsh bases and may reverse simultaneously all signed
columns and baselines at one base; equality of two signed columns and membership of the
baseline in \(\{0,4v\}\) are invariant.

Run both frozen classifications with

    ./verify.sh

The bundle was frozen with Apple clang 21.0.0 on arm64 macOS. The combined pruned and direct
runs use less than 5 MB peak RSS.
