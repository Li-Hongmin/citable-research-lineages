#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

struct Item {
  int pattern;
  int tail;
  int mass;
  std::array<int, 5> value;
};

static constexpr std::array<std::array<int, 4>, 8> PROJECTED{{
    {{+1,+1,+1,+1}}, {{+1,+1,+1,-1}},
    {{+1,-1,-1,+1}}, {{+1,-1,-1,-1}},
    {{-1,+1,-1,+1}}, {{-1,+1,-1,-1}},
    {{-1,-1,+1,+1}}, {{-1,-1,+1,-1}},
}};

static int chi(int base, int block) {
  return (__builtin_popcount(static_cast<unsigned>(base & block)) & 1) ? -1 : +1;
}

static std::vector<std::array<int, 8>> label_representatives() {
  std::set<std::array<int, 8>> affine_group;
  for (int column_zero = 1; column_zero < 8; ++column_zero)
    for (int column_one = 1; column_one < 8; ++column_one)
      if (column_one != column_zero)
        for (int column_two = 1; column_two < 8; ++column_two)
          if (column_two != column_zero && column_two != column_one &&
              column_two != (column_zero ^ column_one))
            for (int shift = 0; shift < 8; ++shift) {
              std::array<int, 8> affine{};
              for (int point = 0; point < 8; ++point) {
                affine[point] = shift
                    ^ ((point & 1) ? column_zero : 0)
                    ^ ((point & 2) ? column_one : 0)
                    ^ ((point & 4) ? column_two : 0);
              }
              affine_group.insert(affine);
            }

  std::set<std::array<int, 8>> remaining;
  std::array<int, 8> permutation{{0,1,2,3,4,5,6,7}};
  do {
    remaining.insert(permutation);
  } while (std::next_permutation(permutation.begin(), permutation.end()));

  std::vector<std::array<int, 8>> representatives;
  while (!remaining.empty()) {
    const auto representative = *remaining.begin();
    representatives.push_back(representative);
    for (const auto& affine : affine_group) {
      std::array<int, 8> orbit_member{};
      for (int index = 0; index < 8; ++index) {
        orbit_member[index] = affine[representative[index]];
      }
      remaining.erase(orbit_member);
    }
  }
  if (affine_group.size() != 1344 || representatives.size() != 30) {
    throw std::runtime_error("AGL(3,2) quotient construction failed");
  }
  return representatives;
}

struct Search {
  Search(
      const std::string& profile_name,
      const std::array<int, 8>& profile_masses,
      bool use_prop49)
      : representatives(label_representatives()),
        use_prop49_prune(use_prop49),
        name(profile_name),
        masses(profile_masses) {}

  std::vector<std::array<int, 8>> representatives;
  bool use_prop49_prune;
  std::string name;
  std::array<int, 8> masses;
  bool found = false;
  bool saw_base_zero_feasible = false;
  uint64_t completed_splits = 0;
  uint64_t partitions = 0;
  uint64_t labelings = 0;
  uint64_t prop49_rejects = 0;
  uint64_t full_checks = 0;
  uint64_t pair_base_checks = 0;

  std::vector<Item> items;
  std::vector<int> order;
  std::array<std::vector<int>, 8> bins;
  std::array<int, 8> loads{};
  int bin_count = 0;
  int target = 0;
  std::array<int, 8> current_plus{};
  std::array<int, 8> witness_plus{};
  std::vector<int> witness_blocks;
  std::array<std::array<int, 8>, 5> witness_totals{};

  bool pair_is_covered(
      int left,
      int right,
      int base,
      const std::vector<int>& block,
      const std::array<std::array<int, 8>, 5>& totals) {
    ++pair_base_checks;
    return pair_is_covered_raw(left, right, base, block, totals);
  }

  bool pair_is_covered_raw(
      int left,
      int right,
      int base,
      const std::vector<int>& block,
      const std::array<std::array<int, 8>, 5>& totals) const {
    const int left_walsh = chi(base, block[left]);
    const int right_walsh = chi(base, block[right]);
    for (int row = 0; row < 5; ++row) {
      const int left_value = left_walsh * items[left].value[row];
      const int right_value = right_walsh * items[right].value[row];
      if (left_value == right_value &&
          (totals[row][base] == 0 || totals[row][base] == 4 * left_value)) {
        return true;
      }
    }
    return false;
  }

  bool verify(const std::array<int, 8>& labeling) {
    ++labelings;
    std::vector<int> block(items.size());
    std::array<std::array<int, 8>, 5> block_sums{};
    for (int bin = 0; bin < 8; ++bin) {
      const int block_label = labeling[bin];
      for (int item : bins[bin]) {
        block[item] = block_label;
        for (int row = 0; row < 5; ++row) {
          block_sums[row][block_label] += items[item].mass * items[item].value[row];
        }
      }
    }

    std::array<std::array<int, 8>, 5> totals{};
    for (int row = 0; row < 5; ++row)
      for (int base = 0; base < 8; ++base)
        for (int block_label = 0; block_label < 8; ++block_label)
          totals[row][base] += chi(base, block_label) * block_sums[row][block_label];

    if (totals[0][0] != 0 || totals[1][0] != 0 || totals[2][0] != 0 ||
        totals[3][0] != 4 || totals[4][0] != target) {
      throw std::runtime_error("selected-base invariant failed");
    }

    if (!saw_base_zero_feasible) {
      bool passes = true;
      for (int left = 0; left < static_cast<int>(items.size()) && passes; ++left) {
        const int first_right = items[left].mass >= 2 ? left : left + 1;
        for (int right = first_right; right < static_cast<int>(items.size()); ++right) {
          if (!pair_is_covered_raw(left, right, 0, block, totals)) {
            passes = false;
            break;
          }
        }
      }
      saw_base_zero_feasible = passes;
    }

    bool has_overfull_pattern = false;
    for (int pattern = 0; pattern < 8; ++pattern) {
      if (masses[pattern] <= 4) continue;
      has_overfull_pattern = true;
      int overfull_positive = -1;
      int overfull_negative = -1;
      for (int item = 0; item < static_cast<int>(items.size()); ++item) {
        if (items[item].pattern == pattern && items[item].tail == +1)
          overfull_positive = item;
        if (items[item].pattern == pattern && items[item].tail == -1)
          overfull_negative = item;
      }
      if (overfull_positive < 0 || overfull_negative < 0) {
        throw std::runtime_error("overfull projected type was not split");
      }
      const int difference = block[overfull_positive] ^ block[overfull_negative];
      if (difference == 0) {
        throw std::runtime_error("overfull lifts share one mass-four block");
      }
      if (use_prop49_prune) {
        for (int base = 1; base < 8; ++base) {
          if (chi(base, difference) == -1) {
            const int common_value = chi(base, block[overfull_positive]);
            if (totals[4][base] != 0 && totals[4][base] != 4 * common_value) {
              ++prop49_rejects;
              return false;
            }
          }
        }
      }
    }
    if (!has_overfull_pattern) {
      throw std::runtime_error("profile has no overfull projected type");
    }

    ++full_checks;
    for (int left = 0; left < static_cast<int>(items.size()); ++left) {
      const int first_right = items[left].mass >= 2 ? left : left + 1;
      for (int right = first_right; right < static_cast<int>(items.size()); ++right) {
        for (int base = 0; base < 8; ++base) {
          if (!pair_is_covered(left, right, base, block, totals)) return false;
        }
      }
    }

    found = true;
    witness_plus = current_plus;
    witness_blocks = block;
    witness_totals = totals;
    return true;
  }

  void pack(int position) {
    if (found) return;
    if (position == static_cast<int>(order.size())) {
      if (bin_count != 8) return;
      for (int bin = 0; bin < 8; ++bin) {
        if (loads[bin] != 4) return;
      }
      ++partitions;
      for (const auto& labeling : representatives) {
        if (verify(labeling)) return;
      }
      return;
    }

    const int item = order[position];
    const int mass = items[item].mass;
    for (int bin = 0; bin < bin_count; ++bin) {
      if (loads[bin] + mass > 4) continue;
      bins[bin].push_back(item);
      loads[bin] += mass;
      pack(position + 1);
      loads[bin] -= mass;
      bins[bin].pop_back();
      if (found) return;
    }
    if (bin_count < 8) {
      bins[bin_count].push_back(item);
      loads[bin_count] = mass;
      ++bin_count;
      pack(position + 1);
      --bin_count;
      loads[bin_count] = 0;
      bins[bin_count].pop_back();
    }
  }

  void try_split(const std::array<int, 8>& plus) {
    ++completed_splits;
    current_plus = plus;
    items.clear();
    order.clear();
    for (auto& bin : bins) bin.clear();
    loads.fill(0);
    bin_count = 0;

    for (int pattern = 0; pattern < 8; ++pattern) {
      const int positive_mass = plus[pattern];
      const int negative_mass = masses[pattern] - positive_mass;
      if (positive_mass > 0) {
        Item item{pattern, +1, positive_mass, {}};
        for (int row = 0; row < 4; ++row) item.value[row] = PROJECTED[pattern][row];
        item.value[4] = +1;
        items.push_back(item);
      }
      if (negative_mass > 0) {
        Item item{pattern, -1, negative_mass, {}};
        for (int row = 0; row < 4; ++row) item.value[row] = PROJECTED[pattern][row];
        item.value[4] = -1;
        items.push_back(item);
      }
    }
    order.resize(items.size());
    for (int item = 0; item < static_cast<int>(items.size()); ++item) order[item] = item;
    std::stable_sort(order.begin(), order.end(), [&](int left, int right) {
      return items[left].mass > items[right].mass;
    });
    pack(0);
  }

  void split_rec(int position, int remaining_plus, std::array<int, 8>& plus) {
    if (found) return;
    if (position == 8) {
      if (remaining_plus == 0) try_split(plus);
      return;
    }

    int minimum_future = 0;
    int maximum_future = 0;
    for (int pattern = position + 1; pattern < 8; ++pattern) {
      minimum_future += std::max(0, masses[pattern] - 4);
      maximum_future += std::min(4, masses[pattern]);
    }
    const int minimum = std::max(0, masses[position] - 4);
    const int maximum = std::min(4, masses[position]);
    for (int value = minimum; value <= maximum; ++value) {
      const int after = remaining_plus - value;
      if (after < minimum_future || after > maximum_future) continue;
      plus[position] = value;
      split_rec(position + 1, after, plus);
      if (found) return;
    }
  }

  void run() {
    std::array<int, 8> plus{};
    for (int baseline : {24,20,16,12,8,28}) {
      target = baseline;
      split_rec(0, (32 + baseline) / 2, plus);
      if (found) return;
    }
    if (!saw_base_zero_feasible) {
      throw std::runtime_error("no selected-base feasible state was generated");
    }
  }

  void print_result() const {
    std::cout << name << ' ';
    std::cout << (found ? "FULL_WITNESS" : "VERIFIED_INFEASIBLE");
    std::cout << " completed_splits=" << completed_splits
              << " partitions=" << partitions
              << " labelings=" << labelings
              << " base0_feasible=" << (saw_base_zero_feasible ? 1 : 0)
              << " prop49_rejects=" << prop49_rejects
              << " full_checks=" << full_checks
              << " pair_base_checks=" << pair_base_checks << "\n";

    if (found) {
      std::cout << "target_T5_0=" << target << " plus=";
      for (int value : witness_plus) std::cout << value << ',';
      std::cout << "\nitems=";
      for (int item = 0; item < static_cast<int>(items.size()); ++item) {
        std::cout << '(' << items[item].pattern << ','
                  << (items[item].tail > 0 ? '+' : '-') << ',' << items[item].mass
                  << ",b" << witness_blocks[item] << ')';
      }
      std::cout << "\nbaselines=";
      for (int row = 0; row < 5; ++row) {
        std::cout << " row" << (row + 1) << '=';
        for (int base = 0; base < 8; ++base) std::cout << witness_totals[row][base] << ',';
      }
      std::cout << "\n";
    }
  }
};

int main(int argc, char** argv) {
  bool use_prop49 = true;
  if (argc == 2 && std::string(argv[1]) == "--no-prop49") use_prop49 = false;
  else if (argc != 1)
    throw std::runtime_error("usage: verify_final_three_full_lifts [--no-prop49]");

  struct Profile {
    const char* name;
    std::array<int, 8> masses;
  };
  const std::array<Profile, 3> profiles{{
      {"profile=30 partition=(4,4,4,6)", {{4,4,4,4,4,4,6,2}}},
      {"profile=31 partition=(3,5,5,5)", {{3,5,5,3,5,3,5,3}}},
      {"profile=32 partition=(4,4,5,5)", {{4,4,4,4,5,3,5,3}}},
  }};
  for (const auto& profile : profiles) {
    Search search(profile.name, profile.masses, use_prop49);
    search.run();
    search.print_result();
  }
  return 0;
}
