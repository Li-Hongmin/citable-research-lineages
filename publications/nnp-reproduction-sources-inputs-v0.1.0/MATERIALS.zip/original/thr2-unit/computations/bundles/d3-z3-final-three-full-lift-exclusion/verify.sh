#!/bin/sh
set -eu

bundle_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$bundle_dir"

shasum -a 256 -c SHA256SUMS
binary_path=$(mktemp "${TMPDIR:-/tmp}/final-three-full-lifts.XXXXXX")
pruned_output=$(mktemp "${TMPDIR:-/tmp}/final-three-pruned.XXXXXX")
direct_output=$(mktemp "${TMPDIR:-/tmp}/final-three-direct.XXXXXX")
trap 'rm -f "$binary_path" "$pruned_output" "$direct_output"' EXIT HUP INT TERM

c++ -O3 -std=c++17 verify_final_three_full_lifts.cpp -o "$binary_path"
"$binary_path" > "$pruned_output"
"$binary_path" --no-prop49 > "$direct_output"
diff -u expected-pruned-output.txt "$pruned_output"
diff -u expected-direct-output.txt "$direct_output"
echo VERIFIED
