# Block-constant \(d=3\) Walsh-star verification

This bundle verifies the finite lemma used in Proposition 36 of the active paper. There are eight
Walsh blocks indexed by \(\mathbb F_2^3\), every block has the same length divisible by four,
and the fixed window is \(W=0\). A block-constant center is represented by a Boolean function
\(f:\mathbb F_2^3\to\{-1,1\}\).

Multiplying a center by \(-1\) preserves separation, so the verifier fixes \(f(0)=1\) and
enumerates all 128 truth tables. At a Walsh base \(g\), a block-constant row can separate a
distance-two pair only when its Walsh coefficient at \(g\) is zero. This reduces all coordinate
pairs to 224 distinct cross-block requirements and eight within-block requirements.

The verifier checks every five-row subset after deleting inert functions and duplicate rows.
Useful functions consist of eight characters and 56 functions with four-point Walsh support.
The output records, for each possible number of four-sparse rows, the number of five-row families
and the largest number of requirements covered. It also verifies a six-character upper witness.

Run from the repository root:

```text
uv run --no-project python units/thr2-lower-bounds/computations/bundles/d3-block-constant-walsh-stars/verify_block_constant_d3_walsh_stars.py
```

The conclusion is restricted to block-constant centers. It does not prove that five arbitrary
centers with nonconstant columns inside a block are impossible.
