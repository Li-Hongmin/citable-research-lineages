#!/usr/bin/env python3
"""Exhaust the block-constant d=3, W=0 Walsh-star problem."""

from __future__ import annotations

from itertools import combinations
from platform import python_version
from time import perf_counter


POINTS = tuple(range(8))
BLOCK_PAIRS = tuple(combinations(POINTS, 2))
CROSS_REQUIREMENTS = len(POINTS) * len(BLOCK_PAIRS)
REQUIREMENT_COUNT = CROSS_REQUIREMENTS + len(POINTS)
FULL_MASK = (1 << REQUIREMENT_COUNT) - 1


def character(g: int, x: int) -> int:
    return -1 if (g & x).bit_count() % 2 else 1


def truth_table(bits: int) -> tuple[int, ...]:
    """Use the global-sign normalization f(0)=1."""
    return (1,) + tuple(1 if (bits >> (x - 1)) & 1 else -1 for x in range(1, 8))


def walsh_support(values: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(
        g
        for g in POINTS
        if sum(values[x] * character(g, x) for x in POINTS) != 0
    )


def coverage_mask(values: tuple[int, ...]) -> int:
    mask = 0
    bit = 0
    zero_rows: list[bool] = []
    for g in POINTS:
        transform = sum(values[x] * character(g, x) for x in POINTS)
        is_zero = transform == 0
        zero_rows.append(is_zero)
        for left, right in BLOCK_PAIRS:
            if is_zero and (
                values[left] * character(g, left)
                == values[right] * character(g, right)
            ):
                mask |= 1 << bit
            bit += 1
    for is_zero in zero_rows:
        if is_zero:
            mask |= 1 << bit
        bit += 1
    assert bit == REQUIREMENT_COUNT
    return mask


def union_mask(indices: tuple[int, ...], masks: list[int]) -> int:
    result = 0
    for index in indices:
        result |= masks[index]
    return result


def main() -> None:
    started = perf_counter()
    values = [truth_table(bits) for bits in range(128)]
    supports = [walsh_support(table) for table in values]
    masks = [coverage_mask(table) for table in values]

    characters = [index for index, support in enumerate(supports) if len(support) == 1]
    four_sparse = [index for index, support in enumerate(supports) if len(support) == 4]
    inert = [index for index, support in enumerate(supports) if len(support) == 8]
    assert (len(characters), len(four_sparse), len(inert)) == (8, 56, 64)
    assert all(masks[index] == 0 for index in inert)

    upper_witness: tuple[int, ...] | None = None
    for chosen in combinations(characters, 6):
        if union_mask(chosen, masks) == FULL_MASK:
            upper_witness = chosen
            break
    assert upper_witness is not None

    rows: list[tuple[int, int, int, tuple[int, ...]]] = []
    for nonlinear_count in range(6):
        case_count = 0
        best_covered = -1
        best_choice: tuple[int, ...] | None = None
        for chosen_characters in combinations(characters, 5 - nonlinear_count):
            character_mask = union_mask(chosen_characters, masks)
            for chosen_nonlinear in combinations(four_sparse, nonlinear_count):
                case_count += 1
                covered = character_mask | union_mask(chosen_nonlinear, masks)
                covered_count = covered.bit_count()
                if covered_count > best_covered:
                    best_covered = covered_count
                    best_choice = chosen_characters + chosen_nonlinear
        assert best_choice is not None
        assert best_covered < REQUIREMENT_COUNT
        rows.append((nonlinear_count, case_count, best_covered, best_choice))

    elapsed = perf_counter() - started
    print(f"python={python_version()}")
    print("parameters=d=3,multiple-of-4 block length,W=0,block-constant centers")
    print(f"truth_tables=128 characters={len(characters)} four_sparse={len(four_sparse)} inert={len(inert)}")
    print(f"requirements={REQUIREMENT_COUNT} cross={CROSS_REQUIREMENTS} within={len(POINTS)}")
    print(
        "six_row_witness_supports="
        + ",".join(str(supports[index][0]) for index in upper_witness)
    )
    print("nonlinear_rows cases best_covered uncovered")
    for nonlinear_count, case_count, best_covered, _ in rows:
        print(
            f"{nonlinear_count} {case_count} {best_covered} "
            f"{REQUIREMENT_COUNT - best_covered}"
        )
    print(f"elapsed_seconds={elapsed:.6f}")
    print("result=PASS minimum_block_constant_centers=6")


if __name__ == "__main__":
    main()
