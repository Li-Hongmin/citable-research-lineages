#!/usr/bin/env python3
"""Generate a four-cell Walsh-plane quotient CNF for a normalized z=3 profile.

The quotient retains the four cells cut out by two independent Walsh
characters. Every cell has mass eight and represents two original blocks.
It preserves all data visible on the plane {0,1,2,3} and forgets only the
split of each cell into two blocks of mass four.
"""

from __future__ import annotations

import argparse
import itertools
from pathlib import Path


ROWS = range(5)
CELLS = range(4)
CLASSES = range(16)
BASES = (0, 1, 2, 3)


def chi(g: int, cell: int) -> int:
    return -1 if (g & cell).bit_count() & 1 else 1


def representative(projective: int, row: int) -> int:
    if row == 4:
        return 1
    return 1 if (projective >> row) & 1 else -1


class CNF:
    def __init__(self) -> None:
        self.nvars = 0
        self.clauses: list[list[int]] = []

    def var(self) -> int:
        self.nvars += 1
        return self.nvars

    def add(self, *literals: int) -> None:
        self.clauses.append(list(literals))

    def exactly_one(self, literals: list[int]) -> None:
        self.add(*literals)
        for index, left in enumerate(literals):
            for right in literals[index + 1 :]:
                self.add(-left, -right)

    def write(self, path: Path) -> None:
        with path.open("w", encoding="ascii") as stream:
            stream.write(f"p cnf {self.nvars} {len(self.clauses)}\n")
            for clause in self.clauses:
                stream.write(" ".join(map(str, clause)) + " 0\n")


# State zero is unused. Every other state is (cell, orientation, mass).
STATES: list[tuple[int | None, int, int]] = [(None, 0, 0)] + [
    (cell, orientation, mass)
    for cell in CELLS
    for orientation in (-1, 1)
    for mass in range(1, 5)
]


def add_cell_symmetry_break(cnf: CNF, choice: list[list[int]]) -> int:
    """Fix the first two stages of an AGL(2,2) cell representative."""
    selected = [index for index, state in enumerate(STATES) if state[0] is not None]
    outside_zero = [
        index for index, state in enumerate(STATES) if state[0] not in (None, 0)
    ]
    outside_zero_one = [
        index for index, state in enumerate(STATES) if state[0] not in (None, 0, 1)
    ]
    before = len(cnf.clauses)

    # Translate the least selected projective class to cell 0.
    for projective in CLASSES:
        earlier_selected = [
            choice[earlier][state]
            for earlier in range(projective)
            for state in selected
        ]
        for state in outside_zero:
            cnf.add(-choice[projective][state], *earlier_selected)

    # GL(2,2), fixing cell 0, is transitive on the three nonzero cells.
    # Send the least selected class outside cell 0 to cell 1.
    for projective in CLASSES:
        earlier_outside_zero = [
            choice[earlier][state]
            for earlier in range(projective)
            for state in outside_zero
        ]
        for state in outside_zero_one:
            cnf.add(-choice[projective][state], *earlier_outside_zero)

    added = len(cnf.clauses) - before
    assert added == 640
    return added


def add_final_cell_symmetry_break(cnf: CNF, choice: list[list[int]]) -> int:
    """Fix the residual stabilizer exchanging cells 2 and 3."""
    outside_zero_one = [
        index for index, state in enumerate(STATES) if state[0] not in (None, 0, 1)
    ]
    in_cell_three = [
        index for index, state in enumerate(STATES) if state[0] == 3
    ]
    before = len(cnf.clauses)

    # After cells 0 and 1 are fixed, the residual stabilizer exchanges cells
    # 2 and 3.  Send the least selected class outside cells 0 and 1 to cell 2.
    for projective in CLASSES:
        earlier_outside_zero_one = [
            choice[earlier][state]
            for earlier in range(projective)
            for state in outside_zero_one
        ]
        for state in in_cell_three:
            cnf.add(-choice[projective][state], *earlier_outside_zero_one)

    added = len(cnf.clauses) - before
    assert added == 128
    return added


def add_lex_leq(cnf: CNF, left: list[list[int]], right: list[list[int]]) -> None:
    """Enforce lexicographic order on two four-component one-hot vectors."""
    prefix = [cnf.var() for _ in range(5)]
    cnf.add(prefix[0])
    for component in range(4):
        for left_value in range(5):
            for right_value in range(left_value):
                cnf.add(
                    -prefix[component],
                    -left[component][left_value],
                    -right[component][right_value],
                )
        cnf.add(-prefix[component + 1], prefix[component])
        for left_value in range(5):
            for right_value in range(5):
                if left_value != right_value:
                    cnf.add(
                        -prefix[component + 1],
                        -left[component][left_value],
                        -right[component][right_value],
                    )
        for value in range(5):
            cnf.add(
                -prefix[component],
                -left[component][value],
                -right[component][value],
                prefix[component + 1],
            )


def add_head_lex_symmetry_break(
    cnf: CNF, choice: list[list[int]], profile: tuple[int, ...]
) -> tuple[int, tuple[tuple[int, ...], ...]]:
    """Sort lift-mass signatures inside equal-alpha tetrahedral head groups."""
    heads = [head for head in range(8) if profile[head] or profile[head + 8]]
    if len(heads) != 4:
        raise ValueError("head-lex symmetry breaking requires a tetrahedral profile")
    groups: dict[int, list[int]] = {}
    for head in heads:
        groups.setdefault(profile[head + 8], []).append(head)
    repeated_groups = tuple(
        tuple(sorted(group)) for group in groups.values() if len(group) > 1
    )
    repeated_heads = sorted({head for group in repeated_groups for head in group})
    if not repeated_heads:
        raise ValueError("profile has no repeated alpha value")

    before = len(cnf.clauses)
    signatures: dict[int, list[list[int]]] = {}
    for head in repeated_heads:
        # (+,+), (+,-), (-,+), (-,-), where the signs are rows 4 and 5.
        sources = ((head + 8, 1), (7 - head, -1), (head, 1), (15 - head, -1))
        signature: list[list[int]] = []
        for projective, orientation in sources:
            one_hot = [cnf.var() for _ in range(5)]
            cnf.exactly_one(one_hot)
            for state_index, state in enumerate(STATES):
                value = state[2] if state[1] == orientation else 0
                cnf.add(-choice[projective][state_index], one_hot[value])
            signature.append(one_hot)
        signatures[head] = signature

    for group in repeated_groups:
        for left, right in zip(group, group[1:]):
            add_lex_leq(cnf, signatures[left], signatures[right])

    return len(cnf.clauses) - before, repeated_groups


def add_split_lift_constraints(cnf: CNF, choice: list[list[int]]) -> int:
    """Force every mass-eight plane cell to split into two mass-four blocks."""
    before = len(cnf.clauses)
    for cell in CELLS:
        mass_two = [
            index
            for index, state in enumerate(STATES)
            if state[0] == cell and state[2] == 2
        ]
        mass_three = [
            index
            for index, state in enumerate(STATES)
            if state[0] == cell and state[2] == 3
        ]
        for first, second, third in itertools.combinations(CLASSES, 3):
            classes = (first, second, third)
            for two_position in range(3):
                two_class = classes[two_position]
                left, right = (
                    projective
                    for position, projective in enumerate(classes)
                    if position != two_position
                )
                for two_state in mass_two:
                    for left_state in mass_three:
                        for right_state in mass_three:
                            cnf.add(
                                -choice[two_class][two_state],
                                -choice[left][left_state],
                                -choice[right][right_state],
                            )

    added = len(cnf.clauses) - before
    assert added == 53_760
    return added


def add_categorical_sum(
    cnf: CNF,
    choice: list[list[int]],
    contribution,
    maximum: int,
    target: int | None = None,
) -> list[list[int]]:
    """Exact DP for a sum of contributions chosen by categorical variables."""
    stages = [[cnf.var() for _ in range(maximum + 1)] for _ in range(17)]
    for stage in stages:
        cnf.exactly_one(stage)
    cnf.add(stages[0][0])
    for value in range(1, maximum + 1):
        cnf.add(-stages[0][value])

    for projective in CLASSES:
        for previous in range(maximum + 1):
            for state_index, state in enumerate(STATES):
                value = previous + contribution(projective, state)
                if value <= maximum:
                    cnf.add(
                        -stages[projective][previous],
                        -choice[projective][state_index],
                        stages[projective + 1][value],
                    )
                else:
                    cnf.add(-stages[projective][previous], -choice[projective][state_index])
    if target is not None:
        cnf.add(stages[16][target])
    return stages


def safe_canonical(profile: tuple[int, ...]) -> tuple[int, ...]:
    """Canonicalize under (C2)^3 semidirect S3 on the three zero rows."""
    best = None
    for permutation in itertools.permutations(range(3)):
        for flips in range(8):
            image = [0] * 16
            for code in range(16):
                target = code & 8
                for row in range(3):
                    value = ((code >> permutation[row]) & 1) ^ ((flips >> row) & 1)
                    target |= value << row
                image[target] = profile[code]
            candidate = tuple(image)
            if best is None or candidate < best:
                best = candidate
    assert best is not None
    return best


def bounded_partition_profile(partition: tuple[int, int, int, int]) -> tuple[int, ...]:
    """Proposition 41 family (33kh), with H={+++, +--, -+-, --+}."""
    profile = [0] * 16
    for head, alpha in zip((7, 1, 2, 4), partition):
        profile[head + 8] = alpha
        profile[head] = 8 - alpha
    return safe_canonical(tuple(profile))


def exceptional_profile() -> tuple[int, ...]:
    """Proposition 41 family (33ki), using S={+++, +--}."""
    profile = [0] * 16
    heads = (7, 1, 2, 4)
    selected = set(heads[:2])
    for head in heads:
        if head in selected:
            profile[head + 8] = 8
            profile[(7 - head) + 8] = 1
        else:
            profile[head] = 7
    return safe_canonical(tuple(profile))


PROFILE_PARTITIONS = tuple(
    (a, b, c, d)
    for a in range(9)
    for b in range(a, 9)
    for c in range(b, 9)
    for d in range(c, 9)
    if a + b + c + d == 18
)
assert len(PROFILE_PARTITIONS) == 31
PROFILE_LABEL_BY_VALUE = {
    bounded_partition_profile(partition): f"partition={partition}"
    for partition in PROFILE_PARTITIONS
}
PROFILE_LABEL_BY_VALUE[exceptional_profile()] = "exceptional=(8,1;7)"
assert len(PROFILE_LABEL_BY_VALUE) == 32

PROFILE_PATTERNS = tuple(range(16))
PROFILES = tuple(sorted(PROFILE_LABEL_BY_VALUE))
PROFILE_LABELS = tuple(PROFILE_LABEL_BY_VALUE[profile] for profile in PROFILES)


def build(
    bases: tuple[int, ...],
    profile_index: int | None = None,
    cell_symmetry_break: bool = False,
    full_cell_symmetry_break: bool = False,
    head_lex_symmetry_break: bool = False,
    split_lift: bool = False,
) -> tuple[CNF, list[list[int]], dict[tuple[int, int, int], int]]:
    cnf = CNF()
    choice = [[cnf.var() for _ in STATES] for _ in CLASSES]
    for states in choice:
        cnf.exactly_one(states)

    if cell_symmetry_break or full_cell_symmetry_break:
        if set(bases) != set(BASES):
            raise ValueError("cell symmetry breaking requires the complete Walsh plane")
        add_cell_symmetry_break(cnf, choice)

    if profile_index is not None:
        targets = dict(zip(PROFILE_PATTERNS, PROFILES[profile_index]))
        # Orientation + of class p projects to p on the first four rows;
        # orientation - projects to its complement 15-p.  A compatible
        # clique contains at most one member of each complementary pair.
        for projective in CLASSES:
            for state_index, state in enumerate(STATES[1:], start=1):
                projected = projective if state[1] == 1 else 15 - projective
                if targets.get(projected, 0) == 0:
                    cnf.add(-choice[projective][state_index])
        # For each surviving projected pattern x, exactly its two canonical
        # classes x and 15-x can realize it.  Forbid every mass pair that does
        # not sum to the prescribed aggregate profile.
        for projected, target in targets.items():
            if target == 0:
                continue
            left, right = projected, 15 - projected
            for left_index, left_state in enumerate(STATES):
                left_mass = (
                    left_state[2]
                    if left_state[0] is not None and left_state[1] == 1
                    else 0
                )
                for right_index, right_state in enumerate(STATES):
                    right_mass = (
                        right_state[2]
                        if right_state[0] is not None and right_state[1] == -1
                        else 0
                    )
                    if left_mass + right_mass != target:
                        cnf.add(-choice[left][left_index], -choice[right][right_index])

    # Each plane cell is the union of two original mass-four blocks.
    for cell in CELLS:
        add_categorical_sum(
            cnf,
            choice,
            lambda _p, state, cell=cell: state[2] if state[0] == cell else 0,
            maximum=8,
            target=8,
        )

    final_count: dict[tuple[int, int, int], int] = {}
    for row in ROWS:
        for g in bases:
            stages = add_categorical_sum(
                cnf,
                choice,
                lambda p, state, row=row, g=g: (
                    state[2]
                    if state[0] is not None
                    and state[1] * representative(p, row) * chi(g, state[0]) == 1
                    else 0
                ),
                maximum=32,
            )
            for count in range(33):
                final_count[row, g, count] = stages[16][count]

    # Exact z=3 normalization.  The inactive fifth row can independently be
    # negated, so fix its nonzero baseline positive (plus count > 16).
    cnf.add(final_count[0, 0, 16])
    cnf.add(final_count[1, 0, 16])
    cnf.add(final_count[2, 0, 16])
    cnf.add(final_count[3, 0, 18])
    cnf.add(*[final_count[4, 0, count] for count in range(17, 33) if count != 18])

    value_plus: dict[tuple[int, int, int], int] = {}
    for projective in CLASSES:
        for g in bases:
            for row in ROWS:
                literal = cnf.var()
                value_plus[projective, g, row] = literal
                for state_index, state in enumerate(STATES):
                    if state[0] is None:
                        positive = False
                    else:
                        positive = (
                            state[1]
                            * representative(projective, row)
                            * chi(g, state[0])
                            == 1
                        )
                    cnf.add(-choice[projective][state_index], literal if positive else -literal)

    def add_witness_conditions(witness: int, p: int, g: int, row: int, q: int | None) -> None:
        # A witness may only refer to selected types.
        cnf.add(-witness, -choice[p][0])
        if q is not None:
            cnf.add(-witness, -choice[q][0])
            vp, vq = value_plus[p, g, row], value_plus[q, g, row]
            cnf.add(-witness, -vp, vq)
            cnf.add(-witness, vp, -vq)
        vp = value_plus[p, g, row]
        # vp=+1 requires T in {0,+4}; vp=-1 requires T in {0,-4}.
        cnf.add(-witness, -vp, final_count[row, g, 16], final_count[row, g, 18])
        cnf.add(-witness, vp, final_count[row, g, 16], final_count[row, g, 14])

    for p in CLASSES:
        for q in range(p + 1, 16):
            for g in bases:
                witnesses = []
                for row in ROWS:
                    witness = cnf.var()
                    witnesses.append(witness)
                    add_witness_conditions(witness, p, g, row, q)
                cnf.add(choice[p][0], choice[q][0], *witnesses)

    # Repeated coordinates of one selected type also require a witness.
    for p in CLASSES:
        nonrepeated = [choice[p][0]] + [
            choice[p][state_index]
            for state_index, state in enumerate(STATES)
            if state_index and state[2] == 1
        ]
        for g in bases:
            witnesses = []
            for row in ROWS:
                witness = cnf.var()
                witnesses.append(witness)
                add_witness_conditions(witness, p, g, row, None)
            cnf.add(*nonrepeated, *witnesses)

    # Append the new symmetry clauses after the original formula so that the
    # previously certified CNFs retain their exact variable and clause order.
    if full_cell_symmetry_break:
        add_final_cell_symmetry_break(cnf, choice)
    if head_lex_symmetry_break:
        if profile_index is None:
            raise ValueError("head-lex symmetry breaking requires a profile")
        add_head_lex_symmetry_break(cnf, choice, PROFILES[profile_index])
    if split_lift:
        add_split_lift_constraints(cnf, choice)

    return cnf, choice, final_count


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--profile", type=int, choices=range(1, len(PROFILES) + 1), required=True
    )
    parser.add_argument("--dimacs", type=Path, required=True)
    cell_group = parser.add_mutually_exclusive_group()
    cell_group.add_argument("--cell-symmetry-break", action="store_true")
    cell_group.add_argument("--full-cell-symmetry-break", action="store_true")
    parser.add_argument("--head-lex-symmetry-break", action="store_true")
    parser.add_argument("--split-lift", action="store_true")
    args = parser.parse_args()
    profile_index = args.profile - 1
    cnf, _, _ = build(
        BASES,
        profile_index,
        args.cell_symmetry_break,
        args.full_cell_symmetry_break,
        args.head_lex_symmetry_break,
        args.split_lift,
    )
    print(
        f"profile={args.profile} {PROFILE_LABELS[profile_index]} variables={cnf.nvars} "
        f"clauses={len(cnf.clauses)} bases={BASES} "
        "cell_symmetry_break="
        f"{'full' if args.full_cell_symmetry_break else 'partial' if args.cell_symmetry_break else 'no'} "
        f"head_lex_symmetry_break={'yes' if args.head_lex_symmetry_break else 'no'} "
        f"split_lift={'yes' if args.split_lift else 'no'}"
    )
    cnf.write(args.dimacs)


if __name__ == "__main__":
    main()
