# Certified Walsh-plane exclusions for thirteen \(z=3\) profiles

This bundle verifies Propositions 43--47 of the active paper.  It contains one parameterized
four-cell Walsh-plane generator and certified UNSAT proofs for the normalized profile indices

\[
8, 9, 10, 11, 12, 13, 15, 16, 17, 18, 20, 24, 25.
\]

The corresponding tetrahedral partitions and formula sizes are

```text
profile  partition       variables  clauses
8        (2,2,6,8)       15400      592792
9        (0,5,5,8)       15400      591855
10       (1,4,5,8)       15400      592624
11       (2,3,5,8)       15400      593368
12       (2,4,4,8)       15445      593721
13       (3,3,4,8)       15445      593825
15       (1,3,7,7)       15400      593729
16       (2,2,7,7)       15400      594369
17       (0,5,6,7)       15400      592792
18       (1,4,6,7)       15400      593561
20       (1,5,5,7)       15400      593665
24       (0,6,6,6)       15400      592792
25       (1,5,6,6)       15400      593665
```

Profile 8 has the additional sharp-boundary witness described below.  Profiles 11 and 16 use
the first two stages of the sound cell-symmetry normalization described below.  Profiles 12 and
13 use the complete cell normalization together with a repeated-head normalization.  No
analogous three-base feasibility claim is made for the other twelve profiles.

## The complete \(a\le1\) boundary

Proposition 41 parameterizes the tetrahedral orbits by

\[
0\le a\le b\le c\le d\le8,
\qquad a+b+c+d=18.
\]

There are exactly seven orbits with \(a=0\):

\[
\begin{gathered}
(0,2,8,8),\ (0,3,7,8),\ (0,4,6,8),\ (0,4,7,7),\\
(0,5,5,8),\ (0,5,6,7),\ (0,6,6,6).
\end{gathered}
\]

The first four are excluded by the one-cut certificates in
[`d3-z3-two-half-unsat`](../d3-z3-two-half-unsat/README.md).  This bundle excludes the last
three on a complete two-dimensional Walsh plane.

There are exactly eight orbits with \(a=1\):

\[
\begin{gathered}
(1,1,8,8),\ (1,2,7,8),\ (1,3,6,8),\ (1,3,7,7),\\
(1,4,5,8),\ (1,4,6,7),\ (1,5,5,7),\ (1,5,6,6).
\end{gathered}
\]

The same one-cut bundle excludes the first three.  This bundle excludes the remaining five on
the complete Walsh plane.  Hence every globally liftable tetrahedral \(z=3\) profile must
satisfy

\[
2\le a\le b\le c\le d\le8.
\]

The one-cut bundle excludes eight orbits, including the exceptional orbit; the nine plane
certificates are disjoint from them.  Thus the certified exclusions leave at most
\(32-8-9=15\) local \(z=3\) orbits.

## Two \(a=2\) profiles

Profiles 11 and 16 are the tetrahedral partitions

\[
(a,b,c,d)=(2,3,5,8),\qquad (2,2,7,7).
\]

Their certified CNFs add 640 symmetry-breaking clauses to the same four-cell relaxation.  Regard
the cells and plane bases as \(\mathbb F_2^2\).  Translation by \(t\) sends

\[
q\longmapsto q+t,
\qquad
\chi_g(q+t)=\chi_g(t)\chi_g(q).
\]

Thus it multiplies every class value and every row baseline at base \(g\) by the same sign and
preserves each witness condition.  Translate the least selected projective class to cell 0.
Because the four cells have mass eight and the total mass is 32, a selected class lies outside
cell 0.  The group \(\operatorname{GL}(2,2)\) fixes cell 0, acts transitively on the three
nonzero cells, and only permutes the three nonzero plane bases.  It can therefore send the least
selected class outside cell 0 to cell 1.

The 640 clauses impose exactly these two canonical choices: 384 fix the least selected class in
cell 0, and 256 fix the least selected class outside cell 0 in cell 1.  Every unconstrained
plane model has a representative satisfying them, so UNSAT of the symmetry-broken formula
implies UNSAT of the original plane model.  The resulting profile-11 and profile-16 formulas
have the dimensions displayed above and are certified UNSAT.  Hence both profiles are impossible,
leaving at most

\[
15-2=13
\]

local \(z=3\) orbits.

## Two repeated-\(\alpha\) profiles

Profiles 12 and 13 are

\[
(a,b,c,d)=(2,4,4,8),\qquad (3,3,4,8).
\]

The normalization used for profiles 11 and 16 leaves the order-two stabilizer that fixes cells
0 and 1 and exchanges cells 2 and 3.  Since every cell has mass eight, some selected class lies
outside cells 0 and 1.  Send the least such class to cell 2.  For each of the sixteen candidate
classes, its eight states in cell 3 are forbidden unless an earlier class already lies in cell
2 or 3.  These 128 clauses complete the normalization of all

\[
4\cdot3\cdot2=24
\]

affine cell labels, for 768 cell-symmetry clauses in total.

Both profiles also have two heads with the same \(\alpha\).  For a head \(h\), let

\[
\rho(h)=
(n_{h,+,+},n_{h,+,-},n_{h,-,+},n_{h,-,-}),
\]

where the last two signs record rows 4 and 5 and cell labels are forgotten.  The signed-row
stabilizer of the normalized profile exchanges the equal-\(\alpha\) heads, while affine cell
maps leave \(\rho\) unchanged.  We may therefore require the two signatures, ordered by their
canonical head labels, to be lexicographically nondecreasing.  The CNF uses forty one-hot mass
variables and five prefix variables; 352 clauses define the signatures and 145 implement the
lexicographic comparator, adding 45 variables and 497 clauses.

The resulting dimensions are

```text
profile  partition       original clauses  normalized variables  normalized clauses
12       (2,4,4,8)       592456            15445                 593721
13       (3,3,4,8)       592560            15445                 593825
```

Both formulas are certified UNSAT.  Hence neither profile has a plane lift or a global lift,
and at most

\[
13-2=11
\]

local \(z=3\) orbits remain.

## Exact recovery of the two blocks in each cell

The four-cell quotient forgets which of the two original mass-four blocks contains each
selected projective class.  Fix one mass-eight cell and let its positive class multiplicities
be

\[
m_1,\ldots,m_r\in\{1,2,3,4\},\qquad \sum_i m_i=8.
\]

Because a projective class belongs to one original block and cannot be split, the cell recovers
two mass-four blocks exactly when some subset of the \(m_i\) sums to four.  Among the fifteen
integer partitions of eight with parts at most four, the unique obstruction is

\[
3+3+2.
\]

Equivalently, if \(N_j\) counts mass-\(j\) classes in the cell, recovery is possible exactly
when \(N_1\ge N_3\).  The four cells split independently.  Since the four plane characters are
constant on the two blocks within one cell, the split preserves every plane baseline and pair
witness.

The optional `--split-lift` flag encodes this exact criterion.  For every cell it forbids a
mass-two state together with two mass-three states of distinct classes, expanding all eight
orientation choices.  This adds

\[
4\binom{16}{3}\cdot3\cdot2^3=53{,}760
\]

clauses and no variables.  The option is not used by the thirteen certified exclusions above,
so it does not alter their CNFs or proofs.  It also makes no claim about pair separation on the
four bases outside the plane; those require choosing a side for every class and imposing the
new Walsh conditions.

## Direct three-base lift for profile 8

The script `verify_profile8_three_base_lift.py` checks the following actual eight-block
assignment for \((a,b,c,d)=(2,2,6,8)\):

\[
\begin{array}{c|l}
000 &(+-+-+)^4\\
001 &(---++)^4\\
010 &(---+-)^4\\
011 &(-++-+)^4\\
100 &(-++--)^2\cup(-++++)^2\\
101 &(++-+-)^3\cup(++---)^1\\
110 &(++--+)^1\cup(++-++)^3\\
111 &(+-+--)^2\cup(+-+++)^2 .
\end{array}
\]

The verifier reconstructs the projective classes, checks unique block and orientation with
multiplicity at most four, recovers the base-zero profile, and checks all

\[
3\binom{32}{2}=1488
\]

original coordinate-pair conditions at bases \(0,e_1,e_2\).  Its baselines are

\[
T(0)=(0,0,0,4,8),\qquad T(e_1)=T(e_2)=(0,0,0,0,0).
\]

This lift fails at \(e_1+e_2\), while the profile-8 plane CNF is certified UNSAT.  Thus

\[
\{0,e_1,e_2\}\text{ is feasible},\qquad
\langle e_1,e_2\rangle\text{ is infeasible}
\]

for profile 8.

## Four-cell plane relaxation

Two independent Walsh characters divide the eight original blocks into four cells.  A class
state maps by

\[
(\lambda,\varepsilon,n)
\longmapsto
((\lambda_1,\lambda_2),\varepsilon,n).
\]

Every cell has mass eight and is the union of two original mass-four blocks.  At every base in

\[
\{0,e_1,e_2,e_1+e_2\},
\]

the signed row values depend only on the cell.  The quotient therefore preserves all five
baselines and every distinct-type and repeated-type separation condition on the plane, while
forgetting only the split of each cell into its two blocks.  Consequently

\[
\text{global lift}\Longrightarrow\text{four-cell plane model}.
\]

The deterministic generator accepts any of the \(32\) normalized profile indices and optionally
adds the cell, repeated-head, and exact split-lift constraints.  The certified scope of this bundle is
exactly \(8,9,10,11,12,13,15,16,17,18,20,24,25\).  Profiles 11 and 16 use the
640-clause cell option; profiles 12 and 13 use the 768-clause full cell option and the
repeated-head option.

CaDiCaL 3.0.1 at commit `c60730422e758ef1cebe7aeddf2dda31c996bf04` returned UNSAT for
the thirteen formulas.  Each proof was reduced to its core with drat-trim at commit
`2e3b2dc0ecf938addbd779d42877b6ed69d9a985`, emitted as binary DRAT, independently checked
again, and compressed with zstd.  `SHA256SUMS` fixes the compressed proof bytes.

## Verification

From the repository root, with drat-trim built at the recorded commit:

```text
uv run --no-project python \
  units/thr2-lower-bounds/computations/bundles/d3-z3-plane-profile-exclusions/verify_bundle.py \
  --drat-trim /path/to/drat-trim
```

The verifier checks all proof hashes, enumerates the complete \(a\le1\) boundary, directly
validates the profile-8 three-base construction, enumerates the exact cell-splitting criterion,
regenerates one plane CNF at a time, applies
the recorded symmetry normalizations only to profiles 11--13 and 16, decompresses each proof into a temporary
directory, and requires `s VERIFIED` from drat-trim.  Use `--profile 11` for a quick
single-certificate check.

The result does not decide any of the remaining \(11\) \(z=3\) orbits, the \(z=4\) branch, or
the separate three-active parity branch.  It does not prove that a global five-row separating
family exists or is impossible.
