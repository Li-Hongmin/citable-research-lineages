#!/usr/bin/env python3
"""Regenerate and verify the certified z=3 Walsh-plane profile exclusions."""

from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.util
from pathlib import Path
from platform import python_version
import shutil
import subprocess
import sys
import tempfile
from time import perf_counter


sys.dont_write_bytecode = True


BUNDLE = Path(__file__).resolve().parent
GENERATOR = BUNDLE / "generate_z3_plane_profile_cnf.py"
LIFT_VERIFIER = BUNDLE / "verify_profile8_three_base_lift.py"
PROFILES = (8, 9, 10, 11, 12, 13, 15, 16, 17, 18, 20, 24, 25)
PARTIAL_CELL_SYMMETRY_PROFILES = (11, 16)
FULL_CELL_HEAD_SYMMETRY_PROFILES = (12, 13)
PLANE_A0_PROFILES = (9, 17, 24)
PLANE_A1_PROFILES = (10, 15, 18, 20, 25)
EXPECTED_LABELS = {
    8: "partition=(2, 2, 6, 8)",
    9: "partition=(0, 5, 5, 8)",
    10: "partition=(1, 4, 5, 8)",
    11: "partition=(2, 3, 5, 8)",
    12: "partition=(2, 4, 4, 8)",
    13: "partition=(3, 3, 4, 8)",
    15: "partition=(1, 3, 7, 7)",
    16: "partition=(2, 2, 7, 7)",
    17: "partition=(0, 5, 6, 7)",
    18: "partition=(1, 4, 6, 7)",
    20: "partition=(1, 5, 5, 7)",
    24: "partition=(0, 6, 6, 6)",
    25: "partition=(1, 5, 6, 6)",
}
EXPECTED_VARIABLES = {profile: 15_400 for profile in PROFILES}
EXPECTED_VARIABLES.update({12: 15_445, 13: 15_445})
EXPECTED_CLAUSES = {
    8: 592_792,
    9: 591_855,
    10: 592_624,
    11: 593_368,
    12: 593_721,
    13: 593_825,
    15: 593_729,
    16: 594_369,
    17: 592_792,
    18: 593_561,
    20: 593_665,
    24: 592_792,
    25: 593_665,
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def check_hashes() -> None:
    for line in (BUNDLE / "SHA256SUMS").read_text(encoding="ascii").splitlines():
        expected, relative = line.split(maxsplit=1)
        path = BUNDLE / relative.lstrip("*")
        actual = sha256(path)
        if actual != expected:
            raise RuntimeError(f"checksum mismatch for {path.name}: {actual}")
    print("proof_checksums=verified")


def load_generator():
    spec = importlib.util.spec_from_file_location("plane_generator", GENERATOR)
    if not spec or not spec.loader:
        raise RuntimeError("could not load the plane generator")
    generator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(generator)
    return generator


def check_low_a_boundary() -> None:
    generator = load_generator()
    profiles_by_a = {0: [], 1: []}
    for index, label in enumerate(generator.PROFILE_LABELS, start=1):
        if not label.startswith("partition="):
            continue
        partition = ast.literal_eval(label.split("=", 1)[1])
        if partition[0] in profiles_by_a:
            profiles_by_a[partition[0]].append(index)
    expected_a0 = (1, 4, 6, 9, 14, 17, 24)
    expected_a1 = (2, 5, 7, 10, 15, 18, 20, 25)
    if tuple(profiles_by_a[0]) != expected_a0:
        raise RuntimeError(f"unexpected a=0 profiles: {profiles_by_a[0]}")
    if tuple(profiles_by_a[1]) != expected_a1:
        raise RuntimeError(f"unexpected a=1 profiles: {profiles_by_a[1]}")
    if tuple(profile for profile in profiles_by_a[0] if profile not in (1, 4, 6, 14)) != (
        PLANE_A0_PROFILES
    ):
        raise RuntimeError("the plane certificates do not close the remaining a=0 profiles")
    if tuple(profile for profile in profiles_by_a[1] if profile not in (2, 5, 7)) != (
        PLANE_A1_PROFILES
    ):
        raise RuntimeError("the plane certificates do not close the remaining a=1 profiles")
    print("a0_profiles=" + ",".join(map(str, profiles_by_a[0])))
    print("a0_plane_profiles=" + ",".join(map(str, PLANE_A0_PROFILES)))
    print("a1_profiles=" + ",".join(map(str, profiles_by_a[1])))
    print("a1_plane_profiles=" + ",".join(map(str, PLANE_A1_PROFILES)))


def check_split_lift_criterion() -> None:
    generator = load_generator()

    def partitions(total: int, maximum: int, prefix: tuple[int, ...] = ()):
        if total == 0:
            yield prefix
            return
        for part in range(min(total, maximum), 0, -1):
            yield from partitions(total - part, part, prefix + (part,))

    obstructions = []
    for parts in partitions(8, 4):
        splittable = any(
            sum(parts[index] for index in range(len(parts)) if mask >> index & 1)
            == 4
            for mask in range(1 << len(parts))
        )
        if splittable != (parts.count(1) >= parts.count(3)):
            raise RuntimeError(f"split count criterion failed for {parts}")
        if not splittable:
            obstructions.append(parts)
    if obstructions != [(3, 3, 2)]:
        raise RuntimeError(f"unexpected split obstructions: {obstructions}")

    cnf = generator.CNF()
    choice = [
        [cnf.var() for _ in generator.STATES] for _ in generator.CLASSES
    ]
    added = generator.add_split_lift_constraints(cnf, choice)
    if cnf.nvars != 528 or added != 53_760 or len(cnf.clauses) != 53_760:
        raise RuntimeError(
            f"unexpected split encoding: variables={cnf.nvars} clauses={len(cnf.clauses)}"
        )
    print("split_lift_obstruction=3+3+2 split_lift_clauses=53760")


def run_checked(command: list[str]) -> str:
    completed = subprocess.run(
        command,
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    if completed.returncode != 0:
        print(completed.stdout, end="", file=sys.stderr)
        raise RuntimeError(
            f"command failed with exit code {completed.returncode}: {' '.join(command)}"
        )
    return completed.stdout


def main() -> None:
    started = perf_counter()
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--drat-trim",
        type=Path,
        help="path to drat-trim (otherwise resolved from PATH)",
    )
    parser.add_argument(
        "--zstd",
        type=Path,
        help="path to zstd (otherwise resolved from PATH)",
    )
    parser.add_argument(
        "--profile",
        action="append",
        type=int,
        choices=PROFILES,
        help="verify only this profile; repeat to select several",
    )
    args = parser.parse_args()

    drat_trim = str(args.drat_trim) if args.drat_trim else shutil.which("drat-trim")
    zstd = str(args.zstd) if args.zstd else shutil.which("zstd")
    if not drat_trim:
        parser.error("drat-trim was not found; pass --drat-trim /path/to/drat-trim")
    if not zstd:
        parser.error("zstd was not found; pass --zstd /path/to/zstd")

    print(f"python={python_version()}")
    print(f"drat_trim={drat_trim}")
    print(run_checked([zstd, "--version"]).strip())
    check_hashes()
    check_low_a_boundary()
    check_split_lift_criterion()
    lift = run_checked([sys.executable, str(LIFT_VERIFIER)])
    print(lift, end="")

    profiles = sorted(set(args.profile or PROFILES))
    with tempfile.TemporaryDirectory(prefix="d3-z3-plane-profiles-") as temporary:
        work = Path(temporary)
        for profile in profiles:
            cnf = work / f"profile-{profile}.cnf"
            proof = work / f"profile-{profile}.drat"
            generate_command = [
                sys.executable,
                str(GENERATOR),
                "--profile",
                str(profile),
                "--dimacs",
                str(cnf),
            ]
            if profile in PARTIAL_CELL_SYMMETRY_PROFILES:
                generate_command.append("--cell-symmetry-break")
            elif profile in FULL_CELL_HEAD_SYMMETRY_PROFILES:
                generate_command.extend(
                    ["--full-cell-symmetry-break", "--head-lex-symmetry-break"]
                )
            generated = run_checked(generate_command)
            expected = (
                f"profile={profile} {EXPECTED_LABELS[profile]} "
                f"variables={EXPECTED_VARIABLES[profile]} clauses={EXPECTED_CLAUSES[profile]} "
                "bases=(0, 1, 2, 3)"
            )
            if expected not in generated:
                raise RuntimeError(
                    f"unexpected CNF dimensions for profile {profile}: {generated.strip()}"
                )

            compressed = BUNDLE / "proofs" / f"profile-{profile}.drat.zst"
            run_checked([zstd, "-d", "-q", "-f", "-o", str(proof), str(compressed)])
            verified = run_checked([drat_trim, str(cnf), str(proof), "-i", "-w"])
            if "s VERIFIED" not in verified:
                print(verified, end="", file=sys.stderr)
                raise RuntimeError(f"profile {profile} proof was not verified")
            print(
                f"profile={profile} variables={EXPECTED_VARIABLES[profile]} "
                f"clauses={EXPECTED_CLAUSES[profile]} plane_result=VERIFIED_UNSAT"
            )

    if tuple(profiles) == PROFILES:
        print("a_le_1_boundary=EXCLUDED")
        print("profile_11=EXCLUDED")
        print("profile_12=EXCLUDED")
        print("profile_13=EXCLUDED")
        print("profile_16=EXCLUDED")
        print("surviving_z3_orbits=11")
    print("result=PASS verified_profiles=" + ",".join(map(str, profiles)))
    print(f"elapsed_seconds={perf_counter() - started:.6f}")


if __name__ == "__main__":
    main()
