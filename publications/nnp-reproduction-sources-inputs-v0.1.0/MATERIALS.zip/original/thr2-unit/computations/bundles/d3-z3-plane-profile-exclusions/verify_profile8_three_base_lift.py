#!/usr/bin/env python3
"""Directly verify an eight-block lift of profile (2,2,6,8) on bases 0,1,2."""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations


ROWS = range(5)
BASES = (0, 1, 2)
EXPECTED_PROFILE = {
    3: 2,
    5: 6,
    6: 6,
    8: 8,
    11: 6,
    13: 2,
    14: 2,
}

# block: (projective class, orientation, multiplicity)
ASSIGNMENT = {
    0: ((5, 1, 4),),
    1: ((8, 1, 4),),
    2: ((7, -1, 4),),
    3: ((6, 1, 4),),
    4: ((9, -1, 2), (14, 1, 2)),
    5: ((4, -1, 3), (12, -1, 1)),
    6: ((3, 1, 1), (11, 1, 3)),
    7: ((10, -1, 2), (13, 1, 2)),
}


def representative(projective: int, row: int) -> int:
    return 1 if row == 4 or (projective >> row) & 1 else -1


def chi(base: int, block: int) -> int:
    return -1 if (base & block).bit_count() & 1 else 1


def main() -> None:
    columns: list[tuple[int, ...]] = []
    metadata: list[tuple[int, int, int]] = []
    class_blocks: dict[int, set[int]] = defaultdict(set)
    class_orientations: dict[int, set[int]] = defaultdict(set)
    class_multiplicity: Counter[int] = Counter()

    for block in range(8):
        states = ASSIGNMENT[block]
        assert sum(mass for _projective, _orientation, mass in states) == 4
        for projective, orientation, mass in states:
            assert orientation in (-1, 1)
            assert 1 <= mass <= 4
            column = tuple(
                orientation * representative(projective, row) for row in ROWS
            )
            columns.extend([column] * mass)
            metadata.extend([(block, projective, orientation)] * mass)
            class_blocks[projective].add(block)
            class_orientations[projective].add(orientation)
            class_multiplicity[projective] += mass

    assert len(columns) == 32
    assert all(len(blocks) == 1 for blocks in class_blocks.values())
    assert all(len(signs) == 1 for signs in class_orientations.values())
    assert all(mass <= 4 for mass in class_multiplicity.values())

    profile: Counter[int] = Counter()
    for column in columns:
        code = sum((column[row] == 1) << row for row in range(4))
        profile[code] += 1
    assert dict(profile) == EXPECTED_PROFILE

    totals = {
        base: tuple(
            sum(
                columns[index][row] * chi(base, metadata[index][0])
                for index in range(32)
            )
            for row in ROWS
        )
        for base in range(8)
    }
    assert totals[0] == (0, 0, 0, 4, 8)
    assert totals[1] == totals[2] == (0, 0, 0, 0, 0)

    checked = 0
    for base in BASES:
        for left, right in combinations(range(32), 2):
            assert any(
                (
                    value := columns[left][row] * chi(base, metadata[left][0])
                )
                == columns[right][row] * chi(base, metadata[right][0])
                and totals[base][row] in (0, 4 * value)
                for row in ROWS
            ), (base, left, right)
            checked += 1
    assert checked == 1488

    first_plane_failure = None
    for left, right in combinations(range(32), 2):
        if not any(
            (value := columns[left][row] * chi(3, metadata[left][0]))
            == columns[right][row] * chi(3, metadata[right][0])
            and totals[3][row] in (0, 4 * value)
            for row in ROWS
        ):
            first_plane_failure = (left, right)
            break
    assert first_plane_failure is not None

    print("profile=(2,2,6,8)")
    print("block_masses=4,4,4,4,4,4,4,4")
    print(f"selected_projective_classes={len(class_blocks)}")
    print("baselines_base0=0,0,0,4,8")
    print("baselines_base1=0,0,0,0,0")
    print("baselines_base2=0,0,0,0,0")
    print(f"verified_coordinate_pairs={checked}")
    print(
        "base3_first_failure="
        + ",".join(map(str, first_plane_failure))
        + " (this construction is not global)"
    )
    print("result=PASS")


if __name__ == "__main__":
    main()
