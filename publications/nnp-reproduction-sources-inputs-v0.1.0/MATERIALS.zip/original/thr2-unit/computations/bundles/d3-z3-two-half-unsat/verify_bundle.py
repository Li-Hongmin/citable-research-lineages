#!/usr/bin/env python3
"""Regenerate and verify the two-half DRAT certificates for the z=3 branch."""

from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.util
from pathlib import Path
from platform import python_version
import shutil
import subprocess
import sys
import tempfile
from time import perf_counter

sys.dont_write_bytecode = True


BUNDLE = Path(__file__).resolve().parent
GENERATOR = BUNDLE / "generate_z3_two_half_cnf.py"
PROFILES = (1, 2, 3, 4, 5, 6, 7, 14)
EXPECTED_CLAUSES = {
    1: 208_388,
    2: 208_629,
    3: 208_629,
    4: 208_613,
    5: 208_854,
    6: 208_569,
    7: 208_838,
    14: 208_810,
}
EXPECTED_VARIABLES = 7_980


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def check_hashes() -> None:
    for line in (BUNDLE / "SHA256SUMS").read_text(encoding="ascii").splitlines():
        expected, relative = line.split(maxsplit=1)
        path = BUNDLE / relative.lstrip("*")
        actual = sha256(path)
        if actual != expected:
            raise RuntimeError(f"checksum mismatch for {path.name}: {actual}")
    print("proof_checksums=verified")


def run_checked(command: list[str], *, stdout=None) -> str:
    completed = subprocess.run(
        command,
        check=False,
        stdout=stdout or subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=stdout is None,
    )
    output = "" if stdout is not None else completed.stdout
    if completed.returncode != 0:
        if output:
            print(output, end="", file=sys.stderr)
        raise RuntimeError(
            f"command failed with exit code {completed.returncode}: {' '.join(command)}"
        )
    return output


def check_profile_boundary() -> None:
    spec = importlib.util.spec_from_file_location("two_half_generator", GENERATOR)
    if not spec or not spec.loader:
        raise RuntimeError("could not load the generator")
    generator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(generator)
    selected = []
    for index, label in enumerate(generator.PROFILE_LABELS, start=1):
        if label.startswith("exceptional="):
            selected.append(index)
            continue
        partition = ast.literal_eval(label.split("=", 1)[1])
        a, b, _c, d = partition
        if a <= 1 and a + b <= 4 and (a == 0 or d == 8):
            selected.append(index)
    if tuple(selected) != PROFILES:
        raise RuntimeError(f"unexpected excluded profile indices: {selected}")
    print("profile_boundary=exceptional_or_a<=1,a+b<=4,(a=0_or_d=8)")
    print("excluded_profiles=" + ",".join(map(str, PROFILES)))
    print(f"surviving_orbits={len(generator.PROFILES) - len(PROFILES)}")


def main() -> None:
    started = perf_counter()
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--drat-trim",
        type=Path,
        help="path to drat-trim (otherwise resolved from PATH)",
    )
    parser.add_argument(
        "--zstd",
        type=Path,
        help="path to zstd (otherwise resolved from PATH)",
    )
    parser.add_argument(
        "--profile",
        action="append",
        type=int,
        choices=PROFILES,
        help="verify only this profile; repeat to select several",
    )
    args = parser.parse_args()

    drat_trim = str(args.drat_trim) if args.drat_trim else shutil.which("drat-trim")
    zstd = str(args.zstd) if args.zstd else shutil.which("zstd")
    if not drat_trim:
        parser.error("drat-trim was not found; pass --drat-trim /path/to/drat-trim")
    if not zstd:
        parser.error("zstd was not found; pass --zstd /path/to/zstd")

    print(f"python={python_version()}")
    print(f"drat_trim={drat_trim}")
    print(run_checked([zstd, "--version"]).strip())
    check_hashes()
    check_profile_boundary()

    profiles = sorted(set(args.profile or PROFILES))
    with tempfile.TemporaryDirectory(prefix="d3-z3-two-half-") as temporary:
        work = Path(temporary)
        for profile in profiles:
            cnf = work / f"profile-{profile}.cnf"
            proof = work / f"profile-{profile}.drat"
            generated = run_checked(
                [
                    sys.executable,
                    str(GENERATOR),
                    "--profile",
                    str(profile),
                    "--dimacs",
                    str(cnf),
                ]
            )
            expected = (
                f"variables={EXPECTED_VARIABLES} clauses={EXPECTED_CLAUSES[profile]} "
                "bases=(0, 1)"
            )
            if expected not in generated:
                raise RuntimeError(
                    f"unexpected CNF dimensions for profile {profile}: {generated.strip()}"
                )

            compressed = BUNDLE / "proofs" / f"profile-{profile}.drat.zst"
            run_checked([zstd, "-d", "-q", "-f", "-o", str(proof), str(compressed)])
            verified = run_checked([drat_trim, str(cnf), str(proof), "-i"])
            if "s VERIFIED" not in verified:
                print(verified, end="", file=sys.stderr)
                raise RuntimeError(f"profile {profile} was not verified")
            print(
                f"profile={profile} variables={EXPECTED_VARIABLES} "
                f"clauses={EXPECTED_CLAUSES[profile]} result=VERIFIED"
            )

    print(f"result=PASS verified_profiles={','.join(map(str, profiles))}")
    print(f"elapsed_seconds={perf_counter() - started:.6f}")


if __name__ == "__main__":
    main()
