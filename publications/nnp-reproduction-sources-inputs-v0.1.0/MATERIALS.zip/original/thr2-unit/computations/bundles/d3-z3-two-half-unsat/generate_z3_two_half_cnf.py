#!/usr/bin/env python3
"""Generate the two-half CNFs used to exclude eight normalized z=3 profiles.

Fixing one nonzero Walsh base divides the eight four-coordinate blocks into two
halves of mass sixteen.  Forgetting the four blocks inside each half is a
relaxation of the original problem.  The formula retains Proposition 37's
one-state-per-projective-class property, multiplicity at most four, the exact
z=3 normalization at base zero, and every type-pair condition at bases 0 and 1.
"""

from __future__ import annotations

import argparse
import itertools
from pathlib import Path


ROWS = range(5)
HALVES = range(2)
CLASSES = range(16)
BASES = (0, 1)


def chi(g: int, half: int) -> int:
    return -1 if g == 1 and half == 1 else 1


def representative(projective: int, row: int) -> int:
    if row == 4:
        return 1
    return 1 if (projective >> row) & 1 else -1


class CNF:
    def __init__(self) -> None:
        self.nvars = 0
        self.clauses: list[list[int]] = []

    def var(self) -> int:
        self.nvars += 1
        return self.nvars

    def add(self, *literals: int) -> None:
        self.clauses.append(list(literals))

    def exactly_one(self, literals: list[int]) -> None:
        self.add(*literals)
        for index, left in enumerate(literals):
            for right in literals[index + 1 :]:
                self.add(-left, -right)

    def write(self, path: Path) -> None:
        with path.open("w", encoding="ascii") as stream:
            stream.write(f"p cnf {self.nvars} {len(self.clauses)}\n")
            for clause in self.clauses:
                stream.write(" ".join(map(str, clause)) + " 0\n")


# State zero is unused.  Every other state is (half, orientation, mass).
STATES: list[tuple[int | None, int, int]] = [(None, 0, 0)] + [
    (half, orientation, mass)
    for half in HALVES
    for orientation in (-1, 1)
    for mass in range(1, 5)
]


def add_categorical_sum(
    cnf: CNF,
    choice: list[list[int]],
    contribution,
    maximum: int,
    target: int | None = None,
) -> list[list[int]]:
    """Exact DP for a sum of contributions chosen by categorical variables."""
    stages = [[cnf.var() for _ in range(maximum + 1)] for _ in range(17)]
    for stage in stages:
        cnf.exactly_one(stage)
    cnf.add(stages[0][0])
    for value in range(1, maximum + 1):
        cnf.add(-stages[0][value])

    for projective in CLASSES:
        for previous in range(maximum + 1):
            for state_index, state in enumerate(STATES):
                value = previous + contribution(projective, state)
                if value <= maximum:
                    cnf.add(
                        -stages[projective][previous],
                        -choice[projective][state_index],
                        stages[projective + 1][value],
                    )
                else:
                    cnf.add(-stages[projective][previous], -choice[projective][state_index])
    if target is not None:
        cnf.add(stages[16][target])
    return stages


def safe_canonical(profile: tuple[int, ...]) -> tuple[int, ...]:
    """Canonicalize under (C2)^3 semidirect S3 on the three zero rows."""
    best = None
    for permutation in itertools.permutations(range(3)):
        for flips in range(8):
            image = [0] * 16
            for code in range(16):
                target = code & 8
                for row in range(3):
                    value = ((code >> permutation[row]) & 1) ^ ((flips >> row) & 1)
                    target |= value << row
                image[target] = profile[code]
            candidate = tuple(image)
            if best is None or candidate < best:
                best = candidate
    assert best is not None
    return best


def bounded_partition_profile(partition: tuple[int, int, int, int]) -> tuple[int, ...]:
    """Proposition 41 family (33kh), with H={+++, +--, -+-, --+}."""
    profile = [0] * 16
    for head, alpha in zip((7, 1, 2, 4), partition):
        profile[head + 8] = alpha
        profile[head] = 8 - alpha
    return safe_canonical(tuple(profile))


def exceptional_profile() -> tuple[int, ...]:
    """Proposition 41 family (33ki), using S={+++, +--}."""
    profile = [0] * 16
    heads = (7, 1, 2, 4)
    selected = set(heads[:2])
    for head in heads:
        if head in selected:
            profile[head + 8] = 8
            profile[(7 - head) + 8] = 1
        else:
            profile[head] = 7
    return safe_canonical(tuple(profile))


PROFILE_PARTITIONS = tuple(
    (a, b, c, d)
    for a in range(9)
    for b in range(a, 9)
    for c in range(b, 9)
    for d in range(c, 9)
    if a + b + c + d == 18
)
assert len(PROFILE_PARTITIONS) == 31
PROFILE_LABEL_BY_VALUE = {
    bounded_partition_profile(partition): f"partition={partition}"
    for partition in PROFILE_PARTITIONS
}
PROFILE_LABEL_BY_VALUE[exceptional_profile()] = "exceptional=(8,1;7)"
assert len(PROFILE_LABEL_BY_VALUE) == 32

PROFILE_PATTERNS = tuple(range(16))
PROFILES = tuple(sorted(PROFILE_LABEL_BY_VALUE))
PROFILE_LABELS = tuple(PROFILE_LABEL_BY_VALUE[profile] for profile in PROFILES)


def build(profile_index: int) -> CNF:
    cnf = CNF()
    choice = [[cnf.var() for _ in STATES] for _ in CLASSES]
    for states in choice:
        cnf.exactly_one(states)

    targets = dict(zip(PROFILE_PATTERNS, PROFILES[profile_index]))
        # Orientation + of class p projects to p on the first four rows;
        # orientation - projects to its complement 15-p.  A compatible
        # clique contains at most one member of each complementary pair.
    for projective in CLASSES:
        for state_index, state in enumerate(STATES[1:], start=1):
            projected = projective if state[1] == 1 else 15 - projective
            if targets.get(projected, 0) == 0:
                cnf.add(-choice[projective][state_index])
    # For each surviving projected pattern x, exactly its two canonical
    # classes x and 15-x can realize it.  Forbid every mass pair that does
    # not sum to the prescribed aggregate profile.
    for projected, target in targets.items():
        if target == 0:
            continue
        left, right = projected, 15 - projected
        for left_index, left_state in enumerate(STATES):
            left_mass = (
                left_state[2]
                if left_state[0] is not None and left_state[1] == 1
                else 0
            )
            for right_index, right_state in enumerate(STATES):
                right_mass = (
                    right_state[2]
                    if right_state[0] is not None and right_state[1] == -1
                    else 0
                )
                if left_mass + right_mass != target:
                    cnf.add(-choice[left][left_index], -choice[right][right_index])

    # The chosen nonzero base cuts the 32 coordinates into two halves of mass 16.
    for half in HALVES:
        add_categorical_sum(
            cnf,
            choice,
            lambda _p, state, half=half: state[2] if state[0] == half else 0,
            maximum=16,
            target=16,
        )

    final_count: dict[tuple[int, int, int], int] = {}
    for row in ROWS:
        for g in BASES:
            stages = add_categorical_sum(
                cnf,
                choice,
                lambda p, state, row=row, g=g: (
                    state[2]
                    if state[0] is not None
                    and state[1] * representative(p, row) * chi(g, state[0]) == 1
                    else 0
                ),
                maximum=32,
            )
            for count in range(33):
                final_count[row, g, count] = stages[16][count]

    # Exact z=3 normalization.  The inactive fifth row can independently be
    # negated, so fix its nonzero baseline positive (plus count > 16).
    cnf.add(final_count[0, 0, 16])
    cnf.add(final_count[1, 0, 16])
    cnf.add(final_count[2, 0, 16])
    cnf.add(final_count[3, 0, 18])
    cnf.add(*[final_count[4, 0, count] for count in range(17, 33) if count != 18])

    value_plus: dict[tuple[int, int, int], int] = {}
    for projective in CLASSES:
        for g in BASES:
            for row in ROWS:
                literal = cnf.var()
                value_plus[projective, g, row] = literal
                for state_index, state in enumerate(STATES):
                    if state[0] is None:
                        positive = False
                    else:
                        positive = (
                            state[1]
                            * representative(projective, row)
                            * chi(g, state[0])
                            == 1
                        )
                    cnf.add(-choice[projective][state_index], literal if positive else -literal)

    def add_witness_conditions(witness: int, p: int, g: int, row: int, q: int | None) -> None:
        # A witness may only refer to selected types.
        cnf.add(-witness, -choice[p][0])
        if q is not None:
            cnf.add(-witness, -choice[q][0])
            vp, vq = value_plus[p, g, row], value_plus[q, g, row]
            cnf.add(-witness, -vp, vq)
            cnf.add(-witness, vp, -vq)
        vp = value_plus[p, g, row]
        # vp=+1 requires T in {0,+4}; vp=-1 requires T in {0,-4}.
        cnf.add(-witness, -vp, final_count[row, g, 16], final_count[row, g, 18])
        cnf.add(-witness, vp, final_count[row, g, 16], final_count[row, g, 14])

    for p in CLASSES:
        for q in range(p + 1, 16):
            for g in BASES:
                witnesses = []
                for row in ROWS:
                    witness = cnf.var()
                    witnesses.append(witness)
                    add_witness_conditions(witness, p, g, row, q)
                cnf.add(choice[p][0], choice[q][0], *witnesses)

    # Repeated coordinates of one selected type also require a witness.
    for p in CLASSES:
        nonrepeated = [choice[p][0]] + [
            choice[p][state_index]
            for state_index, state in enumerate(STATES)
            if state_index and state[2] == 1
        ]
        for g in BASES:
            witnesses = []
            for row in ROWS:
                witness = cnf.var()
                witnesses.append(witness)
                add_witness_conditions(witness, p, g, row, None)
            cnf.add(*nonrepeated, *witnesses)

    return cnf


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dimacs", type=Path, required=True)
    parser.add_argument("--profile", type=int, choices=range(1, len(PROFILES) + 1), required=True)
    args = parser.parse_args()
    profile_index = args.profile - 1
    cnf = build(profile_index)
    print(
        f"profile={args.profile} {PROFILE_LABELS[profile_index]} "
        f"variables={cnf.nvars} clauses={len(cnf.clauses)} bases={BASES}"
    )
    cnf.write(args.dimacs)


if __name__ == "__main__":
    main()
