# Two-half DRAT certificates for eight three-zero profiles

This bundle verifies the finite exclusion used in Proposition 42 of the active paper.  Under the
assumptions of Proposition 37, normalize a four-active Walsh base to \(0\) with baselines

\[
(T_1(0),T_2(0),T_3(0),T_4(0))=(0,0,0,4).
\]

Proposition 41 classifies the projected four-row data into 31 tetrahedral profile orbits,
indexed by

\[
0\le a\le b\le c\le d\le8,
\qquad a+b+c+d=18,
\]

and one exceptional \((8,1;7)\) orbit.

## The two-half relaxation

Fix any nonzero Walsh base \(g\).  It divides the eight blocks into the two halves
\(\chi_g(\lambda)=\pm1\), each of total mass \(16\).  A projective class in the original
problem has a unique state

\[
(\lambda,\varepsilon,n),
\qquad 1\le n\le4.
\]

The map

\[
(\lambda,\varepsilon,n)
\longmapsto
(\chi_g(\lambda),\varepsilon,n)
\]

forgets only the four capacity-four blocks inside each half.  It preserves the class,
orientation and multiplicity, the mass \(16\) of both halves, all five baselines at bases
\(0,g\), and every distinct-type and repeated-type separation condition at those bases.
Consequently the generated two-half formula is a relaxation:

\[
\text{original lift across }\{0,g\}
\Longrightarrow
\text{two-half model}.
\]

An UNSAT certificate for the relaxation therefore excludes the corresponding global profile.
All nonzero \(g\) are equivalent after a \(\mathrm{GL}(3,2)\) relabelling fixing base \(0\), so
the generator uses \(g=1\).

## Certified profile boundary

The bundle excludes the exceptional orbit and exactly the seven tetrahedral partitions satisfying

\[
a\le1,
\qquad a+b\le4,
\qquad (a=0\ \text{or}\ d=8).
\]

They occur at the generator indices below.

```text
profile  label                  variables  clauses
1        (0,2,8,8)              7980       208388
2        (1,1,8,8)              7980       208629
3        exceptional (8,1;7)    7980       208629
4        (0,3,7,8)              7980       208613
5        (1,2,7,8)              7980       208854
6        (0,4,6,8)              7980       208569
7        (1,3,6,8)              7980       208838
14       (0,4,7,7)              7980       208810
```

The eight binary DRAT proofs in `proofs/` were generated with CaDiCaL 3.0.1 at commit
`c60730422e758ef1cebe7aeddf2dda31c996bf04` and independently checked with `drat-trim` at
commit `2e3b2dc0ecf938addbd779d42877b6ed69d9a985`.  `SHA256SUMS` fixes the compressed proof
bytes.  This leaves \(32-8=24\) profile orbits not excluded by these certificates.

## Verification

Build `drat-trim` at the recorded commit, make `zstd` available, and run from the repository
root:

```text
uv run --no-project python units/thr2-lower-bounds/computations/bundles/d3-z3-two-half-unsat/verify_bundle.py \
  --drat-trim /path/to/drat-trim
```

The verifier checks the proof hashes, confirms the analytic profile boundary, regenerates one
CNF at a time, decompresses the matching proof into a temporary directory, and requires
`s VERIFIED` from `drat-trim`.  Use `--profile 1` for a quick single-certificate check.

The conclusion is only a strict surviving-orbit reduction for the \(z=3\) four-active branch.
The remaining 24 \(z=3\) orbits, the \(z=4\) branch, and the three-active branch are not
decided here.
