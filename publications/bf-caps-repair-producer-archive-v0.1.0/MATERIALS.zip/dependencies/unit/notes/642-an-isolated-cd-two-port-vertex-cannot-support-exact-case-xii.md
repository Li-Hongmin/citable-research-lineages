> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# An isolated \(C,D\) two-port vertex cannot support exact Case XII

Retain the minimum-host, tight-carrier and genuine-row hypotheses of [Note 641](641-an-isolated-two-port-vertex-forces-a-nested-case-xiii-cut.md), and the \((B,b)\) central-path prism of [Notes 513](513-the-last-central-path-forbidden-pair-requires-a-long-route.md) and [515](515-two-zero-shore-masks-must-share-the-long-route-e-exit.md). Thus the external core is the path \(1-2-3-4-5-6\), with its five edges subdivided at \(u_1,\ldots,u_5\), and its four remaining edges subdivided at the marks
\[
X=13,\qquad Y=25,\qquad Z=46,\qquad W=16.
\]
The marked vertices join the corresponding vertices of the original terminal pentagon, whose two possible orders under exact Case XII are
\[
S_1=e-X-Y-W-Z-e,\qquad S_2=e-X-W-Y-Z-e.
\]
The shore ports \(p_i\) join \(u_i\). In either residual signature of Note 515, the \(C\)-port is \(p_3\) and the \(D\)-port is \(p_4\) or \(p_5\).

**Theorem.** A quotient-isolated zero-length original-port path \(d\) carrying \(C,D\) is impossible in this exact Case-XII minimum-host branch, at every shore order.

By Note 641, the cut isolating the fixed opposite five-pole \(H\) is a genuine Case-XIII cut. The known row has a loop on the carrier side, so the complete boundary relation of \(H\) must be the loopless \(R^*\). The published [Proposition 4.4 and its preceding discussion](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) state that a pole with this \(R^*\) relation is not three-edge-colourable. We give a three-edge-colouring of \(H\) for each allowed pentagon order.

Use colours \(1,2,3\). For each subdivided core edge, the table records the colours on its two halves, in the order of the indicated endpoints. Its third edge, toward a shore port or pentagon vertex, receives the omitted colour. The ports \(p_3,p_4\) or \(p_3,p_5\) join the single vertex \(d\); the other four original shore attachments become cut semiedges of \(H\).

| subdivided edge (endpoint order) | \(S_1\) halves | \(S_1\) third colour | \(S_2\) halves | \(S_2\) third colour |
|---|---:|---:|---:|---:|
| \(u_1:12\) | \(1,3\) | \(2\) | \(3,2\) | \(1\) |
| \(u_2:23\) | \(1,2\) | \(3\) | \(3,1\) | \(2\) |
| \(u_3:34\) | \(3,1\) | \(2\) | \(2,3\) | \(1\) |
| \(u_4:45\) | \(2,3\) | \(1\) | \(2,1\) | \(3\) |
| \(u_5:56\) | \(2,3\) | \(1\) | \(3,1\) | \(2\) |
| \(X:13\) | \(2,1\) | \(3\) | \(1,3\) | \(2\) |
| \(Y:25\) | \(2,1\) | \(3\) | \(1,2\) | \(3\) |
| \(Z:46\) | \(3,2\) | \(1\) | \(1,2\) | \(3\) |
| \(W:16\) | \(3,1\) | \(2\) | \(2,3\) | \(1\) |

For \(S_1\), colour its consecutive pentagon edges \(eX,XY,YW,WZ,Ze\) by \(1,2,1,3,2\). For \(S_2\), colour \(eX,XW,WY,YZ,Ze\) by \(1,3,2,1,2\). At the pentagon vertex \(e\), the remaining cut semiedge has colour \(3\) in both cases. At each of the four other pentagon vertices, the spoke colour in the table differs from its two incident pentagon-edge colours. At each of the six original core vertices, its three displayed incident half-edge colours are \(1,2,3\).

For \(S_1\), the edges \(du_3\) and \(du_4\) or \(du_5\) have colours \(2,1\), so the cut semiedge at \(d\) has colour \(3\). For \(S_2\), they have colours \(1,3\) or \(1,2\), so that semiedge has colour \(2\) or \(3\), respectively. Every vertex of \(H\) therefore sees all three colours. This is a proper three-edge-colouring of the **entire opposite five-pole**, contradicting its required \(R^*\) relation. \(\square\)

## Orientation of the surviving \(A,B\) placement

The same fixed opposite pole is three-edge-colourable when \(d\) carries any \(A,B\) pair. To check the two terminal attachments at \(d\), first leave all six ports \(e,p_1,\ldots,p_5\) as semiedges. The two colourings above have the following signatures:
\[
\begin{array}{c|rrrrrr}
 &e&p_1&p_2&p_3&p_4&p_5\\\hline
S_1&3&2&3&2&1&1\\
S_2&3&1&2&1&3&2.
\end{array}                                                    \tag{1}
\]
Here an \(A\)-port is one of \(e,p_1,p_2\), and a \(B\)-port is \(p_4\) or \(p_5\). The \(S_1\) signature separates every such pair. The \(S_2\) signature separates all pairs except \((e,p_4)\) and \((p_2,p_5)\).

Reflecting the first colouring by \(i\mapsto7-i\) on the core interchanges \(X,Z\), fixes \(Y,W\), sends \(p_i\) to \(p_{6-i}\), and changes \(S_1\) into \(S_2\). Its \(S_2\) signature is
\[
                 (e,p_1,p_2,p_3,p_4,p_5)=(3,1,1,2,3,2),          \tag{2}
\]
which separates \((p_2,p_5)\).

For \((e,p_4)\), take the \(S_1\) colouring in the table and switch colours \(1,3\) on the alternating path
\[
e-\bar e-\bar X-t_X-3-u_3-4-t_Z-\bar Z-\bar W-\bar Y-t_Y-5-u_4-p_4.
\]
Bars denote pentagon vertices and \(t_X,t_Y,t_Z\) the marked subdivision vertices. The displayed path alternates \(3,1\) and has no other terminal; switching changes only the boundary colours at \(e\) and \(p_4\), from \((3,1)\) to \((1,3)\). The colour at \(p_2\) remains \(3\). Reflecting this switched colouring yields an \(S_2\) colouring with \(e=1,p_4=3\). Thus every \(A,B\) attachment can be joined at \(d\) using two different colours, with its third colour on the carrier cut semiedge.

Consequently, under exact Case XII, the opposite pole is \(L^*\) and the carrier-plus-\((F-\{d\})\) side must be \(R^*\). [Note 564's terminal-independence theorem](564-case-xiii-rstar-terminal-independence-excludes-an-eight-edge-loop-centre.md) then requires the four remaining original-port vertices in \(F-\{d\}\) to be distinct and pairwise nonadjacent. In particular, an original internal \(N_0\)-edge joining two of them excludes the placement. This necessary condition uses the **complete** Case-XIII relation, not only the known row \((aC)(aD)\).

In the twelve-vertex disconnected exterior left by [Note 639](639-no-isolated-one-edge-path-in-a-disconnected-twelve-vertex-exterior.md), an isolated two-port vertex can consequently carry only an \(A,B\) pair, and its carrier side must realize \(R^*\). This does not exclude that orientation, larger exteriors, other carriers, full exact Case XII, or Berge--Fulkerson. The colour certificates are hand derivations from the fixed host wiring and the published Case-XIII relation; they have not had independent review. No OMEN or local mathematical recomputation was used.
