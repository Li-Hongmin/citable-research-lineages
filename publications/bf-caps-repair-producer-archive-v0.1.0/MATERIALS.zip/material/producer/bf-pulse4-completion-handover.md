> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# BF fourth bounded pulse: actual four-occurrence repair

2026-10-03. This is new task-5 material; the original BF unit remains read-only and the earlier frozen candidates are retained.

## Mathematical advance

The previous pulse supplied necessary component-weight inequalities, but no four-occurrence repair. This pulse supplies such a repair under an explicit checkable condition in **every genuine permitted row** satisfying the stated zero-port assumptions. This pulse does not prove that complete support or minimum-host assumptions force that condition.

The self-contained candidate is `bf-pulse4-four-occurrence-completion.md`. Start with an actual shore row (Q_a,Q_b,R_c,R_d,R_e,R_f), both a,b zero-port on Z, and switch a on a union of internal difference cycles to obtain P. Hold b fixed. The target residual demand is m=2−1_P−1_Qb. Edges of demand one are the retained difference edges; edges of demand two form a graph K consisting of paths and cycles. Fix the original residual singleton colours on demand-one edges and fix every port's original residual pair. Then a four-occurrence repair exists **iff**:

- all closed K components are even;
- on each L-edge K path, endpoint pairs agree for odd L and are complementary for even L, counting semiedges as edges.

The proof constructs all four matching occurrences by alternating each pair and its complement. A compatible path has one labelling; each even cycle has six, giving 6^z labelled completions with z closed cycles. This is a proof and constructor, not an existential solver claim or enumeration result.

Slotwise shore boundary masks remain unchanged. Therefore one can glue these four repaired shore matchings, P and Q_b, to the **original six exterior occurrences of L**. They remain actual whole-L matchings and produce the same permitted L-boundary state. No cover of a hypothetical counterexample host G is assumed or constructed.

A simpler local theorem gives an immediate special case: if all b-only edges on a selected difference component have the same residual colour h, swapping a,h on that component gives an explicit repair with the other three residual slots unchanged. Under the stronger rule that all residual labels outside the selected components are fixed, this uniform condition is also necessary. The K test allows more proper-edge recolouring and can pass without uniformity.

## Two distinct failure meanings

An **odd closed K cycle** has only demand-two incidences and excludes every completion of that target pair, even if all demand-one colours are freed. This is an unconditional obstruction.

An **endpoint mismatch with the original singleton colours pinned** excludes only that completion class. It is not a certificate of global BF incompatibility. The fixed cube witness proves this distinction: flipping its top square fails the original-pins test, but an explicitly supplied completion succeeds by changing the retained bottom singleton colours.

The candidate also states the exact fully free reduction. Assign each retained demand-one edge one global colour t_e in {c,d,e,f}; the two incident such colours at each retained-difference vertex must differ. Its K endpoint pair becomes I minus those two colours. A boundary-preserving free completion exists iff there are no odd K cycles and some such assignment makes **all** K path relations hold with the fixed port pairs. This removes the doubled paths from the unknown system, but existence of that singleton assignment remains a mathematical obligation. No assignment search or SAT was performed.

## Component weights now have a constructive companion

For every closed odd cycle O avoiding Q_b and every repaired row, the capacity bound forces |P intersection E(O)|>=2. If D has components C_i and w_i(O)=|Q_a intersection E(C_i) intersection E(O)|, a successful switch deleting S therefore gives sum_(i not in S)w_i(O)>=2 for every O.

All uniform eligible components can be removed simultaneously with an explicit row. Consequently every odd O retains at least two original a-edges in **ineligible** components. If an odd O exists, at least one such component exists. This does not force one component to carry all odd-cycle obligations. Eligibility is row-dependent and directed, and the zero-port/cycle-only assumption must not be omitted from the weight decomposition.

To obtain a size-eight compatible difference, first choose an eight-cycle component C_j of a real permitted row and test the target that flips all other components. A passing K test constructs exactly the desired repaired row, including the four residual occurrences and the original boundary. Existence of C_j, concentration of its weights, and success of the target test have **not** been established from full exact support. A retained difference consisting of one C16 still supplies no C8 merely by this construction.

## Fixed certificates and reproduction

Run `python3 check_bf_four_completion.py`. It checks only explicit incidence certificates and traces their residual paths; it does not search for perfect matchings, covers or graphs.

The single supplied cube row gives both main scope checks: flipping both squares passes with two even K four-cycles and 36 completions despite nonuniform residual colours; flipping just the top gives two length-three paths with incompatible original endpoint pins, yet the separate explicitly supplied unpinned completion is valid.

The supplied six-vertex two-pole gives a boundary-bearing positive test. Flipping its four-cycle produces a seven-edge K path, including both semiedges, with equal cf endpoint pins. Its unique constructed completion preserves both port labels slot by slot. This witness has a four-cycle and two ports; neither it nor the cube is claimed to have exact-XII full support or minimum-host geometry.

The existing frozen G20 certificate supplies the negative method check. Switching one C8 produces two odd closed K pentagons and hence an unconditional failure, agreeing with the pulse-3 zero-defect capacity obstruction. Its BF cover and cyclic two-cut are retained in every statement of scope. No additional graph family or parameter was explored.

`bf-pulse4-completion-certificate.json` contains the K paths, endpoint pins, failure kinds and constructed row labels. The only earlier reproduction dependency is `bf-pulse3-distance-certificate.json`, read without modification. The generic constructor checks each output vertex's complete six-slot partition and every boundary label.

## Review and correction record

The fresh-context same-model reviewer independently proved the uniform fixed-outside iff and K fixed-singleton criterion. It supplied and directly checked the cube's alternative row independently, then checked the main draft, constructor and JSON and independently validated the two-pole's exact seven-edge port path and new incidences. Review records are `audit-pulse4/completion-independent-review.md`, `cube-fixed-witness-check.json` and `two-pole-independent-check.json`.

During final self-review the primary agent sharpened a failure-scope sentence: an odd K cycle excludes **all** completions, whereas a path-pin mismatch alone only excludes the pinned class. The independent reviewer confirmed this correction and the fully free singleton-variable reduction. The earlier draft is not being presented as a correct unrestricted failure theorem. There are no human or external-model acceptance or novelty claims. The final text acceptance is recorded separately before freezing.

This derivation extends the local repeated-mask complementary-pair criterion explicitly recorded in original Note 230 to targets with retained difference edges. The note was read; its earlier deficient-core/barrier premises and the upstream host chain were not re-proved. Its prior existence is acknowledged, and this candidate is not marketed as a new general edge-colouring theorem.

## Remaining boundary and next mathematical task

Full exact-XII support records all actual boundary types. It might impose further internal constraints; this pulse does not prove that it fails to force the new condition. No actual full exact-XII/minimum-host instance violating the criterion is supplied. The cube and two-pole establish only local completion-scope distinctions. The target of this pulse was an explicit sufficient condition, and that target is complete.

The next bounded question can use the exact singleton-variable reduction: for a chosen real permitted row and target component, derive the path-pair constraints on retained difference edges from its actual graph and boundary, then seek an analytic satisfying assignment or an invariant obstruction using the full support and true host cuts. If the original-pins test fails only by path mismatch, recolouring retained singleton edges is the unresolved repair freedom. If an odd K cycle appears, that target pair is genuinely impossible and must be changed. Neither situation warrants expanding enumeration to replace the upstream argument.

All previous configuration gaps remain: the general perfectly-matchable F branch, the three barrier profiles, existence of a compatible size-eight difference, the zero-versus-two port split, carrier tightness and residual exterior profile. The conditional 818-certificate branch exclusion remains conditional. No statement solves the main conjecture.

Release selection, contributor order, licence, external verification and prior-art assessment are reserved to the parent's user-designated contribution task. The new candidate and its source/JSON/reproduction dependency receive their own manifest; earlier packets are not replaced. No publication, upload, key, DOI, paid service, other-line action or Git operation occurred.

## Closure checkpoint

Startup comparison found all 1,782 original-unit size/mtime entries unchanged from pulse 3 and all 21 items in the pulse-2/3 frozen manifests unchanged. The final comparison, `bf-pulse4-final-file-check.json`, again records all 1,782 entries unchanged after approximately 1,410 seconds and all 21 frozen hashes unchanged. Metadata stability is not a content-hash audit of the original unit.

Final text and program-scope review passed in `audit-pulse4/final-packet-acceptance.md`; the reviewer has stopped. It confirms the pinned iff, uniform fixed-outside iff, free singleton reduction, universal odd-K obstruction versus scoped path-pin failure, and the explicitly unproved forcing boundary. The wording “this pulse does not prove ... force” was used to avoid implying that no future forcing theorem could hold. This is same-model acceptance within the stated scope, not human or external-model acceptance.