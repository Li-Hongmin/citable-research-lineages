> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Independent analytic review of the C8 free-completion phase criterion

2026-10-03. Fresh-context review within the same model family; this is not human review or external-model acceptance. Only this new audit file is written. No new graph, matching, cover or phase-assignment enumeration, SAT, HPC, Git, paid service, publication or other research line is used.

## Verdict and assumptions

The proposed GF(2) phase criterion, its forest iff, its h=2 virtual-chord extension, the stated port-parity tests, and the conditional host attachment bounds are correct. The stronger necessary condition subsequently proposed by the parent is also correct: under the applicable 519 all-odd gate, every successful repair must use all three directions, and its real/virtual crossing graph must contain a cycle. In that setting a forest target is impossible. The proof below derives these statements independently from the vertex partition rule, rather than accepting a numbered note. Draft acceptance is still pending a read of the finished parent draft.

Let Z be a finite loopless cubic multipole with six boundary semiedges and a genuine six-occurrence double-cover row. Its occurrences a,b use no semiedge. Switch a on every unwanted internal component of its symmetric difference with b, obtaining actual zero-port matchings P,Q_b with P symmetric-difference Q_b equal to a single C8. The four remaining occurrence slots are I={c,d,e,f}; their singleton labels on C8 are now free, while their six boundary masks are held slot by slot fixed. Define

    m(e)=2−1_P(e)−1_Q_b(e).

All edge lengths below count a boundary semiedge as one edge, by attaching an auxiliary leaf to it. Let K consist of the m=2 edges. At a C8 vertex K has degree one, and at every other internal vertex it has degree two. Every boundary leaf has degree one. Thus K has paths and closed cycles. Its only internal leaves are the eight C8 vertices. The m=1 edges are exactly the eight C8 edges. Every other proper edge has m=0 or 2. On m=0 edges there is no I colour; on an m=2 edge there is an unordered I-pair. At a K-degree-two vertex the two pairs must be complementary in I.

In particular an odd closed K component rules out every four-occurrence completion of this fixed target pair, even if singleton colours and boundary masks are freed. An even closed K component can always be labelled by choosing a pair and alternating it with its complement. The assertions below always include the absence of odd closed K components.

## The no-C-to-port case: exact phase equations

Assume no K path joins a C8 vertex to a port. The eight C leaves are then paired by exactly four K paths, and the six port leaves by exactly three K paths. Components with no leaves are closed K cycles and are not part of these counts. For each port-to-port path of L edges, with its fixed endpoint pairs A,B, the necessary and sufficient condition is

    B=κ^(L−1)(A),    κ(A)=I\A.

Thus equal pins require odd L and complementary pins require even L. Pins that are neither equal nor complementary are incompatible for either parity. This test concerns the actual boundary masks and does not use any original singleton label.

Write the C8 vertices as v_0,...,v_7 cyclically, and let t_i be the singleton on edge v_i v_(i+1), with subscripts modulo eight. Identify the four named colours I bijectively with V=F_2^2. Write addition in V as +. Set

    σ_i=t_(i−1)+t_i.

The vertex rule is exactly σ_i≠0: the two incident singleton colours must differ. For nonzero σ define φ_σ(u)=det(σ,u). This is a nonzero linear functional with kernel {0,σ}. The unordered pair {t_(i−1),t_i} is the affine line φ_(σ_i)(u)=φ_(σ_i)(t_(i−1)). Its complementary pair, which labels the K leg at v_i, is the other parallel line

    φ_(σ_i)(u)=φ_(σ_i)(t_(i−1))+1.                 (1)

The +1 is literal because each level of this nonzero functional has two elements.

For an internal K path r joining v_i to v_j, complement propagation preserves the direction of its pair. Consequently σ_i=σ_j=:σ_r. If its length is L_r, put ε_r=(L_r−1) mod 2. Comparing the two levels in (1), the two +1 terms cancel, and the path relation is exactly

    det(σ_r,t_(i−1)+t_(j−1))=ε_r.                (2)

There is no additional parity or orientation sign in (2). For L=1 it requires equal endpoint pairs; for L=2 it requires complementary pairs.

The four pairs of endpoints make an abstract chord matching on the eight cyclic vertices. Its crossing graph X has one vertex for each path r, with r adjacent to s exactly when their endpoint pairs interlace. No planar embedding of the actual paths is assumed. Choose i<j for path r. Since t_(j−1)+t_(i−1)=Σ_(k=i)^(j−1) σ_k, a second path s contributes its σ_s once if it crosses r, and contributes zero or twice otherwise. The endpoint i of r contributes σ_r, whose determinant with itself is zero. Hence (2) becomes

    ε_r=Σ_(s adjacent to r) det(σ_r,σ_s),
    σ_r∈V\{0}.                                 (3)

Both determinant and the sum are over F_2. The three nonzero vectors of F_2^2 have determinant one with each other and zero with themselves. Thus (3) says that, at each chord r, ε_r is the parity of the number of its neighbours given a different one of the three directions.

Closure of the singleton labels introduces no extra equation: each σ_r occurs at exactly two C8 vertices, so Σ_(i=0)^7 σ_i=0 automatically. Conversely, given any solution of (3), choose any τ∈V and set

    t_7=τ,
    t_i=τ+Σ_(k=0)^i σ_k  for i=0,...,6.

The zero total sum gives the required relation at v_7 too. All eight σ_i are nonzero, so adjacent singleton colours differ. Put the complementary singleton-pair (1) on every C leg and alternate complements down each internal K path. Equation (3) guarantees the far-end pair. Independently label each compatible port path and each even closed K cycle by complement propagation. Every internal vertex now meets each I colour exactly once, so each named I colour is an actual perfect-matching occurrence. Adding P,Q_b gives load two on every proper edge and semiedge, and the boundary masks agree slot by slot with the original row.

This proves the exact iff: a free completion in the no-C-to-port class exists if and only if all closed K cycles are even, all three fixed port paths are compatible, and (3) admits nonzero directions. It gives a constructor from a direction assignment, not a claim that the assignment always exists. It does not use matching search. For fixed directions, the four choices of τ are allowed because no C path reaches a boundary pin. If K has z closed components, their 6^z pair choices are independent.

## Two directions and the forest iff

Take distinct nonzero u,v and write σ_r=u+x_r(u+v), x_r∈F_2. Then

    det(σ_r,σ_s)=x_r+x_s,

so (3) reduces to L_X x=ε, where the F_2 Laplacian has diagonal deg_X(r) mod 2 and off-diagonal entry one for each edge of X. A solution of this binary system is sufficient for a three-direction completion. A componentwise parity condition is necessary even for three directions: summing (3) over a connected component counts each symmetric determinant twice, hence

    Σ_(r in component) ε_r=0.                    (4)

If X is a forest, (4) is sufficient. Root each nontrivial tree. For an edge e joining a vertex to its parent, let λ_e be the sum of ε over the subtree below that vertex. Then Σ_(e incident to r) λ_e=ε_r at every nonroot vertex; the root identity follows from (4). Fix a root bit, and set the child bit equal to the parent bit plus λ_e. This gives x_r+x_s=λ_rs on every edge and therefore L_X x=ε. At an isolated vertex (4) is simply ε_r=0. This proves the forest iff by a construction, with no case enumeration.

The forest hypothesis is essential to this proof. Componentwise even ε is necessary on every crossing graph, but is not asserted here to be sufficient on every crossing graph. On a graph with cycles, testing only the binary Laplacian is also not a necessary condition for the three-direction system. For example, on an abstract four-cycle X with vertices 0,1,2,3, take σ=(u,v,w,u), with u,v,w the three distinct directions. Then the heterochromatic-edge pattern is (1,1,1,0), giving ε=(1,0,0,1). The binary Laplacian of C4 instead forces ε_0=ε_2 and ε_1=ε_3, so it has no solution for this ε. C4 is itself a circle graph: the cyclic endpoint word 0,1,3,0,2,3,1,2 realizes exactly its four crossing edges. This is an analytic warning against promoting the binary sufficient test to a general iff, rather than a new witness search.

An isolated actual internal chord r with even L_r has ε_r=1 but zero right side in (3). It is an obstruction to every free completion of this target pair in this K geometry. Changing the six port pins cannot repair this internal equation in the no-C-to-port case. This is stronger than a failure of the original pinned-singleton test, but is not a statement that the entire graph or every possible target pair lacks a BF row.

## Fixed prism port signature

For the specified genuine prism row, take

    A={c,d}, B={e,f}=κ(A),
    C={d,f}, D={c,e}=κ(C),

with boundary multiset (A,A,A,B,C,D). The A/B direction and C/D direction are distinct. With no C-to-port path, the C and D ports must pair with each other and their K path must have even length. The remaining three A ports and one B port must pair as one A–B path of even length and one A–A path of odd length. These are both necessity and sufficiency for the three port paths.

A port path joining the two direction classes has no free completion with these same slotwise boundary masks, whatever happens to singleton colours on C8. This is a fixed-interface obstruction. Altering the interface or exterior may change these pins; no repair by such a change is proved, and this port obstruction must not be described as the boundary-independent odd-K obstruction.

## h=2: two C-to-port paths and a virtual fourth chord

Suppose exactly two C-to-port K paths occur. Their C endpoints are v_i,v_j, their port pins are B_p,B_q, and their edge lengths, including semiedges, are L_p,L_q. The other six C endpoints are paired by three internal paths; the other four port leaves are paired by two port-to-port paths. Closed K components remain independent.

Complement propagation forces the C-end pairs

    A_i=κ^(L_p−1)(B_p),
    A_j=κ^(L_q−1)(B_q).                          (5)

The σ values at the six other endpoints come in three equal pairs. Singleton closure on C8 thus forces σ_i+σ_j=0. Therefore the two transported pins, and hence B_p,B_q, must have the same nonzero direction. In V a pair determines its direction by summing its two elements, and two pairs have the same direction exactly when they are equal or complementary. If B_p,B_q are neither, this h=2 geometry has no completion with those masks.

Assume they are in one direction class, and define θ=0 if B_p=B_q and θ=1 if B_q=κ(B_p). Insert a virtual fourth chord r_0 between v_i,v_j. Set

    σ_0=dir(B_p)=dir(B_q),
    ε_0=θ+L_p+L_q mod 2.                        (6)

The actual exponent comparing A_i to A_j in (5) is θ+(L_p−1)+(L_q−1)=θ+L_p+L_q, proving the sign and the two semiedge corrections in (6). Give each of the three real chords its usual ε_r=L_r−1 mod 2. Form the crossing graph of these four chords. The same derivation yields (3), now including the virtual equation r_0, with the extra condition that σ_0 is the fixed direction in (6). The virtual equation says precisely that the two C-end pairs have the relative complementary phase required by (5).

It remains to meet an absolute pin, not merely this relative phase. A global translation τ of all t_i changes the level of their incident pair by det(σ_0,τ). This is a nonzero one-bit functional. Exactly two τ choices make the K pair at v_i equal to A_i. The virtual equation then automatically makes the K pair at v_j equal to A_j. Alternating complements along the two real C-to-port paths gives their prescribed port pins. The other port paths must separately pass their fixed-pin tests, and all closed K cycles must be even, as before.

Equivalently, it is enough that the unconstrained three-direction system (3) have a solution: every invertible linear map of F_2^2 has determinant one, and one can take the nonzero direction at r_0 to the required σ_0 by such a map. This preserves (3). The subsequent translation fixes the absolute pair level. Conversely any completion produces such a constrained solution. Thus this virtual-chord reduction is an exact h=2 iff, with its port and closed-cycle conditions included.

For a forest X, (4) remains the exact criterion for the direction equations, even with the virtual direction prescribed. Use two directions u=σ_0 and any other nonzero v. The tree construction fixes bits up to a simultaneous flip in each connected component. Flip the component containing r_0 if necessary to make x_0=0; all equations remain unchanged. The other components can be constructed independently. Here an isolated virtual chord with ε_0=1 is a fixed-port obstruction, whereas an isolated real even-length chord is an internal obstruction. These scopes must be distinguished.

## Why the stated full-support branch has h=0 or h=2

This paragraph is conditional on the already audited 519 all-odd gate in its fixed-prism/full-exact-XII setting. It does not re-prove the full-support premise or assume it in a general multipole. If a completion preserves the permitted whole-shore boundary, the gate gives an odd closed component in each of Z−P and Z−Q_b.

The necessary two-edge defect bound is elementary. For an odd cycle O of length 2k+1 avoiding Q_b, its total double-cover demand is 4k+2. Each of the other four occurrences uses at most k cycle edges, so P must use at least two edges of O. Interchanging P,Q_b gives the other bound. Away from C8 the two matchings agree, so these opposite-matching edges lie on C8.

A closed complementary component meeting C8 cannot use a C-to-port K path: after such a leg the degree-two complement path reaches a boundary semiedge, so that component is open. Odd closed K components disjoint from C8 cannot occur in a completed row. Hence an odd component of either matching complement uses at least two alternating edges, and at least four C vertices, among the 8−h internally paired C leaves. The number h is even because the remaining C leaves pair internally. Consequently h≤4. If h=4, the same four remaining vertices would have to contain two P edges and two Q_b edges. The two P edges already cover all four vertices, as do the two Q_b edges. Their union would be a degree-two four-vertex component of the single C8, impossible. Therefore h=0 or 2. This independently justifies the branch count; it does not force the zero branch or guarantee any successful completion.

## Conditional host cut bounds

In the no-C-to-port case let B be the vertex set consisting of C8 and the interiors of its four internal K paths. Do not add the vertex sets of closed K cycles. Additional common-matching edges with both endpoints in B are allowed. Write N=P∩Q_b. Every C8 vertex has all three incident edges in B. At an internal vertex of one of the four paths, the third edge belongs to N. Thus the actual host cut δ(B) consists exactly of N edges leaving B, and every cut edge has a distinct endpoint among the path interiors.

When a completion succeeds, any of the four I matchings has no cut edge, because all cut edges have residual demand zero. It therefore matches B internally and |B| is even. Equivalently, summing (3) gives Σ_r ε_r=0 and

    |B|=8+Σ_r(L_r−1)≡0 mod 2.

The cubic cut identity gives |δ(B)|≡|B| mod 2, so |δ(B)| is even. If this is the actual cut in the specified cyclically five-edge-connected host and the complement of B contains a cycle, the cut is cyclic: B contains C8 and the other shore contains the exterior prism/cap cycle. Its size is at least five and hence at least six. Since each path-interior vertex has at most one cut edge,

    6≤|δ(B)|≤Σ_r(L_r−1)=|B|−8,

giving |B|≥14. This establishes the stated lower bounds without accepting the proof by number. The cyclic-host and opposite-cycle hypotheses cannot be omitted. Global minimum is upstream justification of the applicable host setting; the cut inequality itself uses cyclic five-connectivity. These bounds do not force equality, h=0, a forest crossing graph, a particular path-length pattern or the desired exterior profile.

For h=2, the corresponding B excludes both C-to-port path interiors. Its cut consists of common-matching edges plus the first edge of each of the two C-to-port paths. If it is an actual cyclic host cut, five-connectivity gives at least three common-matching attachments and |B|≥11. There is no claim here that this cut is necessarily even.

The virtual phase sharpens this h=2 count. Let C_B be the common-matching cut edges. The two remaining cut edges are the C-to-port K legs, used by neither P nor Q_b. The size formula and the sum of the four direction equations give

    |B|=8+Σ_(three real r)(L_r−1),
    |B| mod 2=Σ_(real r) ε_r=ε_0.

Perfect-matching parity for P on B gives |C_B|≡|B|≡ε_0 mod 2. Equivalently, cubic cut parity applied to |δ(B)|=|C_B|+2 gives the same result. Cyclic five-connectivity still requires |C_B|+2≥5. Therefore ε_0=0 forces |C_B|≥4 and |B|≥12, while ε_0=1 gives |C_B|≥3 and |B|≥11. The latter size bounds use |C_B|≤|B|−8, since all common cut endpoints are internal to the three real C-to-C paths. In particular tight (|B|,|C_B|)=(11,3) requires virtual ε_0=1. These remain conditional lower bounds, not a proof of tightness or existence.

## A two-direction completion makes both zero-port complements all-even

This is a stronger obstruction supplied during the review and independently verified here. It applies to either h=0 or h=2. Suppose a successful direction assignment uses at most two of the three nonzero vectors. Choose distinct nonzero u,v containing its used directions, set w=u+v, and let ℓ(t)=det(w,t). Then ℓ(u)=ℓ(v)=1. Consequently ℓ(t_i) flips at each step around C8. The residual singleton labels on the four P edges are all in one two-element fibre J_P of ℓ, while those on the four Q_b edges are all in its other fibre J_Q. A translation τ changes at most which fibre is named J_P; it does not change this assertion.

Every real C-to-C K path has direction u or v. Because ℓ evaluates to one on that direction, every pair on every edge of that path contains one colour from each of J_P,J_Q. Its complementary pair has this same property, so it survives propagation along the entire path. The same assertion holds for either C-to-port path in h=2, since its endpoint direction is among the two used directions. The virtual direction is an actual C endpoint direction and is therefore included in this hypothesis.

Consider a closed component O of Z−Q_b that meets C8. Its C8 edges are P edges. It cannot enter a C-to-port path, since the degree-two complementary component would then reach a boundary semiedge and be open. Hence all its other edges lie on the internal C-to-C K paths. Every edge of O has exactly one residual colour in J_P. At a C vertex the P edge and the K edge have distinct J_P colours, because the vertex partition contains each residual slot exactly once. At any internal K vertex its two complementary edge pairs also give distinct J_P colours. Thus the two named colours of J_P give a proper alternating two-edge-colouring of O. Therefore O is even.

The identical argument on Z−P uses its Q_b edges and the two J_Q colours, making every closed component meeting C8 even. Any closed component of either complement disjoint from C8 is a closed K component, already even in every successful completion. Components involving ports are open and make no additional closed cycle. Thus both Z−P and Z−Q_b have no odd closed component.

This proof concerns the two directions used at C8; an even closed K cycle elsewhere may use the third direction without affecting it. Likewise a separate port-to-port path can have any pin direction allowed by its fixed-parity test. Neither supplies an odd closed complementary component.

Under the fixed-prism/full-exact-XII hypotheses of the audited 519 gate, a successful boundary-preserving repair is another genuine permitted row. Each of its zero-port matchings must have an odd closed complementary component. The preceding all-even conclusion is a contradiction. Therefore a successful phase assignment must use all three C8 directions.

If X is a forest, there are now two possibilities. If some component has odd ε sum, no three-direction assignment exists. If every component has even ε sum, the proven forest construction gives a two-direction assignment. When the independent closed-K and port-path tests pass, this assignment constructs a boundary-preserving row with both complements all-even, contradicting 519. If an independent test fails, no completion exists already. Hence every forest target is impossible in the stated all-odd/full-support setting, and any successful h=0 or h=2 repair must have a cyclic crossing graph. This is a proved necessary condition in that setting, not a general ban on forest completions in cubic multipoles.

As a direct consistency check, for the four opposite chords (0,4),(1,5),(2,6),(3,7), X=K4. With ε=(0,1,0,1), the direction assignment (u,v,u,w), where u,v,w are the three distinct directions, satisfies all four equations: a u vertex sees two unequal neighbours, and each of the v,w vertices sees three. This confirms only consistency of the necessary cycle/three-direction condition with the stated canonical path pattern. It is not an actual full-exact-XII host witness or a forcing argument.

## Review boundary

The phase theorem is exact for the stated chosen target and K geometry, with h=0 or h=2 handled as above. The forest theorem converts only the direction subsystem into the explicit componentwise-even test. Even closed K components and compatible fixed port paths are additional conditions. General crossing graphs retain the actual three-direction feasibility obligation.

No actual full-exact-XII/global-minimum-host witness is supplied or constructed. This review proves the conditional necessary cyclic-X/three-direction requirement using the applicable 519 gate. It does not claim that full support forces a successful phase assignment, that full support fails to force one, that a permitted C8 row exists, or that configuration tightness follows. The parent draft and any constructor/certificate still require a final read before packet acceptance. The original notes 523 and 525 were read only at the specific paths supplied by the parent; 519 is cited only under the already audited conditions reported in pulse 2.
