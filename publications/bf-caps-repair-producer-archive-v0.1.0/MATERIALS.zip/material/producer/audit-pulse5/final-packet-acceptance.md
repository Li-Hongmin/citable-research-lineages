> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Pulse-5 final mathematical and fixed-certificate acceptance

2026-10-03. This is a fresh-context review in the same model family. It is not human review, an external-model opinion, novelty clearance or publication acceptance.

## Material read

- `bf-pulse5-c8-phase-completion.md`, including its corrected real/virtual isolated-chord sentence.
- `check_bf_c8_phases.py` and the resulting `bf-pulse5-phase-certificate.json`.
- `bf-pulse5-certificate-correction.md`.
- `bf-pulse5-handover.md`, including its remaining-question and closure-checkpoint scopes.
- The specific original notes 523 and 525, read only. The all-odd gate 519 remains a conditional reference to its pulse-2 audit, not a newly re-proved source premise.

The analytic derivation and scope audit are in `audit-pulse5/completion-review.md`.

## Acceptance

The packet passes within its explicit scope. In particular:

1. The h=0 direction equations use ε=L−1 correctly. Affine pair levels, their complements, singleton closure, and chord interlacing give the exact necessary-and-sufficient free-completion reduction, with even closed K components and the fixed port-path tests included.
2. For h=2, the forced virtual sign is θ+L_p+L_q. The equal/complement port-direction condition is necessary; a determinant-preserving linear map normalises the virtual direction, and exactly two translations meet its absolute pin. The independent remaining port paths must still pass their fixed-pin tests.
3. The binary F_2 Laplacian test is generally sufficient. It becomes an exact three-direction criterion on forests precisely when every connected component has even ε sum. The statement distinguishes an isolated real even-length chord's internal obstruction from an isolated virtual chord's fixed-interface obstruction.
4. Every completion using at most two C8 directions makes both zero-port complementary closed-cycle systems all-even. Therefore, under the stated all-odd hypothesis supplied in the audited fixed-prism/full-exact-XII branch, successful h=0 or h=2 repairs require all three directions and a crossing graph with a cycle. This is a necessary condition; three directions or a cycle alone is not claimed sufficient.
5. The capacity argument excludes h≥4 under the two odd-complement requirements. The prism port class and parity table are correct and are scoped to the fixed slotwise interface.
6. The host bounds use an actual cyclic cut with cycles on both shores. The h=0 bounds are six common attachments and fourteen internal vertices. For h=2 the virtual sign determines common-cut parity: ε_0=0 gives at least four common attachments/twelve vertices, while ε_0=1 gives at least three/eleven. These are lower bounds, with no forced tightness claim.
7. The fourteen-vertex carrier has six common ab semiedges, so a,b are not zero-port on that carrier. Its role is an internal phase/row certificate, not a whole zero-port Z or exact-XII/global-minimum host witness. The corrected complementary cycle lengths are (7,7) on both sides.

## Independent fixed verification

The reviewer loaded the script with `runpy.run_path`, invoked only its fixed functions, and compared their returned phases and labels to the existing JSON. This did not invoke `main` and did not write or overwrite the parent's certificate. The following passed:

- Constructive forest solution for the one supplied chord diagram and sign vector.
- Its direct affine endpoint-pair relations and the h=2 transport with port pins cd/cd and lengths 1,2, including semiedges.
- The supplied isolated-component obstruction.
- Every vertex's complete six-slot partition in the given carrier, its fourteen internal vertices and six ab ports.
- Direct complementary-component tracing giving `a: [7,7]` and `b: [7,7]`.
- Agreement between the returned fixed phases/row labels and the recorded JSON.

The correction record truthfully preserves the initial mistaken expected (5,9) assertion. The revised (7,7) expectation is independently supported by the supplied paths and labels; no phase or incidence change was needed.

The subsequent handover was read after the first acceptance text was written. It correctly preserves the ab-port carrier limitation, the recorded (5,9) to (7,7) correction, the fixed-prism/full-support conditions on the forest obstruction, and the lower-bound-only host-cut claims. It leaves upstream row existence and cyclic-target completion unresolved. This handover read requires no further mathematics or verifier changes.

These are fixed checks, not graph, matching, BF-cover or direction-assignment enumeration. The universal claims are supported by the analytic proofs, not extrapolated from these examples.

## Limits and stop state

No actual full-exact-XII/global-minimum-host witness has been supplied. Existence of an allowed target C8, existence of a successful cyclic three-direction assignment under the full support conditions, and the later exterior configuration-forcing steps remain unresolved. The packet does not assert that full support forces or fails to force a successful phase assignment. It does prove its explicitly conditional forest obstruction.

No remaining mathematical or code-scope correction blocks this local packet acceptance. Only new files in `audit-pulse5` were written by the reviewer. Original research files and parent deliverables were read only; no Git, HPC, SAT, enumeration, paid action, publication or unrelated research was performed. Review is now stopped.
