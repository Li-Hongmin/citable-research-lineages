> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Four-occurrence completion after internal component switches

Version 1, 2026-10-03. This additional candidate preserves all earlier packets. The result gives an explicit sufficient condition for maintaining BF compatibility in a genuine allowed row, with an exact criterion in a stated class of residual completions. It neither proves general exact-Case-XII configuration forcing nor resolves the Berge–Fulkerson conjecture. No novelty claim is made.

## Objects and the completion question

Let Z be a finite loopless cubic graph or cubic multipole. A perfect-matching occurrence covers each internal vertex exactly once; a boundary semiedge need not belong to every occurrence. Fix a genuine six-occurrence double-cover row

    (Q_a,Q_b,R_c,R_d,R_e,R_f),  I={c,d,e,f}.

Every proper edge and every semiedge has load two. Its label is the unordered pair of occurrence slots using it; at every internal vertex the three labels partition {a,b,c,d,e,f}. Slots may represent equal underlying matchings.

Assume Q_a and Q_b use no boundary semiedge of Z. Then D=Q_a symmetric-difference Q_b consists entirely of disjoint internal alternating cycles. Choose a union S of these components and switch only a, obtaining

    P=(Q_a minus E(S)) union (Q_b intersection E(S)).

P is an actual zero-port matching. The question is whether P,Q_b can be completed by four occurrences with the **same boundary masks slot by slot** as the original row. If Z is a subshore of a larger BF-colourable shore L, retaining these masks allows the constructed row to glue to the original exterior of L. The row's entire L-boundary state is then unchanged, including any permitted Case-XII state. This concerns rows of a colourable shore, not a cover of a hypothesized counterexample host.

## An exact constructive criterion with fixed single-colour edges

Define residual demand on each proper edge or semiedge by

    m(e)=2−1_P(e)−1_Qb(e),   m(e) in {0,1,2}.

We seek a completion in the following class: keep the original residual colour on every edge with m=1, keep the original residual colour pair on every boundary semiedge, and allow proper m=2 edges to change their residual colours. This fixes less than all labels outside S, but more than boundary masks alone.

The m=1 edges are precisely the original a-only and b-only edges on the **retained** D components. Their original residual colours belong to I and are distinct at each vertex incident with two such edges. Since both target occurrences are zero-port, every semiedge has m=2.

Form K from the m=2 edges. Extend each boundary semiedge to its own auxiliary degree-one vertex, so that it counts as one edge of K. At an internal vertex where P,Q_b agree, their common edge has m=0 and the other two have m=2, giving K-degree two. At a vertex where they differ, their two used edges have m=1 and the third has m=2, giving K-degree one. Thus K consists of paths and closed cycles. Parallel proper edges, if present, are distinct edges; a two-edge cycle is even. No loops are allowed.

At an internal degree-one endpoint v, let x_v,y_v be the fixed colours on its two m=1 edges and pin its incident K-edge label to

    A_v=I minus {x_v,y_v}.

At an auxiliary boundary endpoint, pin the K-edge label to that semiedge's original I-pair. Every pin is a two-element subset of I. Let kappa(A)=I minus A, the complement involution on these six subsets.

**Theorem 1.** A four-occurrence completion in this fixed-single-colour, fixed-boundary class exists if and only if:

1. Every closed K component has even length.
2. Every K path with L edges and endpoint pins A,B satisfies B=kappa^(L−1)(A).

L includes boundary semiedges. In particular L=1 requires equal pins, L=2 complementary pins, and L=3 equal pins. If the conditions hold and K has z closed cycles, the number of labelled residual completions in this class is exactly 6^z. The four slots remain named c,d,e,f; the count does not identify them under permutation.

**Proof.** In any completion, an m=2 edge carries a two-element subset of I, an m=1 edge carries its fixed singleton, and an m=0 edge carries no I colour. At a K-degree-two vertex its two incident pairs must partition I, so they are complementary. At a K-degree-one internal vertex its two fixed singletons force the stated remaining pair. Boundary masks force the auxiliary-leaf pins. Complement propagation yields the path equation. A cycle of length L requires A=kappa^L(A); no two-element set is equal to its complement, so L must be even.

Conversely, on each path start with its first pin and alternate a set and its complement on successive edges. The path equation gives its last pin. On each even cycle choose any of the six pairs on one specified edge and alternate complements around the cycle. Together with the fixed m=1 labels and empty m=0 labels, every internal vertex has each I colour exactly once. Edges bearing a given colour define an actual perfect-matching occurrence. Adding P,Q_b gives load two on every edge and semiedge. The boundary masks agree individually with the original row. Each pinned path has a unique labelling; each even cycle has six choices, independently. This proves both assertions. No search for matchings or covers is involved.

**Scope of a failure certificate.** An odd closed K cycle excludes **every** four-occurrence completion of the target pair: its vertices have no m=1 incidences, so pair alternation cannot be changed by freeing singleton labels elsewhere. Incompatible path pins, by themselves, exclude only the specified pinned class; a completion may exist if retained m=1 colours also change. Success constructs four genuine occurrences and certifies compatibility with the fixed boundary. For nonzero-port a or b, boundary demand may be zero or one; the all-two-colour boundary formulation must be changed and is not claimed here.

**Corollary (eliminating the double-loaded paths without fixing singleton colours).** The fully free four-occurrence completion problem with only the boundary masks fixed has the following exact reduction. Choose a colour t_e in I for every m=1 edge, with the two such colours distinct at each retained-D vertex. Pin that vertex's K-edge pair to I minus {t_e,t_f}; keep the original port pins. A free completion exists if and only if K has no odd closed component and there exists a choice of these edge colours satisfying all the path equations in Theorem 1. Necessity extracts the singleton colours from any completed row. Sufficiency alternates the prescribed pairs along K as in the proof above and uses the chosen singleton labels. This reduces the unknowns to retained-D edges and their path constraints; it does not assert the existence of a satisfying assignment or replace it by the odd-cycle weights. No assignments are searched in this packet.

## A simpler local sufficient condition and its exact boundary

On a component C of D an a-only edge has label {a,y} and a b-only edge has label {b,x}, with x,y in I. At an endpoint x differs from y and the third edge carries I minus {x,y}.

Call C eligible, in the direction a-to-b, when all its b-only edges have the same residual colour h in I.

**Theorem 2.** Every union of eligible components can be removed from D while retaining b and the row's complete boundary. An explicit completion exchanges a and h on each selected component. Moreover, if every I-colour incidence outside the union is required to remain fixed, such a completion exists if and only if every selected component is eligible in the original row.

**Proof of sufficiency.** On an eligible C, h occurs on every b-only edge. It is absent from every a-only edge, since adjacent labels are disjoint. Hence C is an a,h alternating cycle. Exchanging these two slot colours gives

    Q_a'=(Q_a minus E(C)) union (Q_b intersection E(C)),
    R_h'=(R_h minus E(C)) union (Q_a intersection E(C)).

Q_b and the other three residual occurrences are unchanged. Each affected vertex retains exactly one incidence of a and of h; every edge retains two distinct colours. C has no boundary edge. Vertex-disjoint components can be treated simultaneously even if they use different h's, or the same h. Every label outside the selected components is unchanged.

**Proof of necessity in the fixed-outside class.** After flipping C, its old b-only edges carry {a,b}, while its old a-only edges must carry two I colours. At a vertex the third incident edge's fixed label is I minus {x,y}, so the new I-pair on the old a-only edge must be {x,y}. On one such edge uv the original y is the same at both ends. Its new pair must equal both {x_u,y} and {x_v,y}; since x_u,x_v differ from y, equality forces x_u=x_v. Propagating around C makes all old b-only residual colours equal. The third edge of a D vertex lies outside the union of its D components, including when it joins vertices on two different selected components, so this argument applies component by component.

Theorem 1 permits more recolouring than this fixed-outside problem and is strictly broader. Eligibility is a property of a particular labelled row and a chosen direction, not merely of its support state or graph.

## Weighted odd-cycle consequences

For any odd closed cycle O avoiding Q_b, a compatible target P must satisfy |P intersection E(O)|>=2: if |O|=2r+1, the other four occurrences can cover at most 4r cycle-edge incidences, whereas double coverage requires 4r+2. This counts edges on O; chords and semiedges do not enlarge the capacity. It is not an assertion about odd open paths.

Write D's components as C_1,...,C_t and set w_i(O)=|Q_a intersection E(C_i) intersection E(O)|. Every Q_a edge on O belongs to D. After deleting a set of components S,

    |P intersection E(O)| = sum_(i not in S) w_i(O).

A success of Theorem 1 certifies all these inequalities by constructing an actual row. Theorem 2 gives a more direct corollary: if N denotes all initially ineligible components, simultaneously delete all eligible ones to obtain

    sum_(i in N) w_i(O) >= 2   for every such O.

Thus if a closed odd Q_b-complement cycle exists, at least one component is ineligible, and every such cycle has at least two Q_a edges in the ineligible components. This does not put all obligations into one component. If no odd cycle exists, all components can be eligible and all can be deleted. If D has boundary paths, the internal-switch theorem still holds but this cycle-only weight decomposition needs their retained contributions; the present zero-port assumption avoids that issue.

To keep just C_j, flip all other components and construct K. If Theorem 1's conditions hold, this is a genuine permitted row with difference exactly C_j. If C_j is an eight-cycle, this gives the desired difference-size-eight row **conditionally on the explicit successful criterion**. Neither the existence of such a C_j nor success of the criterion is forced here.

## Explicit witnesses for the scope distinctions

**Cube with no boundary.** Let T0...T3 and B0...B3 be two four-cycles, joined by T_i B_i. On each square, label edges 01,12,23,30 respectively ae,bc,af,bd; label the four verticals in index order cf,df,de,ce. Every vertex partitions the six colours, so this is a genuine BF row. Its a,b difference is the two squares; both have nonuniform b-edge residual colours c,d.

Flip a on both squares. Then P=Q_b and K is the union of the two even cycles T0–T1–B1–B0–T0 and T2–T3–B3–B2–T2. Theorem 1 supplies 36 labelled completions, despite neither component being eligible. This proves its greater scope over Theorem 2's fixed-outside criterion.

Flip only the top square. K has two length-three paths from B0 to B1 and B2 to B3. Their pins are cf/df and de/ce respectively. Both fail the required equality. Nevertheless there is a completion with the same a flip and b fixed if the retained bottom singleton colours can change:

    top 01,23: cd; top 12,30: ab;
    bottom 01,23: ac; bottom 12,30: bd;
    all verticals: ef.

These labels again partition all six colours at each vertex. This proves that a failed pinned test must not be reported as global BF incompatibility. The cube has girth four and no Case-XII boundary; it is a scope witness only.

**Positive witness with actual fixed boundary pins.** A six-vertex two-pole has internal vertices 0,1,2,3,r,s. Its proper edge labels are

    01:ae, 12:bc, 23:af, 30:bd, r2:de, 1s:df, s3:ce, rs:ab,

and it has one semiedge at 0 and one at r, both labelled cf. It is a genuine row with a,b zero-port. Flip a on the four-cycle 0–1–2–3–0. K is the single path

    port_0–0–1–s–3–2–r–port_r,

with seven edges including its semiedges, and equal pins cf at its endpoints. The criterion succeeds uniquely; along that path the new pairs are cf,de,cf,de,cf,de,cf. Its b-only residual colours originally were c,d, so it was ineligible for the fixed-outside exchange. This directly checks the semiedge convention and boundary-preserving construction. It has a four-cycle and only two ports; it is not an exact-XII/minimum-host example.

**G20 retained as a method counterexample.** Using the previous packet's explicitly supplied G20 row, flip a on one of its two difference eight-cycles. K includes the two odd pentagons of the switched block, so Theorem 1 fails. In this instance the independent odd-cycle defect bound already forbids every BF completion, since those cycles contain no P edge. G20 has a cyclic two-cut and a BF cover; it does not refute any full exact-XII or global-minimum assertion. No expanded search on it was performed.

## Reproduction and contribution limits

Run `python3 check_bf_four_completion.py` in the packet directory. It constructs the pinned residual row when the criterion passes and returns explicit failed cycles or endpoint pins when it does not. The fixed tests use only the supplied cube incidences, the supplied two-pole incidences and the frozen `bf-pulse3-distance-certificate.json`; there is no matching/cover enumeration. `bf-pulse4-completion-certificate.json` records component paths, pins and constructed labels. The counts arise from the analytic proof, not a count of searched solutions.

The full repeated-mask special case is the case P=Q_b: K is the complementary graph with its boundary pins. The earlier local project Note 230 already records its complementary-two-set criterion. Theorem 1 is the present derivation with retained-difference singleton pins; no claim of a new general edge-colouring discovery or prior-art clearance is made.

Fresh-context review is recorded in `audit-pulse4/completion-independent-review.md`. It is within the same model family, not human or external-model acceptance. No actual full exact-XII pole violating the condition is supplied. Conversely no implication from full exact support/minimum-host conditions to a successful target test has been proved. The construction establishes the promised sufficient condition in every genuine row satisfying its explicit assumptions, while the configuration-forcing step remains open.

Release selection, attribution, licence, external verification and novelty assessment belong to the separate parent-designated contribution task. No upload, publication, key or DOI was created here. The frozen manifest identifies this local candidate and its reproduction dependency without replacing previous versions.
