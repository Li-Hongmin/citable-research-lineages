> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# BF third bounded pulse: the configuration-forcing gap

2026-10-03. Original BF unit remained read-only; new material is confined to task-5. The first and second pulse reports, original errors, scripts and frozen public packet versions are preserved. No research expansion beyond one explicit 20-vertex certificate occurred.

## Outcome

We have not proved that general exact Case XII forces the configuration excluded by pulses 1–2. We identified the first missing existential step within the already fixed central-path-prism branch, proved a necessary BF pair-completion condition, and supplied a structural counterexample showing that ordinary matching minimization cannot fill that step without additional host/support hypotheses.

The self-contained new candidate is `bf-pulse3-defect-and-distance.md`. In an explicit two-Petersen graph G20, every perfect-matching complement contains odd cycles, the minimum positive difference size among arbitrary actual matching pairs is 8, and **every BF-compatible pair has difference size 16**. The graph has girth five and a cyclic two-cut. It already has a BF cover; it is neither a BF counterexample nor a complete exact-XII pole. Its role is to disprove an unrestricted method of reducing compatible pairs, not to disprove the intended minimum-host result.

For compatible occurrences P,Q and any odd cycle O avoiding Q, the necessary inequality |P intersection E(O)|>=2 follows from exact double coverage and the other four matchings' cycle capacities. If switching selected components of Q1 symmetric-difference Q2 deletes too many Q1 edges from any Q2-odd cycle, the resulting actual matching cannot cooccur with Q2 in **any** BF row. To retain just one difference component C_j, it is already necessary that C_j contain at least two Q1 edges on each Q2-odd cycle. This gives a concrete upstream obligation; it does not give sufficient completion.

## Start from the true quantifiers

The published minimum-host classification applies to every actual cyclic five-cut in a **global minimum** BF counterexample and describes each shore's support over **all** its BF colourings. A row of a BF-colourable shore L is not a six-cover of the counterexample host G. In particular any pair used to normalize a six-port subshore must come from a genuine BF row of L, with its permitted boundary state and its other four occurrences. Choosing arbitrary actual perfect matchings of the subshore changes this quantified object.

An arbitrary exact-support pole capped by the complementary pentagon need not give a global minimum counterexample. Minimizing that capped graph can discard the selected cut, fragment or row. Minimality within a family of exact-support poles is not a substitute for global minimality at nested cuts. These restrictions remain the same as in the second pulse.

There are earlier gaps if one starts with general exact XII rather than assumes the fixed prism branch. Note 167 expressly retains the perfectly-matchable branch of F=J−M: an all-terminal matching need not extend to an all-terminal BF row. Its Petersen-walk criterion couples the cycle labels across the matching edges. Consequently absence of all-terminal **BF support** does not prove F has no perfect matching. Note 169's barrier profiles are conditional on connected marked core, minimum-host inputs and deficiency two. Even in that branch it leaves one five-cut shore with one internal mark, one seven-cut shore with no internal marks, or two five-cut shores with no internal marks. It does not force the one-internal-mark profile, fixed tree, barrier size or cycle rank.

This pulse read those boundaries and their displayed arguments; it did not independently re-prove their entire historical dependency chain. They should be treated as conditional upstream entries, not newly accepted universal theorems.

## The smallest unresolved step in the fixed prism branch

Assume the exact-support central-path-prism setting audited in pulse 2. Note 519 forces each actual zero-port shore matching to have an odd closed complementary cycle. If a genuine permitted row has zero-port occurrences Q1,Q2, Note 522 gives

    |Q1 symmetric-difference Q2| >= 8.

At girth five, **if equality holds**, the difference is a single eight-cycle: alternating components are even, and girth five excludes components of length four. No upper bound, attainment, or minimization preserving BF compatibility is supplied by 522. It is not legitimate to change this lower bound into an existential statement that some permitted row attains equality.

The first missing statement among the listed D/port/tightness/profile steps is therefore:

    For the specified true minimum-host exact-support shore and permitted
    BF boundary rows, there exists a genuine row with two zero-port
    occurrences whose internal symmetric difference has size exactly 8.

This is stated conditionally on having reached the fixed prism branch and its relevant row interface; neither that branch nor availability of every desired row is claimed universal here. Any choice minimizing difference must minimize over **admissible cooccurring pairs**, not all actual zero-port matchings.

The distinction is strict in G20: admissible differences have size 16, while arbitrary matching differences can have size 8. A selected compatible pair with difference two eight-cycles can be shortened by switching an actual matching, but either single-component switch destroys cooccurrence. This makes the row-completion gap explicit. G20's cyclic two-cut is exactly why it does not settle whether full exact support and cyclic five-connectivity can prevent that obstruction.

Even a proof of equality would not finish the next steps. Note 523 permits **zero or two** difference-to-port paths; it does not force zero. Note 525 uses cyclic five-connectivity to give the zero-port lower bounds |C_B|>=6 and |B|>=14, not their equality. A classification under tight (14,6) hypotheses cannot force tightness. The residual (0,9,2) exterior with precisely two crosses remains a further configuration assumption. The finite 818-certificate branch exclusion must therefore remain conditional.

## Which steps require global minimum

| Interface | Hypothesis actually used | Present status |
|---|---|---|
| Odd-cycle defect inequality and selected internal component switching | Actual matching incidences and a genuine six-cover for compatibility | Proved here; no host minimality |
| G20 distance and odd-complement facts | Explicit two-Petersen construction | Proved analytically and fixed certificate checked; no exact XII |
| 519 all-odd gate | Fixed prism plus full exact-XII support | Audited in pulse 2; not general profile forcing |
| 522 difference lower bound | Two genuine zero-port row occurrences, both odd complements | Lower bound; full predecessor chain not newly re-proved |
| 523 zero/two-path split | Assume D is a single eight-cycle and genuine row | Conditional split; zero branch not forced |
| 525 attachment bound | Selected carrier gives actual cyclic host cut; cyclic five-connectivity | Conditional lower bounds; does not need global minimum separately once connectivity is supplied |
| Published nested five-cut classification used in pulse 2 | Global minimum BF counterexample and true cyclic five-cut | Cannot apply just from local minimality or an arbitrary capped pole |
| General barrier/profile selection | Connected-core and deficiency assumptions plus marked-cut/minimum-host input | Earlier branches remain unresolved/unreviewed as noted above |

## Evidence and failed-route record

The fresh-context same-model reviewer independently reconstructed G20 and checked the six supplied rows and both failed switches. It then validated the analytic classification of all Petersen matchings, six-cover multiplicities, cut restoration, distance gap, complementary cycle lengths and girth argument. The review is `audit-pulse3/configuration-gap-independent-review.md`, including its strengthening in section 4. No independent-model or human scientific acceptance is implied.

`audit-pulse3/check_configuration_gap_certificate.py` checks just the supplied certificate; its JSON records difference lengths [8,8], Q2 complement lengths [5,5,5,5], and the two switch-defect vectors [0,0,2,2] and [2,2,0,0]. `check_bf_pair_distance.py` checks three Petersen pair symmetry representatives, all six **supplied** Petersen complements, one actual distance-eight pair and one supplied compatible pair of each shape. `bf-pulse3-distance-certificate.json` includes all graph edges and six supplied matching lists. There is no PM/cover search, graph census, parameter expansion, SAT, HPC or external execution.

The rejected route is explicit: full closure of actual matchings under internal cycle switching does not imply closure of cooccurring BF pairs. The positive defect inequalities alone are also not a completion certificate. Do not turn this failure into an exclusion of exact XII or a claim of a minimum-size counterexample.

## Next bounded mathematical step

Retain the genuine permitted shore row and build the obligations w_i(O)=|Q1 intersection E(C_i) intersection E(O)| for its difference components C_i and Q2-odd cycles O. A reduction to one retained component requires some j with w_j(O)>=2 for every O, and an actual four-occurrence completion preserving the permitted shore boundary. Try to derive this concentration from full exact support and a true host cut argument, or prove a conditional obstruction to it. Merely satisfying these weights does not supply the completion.

Alternatively formulate a disjunction: exact support/minimum-host conditions either admit a row of size-eight difference, or a larger compatible pair forces forbidden support through an independently justified cut/composition argument. Neither arm currently has a proof. This is a symbolic upstream task; broader local graph enumeration would not replace it. If neither direction yields a bounded advance, preserve this checkpoint and revisit the earlier perfectly-matchable/barrier-profile fork.

The separate parent-designated contribution task can assess this new self-contained candidate alongside the frozen cap-colouring candidate. Contributor order, licence, external verification and novelty assessment remain with that task. No local private packet was uploaded, no signature key or DOI generated, and no publication or other-line operation performed.

## Closure record

The final text review passed in `audit-pulse3/final-packet-acceptance.md`. It required two scope clarifications, now applied and recorded: the weighted component corollary assumes the whole difference consists of internal cycles; the bridge-shore parity proof explicitly assumes cubicity. The reviewer stopped after acceptance. This remains same-model review and does not convert historical unreviewed premises into accepted results.

`bf-pulse3-final-file-check.json` compares this pulse's starting and final original-unit metadata: all 1,782 size/mtime entries agree after about 1,195 seconds. It also verifies all eleven files in the pulse-2 frozen SHA256 manifest; all agree. Exact new deliverable hashes are in `bf-pulse3-deliverable-sha256.txt`, generated only after the texts and acceptance were finalized. No further research is running in this task.