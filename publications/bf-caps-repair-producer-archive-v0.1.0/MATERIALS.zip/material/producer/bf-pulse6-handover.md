> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Berge–Fulkerson pulse 6 checkpoint

2026-10-03. One bounded continuation of the task-5 research line. The original unit and all five earlier pulses are frozen. New conditional candidate: `bf-pulse6-canonical-free-repair.md`. Fixed certificate: `check_bf_canonical_free.py` and `bf-pulse6-free-repair-certificate.json`. Fresh-context same-model review: `audit-pulse6/review.md`; final-draft acceptance is recorded separately when completed, not substituted for human or external review.

## Concrete mathematical result

Selected the actual cut-mask interface of Notes 534/535, rather than an arbitrary graph or phase catalogue. Given the stated antipodal tight B14 and an **actual exterior matching N** with B-cut mask {b0,d0} and zero original six-port mask, its glued retained pair W_a,W_b is actual and differs on C8. BF co-occurrence remains a separate question.

Let Γ=F−N. The residual four-slot graph has fixed length-two chords 15 and 37. Every changed-leg Γ path adds two edges on becoming a C-to-C path; every Γ-to-original-port path adds one edge on becoming a whole C-to-port path. These are complementary paths, not the N0△N switching paths of the earlier transfer theorem.

Under the precise fixed-prism/full-exact-XII AllOdd gate, any successful free completion has at least one same-pair Γ path a1–a2 or c1–c2. Crossed-only cases give a star crossing graph, and any forest phase solution can be replaced by a two-direction solution which makes both complements all-even. Four open C legs are separately excluded by the four-slot odd-cycle capacity bound.

The same-pair cases are exactly soluble without literal outside-label alignment:

* Two same-pair paths: their Γ lengths must both be odd. Subject also to even closed Γ cycles and compatible fixed masks on every remaining original-port path, there are exactly **24×6^z** labelled residual four-occurrence completions.
* One same-pair path: its Γ length must be odd. The two connected original-port pairs must have the same direction and virtual sign θ+Lp+Lq=0 (whole C-to-port lengths, θ=0 equal pairs/1 complementary). Subject also to the independent closed-cycle and remaining port-path tests, there are exactly **4×6^z** labelled completions.

Here z counts closed Γ cycles; W_a,W_b remain fixed named occurrences. An odd Γ cycle blocks every boundary choice. A failing path pin blocks the specified boundary choice. No weights or fractional substitute is used for actual N.

The universal count is analytic: for K4 chords, ε_r is the parity of the size of the same-direction class containing r. Signs 0101 force classes 2+1+1, hence six assignments and four translations. The 24 local phases form a **single S4 orbit**, so the new phase language does not uncover an extra local family beyond the complete carrier-permutation orbit already available in Note 535. Its useful extension is a criterion for free completion across the actual exterior fibre.

If the actual host has girth≥5, each same-pair Γ path plus the old common bridge is a simple host cycle, so successful odd Γ lengths are at least five. The new C8-plus-real-residual-path carrier B* therefore has **at least 22 vertices for h=0** or **16 for h=2**, and each mixed odd target-complement cycle has length **at least 11**. B* includes exterior vertices and cannot inherit the old tight B14 hypotheses. Any cyclic-five-cut refinement also requires a true host cut and an opposite-shore cycle.

## Evidence and claim status

The first run of `python3 check_bf_canonical_free.py` passed. It verifies one supplied K4 phase, both source-forced crossed stars, h=2 fixed-pin arithmetic and one 22-vertex carrier with two (11,11) retained-complement decompositions. The supplied carrier has **ten common a,b boundary legs**, so a,b are not zero-port on that carrier. It is not a six-port Z or a witness for actual N/N0, exact-XII support, cyclic connectivity, minimum host or host girth. No graph, matching, cover, phase-assignment or arbitrary-catalogue enumeration occurred. The counts, necessity arguments and size bounds are proofs in the manuscript; the small certificate does not establish their universal scope by itself.

New analytic claims pass the initial independent-context same-model review. This is not a human reviewer, different-model consensus or publication acceptance. Final manuscript/certificate/handover review is a separate file; consult it before treating the packet as accepted. The final-draft reviewer identified one overbroad sentence: the two-direction colour split applies to K paths meeting C, not arbitrary disconnected Γ components. It was explicitly narrowed; disconnected closed cycles use the separate even-cycle test. This was a proof-scope wording correction, not a failed certificate or change of the theorem.

Imported conditions remain conditions. This pulse independently uses the explicit B geometry and inside complement paths, and audits the matching-switch/complement distinction. It does not re-prove the full Note 533/526 chain, the Note 519 applicability theorem or historical support forcing. No error is newly found in these targeted interfaces; no conclusion is drawn about the unreviewed remainder of the 655-note line. The pulse-5 failed expectation (5,9), its corrected (7,7) certificate and its correction record remain untouched.

## Precise upstream stop and next useful work

Within this selected canonical route, the smallest missing input is existence of an actual exterior N with mask {b0,d0}, zero original ports, and Γ satisfying one of the exact free-completion criteria above. The alternating-path criterion in Note 534 settles matching existence only when its paths are supplied. Literal transfer in Note 535 is an additional conditional construction; it neither forces this fibre nor supplies the complement topology and port masks in general. Full support and AllOdd alone have not been shown to force a suitable N. No actual separating exact-XII example is given, so strict existential gain over literal transfer is not claimed.

Before this route, the broader missing input remains a genuine allowed row with the zero-port C8 pair, together with the tight-carrier hypotheses. A lower bound does not force attainment. Completion **after** such a pair/geometry is supplied is now exact in this fibre; existence **of** the pair/geometry/fibre remains open.

## Operational and public boundaries

Original unit `[unbundled historical source scope]` stayed read only. Startup observed 1782 unit file metadata entries unchanged and all 41 recorded prior SHA entries unchanged (40 unique files). A final comparison is stored separately. Those SHA entries cover the available pulse-2–5 manifests; no pulse-1 historical manifest exists, and this is not retroactively invented. Frozen manifest files themselves remain preserved.

Potential minimal public contribution: the self-contained conditional K4/free-fibre criterion plus girth-growth lemma. Publication still lacks contributor/author approval and attribution, licence choice, prior-art checks, external mathematical review and any desired actual-host witness. This packet supplies local candidate files only. Public AI Research Commons/CRL boundaries stay with the parent coordinator; no upload is authorized or performed here.
