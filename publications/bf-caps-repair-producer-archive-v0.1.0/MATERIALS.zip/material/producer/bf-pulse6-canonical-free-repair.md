> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Canonical C8 exterior repair: exact free completion and carrier growth

2026-10-03, bounded pulse 6. Conditional research candidate, independently reviewed in a fresh context using the same model. No novelty claim, actual exact-XII example, minimum counterexample or solution of Berge–Fulkerson is asserted. Pulses 1–5 and the original BF unit are preserved read only.

## Premises and the actual matching fibre

Let Z be a cubic shore with six original boundary semiedges. Six named matching occurrences a,b,c,d,e,f constitute a row when every internal vertex meets each occurrence once, every proper edge has total load two, and the original boundary masks are the specified two-sets. Fix a,b and put I={c,d,e,f}. All completion counts below keep a,b named and fixed, keep the original I boundary masks fixed, and distinguish all four I occurrences; they do not divide by colour permutations or exchange a,b.

The structural input is the following **specified** fourteen-vertex carrier B, with cycle C=0,1,...,7,0 and four other paths:

    0-a1-a2-4,   1-b0-5,   2-c1-c2-6,   3-d0-7.

B has six cut legs at a1,a2,b0,c1,c2,d0. Original zero-original-port matchings Q_a,Q_b alternate on C, use all six B cut legs and agree outside B as N0. This geometry is conditional on the genuine tight-carrier hypotheses of original Notes 533/534; this pulse does not re-prove their entire dependency chain or force their occurrence.

Let F be the exterior of B within Z, retaining the six B-cut semiedges and the six original Z-port semiedges. **Assume an actual complete exterior matching N** uses exactly the B-cut legs {b0,d0} and no original Z port. Inside B let M_a,M_b use their respective alternating C phase, both bridges a1a2,c1c2 and the b0,d0 cut legs. Gluing N gives actual zero-original-port shore matchings W_a,W_b, differing precisely on C. This proves matching status, not BF co-occurrence.

The source gives a criterion for existence of N: two vertex-disjoint N0-alternating exterior paths with endpoints a1,a2,c1,c2 and no original Z port. This matching-switch graph N0△N is **different from the complementary graph Γ=F−N** used below. Neither the source's alternating-path existence nor its literal singleton-transfer gate is assumed proved here. Optional N0-alternating cycles may be removed when testing matching existence, but changing N may change Γ and its completion properties.

We additionally assume the precise AllOdd gate: every actual zero-original-port shore matching of Z has an odd closed component in its complement. This is the conditional fixed central-path prism/full exact-XII gate of Note 519, not arbitrary Case XII. True-host girth or cyclic-cut statements below additionally require an actual host G with those properties.

## Residual graph and an exact phase reduction

For target pair W_a,W_b, residual demand m(e)=2−1_Wa(e)−1_Wb(e) is one on C, zero on common matching edges and two on a graph K. Away from C, K has degree two; its eight C vertices have degree one. Original semiedges are leaves. On a K edge choose a two-set A⊂I; at an internal K vertex the next two-set is κA=I\A. Thus a length-L path, counting both endpoint edges, transports A to κ^(L−1)A. Every closed K cycle must be even, in which case it has six labelled choices. Every K component joining two original ports must satisfy the same transport equation for their fixed masks; a mismatch is an obstruction at this fixed interface, whereas an odd K cycle obstructs every interface.

Γ has four changed-cut leaves a1,a2,c1,c2 and six original port leaves. Its other two B cuts are selected by N and absent. It consists of five paths and closed cycles. The common bridges inside B have residual demand zero. The two fixed C-to-C K paths 1-b0-5 and 3-d0-7 have length two. The other four C legs continue via 0-a1,4-a2,2-c1,6-c2 through Γ. A Γ path of length L joining changed legs, including its two actual B-cut edges once after gluing, becomes a C-to-C K path of length L+2. A Γ path from a changed leg to an original port becomes a C-to-port path of length L+1. No cut edge is duplicated.

For completeness, the C phase equations follow as in pulse 5. Identify I with V=F2². Give C edge i(i+1) a singleton colour t_i. Adjacent colours differ; at vertex i the K pair is A_i=V\{t_(i−1),t_i}, with nonzero direction σ_i=t_(i−1)+t_i. A C-to-C K path r joining i,j has a common direction σ_r and sign ε_r=(L_r−1) mod 2. If X is the crossing graph of its chords, complement transport is equivalent to

    ε_r = Σ_(s adjacent to r in X) det(σ_r,σ_s)  (mod 2).

Indeed integrate t_i=t_(i−1)+σ_i. The sum of σ along the arc between the two ends cancels for chords with both ends on that arc, leaving one σ_s for every chord crossing r. Its determinant with σ_r is the transverse displacement deciding equality or complementation of A_i,A_j. Every direction assignment satisfying these equations yields exactly four integrated phases, indexed by translation τ∈V.

With two C-to-port paths add the virtual chord between their C endpoints. Their fixed port pairs must have the same direction, hence be equal or complementary. Write θ=0 for equal and θ=1 for complementary, and let Lp,Lq be the **whole** C-to-port K lengths. The virtual sign is ν=θ+Lp+Lq mod 2, its direction is fixed by the port pairs, and one absolute pair pin leaves exactly two translations τ. The second pin then follows from the virtual equation. The other independent closed-cycle and original-port-path tests still apply.

## K4 rigidity: no hidden local phase family

For antipodal chords 04,15,26,37, X=K4. If the direction class containing r has size n_r, r has 4−n_r differently directed neighbours; det is one precisely for different nonzero directions. Consequently ε_r=n_r mod 2. Directly:

* Odd sign weight is impossible, by summing the equations.
* Weight zero has classes of sizes 4 or 2+2; it uses at most two directions.
* Weight four has classes of sizes 3+1; it uses at most two directions.
* Weight two has classes 2+1+1: the two zero-sign chords share a direction; the one-sign chords have the other two directions.

For ε=(0,1,0,1) this gives 3×2=6 direction assignments and four translations each, hence exactly 24 labelled C phases. They use all four colours. AGL(2,2) is the complete S4 action on four colours, has order 24 and acts freely here. These phases form one S4 orbit. In particular the old local carrier with path lengths (3,2,3,2) and six common a,b cut legs has exactly this orbit; no additional intrinsic phase choices beyond the complete carrier-colour permutations in Note 535 are uncovered. This is a local fact, not a count of full exterior rows.

## Why AllOdd excludes the other exterior pairings

Two-direction phases cannot occur in a successful completion under AllOdd. If the directions lie in {u,v}, the functional ℓ(x)=det(u+v,x) changes on every C step. It divides I into two two-sets used on alternate C phases. Every K two-set on a path meeting C has one colour in each division. Each retained-matching closed complement meeting C therefore receives a proper two-edge colouring on its C and K edges; closed K cycles disjoint from C are even by the independent test. Both complements are all-even, contradicting AllOdd.

On a forest crossing graph, any solvable phase equation has a two-direction solution: write σ_r=u or v according to bit x_r, so det(σ_r,σ_s)=x_r+x_s. The equations are the mod-two graph Laplacian. On each tree the only compatibility condition is Σ ε_r=0; remove leaves and integrate the forced edge differences to construct x. Hence a forest target admits no successful completion under AllOdd, even if a three-direction assignment was initially proposed.

Also a successful target has at most two C-to-port K paths. On an odd cycle of either retained complement, four residual matchings each meet at most (n−1)/2 of its n edges. Total residual load is 2n−k, where k is the number of edges of the other retained matching, so k≥2. Each required odd cycle needs at least four C endpoints with K paths closing internally. With four open C legs only four such endpoints remain; they would need to support two edges from each alternating C phase, forming a four-cycle inside the single C8, impossible. With six or eight open legs there are too few endpoints.

Thus a successful target here must have a **same-pair Γ path a1–a2 or c1–c2**. Without one, two changed-leg pairs are crossed, giving chords (02,46,15,37) or (06,24,15,37), whose crossing graphs are stars. With one crossed changed-leg pair, adding the virtual remaining chord gives the same star. With no changed-leg pair there are four open legs, already excluded. This is a case split forced by the actual four changed legs, not an arbitrary chord catalogue.

## Exact free-completion criteria within this actual fibre

Let z be the number of closed Γ cycles. In each case require all these cycles even and require every Γ path between two original ports to pass its actual fixed-mask transport test. The choices on such paths are pinned; each even closed cycle contributes independently six choices. These common tests are necessary and sufficient alongside the following C tests.

**Two same-pair paths (h=0).** Let Γ pair a1–a2 and c1–c2 with lengths La,Lc. The four real K path lengths are (La+2,2,Lc+2,2), so signs are (La−1,1,Lc−1,1) modulo two. Under AllOdd, a successful completion exists **iff La and Lc are both odd** and the common tests pass. It then has exactly 24×6^z labelled completions.

Proof: odd sign weight is impossible. Both lengths even give all-one signs and a two-direction completion whenever the independent tests pass, contradicting AllOdd. Both odd give exactly (0,1,0,1), whose 24 phases extend uniquely along all paths. AllOdd alone, without successful completion and the independent tests, must not be read as forcing both lengths odd; geometrically it may initially require only one of the two mixed cycles odd.

**Exactly one same-pair path (h=2).** Let its Γ length be L. The other two changed legs reach distinct original ports; use their whole C-to-port lengths Lp,Lq and θ above. Under AllOdd, a successful completion exists **iff** L is odd, the two C-connected port pairs have the same direction, ν=θ+Lp+Lq=0, and the common tests pass. It has exactly 4×6^z labelled completions.

Proof: the fixed chords have sign one. If the cycle test passes, the sole possible odd closed retained-complement component is the same-pair path closed through the six-edge inside complement path, so AllOdd forces L odd. Its chord has sign zero, and summing the K4 equations forces virtual sign zero. These conditions give the same weight-two solution: its real and virtual zero-sign chords share the fixed port direction, and the remaining two directions can be ordered in two ways. Each assignment has two translations satisfying the absolute pair pin, giving four phases; propagation gives the rest. If using Γ-to-port lengths rather than whole K lengths, both receive +1 and these cancel in ν.

These are **free** completions: the four residual matchings may change throughout Z. No monochromatic matching-switch cycle or alignment with the old singleton labels is required. This extends the restricted literal-transfer gate in scope, but no actual exact-XII separating host example has been exhibited; strict improvement of existential power is not claimed. Existence of an alternating-path matching N alone does not imply either completion criterion.

## True-host girth forces a larger repaired carrier

Now require the actual host G to have girth at least five. A same-pair Γ path a1–a2 lies outside old B, except for its two ends and actual cut edges. Add the old proper bridge a1a2, which belongs to W_a∩W_b. This forms a simple host cycle of length L+1. Therefore L≥4; successful AllOdd completion requires L odd, so **L≥5**. The bridge is a common inside matching edge, not an edge of the exterior restriction N. The same argument applies to c1–c2.

Let B* be C8 plus the interiors of its real C-to-C K paths. In h=0,

    |B*| = 8+(La+1)+1+(Lc+1)+1 = 12+La+Lc ≥22.

Each target complement has two mixed closed cycles, lengths La+6 and Lc+6, hence both odd and at least eleven. In h=2,

    |B*| = 8+(L+1)+1+1 = 11+L ≥16.

Each complement has one mixed closed cycle of length L+6≥11; its other two changed legs connect through an open original-port component. All closed Γ components must be even. These component lengths follow from the explicit inside complement paths

    M_a: a1-0-7-d0-3-4-a2; c1-2-1-b0-5-6-c2,
    M_b: a1-0-1-b0-5-4-a2; c1-2-3-d0-7-6-c2,

each of six proper edges. Their cut edges were already counted in L.

If B* and its opposite shore both contain cycles in an actual cyclically five-edge-connected host, in h=2 its ν=0 makes the common-matching cut size even. The cut consists of that size plus two K legs, so there are at least four common cut legs. This is conditional on the true cut and opposite-shore cycle, and the ≥16 girth bound is stronger than the generic ≥12 bound. No opposite-shore cycle is manufactured by the local certificate.

B* includes exterior path vertices and differs from the original tight B14. The old tight-fourteen-vertex classification cannot be applied again to B*. This size growth is a concrete constraint on the selected real repair route, not a descent argument or proof that a repair exists.

## Reproduction, scope and stop point

Run `python3 check_bf_canonical_free.py`. It checks one fixed K4 phase, the two source-forced star crossing graphs, one supplied 22-vertex repaired-carrier row and its (11,11) complement cycles, plus h=2 pin/count arithmetic. The row certificate has ten common a,b boundary legs; a,b are not zero-port on this **carrier**. It is not an actual six-port Z, complete exact-XII support family, original N/N0 fibre, minimum host or claimed girth-five host. The universal 24/4 counts and girth bounds are analytic proofs, not inferred from enumeration. No graph, matching, BF, phase-assignment or catalogue enumeration is performed.

The public-sized mathematical candidate is the conditional K4/free-fibre criterion and girth-growth lemma above. Before any public deposit: obtain author/contributor consent and attribution, decide a licence, verify sources and possible prior art, complete an external mathematical review, and supply any claimed actual-host witness or explicitly omit that claim. Nothing is uploaded, signed or assigned a DOI by this pulse.

The selected route's smallest still-unproved input is an **actual zero-original-port N of cut mask {b0,d0} whose complement Γ has one or two same-pair paths and satisfies the exact parity, closed-cycle and fixed-port conditions above**. Notes 534/535 offer conditional matching-switch and literal-transfer interfaces, not this existence theorem. A nonempty matching fibre itself would still leave its complement conditions unproved. At the broader earlier stage there is also no proof that a genuine allowed row attains a zero-port C8 target and then the tight canonical B assumptions; lower bounds do not force equality. This pulse stops at these precise upstream obligations. It does not loop through unrestricted diagrams or promote either existential assertion to a theorem.
