> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Independent review: canonical carrier and free transferred-pair completion

2026-10-03. Fresh-context same-model analytic review. This is neither human acceptance nor an external-model review. Only this new audit-pulse6 file was written. The original project was read only. No Git, HPC, SAT, graph/matching/BF enumeration, paid service, publication or catalogue expansion was used.

## Verdict and premise boundary

The proposed free-completion reduction and its counts **pass conditionally**. For an actual exterior matching N with precisely the carrier cut mask {b,d} and no original Z-port, the necessary and sufficient free-completion criteria below follow analytically. They do not require literal transfer or monochromatic new edges of N0 symmetric-difference N.

Canonical B is an accepted *conditional input*: C8 with paths 0-a1-a2-4, 1-b-5, 2-c1-c2-6, 3-d-7. The geometry is the conclusion of original Note 534 under the actual tight fourteen-vertex/six-cut hypotheses carried from 533/526. This review does not re-prove that chain or promote it to a theorem that a real full-support row has this carrier. The all-odd hypothesis is precisely the fixed central-path prism/full-exact-XII condition of Note 519, not arbitrary Case XII. Any true host-cut consequence additionally requires the actual cyclically five-edge-connected host and a cycle on the opposite shore.

Read inputs: task-5/bf-pulse5-c8-phase-completion.md; original notes/534-the-tight-zero-port-carrier-has-a-unique-antipodal-geometry.md, notes/535-the-tight-six-cut-has-an-exact-literal-singleton-phase-gate.md, and the stated all-odd theorem in notes/519-the-central-path-prism-forces-every-zero-shore-complement-odd.md. The pulse-5 phase reduction is used only through its explicitly proved residual-load and path-propagation equations.

## Actual pair, two different outside decompositions

The inside matchings Ma,Mb use their respective alternating C8 phase, both bridges a1a2,c1c2, and both b,d cut edges. Gluing the same complete N outside gives actual zero-original-port matchings Wa,Wb. Their difference is C8 and they agree everywhere else. This proves their matching status; it does not certify that they occur together in a BF row.

N0 symmetric-difference N describes matching *switches*: its changed-cut alternating paths, and any optional alternating cycles, give the rectangle and the restricted literal-transfer gate of Note 535. They are not the paths used in the free-completion theorem.

The residual-demand graph K for target pair Wa,Wb is obtained from the complement F-N, where F is outside B. Its fixed inside paths are 1-b-5 and 3-d-7, both of length two and hence sign one. The bridge edges are common target matching edges, so have residual load zero. The other four K legs are 0-a1, 4-a2, 2-c1, 6-c2, each continued through the corresponding changed cut edge into F-N. The six original Z-ports are K leaves, since N uses none of them. Off C8, each remaining residual edge needs two of the four named singleton colours; C8 edges need one.

Every closed component of F-N is a closed K component. An odd such cycle forbids **all** four-colour completions of this target pair, even if C8 colours or original boundary masks are changed. A port-to-port F-N path instead has the original fixed-pin condition Bq=kappa^(L-1)(Bp), counting both original port semiedges. Its failure excludes all completions preserving those masks; it need not survive changing them.

Cut semiedges are counted once when the multipoles are glued. If an F-N path between changed legs has length L, counting its two carrier-cut semiedges, the whole C-to-C K path has length L+2: add precisely the two carrier edges C-a/c. Its sign is (L+1) mod 2, equivalently (L-1) mod 2. If an F-N path joins a changed leg to an original port, its full C-to-port length is L+1. There is no additional duplicated cut edge in either expression.

## Exact K4 phase and count

For four mutually crossing antipodal chords, the pulse-5 equations are

    epsilon_r = sum_(s != r) det(sigma_r,sigma_s),
    sigma_r in F2^2 minus {0}.

If n_r is the size of the direction class containing r, its differently directed neighbours number 4-n_r. Thus epsilon_r=n_r mod 2. This proves the entire classification directly:

* Weight zero admits one class of size four or two classes of size two; a solution uses at most two directions.
* Weight four admits classes of sizes three and one; again at most two directions.
* Weight two forces sizes 2+1+1. The two sign-zero chords have the repeated direction; the two sign-one chords have the two remaining distinct directions. It has 3 times 2 = 6 direction assignments.
* Odd weight is impossible, by summing the four equations.

For epsilon=(0,1,0,1), each of those six assignments integrates to exactly four C8 singleton labellings, one for each translation tau in F2^2. Adjacent colours differ automatically, and K propagation is then unique on paths. Hence there are exactly 24 labelled C8/carrier solutions. All three directions occur, so all four colours occur. The affine group AGL(2,2) has order 4 times 6 = 24 and is the full S4 action on the four colours. It preserves the phase equations and acts freely on these labellings. Therefore the 24 solutions form one S4 orbit.

This also verifies that the *original local canonical carrier*, with its six common zero-colour cut labels and no singleton on that cut, has exactly these 24 free singleton colourings. There are no extra local phases beyond the complete carrier-permutation orbit of Note 535. Original named exterior singleton restrictions may remain fixed because every carrier singleton restriction has zero carrier-cut mask. This local fact does not count arbitrary full-exterior rows.

## Two same-pair complement paths: h=0

Suppose F-N pairs changed legs a1-a2 and c1-c2. K then has four antipodal chords 04,15,26,37 with lengths (La+2,2,Lc+2,2). Its signs are (La-1,1,Lc-1,1), modulo two.

Under the all-odd hypothesis, a successful completion must use all three C8 directions, by the pulse-5 two-direction obstruction. The K4 classification therefore forces epsilon=(0,1,0,1), namely La,Lc both odd. Equivalently, if the independent cycle and pin tests pass, a different feasible sign pattern would give a two-direction completion with both target complements all-even, contradicting the all-odd premise. Do not state that all-odd alone, without successful completion and the independent tests, forces both individual path parities: geometrically it initially forces at least one same-pair path to be odd.

Consequently the exact all-odd free-completion criterion in this branch is: La,Lc odd; all closed F-N cycles even; every remaining original-port-to-port path passes its actual fixed-pin test. If these hold, there are exactly 24 times 6^z labelled four-occurrence completions, where z is the number of closed F-N cycles. Each even cycle has six choices of a two-set on one chosen edge and then unique complement propagation; the components are independent. Original port paths are fully pinned and add no factor. Wa,Wb are treated as fixed named occurrences; exchanging or relabelling them is not included in this count.

## One same-pair complement path: h=2

Suppose precisely one of a1-a2,c1-c2 is an F-N path. The other two changed legs must each reach an original port. Let L be the same-pair F-N length, and let Lp,Lq be the full C-to-port K lengths. The two fixed inside chords still have sign one. The missing antipodal chord is virtual, with sign

    epsilon_virtual = theta + Lp + Lq (mod 2),

where theta=0 for equal port pairs and theta=1 for complementary pairs. The port directions must agree. This formula follows by transporting each port pin by kappa^(Lj-1); the two minus-one terms cancel. Lp,Lq include the one carrier leg and the cut/original-port edges counted once.

If the independent closed-cycle test passes, the only possible odd closed target-complement component comes from the one same-pair F-N path, closed by an even carrier complement path from Note 534(4). All-odd therefore forces L odd. The real chord sign is zero. Summing the K4 phase equations then forces virtual sign zero. Conversely, real sign zero, virtual sign zero and two fixed signs one give exactly the weight-two K4 system, so the phase equations are sufficient once the independent pin and cycle conditions hold.

Thus the exact criterion is: L odd; the two C-connected original port pairs have a common direction; theta+Lp+Lq=0; all closed F-N cycles even; and all remaining original-port paths compatible. The real and virtual sign-zero chords have the repeated direction, now fixed by the port direction. The two sign-one chords can exchange the other two directions, giving two assignments. One absolute pair pin imposes a nonzero linear equation on tau and leaves exactly two translations; the other pin then follows. Hence there are exactly 4 times 6^z labelled completions. No exterior singleton label alignment is assumed.

For the *new* transferred-pair set B' consisting of C8 and its three real C-to-C K-path interiors, epsilon_virtual=0 gives |B'| even and the number of common-matching cut edges even. Its actual cyclic host cut has those common edges plus two K legs. Cyclic five-connectivity therefore implies at least four common cut edges and |B'|>=12. This excludes a tight (11 vertices, three common cut edges) B' in this branch. B' is not the original fourteen-vertex canonical carrier: the set includes the relevant outside same-pair path and omits the two C-to-port interiors. The opposite-shore cycle and actual-host hypotheses remain essential.

## Girth refinement in the real host

Suppose the actual host has girth at least five, as required in the original minimum-host branch. A same-pair F-N path of length L includes its two actual carrier-cut edges. Its internal vertices lie outside the original B and the path is simple. Adjoining the original proper carrier bridge a1a2 or c1c2 therefore makes a simple host cycle of length L+1. Girth implies L>=4. A successful all-odd completion requires L odd, as proved above, so in fact L>=5. This uses the complement path F-N, not the matching-switch paths N0 symmetric-difference N.

For two same-pair paths, the new C8-plus-real-K-path carrier B* has

    |B*| = 8 + (La+1) + 1 + (Lc+1) + 1
          = 12 + La + Lc >= 22.

Both target complements have two mixed closed components, of lengths La+6 and Lc+6, hence odd lengths at least eleven. The six proper carrier-complement edges in Note 534(4) are added to the F-N length; the two cut edges are already counted in the latter, so no extra semiedges are added here. All other closed F-N components must be even in a successful completion.

For one same-pair path, B* has

    |B*| = 8 + (L+1) + 1 + 1 = 11 + L >= 16.

Each target complement has exactly one mixed closed component, of odd length L+6>=11. The other two changed legs reach original ports and remain open. The even-F-N-cycle condition excludes any additional odd closed component. The virtual sign is still zero and the actual cyclic-cut consequence of at least four common cut edges remains conditional on the true cut/opposite-shore cycle hypotheses.

These strengthen the size bounds for this specific transferred target; they do not force N's existence. B* is different from the old tight B14: it includes the same-pair outside path interiors, and the old bridge on each such pair is now an inside edge of Wa intersection Wb. Strictly it is not an edge of the exterior restriction N. The old tight-fourteen-vertex classification hypotheses cannot be reapplied to B*.

## Exhaustiveness under all-odd and no inference of existence

The four changed-leg leaves of F-N either pair with each other or reach original ports. If s internal pairs occur, h=4-2s. With two internal pairs, there are only the same-pair pairing or the two crossed pairings; with one internal pair there is a same-pair or a crossed pair. This is a structural case split, not a computational search.

If there is no same-pair and h=0, the real chords are either (02,46,15,37) or (06,24,15,37). Their crossing graph is a star centred respectively at 15 or 37. If there is no same-pair and h=2, adding the virtual chord on the remaining endpoints gives one of the same two star diagrams. The pulse-5 forest obstruction excludes every successful fixed-boundary completion of these targets under all-odd. If h=4, the all-odd four-slot capacity argument excludes successful completion: an odd component of each target complement would need two edges of the opposite alternating C8 phase, so the same four internal endpoints would support both alternating phases as a four-vertex cycle inside C8, impossible.

Therefore every successful free transferred-pair completion under these hypotheses requires at least one same-pair **F-N complement path**. This extends the limited literal-transfer conclusion of Note 535: it is independent of its monochromatic N0 symmetric-difference N labels. It does not imply that its alternating-path matching fibre is nonempty, or that it contains a matching with the required complement topology, parities and original port-pin pairing.

## Remaining precise gap and final acceptance status

There is still no exhibited actual row/host forcing canonical tight B, no exhibited actual zero-original-port exterior N selecting exactly {b,d}, and no proof that a nonempty such fibre supplies a same-pair F-N path of the required parity, even closed F-N cycles and compatible original port paths. An alternating-path proof of N's existence would settle only the matching fibre, not these complement and pin conditions. Full exact support supplies the applicable all-odd gate; it does not supply N or a free completion.

The review accepts the conditional analytic claims and counts above. It does not yet accept the parent's final pulse-6 draft or handover: those files require a subsequent final read for these scopes, lengths and qualifications.
