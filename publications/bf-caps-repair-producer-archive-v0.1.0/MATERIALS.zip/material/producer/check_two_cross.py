# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Bounded local combinatorial check; no claim about complete BF support."""
from itertools import combinations, permutations
from collections import Counter, deque
import json

def edge(a,b): return tuple(sorted((a,b)))
PATH={edge(i,i+1) for i in range(9)}
H={edge(i,i+1) for i in range(0,10,2)}

def matchings(vertices,edges):
    if not vertices:
        yield frozenset(); return
    v=min(vertices)
    for w in sorted(vertices-{v}):
        e=edge(v,w)
        if e in edges:
            for m in matchings(vertices-{v,w},edges): yield m|{e}

def components(edges):
    adj={}
    for a,b in edges: adj.setdefault(a,set()).add(b);adj.setdefault(b,set()).add(a)
    unseen=set(adj); ans=[]
    while unseen:
        root=min(unseen); seen={root}; todo=[root]
        while todo:
            v=todo.pop()
            for w in adj[v]-seen:seen.add(w);todo.append(w)
        unseen-=seen
        if all(len(adj[v])==2 for v in seen): ans.append(sorted(seen))
    return ans

def girth_ok(edges):
    adj={}
    for a,b in edges:adj.setdefault(a,set()).add(b);adj.setdefault(b,set()).add(a)
    for a,b in edges:
        todo=deque([(a,0)]);seen={a}
        while todo:
            v,d=todo.popleft()
            if d>=3:continue
            for w in adj[v]:
                if edge(v,w)==(a,b):continue
                if w==b:return False
                if w not in seen:seen.add(w);todo.append((w,d+1))
    return True

def paired(x,y,chords):
    adj={i:[] for i in range(10)}
    for a,b in H|chords:adj[a].append(b);adj[b].append(a)
    todo=[x];seen={x}
    while todo:
        v=todo.pop()
        for w in adj[v]:
            if w not in seen:seen.add(w);todo.append(w)
    return y in seen

def main():
    # No symmetry reduction. Covers all labelled endpoint assignments under
    # terminal independence: neither 09 chord nor endpoint crosses allowed.
    pool=[edge(a,b) for a,b in combinations(range(10),2) if b-a>=4 and (a,b)!=(0,9)]
    counts=Counter(); survivors=[]; witnesses=[]; classified=Counter()
    for pair in combinations(pool,2):
        chords=set(pair); ends={v for e in pair for v in e}
        if len(ends)!=4:continue
        for x,y in permutations(set(range(1,9))-ends,2):
            legs=set(range(10))-ends-{x,y}
            for qs in [(0,1),(1,2),(0,2)]:
                proper=PATH|chords
                full=proper|{(10,11),(11,12),edge(x,10+qs[0]),edge(y,10+qs[1])}
                if not girth_ok(full):continue
                counts['girth_valid']+=1
                if not paired(x,y,chords):continue
                counts['cross_paired']+=1
                choices=[]
                for q,z in zip(qs,[x,y]):
                    if q==1:continue  # Remaining Q pair must be an edge.
                    for k in sorted(legs):
                        for m in matchings(set(range(10))-{z,k},proper):
                            cycles=components(proper-set(m));odd=[c for c in cycles if len(c)%2]
                            choices.append({'q':q,'cross':z,'leg':k,'matching':sorted(m),'cycles':cycles,'odd':odd})
                rec={'chords':sorted(chords),'crosses':[[qs[0],x],[qs[1],y]],'legs':sorted(legs),'one_cross':choices}
                if not choices:counts['no_one_cross']+=1;survivors.append(rec)
                elif all(c['odd'] for c in choices):counts['all_one_cross_odd']+=1;survivors.append(rec)
                else:
                    counts['clean_one_cross']+=1
                    clean=next(c for c in choices if not c['odd'])
                    witnesses.append({k:rec[k] for k in ['chords','crosses','legs']}|{'witness':clean})
                for c in choices:
                    for cy in c['odd']:
                        ce={e for e in proper-set(c['matching']) if set(e)<=set(cy)}
                        classified[(len(cy),len(ce&chords))]+=1
    out={'scope':'P=0..9, Q=10..12; exactly 2 disjoint chords of span>=4, no 09; two distinct internal cross endpoints; all 3 labelled Q cross pairs; girth>=5; H+chords cross pairing',
         'counts':dict(counts),'odd_cycle_types':{str(k):v for k,v in classified.items()},'survivors':survivors}
    with open('two-cross-result.json','w') as f:json.dump(out,f,indent=2)
    with open('two-cross-witnesses.json','w') as f:json.dump(witnesses,f,indent=2)
    print(json.dumps({k:v for k,v in out.items() if k!='survivors'},indent=2))
    print('survivors',len(survivors))
    for r in survivors[:8]:print(json.dumps(r))

if __name__=='__main__':main()
