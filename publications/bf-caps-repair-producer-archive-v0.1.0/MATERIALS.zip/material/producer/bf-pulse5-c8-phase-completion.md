> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Free four-matching completion around an eight-cycle

Version 1, 2026-10-03. This new candidate gives an exact finite-dimensional phase reduction, a constructive forest criterion and a conditional obstruction in an all-odd shore. No novelty, order-minimality or solution of the Berge–Fulkerson conjecture is claimed. Earlier packets are preserved.

## Precise target and boundary

Start with a genuine six-occurrence double-cover row on a loopless cubic multipole Z, with two zero-port occurrences Q_a,Q_b and four other slots I={c,d,e,f}. Retain one internal eight-cycle C of Q_a symmetric-difference Q_b, and switch a on every other component to obtain the actual zero-port matching P. Then P symmetric-difference Q_b=C. We seek four residual matching occurrences preserving the original Z-boundary masks slot by slot, while allowing **all** residual singleton colours on C to change.

If Z lies inside a BF-colourable shore L, the constructed row glues to the original six exterior occurrences and has the original L-boundary state. The claim concerns a permitted row of L, not a BF cover of a hypothetical counterexample host.

Put m(e)=2−1_P(e)−1_Qb(e). The m=1 edges are exactly C; the m=2 edges form K after extending each semiedge to an auxiliary leaf. Internal K vertices have degree two except for the eight vertices of C, which have degree one. Thus K consists of paths and closed cycles. Its cycles must be even in any completion, independently of singleton recolouring. Port-to-port paths must obey their fixed endpoint pair relation B=kappa^(L−1)(A), where kappa(A)=I minus A and L includes semiedges. A failure involving two fixed port endpoints excludes every completion with these boundary masks; changing exterior/interface masks is a different problem. An original singleton-pin mismatch at a C endpoint, in contrast, need not exclude a free completion.

We treat the two cases h=0 or h=2, where h is the number of K paths from a C vertex to a port. Why these are the relevant cases under an all-odd hypothesis is proved below. No assertion is made that they cover arbitrary shores without that hypothesis.

## The exact chord phase equations

Number C's vertices 0,...,7 cyclically, with P using edges i(i+1) for even i and Q_b using those for odd i. Identify the four named colours in I with the four vectors of V=F_2^2. Addition is xor. For nonzero sigma write ell_sigma(x)=det(sigma,x), over F_2. This nonzero functional has kernel {0,sigma}; its two level sets are exactly the two complementary pairs whose vector sum is sigma.

Let t_i be the unknown singleton colour on edge i(i+1). Distinct incident singleton colours require

    sigma_i=t_(i−1)+t_i != 0.

The pair on the K edge at vertex i is A_i=V minus {t_(i−1),t_i}. Its direction is sigma_i. K path propagation makes the directions at its two C endpoints equal. In the h=0 case, four C-to-C paths pair the eight vertices. Regard these as four abstract chords r with endpoint directions sigma_r and signs epsilon_r=(L_r−1) mod 2.

Let X be the four-node **crossing graph**: two chord nodes are adjacent precisely when their endpoints interlace in the cyclic order of C. This is a combinatorial diagram, not a planar-embedding assumption.

**Theorem 1 (h=0 free completion).** Subject to even closed K cycles and compatible fixed port-to-port paths, a free four-occurrence completion exists if and only if nonzero directions sigma_r in V can be chosen so that

    epsilon_r = sum_(s adjacent to r in X) det(sigma_r,sigma_s) mod 2

for every chord r. Since two distinct nonzero vectors have determinant one, this says that the number of crossing neighbours with a different direction has parity epsilon_r. There are three available directions. It does not require adjacent chords to have different directions.

**Proof.** On a paired set of C endpoints the direction is common. Every chord contributes its direction twice to sum_i sigma_i, so the sum is zero. Given directions, choose an arbitrary starting colour tau=t_7 and integrate t_i=tau+sum_(k=0)^i sigma_k around C; this closes and adjacent colours differ.

The coset value of A_i under ell_sigma_i is ell_sigma_i(t_(i−1))+1. Thus the pair relation between endpoints i,j of a chord of direction sigma is equivalent to

    det(sigma, sum of sigma_k on the arc from i through j−1)=epsilon_r.

The term from that chord itself has determinant zero. Other chords with both or neither endpoint on the arc contribute zero; exactly the interlacing chords contribute once. This gives the displayed equations, independent of tau. Conversely those equations make all C-to-C K pair relations hold. Alternating each pair and its complement along K, and using the singleton colours t_i on C, constructs four actual matching occurrences. Even K cycles can be labelled independently. Fixed port paths retain their pins, so the resulting six-slot row has precisely the original boundary. This proves necessity and sufficiency without searching for assignments.

## Two port paths and the virtual chord

For h=2, three actual K paths pair six C vertices; let the remaining endpoints be i_0,j_0, joined to ports p,q by K paths of lengths L_p,L_q. Transport their fixed port pairs B_p,B_q back to C:

    A_i0=kappa^(L_p−1)(B_p),  A_j0=kappa^(L_q−1)(B_q).

The sum of the eight sigma_i must vanish. The six paired endpoints cancel in pairs, so sigma_i0=sigma_j0. Consequently B_p,B_q must have the same direction, equivalently be equal or complementary. If not, **no** free completion with these port masks exists.

When they have the same direction sigma_0, add a virtual fourth chord between i_0,j_0. Let theta=0 if B_p=B_q and theta=1 if they are complementary. Its forced sign is

    epsilon_0=theta+L_p+L_q mod 2.

The minus-one terms from transporting both pins cancel. Use this virtual chord and the three actual chords to form X.

**Theorem 2 (h=2 free completion).** With even closed K cycles and compatible remaining port-to-port paths, a completion exists iff B_p,B_q have a common direction and the four-chord phase equations admit a direction assignment with sigma_0 equal to that direction.

The phase equations enforce the relative pair of the two C endpoints. A single nonzero linear equation in tau sets their absolute pair at i_0; the second endpoint then follows. There are two translations tau satisfying this equation. An arbitrary direction solution can be transformed to one with the required sigma_0 by an invertible linear map of V; all such maps over F_2 preserve determinants. Thus existence is the same three-direction phase problem with one direction normalised. It is not an enumeration of colours or BF rows.

## A constructive forest criterion

Restrict the chord directions to two nonzero values u,v and set sigma_r=u when x_r=0 and v when x_r=1. The phase equations become

    L_X x=epsilon over F_2,

where L_X has vertex degree on its diagonal and adjacency off diagonal, both reduced modulo two. This binary condition is sufficient for general X; it is **not** generally necessary for the three-direction problem.

**Theorem 3.** If X is a forest, the full three-direction problem is solvable iff the signs sum to zero on **each connected component** of X. In that case a two-direction solution is constructive.

Necessity follows by summing the phase equations over a connected component: each determinant term occurs twice. For sufficiency, root each tree. Give an edge to a child the bit equal to the sum of epsilon in that child's subtree. These edge bits have the required epsilon as their vertex boundary. Set root x=0 and integrate those edge bits to obtain all x. In h=2 one can complement all x bits in the virtual chord's component to set x_0=0, taking u to be its fixed direction. An isolated **real** chord requires epsilon=0, or odd actual K path length; even length excludes every completion of that target pair, independently of singleton or port recolouring. An isolated **virtual** chord also requires epsilon_0=0, but its failure depends on the fixed interface phase and need not survive changing those port masks. Neither failure is a fixed-singleton-pin artifact.

## What full all-odd support rules out

Assume now that **every actual zero-port matching of Z has an odd closed complementary component**. This is an explicit hypothesis of the next result. In the already audited fixed central-path-prism Case-XII branch it follows from complete support by the all-odd gate of original Note 519; it is not asserted for general Case XII or other profiles here.

Any successful completion must have h=0 or h=2. Indeed each odd complementary cycle of Q_b must contain at least two P edges by the four-slot cycle capacity bound, and conversely. Such a cycle needs four C vertices whose K legs pair internally. The number h is even. If h>=6, too few internal endpoints remain. If h=4, the same four internal endpoints would have to support two P edges and two Q_b edges, forming an alternating four-cycle inside the single eight-cycle C, impossible. Thus h is zero or two.

**Theorem 4 (forest obstruction in an all-odd shore).** Any successful free completion in this setting requires all three nonzero directions. Its four-chord crossing graph, with the virtual chord when h=2, must contain a cycle. In particular every forest target is impossible in this setting, although Theorem 3 constructs forest completions in the unrestricted local problem.

**Proof.** Suppose a phase solution uses only u,v (the one-direction case is included by choosing an unused second direction). Let w=u+v and ell=det(w,.); ell(u)=ell(v)=1. Therefore ell(t_i) alternates around C. All P-edge singleton colours lie in one two-element level set J_P of ell, and all Q_b-edge colours lie in its complementary set J_Q. A pair whose direction is u or v contains exactly one colour from each J. Every C-to-C K path therefore carries one colour of each J on every edge, and alternation gives at each internal vertex both colours in each J exactly once.

On any closed component of Z−Q_b meeting C, the two J_P slots consequently give a proper two-edge-colouring: at a C vertex its P edge uses one J_P colour and its K edge the other; off C its two K edges do likewise. Hence the closed component is even. The same argument using J_Q colours proves every P-complement closed component meeting C even. A closed component disjoint from C is an even K cycle. Port paths, including those in h=2, do not create closed components. Both complements therefore have no odd closed component, contradicting the hypothesis. If X is a forest and any phase solution exists, Theorem 3 supplies a two-direction solution and yields this contradiction. This proves the result.

The conclusion is conditional on the all-odd property and the stated target geometry. It does not assert that the original row has a removable C8, or that every difference has a single cycle. It supplies a precise obstruction to repairing that particular target in the genuine allowed branch.

## The actual prism boundary signature

In the fixed audited row, the six port pairs can be written

    (A,A,A,B,C,D),
    A={c,d}, B={e,f}=kappa(A), C={d,f}, D={c,e}=kappa(C).

The A/B direction differs from the C/D direction. When h=0, fixed port paths must pair C with D with **even** length; the other four ports must form one A–B even-length path and one A–A odd-length path. Pairing across the two direction classes forbids every completion retaining this interface, regardless of internal singleton recolouring.

For h=2 the two C-connected ports must come from the same direction class. The possibilities are:

| C-connected port pairs | Remaining port paths | theta in virtual sign |
|---|---|---|
| A,A | A–B even; C–D even | 0 |
| A,B | A–A odd; C–D even | 1 |
| C,D | A–A odd; A–B even | 1 |

The virtual sign remains theta+L_p+L_q. These are exact constraints for the original slotwise shore interface; a different exterior row with different shore pins is not excluded by a failure here. Full support was used to obtain the all-odd property in the specified branch, not to assume these internal equations have a solution.

## True host-cut consequences and a parity refinement

Suppose Z is in a cubic host G that is cyclically five-edge-connected, and the vertex set B below has cycles on both shores (the actual fixed prism exterior supplies the outside cycle). A global minimum counterexample gives these host hypotheses; merely capping an arbitrary pole does not. No six-cover of G is used.

Let B consist of C and the interiors of its actual C-to-C K paths, excluding C-to-port path interiors. Edges leaving B are common P,Q_b matching edges C_B and the first edges of the h C-to-port K paths. Only the off-C vertices of B can issue an edge of C_B, so |C_B|<=|B|−8.

For h=0, |B|=8+sum_r(L_r−1)=4+sum_r L_r. Any successful phase assignment has sum_r epsilon_r=0, so |B| is even. Matching-cut parity gives even |C_B|, and the true cyclic cut has size at least five. Hence |C_B|>=6 and |B|>=14. These are lower bounds, not a forced equality or canonical-carrier theorem.

For h=2, there are three actual internal paths and a virtual chord. Successful phase equations give sum_real epsilon_r=epsilon_0. Thus

    |B|=8+sum_real(L_r−1) == epsilon_0 (mod 2),
    |C_B| == |B| == epsilon_0 (mod 2).

The matching uses exactly C_B on the cut and neither of its two K legs. The cyclic cut has |C_B|+2>=5. Therefore epsilon_0=0 requires |C_B|>=4 and |B|>=12; epsilon_0=1 requires |C_B|>=3 and |B|>=11. A tight eleven-vertex/three-common-leg carrier can occur only with virtual sign one. This refines the unsigned attachment lower bound; it does not force a tight carrier or solve its exterior composition.

## A fixed three-direction carrier and reproduction

The fourteen-vertex carrier already used in earlier work has C=0–...–7–0 and K paths 0–a1–a2–4, 1–b1–5, 2–c1–c2–6, 3–d1–7. Its four chords all cross, so X=K4. Path lengths (3,2,3,2) give signs (0,1,0,1). Directions (u,v,u,u+v) satisfy the phase equations. The binary Laplacian of K4 is the all-ones matrix, whose image is only {0000,1111}; this sign vector genuinely needs three directions.

Integrating with colour coding c=0,d=1,e=2,f=3 and u=1,v=2, tau=0 gives C-edge residual colours (d,f,e,d,c,e,f,c). K pairs are ef–cd–ef on the first path, ce–df on the second, cd–ef–cd on the third and cf–de on the fourth. Each of the six off-C vertices has a boundary semiedge labelled ab. Every vertex partitions all six colours. Both a- and b-complement cycles have lengths (7,7). The first certificate run caught an incorrect expected (5,9) in the draft; the direct paths give (7,7), and this correction is preserved in `bf-pulse5-certificate-correction.md`. The phase equations and row incidences were not changed.

This is one genuine carrier row with **six common a,b boundary semiedges**; a,b are not zero-port on the carrier itself. It illustrates the internal C8 phase mechanism and is not a whole zero-port Z, complete exact-XII pole, minimum host or counterexample. Its need for three directions is consistent with, and does not prove sufficiency of, Theorem 4's necessary condition.

Run `python3 check_bf_c8_phases.py`. The script verifies one constructive forest phase example, one virtual-chord transport, one isolated-component obstruction and this fixed fourteen-vertex row. It checks phase relations and vertex colour incidences directly and records `bf-pulse5-phase-certificate.json`. Abstract diagram examples are not asserted to be actual exact-XII graphs. No graph, matching, BF-cover or direction-assignment enumeration occurs; the universal claims are analytic proofs.

Fresh-context same-model review is in `audit-pulse5/completion-review.md`; it is not human or external-model acceptance. Full Case-XII configuration forcing, existence of a target C8 and successful cyclic crossing-graph assignments remain unresolved. Release selection, authorship, licence, external verification and prior-art assessment remain with the designated contribution task. No publication, upload, signature key or DOI was created.
