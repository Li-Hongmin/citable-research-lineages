# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Check only the explicitly supplied 20-vertex two-Petersen certificate.

No PM search, cover search, graph census, parameter expansion, or external input.
The impossibility of the switched pair is the odd-cycle counting proof, not an
unsatisfiability assertion from computation.
"""
import json
from collections import Counter
from pathlib import Path


def edge(x, y):
    return tuple(sorted((x, y)))


def vertex(side, kind, index):
    return f"{side}:{kind}{index % 5}"


def petersen(side):
    u = lambda i: vertex(side, "u", i)
    v = lambda i: vertex(side, "v", i)
    graph = {edge(u(i), u(i + 1)) for i in range(5)}
    graph |= {edge(v(i), v(i + 2)) for i in range(5)}
    graph |= {edge(u(i), v(i)) for i in range(5)}
    matchings = [{edge(u(i), v(i)) for i in range(5)}]
    for k in range(5):
        matchings.append({edge(u(k), v(k)), edge(u(k + 1), u(k + 2)),
                          edge(u(k + 3), u(k + 4)), edge(v(k + 1), v(k + 3)),
                          edge(v(k + 2), v(k + 4))})
    return graph, matchings


def is_pm(matching, vertices):
    degree = Counter(x for e in matching for x in e)
    return set(degree) == vertices and all(x == 1 for x in degree.values())


def cycles(edges):
    adjacency = {}
    for x, y in edges:
        adjacency.setdefault(x, []).append(y)
        adjacency.setdefault(y, []).append(x)
    assert all(len(neighbors) == 2 for neighbors in adjacency.values())
    remaining = set(adjacency)
    result = []
    while remaining:
        first = min(remaining)
        walk, previous, current = [], None, first
        while current not in walk:
            walk.append(current)
            nxt = next(x for x in sorted(adjacency[current]) if x != previous)
            previous, current = current, nxt
        assert current == first
        remaining.difference_update(walk)
        result.append(walk)
    return result


def cycle_edges(walk):
    return {edge(walk[i], walk[(i + 1) % len(walk)]) for i in range(len(walk))}


def main():
    graph_a, rows_a = petersen("a")
    graph_b, rows_b = petersen("b")
    removed = {edge(vertex(s, "u", 0), vertex(s, "v", 0)) for s in "ab"}
    joining = {edge(vertex("a", k, 0), vertex("b", k, 0)) for k in "uv"}
    graph = (graph_a | graph_b) - removed | joining
    vertices = {x for e in graph for x in e}
    degree = Counter(x for e in graph for x in e)
    assert len(vertices) == 20 and len(graph) == 30
    assert all(d == 3 for d in degree.values())
    rows = []
    for color, (a, b) in enumerate(zip(rows_a, rows_b)):
        row = (a | b) - removed
        if color in (0, 1):
            row |= joining
        assert row <= graph and is_pm(row, vertices)
        rows.append(row)
    coverage = Counter(e for row in rows for e in row)
    assert set(coverage) == graph and set(coverage.values()) == {2}
    q1, q2 = rows[:2]
    difference_cycles = cycles(q1 ^ q2)
    assert sorted(map(len, difference_cycles)) == [8, 8]
    complement_cycles = cycles(graph - q2)
    assert sorted(map(len, complement_cycles)) == [5, 5, 5, 5]
    assert all(len(cycle_edges(c) & q1) == 2 for c in complement_cycles)
    switched = []
    for difference in difference_cycles:
        support = cycle_edges(difference)
        qp = (q1 - support) | (q2 & support)
        assert is_pm(qp, vertices)
        counts = [len(cycle_edges(c) & qp) for c in complement_cycles]
        assert sorted(counts) == [0, 0, 2, 2]
        switched.append({"flipped_cycle": difference,
                         "actual_perfect_matching": True,
                         "odd_cycle_q1_prime_edge_counts": counts,
                         "impossible_cooccurrence_by_odd_cycle_bound": True})
    shores = [{vertex(s, kind, i) for kind in "uv" for i in range(5)} for s in "ab"]
    cut = {e for e in graph if (e[0] in shores[0]) != (e[1] in shores[0])}
    assert cut == joining
    for s in "ab":
        outer = [vertex(s, "u", i) for i in range(5)]
        assert cycle_edges(outer) <= graph
    return {"scope": "one supplied graph only; no matching or cover enumeration",
            "vertices": 20, "edges": 30, "simple_cubic": True,
            "six_given_rows_are_perfect_matchings": True,
            "edge_multiplicities": [2], "difference_cycles": difference_cycles,
            "q2_complement_odd_cycles": complement_cycles,
            "initial_odd_cycle_q1_edge_counts": [2] * 4,
            "one_component_switches": switched,
            "cyclic_two_edge_cut": sorted(joining),
            "does_not_establish_exact_case_xii_or_minimum_host_counterexample": True}


if __name__ == "__main__":
    output = main()
    target = Path(__file__).with_name("configuration-gap-certificate-check.json")
    target.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))
