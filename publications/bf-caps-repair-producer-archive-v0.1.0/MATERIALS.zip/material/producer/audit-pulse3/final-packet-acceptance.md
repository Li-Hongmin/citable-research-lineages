> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Final local packet acceptance

2026-10-03. Verdict: **accepted within the stated mathematical scope**. No remaining mathematical correction was identified in the reviewed packet after the two scope clarifications below were applied. This is a fresh-context review within the same model family, not human scientific acceptance, independent-model review, novelty assessment, publication admission, or release authorization.

Reviewed files:

- `bf-pulse3-defect-and-distance.md`
- `bf-pulse3-configuration-handover.md`
- `check_bf_pair_distance.py`
- `bf-pulse3-distance-certificate.json`

The final re-read of the mathematical candidate confirmed these applied corrections:

1. The weighted component formulation expressly assumes D consists entirely of internal alternating cycles, covers the two-zero-port case, and excludes multipole differences with boundary paths.
2. The bridge argument expressly assumes cubicity and derives odd shore order by degree counting before applying matching-cut parity.

## Accepted mathematical statements

The odd-cycle defect inequality is correct for every odd cycle O avoiding Q, when P,Q occupy two different slots of an actual six-occurrence double cover. Its count is on E(O). Each remaining occurrence can contribute at most floor(|O|/2) cycle edges, yielding `|P∩E(O)|≥2`. Boundary semiedges and chords do not alter this bound.

For differences consisting entirely of internal alternating cycles, switching all but C_j leaves exactly w_j(O) first-matching edges on each Q2-odd cycle. Therefore `w_j(O)≥2` for every such O is necessary for the switched pair to be BF-compatible. The packet correctly avoids claiming sufficiency, existence of a component meeting all these obligations, or existence of a permitted boundary-preserving completion by four more occurrences.

The analytic Petersen matching classification, six-cover multiplicities, and G20 restoration argument support the universal distance quantifiers. **Every BF-compatible pair** in the fixed G20 has difference size 16, with shape two C8s or one C16. **All distinct actual PM pairs** have positive distance 8 or 16, and a displayed distance-eight pair proves that their minimum positive distance is 8. The statements do not incorrectly minimize over all actual PMs in place of admissible cooccurring occurrences.

The complementary 2-factor statements are correct: using both joining edges gives lengths `[5,5,5,5]`; using neither gives `[5,5,10]`. Consequently every actual PM complement contains odd cycles, while not every complementary component is odd. The final candidate states this distinction explicitly.

The connected/simple/cubic/girth-five/bridgeless properties and the exhibited cyclic two-cut are consistent with the explicit construction. The original six-row certificate makes G20 BF-covered; it is therefore not itself a BF counterexample, and its cyclic two-cut puts it outside the cyclically-five-edge-connected minimum-host setting. The absence of the specified complete exact-XII pole boundary structure is retained as a scope limitation.

## Handover quantifiers and evidence limits

The handover preserves the distinction between a genuine permitted BF row of a colourable shore and a six-cover of the global counterexample host. It does not promote local pole minimality or arbitrary capping to global minimum-counterexample hypotheses at nested cuts.

The reference to 522 is a conditional lower bound `|Q1△Q2|≥8`; equality is used only under an explicit “if equality holds” condition. The existential attainment step remains unresolved, as do the subsequent zero-port, tight-carrier, and exterior-profile selection steps. In particular the packet does not turn the already conditional 818-certificate branch exclusion into a general exact-XII exclusion.

The code checks only supplied representatives, supplied complements, and the fixed witnessed pairs. Its JSON records the three representative common edges and C8s, six `[5,5]` Petersen complements, an actual distance-eight pair, and compatible pair shapes `[8,8]` and `[16]`, in agreement with the mathematical proof. The universal claims are explicitly attributed to analytic classification and restoration rather than computation. No PM/cover enumeration is disguised as certificate verification.

This final pass made no new search, mathematical computation, remote call, original-unit write, Git change, or overwrite of previous pulse material. It did not independently re-prove historical notes 167, 169, 519, 522, 523, 525 or the published minimum-host classification; their cited conditional boundaries are the handover's stated inputs. Full general exact-XII configuration forcing remains open.

Review stopped after this acceptance record. Release-related choices and operations remain with the separately user-designated contribution task.
