> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Independent finite review: PM closure versus BF pair compatibility

Verdict: both supplied claims are correct, with the qualifications below. The odd-cycle condition is necessary only. The explicit graph disproves closure of BF-compatible pairs under switching just one matching on a symmetric-difference component. It does not refute a claim restricted to actual exact Case XII shores or globally minimum counterexamples.

## 1. Necessary odd-cycle count

Let six perfect-matching occurrences `(Q1',Q2,R1,R2,R3,R4)` double-cover the edges of the graph (or of a multipole, with the usual perfect-matching restriction at its vertices). Repetitions of occurrences are allowed. Let O be an odd closed cycle component of `Z-Q2`, of length `2r+1`. Define `t(O)=|Q1' ∩ E(O)|`; this counts **edges on the cycle**, not arbitrary edges joining its vertex set.

No edge of O belongs to Q2. Each Ri is a matching, so it contains at most r edges of O. Exact double coverage gives

`4r+2 = 2|E(O)| = t(O) + Σ_i |Ri ∩ E(O)| ≤ t(O)+4r`.

Hence `t(O)≥2`. This proof uses neither the initial cooccurrence of Q1,Q2 nor cubicity away from O. It also applies when the other occurrences use boundary semiedges or Q2 has chords joining vertices of O: neither possibility increases a matching's maximum number of **cycle edges**. A closed component is essential to the stated cycle formulation; odd open paths are not being claimed here.

Now let `D=Q1△Q2`, and let C be any union of its alternating cycle components. Switching only Q1 gives

`Q1'=(Q1 \ E(C)) ∪ (Q2 ∩ E(C))`.

This is an actual perfect matching because each vertex on a selected cycle exchanges its unique Q1 edge for its unique Q2 edge; every other vertex is unchanged. For a zero-port occurrence, internal cycle switching preserves the zero-port boundary mask. Because `E(O)∩Q2=∅`,

`t(O)=|E(O)∩(Q1 \ E(C))|`.

Thus deleting selected D components from the original defect support leaves at least two Q1 edges on **each** odd complementary cycle, if `(Q1',Q2)` can cooccur in any BF row. Summing these counts without retaining the individual odd-cycle inequalities would give a weaker condition. The condition alone is not sufficient for cooccurrence; no completion theorem has been proved by this count.

## 2. Explicit 20-vertex countermodel

For one Petersen graph use indices modulo 5, outer edges `u_i u_{i+1}`, spokes `u_i v_i`, and inner edges `v_i v_{i+2}`. The six supplied matchings are

`M_inf={u_i v_i : i∈Z_5}`,

`M_k={u_k v_k, u_{k+1}u_{k+2}, u_{k+3}u_{k+4}, v_{k+1}v_{k+3}, v_{k+2}v_{k+4}}`.

Each is a perfect matching. A spoke belongs exactly to M_inf and M_i. An outer edge `u_i u_{i+1}` belongs exactly to `M_{i-1}` and `M_{i-3}`. An inner edge `v_i v_{i+2}` belongs exactly to `M_{i-1}` and `M_{i-2}`. Therefore these six occurrences double-cover the Petersen graph without invoking completeness of the list of all its perfect matchings.

Take two copies a,b, remove `u_0^a v_0^a` and `u_0^b v_0^b`, and add `u_0^a u_0^b` and `v_0^a v_0^b`. For each color, merge its two copy-matchings, remove the removed edges, and add both joining edges exactly in colors inf and 0. These are six actual perfect matchings, and every edge has load two. The graph is simple cubic with 20 vertices and 30 edges. This explicit BF row alone also rules out bridges by matching-cut parity.

Write Q1 for color inf and Q2 for color 0. Their difference consists exactly of the following two disjoint C8s, one in each copy:

`u1-u2-v2-v4-u4-u3-v3-v1-u1`.

The two joining edges belong to both Q1 and Q2, so neither is in D. On each copy the Q2 complement consists of two internal C5s:

`O1=u0-u1-v1-v4-u4-u0`,

`O2=u2-u3-v3-v0-v2-u2`.

Before switching, Q1 contributes the two spokes `u1v1,u4v4` to O1 and the two spokes `u2v2,u3v3` to O2. Thus every one of the four odd cycles meets the lower bound exactly.

After switching Q1 on the C8 of copy a, Q1' equals Q2 on copy a, and remains Q1 on copy b. In particular `|Q1'∩E(O1^a)|=|Q1'∩E(O2^a)|=0`, while the two corresponding counts on copy b remain 2. The new Q1' is a perfect matching, but the bound in part 1 proves that Q1',Q2 cannot cooccur in **any** six-perfect-matching double cover, regardless of how the other four occurrences are chosen. Switching copy b is symmetric.

The obstruction is on the **switched block, where Q1' equals Q2**. Wording such as “the other block has equal matchings” risks reversing this location. Switching neither component leaves the original row. Switching both gives Q1'=Q2 globally and is also incompatible here, by the same odd-cycle obstruction.

## 3. Precise boundary and effect on the unresolved interface

The two joining edges form a cyclic 2-edge cut: removing them separates the two copies, and each shore retains its outer C5. Consequently the example violates the cyclically-five-edge-connected host assumptions used in the minimum-counterexample framework. Moreover, the explicit original BF row means this graph itself is not a BF counterexample at all.

This is a valid structural countermodel to the unrestricted implication

`actual PM component closure ⇒ BF-compatible pair component closure`.

It is not an actual exact Case XII counterexample, a minimal-host counterexample, or an example with the required fixed six-port boundary relation. It therefore identifies why the proposed general reduction needs a separate BF row-completion argument, but does not disprove a completion statement with additional exact-support/minimum-host hypotheses. Nor does it establish existence of an allowable component switch satisfying all residual odd-cycle bounds in that narrower setting.

The only computation in this review constructs the supplied graph and supplied six rows, then checks their incidence, cover loads, D cycles, four Q2-complement cycles, two one-component switches, and the exhibited cyclic 2-cut. It searches for neither perfect matchings nor BF covers. The impossibility conclusion is the displayed counting proof.

Reproduction: `python3 audit-pulse3/check_configuration_gap_certificate.py`.

Evidence: `configuration-gap-certificate-check.json`. Same-model independent review only; no external-model or human acceptance is claimed.

## 4. Analytic strengthening on the same graph

The following strengthens the obstruction without a perfect-matching enumeration.

**All Petersen perfect matchings.** If a perfect matching uses s spokes, its unused outer vertices must be paired by outer edges, so `5-s` is even. Hence `s∈{1,3,5}`. For s=3 there are two unused indices i,j: they would need an outer edge, requiring `i-j=±1`, and an inner edge, requiring `i-j=±2`, impossible modulo 5. For s=1, say its spoke is `u_kv_k`, the four remaining outer vertices form a four-vertex path in the outer C5 and have a unique perfect matching; the four remaining inner vertices similarly form a path in the inner C5. These forced edges are precisely M_k. For s=5 the matching is M_inf. This proves the six given matchings are all perfect matchings, analytically.

**Unique multiplicities in a Petersen BF cover.** Let a be the number of M_inf occurrences and b_k the number of M_k occurrences in any six-occurrence double cover. Spoke `u_kv_k` gives `a+b_k=2`. The number of occurrences gives `a+Σ_k b_k=6`. Substitution yields `10-4a=6`, hence `a=1` and every `b_k=1`. This determines multiplicities; arbitrary order of the six slots remains possible.

**G20 restriction and restoration.** Let J be the joining 2-cut. Each shore has ten vertices, so matching-cut parity forces every actual G20 perfect matching to use zero or two edges of J. In the two-edge case, remove those edges and restore `u_0v_0` inside each shore; in the zero-edge case keep each shore restriction and do not add `u_0v_0`. This gives a bijection with pairs of Petersen perfect matchings whose use-bits for `u_0v_0` agree. Conversely, such a pair joins to an actual G20 matching. The bit-1 class is `{M_inf,M_0}`, the bit-0 class is `{M_1,M_2,M_3,M_4}`.

In any six-occurrence G20 cover, exactly two occurrences use J, because each joining edge has load two and the two are always used together. Consequently each restored shore list is itself a six-occurrence Petersen double cover: all original internal edges retain load two, and restored `u_0v_0` occurs exactly twice. By the preceding multiplicity argument, each shore list contains every one of its six Petersen matchings exactly once. Therefore any two different slots of a G20 BF cover restrict to **different** Petersen matchings in each shore. In particular no BF cover has a repeated G20 perfect matching occurrence.

**Pair differences in Petersen.** Any two distinct Petersen matchings share exactly one edge. Rotation reduces M_inf-versus-M_k to M_inf-versus-M_0. It reduces M_k-versus-M_l, after interchanging their order if necessary, to M_0-versus-M_1 or M_0-versus-M_2, because their index difference is `±1` or `±2`. The corresponding common edges are `u_0v_0`, `v_2v_4`, and `u_3u_4`. Each difference is a single C8. For completeness its cycles in these three representative cases are, respectively,

`u1-u2-v2-v4-u4-u3-v3-v1-u1`,

`u0-v0-v3-v1-u1-u2-u3-u4-u0`,

`u0-v0-v3-v1-v4-v2-u2-u1-u0`.

These are three symmetry representatives, not a search through perfect matchings or covers.

**All compatible pairs have difference size 16.** Define `δ(P,Q)=|P△Q|`. If two BF slots have the same use-bit, neither shore difference contains restored `u_0v_0`, and the actual G20 difference is the disjoint union of its two shore C8s. If they have different bits, each shore C8 contains restored `u_0v_0`; removing it leaves a path with seven edges from u0 to v0. The two paths, together with both joining edges, form a single C16. Thus every BF-compatible pair in G20 has δ=16, with the complete two-component/single-component distinction just stated. This excludes any BF-compatible pair of difference size eight.

For arbitrary distinct actual G20 perfect matchings with equal use-bit, each shore is either unchanged or changes by a C8. Their difference has size eight or sixteen. For different bits it always has size sixteen. The original `(M_inf,M_inf)` matching and `(M_0,M_inf)` matching are an actual pair differing by exactly one C8. Hence the minimum positive δ over all actual perfect-matching pairs is exactly eight. The gap between unrestricted pairs and compatible pairs is therefore `8 versus 16`, not merely failure of one selected switch.

**Every actual G20 matching leaves odd complementary cycles.** For M_inf the Petersen complement is the outer and inner C5. For M_0 it is O1,O2 displayed above; rotation gives two C5s for each M_k. If a G20 matching uses both joining edges, the complementary 2-factor is the disjoint union of both Petersen complements, so has lengths `[5,5,5,5]`. If it uses neither joining edge, each shore matching avoids `u_0v_0`, so that edge lies in exactly one of its two complementary C5s. Deleting it leaves a four-edge path from u0 to v0. These two paths join through J to form a C10, while one internal C5 survives in each shore. Thus its complementary lengths are `[5,5,10]`.

The correct assertion is “the complement of **every** perfect matching contains odd cycles.” It is stronger here to say each such complement contains at least two C5s. The wording “all PM all odd” must not mean “every complementary component is odd,” since bit-0 matchings have an even C10.

**Girth and limits.** The Petersen graph has girth five: cycles with no spokes lie in either C5; a hypothetical shorter cycle with spokes has two spokes and would require the same pair of indices to be adjacent both in the outer and inner graphs, impossible; four spokes require at least four nonspoke edges. Any G20 cycle crossing J uses both joining edges and contains a u0-v0 path in each edge-deleted Petersen shore. Each such path has length at least four, since restoring `u_0v_0` would otherwise give a Petersen cycle shorter than five. Hence crossing cycles have length at least ten. The retained outer C5s show that G20 has girth exactly five.

Accordingly this same explicit graph is simple, cubic, bridgeless, of girth five, BF-covered, and every perfect-matching complement contains odd cycles; nevertheless it has no BF-compatible pair with δ=8. These properties by themselves cannot force an eight-edge compatible pair. The cyclic 2-cut remains the decisive scope limitation. No conclusion restricted to a cyclically-five-edge-connected minimum host or a complete exact Case XII boundary relation has been refuted.
