# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Direct finite verification of only the carrier-pairing premise in Note 542."""
from itertools import combinations
import json
from check_two_cross import edge,matchings

names={8:'a1',9:'a2',10:'b',11:'c1',12:'c2',13:'d'}
legs=set(names)
edges={edge(i,(i+1)%8) for i in range(8)}
for path in [(0,8,9,4),(1,10,5),(2,11,12,6),(3,13,7)]:
    edges.update(edge(a,b) for a,b in zip(path,path[1:]))
exceptional={frozenset(x) for x in [(8,9),(11,12),(10,13)]}
out=[]
for mask in combinations(sorted(legs),2):
    if frozenset(mask) in exceptional:continue
    pairings={}
    for m in matchings(set(range(14))-set(mask),edges):
        adj={i:set() for i in range(14)}
        for a,b in edges-set(m):adj[a].add(b);adj[b].add(a)
        unseen=set(range(14));pairs=[];closed=False
        while unseen:
            root=min(unseen);seen={root};todo=[root]
            while todo:
                v=todo.pop()
                for w in adj[v]-seen:seen.add(w);todo.append(w)
            unseen-=seen
            endpoints=sorted(v for v in seen if len(adj[v])==1)
            if not endpoints:closed=True;break
            assert len(endpoints)==2 and set(endpoints)<=legs-set(mask)
            pairs.append(tuple(endpoints))
        if not closed:
            assert len(pairs)==2
            pairings.setdefault(tuple(sorted(pairs)),sorted(m))
    assert len(pairings)>=2,(mask,pairings)
    out.append({'mask':[names[v] for v in mask], 'pairings':[
        {'pairs':[[names[v] for v in p] for p in ps],'matching':m}
        for ps,m in pairings.items()]})
with open('carrier-gate-check.json','w') as f:json.dump(out,f,indent=2)
print(json.dumps({'nonexceptional_masks':len(out),'distinct_pairings_per_mask':[len(r['pairings']) for r in out]}))
