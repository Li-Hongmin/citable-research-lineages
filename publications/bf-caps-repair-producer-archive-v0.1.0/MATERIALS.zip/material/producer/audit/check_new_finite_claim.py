# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
from pathlib import Path
"""Independent nonrecursive finite review of the nine-edge two-cross claim.

Matching coverage: every four-edge subset of the eleven proper P edges.
Girth coverage: common-neighbour tests for triangles and quadrilaterals.
Clean certificate: bipartite colouring of the residual proper P graph.
No quotienting, and both with/without the 09 restriction are reported.
"""
from itertools import combinations, permutations
from collections import Counter
import json

V=set(range(10)); path={tuple((i,i+1)) for i in range(9)}
qp={(10,11),(11,12)}
def edge(a,b):return (min(a,b),max(a,b))
def graph(es,n):
    a=[set() for _ in range(n)]
    for u,v in es:a[u].add(v);a[v].add(u)
    return a
def girth_ok(es):
    a=graph(es,13)
    if any(a[u]&a[v] for u,v in es):return False
    return all(len(a[u]&a[v])<2 for u,v in combinations(range(13),2))
def paired(x,y,cs):
    mates={u:v for a,b in cs for u,v in ((a,b),(b,a))}
    z=x;seen=set()
    while z not in seen:
        seen.add(z);z=z^1
        if z not in mates:return z==y
        z=mates[z]
    raise AssertionError('Incidence cannot enter a closed alternating cycle')
def residual_information(es,cs):
    a=graph(es,10);col={};odd=[];clean=True
    for root in range(10):
        if root in col:continue
        col[root]=0;comp={root};todo=[root];conflict=False
        while todo:
            u=todo.pop()
            for v in a[u]:
                if v in col:
                    if col[v]==col[u]:conflict=True
                else:col[v]=1-col[u];comp.add(v);todo.append(v)
        if conflict:
            clean=False
            assert all(len(a[u])==2 for u in comp)
            odd.append((len(comp),sum(a in comp and b in comp for a,b in cs)))
    return clean,odd

counts={'allow09':Counter(),'forbid09':Counter()}
odd_types=Counter();fail=[];certificates=[];blocked=[]
pool=[(a,b) for a,b in combinations(range(10),2) if b-a>=4]
for cs0 in combinations(pool,2):
    ends={v for e in cs0 for v in e}
    if len(ends)!=4:continue
    cs=set(cs0);proper=path|cs
    # A one-cross matching has exactly four selected proper P edges.
    candidates=[]
    for ms in combinations(sorted(proper),4):
        covered=[v for e in ms for v in e]
        if len(set(covered))!=8:continue
        exposed=V-set(covered)
        if exposed&ends:continue  # Crosses/legs cannot also be private-chord ends.
        clean,odd=residual_information(proper-set(ms),cs)
        candidates.append((exposed,ms,clean,odd))
    for x,y in permutations(sorted(set(range(1,9))-ends),2):
        legs=V-ends-{x,y}
        for qa,qb in [(0,1),(1,2),(0,2)]:
            full=proper|qp|{edge(x,10+qa),edge(y,10+qb)}
            if not girth_ok(full):continue
            groups=['allow09']+(['forbid09'] if (0,9) not in cs else [])
            typ='separated' if (qa,qb)==(0,2) else 'adjacent_'+str(qa)+str(qb)
            for group in groups:counts[group]['girth_'+typ]+=1
            if not paired(x,y,cs):continue
            for group in groups:counts[group]['paired_'+typ]+=1
            actual=[]
            for q,z in [(qa,x),(qb,y)]:
                if q==1:continue
                for exposed,ms,clean,odd in candidates:
                    if z not in exposed:continue
                    k=next(iter(exposed-{z}))
                    if k not in legs:continue
                    actual.append((q,z,k,ms,clean,odd))
                    if 'forbid09' in groups:
                        odd_types.update(odd)
                        if not clean:
                            blocked.append({'chords':cs0,'selected_cross_vertex':z,
                                            'other_cross_vertex':y if z==x else x,
                                            'selected_leg':k,'proper_matching':ms})
            clean=[a for a in actual if a[4]]
            for group in groups:
                counts[group]['actual_matchings']+=len(actual)
                counts[group]['no_one_cross']+=not bool(actual)
                counts[group]['clean_'+typ]+=bool(clean)
                counts[group]['all_odd']+=bool(actual) and not bool(clean)
            if not clean:fail.append({'chords':cs0,'crosses':[(qa,x),(qb,y)],'actual':actual})
            elif 'forbid09' in groups:
                q,z,k,ms,_,_=clean[0]
                certificates.append({'chords':cs0,'crosses':[(qa,x),(qb,y)],
                                     'selected_cross':(q,z),'selected_leg':k,'proper_matching':ms})

out={'method':'four-edge subsets/common neighbours/bipartite colouring; no symmetry reduction',
     'counts':{k:dict(sorted(v.items())) for k,v in counts.items()},
     'odd_cycle_types':{str(k):v for k,v in sorted(odd_types.items())},'failures':fail,
     'certificate_count':len(certificates)}
print(json.dumps(out,indent=2))
with open(str(Path(__file__).with_name('clean_one_cross_certificates.json')),'w') as f:
    json.dump(certificates,f,indent=2)
with open(str(Path(__file__).with_name('blocked_one_cross_matchings.json')),'w') as f:
    json.dump(blocked,f,indent=2)
assert not fail
