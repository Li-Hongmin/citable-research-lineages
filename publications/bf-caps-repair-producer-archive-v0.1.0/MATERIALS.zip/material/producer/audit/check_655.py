# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Independent finite interface check of Note 655, P=0..9, Q=10..12.

No BF-support or carrier claims are computed. Enumerates disjoint private
chords, internal crosses, girth >=5, and actual one-cross matchings.
"""
from itertools import combinations, permutations
from collections import Counter, deque
import json

def edge(a,b): return tuple(sorted((a,b)))
P=set(range(10)); Q=set(range(10,13))
path={edge(i,i+1) for i in range(9)}
qp={edge(10,11),edge(11,12)}
H={edge(i,i+1) for i in range(0,10,2)}

def adj(edges, vertices=P|Q):
    a={v:set() for v in vertices}
    for u,v in edges: a[u].add(v); a[v].add(u)
    return a

def girth5(edges):
    a=adj(edges)
    for u,v in edges:
        seen={u}; todo=deque([(u,0)])
        while todo:
            z,d=todo.popleft()
            if d>=3: continue
            for w in a[z]:
                if edge(z,w)==(u,v): continue
                if w==v: return False
                if w not in seen: seen.add(w);todo.append((w,d+1))
    return True

def reach(arcs,start):
    r={start}; todo=[start]
    while todo:
        z=todo.pop()
        for a,b in arcs:
            if a==z and b not in r:r.add(b);todo.append(b)
    return r

def partner(x,chords):
    mate={u:v for a,b in chords for u,v in ((a,b),(b,a))}
    z=x
    while True:
        z=z^1
        if z not in mate:return z
        z=mate[z]

def perfect_matchings(vertices,edges):
    if not vertices:
        yield set();return
    u=min(vertices)
    for a,b in edges:
        if u not in (a,b):continue
        v=b if a==u else a
        if v in vertices:
            for rem in perfect_matchings(vertices-{u,v},edges):
                yield rem|{(a,b)}

def cycle_lengths(edges):
    a=adj(edges); seen=set();lens=[]
    for v in a:
        if v in seen:continue
        comp={v};todo=[v];seen.add(v)
        while todo:
            z=todo.pop()
            for w in a[z]:
                if w not in seen:seen.add(w);comp.add(w);todo.append(w)
        if all(len(a[z])==2 for z in comp):lens.append(len(comp))
    return lens

counts=Counter(); failures=[]
possible_chords=[edge(a,b) for a,b in combinations(range(10),2) if b-a>=4]
for ch in combinations(possible_chords,2):
    used=set(sum((list(e) for e in ch),[]))
    if len(used)!=4:continue
    for x,y in permutations(sorted(P-used),2):
        if x not in range(1,9) or y not in range(1,9):continue
        legs=P-used-{x,y}
        for typ,qy in [('adjacent',11),('separated',12)]:
            crosses={edge(10,x),edge(qy,y)};g=path|qp|set(ch)|crosses
            if not girth5(g):continue
            counts['girth5_'+typ]+=1
            paired=partner(x,ch)==y
            bip=all((a-b)%2 for a,b in ch)
            if paired and bip:
                counts['paired_bip_'+typ]+=1
                even,odd=(x,y) if x%2==0 else (y,x)
                r,t=even//2,odd//2
                arcs={(i,i+1) for i in range(4)}
                for a,b in ch:
                    o,e=(a,b) if a%2 else (b,a)
                    arcs.add((o//2,e//2))
                R=reach(arcs,r);L=reach({(b,a) for a,b in arcs},t)
                fwd={2*i+1 for i in R}&legs
                rev={2*i for i in L}&legs
                if not fwd and not rev:failures.append(['directed',typ,ch,x,y])
                if typ=='adjacent' and not (fwd if x%2==0 else rev):
                    failures.append(['q0_directed',ch,x,y])
            # The selected Q cross must leave two adjacent Q vertices.
            for cross_vertex,q in [(x,10),(y,qy)]:
                unused_q=Q-{q}
                qe=edge(*sorted(unused_q))
                if qe not in qp:continue
                for k in legs:
                    for pm in perfect_matchings(P-{cross_vertex,k},path|set(ch)):
                        counts['one_cross_matchings_'+typ]+=1
                        residual=g-pm-{edge(q,cross_vertex),qe}
                        odd_cycles=[n for n in cycle_lengths(residual) if n%2]
                        if any(n!=5 for n in odd_cycles):
                            failures.append(['odd_not_pentagon',typ,ch,x,y,k,sorted(pm),odd_cycles])
                        if paired and bip and odd_cycles:
                            failures.append(['bip_odd',typ,ch,x,y,k,sorted(pm),odd_cycles])

# Explicit forest certificates from 655.
examples=[({(0,5),(2,8)},1,4,11,9,{(0,5),(2,8),(3,4),(6,7)}),
          ({(0,6),(1,8)},4,5,12,7,{(0,1),(2,3),(5,6),(8,9)})]
for ch,x,y,qy,k,pm in examples:
    covered=[v for e in pm for v in e]+[x,k]
    assert sorted(covered)==list(range(10))
    residual=(path|qp|ch|{edge(10,x),edge(qy,y)})-pm-{edge(10,x),edge(11,12)}
    assert cycle_lengths(residual)==[]
counts['explicit_forest_certificates']=len(examples)
result={'scope':'P=9 edges; two disjoint chords; internal distinct crosses; girth>=5; no BF/carrier validation',
        'counts':dict(sorted(counts.items())),'failures':failures}
print(json.dumps(result,indent=2))
assert not failures
