# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Validate the 12 projected P repair types and their computational coverage."""
import json
from pathlib import Path
base=Path(__file__).resolve().parents[1]
blocked=json.loads((base/'audit/blocked_one_cross_matchings.json').read_text())
def makekey(cs,z,y,k):return (tuple(sorted(tuple(sorted(e)) for e in cs)),z,y,k)
def reflect(key):
    cs,z,y,k=key
    return makekey([(9-a,9-b) for a,b in cs],9-z,9-y,9-k)
def canonical(key):return min(key,reflect(key))
covered={canonical(makekey(r['chords'],r['selected_cross_vertex'],r['other_cross_vertex'],r['selected_leg'])) for r in blocked}
rows=[]
for line in (base/'bf-two-cross-checkpoint.md').read_text().splitlines():
    if not line.startswith('|'):continue
    cells=[x.strip() for x in line.strip('|').split('|')]
    if len(cells)!=6 or not cells[1].isdigit():continue
    cs=[tuple(map(int,x)) for x in cells[0].split(',')]
    z,y,k,knew=map(int,cells[1:5])
    ms={tuple(map(int,x)) for x in cells[5].split(',')}
    key=makekey(cs,z,y,k)
    ends={v for e in cs for v in e};legs=set(range(10))-ends-{z,y}
    assert k in legs and knew in legs and knew!=k
    proper={(i,i+1) for i in range(9)}|set(cs)
    assert len(ms)==4 and ms<=proper
    assert sorted([v for e in ms for v in e]+[z,knew])==list(range(10))
    a={i:set() for i in range(10)}
    for u,v in proper-ms:a[u].add(v);a[v].add(u)
    col={}
    for root in range(10):
        if root in col:continue
        col[root]=0;todo=[root]
        while todo:
            u=todo.pop()
            for v in a[u]:
                if v in col:assert col[v]!=col[u]
                else:col[v]=1-col[u];todo.append(v)
    rows.append(key)
assert len(rows)==len(set(rows))==12
assert {canonical(key) for key in rows}==covered
out={'blocked_actual_matchings':len(blocked),'projected_P_types_mod_reflection':len(covered),
     'repair_rows':len(rows),'all_repair_rows_actual':True,'all_repair_complements_bipartite':True,
     'projected_type_coverage_exact':True}
print(json.dumps(out,indent=2))
