# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Checks explicit parent certificates against independent scope enumeration."""
import json
from pathlib import Path
base=Path(__file__).resolve().parents[1]
parent=json.loads((base/'two-cross-witnesses.json').read_text())
ours=json.loads((base/'audit/clean_one_cross_certificates.json').read_text())
def key(r):return (tuple(map(tuple,r['chords'])),tuple(map(tuple,r['crosses'])))
assert len(parent)==len({key(r) for r in parent})==818
assert {key(r) for r in parent}=={key(r) for r in ours}
fail=[];path={(i,i+1) for i in range(9)}
for r in parent:
    cs=set(map(tuple,r['chords']));proper=path|cs
    w=r['witness'];q,z,k=w['q'],w['cross'],w['leg']
    ms=set(map(tuple,w['matching']))
    assert q in (0,2) and [q,z] in r['crosses']
    assert k in r['legs']
    assert len(ms)==4 and ms<=proper
    assert sorted([u for e in ms for u in e]+[z,k])==list(range(10))
    a={i:set() for i in range(10)}
    for u,v in proper-ms:a[u].add(v);a[v].add(u)
    color={}
    for root in range(10):
        if root in color:continue
        color[root]=0;todo=[root]
        while todo:
            u=todo.pop()
            for v in a[u]:
                if v in color:
                    assert color[v]!=color[u]
                else:color[v]=1-color[u];todo.append(v)
out={'parent_witnesses':len(parent),'independent_scope_keys':len(ours),
     'all_unique':True,'scope_sets_equal':True,'all_actual':True,
     'all_residual_proper_P_bipartite':True}
print(json.dumps(out,indent=2))
