> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# BF fifth bounded pulse: C8 phase constraints and a genuine-support obstruction

2026-10-03. New files are confined to task-5. The original BF unit is read-only, all prior frozen versions are retained, and no new graph/matching/cover/direction-assignment search was performed.

## What changed mathematically

The fourth pulse left the free completion question as singleton colours on retained difference edges coupled through K paths. When the retained difference is one C8, the fifth pulse eliminates these colours into a four-chord phase system over F2². This is a complete analytic reduction for the zero- or two-C-to-port cases, with explicitly retained boundary pins.

For h=0, four actual K paths pair the C8 vertices. Chords r,s are adjacent in the crossing graph X iff their endpoints interlace. Each chord gets one of three nonzero directions sigma_r, and a sign epsilon_r=(L_r−1) mod2. The exact free-completion equations are

    epsilon_r = sum_(s crossing r) det(sigma_r,sigma_s).

For h=2, three actual paths plus a virtual chord again give four nodes. The two C-connected port pairs must be equal or complementary. Their virtual sign is epsilon_0=theta+L_p+L_q, with theta distinguishing equal from complementary pairs. All lengths count boundary semiedges. The virtual direction is pinned, but invertible linear transformations and a colour translation handle its absolute boundary value constructively.

The key advance is the interaction with **complete support**, rather than another generic local sufficiency claim. For a forest X, each connected component's sign sum being even is exactly sufficient: leaf elimination gives a two-direction solution. But any two-direction completion makes both P and Q_b complementary closed components all even. This contradicts the all-odd gate of 519 in the already audited fixed central-path-prism exact-support branch. Therefore **a target retaining C8 with forest crossing graph cannot be repaired in that branch**. Any successful target requires all three directions and a cycle in X. This is a new conditional necessary structural restriction; it is not an exclusion of general Case XII or of every cyclic diagram.

The public-candidate theorem states the all-odd property explicitly as a hypothesis, with a self-contained proof of the forest obstruction. Its use for the private research line imports 519 only in its fixed prism/full-support scope, previously audited in pulse 2. It does not import 519 for arbitrary profiles, or claim that boundary-type names alone imply its conclusion.

## The real interface and host-cut conditions

The actual six-port signature is (A,A,A,B,C,D), where B=complement(A), D=complement(C), and the two direction classes differ. For h=0, the port paths must be A–A of odd length, A–B of even length and C–D of even length. For h=2, the two C-connected ports must be A,A or A,B or C,D; the candidate lists the remaining fixed paths and virtual phase. A cross-class port connection fails all free completions **with this slotwise interface**, but changing exterior/interface masks is a separate problem.

The true cyclic host cut supplies attachment bounds, without treating a BF row of L as a cover of G. Let B contain C8 and its actual C-to-C K paths, not its C-to-port interiors. Its cut consists of common P,Q_b matching legs C_B plus h K legs. The complementary host must contain a cycle, as supplied by the actual fixed prism exterior. Cyclic five-connectivity gives the original zero-port bounds |C_B|>=6, |B|>=14 after a successful completion.

For h=2, the virtual phase gives a refinement: |C_B|==|B|==epsilon_0 mod2. Hence epsilon_0=0 requires |C_B|>=4 and |B|>=12; epsilon_0=1 requires |C_B|>=3 and |B|>=11. A tight eleven-vertex/three-common-leg case needs epsilon_0=1. These remain lower bounds and conditional geometry; no equality or profile is forced. The host premise comes from a genuine cyclically-five-connected minimum host if that framework applies, not from arbitrary pole capping or local minimality.

## Keep the obstruction scopes separate

- An odd closed K cycle excludes every completion of the target pair, even if interface masks or singleton colours change.
- An isolated real chord of even K length also violates the phase equations independently of singleton and port recolouring.
- An isolated virtual chord with sign one is a fixed-interface phase obstruction, since its sign depends on the transported port pairs.
- Failure with the original retained singleton colours pinned can still be repaired by recolouring them. The fifth pulse solves the free phase problem; it does not revert to the fourth pulse's pinned test.
- Necessary odd-cycle weights do not replace any of these completion equations.

The statement that forest targets are impossible uses the all-odd property and target geometry, not merely the sign-sum test or a local minimum. It neither proves that every genuine row has a target C8 nor that a successful cyclic diagram exists.

## Fixed evidence, correction and review

The self-contained candidate is `bf-pulse5-c8-phase-completion.md`. Run `python3 check_bf_c8_phases.py` to reproduce the fixed certificate. It constructs one forest solution by leaf elimination, checks one virtual-chord transport and one isolated-component obstruction, then directly checks one supplied fourteen-vertex carrier. `bf-pulse5-phase-certificate.json` records its arithmetic, incidence labels and complementary cycle lengths. The abstract diagrams are not claimed to be whole exact-XII graphs.

The carrier has opposite endpoint chords, X=K4, signs (0,1,0,1) and directions (u,v,u,u+v). Its six boundary semiedges have common label ab, so a,b are not zero-port on the carrier itself. It is not a whole Z or minimum-host counterexample. The K4 binary Laplacian has only image {0000,1111}, so this signature needs three directions; the row has odd complementary cycles (7,7) on each side. This validates that the required three-direction/cyclic-diagram condition can hold locally and does not by itself prove exclusion or full-support closure.

The first verifier execution failed because the draft erroneously expected carrier complement lengths (5,9). Direct path tracing gave (7,7) on both sides. The program and draft were corrected without altering directions or row labels; the failed expectation and explicit correction are preserved in `bf-pulse5-certificate-correction.md`. Original notes and earlier packets were not edited.

A fresh-context same-model reviewer independently derived the phase equations, virtual sign, forest criterion, two-direction/all-even implication, actual port table and host-cut parity refinement. It then read the draft and fixed verifier, checked the supplied functions without modifying the primary JSON, and verified the carrier's vertex incidences and (7,7) cycle lists. Its review is `audit-pulse5/completion-review.md`. A final scope correction distinguishes isolated actual chords from isolated virtual chords; their obstruction scopes differ as described above. Final acceptance is recorded separately before freezing. This is not human or independent-model acceptance, novelty assessment or publication approval.

## Remaining question and next bounded step

In the fixed all-odd branch, forest repair is now a closed route. The next meaningful step must select an actual **cyclic** chord diagram and its signs from a real row/target geometry, with all three directions and the true interface. The exact equations then permit a symbolic solution or obstruction. A catalogue of arbitrary chord diagrams would not supply the upstream row or host constraints and is not proposed as a substitute.

The h=2 virtual sign additionally offers a concrete way to combine a real target's port lengths with its common-leg cut parity. Before exploring further profiles, check whether a proposed tight (11,3) geometry has sign one; sign zero requires a larger actual carrier. This is a conditional consistency test, not a claimed universal profile selection.

General perfectly-matchable/barrier-profile branches, existence of a compatible difference-eight row, zero-versus-two port selection, forced tightness and exterior composition all remain open. The earlier 818 finite branch exclusion remains conditional. No resolution of the main conjecture is claimed.

The new candidate and reproduction files can be handed to the parent's contribution task for release selection, attribution, licence, external verification and prior-art assessment. Nothing was uploaded, signed, assigned a DOI or published. There was no Git operation, remote/HPC/SAT work, paid service, account operation or other-line work.

## Closure checkpoint

Startup found all 1,782 original-unit size/mtime entries unchanged from pulse 4 and all 32 manifest entries in pulses 2–4 unchanged (the count includes a repeated dependency entry). The final comparison in `bf-pulse5-final-file-check.json` records the same 1,782 entries unchanged after about 1,384 seconds, and all 32 hashes unchanged, representing 31 unique files. No pre-existing local pulse-1 hash manifest was found; this pulse did not write any earlier packet file and does not claim a nonexistent historical hash comparison.

Final mathematical and fixed-certificate acceptance passed in `audit-pulse5/final-packet-acceptance.md`, including the real/virtual isolated-chord distinction and the explicit carrier correction. The reviewer has stopped; this is same-model acceptance within the declared scope. Only closure metadata and the final hash manifest were appended afterwards, without altering accepted mathematics. The new deliverables are frozen in `bf-pulse5-deliverable-sha256.txt`; no further research is running in this bounded pulse.