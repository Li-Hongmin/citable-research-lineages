# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Small direct edge-colouring check of the fixed 20-vertex six-pole.

This tests the cap-cycle mapping in 642, not BF support or host minimality.
"""
from itertools import combinations
import json

MARKS={'X':(1,3),'Y':(2,5),'Z':(4,6),'W':(1,6)}
S=['eXYWZ','eXWYZ']

def cycle_edges(order):
    return {tuple(sorted((a,b))) for a,b in zip(order,order[1:]+order[:1])}

def build(cap):
    edges=[];ports={}; vertices=set()
    def add(a,b):edges.append((a,b));vertices.update([a,b] if b is not None else [a])
    for i in range(1,6):
        add(str(i),'u'+str(i));add('u'+str(i),str(i+1))
        ports['p'+str(i)]=len(edges);add('u'+str(i),None)
    for mark,(a,b) in MARKS.items():
        add(str(a),'t'+mark);add('t'+mark,str(b));add('t'+mark,'bar'+mark)
    for a,b in sorted(cap):add('bar'+a,'bar'+b)
    ports['e']=len(edges);add('bare',None)
    assert len(vertices)==20 and len(edges)==33
    incidence={v:[] for v in vertices}
    for i,(a,b) in enumerate(edges):
        incidence[a].append(i)
        if b is not None:incidence[b].append(i)
    assert all(len(ix)==3 for ix in incidence.values())
    return edges,ports,incidence

def signatures(cap):
    edges,ports,inc=build(cap); used={v:set() for v in inc}; colours={};out={}
    # Quotient only global colour permutations, by fixing vertex 1.
    for colour,i in enumerate(inc['1'],1):
        colours[i]=colour
        for v in edges[i]:
            if v is not None:used[v].add(colour)
    def rec():
        if len(colours)==len(edges):
            sig=tuple(colours[ports[p]] for p in ['e','p1','p2','p3','p4','p5'])
            out.setdefault(sig,dict(colours));return
        best=None;avail=None
        for i,(a,b) in enumerate(edges):
            if i in colours:continue
            cs={1,2,3}-used[a]-(used[b] if b is not None else set())
            if not cs:return
            if avail is None or len(cs)<len(avail):best=i;avail=cs
        a,b=edges[best]
        for c in sorted(avail):
            colours[best]=c;used[a].add(c)
            if b is not None:used[b].add(c)
            rec()
            del colours[best];used[a].remove(c)
            if b is not None:used[b].remove(c)
    rec()
    return out,edges

all_pairs=set(combinations('eXYZW',2))
all_pairs={tuple(sorted(p)) for p in all_pairs}
result=[]
for s in S:
    se=cycle_edges(s)
    for typ,cap in [('allowed-loop-S',se),('physical-cap-T',all_pairs-se)]:
        ss,es=signatures(cap)
        names=['e','p1','p2','p3','p4','p5']; witness={}
        for a in ['e','p1','p2','p3']:
            for b in ['p4','p5']:
                good=next((sig for sig in sorted(ss) if sig[names.index(a)]!=sig[names.index(b)]),None)
                key=a+'+'+b
                if good is not None:witness[key]={'signature':good,'edge_colours':[[*es[i],c] for i,c in sorted(ss[good].items())]}
                else:witness[key]=None
        result.append({'S':s,'tested_cap':typ,'cap_edges':sorted(cap),'signature_count_mod_global_colour':len(ss),'signatures':sorted(ss),'pair_witnesses':witness})
with open('cap-colouring-result.json','w') as f:json.dump(result,f,indent=2)
for r in result:print(json.dumps({k:v for k,v in r.items() if k not in ['signatures','pair_witnesses']}|{'colourable_pairs':[k for k,v in r['pair_witnesses'].items() if v]}))
