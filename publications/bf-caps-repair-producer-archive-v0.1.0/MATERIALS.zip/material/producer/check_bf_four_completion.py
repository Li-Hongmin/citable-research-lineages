# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Construct a pinned four-occurrence completion; check fixed witnesses only.

No matching/cover search, graph census, SAT, or parameter enumeration. A path-pin
failure excludes only the pinned class; an odd closed K cycle excludes every
completion of the target pair. Proof is in the pulse-4 note.
"""
import json
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
COLORS = set("abcdef")
I = set("cdef")


def validate(edges, internal, labels):
    assert set(edges) == set(labels)
    for label in labels.values():
        assert len(label) == 2 and label <= COLORS
    for v in internal:
        incident = [labels[e] for e, ends in edges.items() if v in ends]
        assert len(incident) == 3
        assert sum(map(len, incident)) == len(set.union(*incident)) == 6


def chains(edges):
    adj = defaultdict(list)
    for e, (u, v) in edges.items():
        assert u != v
        adj[u].append(e)
        adj[v].append(e)
    assert all(len(es) in (1, 2) for es in adj.values())
    unused, out = set(edges), []
    while unused:
        endpoint = sorted(v for v, es in adj.items()
                          if len(es) == 1 and es[0] in unused)
        start = endpoint[0] if endpoint else min(edges[min(unused)])
        v, vertices, walk = start, [start], []
        while True:
            choices = sorted(e for e in adj[v] if e in unused)
            if not choices:
                break
            e = choices[0]
            unused.remove(e)
            walk.append(e)
            u, w = edges[e]
            v = w if v == u else u
            vertices.append(v)
            if v == start:
                break
        out.append({"edges": walk, "vertices": vertices,
                    "closed": vertices[-1] == start})
    return out


def solve(edges, internal, old, flipped):
    validate(edges, internal, old)
    assert all(not (old[e] & set("ab")) for e, ends in edges.items()
               if not set(ends) <= internal)  # both occurrences are zero-port
    a = {e for e in edges if "a" in old[e]}
    b = {e for e in edges if "b" in old[e]}
    d = a ^ b
    assert set(flipped) <= d
    for v in internal:
        n = sum(v in edges[e] for e in flipped)
        assert n in (0, 2)  # a union of complete internal D components
    assert all(set(edges[e]) <= internal for e in d)
    p = (a - set(flipped)) | (b & set(flipped))
    m = {e: 2 - (e in p) - (e in b) for e in edges}
    singleton = {e: old[e] & I for e in edges if m[e] == 1}
    assert all(len(s) == 1 for s in singleton.values())
    k = {e: ends for e, ends in edges.items() if m[e] == 2}
    adj = defaultdict(list)
    for e, ends in k.items():
        for v in ends:
            adj[v].append(e)
    pins = {}
    for v, es in adj.items():
        if v not in internal:
            assert len(es) == 1
            pins[v] = old[es[0]] & I
        elif len(es) == 1:
            used = set.union(*(s for e, s in singleton.items() if v in edges[e]))
            assert len(used) == 2
            pins[v] = I - used
        else:
            assert len(es) == 2
    labels = {e: set(singleton.get(e, set())) for e in edges}
    components, failures, z = chains(k), [], 0
    for item in components:
        walk, vertices = item["edges"], item["vertices"]
        length = len(walk)
        item["length_including_semiedges"] = length
        if item["closed"]:
            item["passes"] = length % 2 == 0
            initial = set("cd")
            z += 1
            if not item["passes"]:
                failures.append("odd closed K cycle")
        else:
            initial, last = pins[vertices[0]], pins[vertices[-1]]
            expected = initial if length % 2 else I - initial
            item.update({"first_pin": sorted(initial), "last_pin": sorted(last),
                         "expected_last_pin": sorted(expected), "passes": last == expected})
            if not item["passes"]:
                failures.append("K path endpoint pins incompatible")
        current = initial
        for e in walk:
            labels[e] = set(current)
            current = I - current
    result = {"pinned_completion_exists": not failures, "K_components": components,
              "obstructions": failures,
              "unconditional_odd_cycle_obstruction": "odd closed K cycle" in failures,
              "path_pin_failure_alone_is_not_global_incompatibility":
                  "K path endpoint pins incompatible" in failures and "odd closed K cycle" not in failures,
              "labelled_pinned_completion_count": 0 if failures else 6 ** z,
              "scope": "fixed original residual-demand-one colours and slotwise boundary pairs"}
    if not failures:
        for e in edges:
            if e in p:
                labels[e].add("a")
            if e in b:
                labels[e].add("b")
        validate(edges, internal, labels)
        for e, ends in edges.items():
            if not set(ends) <= internal:
                assert labels[e] == old[e]
        result["constructed_row_labels"] = {e: "".join(sorted(s)) for e, s in labels.items()}
    return result


def cube():
    edges, labels = {}, {}
    for side in "TB":
        for i, j, s in [(0, 1, "ae"), (1, 2, "bc"), (2, 3, "af"), (3, 0, "bd")]:
            eid = f"{side}{i}-{side}{j}"
            edges[eid], labels[eid] = (f"{side}{i}", f"{side}{j}"), set(s)
    for i, s in enumerate(["cf", "df", "de", "ce"]):
        eid = f"T{i}-B{i}"
        edges[eid], labels[eid] = (f"T{i}", f"B{i}"), set(s)
    return edges, {f"{side}{i}" for side in "TB" for i in range(4)}, labels


def two_pole():
    edges = {"01": ("0", "1"), "12": ("1", "2"), "23": ("2", "3"),
             "30": ("3", "0"), "r2": ("r", "2"), "1s": ("1", "s"),
             "s3": ("s", "3"), "rs": ("r", "s"),
             "port0": ("0", "@0"), "portr": ("r", "@r")}
    text = {"01": "ae", "12": "bc", "23": "af", "30": "bd", "r2": "de",
            "1s": "df", "s3": "ce", "rs": "ab", "port0": "cf", "portr": "cf"}
    return edges, set(["0", "1", "2", "3", "r", "s"]), {e: set(s) for e, s in text.items()}


def main():
    e, v, old = cube()
    top = {x for x in e if x.startswith("T") and "-T" in x}
    bottom = {x for x in e if x.startswith("B") and "-B" in x}
    single = solve(e, v, old, top)
    both = solve(e, v, old, top | bottom)
    assert not single["pinned_completion_exists"]
    assert len(single["K_components"]) == 2
    assert both["pinned_completion_exists"] and both["labelled_pinned_completion_count"] == 36
    assert sorted(x["length_including_semiedges"] for x in both["K_components"]) == [4, 4]
    free = dict(old)
    for eid in top:
        free[eid] = set("cd" if eid in ("T0-T1", "T2-T3") else "ab")
    for eid in bottom:
        free[eid] = set("ac" if eid in ("B0-B1", "B2-B3") else "bd")
    for i in range(4):
        free[f"T{i}-B{i}"] = set("ef")
    validate(e, v, free)
    assert {x for x in e if "b" in free[x]} == {x for x in e if "b" in old[x]}
    assert ({x for x in e if "a" in free[x]} ^ {x for x in e if "a" in old[x]}) == top
    pe, pv, pl = two_pole()
    positive = solve(pe, pv, pl, {"01", "12", "23", "30"})
    assert positive["pinned_completion_exists"]
    assert positive["labelled_pinned_completion_count"] == 1
    assert [x["length_including_semiedges"] for x in positive["K_components"]] == [7]
    cert = json.loads((ROOT / "bf-pulse3-distance-certificate.json").read_text())
    ge = {f"e{i}": tuple(ends) for i, ends in enumerate(cert["edges"])}
    rows = [{tuple(ends) for ends in row} for row in cert["six_supplied_perfect_matchings"]]
    gl = {eid: {"abcdef"[i] for i, row in enumerate(rows) if ends in row}
          for eid, ends in ge.items()}
    ga = {eid for eid, ends in ge.items() if "a" in gl[eid] and "b" not in gl[eid]
          and all(x.startswith("a:") for x in ends)}
    gb = {eid for eid, ends in ge.items() if "b" in gl[eid] and "a" not in gl[eid]
          and all(x.startswith("a:") for x in ends)}
    negative = solve(ge, set(cert["vertices"]), gl, ga | gb)
    assert not negative["pinned_completion_exists"]
    assert sum(x["closed"] and x["length_including_semiedges"] % 2 for x in negative["K_components"]) == 2
    output = {"method": "Direct fixed-witness incidence checks and constructive path tracing; no PM/cover search",
              "cube_top_only_pinned_failure": single,
              "cube_top_only_unpinned_completion_valid": True,
              "cube_both_pinned_success": both,
              "two_pole_input_edges": pe, "two_pole_input_labels": {x: "".join(sorted(s)) for x, s in pl.items()},
              "two_pole_boundary_preserving_success": positive,
              "G20_single_component_pinned_failure": negative}
    target = ROOT / "bf-pulse4-completion-certificate.json"
    target.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"certificate": target.name, "cube_both_count": 36,
                      "cube_top_pinned": False, "cube_top_unpinned": True,
                      "two_pole_count": 1, "G20_odd_K_cycles": 2}))


if __name__ == "__main__":
    main()
