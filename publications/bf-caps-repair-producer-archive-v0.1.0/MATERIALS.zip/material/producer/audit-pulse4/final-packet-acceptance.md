> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Pulse 4 final mathematical and program-scope acceptance

Date: 2026-10-03. Reviewer: the fresh-context same-model agent that wrote `completion-independent-review.md`. This is not human scientific acceptance, external-model review, publication approval, or a novelty assessment.

## Outcome

Accepted the final mathematical content and reproduction scope of:

* `bf-pulse4-four-occurrence-completion.md`;
* `bf-pulse4-completion-handover.md`;
* `check_bf_four_completion.py` and `bf-pulse4-completion-certificate.json`.

No mathematical or program-scope blocker remains for the stated pulse goal: an explicit sufficient condition for four-occurrence completion after a partial internal-component switch in a genuine zero-port BF row, preserving slotwise boundary masks.

## Proof and scope checks

The demand graph construction is correct: m=0 edges carry no residual colour, m=1 edges are retained-D edges, and K uses m=2 edges. Every internal K vertex has degree one or two. Zero-port a,b ensure that each boundary semiedge belongs to K and carries a two-colour pin. Counting semiedges in path length gives the endpoint equation kappa^(L-1), including the length-one case. The path/cycle constructor proves the fixed-original-singleton and fixed-boundary iff; its labelled completion count 6^z is analytic and not a search count.

The two failure meanings are now stated correctly. An odd closed K cycle excludes **every** residual completion of the target pair, independently of singleton pins. A failure caused only by the original path pins excludes the fixed-singleton class and may be repaired by recolouring retained singleton edges. The exact fully free reduction uses one colour per m=1 **edge**, shared at its two endpoints, distinct incident singleton colours at each retained-D vertex, fixed port pairs, and all path constraints simultaneously. Its existential t-assignment condition is neither assumed satisfiable nor searched in this packet.

The uniform-x exchange is sufficient, works simultaneously on vertex-disjoint components with possibly different residual colours, and preserves all exterior labels. Its iff applies only when all I-colour incidences outside the selected components are fixed. Boundary masks alone impose a weaker requirement. The cube examples correctly distinguish these completion classes.

The odd-cycle capacity argument and weighted decomposition are correct with the stated zero-port/cycle-only hypotheses. The existence of at least one ineligible component is conditional on a closed odd Q_b-complement cycle existing. The weight lower bounds do not force one component to carry all obligations and do not provide a sufficient completion by themselves.

The subshore gluing statement uses an original genuine BF row of the larger colourable shore L and preserves each slot's interface mask. It does not supply a BF cover of a counterexample host. The eight-cycle target remains conditional on an actual chosen C8 and a successful completion test.

Neither draft asserts that full exact-XII support/minimum-host assumptions force the completion condition, nor that they fail to force it. The handover's potentially ambiguous wording was replaced and directly verified as: “This pulse does not prove that complete support or minimum-host assumptions force that condition.” The cube and two-pole remain local scope witnesses, and G20 retains its BF cover and cyclic two-cut limitations. The earlier configuration-forcing gaps remain open.

## Fixed program checks and evidence

I read the constructor and output, then ran `python3 check_bf_four_completion.py` on the final revised code. It passed and reported cube-both count 36, cube-top pinned failure with an explicit free completion, two-pole count 1, and two odd K pentagons for the fixed G20 switch. The JSON distinguishes unconditional odd-cycle obstructions from path-only failures. The code reads the frozen pulse-3 G20 certificate without modifying it and performs no PM/cover search, SAT, graph census, parameter enumeration, or search for free t assignments.

I also independently checked the supplied two-pole using direct colour-incidence counts, rather than the constructor's validation function. Old and new labels contain each of the six colours exactly once at all six internal vertices; a and b are zero-port; b is unchanged; a changes exactly on the specified C4; both port labels are unchanged; and the seven K-edge pairs alternate cf,de,cf,de,cf,de,cf. Evidence is `two-pole-independent-check.json`. The independently checked cube witness is `cube-fixed-witness-check.json`, and the independent proofs and scope examples are in `completion-independent-review.md`.

This acceptance covers mathematical content and fixed reproduction scope. It does not independently certify original-unit process ownership, historical upstream premises, the forthcoming closure metadata or manifest hashes, Note 230's broader prerequisite chain, release decisions, or novelty. No wider computation or source search was performed during this review.

The assigned review is complete and stops here. The parent may append closure metadata and generate the manifest without changing the accepted mathematical content.
