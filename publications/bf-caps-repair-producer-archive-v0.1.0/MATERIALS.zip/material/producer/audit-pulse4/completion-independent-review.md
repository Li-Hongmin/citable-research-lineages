> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Pulse 4 independent mathematical review: local BF completion

Date: 2026-10-03. Reviewer: fresh-context agent of the same model family. This is not human review or external-model review. I derived the local argument independently before consulting the pulse-3 text for terminology. No novelty assessment is made. This file does not modify the first three packets.

## Verdict and precise scope

The proposed uniform residual-colour condition is correct as a sufficient condition. It is also necessary for the narrowly specified completion class in which the other four colours are fixed on **every edge and semiedge outside the selected component**, the b-occurrence is fixed everywhere, and the a-occurrence is changed only by the specified component flip. Fixing the multipole's external boundary alone is weaker and does not yield this necessity statement.

For several selected components, which are vertex-disjoint components of the symmetric difference, their uniform residual colours may differ. All prescribed switches can be carried out simultaneously, preserving the complete row's boundary. Removing every eligible component then leaves at least two a-edges on each closed odd complementary cycle of b. The conclusion that there must be an ineligible component requires that at least one such odd cycle exists. It is false without that existence hypothesis.

Nothing in the proof establishes that full exact Case XII, a minimum-host condition, or any previously conditional configuration forces uniformity, an eligible component, or a desired weight concentration.

## Setup

Let R=(Q_a,Q_b,Q_c,Q_d,Q_e,Q_f) be a genuine six-perfect-matching double-cover row of a cubic graph or cubic multipole L. For multipoles, each occurrence covers each internal vertex once, and each edge or boundary semiedge has row load two. Colours denote occurrence slots; they need not denote distinct underlying perfect matchings. Write I={c,d,e,f}.

Give each edge or semiedge its unordered pair of distinct occurrence colours. At an internal cubic vertex the three incident labels partition the six colours into three pairs. Let D=Q_a symmetric-difference Q_b. If both a and b are zero-port occurrences, D consists entirely of vertex-disjoint internal alternating cycles. More generally the following local proof applies to any internal cycle component of D, even if other components are boundary paths.

On an internal component C, an a-only edge has label {a,y}, with y in I, and a b-only edge has label {b,x}, with x in I. At each vertex of C, x differs from y and the third incident edge has label I minus {x,y}. That third edge lies outside C; it can be an internal chord or a boundary semiedge. These facts follow from the vertex partition, not from an extra support assumption.

Call C eligible when x is one constant colour c_0 in I on all its b-only edges. The condition is row-dependent and directed: eligibility for flipping a while retaining b need not equal eligibility for flipping b while retaining a.

## Sufficient condition: an explicit completion

Assume C is eligible with colour c_0. Every b-only edge of C has label {b,c_0}. Every a-only edge has label {a,y} with y different from c_0, because it meets a b-only edge and incident colour pairs are disjoint. Thus C is an alternating cycle of the a and c_0 occurrences: a occupies precisely the a-only edges, and c_0 occupies precisely the b-only edges.

Exchange a and c_0 on the edges of C. At each vertex of C both colours retain exactly one incident edge; all other colours retain their incidences. Away from C nothing changes. More explicitly,

    Q_a' = (Q_a \ E(C)) union (Q_b intersection E(C)),
    Q_c0' = (Q_c0 \ E(C)) union (Q_a intersection E(C)),
    Q_b' = Q_b,

and the other three residual occurrences are unchanged. Every changed label still has two distinct colours, so every edge retains load two. All six occurrences remain actual perfect matchings. The a,b pair therefore cooccurs in the explicitly supplied new BF row.

Because C contains no boundary semiedge, every occurrence's complete boundary mask is unchanged. If the row is a row on a larger shore L containing the local shore under discussion, the same internal swap can be performed directly in L. It therefore preserves all boundary semiedges of L, as well as any semiedges of the local shore not in C. This is a statement about a BF-colourable shore row, not a BF cover of a hypothesized counterexample host G.

## Necessity with fixed exterior residual incidences

Suppose a new row has Q_b unchanged, Q_a changed exactly by flipping C, and the four I-colour incidences fixed on every edge and semiedge outside C. We prove C eligible in the original row.

In the new row each original b-only edge on C belongs to both a and b, so its label is {a,b} and it has no I-colour. Each original a-only edge on C belongs to neither a nor b and must have a two-colour label contained in I. At a vertex of C, let x be the original residual colour on its b-only edge, y the original residual colour on its a-only edge, and T the third incident edge. Originally T has residual label I minus {x,y}. Its I incidences are fixed in the new row. Since a and b now both occupy the b-only edge, the new label of the a-only edge must be exactly {x,y}.

Now consider an original a-only edge uv. Its original y is the same at u and v, because it is one edge label. Write x_u,x_v for the original residual colours of the b-only edges incident with u,v. The new label of uv must be both {x_u,y} and {x_v,y}. As x_u and x_v differ from y, equality implies x_u=x_v. Therefore the residual colours on the two neighbouring b-only edges agree. Propagating around C gives one constant c_0 on every b-only edge. This proves necessity.

Combining the two arguments gives an iff for this fixed-exterior completion problem. The proof does not require the new row's residual labels on C to be specified in advance; their required values are forced at the vertices.

## Several components

Let S be any set of internal components, each eligible with its own c_i. On C_i swap a and c_i. Distinct D components have disjoint vertex sets, so no vertex is subjected to two switches. This remains valid when different components use the same residual colour, or when an edge outside D joins vertices on different components: that edge's label is unchanged, and each endpoint's partition remains valid separately.

The resulting row retains b, flips a on exactly the selected components, preserves all exterior labels and all boundary masks, and has

    Q_a' symmetric-difference Q_b = D \ union_{i in S} E(C_i).

Necessity also extends componentwise under fixed exterior I incidences for the union of the selected components, because each vertex's third edge lies outside that union.

## Boundary-only necessity fails: an explicit cube example

This example is a scope counterexample, not a counterexample to the proposed sufficient condition. Let L be the cube: two squares T_0T_1T_2T_3T_0 and B_0B_1B_2B_3B_0, with vertical edges T_iB_i. It is a closed cubic graph, so its external boundary is empty. On both squares assign labels

    edge 01: {a,e}; edge 12: {b,c};
    edge 23: {a,f}; edge 30: {b,d}.

Give the vertical edges, in index order 0,1,2,3, labels

    {c,f}, {d,f}, {d,e}, {c,e}.

At every vertex the three labels partition {a,b,c,d,e,f}, so these labels describe a genuine BF row. Its a,b difference consists of the two square cycles. On the top component the b-only residual colours are c and d, hence it is ineligible.

Nevertheless flip a on the top square alone, retain b everywhere, and use the following completed row labels:

    top 01 and 23: {c,d}; top 12 and 30: {a,b};
    bottom 01 and 23: {a,c}; bottom 12 and 30: {b,d};
    all vertical edges: {e,f}.

Again every vertex has all six colours exactly once. This is a genuine completion of the requested a flip, and the b-occurrence is unchanged. Boundary is preserved, since it is empty. Residual labels outside the top component changed, exactly as excluded by the fixed-exterior necessity theorem. Thus a boundary-preserving completion can exist without original uniform-x eligibility.

The supplied witness was directly checked in `cube-fixed-witness-check.json`: both labelings partition the six colours at all eight vertices, b is fixed, a flips only on the top square, and its original b-only residual colours are c,d. This is one fixed incidence check, not an enumerative search.

## Odd-cycle constraints and weighted obligations

Let O be any internal closed odd cycle avoiding Q_b, of length 2r+1. In any genuine row containing Q_a' and Q_b, each of the other four occurrences uses at most r cycle edges. Exact double coverage gives

    4r+2 = |Q_a' intersection E(O)| + sum_{h in I}|Q_h' intersection E(O)|
          <= |Q_a' intersection E(O)| + 4r,

so |Q_a' intersection E(O)|>=2. This counts edges of O, irrespective of matching chords or semiedges. The argument does not apply to odd open complementary paths.

Assume D has only internal cycle components C_1,...,C_m, as holds for two zero-port occurrences. Define

    w_i(O)=|Q_a intersection E(C_i) intersection E(O)|.

Every Q_a edge on O lies in D, since O avoids Q_b. After flipping a on a subset S of components,

    |Q_a' intersection E(O)| = sum_{i not in S} w_i(O).

If S consists of eligible components, the explicit simultaneous completion proves, for each O,

    sum_{i not in S} w_i(O) >= 2.

In particular, if E denotes **all** eligible components and N all ineligible components, then

    sum_{i in N} w_i(O) >= 2,
    sum_{i in E} w_i(O) <= sum_i w_i(O)-2.

Thus each existing closed odd complementary cycle has at least two original a-edges belonging to ineligible components, although these edges can belong to one component or several. At least one ineligible component exists if such an O exists. More generally any desired target that retains components T requires sum_{i in T}w_i(O)>=2 for every O; retaining just C_j requires w_j(O)>=2 for every O. These inequalities remain necessary only and do not certify a completion when the proposed deletions include ineligible components.

If D also has boundary paths, the internal-switch theorem remains true, but the displayed cycle-only weight decomposition must be replaced by

    |Q_a' intersection E(O)|
       = |Q_a intersection E(O) outside the selected internal cycles| >= 2,

or by an expanded sum including the contributions of every retained path component. One cannot silently omit those path weights.

Without any closed odd complementary cycle, all components can be eligible. For example, double each of the three perfect matchings in a proper three-edge-colouring of the cube. Choose a,b from two different edge colours and c_0 as the second occurrence of the b edge colour. Then every a,b difference component is eligible with c_0, all can be removed simultaneously, and the completed a,b occurrences coincide. Their complement consists of even cycles, so there is no odd-cycle contradiction. Repeated occurrences are allowed by the row definition.

## Additional independent review: residual demand graph criterion

The parent supplied this stronger analytic criterion after the review above. It is correct with the following explicit hypotheses and restrictions. I did not consult Note 230 or search for related literature; I verify the stated criterion directly and make no historical or novelty claim.

Let H be a loopless cubic graph or cubic multipole carrying the original genuine row, with a,b both zero-port. Flip a on a chosen set S of internal D components to obtain P, and retain Q_b. The completion problem now fixes the original I-colour on every residual-demand-one edge and fixes the original I-colour pair on every boundary semiedge. It allows proper residual-demand-two edges to recolour freely. This is a different, broader restriction than fixing all I incidences outside the selected components.

For every proper edge or boundary semiedge define

    m(e)=2-1_P(e)-1_Qb(e).

At each internal vertex the total residual demand is four. The cases are exact:

* If P and Q_b use the same edge, that edge has m=0 and the other two have m=2.
* If they use different edges, each used edge has m=1 and the third has m=2.

The m=1 edges are precisely the old a-only and b-only edges on retained D components. Their fixed original I colours at any internal endpoint are x,y with x different from y. The m=0 edges include the original common a,b edges and the old b-only edges on flipped components; none carries any residual colour. Because both occurrences are zero-port, every boundary semiedge has m=2.

Form K from the m=2 edges and semiedges, extending each semiedge to a separate auxiliary leaf. An internal vertex has K-degree two in the first case above and degree one in the second; an auxiliary boundary leaf has degree one. Thus K components are closed cycles or paths, with no isolated internal vertices. Parallel edges can yield a two-edge cycle, which is correctly admitted as even.

At an internal degree-one endpoint v, pin its K-edge pair to

    S_v=I minus {x_v,y_v},

where x_v,y_v are the fixed colours on the two m=1 edges at v. At an auxiliary leaf, pin its K-edge pair to the original semiedge label, which is an I two-element set. If a one-edge path has pins from both endpoints, both apply to the same edge. Define the complement involution kappa(A)=I minus A on the six two-element subsets of I.

**Criterion.** A completion in this pinned class exists iff every closed component of K has even length and every path with L edges and endpoint pins S,T satisfies

    T = kappa^(L-1)(S).

The length L includes all boundary semiedges after extension. For example a one-edge path requires identical pins; a two-edge path requires complementary pins. If the criterion holds and K has z closed cycles, there are exactly 6^z labelled residual completions in this pinned class; paths contribute one choice each. This count treats c,d,e,f as fixed occurrence slots, and does not quotient by their permutations.

**Necessity.** A completed residual row assigns each m=2 edge exactly two distinct colours from I. At a K-degree-two internal vertex, those two incident pairs must partition I, so they are complementary. At a K-degree-one internal vertex the fixed m=1 colours force the stated pair. The prescribed boundary labels force the auxiliary-leaf pins. Propagating complements along a path gives the endpoint condition. Going around a closed K cycle gives A=kappa^L(A). No two-element subset equals its complement, so L must be even.

**Sufficiency.** On each pinned path start with its first pin and alternate A,kappa(A) along successive edges; the endpoint condition makes the final pin hold. On each even cycle choose any of the six I two-element subsets on one specified edge, and alternate it with its complement around the cycle. Fix the original colour on each m=1 edge and place no I colour on m=0 edges. At every internal vertex each of the four residual colours occurs exactly once, by the two cases above. Each residual colour consequently defines a perfect-matching occurrence of the multipole. Each edge has residual load m, so adding P and Q_b yields load two everywhere. The six boundary masks agree slot by slot with the original row. Choices on distinct K cycles are independent and distinguish labelled completions, proving 6^z.

If H is a subshore of a BF-colourable shore L, keeping all six boundary masks of H fixed permits gluing to the unchanged original exterior of L. Each occurrence is still an actual matching across the interface, giving a genuine row of L with its full original boundary masks and hence its original allowed boundary type. This does not establish a BF row of a different counterexample host. If H=L the gluing step is unnecessary.

The zero-port assumption is material to this formulation: it ensures every boundary semiedge has demand two and every terminal auxiliary leaf carries a two-colour pin. For occurrences with nonzero port masks, boundary demand can be zero or one; additional singleton boundary conditions require a revised formulation. Internal-cycle swaps alone still preserve those occurrences' masks, but the present all-port-pair criterion must not be applied verbatim.

### How the two criteria differ, and where the pinned criterion stops

Every uniform-x simultaneous switch supplies a completion of the pinned demand problem: it preserves all residual labels outside the flipped components and therefore in particular preserves the retained m=1 colours and the boundary pins. The demand-graph test can also succeed for ineligible components because it allows other m=2 proper edges to recolour.

The cube witness makes both distinctions concrete. If both its square D components are flipped, P=Q_b. There are no m=1 edges or boundary pins. K is the union of the two even four-cycles

    T0-T1-B1-B0-T0 and T2-T3-B3-B2-T2.

The criterion succeeds (36 labelled residual completions), although both original D square components have nonuniform b-only colours c,d. Thus the stronger criterion is strictly broader than uniform-x eligibility.

If only the top square is flipped, the bottom D component is retained and all its original m=1 colours are pinned. The two K components are three-edge paths joining B0 to B1 and B2 to B3 through the top square. Their endpoint pins are respectively

    at B0: {c,f}; at B1: {d,f};
    at B2: {d,e}; at B3: {c,e}.

Since L=3, the path criterion requires equal pins at the two endpoints; both paths fail it. Therefore no fixed-m=1 completion exists. Yet the explicit cube completion earlier in this file does exist, because it changes retained bottom m=1 colours. A path-pin failure for the original singleton colours therefore excludes only that pinned class and need not exclude every BF completion with the same a,b pair or boundary masks. Conversely success is a genuine explicit BF-completion certificate, which is stronger than satisfying odd-cycle weights alone.

### Refined failure scope and free-singleton reduction

An odd closed K cycle is a stronger obstruction than a path-pin mismatch. Every vertex on such a K cycle has degree two in K and no m=1 edge. In **any** four-occurrence completion its two K-edge pairs must be complementary, regardless of any singleton recolouring elsewhere. Odd-cycle propagation is impossible. Therefore an odd K cycle excludes every four-occurrence completion of the prescribed P,Q_b, even when m=1 colours may change. The limited scope above applies to failures caused solely by the original singleton pins.

The following exact reduction of the fully free singleton problem is also correct. Assign a colour t_e in I to each m=1 edge e, with one global value for that edge (the same at both endpoints). Require the two incident singleton colours to differ at each retained-D vertex. Pin each internal degree-one K endpoint to I minus its two incident t values and retain every original boundary-pair pin. Then a completion preserving all slotwise boundary masks exists iff every K cycle is even and **there exists one such global t assignment satisfying every K path's endpoint parity equation simultaneously**. Necessity extracts t_e from a completed row and uses the same propagation proof. Sufficiency fixes that t assignment and uses the path/cycle construction already proved. This reduction neither asserts that a suitable t assignment exists nor performs a search for it.

## Review status and limits

The candidate local sufficiency/necessity theorem is mathematically accepted subject to the precise scopes above. The residual demand-graph criterion is also accepted for the stated fixed-m=1 and fixed-boundary-pin completion class. The odd-cycle conclusion is accepted with an explicit odd-cycle existence premise, and the weighted form is accepted with the cycle-only or path-inclusive qualification. A final draft should distinguish fixed exterior labels from fixed row boundary, original-row eligibility from arbitrary completion, and genuine shore rows from counterexample-host covers. No wider search, SAT enumeration, host classification, remote computation, or paid service was used.

Final-draft mathematical and program-scope acceptance is complete and recorded in `final-packet-acceptance.md`. The assigned review stops here.
