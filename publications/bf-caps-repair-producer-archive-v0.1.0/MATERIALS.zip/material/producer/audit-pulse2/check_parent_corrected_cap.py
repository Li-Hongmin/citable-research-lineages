# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Independent read-only validation of parent's two universal true-cap certificates."""
import json
from collections import defaultdict
from itertools import combinations,product
def edge(a,b):return tuple(sorted((str(a),str(b))))
marks={'X':(1,3),'Y':(2,5),'Z':(4,6),'W':(1,6)}
rs=json.load(open('corrected-cap-two-tables.json'))
assert len(rs)==2
results=[]
for r in rs:
    S=r['allowed_S'];Sedges={edge(a,b) for a,b in zip(S,S[1:]+S[:1])}
    T={edge(a,b) for a,b in combinations('eXYZW',2)}-Sedges
    assert T=={edge(a,b) for a,b in r['physical_T_edges']}
    c={}
    for a,b,col in r['edge_colours']:
        if b is None:b='e' if a=='bare' else 'p'+a[1:]
        e=edge(a,b);assert e not in c;c[e]=col
    expected=set()
    for i in range(1,6):expected|={edge(i,f'u{i}'),edge(i+1,f'u{i}'),edge(f'u{i}',f'p{i}')}
    for j,(a,b) in marks.items():expected|={edge(a,f't{j}'),edge(b,f't{j}'),edge(f't{j}',f'bar{j}')}
    expected|={edge('bar'+a,'bar'+b) for a,b in T}|{edge('bare','e')}
    assert set(c)==expected
    adj=defaultdict(list)
    for (a,b),col in c.items():adj[a].append(col);adj[b].append(col)
    internal=[v for v,cols in adj.items() if len(cols)>1]
    assert len(internal)==20
    assert all(sorted(adj[v])==[1,2,3] for v in internal)
    signature=[adj[v][0] for v in ['e','p1','p2','p3','p4','p5']]
    assert signature==r['signature']==[1,2,2,1,3,3]
    pairs=[('p3','p4'),('p3','p5')]+list(product(['e','p1','p2'],['p4','p5']))
    for a,b in pairs:
        ca,cb=adj[a][0],adj[b][0]
        assert sorted([ca,cb,6-ca-cb])==[1,2,3]
    results.append({'allowed_S':S,'physical_T_complement_verified':True,'internal_vertices_checked':20,'signature':signature,'joined_d_pairs_checked':pairs})
with open('audit-pulse2/parent-corrected-cap-check.json','w') as f:json.dump(results,f,indent=2)
print(json.dumps(results))
