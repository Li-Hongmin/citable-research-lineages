# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Bounded, direct incidence checks; no host search, SAT, or support inference."""
from itertools import combinations
from collections import defaultdict
import json

def edge(a,b): return tuple(sorted((str(a),str(b))))
marks={'X':(1,3),'Y':(2,5),'Z':(4,6),'W':(1,6)}
core_edges=set()
for i in range(1,6):
    core_edges |= {edge(i,f'u{i}'),edge(i+1,f'u{i}'),edge(f'u{i}',f'p{i}')}
for j,(a,b) in marks.items():
    core_edges |= {edge(a,f't{j}'),edge(b,f't{j}'),edge(f't{j}',j)}

def components(edges):
    adj=defaultdict(list)
    for a,b in edges: adj[a].append(b);adj[b].append(a)
    seen=set(); out=[]
    for a in adj:
        if a in seen: continue
        stack=[a]; vs=set()
        while stack:
            x=stack.pop()
            if x in vs: continue
            vs.add(x);stack.extend(adj[x])
        seen |= vs
        ends=sorted(x for x in vs if len(adj[x])==1)
        out.append((ends,sum(len(adj[x]) for x in vs)//2))
    return out

expected={('Y',2):[(['Y','p5'],4),(['p1','p2'],4),(['p3','p4'],10)],
          ('Y',5):[(['Y','p1'],4),(['p2','p3'],10),(['p4','p5'],4)],
          ('W',1):[(['W','p4'],6),(['p1','p3'],6),(['p2','p5'],6)],
          ('W',6):[(['W','p2'],6),(['p1','p4'],6),(['p3','p5'],6)]}
paths={}
for (j,r),want in expected.items():
    selected={edge(f't{k}',k) for k in marks if k!=j}|{edge(f't{j}',r)}
    for i in range(1,6):
        child=i if i<r else i+1
        selected.add(edge(f'u{i}',child))
    got=components(core_edges-selected)
    assert sorted(got)==sorted(want),(j,r,got)
    paths[f'{j}:{r}']=got

def pairings(xs):
    if not xs: yield [];return
    a=xs[0]
    for i,b in enumerate(xs[1:],1):
        for rest in pairings(xs[1:i]+xs[i+1:]): yield [(a,b)]+rest

# Check the matching-level port-connectivity argument for all 15 shore pairings.
pairing_witnesses=[]
for shore in pairings(['e','p1','p2','p3','p4','p5']):
    successful=[]
    for (j,r),exterior in expected.items():
        glued={edge(a,b) for a,b in shore}|{edge(*ends) for ends,_ in exterior}
        # A coincident pair represents a two-edge closed component, not one edge.
        duplicate=any(edge(*ends) in {edge(a,b) for a,b in shore} for ends,_ in exterior)
        cycles=[c for c in components(glued) if not c[0]]
        if not duplicate and not cycles: successful.append(f'{j}:{r}')
    assert successful,shore
    pairing_witnesses.append({'shore':shore,'no_mixed_cycle_roots':successful})

# Direct verification of the Note 642 complete opposite-pole colourings.
halves1=[(1,3),(1,2),(3,1),(2,3),(2,3),(2,1),(2,1),(3,2),(3,1)]
halves2=[(3,2),(3,1),(2,3),(2,1),(3,1),(1,3),(1,2),(1,2),(2,3)]
def colouring(halves,order,pentcol):
    c={}
    subdivisions=[(f'u{i}',i,i+1,f'p{i}') for i in range(1,6)]
    subdivisions += [(f't{j}',a,b,f'bar{j}') for j,(a,b) in marks.items()]
    for (v,a,b,third),(x,y) in zip(subdivisions,halves):
        c[edge(v,a)]=x;c[edge(v,b)]=y;c[edge(v,third)]=6-x-y
    for a,b,col in zip(order,order[1:]+order[:1],pentcol): c[edge(f'bar{a}',f'bar{b}')]=col
    c[edge('bare','e')]=3
    return c
c1=colouring(halves1,['e','X','Y','W','Z'],[1,2,1,3,2])
c2=colouring(halves2,['e','X','W','Y','Z'],[1,3,2,1,2])
def reflect_vertex(v):
    if v in map(str,range(1,7)):return str(7-int(v))
    if v.startswith('u') or v.startswith('p'):return v[0]+str(6-int(v[1:]))
    return {'tX':'tZ','tZ':'tX','barX':'barZ','barZ':'barX'}.get(v,v)
def reflected(c):return {edge(reflect_vertex(a),reflect_vertex(b)):col for (a,b),col in c.items()}
cr=reflected(c1)
alternating=['e','bare','barX','tX','3','u3','4','tZ','barZ','barW','barY','tY','5','u4','p4']
switched=dict(c1)
sequence=[c1[edge(a,b)] for a,b in zip(alternating,alternating[1:])]
assert sequence==[3,1]*7,sequence
for a,b in zip(alternating,alternating[1:]): switched[edge(a,b)]=4-switched[edge(a,b)]
crs=reflected(switched)
def valid(c,joined=None):
    incident=defaultdict(list)
    for (a,b),col in c.items():
        for v in (a,b):
            w='d' if joined and v in joined else v
            if w in {'e','p1','p2','p3','p4','p5'}:continue
            incident[w].append(col)
    if joined:
        cols=incident['d'];assert len(cols)==2 and len(set(cols))==2
        cols.append(6-sum(cols))
    assert all(sorted(cols)==[1,2,3] for cols in incident.values()),incident
    return len(incident)
for c in [c1,c2,cr,switched,crs]:assert valid(c)==20
certificates=[]
for order,cols in [('S1',[c1]),('S2',[c2,cr,crs])]:
    for joined in [('p3','p4'),('p3','p5')]+[(a,b) for a in ['e','p1','p2'] for b in ['p4','p5']]:
        witness=None
        for i,c in enumerate(cols):
            try: assert valid(c,joined)==21
            except AssertionError:continue
            witness=i;break
        assert witness is not None,(order,joined)
        certificates.append({'order':order,'joined_ports':joined,'certificate_index':witness})

# Support-state/missing-pair orientation uses colour occurrences, not names A/B.
labels={'A':{'Da','Db'},'B':{'K','J'},'C':{'J','Db'},'D':{'K','Da'},'a':{'Q1','Q2'}}
def type_of(boundary):
    uses={col:[] for col in ['Da','Db','K','J','Q1','Q2']}
    for pos,label in enumerate(boundary):
        for col in labels[label]: uses[col].append(pos)
    return [sorted(set(range(5))-set(v)) for v in uses.values() if len(v)==3]
assert type_of(['a','A','A','A','B'])==[[0,4],[0,4]]
assert type_of(['a','A','A','C','D'])==[[0,3],[0,4]]

# All local cases in Note 564's R* terminal-independence proof.
P={frozenset(map(int,s)) for s in ['13','14','24','35','45']}
Q={frozenset(map(int,s)) for s in ['12','15','23','25','34']}
all5=set(range(1,6))
assert [T for T in combinations(range(1,6),3) if len({frozenset(p) in P for p in combinations(T,2)})==1]==[(1,2,5)]
for ij in combinations(range(1,6),2):
    T=all5-set(ij);pairs=[frozenset(p) for p in combinations(T,2)]
    if T=={1,2,5}:
        for z in T: assert frozenset(ij) in Q and frozenset(T-{z}) in Q
        continue
    minority=next(p for p in pairs if sum((p in P)==(r in P) for r in pairs)==1)
    for q in pairs:
        if q==minority:continue
        singleton_ports=list(minority)+list(q)
        assert len([z for z in singleton_ports if z not in minority])==1
        for slots in combinations(range(4),2):
            z=next(singleton_ports[k] for k in slots if singleton_ports[k] in minority)
            r=frozenset(T-{z})
            assert (r in P)==(q in P)

result={'519_four_exterior_root_paths':paths,'519_shore_pairings_checked':len(pairing_witnesses),
        '519_pairing_witnesses':pairing_witnesses,'642_original_wrong_cap_tables_local_validation_only':certificates,
        '641_row_missing_pairs_checked':['CD -> [aB]','AB -> (aC)(aD)'],
        '564_terminal_pairs_checked':10,'scope':'direct finite incidence only; not support certification or host/carrier audit'}
with open('audit-pulse2/support-interface-check.json','w') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k not in ['519_pairing_witnesses','519_four_exterior_root_paths','642_original_wrong_cap_tables_local_validation_only']},ensure_ascii=False))
