> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Final bounded handover interface acceptance

Reviewed 2026-10-03: task-5/bf-pulse2-interface-handover.md and bf-public-minimal-cap-colouring.md; read only the necessary 654/542 interfaces and pulse-1 checkpoint's independently verified 818-witness class. This is a manuscript-interface check, not another upstream-history audit or a new run of the finite enumeration.

## Decision

Accept the explicit conditional host-branch exclusion and the minimal public colouring lemma at the stated mathematical interface. No additional unstated mathematical gate was found between the explicitly assumed graph/row configuration and the contradiction. The broader claim that general exact Case XII forces this configuration remains unproved, and the documents correctly preserve that boundary. The one recommended notation correction was made by the parent and then verified below.

This acceptance is by a fresh-context agent using the same model. It is not human acceptance, independent-model external scientific review, novelty certification, or release approval. Nothing was published or modified in the original project.

## Exact configuration and vertex arithmetic

The host statement explicitly assumes a simple cubic girth-at-least-five cyclically-five-connected globally minimum BF counterexample, an actual cap-versus-L cyclic five-cut, complete exact-XII support on L, the specified central prism and six-port shore, the explicit fourteen-vertex B, an actual BF row with common F restriction N0 and all six selected carrier legs, the specified residual original-port labels, and the isolated-AB (0,9,2) exterior with exactly two crosses and two private P chords.

Those inputs are assumptions, not inferred from a generic exact-XII pole. Explicit B removes the need to import any assertion that conditional tightness is universal. The actual row is a BF colouring of L, not a BF cover of the counterexample host G.

Core exterior: six original core vertices + five tree subdivisions + four marked subdivisions = 15 vertices. Z has |B|+|F|=14+14=28 vertices. Therefore |L|=43 and the cap adds 5, giving |G|=48. U=B∪(F−{d_F}) has 14+13=27 vertices; H=G−U has 15+5+1=21. The nested boundary is the carrier leg a at d_F plus the other four original shore attachments, hence five host edges. U contains B's eight-cycle; H contains the unchanged core/cap cycles. Both sides exceed five vertices, so the global-minimum host classification selects Case XIII.

d_B denotes the explicit carrier vertex on 3−d_B−7, whereas d_F is the isolated exterior vertex. A cut mask “containing d_F” means containing the carrier leg a attached to d_F. The exceptional mask {b,d_B} consists of two carrier leg labels; neither notation identifies d_F with d_B. The documents now distinguish these correctly.

## Physical cap and orientation

The allowed-loop cycles S1=e−X−Y−W−Z−e and S2=e−X−W−Y−Z−e are correctly separated from their physical complements T1=e−Y−Z−X−W−e and T2=e−Y−X−Z−W−e. The public tables equal the previously independently checked actual-T edge certificates, and their common six-port signature is (1,2,2,1,3,3). Each possible AB join has A-colour 1 or 2 and B-colour 3; each possible CD join has colours 1 and 3. Hence every required true H is Tait.

For isolated AB, H cannot be R* because doubled Tait gives an ordinary [ij] loop. H=L* and U=R* follow from the exhaustive Case-XIII pair. This uses the unambiguous R* support, not the conflicting printed L* Appendix entries.

## Internal crosses and 09 prohibition

U's four original-port terminal vertices are p0,p9,q0,q2. Complete R* terminal independence makes them distinct and pairwise nonadjacent. Thus an N0 cross from q0 or q2 cannot end at p0 or p9, and the private chord p0p9 is absent.

If q1 has a cross, the actual all-terminal R* BF row supplies a matching colour selecting all five U semiedges, including those at p0,p9,q0,q2. Consequently q0 and q2 cannot match internally to q1, and q1 must use its cross. That cross cannot go to either already-covered P endpoint. Thus both cross ends belong to p1,...,p8, also when one Q cross is at the internal vertex q1. No selected-row surrogate is being used for this step: complete R* supplies the new all-terminal row on U.

## 654 → finite 818 class → 542

The explicit assumptions supply exactly the N0 incidence partition used in 654: P path vertices are covered by private N0 chords, the two crosses or carrier legs; Q has two distinct crossed vertices and one carrier-leg vertex; d_F has its leg. Girth forbids a private Q chord and supplies the chord and mixed-cycle restrictions in the finite class. The terminal argument above supplies internal cross ends and 09 absence.

654's alternating-switch argument therefore applies and forces the two P cross incidences to be partners in the path matching plus its private chords. It also forces the canonical mask {a, sole-Q-leg} to be one of the three exceptional pairs. No exceptional {b,d_B} orientation is silently assumed: all three exceptional masks are permitted, and their disjointness is sufficient.

This is precisely the pulse-1 finite class: P has vertices 0,...,9, two vertex-disjoint private chords spanning at least four path edges, no 09, distinct internal cross ends disjoint from chord ends, all three possible Q-cross vertex pairs and both assignments, proper girth at least five, and the alternating partnership. Pulse 1's independent 818-scope validation covers all such labelled fragments.

Its witness selects an endpoint-Q cross q−z, a P leg k, a proper matching of (P+C)−{z,k}, the remaining Q edge, and the d_F leg. Those six proper matching edges and two selected legs cover all fourteen F vertices exactly once and use no original shore port. The residual P graph has only even closed components; Q and isolated d_F have no closed component, and only one cross remains unselected, so no mixed closed component can form. The unused sole Q carrier leg reaches an original port, leaving at most one cut-to-cut path: q(N)≤1.

The witness mask {a,k} differs from the canonical exceptional mask {a,sole-Q-leg} and intersects it at a. Since the three exceptional pairs partition the six carrier legs, {a,k} is nonexceptional. The independently checked explicit-B carrier pairings and 519 supply 542's premise. 542 then forbids this actual two-cut matching with no odd exterior closed component and q≤1. This closes the specified branch.

## Notation correction completed

The initial handover used H first for the 21-vertex nested opposite pole and later wrote “H+C partners” without defining that local matching notation in the same document. The parent revised the standalone interface to distinguish:

“Put H_P={01,23,45,67,89} and let C_P be the two private P chords. By 654, the two P cross incidences are endpoints of the same path component of H_P∪C_P.”

The revised source explicitly defines H_P and C_P in its audited-654 interface paragraph and uses H_P∪C_P in the proof. I read and verified that change. This is a clarity correction, not a missing mathematical hypothesis. The public colouring candidate also now includes the relative reproducibility command; no publication operation was performed.

## Remaining limits

The proof depends on the published minimum-host classification and independently checked finite witness coverage, and does not re-prove the paper's exhaustive classification. It does not force the explicit B, common N0 row, first long-route labels, fourteen-vertex F or two-cross (0,9,2) profile in arbitrary exact-XII cases. It does not exclude other carriers, profiles or larger orders, nor resolve general Case XII or Berge–Fulkerson. The minimal public cap-colouring lemma is independent of those host assumptions and carries no general support claim. Release remains with the parent's coordinated user workflow.
