> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Bounded independent support-interface review

Date: 2026-10-03. Read-only project review; all outputs remain in task-5/audit-pulse2. No project edits, Git, HPC, SAT, other research lines, or full carrier-history audit. Same-model fresh-context review is not human acceptance.

## Decisive outcome

519's all-odd zero-shore theorem and 564's complete-R* terminal-independence theorem check out under their stated hypotheses. 641's genuine nested five-cut, CD loop orientation, and AB missing-pair calculation check out conditional on the genuine carrier, actual row and globally minimum BF-counterexample host assumptions. 642's displayed proof has a real support-to-geometry mapping error: it colours cap S, whereas the physical original pentagon is T=K5−S. The intended CD exclusion and AB orientation nevertheless follow after replacing those certificates by the parent's two explicit true-T-cap colour tables, which this reviewer independently checked edge by edge and vertex by vertex.

This is a repaired conditional deduction, not approval of 642's original displayed proof, nor a deduction that the fourteen-vertex carrier is forced in all exact-Case-XII poles.

## Source interface and two notation issues

Source: local editamacajova2026cycle.pdf, Definition 4.1 (pp.9–10), discussion pp.13–16, Proposition 4.4 p.17, Appendix XII p.21 and XIII p.22, Figure 7 p.16. PDF pages 16 and 22 were visually inspected, not inferred solely from pdftotext.

The state xy of a matching means the matching's triple boundary omits terminals x,y. A BF type (xy)(uv) names the missing pairs of the two triple colour occurrences. A loop [xy] means the two missing pairs coincide. An actual three-edge-colouring of an odd-order five-pole has boundary colour multiplicities 3,1,1; doubling its three colour classes gives the ordinary BF loop [xy], where x,y are its two lonely positions.

For the physical pentagon T on positions 1,2,3,4,5 in cyclic order, Appendix I–XII R* has ordinary loops [12],[23],[34],[45],[15]. Appendix XII L* has loops [13],[14],[24],[25],[35], the edges of its complementary five-cycle S. Therefore the allowed-loop cycle S is not the physical cap cycle T. In this branch:

- allowed S1=e-X-Y-W-Z-e has physical T1=e-Y-Z-X-W-e;
- allowed S2=e-X-W-Y-Z-e has physical T2=e-Y-X-Z-W-e.

Case-XIII R* is P×Q plus the all-terminal type (12345), for P={13,14,24,35,45}, Q={12,15,23,25,34}. It has no ordinary [ij] loop. It does have the special (12345) loop under the source's auxiliary-graph definition. Statements saying simply “loopless” require this distinction; the CD ordinary-loop orientation remains sound.

The printed Appendix XIII L* repeats 45 in its second clique where Figure 7 requires 25; it consequently repeats [45] and lists four types also present in R*. This is visible in the PDF itself. Figure 7 instead shows the two disjoint complete cliques on P and Q. Note 563 already acknowledges the discrepancy and deliberately uses Figure 7. R*'s own Appendix list and Figure 7 agree, so 564 does not depend on guessing a correction to R*.

## 519: all-odd shore interface

For any complete zero-port shore matching Q, each of the four rooted exterior masks glues independently to Q as an actual single triple-boundary matching. This is a Cartesian product of real matchings, not a presumption that those four matchings simultaneously belong to one BF cover.

I independently traced the four exterior complements from the stated tree 1−2−3−4−5−6 and marks X=13,Y=25,Z=46,W=16. They give precisely:

| Root | terminal exit | proper-port pairs and lengths |
|---|---|---|
| Y:2 | p5, length 4 | 12 length 4; 34 length 10 |
| Y:5 | p1, length 4 | 23 length 10; 45 length 4 |
| W:1 | p4, length 6 | 13 length 6; 25 length 6 |
| W:6 | p2, length 6 | 14 length 6; 35 length 6 |

Their interiors exhaust all fifteen exterior vertices, leaving no exterior cycle. For a shore pairing ep_a | f | g and any root exit p_b≠p_a, a mixed cycle can occur only when f or g equals an exterior proper-port pair: the open terminal path has already consumed at least one shore pair and one exterior pair. The four exits are distinct, leaving at least three b≠a choices. The eight exterior proper-port pairs are all distinct, so f and g can obstruct at most two roots. Hence one root has no mixed cycle. This combinatorial claim was also checked over all fifteen pairings of the six shore ports.

If all shore-only closed components were even, this root's complete triple complement would split into two actual matching colour classes. Doubling that Tait colouring yields [eY] or [eW], absent from the exact-XII allowed-loop relation. Thus every Q has an odd shore-only closed component. If two zero-port occurrences in one actual BF row shared Q, the four remaining colour occurrences would alternate complementary two-sets around that odd cycle, which is impossible. This proves their restrictions differ. The separate Tait-empty corollary follows by ordinary terminal Kempe moves around S, reaching eX or eZ and contradicting the same all-odd condition.

No physical cap is used in this argument; 642's S/T mistake does not invalidate 519. The bounded check does not prove every odd blocker must be met by a second matching twice beyond the cited gate, certify exact support, or exclude the one-spoke class.

## 641 and 564: nested classification and direction

For quotient-isolated two-port d, no internal N0 edge touches d, and the only proper edge at d is carrier leg a. The set B∪(F−{d}) has five host boundary edges: a and the four remaining original shore attachments. The B side contains its actual alternating eight-cycle; the opposite side contains the unchanged core/cap cycles. Their orders exceed five (carrier side 19+2r; opposite side 21). These are two non-acyclic sides of a genuine cyclic five-cut.

Proposition 4.4 applies only because the full bridgeless cubic host is assumed to be a globally minimum-order BF counterexample and cyclically five-edge-connected. Neither side is the physical pentagon required in cases I–XII, so the cut is Case XIII. Being a small pole, having exact XII support, or being a minimum candidate within the carrier subclass would not suffice.

Using actual row labels A=DaDb (three positions), B=KJ, C=JDb, D=KDa:

- d carries C,D: the nested carrier-side boundary is a,A,A,A,B. Da and Db each meet the three A positions, hence both miss a,B, giving the actual ordinary loop [aB]. Therefore this side is L* and its opposite is R*.
- d carries A,B: the boundary is a,A,A,C,D. Da misses a,C; Db misses a,D. This gives the actual type (aC)(aD), but this row alone does not fix direction.

564's terminal-independence result uses only the complete R* relation. The (12345) type forbids two terminal semiedges at one vertex. If adjacent distinct terminal vertices are i,j, both their semiedges carry the two triple colours in a suitable cross-class (p)(q) row with p,q⊂T=[5]−{i,j}. The joining edge has two singleton colours. Exactly one of four singleton colours has its port outside p, so at least one joining-edge colour Z is lonely at z∈p. Exchanging one triple colour on both terminal semiedges with Z on their joining edge preserves every cubic six-colour partition. The new missing pairs q and T−{z} lie in the same majority class, producing a forbidden same-class pair or ordinary loop. The sole monochromatic T is {1,2,5}; there i,j=3,4, and the same exchange in an all-terminal row produces two missing pairs in Q. Both cases contradict exact R* support. All ten potential adjacent terminal pairs were checked algebraically.

This validates 564's eight-edge loop-centre deduction under its specific carrier/row/length and global minimum-host inputs: its nested side has an ordinary loop, putting the opposite side in R*, while the remaining length-one AA path has adjacent terminal vertices. It does not validate arbitrary other exterior topologies or establish that this carrier is universal.

## 642: proof gap and verified repair

Original 642's displayed colour tables, reflection and Kempe path do properly colour the two graphs it explicitly writes. Those are cap-S graphs, not the true cap-T opposite poles. Thus those original certificates alone do not prove CD exclusion, AB orientation, or the invoked terminal-independence consequence for the actual host.

Parent supplied corrected-cap-two-tables.json. This review independently reconstructed each graph from the unaltered six-vertex core, five tree subdivisions, four marked subdivisions, five physical cap vertices and six open attachments. For each table I checked:

1. every listed proper edge and semiedge equals the required graph edge set, with no duplicates or omissions;
2. physical cap edge set equals K5−S, not S;
3. all twenty internal vertices see exactly colours {1,2,3};
4. all six terminal colours are (e,p1,p2,p3,p4,p5)=(1,2,2,1,3,3);
5. joining p3 with p4 or p5 (CD), or any of e,p1,p2 with either p4,p5 (AB), gives two distinct colours at d; its remaining semiedge receives 6−c1−c2, making a valid {1,2,3} partition.

These two universal certificates therefore colour every true opposite pole H needed here. CD yields a Tait H in the required R* orientation, impossible because doubled Tait has an ordinary loop absent from R*. AB yields a Tait H, forcing H=L* and the carrier side=R*; 564 then forces distinct, nonadjacent carrier-side terminal vertices. This restores the intended conclusions, conditional on the prior structural and host hypotheses.

I also found direct valid colour certificates for all sixteen true-T joined graphs using bounded fixed-graph backtracking (32–74 recursive nodes per case), independently of the parent's universal tables. The universal tables are the simpler reviewable proof; the finite search does not certify BF support.

## Deliverables and uncovered boundary

- check_support_interfaces.py / support-interface-check.json: four 519 rooted paths; all fifteen shore pairings; 641 row states; ten 564 adjacency cases. Its original-642 colour data are explicitly labelled wrong-cap local validation only.
- check_true_cap.py / true-cap-colouring-check.json: independent true-cap sixteen-case colouring witnesses, no SAT/HPC.
- check_parent_corrected_cap.py / parent-corrected-cap-check.json: independent validation of the two supplied universal true-cap tables, including every d join.
- source-figure7.png and source-appendix-xiii.png: scratch renderings for source verification.

The review assumes the actual tight fourteen-vertex carrier, its common six selected cut legs, the genuine original BF row and first long-route port pattern, as delegated. It does not prove those inputs are forced in an arbitrary exact-XII pole, cover the other long-route signature, audit all carrier history, exclude the surviving isolated AB orientation, certify any candidate's complete support, or settle full Case XII/Berge–Fulkerson. This one bounded pulse is finished.
