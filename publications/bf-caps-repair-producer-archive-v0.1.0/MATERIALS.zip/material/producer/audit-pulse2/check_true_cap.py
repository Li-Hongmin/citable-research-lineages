# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Small fixed 21-vertex cubic five-poles; direct 3-edge-colouring backtracking."""
import json
from collections import defaultdict
from itertools import product
def edge(a,b):return tuple(sorted((str(a),str(b))))
marks={'X':(1,3),'Y':(2,5),'Z':(4,6),'W':(1,6)}
ports={'e','p1','p2','p3','p4','p5'}
def graph(order,joined):
    edges=set()
    for i in range(1,6): edges|={edge(i,f'u{i}'),edge(i+1,f'u{i}'),edge(f'u{i}',f'p{i}')}
    for j,(a,b) in marks.items():edges|={edge(a,f't{j}'),edge(b,f't{j}'),edge(f't{j}',f'bar{j}')}
    for a,b in zip(order,order[1:]+order[:1]):edges.add(edge(f'bar{a}',f'bar{b}'))
    edges.add(edge('bare','e'))
    edges={edge('d' if a in joined else a,'d' if b in joined else b) for a,b in edges}
    edges.add(edge('d','cutd'))
    return sorted(edges)
def solve(edges):
    adj=defaultdict(list)
    for i,(a,b) in enumerate(edges):adj[a].append(i);adj[b].append(i)
    full=[v for v,es in adj.items() if len(es)==3]
    assert len(full)==21 and all(len(es) in [1,3] for es in adj.values())
    cs=[0]*len(edges);used={v:set() for v in adj};calls=0
    def assign(i,c):
        cs[i]=c
        for v in edges[i]:used[v].add(c)
    def unassign(i,c):
        cs[i]=0
        for v in edges[i]:used[v].remove(c)
    for i,c in zip(adj['1'],[1,2,3]):assign(i,c)
    def recurse():
        nonlocal calls
        calls+=1
        if calls>2_000_000: raise RuntimeError('bounded-search limit')
        choices=[]
        for i,(a,b) in enumerate(edges):
            if cs[i]:continue
            possible={1,2,3}-used[a]-used[b]
            if not possible:return False
            choices.append((len(possible),i,possible))
        if not choices:return True
        _,i,possible=min(choices,key=lambda x:x[:2])
        for c in sorted(possible):
            assign(i,c)
            if recurse():return True
            unassign(i,c)
        return False
    ok=recurse()
    if ok:
        assert all({cs[i] for i in adj[v]}=={1,2,3} for v in full)
    return ok,calls,[{'edge':e,'colour':c} for e,c in zip(edges,cs)] if ok else None
out=[]
orders={'T1':['e','Y','Z','X','W'],'T2':['e','Y','X','Z','W']}
for name,order in orders.items():
    for joined in [('p3','p4'),('p3','p5')]+list(product(['e','p1','p2'],['p4','p5'])):
        ok,calls,w=solve(graph(order,joined))
        out.append({'cap':name,'physical_order':order,'joined':joined,'three_edge_colourable':ok,'nodes':calls,'certificate':w})
        print(name,joined,ok,calls)
with open('audit-pulse2/true-cap-colouring-check.json','w') as f:json.dump(out,f,indent=2)
