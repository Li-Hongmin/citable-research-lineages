# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Verify a fixed two-Petersen certificate and three symmetry representatives.

This does not search for PMs/covers or classify graphs. Universal claims follow
from the analytic proof in bf-pulse3-defect-and-distance.md.
"""
import json
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "fixed_certificate", ROOT / "audit-pulse3/check_configuration_gap_certificate.py")
fixed = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixed)


def main():
    ga, ma = fixed.petersen("a")
    gb, mb = fixed.petersen("b")
    removed = {fixed.edge(fixed.vertex(s, "u", 0), fixed.vertex(s, "v", 0))
               for s in "ab"}
    join = {fixed.edge(fixed.vertex("a", k, 0), fixed.vertex("b", k, 0))
            for k in "uv"}
    graph = (ga | gb) - removed | join
    rows = [(a | b) - removed | (join if i in (0, 1) else set())
            for i, (a, b) in enumerate(zip(ma, mb))]
    representatives = []
    for i, j in [(0, 1), (1, 2), (1, 3)]:
        common = ma[i] & ma[j]
        difference = fixed.cycles(ma[i] ^ ma[j])
        assert len(common) == 1 and list(map(len, difference)) == [8]
        representatives.append({"indices_inf_then_0_to_4": [i, j],
                                "common_edge": sorted(common),
                                "difference_cycle": difference[0]})
    complement_lengths = [sorted(map(len, fixed.cycles(ga - m))) for m in ma]
    assert complement_lengths == [[5, 5]] * 6
    actual_pair = (ma[1] | mb[0]) - removed | join
    assert fixed.is_pm(actual_pair, {v for e in graph for v in e})
    assert sorted(map(len, fixed.cycles(rows[0] ^ actual_pair))) == [8]
    given_pair_shapes = []
    for i, j in [(0, 1), (0, 2)]:
        shape = sorted(map(len, fixed.cycles(rows[i] ^ rows[j])))
        assert shape == ([8, 8] if (i, j) == (0, 1) else [16])
        given_pair_shapes.append({"row_indices": [i, j], "difference_lengths": shape})
    output = {"scope": "one fixed graph, six supplied matchings, three symmetry representatives; no PM/cover search",
              "vertices": sorted({v for e in graph for v in e}), "edges": sorted(graph),
              "six_supplied_perfect_matchings": [sorted(m) for m in rows],
              "petersen_representatives": representatives,
              "six_supplied_petersen_complement_lengths": complement_lengths,
              "actual_pair_of_distance_eight": [sorted(rows[0]), sorted(actual_pair)],
              "two_supplied_compatible_pair_shapes": given_pair_shapes,
              "universal_distance_sixteen_claim_basis": "analytic classification and restoration proof, not search"}
    target = ROOT / "bf-pulse3-distance-certificate.json"
    target.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"certificate": target.name, "representatives_verified": 3,
                      "provided_rows": 6, "actual_distance_eight_pair_verified": True}))


if __name__ == "__main__":
    main()
