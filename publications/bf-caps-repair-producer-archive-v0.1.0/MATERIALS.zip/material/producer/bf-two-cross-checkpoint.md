> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Berge–Fulkerson: bounded takeover and the nine-edge two-cross fragment

2026-10-03. This checkpoint is a local research draft, not a promoted theorem or a public deposit.

## Scope and observed takeover boundary

No ancestor or unit `AGENTS.md` was present at the tested project paths. The math-research-system skill and its controller manual, unit README, LOG, all three dated SPEC files, and Notes 655, 654, 542, 642, 648, 534 and 519 were read. Historical frozen SPECs are preserved; the present user delegation authorizes a new bounded pulse and lightweight local checks. LOG is an old Fano-budget record, not current proof authority.

## Bounded audit, with evidence levels

An independent fresh-context agent, using the same model, checked the following interfaces. This is not an independent-model or human external review.

* Note 654's alternating-switch identity is a direct set identity: the residual proper P graph is the union of two matchings, hence its closed components are even. Its local constructions of canonical two-cut matchings check out.
* Note 655's directed reachability count checks out given the full N0 incidence partition, bipartite private chords and the cross-to-cross H–N0 pairing. Its nine-edge adjacent-cross enumeration also checks out given internal cross endpoints and girth at least five.
* Note 655's residual pentagon gate checks out **conditionally** on the canonical exceptional mask and Note 542: an actual one-cross matching with d and a P leg has q≤1; an odd proper component must lie inside P. A seven-cycle is impossible because girth five forbids an internal matching chord of that cycle, at most two vertices can use the selected cross/leg, and at least five would require different mates among only three exterior P vertices.
* Note 655's two explicit forest matching certificates were independently checked.
* Note 542's gluing logic and 14+k parity calculation check out **if** its actual carrier matching table and all-odd premise hold. Note 519's displayed four-pairing mechanism was read and its combinatorial argument inspected; its exact published-support interface was not freshly certified. A subsequent direct local check of the explicit 14-vertex carrier in Note 534 independently supplies two distinct cycle-free pairings for each of the twelve nonexceptional masks, thus checking the carrier-table premise used from Note 540. The full upstream support/host chain remains outside this bounded audit.
* Note 642's local colouring tables and Kempe route were independently inspected. The nested Case-XIII orientation and the complete R* terminal-independence/all-terminal consequences remain upstream conditions, not facts obtained from one selected BF row.

No local counterexample or error was found in these audited interfaces. This does not certify the entire 655 dependency graph. Known README corrections to older Notes 272–296 and 357 are preserved; no superseded uniqueness/orientation claim is used here.

## This pulse's finite proposition

Let P be the path on vertices 0,...,9. Add two vertex-disjoint private chords C, each spanning at least four path edges, with 09 absent. Choose distinct x,y in {1,...,8}, disjoint from chord endpoints. All four other P vertices are legs. Let Q be q0–q1–q2 and put crosses q_i–x and q_j–y for one of the three unordered Q pairs {0,1}, {1,2}, {0,2}, retaining both endpoint assignments. Require the proper graph P+C+Q+crosses to have girth at least five. Set H={01,23,45,67,89}. Require x and y to be the endpoints of the same path component of H+C.

**Candidate finite conclusion, checked computationally:** some endpoint-Q cross q–z and some P leg k admit a perfect matching M of (P+C)−{z,k} such that (P+C)−M has no odd closed component.

With the isolated double-original-port vertex d restored, select the d leg, the k leg, q–z, the unique Q edge on its other two vertices, and M. This is a complete zero-original-port exterior matching: its six proper matching edges and two legs cover all fourteen vertices exactly once. The residual P components have no odd closed cycle. Only one cross remains unselected, so a mixed closed cycle cannot form. The unselected Q leg connects to an original port, giving q≤1.

Under the **additional genuine tight-carrier, complete exact Case-XII BF support, minimum-host and nested-terminal assumptions** of 542/642/654, this matching has a nonexceptional mask. The canonical mask is {d, sole Q leg}; the new {d,k} differs and shares d, while the three exceptional pairs are disjoint. Note 542 then gives a contradiction. Thus the finite proposition, if accepted together with those upstream gates, closes the entire isolated-A,B (9,2) two-cross branch, including the same-parity-chord remainder. It does not close all fourteen-vertex exteriors, other profiles or cross counts, all orders, exact Case XII, or Berge–Fulkerson.

## Reproducibility and finite coverage

Run `python3 check_two_cross.py` from this directory. It uses only the Python standard library, no SAT solver, data download, HPC or remote process. Runtime here was about 0.17 seconds.

The parameterization is exhaustive for the stated **finite** class: every unordered pair of allowed chords is visited; pairs sharing an endpoint are rejected; every ordered pair of remaining internal cross positions and all three Q pairs are visited. No symmetry quotient is used. Each graph is checked for cycles of length below five. H+C has maximum degree two; connectivity of x,y therefore checks their alternating-path partnership, since x,y have degree one in H+C.

Perfect matchings of the eight unexposed P vertices are enumerated by choosing the least remaining vertex and each possible remaining neighbour, then recurring. Each perfect matching has a unique branch through this recursion; none is omitted. Complement components of degree two throughout are precisely the closed components. Certificates explicitly list the four P matching edges, selected cross, selected P leg and residual cycles for every admissible paired graph.

Observed counts: 5,424 girth-valid labelled graphs; 818 cross-paired graphs; 818 with a clean one-cross witness; zero without a one-cross witness and zero with all such witnesses blocked. Among blocked matchings encountered within the 818 graphs, odd cycles were pentagons: 64 with one chord, 24 with two chords. Counts are reproducibility diagnostics; the exhaustive parameterization and explicit matching witnesses carry the finite claim.

Files: `check_two_cross.py`, `two-cross-result.json`, `two-cross-witnesses.json` (818 witnesses). Independent original-655 interface check: `audit/check_655.py`, `audit/check_655_output.json`.

**Independent implementation result:** `audit/check_new_finite_claim.py` uses every four-edge subset of P's eleven proper edges, common-neighbour tests for triangles/quadrilaterals, and residual bipartite colouring. These differ from the primary recursive matching/BFS/component algorithms. It independently obtains 5,424/818/818, with zero failures. Its labelled breakdown is adjacent {0,1}: 1,646/196; adjacent {1,2}: 1,646/196; separated {0,2}: 2,132/426 (girth-valid/cross-paired). The 818 paired graphs have 2,868 actual one-cross matchings altogether. The output also explores allowing 09, but that extra observation is not part of this proposition's assumptions or contribution claim.

`audit/validate_parent_witnesses.py` verifies that all 818 primary records are unique, that their scope keys equal the independently enumerated scope exactly, that every selected matching is actual, and that each residual P graph is bipartite. Results are in `audit/new_finite_claim_result.json` and `audit/parent_witness_validation.json`; independent witnesses are in `audit/clean_one_cross_certificates.json`. This supplies an independently implemented finite check, while the reviewing agent's same-model limitation remains.

`check_carrier_gate.py` and `carrier-gate-check.json` directly verify the twelve nonexceptional carrier masks on the explicit Note-534 graph, without using its symmetry reduction: each has two different cycle-free complement pairings, whose paths span all fourteen vertices. This checks only the local matching premise, not that a genuine minimum host has this carrier. Reproduce with `python3 check_carrier_gate.py`.

Python here: 3.14.7. Primary SHA256: `check_two_cross.py` = `4da2623af2021db919096631dff5d8ee41ac124b6bde93dda0a9d26a050cf66d`; `two-cross-result.json` = `31a51c40cd30a7c9dc7e6a7fbe4eb03d4029515cf34745e0156ec1c7d52db62c`; `two-cross-witnesses.json` = `de49778e70eecaa18ab5caedcd6b4d1780e40b56ca00b1d6c5572c04b7de217e`.

## A compact view of the blocked matchings

The following are the twelve projected P configurations (Q layout forgotten), modulo P reflection, after the finite assumptions and cross pairing. z is the selected endpoint-Q cross's P vertex, y the other cross, k the selected leg in the blocked matching. The replacement uses the **same cross** and a different leg k'. Every row explicitly covers P−{z,k'} and leaves no odd P component. This table gives concrete repairs; its coverage is computational, not an asserted handwritten classification proof. The independent `audit/check_repair_table.py` verified all twelve rows and regenerated exactly these twelve classes from the 88 blocked actual matchings; each projected class had one blocked proper matching. Its result is in `audit/repair_table_result.json`.

| C | z | y | k | k' | replacement M |
|---|---:|---:|---:|---:|---|
|04,26|3|7|5|9|01,26,45,78|
|04,26|5|1|3|7|01,26,34,89|
|05,26|3|7|4|9|01,26,45,78|
|05,26|4|1|3|7|01,23,56,89|
|06,48|7|1|5|2|01,34,56,89|
|07,48|6|1|5|3|07,12,45,89|
|15,27|3|6|4|0|12,45,67,89|
|15,27|6|3|9|0|15,27,34,89|
|15,37|2|6|4|0|15,34,67,89|
|16,28|4|5|7|9|01,23,56,78|
|18,26|4|5|7|9|01,23,56,78|
|18,26|7|3|4|0|12,34,56,89|

## Continuation boundary and minimal public candidate

The cheapest next mathematical step is to audit the exact published-support/nested-terminal interfaces supplying 519/642/654 and the genuine host-to-carrier reduction. The local carrier-pairing table needed by 542 has now been directly checked. If the remaining gates survive, the finite witness collection can support a short conditional branch-exclusion note. Do not automatically advance to another length profile merely because this local check ended.

A possible minimal public contribution is the standalone finite fragment lemma plus its complete witnesses, assumptions and two independent verification programs; it could be stated without publishing the private BF manuscript. It needs: human-approved author names and contribution attribution; permission for every included private dependency; an explicit code/content licence; independent external review; novelty comparison; and the target Commons' actual admission requirements from the parent's public pilot. None is settled here. No private text was uploaded, no signing key generated, no DOI minted, and no release licence assigned.

## End-of-pulse checkpoint