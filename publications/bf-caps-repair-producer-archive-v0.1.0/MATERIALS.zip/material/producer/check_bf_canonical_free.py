# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Fixed pulse-6 certificates only; no graph/matching/phase enumeration.

Universal phase counts and real-host bounds are proved analytically in the
accompanying manuscript. This supplied carrier is not an actual exact-XII Z.
"""
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
I = set(range(4))


def det(a, b):
    return ((a & 1) * ((b >> 1) & 1)) ^ (((a >> 1) & 1) * (b & 1))


def crossing(chords):
    assert sorted(v for ends in chords for v in ends) == list(range(8))
    graph = [set() for _ in chords]
    for r, ends in enumerate(chords):
        a, b = sorted(ends)
        for s in range(r):
            c, d = sorted(chords[s])
            if a < c < b < d or c < a < d < b:
                graph[r].add(s)
                graph[s].add(r)
    return graph


def fixed_phase():
    chords = [(0, 4), (1, 5), (2, 6), (3, 7)]
    graph = crossing(chords)
    assert all(len(n) == 3 for n in graph)
    directions, signs = [1, 2, 1, 3], [0, 1, 0, 1]
    classes = Counter(directions)
    assert [classes[s] % 2 for s in directions] == signs
    assert [sum(det(directions[r], directions[s]) for s in graph[r]) % 2
            for r in range(4)] == signs
    sigma = [directions[v % 4] for v in range(8)]
    current, t = 0, []
    for s in sigma:
        current ^= s
        t.append(current)
    assert current == 0 and set(t) == I
    pairs = [I - {t[(v - 1) % 8], t[v]} for v in range(8)]
    for r, (u, v) in enumerate(chords):
        assert len(pairs[u]) == len(pairs[v]) == 2
        assert pairs[v] == (pairs[u] if signs[r] == 0 else I - pairs[u])
    return {"directions": directions, "signs": signs,
            "C_singletons": t, "endpoint_pairs": [sorted(p) for p in pairs]}, pairs


def supplied_repaired_carrier(phase, pairs):
    # La=Lc=5 exterior path length -> whole K length 7. The common bridges
    # join a1,a2 and c1,c2, leaving ten common ab boundary legs.
    paths = [["0", "a1", "x1", "x2", "x3", "x4", "a2", "4"],
             ["1", "b0", "5"],
             ["2", "c1", "y1", "y2", "y3", "y4", "c2", "6"],
             ["3", "d0", "7"]]
    edges, labels = {}, {}
    for i, t in enumerate(phase["C_singletons"]):
        eid = f"C{i}"
        edges[eid] = (str(i), str((i + 1) % 8))
        labels[eid] = set(("a" if i % 2 == 0 else "b") + "cdef"[t])
    for r, path in enumerate(paths):
        pair = pairs[int(path[0])]
        for j, (u, v) in enumerate(zip(path, path[1:])):
            eid = f"H{r}:{j}"
            edges[eid], labels[eid] = (u, v), {"cdef"[x] for x in pair}
            pair = I - pair
    bridges = [("a1", "a2"), ("c1", "c2")]
    for u, v in bridges:
        edges[f"bridge:{u}"] = (u, v)
        labels[f"bridge:{u}"] = set("ab")
    internal = {v for ends in edges.values() for v in ends}
    bridged = {v for ends in bridges for v in ends}
    for v in sorted(internal - set(map(str, range(8))) - bridged):
        edges[f"port:{v}"] = (v, f"@{v}")
        labels[f"port:{v}"] = set("ab")
    for v in internal:
        incident = [labels[e] for e, ends in edges.items() if v in ends]
        assert len(incident) == 3
        assert Counter(c for label in incident for c in label) == Counter("abcdef")
    assert all(len(label) == 2 for label in labels.values())
    components = {}
    for colour in "ab":
        adj = defaultdict(set)
        for eid, (u, v) in edges.items():
            if colour not in labels[eid]:
                adj[u].add(v)
                adj[v].add(u)
        assert set(adj) == internal and all(len(n) == 2 for n in adj.values())
        remaining, sizes = set(internal), []
        while remaining:
            stack, seen = [min(remaining)], set()
            while stack:
                v = stack.pop()
                if v not in seen:
                    seen.add(v)
                    stack.extend(adj[v] - seen)
            remaining -= seen
            sizes.append(len(seen))
        components[colour] = sorted(sizes)
    assert len(internal) == 22
    assert sum(e.startswith("port:") for e in edges) == 10
    assert components == {"a": [11, 11], "b": [11, 11]}
    return {"scope": "One supplied carrier row with ten common ab ports; not a six-port Z, N/N0 fibre, exact-XII host or girth certificate",
            "internal_vertices": len(internal), "common_ab_ports": 10,
            "whole_K_path_lengths": [len(p) - 1 for p in paths],
            "same_pair_Gamma_lengths": [5, 5],
            "bridge_closed_cycles": [6, 6],
            "target_complement_cycles": components,
            "edges": edges, "row_labels": {e: "".join(sorted(s)) for e, s in labels.items()}}


def main():
    phase, pairs = fixed_phase()
    stars = []
    for chords, centre in [([(0, 2), (4, 6), (1, 5), (3, 7)], 2),
                           ([(0, 6), (2, 4), (1, 5), (3, 7)], 3)]:
        graph = crossing(chords)
        assert len(graph[centre]) == 3
        assert all(len(graph[v]) == 1 for v in range(4) if v != centre)
        stars.append({"chords": chords, "crossings": [sorted(n) for n in graph]})
    # Virtual chord 26 has sign zero and direction one. Original pins cd/cd
    # and whole C-to-port lengths 3,3 have nu=0 and the fixed phase above.
    assert pairs[2] == pairs[6] == {0, 1}
    assert (0 + 3 + 3) % 2 == 0
    assert (2 * 2, 3 * 2 * 4) == (4, 24)
    assert (12 + 5 + 5, 11 + 5, 5 + 6) == (22, 16, 11)
    output = {"method": "Fixed supplied arithmetic and one row certificate; no enumeration",
              "phase": phase, "source_forced_crossed_pairing_stars": stars,
              "h2_fixed_pins": {"original_pairs": ["cd", "cd"],
                                "whole_K_port_lengths": [3, 3], "virtual_sign": 0,
                                "algebraic_phase_count": 4},
              "analytic_bounds_checked_at_minimum_odd_length": {"same_pair_length": 5,
                                                               "h0_carrier": 22,
                                                               "h2_carrier": 16,
                                                               "mixed_odd_cycle": 11},
              "repaired_carrier": supplied_repaired_carrier(phase, pairs)}
    target = ROOT / "bf-pulse6-free-repair-certificate.json"
    target.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"certificate": target.name, "fixed_K4_phase": True,
                      "source_forced_stars": True, "carrier_vertices": 22,
                      "retained_complements": [11, 11], "h2_fixed_pins": True}))


if __name__ == "__main__":
    main()
