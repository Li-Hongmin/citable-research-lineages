# SPDX-License-Identifier: Apache-2.0
# Archival checker source; not executed in this packaging audit.
# Historical asserts may be disabled under optimization; no fresh mathematical certification.
"""Check fixed C8 phase certificates, construct a forest solution and one carrier.

No graph, matching, cover, or direction-assignment enumeration. Universal claims
are the analytic proofs in bf-pulse5-c8-phase-completion.md.
"""
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
I = set(range(4))


def det(a, b):
    return ((a & 1) * ((b >> 1) & 1)) ^ (((a >> 1) & 1) * (b & 1))


def crossing_graph(chords):
    assert sorted(x for pair in chords for x in pair) == list(range(8))
    out = [set() for _ in chords]
    for r, (a, b) in enumerate(chords):
        a, b = sorted((a, b))
        for s in range(r):
            c, d = sorted(chords[s])
            if a < c < b < d or c < a < d < b:
                out[r].add(s)
                out[s].add(r)
    return out


def verify_phase(chords, eps, directions, tau=0):
    graph = crossing_graph(chords)
    assert all(s in (1, 2, 3) for s in directions)
    actual = [sum(det(directions[r], directions[s]) for s in graph[r]) % 2
              for r in range(4)]
    assert actual == eps
    sigma = [None] * 8
    for r, ends in enumerate(chords):
        for v in ends:
            sigma[v] = directions[r]
    t, current = [], tau
    for direction in sigma:
        current ^= direction
        t.append(current)
    assert current == tau
    endpoint_pairs = [I - {t[(v - 1) % 8], t[v]} for v in range(8)]
    assert all(len(a) == 2 for a in endpoint_pairs)
    for r, (a, b) in enumerate(chords):
        expected = endpoint_pairs[a] if eps[r] == 0 else I - endpoint_pairs[a]
        assert endpoint_pairs[b] == expected
    return {"crossing_graph": [sorted(a) for a in graph], "eps": eps,
            "directions": directions, "tau": tau, "cycle_singleton_colours": t,
            "endpoint_pairs": [sorted(a) for a in endpoint_pairs]}


def forest_solution(graph, eps):
    parent, order, components = {}, [], []
    for root in range(len(graph)):
        if root in parent:
            continue
        parent[root] = None
        stack, component = [root], []
        while stack:
            v = stack.pop()
            order.append(v)
            component.append(v)
            for w in sorted(graph[v]):
                if w == parent[v]:
                    continue
                assert w not in parent, "This constructor is for forests only"
                parent[w] = v
                stack.append(w)
        components.append(component)
    bad = [c for c in components if sum(eps[v] for v in c) % 2]
    if bad:
        return {"forest_phase_satisfiable": False, "odd_sign_components": bad}
    subtree = list(eps)
    for v in reversed(order):
        if parent[v] is not None:
            subtree[parent[v]] ^= subtree[v]
    bits = [0] * len(graph)
    for v in order:
        if parent[v] is not None:
            bits[v] = bits[parent[v]] ^ subtree[v]
    assert [sum(bits[v] ^ bits[w] for w in graph[v]) % 2
            for v in range(len(graph))] == eps
    return {"forest_phase_satisfiable": True, "bits": bits,
            "directions": [1 if x == 0 else 2 for x in bits]}


def carrier():
    chords, lengths = [(0, 4), (1, 5), (2, 6), (3, 7)], [3, 2, 3, 2]
    phase = verify_phase(chords, [0, 1, 0, 1], [1, 2, 1, 3])
    edges, labels = {}, {}
    for i, t in enumerate(phase["cycle_singleton_colours"]):
        e = f"C{i}"
        edges[e], labels[e] = (str(i), str((i + 1) % 8)), set(("a" if i % 2 == 0 else "b") + "cdef"[t])
    paths = [["0", "a1", "a2", "4"], ["1", "b1", "5"],
             ["2", "c1", "c2", "6"], ["3", "d1", "7"]]
    for r, path in enumerate(paths):
        pair = set(phase["endpoint_pairs"][int(path[0])])
        for i, (u, v) in enumerate(zip(path, path[1:])):
            eid = f"H{r}:{i}"
            edges[eid], labels[eid] = (u, v), {"cdef"[j] for j in pair}
            pair = I - pair
    internal = {v for ends in edges.values() for v in ends}
    for v in sorted(internal - set(map(str, range(8)))):
        edges[f"port:{v}"], labels[f"port:{v}"] = (v, f"@{v}"), set("ab")
    for v in internal:
        incidence = [labels[e] for e, ends in edges.items() if v in ends]
        assert len(incidence) == 3
        assert Counter(c for label in incidence for c in label) == Counter("abcdef")
    complements = {}
    for color in "ab":
        adj = defaultdict(set)
        for e, (u, v) in edges.items():
            if color not in labels[e]:
                adj[u].add(v)
                adj[v].add(u)
        assert set(adj) == internal and all(len(n) == 2 for n in adj.values())
        remaining, sizes = set(internal), []
        while remaining:
            stack, seen = [min(remaining)], set()
            while stack:
                v = stack.pop()
                if v not in seen:
                    seen.add(v)
                    stack.extend(adj[v] - seen)
            remaining -= seen
            sizes.append(len(seen))
        complements[color] = sorted(sizes)
    assert complements == {"a": [7, 7], "b": [7, 7]}
    assert len(internal) == 14 and sum(e.startswith("port:") for e in edges) == 6
    return {"scope": "one given fourteen-vertex carrier; six common ab boundary slots, not a zero-port exact-XII shore",
            "phase": phase, "path_lengths": lengths, "edges": edges,
            "row_labels": {e: "".join(sorted(s)) for e, s in labels.items()},
            "internal_vertices": 14, "common_ab_ports": 6,
            "complement_lengths": complements,
            "binary_impossibility_basis": "K4 F2 Laplacian is the all-ones matrix; eps0101 is outside its image"}


def main():
    path_chords = [(0, 2), (1, 4), (3, 6), (5, 7)]
    graph = crossing_graph(path_chords)
    solved = forest_solution(graph, [1, 1, 0, 0])
    assert solved["forest_phase_satisfiable"]
    phase = verify_phase(path_chords, [1, 1, 0, 0], solved["directions"])
    virtual = verify_phase(path_chords, [1, 1, 0, 0], solved["directions"], tau=2)
    # Virtual chord 0 connects C vertices 0 and 2. Pins cd/cd and Lp=1,Lq=2.
    assert virtual["endpoint_pairs"][0] == [0, 1]
    assert virtual["endpoint_pairs"][2] == [2, 3]
    obstruction = forest_solution(crossing_graph([(0, 1), (2, 3), (4, 5), (6, 7)]), [1, 1, 0, 0])
    assert not obstruction["forest_phase_satisfiable"]
    output = {"method": "Fixed phase checks, constructive forest leaf elimination, one supplied carrier; no enumeration",
              "abstract_forest_arithmetic_scope": "Not an exact-XII host or a graph-family census",
              "forest_chords": path_chords, "forest_solution": solved, "forest_phase": phase,
              "two_port_virtual_chord_phase": virtual,
              "two_port_pins": {"first": [0, 1], "second": [0, 1], "lengths_including_semiedges": [1, 2], "virtual_epsilon": 1},
              "isolated_chord_obstruction": obstruction, "three_direction_carrier": carrier()}
    target = ROOT / "bf-pulse5-phase-certificate.json"
    target.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"certificate": target.name, "forest_constructor": True,
                      "virtual_phase": True, "isolated_phase_obstruction": True,
                      "carrier_vertices": 14, "carrier_complements": [7, 7]}))


if __name__ == "__main__":
    main()
