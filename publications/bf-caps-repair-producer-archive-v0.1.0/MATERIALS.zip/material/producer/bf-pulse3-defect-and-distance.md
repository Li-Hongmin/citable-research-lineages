> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Odd-cycle defects obstruct BF pair switching

New contribution candidate, version 1, 2026-10-03. This document does not replace either previously frozen BF packet. It proves a necessary completion condition and gives one explicit structural counterexample to a proposed unrestricted reduction. It does not resolve the Berge–Fulkerson conjecture or a minimum-counterexample configuration problem.

## Definitions and statements

A six-perfect-matching double cover is a list of six perfect-matching occurrences in which every edge occurs exactly twice. Occurrences may in principle repeat. Two actual perfect matchings are **BF-compatible** if they occupy two distinct slots in some such list. Write delta(P,Q)=|P symmetric-difference Q|. In a cubic graph, deleting a perfect matching leaves its complementary 2-factor.

**Proposition 1 (necessary odd-cycle defect bound).** Let Q and P be BF-compatible. For every odd cycle O with no edge in Q,

    |P intersection E(O)| >= 2.

In particular this applies to every odd closed component of the complement of Q in a cubic graph or cubic multipole. For multipoles, the cycle is internal and closed; no assertion about odd open paths is made. The count concerns cycle edges, not arbitrary edges whose endpoints lie in the cycle vertex set.

**Proposition 2 (fixed counterexample to unrestricted pair minimization).** There is an explicit connected, simple, bridgeless cubic graph G20 of girth five, with a six-perfect-matching double cover, such that:

1. The complement of every actual perfect matching contains odd cycles (in fact at least two pentagons).
2. The minimum positive delta over all pairs of actual perfect matchings is 8.
3. Every BF-compatible pair has delta=16. Its difference is either two disjoint eight-cycles or one sixteen-cycle.

Thus matching switching and minimization over actual perfect matchings cannot be substituted for switching and minimization over BF-compatible pairs. G20 has a cyclic two-edge cut. It is outside the cyclically-five-edge-connected minimum-host setting and outside the asserted full exact-Case-XII boundary setting. The example refutes only the unrestricted implication.

## Proof of the defect bound and switching consequence

Write |O|=2r+1 and let the remaining four matching occurrences be R1,...,R4. Since Q uses no cycle edge and each Ri uses at most r cycle edges, exact double coverage gives

    4r+2 = 2|E(O)| = |P intersection E(O)| + sum_i |Ri intersection E(O)|
          <= |P intersection E(O)| + 4r.

This proves Proposition 1. It needs no minimum-host, girth or exact-support hypothesis. Boundary semiedges and matching chords do not increase the maximum number of cycle edges in a matching.

Now let D=Q1 symmetric-difference Q2, and let C be the edge set of any union of its internal alternating cycle components. Switching just Q1 gives

    Q1'=(Q1 minus C) union (Q2 intersection C).

This is an actual perfect matching: on each selected cycle each vertex replaces its Q1 edge by its Q2 edge. For zero-port occurrences such a switch preserves the zero-port boundary mask. If O is an odd complementary cycle of Q2, then

    |Q1' intersection E(O)| = |(Q1 minus C) intersection E(O)|.

Consequently BF compatibility of Q1',Q2 requires retaining at least two unflipped Q1 edges on **each** such odd cycle. A violation certifies impossibility of every completion by four further occurrences, not just failure of a particular original row. Satisfaction of all these inequalities is only necessary; no sufficient completion theorem follows.

When D consists entirely of internal alternating cycles (in particular for two zero-port occurrences), write its components as C1,...,Cm and define w_i(O)=|Q1 intersection E(C_i) intersection E(O)|. If the target switch retains just component C_j and flips every other component, a necessary condition is w_j(O)>=2 for every odd complementary cycle O of Q2. This follows because any Q1 edge on O is absent from Q2 and hence belongs to D. Thus even the existence of a single component able to retain all odd-cycle obligations is a separate issue, before sufficient BF completion is considered. This formulation is not asserted for multipole pairs whose difference also has boundary paths.

## Construction of G20

Indices below are modulo five. A Petersen graph has vertices u_i,v_i, outer edges u_i u_(i+1), spokes u_i v_i, and inner edges v_i v_(i+2). Define

    M_inf = {u_i v_i : i=0,...,4},
    M_k = {u_k v_k, u_(k+1)u_(k+2), u_(k+3)u_(k+4),
           v_(k+1)v_(k+3), v_(k+2)v_(k+4)}  (k=0,...,4).

Each is a perfect matching. Every spoke occurs in M_inf and M_i; every outer edge u_i u_(i+1) occurs in M_(i-1) and M_(i-3); every inner edge v_i v_(i+2) occurs in M_(i-1) and M_(i-2). These six matchings therefore double-cover all edges.

Take copies a,b. Remove e0^a=u0^a v0^a and e0^b=u0^b v0^b and add the joining edges j_u=u0^a u0^b and j_v=v0^a v0^b. For each of the six matching labels, combine its two copy-matchings, delete the removed edges, and insert both joining edges exactly for labels inf and 0. This produces six actual perfect matchings of G20 and covers every edge twice. The graph has 20 vertices and 30 edges.

Removing j_u,j_v separates the copies, each of which retains an outer pentagon. Hence this is a cyclic two-edge cut. Connectivity and cubicity follow directly from the construction. A cubic graph with a six-perfect-matching double cover has no bridge: either shore of a bridge has odd order by cubic degree counting, so matching-cut parity puts the bridge in every perfect matching, giving load six instead of two.

The Petersen graph has girth five. Indeed, cycles without spokes lie in one of its two pentagons; a cycle with two spokes of length less than five would require the same pair of indices to be adjacent in both outer and inner pentagons, which requires both a difference of ±1 and ±2 modulo five. Four spokes require at least four additional edges. Any G20 cycle crossing the joining cut uses both its edges and a u0-v0 path in each edge-deleted copy. Each such path has length at least four, since restoring e0 would otherwise give a Petersen cycle shorter than five. Crossing cycles have length at least ten. The retained outer pentagons show that G20 has girth exactly five.

## Analytic classification and the distance gap

**All Petersen perfect matchings.** Let s be the number of spokes in a perfect matching. The unmatched outer vertices are paired by outer edges, so 5-s is even and s is 1,3 or 5. If s=3, the same two remaining indices would have to be adjacent in the outer pentagon and in the inner pentagon, impossible. If s=1 with index k, deletion of index k leaves a four-vertex path in each pentagon; both path matchings are unique and yield M_k. If s=5 the matching is M_inf. Thus the six displayed matchings are the full list, by this proof rather than enumeration.

**Multiplicities in any Petersen six-cover.** Let a count M_inf occurrences and b_k count M_k occurrences. Spoke loads give a+b_k=2 for each k. Six occurrences give a+sum_k b_k=6. Hence 10-4a=6, so a=1 and b_k=1 for all k. Every six-cover uses each matching exactly once.

**Restriction and restoration at the joining cut.** A G20 perfect matching uses zero or two joining edges, because either ten-vertex shore has an even matching cut. If it uses two, delete them and restore e0 in each shore restriction; if it uses zero, leave each restriction unchanged. This is a bijection between G20 perfect matchings and ordered pairs of Petersen perfect matchings having the same e0-use bit. The bit-one class is {M_inf,M_0}; the bit-zero class is {M_1,M_2,M_3,M_4}.

In any G20 six-cover, exactly two occurrences use both joining edges, since each joining edge has load two. Restoring the shore matchings therefore restores load two on e0 and preserves load two on every other Petersen edge. Each restored shore list is a Petersen six-cover, so uses each of its six matchings exactly once. In particular any two distinct slots restrict to different matchings in **both** shores. This also excludes repeated G20 matching occurrences in a six-cover.

**Petersen pair differences.** Any two distinct displayed Petersen matchings share exactly one edge and differ along a single eight-cycle. Rotation, and interchange of the pair, reduce verification to (M_inf,M_0), (M_0,M_1), (M_0,M_2). The common edges in these three cases are respectively u0v0, v2v4, u3u4. Their difference cycles are respectively

    u1-u2-v2-v4-u4-u3-v3-v1-u1,
    u0-v0-v3-v1-u1-u2-u3-u4-u0,
    u0-v0-v3-v1-v4-v2-u2-u1-u0.

For a BF-compatible pair in G20, both shores change. If the two occurrences have equal use-bits, neither shore difference uses e0, so the actual difference consists of two eight-cycles. If their bits differ, each shore eight-cycle uses e0; removing it leaves a seven-edge path. The two paths joined by j_u,j_v form one sixteen-cycle. Thus every compatible pair has delta=16, and the supplied cover provides such pairs.

For arbitrary distinct actual matchings with equal bits, one or both shores change, giving delta 8 or 16. Different bits always give delta 16. The ordered shore pairs (M_inf,M_inf) and (M_0,M_inf) provide actual G20 matchings with difference one eight-cycle. This proves the minimum positive actual distance is 8 and completes the distance claim.

## Odd complements and an explicit failed switch

The complement of each Petersen matching is two pentagons. For M_inf these are the outer and inner cycles. For M_0 they are

    O1=u0-u1-v1-v4-u4-u0,
    O2=u2-u3-v3-v0-v2-u2;

rotation gives the other M_k cases. A G20 matching using both joining edges therefore has complement lengths [5,5,5,5]. A matching using neither has e0 on one complementary pentagon in each copy. Deleting those edges leaves two four-edge paths, joined through j_u,j_v into a ten-cycle; one pentagon remains in each copy. Its complementary lengths are [5,5,10]. This proves every perfect-matching complement contains odd cycles. It does not claim all its components are odd.

Let Q1 be the supplied inf occurrence and Q2 the supplied 0 occurrence. Their difference is one eight-cycle per copy. Each of Q2's four complementary pentagons has two Q1 edges. Switch Q1 only on copy a's difference cycle. The resulting actual Q1' agrees with Q2 on that copy, so has zero edges on both of its odd cycles; the two counts in copy b remain two. Proposition 1 forbids Q1',Q2 from cooccurring in any six-cover. The obstruction lies in the **switched** copy. This also gives a direct witness that component switching of an actual matching need not preserve pair compatibility.

## Reproduction, limitations and release information

From this document's directory run:

    python3 audit-pulse3/check_configuration_gap_certificate.py
    python3 check_bf_pair_distance.py

The first script verifies the supplied graph, six supplied matching occurrences, double coverage, the selected difference and complement cycles, both single-component switches and the cyclic two-cut. The second checks the three symmetry representatives, six supplied Petersen complements, an actual distance-eight pair and supplied compatible pairs of both shapes. It exports the graph edges and six matching lists in `bf-pulse3-distance-certificate.json`. Neither searches for matchings or covers. The universal conclusions are the analytic proofs above, not search assertions.

The fresh-context review is `audit-pulse3/configuration-gap-independent-review.md`. It is by the same model family; no human scientific acceptance or external-model review is claimed. The final text review additionally identified two needed scope clarifications, now applied: the weighted component formulation excludes multipole differences with boundary paths, and the bridge parity argument explicitly uses cubicity. No order-minimality or mathematical novelty claim is made. The full Case-XII support, cyclic connectivity and global-minimum hypotheses are absent from this graph, so their joint configuration-forcing question remains open.

This is a possible minimal contribution for the separate, user-designated Public AI Research Commons task. Release selection, authorship/contributor order, licence choice, external verification, novelty/prior-art assessment and repository admission remain with that task. The text and scripts contain no copied private source-proof passages; historical note identifiers are needed only in the separate internal handover. No upload, public archive, signing key or DOI has been created. Hashes identify the reviewed local version; they are not signatures or publication acceptance.
