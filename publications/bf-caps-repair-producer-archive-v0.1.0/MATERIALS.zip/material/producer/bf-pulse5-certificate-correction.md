> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Fixed carrier expectation corrected

The first execution of `python3 check_bf_c8_phases.py` failed at the assertion expecting both complementary length lists to be `[5,9]`. This was an incorrect expectation in the new pulse-5 draft, not a failure of the constructed phase row. No prior packet or original project note was altered.

For the stated C8 and path lengths `(3,2,3,2)`, the a-complement components follow the cyclic-vertex orders `0,7,3,4,0` and `1,2,6,5,1`, with expanded lengths respectively `1+2+1+3=7` and `1+3+1+2=7`. The b-complement components follow `0,1,5,4,0` and `2,3,7,6,2`, again both of length seven. The a-slot uses the even-index C edges; b uses the odd-index ones.

The program and draft now expect `[7,7]`. The incidence labels, three-direction phase certificate, signs `(0,1,0,1)` and fourteen-vertex/six-common-port carrier are unchanged. This failed assertion and its correction remain explicit evidence; they are not silently omitted from the packet.
